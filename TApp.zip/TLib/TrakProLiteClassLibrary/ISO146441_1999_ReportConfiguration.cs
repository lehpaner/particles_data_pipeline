﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ISO146441_1999_ReportConfiguration
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ISO146441_1999_ReportConfiguration : StandardsReportConfiguration
  {
    protected ISO146441_1999_ReportConfiguration()
      : base("ISO 14644-1:1999")
    {
      this.standardCutPointsMicrometres = new Decimal[6]
      {
        0.1M,
        0.2M,
        0.3M,
        0.5M,
        1.0M,
        5.0M
      };
      this.minimumRequiredSampleTimeForStandard = new TimeSpan(0, 1, 0);
      this.roomStatusStrings = new string[3]
      {
        "AtRest",
        "Operational",
        "AsBuilt"
      };
      this.airFlowStrings = new string[2]
      {
        "Unidirectional",
        "Multidirectional"
      };
      this.metricMeasurements = true;
      this.roomAreaSquareMetres = 9M;
      this.classLevelIndex = 1;
      this.roomStatusIndex = 1;
      this.allowsSampleExclusion = true;
      this.requiresReplacementOfExcluded = false;
      this.maxAllowedSamplesExcluded = (short) 1;
    }

    protected override Decimal CalculateConcentrationLimitNumberOfParticlePerVolume(
      Decimal particleSize)
    {
      return particleSize > 0M ? StandardsReportConfiguration.SignificantDigits(Math.Pow(10.0, this.ClassLevel) * Math.Pow(0.1 / (double) particleSize, 2.08), 3) : 0.0M;
    }

    protected override Decimal CalculateMinimumSampleVolume(
      Decimal concentrationLimitsNumberOfParticlesPerCubicMetre)
    {
      Decimal minimumSampleVolume = 2.0M;
      if (concentrationLimitsNumberOfParticlesPerCubicMetre <= 0M)
        return minimumSampleVolume;
      Decimal num = 20M / concentrationLimitsNumberOfParticlesPerCubicMetre * 1000M;
      if (num > minimumSampleVolume)
        minimumSampleVolume = num;
      return minimumSampleVolume;
    }

    public double ClassLevel => (double) (this.ClassLevelIndex + 2);

    public override bool IsMinimumSampleTimeRequired => true;

    public override bool IsValidRoomStatusAndClass(int roomStatusIndex, int classLevelIndex)
    {
      return true;
    }

    public override int MinimumNumberOfSampleLocationsForAirFlowAndArea
    {
      get => Convert.ToInt32(Math.Ceiling(Math.Sqrt(Convert.ToDouble(this.roomAreaSquareMetres))));
    }

    public override int MinimumNumberOfSamplesPerZoneForSamples
    {
      get
      {
        int forAirFlowAndArea = this.MinimumNumberOfSampleLocationsForAirFlowAndArea;
        return forAirFlowAndArea == 1 ? 3 : forAirFlowAndArea;
      }
    }

    public override int MinimumNumberOfSamplesPerLocation
    {
      get => this.MinimumNumberOfSampleLocationsForAirFlowAndArea == 1 ? 3 : 1;
    }

    public override Decimal MinimumSampleTimePerLocationSeconds => 60.0M;

    public override bool Uses95UCL => true;

    public override bool UsesStandardError => true;

    public override VolumeType VolumeUnits => VolumeType.Litres;
  }
}
