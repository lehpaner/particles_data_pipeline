﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.SamplingInformation
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class SamplingInformation : DataTable
  {
    public static string SamplingInfoTableName = nameof (SamplingInformation);
    public static string SampleHeaderColumnName = "SampleHeader";
    public static string MinColumnName = "Minimum";
    public static string ActualColumnName = "Actual";
    public static string MeetsMinReq = nameof (MeetsMinReq);

    public SamplingInformation()
      : base(SamplingInformation.SamplingInfoTableName)
    {
      this.Columns.Add(new DataColumn(SamplingInformation.SampleHeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(SamplingInformation.MinColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(SamplingInformation.ActualColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(SamplingInformation.MeetsMinReq, typeof (bool)));
    }
  }
}
