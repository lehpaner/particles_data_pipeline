﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.VersionDeserializationBinder
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using TSI;
using TSI.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  internal sealed class VersionDeserializationBinder : SerializationBinder
  {
    public override Type BindToType(string assemblyName, string typeName)
    {
      Type type = (Type) null;
      string fullName = Assembly.GetExecutingAssembly().FullName;
      if (typeName.StartsWith("System.Collections.Generic.List"))
      {
        if (typeName.Contains("TSI"))
        {
          int startIndex = typeName.IndexOf("[[") + 2;
          int num = typeName.IndexOf(", ");
          switch (typeName.Substring(startIndex, num - startIndex))
          {
            case "TSI.ModbusMap2Recipe":
              type = typeof (List<ModbusMap2Recipe>);
              break;
            case "TSI.ModbusMap2Record":
              type = typeof (List<ModbusMap2Record>);
              break;
            case "TSI.Data.Record_9303":
              type = typeof (List<Record_9303>);
              break;
          }
        }
        else
        {
          int num = typeName.IndexOf(", Version");
          StringBuilder stringBuilder = new StringBuilder(typeName, 0, num + 1, num + 10);
          stringBuilder.Append("]]");
          type = Type.GetType(stringBuilder.ToString());
        }
      }
      else
        type = Type.GetType(string.Format("{0}, {1}", (object) typeName, (object) fullName));
      return type;
    }
  }
}
