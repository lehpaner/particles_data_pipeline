﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.LocationData
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class LocationData : DataTable
  {
    public static string LocationDataTableName = nameof (LocationData);
    public static string LocationHeaderColumnName = "LocationHeader";
    public static string LocationColumnName = "Location";
    public static string NumSamplesColumnName = "NumSamples";
    public static string SizeColumnName = "Size";
    public static string AverageColumnName = "Average";
    public static string OverConcLimit = nameof (OverConcLimit);

    public LocationData()
      : base(LocationData.LocationDataTableName)
    {
      this.Columns.Add(new DataColumn(LocationData.LocationHeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(LocationData.LocationColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(LocationData.NumSamplesColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(LocationData.SizeColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(LocationData.AverageColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(LocationData.OverConcLimit, typeof (bool)));
    }
  }
}
