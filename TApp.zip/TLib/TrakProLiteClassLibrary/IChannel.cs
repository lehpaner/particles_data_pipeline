﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.IChannel
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public interface IChannel
  {
    bool AlarmActive { get; }

    bool Interpolated { get; }

    Decimal ParticleSizeMicrometres { get; }

    Decimal ParticleCount { get; }
  }
}
