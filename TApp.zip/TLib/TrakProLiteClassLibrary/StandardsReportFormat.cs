﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.StandardsReportFormat
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class StandardsReportFormat : DataSet
  {
    private string standardConfigName;
    private string concentrationHeading;

    public static string StandardsReportDataSetName() => "Standards Report";

    public string StandardConfigName => this.standardConfigName;

    public string ConcentrationHeading => this.concentrationHeading;

    public string ReportTitle { get; set; }

    public string Username { get; set; }

    public bool ReviewerSignatureLine { get; set; }

    public StandardsReportFormat(string standardName, bool metric, bool addReviewerLine)
    {
      this.standardConfigName = standardName;
      this.concentrationHeading = string.Format("Conc (#/{0})", metric ? (object) ReportStrings.M3 : (object) ReportStrings.FT3);
      this.ReportTitle = string.Empty;
      this.Username = string.Empty;
      this.ReviewerSignatureLine = addReviewerLine;
      this.Tables.Add((DataTable) new HeaderInformation());
      this.Tables.Add((DataTable) new CleanroomInformation());
      this.Tables.Add((DataTable) new InstrumentInformation());
      this.Tables.Add((DataTable) new SamplingInformation());
      this.Tables.Add((DataTable) new ParticleData());
      this.Tables.Add((DataTable) new LocationData());
      this.Tables.Add((DataTable) new ExcludedSample());
      this.Tables.Add((DataTable) new Comments());
    }
  }
}
