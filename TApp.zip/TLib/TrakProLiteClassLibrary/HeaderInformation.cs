﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.HeaderInformation
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class HeaderInformation : DataTable
  {
    public static string HeaderInfoTableName = nameof (HeaderInformation);
    public static string RoomHeaderColumnName = "Room";
    public static string RoomColumnName = "RoomName";
    public static string DateHeaderColumnName = "Date";
    public static string DateColumnName = "CollectionDate";

    public HeaderInformation()
      : base(HeaderInformation.HeaderInfoTableName)
    {
      this.Columns.Add(new DataColumn(HeaderInformation.RoomHeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(HeaderInformation.RoomColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(HeaderInformation.DateHeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(HeaderInformation.DateColumnName, typeof (string)));
    }
  }
}
