﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.CleanroomInformation
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class CleanroomInformation : DataTable
  {
    public static string CleanroomInfoTableName = nameof (CleanroomInformation);
    public static string HeaderColumnName = "RoomHeader";
    public static string ValueColumnName = "RoomValue";

    public CleanroomInformation()
      : base(CleanroomInformation.CleanroomInfoTableName)
    {
      this.Columns.Add(new DataColumn(CleanroomInformation.HeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(CleanroomInformation.ValueColumnName, typeof (string)));
    }
  }
}
