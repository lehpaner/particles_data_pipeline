﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ReportViewerFormatService
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Data;
using System.Security.Principal;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ReportViewerFormatService : ReportFormatService
  {
    private static ReportViewerFormatService instance = new ReportViewerFormatService();

    public static ReportViewerFormatService Instance => ReportViewerFormatService.instance;

    public StandardsReportFormat FormatStandardsReport(
      StandardsReportConfiguration reportConfiguration,
      IInstrument deviceInformation,
      string strUserName)
    {
      StandardsReportFormat report = new StandardsReportFormat(reportConfiguration.ConfigurationName, reportConfiguration.MetricMeasurements, reportConfiguration.AddReviewerSignature);
      this.PrintCleanroomInformation(report, reportConfiguration.ZoneName, reportConfiguration.RecipeName, reportConfiguration.ClassLevelText, reportConfiguration.RoomArea, reportConfiguration.RoomAreaUnitsText, reportConfiguration.RoomStatusText, reportConfiguration.AirFlowText);
      this.PrintInstrumentInformation(report, deviceInformation.ModelNumber, deviceInformation.SerialNumber, deviceInformation.LastCalibrationDate, reportConfiguration.SampledBy);
      Decimal[] micrometersSpecified = reportConfiguration.CutPointsSizesMicrometersSpecified;
      int actualSampleLocations = 0;
      Decimal samplesPerLocation = 0M;
      Decimal inputVolumeLitres = Decimal.MaxValue;
      List<ReportViewerFormatService.LocationDataSummary> locationSummary = new List<ReportViewerFormatService.LocationDataSummary>();
      bool flag1 = false;
      if (reportConfiguration.StandardsChannelStatistics != null)
      {
        this.meetsStandardsSampleAndVolumeRequirements = true;
        this.meetsStandardsConcentrationRequirements = true;
        this.meetsStandardsUCLChannelConcentrationLimitRequirements = true;
        for (int sizeIndexesForClass = reportConfiguration.MinimumRequiredParticleSizeIndexesForClass; sizeIndexesForClass <= reportConfiguration.MaximumRequiredParticleSizeIndexesForClass; ++sizeIndexesForClass)
        {
          StandardsChannelStatistics channelStatistic = reportConfiguration.StandardsChannelStatistics[sizeIndexesForClass];
          if (Array.IndexOf<Decimal>(micrometersSpecified, channelStatistic.CutPointSizeMicrometres) > -1 && channelStatistic.Count > 0)
          {
            actualSampleLocations = channelStatistic.Count;
            samplesPerLocation = (Decimal) channelStatistic.MinSamplesPerZoneLocation;
            flag1 = true;
            Decimal num = reportConfiguration.ConcentrationLimitsNumberOfParticlesPerVolumeForCurrentChannelSizesAndClassLevel[sizeIndexesForClass];
            bool meetsStandardsConcentrationRequirements = this.MeetsStandardsChannelConcentrationLimitRequirements(num, channelStatistic.StandardsLocationStatistics);
            if (!meetsStandardsConcentrationRequirements)
              this.meetsStandardsConcentrationRequirements = false;
            bool meetsStandardsUCLChannelConcentrationLimitRequirements = !reportConfiguration.Uses95UCL || channelStatistic.Count <= 1 || channelStatistic.Count >= 10 || this.MeetsStandardsUCLChannelConcentrationLimitRequirements(num, channelStatistic);
            if (!meetsStandardsUCLChannelConcentrationLimitRequirements)
              this.meetsStandardsUCLChannelConcentrationLimitRequirements = false;
            this.PrintConcentrationEvaluation(report, reportConfiguration.MetricMeasurements, num, reportConfiguration.ConcentrationLimitPrintFormat, reportConfiguration.Uses95UCL, reportConfiguration.UsesStandardError, channelStatistic, meetsStandardsConcentrationRequirements, meetsStandardsUCLChannelConcentrationLimitRequirements);
            foreach (StandardsLocationStatistics locationStatistic in channelStatistic.StandardsLocationStatistics)
            {
              int index = 0;
              bool flag2 = false;
              while (index < locationSummary.Count && !flag2)
              {
                flag2 = string.Compare(locationStatistic.Location, locationSummary[index].Location) == 0;
                if (!flag2)
                  ++index;
              }
              if (!flag2)
                locationSummary.Add(new ReportViewerFormatService.LocationDataSummary(locationStatistic.Location, channelStatistic.CutPointSizeMicrometres, locationStatistic.Count, locationStatistic.Mean, num));
              else
                locationSummary[index].AddParticleStatistics(channelStatistic.CutPointSizeMicrometres, locationStatistic.Count, locationStatistic.Mean);
            }
            bool flag3 = this.MeetsStandardsLocationRequirements(reportConfiguration.MinimumNumberOfSampleLocationsForAirFlowAndArea, channelStatistic);
            bool flag4 = this.MeetsStandardsVolumeRequirements(reportConfiguration.MinimumSampleVolumesPerLocationForClass[sizeIndexesForClass], Sample.ConvertLitresVolume(channelStatistic.MinimumVolume, reportConfiguration.VolumeUnits));
            bool flag5 = this.MeetsStandardsSamplesPerZoneRequirements(reportConfiguration.MinimumNumberOfSamplesPerZoneForSamples, channelStatistic.SamplesPerZone);
            if (!flag3 || !flag5 || !flag4)
              this.meetsStandardsSampleAndVolumeRequirements = false;
          }
          if (channelStatistic.MinimumVolume < inputVolumeLitres)
            inputVolumeLitres = channelStatistic.MinimumVolume;
        }
        Decimal sampleRequirement = reportConfiguration.MinimumVolumePerSampleRequirement;
        this.PrintSamplingInformation(report, reportConfiguration.MinimumNumberOfSampleLocationsForAirFlowAndArea, reportConfiguration.MinimumNumberOfSamplesPerZoneForSamples, actualSampleLocations, reportConfiguration.MinimumNumberOfSamplesPerLocation, samplesPerLocation, reportConfiguration.SampleCount, reportConfiguration.IsMinimumSampleTimeRequired, reportConfiguration.MinimumRequiredSampleTimeForStandard, reportConfiguration.MinimumSampleTime, sampleRequirement, Sample.ConvertLitresVolume(inputVolumeLitres, reportConfiguration.VolumeUnits), reportConfiguration.VolumeUnits);
        this.PrintLocationData(report, locationSummary);
        this.PrintExcludedSample(report, reportConfiguration.StandardsChannelStatistics, reportConfiguration, reportConfiguration.MetricMeasurements, reportConfiguration.ExcludedSamples);
      }
      if (!flag1)
        this.meetsStandardsSampleAndVolumeRequirements = false;
      if (reportConfiguration.IsMinimumSampleTimeRequired && !this.MeetsStandardsMinimumSampleTimeRequirements(reportConfiguration.MinimumRequiredSampleTimeForStandard, reportConfiguration.MinimumSampleTime))
        this.meetsStandardsSampleAndVolumeRequirements = false;
      string result = ReportFormatService.PassFailOrInvalid(this.meetsStandardsSampleAndVolumeRequirements, this.meetsStandardsConcentrationRequirements && this.meetsStandardsUCLChannelConcentrationLimitRequirements, reportConfiguration.InstrumentFunctionedCorrectlyAcrossAllSamples);
      this.PrintHeaderInformation(report, report.StandardConfigName, reportConfiguration.FirstSampleTimestamp, reportConfiguration.LastSampleTimestamp, result, !reportConfiguration.InstrumentFunctionedCorrectlyAcrossAllSamples);
      report.ReportTitle = reportConfiguration.ReportTitle;
      this.PrintComments(report, reportConfiguration.Comments);
      report.Username = string.IsNullOrEmpty(strUserName) ? WindowsIdentity.GetCurrent().Name : strUserName;
      return report;
    }

    protected void PrintHeaderInformation(
      StandardsReportFormat report,
      string standardName,
      DateTime firstSampleDate,
      DateTime lastSampleDate,
      string result,
      bool instrError)
    {
      string str1 = string.Format("{0} - {1}", (object) firstSampleDate.ToString("dd'/'MM'/'yyyy"), (object) lastSampleDate.ToString("dd'/'MM'/'yyyy"));
      string str2 = string.Format("{0} - {1}", (object) firstSampleDate.ToString("HH:mm:ss"), (object) lastSampleDate.ToString("HH:mm:ss"));
      report.Tables[HeaderInformation.HeaderInfoTableName].Rows.Add((object) "Standard:", (object) standardName, (object) ReportStrings.DateDataTaken, (object) str1);
      report.Tables[HeaderInformation.HeaderInfoTableName].Rows.Add((object) ReportStrings.CertificateResult, (object) result, (object) ReportStrings.TimeDataTaken, (object) str2);
      if (!instrError)
        return;
      report.Tables[HeaderInformation.HeaderInfoTableName].Rows.Add((object) string.Empty, (object) ReportStrings.InstrumentError, (object) string.Empty, (object) string.Empty);
    }

    protected void PrintCleanroomInformation(
      StandardsReportFormat report,
      string zoneName,
      string recipeName,
      string targetClass,
      Decimal area,
      string areaUnits,
      string occupancyState,
      string airFlow)
    {
      report.Tables[CleanroomInformation.CleanroomInfoTableName].Rows.Add((object) ReportStrings.ZoneName, (object) zoneName);
      report.Tables[CleanroomInformation.CleanroomInfoTableName].Rows.Add((object) ReportStrings.RecipeName, (object) recipeName);
      report.Tables[CleanroomInformation.CleanroomInfoTableName].Rows.Add((object) ReportStrings.TargetClass, (object) targetClass);
      string str = string.Format("{0} {1}", (object) area.ToString("0.0"), (object) areaUnits);
      report.Tables[CleanroomInformation.CleanroomInfoTableName].Rows.Add((object) ReportStrings.AreaHeading, (object) str);
      report.Tables[CleanroomInformation.CleanroomInfoTableName].Rows.Add((object) ReportStrings.OccupancyState, (object) occupancyState);
      report.Tables[CleanroomInformation.CleanroomInfoTableName].Rows.Add((object) ReportStrings.AirFlowDirection, (object) airFlow);
    }

    protected void PrintInstrumentInformation(
      StandardsReportFormat report,
      string model,
      string serial,
      DateTime calDate,
      string sampledBy)
    {
      report.Tables[InstrumentInformation.InstrumentInfoTableName].Rows.Add((object) ReportStrings.Instrument, (object) model);
      report.Tables[InstrumentInformation.InstrumentInfoTableName].Rows.Add((object) ReportStrings.SerialNum, (object) serial);
      report.Tables[InstrumentInformation.InstrumentInfoTableName].Rows.Add((object) ReportStrings.LastCalibrationDate, calDate == DateTime.MinValue ? (object) ReportStrings.Unknown : (object) calDate.ToString("dd'/'MM'/'yyyy"));
      int num1 = 3;
      if (!string.IsNullOrEmpty(sampledBy))
      {
        report.Tables[InstrumentInformation.InstrumentInfoTableName].Rows.Add((object) ReportStrings.SampledBy, (object) sampledBy);
        num1 = 4;
      }
      int num2 = report.Tables[CleanroomInformation.CleanroomInfoTableName].Rows.Count - num1;
      for (int index = 0; index < num2; ++index)
        report.Tables[InstrumentInformation.InstrumentInfoTableName].Rows.Add((object) string.Empty, (object) string.Empty);
    }

    protected void PrintConcentrationEvaluation(
      StandardsReportFormat report,
      bool metric,
      Decimal concentrationLimit,
      string concLimitFormat,
      bool uses95UCL,
      bool usesStandardError,
      StandardsChannelStatistics standardsChannelStatistics,
      bool meetsStandardsConcentrationRequirements,
      bool meetsStandardsUCLChannelConcentrationLimitRequirements)
    {
      string str1 = string.Format("{0}, #/{1}", (object) ReportStrings.Cumulative, metric ? (object) ReportStrings.M3 : (object) ReportStrings.FT3);
      string str2 = string.Format("{0}", (object) standardsChannelStatistics.CutPointSizeMicrometres.ToString(Channel.ParticleSizeNumericFormatString));
      string str3 = string.Format("{0}", (object) standardsChannelStatistics.Maximum.ToString(ReportFormatService.standardsStatisticsFormat));
      string str4 = string.Format("{0}", (object) Statistics.Round(standardsChannelStatistics.Mean).ToString(ReportFormatService.standardsStatisticsFormat));
      string str5 = string.Format("{0}", standardsChannelStatistics.StandardDeviation < 0M ? (object) ReportStrings.NotApplicable : (object) Statistics.Round(standardsChannelStatistics.StandardDeviation).ToString(ReportFormatService.standardsStatisticsFormat));
      string empty = string.Empty;
      string str6 = !uses95UCL || standardsChannelStatistics.Count <= 1 || standardsChannelStatistics.Count >= 10 ? ReportStrings.NotApplicable : string.Format("{0}", (object) standardsChannelStatistics.UpperConfidenceLevel95.ToString(ReportFormatService.standardsStatisticsFormat));
      report.Tables[ParticleData.ParticleDataTableName].Rows.Add((object) str1, (object) str2, (object) str3, (object) str4, (object) str5, (object) str6, (object) concentrationLimit.ToString(concLimitFormat));
    }

    protected void PrintSamplingInformation(
      StandardsReportFormat report,
      int minLocationsRequired,
      int minTotalZoneSamplesRequired,
      int actualSampleLocations,
      int minSamplesPerLocation,
      Decimal samplesPerLocation,
      int totalSamples,
      bool isMinSampleTimeRequired,
      TimeSpan minSampleTimeRequired,
      TimeSpan actualSampleTime,
      Decimal minSampleVolume,
      Decimal actualVolume,
      VolumeType volumeUnits)
    {
      report.Tables[SamplingInformation.SamplingInfoTableName].Rows.Add((object) ReportStrings.LocationsPerZone, (object) minLocationsRequired.ToString(), (object) actualSampleLocations.ToString(), (object) (actualSampleLocations >= minLocationsRequired));
      report.Tables[SamplingInformation.SamplingInfoTableName].Rows.Add((object) ReportStrings.SamplesPerLocation, (object) minSamplesPerLocation, (object) samplesPerLocation.ToString("G"), (object) (samplesPerLocation >= (Decimal) minSamplesPerLocation));
      report.Tables[SamplingInformation.SamplingInfoTableName].Rows.Add((object) ReportStrings.TotalSamples, (object) minTotalZoneSamplesRequired, (object) totalSamples.ToString(), (object) (totalSamples >= minTotalZoneSamplesRequired));
      string str1;
      switch (volumeUnits)
      {
        case VolumeType.FeetCubed:
          str1 = ReportStrings.FT3;
          break;
        case VolumeType.MetresCubed:
          str1 = ReportStrings.M3;
          break;
        default:
          str1 = ReportStrings.Litres;
          break;
      }
      string str2 = string.Format("{0} {1}", (object) minSampleVolume.ToString(ReportFormatService.volumeFormat), (object) str1);
      string str3 = string.Format("{0} {1}", (object) actualVolume.ToString(ReportFormatService.volumeFormat), (object) str1);
      report.Tables[SamplingInformation.SamplingInfoTableName].Rows.Add((object) ReportStrings.SampleVolume, (object) str2, (object) str3, (object) (actualVolume >= minSampleVolume));
      if (!isMinSampleTimeRequired)
        return;
      report.Tables[SamplingInformation.SamplingInfoTableName].Rows.Add((object) ReportStrings.SampleTime, (object) minSampleTimeRequired.ToString(), (object) actualSampleTime.ToString(), (object) (actualSampleTime >= minSampleTimeRequired));
    }

    protected void PrintLocationData(
      StandardsReportFormat report,
      List<ReportViewerFormatService.LocationDataSummary> locationSummary)
    {
      foreach (ReportViewerFormatService.LocationDataSummary locationDataSummary in locationSummary)
      {
        DataRow row = report.Tables[LocationData.LocationDataTableName].NewRow();
        row[LocationData.LocationColumnName] = (object) locationDataSummary.Location;
        bool flag = false;
        foreach (ReportViewerFormatService.ParticleStatistics particleStatistic in locationDataSummary.ParticleStatistics)
        {
          if (flag)
          {
            row = report.Tables[LocationData.LocationDataTableName].NewRow();
            row[LocationData.LocationColumnName] = (object) string.Empty;
            row[LocationData.NumSamplesColumnName] = (object) string.Empty;
          }
          else
            row[LocationData.NumSamplesColumnName] = (object) particleStatistic.NumSamples.ToString();
          row[LocationData.SizeColumnName] = (object) particleStatistic.Size.ToString(Channel.ParticleSizeNumericFormatString);
          row[LocationData.AverageColumnName] = (object) particleStatistic.Mean.ToString(ReportFormatService.concentrationFormat);
          row[LocationData.OverConcLimit] = (object) (particleStatistic.Mean > locationDataSummary.ConcLimit);
          report.Tables[LocationData.LocationDataTableName].Rows.Add(row);
          flag = true;
        }
      }
    }

    protected void PrintExcludedSample(
      StandardsReportFormat report,
      StandardsChannelStatistics[] channelStatistics,
      StandardsReportConfiguration standardReportConfiguration,
      bool isMetric,
      List<ISample> samples)
    {
      if (samples.Count < 1)
        return;
      foreach (ISample sample in samples)
      {
        int num = 0;
        DataRow row = report.Tables[ExcludedSample.ExcludedSampleTableName].NewRow();
        row[ExcludedSample.SampleHeaderColumnName] = (object) sample.TimeStamp.ToString("dd'/'MM'/'yyyy HH:mm:ss");
        row[ExcludedSample.LocationColumnName] = (object) sample.Location;
        row[ExcludedSample.SampleIdColumnName] = (object) sample.SampleID.ToString();
        ChannelCollectionStatistics collectionStatistics = new ChannelCollectionStatistics();
        collectionStatistics.Accumulate(sample, ParticleCountMode.Cumulative, true, isMetric ? VolumeType.MetresCubed : VolumeType.FeetCubed);
        for (int index = 0; index < collectionStatistics.Count; ++index)
        {
          if (Array.IndexOf<Decimal>(standardReportConfiguration.CutPointsSizesMicrometersSpecified, collectionStatistics[index].ParticleSizeMicrometres) > -1 && index < sample.Channels.Count)
          {
            Decimal particleCount = collectionStatistics[index].ParticleCount;
            if (num > 0)
            {
              row = report.Tables[ExcludedSample.ExcludedSampleTableName].NewRow();
              row[ExcludedSample.SampleHeaderColumnName] = (object) string.Empty;
              row[ExcludedSample.LocationColumnName] = (object) string.Empty;
            }
            row[ExcludedSample.SizeColumnName] = (object) collectionStatistics[index].ParticleSizeMicrometres.ToString(Channel.ParticleSizeNumericFormatString);
            row[ExcludedSample.ParticleCountColumnName] = (object) particleCount.ToString(ReportFormatService.concentrationFormat);
            report.Tables[ExcludedSample.ExcludedSampleTableName].Rows.Add(row);
            ++num;
          }
        }
      }
    }

    protected void PrintComments(StandardsReportFormat report, string comments)
    {
      int length1 = comments.Length;
      int num = 4;
      string[] strArray = comments.Split('\n');
      for (int index = 0; index < strArray.Length; ++index)
      {
        report.Tables[Comments.CommentsTableName].Rows.Add((object) strArray[index]);
        if (strArray[index].Length > 80)
          --num;
      }
      for (int length2 = strArray.Length; length2 < num - 1; ++length2)
        report.Tables[Comments.CommentsTableName].Rows.Add((object) "  \r\n");
    }

    protected class ParticleStatistics
    {
      private Decimal size;
      private int numSamples;
      private Decimal mean;

      public ParticleStatistics(Decimal size, int numSamples, Decimal mean)
      {
        this.size = size;
        this.numSamples = numSamples;
        this.mean = mean;
      }

      public Decimal Size => this.size;

      public int NumSamples => this.numSamples;

      public Decimal Mean => this.mean;
    }

    protected class LocationDataSummary
    {
      private string location;
      private Decimal concLimit;
      private List<ReportViewerFormatService.ParticleStatistics> particleStatistics;

      public LocationDataSummary(
        string location,
        Decimal particleSize,
        int numSamples,
        Decimal mean,
        Decimal concLimit)
      {
        this.location = location;
        this.concLimit = concLimit;
        this.particleStatistics = new List<ReportViewerFormatService.ParticleStatistics>();
        this.particleStatistics.Add(new ReportViewerFormatService.ParticleStatistics(particleSize, numSamples, mean));
      }

      public void AddParticleStatistics(Decimal particleSize, int numSamples, Decimal mean)
      {
        this.particleStatistics.Add(new ReportViewerFormatService.ParticleStatistics(particleSize, numSamples, mean));
      }

      public string Location => this.location;

      public List<ReportViewerFormatService.ParticleStatistics> ParticleStatistics
      {
        get => this.particleStatistics;
      }

      public Decimal ConcLimit => this.concLimit;
    }
  }
}
