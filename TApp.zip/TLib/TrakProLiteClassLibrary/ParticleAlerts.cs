﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ParticleAlerts
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ParticleAlerts
  {
    public Decimal Size { get; set; }

    public Decimal AlertLevel { get; set; }

    public Decimal ActionLevel { get; set; }

    public int Channel { get; set; }

    public ParticleAlerts()
    {
    }

    public ParticleAlerts(int ch, Decimal sz, Decimal alert, Decimal action)
    {
      this.Channel = ch;
      this.Size = sz;
      this.AlertLevel = alert;
      this.ActionLevel = action;
    }
  }
}
