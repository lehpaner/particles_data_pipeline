﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.StandardsLocationStatistics
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class StandardsLocationStatistics : StatisticsWholePopulation
  {
    private string location;
    private TimeSpan timeSpan;
    private Decimal volume;

    public StandardsLocationStatistics() => this.location = string.Empty;

    public StandardsLocationStatistics(string location) => this.location = location;

    public string Location
    {
      get => this.location;
      set => this.location = value;
    }

    public TimeSpan TimeSpan => this.timeSpan;

    public Decimal Volume => this.volume;

    public void AccumulateVolume(Decimal volume)
    {
      if (!(volume < this.volume))
        return;
      this.volume = volume;
    }

    public void AccumulateTime(TimeSpan timeSpan) => timeSpan += timeSpan;

    public override void Zero()
    {
      this.timeSpan = new TimeSpan(0L);
      this.volume = Decimal.MaxValue;
      base.Zero();
    }
  }
}
