﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MonitorReportFormat
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MonitorReportFormat : DataSet
  {
    public string ReportTitle { get; set; }

    public string Units { get; set; }

    public string CountMode { get; set; }

    public string Username { get; set; }

    public string ConcHeading { get; set; }

    public bool ReviewerSignatureLine { get; set; }

    public MonitorReportFormat(
      string title,
      string units,
      string countMode,
      string currentUser,
      bool addReviewerLine)
    {
      this.ReportTitle = title;
      this.Username = currentUser;
      this.Units = units;
      this.CountMode = countMode;
      this.ConcHeading = string.Compare(units, "#") == 0 ? "Counts" : "Conc";
      this.ReviewerSignatureLine = addReviewerLine;
      this.Tables.Add((DataTable) new MRSamplingInfoTable());
      this.Tables.Add((DataTable) new MRParticleCounter());
      this.Tables.Add((DataTable) new MRParticleCounterSettings());
      this.Tables.Add((DataTable) new MRComments());
      this.Tables.Add((DataTable) new MRResultsSummary());
      this.Tables.Add((DataTable) new MRResultsTable());
    }
  }
}
