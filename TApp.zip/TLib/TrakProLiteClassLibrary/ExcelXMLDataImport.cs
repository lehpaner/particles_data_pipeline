﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ExcelXMLDataImport
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using System.Xml;
using TrakProLiteClassLibrary.Properties;
using TSI;
using TSI.Data;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ExcelXMLDataImport
  {
    public static string ExcelNamespace = "urn:schemas-microsoft-com:office:spreadsheet";

    public object ImportDataFromFile(string filename)
    {
      XmlDocument doc = new XmlDocument();
      try
      {
        doc.Load(filename);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(string.Format("An error occurred trying to open file {0}:\r\n  {1}", (object) filename, (object) ex.Message), Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (object) null;
      }
      XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
      nsmgr.AddNamespace("ss", ExcelXMLDataImport.ExcelNamespace);
      XmlNode deviceNode = doc.SelectSingleNode("//ss:Worksheet[@WorksheetType='Data']", nsmgr);
      if (deviceNode == null)
      {
        int num = (int) MessageBox.Show("The file you are trying to load is not a valid Excel-formatted sample data file.", Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (object) null;
      }
      XmlNode xmlNode1 = doc.SelectSingleNode("//ss:MD5", nsmgr);
      if (xmlNode1 == null)
      {
        int num = (int) MessageBox.Show("Invalid sample data file: this file cannot be verified because it does not contain a secure hash code.", Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (object) null;
      }
      string innerText = xmlNode1.InnerText;
      XmlNode xmlNode2 = doc.SelectSingleNode("//ss:UserSignature", nsmgr);
      string empty = string.Empty;
      string marker = xmlNode2 == null ? "</Worksheet>" : "</UserSignature>";
      if (!FileUtility.VerifyMd5Hash(innerText, filename, marker))
      {
        int num = (int) MessageBox.Show(string.Format("Unable to verify {0}. The original file content may have been modified or corrupted.", (object) filename), Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (object) null;
      }
      string str = this.ReadModelNumber(deviceNode, nsmgr);
      if (string.IsNullOrEmpty(str))
      {
        int num = (int) MessageBox.Show("Invalid data file: the file does not contain an instrument model number.", Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (object) null;
      }
      CultureInfo fileCultureInfo = this.GetFileCultureInfo(doc, nsmgr, "Data");
      if (fileCultureInfo == null)
      {
        int num = (int) MessageBox.Show(string.Format("Unable to read the culture information from the file {0}", (object) filename));
        return (object) null;
      }
      if (str == "9303")
      {
        Storage_9303 instrument = new Storage_9303();
        this.Read9303File(doc, deviceNode, nsmgr, fileCultureInfo, ref instrument);
        return (object) instrument;
      }
      ModbusMap2Device instrument1 = new ModbusMap2Device();
      this.ReadDeviceInfo(deviceNode, nsmgr, fileCultureInfo, ref instrument1);
      if (string.IsNullOrEmpty(instrument1.ModelNumber) || string.IsNullOrEmpty(instrument1.SerialNumber))
      {
        int num = (int) MessageBox.Show("Invalid data file: this file does not contain an instrument model or serial number.", Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (object) null;
      }
      if (instrument1.NumberOfChannels == (ushort) 0 || instrument1.channelSize[0] == (ushort) 0)
      {
        int num = (int) MessageBox.Show("Invalid data file: this file does not contain valid instrument channel information.", Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (object) null;
      }
      if (instrument1.ViableCounts)
      {
        string text = string.Empty;
        if (string.IsNullOrEmpty(instrument1.AlgorithmId1) && string.IsNullOrEmpty(instrument1.AlgorithmId2))
          text = "Algorithm files were not loaded into instrument when data was collected.";
        else if (string.IsNullOrEmpty(instrument1.AlgorithmId1))
          text = "Normal sensitivity algorithm file was not loaded into instrument when data was collected.";
        else if (string.IsNullOrEmpty(instrument1.AlgorithmId2))
          text = "High sensitivity algorithm file was not loaded into instrument when data was collected.";
        else if (!instrument1.AlgorithmId1.Equals(instrument1.AlgorithmId2))
          text = "Normal and high sensitivity algorithm versions in instrument did not match when data was collected.";
        if (text != "")
        {
          int num = (int) MessageBox.Show(text, Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
      }
      if (instrument1.mapRevRegister == (ushort) 0)
      {
        int num = (int) MessageBox.Show("Invalid data file. The instrument type cannot be identified.", Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (object) null;
      }
      this.ReadRecipes(doc, nsmgr, fileCultureInfo, ref instrument1);
      this.ReadZones(doc, nsmgr, fileCultureInfo, ref instrument1);
      this.ReadLocations(doc, nsmgr, ref instrument1);
      this.ReadSampleRecords(deviceNode, nsmgr, fileCultureInfo, ref instrument1);
      return (object) instrument1;
    }

    public object ImportRecipeFromFile(string filename, ref string strModel)
    {
      XmlDocument doc = new XmlDocument();
      try
      {
        doc.Load(filename);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(string.Format("An error occurred trying to open file {0}:{1}", (object) filename, (object) ex.Message));
        return (object) null;
      }
      XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
      nsmgr.AddNamespace("ss", ExcelXMLDataImport.ExcelNamespace);
      XmlNode recipeWorkSheetNode = doc.SelectSingleNode("//ss:Worksheet[@WorksheetType='Recipes']", nsmgr);
      if (recipeWorkSheetNode == null)
        return (object) null;
      XmlNode namedItem = recipeWorkSheetNode.Attributes.GetNamedItem("Model");
      strModel = namedItem == null ? "" : namedItem.Value;
      CultureInfo fileCultureInfo = this.GetFileCultureInfo(doc, nsmgr, "Recipes");
      if (fileCultureInfo != null)
        return (object) this.ImportRecipeConfig(doc, recipeWorkSheetNode, nsmgr, fileCultureInfo);
      int num1 = (int) MessageBox.Show(string.Format("Unable to read the culture information from the file {0}", (object) filename));
      return (object) null;
    }

    public object ImportZoneFromFile(string filename, ref string strModel)
    {
      XmlDocument doc = new XmlDocument();
      try
      {
        doc.Load(filename);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(string.Format("An error occurred trying to open file {0}:{1}", (object) filename, (object) ex.Message));
        return (object) null;
      }
      XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
      nsmgr.AddNamespace("ss", ExcelXMLDataImport.ExcelNamespace);
      if (doc.SelectSingleNode("//ss:Worksheet[@WorksheetType='Data']", nsmgr) != null)
        return (object) null;
      XmlNode zoneWorkSheetNode = doc.SelectSingleNode("//ss:Worksheet[@WorksheetType='Zone']", nsmgr);
      if (zoneWorkSheetNode == null)
        return (object) null;
      XmlNode namedItem = zoneWorkSheetNode.Attributes.GetNamedItem("Model");
      strModel = namedItem == null ? "" : namedItem.Value;
      CultureInfo fileCultureInfo = this.GetFileCultureInfo(doc, nsmgr, "Zone");
      if (fileCultureInfo != null)
        return (object) this.ImportZoneConfig(doc, zoneWorkSheetNode, nsmgr, fileCultureInfo);
      int num1 = (int) MessageBox.Show(string.Format("Unable to read the culture information from the file {0}", (object) filename));
      return (object) null;
    }

    public object ImportLocationsFromFile(string filename)
    {
      XmlDocument xmlDocument = new XmlDocument();
      try
      {
        xmlDocument.Load(filename);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(string.Format("An error occurred trying to open file {0}:{1}", (object) filename, (object) ex.Message));
        return (object) null;
      }
      XmlNamespaceManager nsmgr = new XmlNamespaceManager(xmlDocument.NameTable);
      nsmgr.AddNamespace("ss", ExcelXMLDataImport.ExcelNamespace);
      XmlNode xmlNode1 = xmlDocument.SelectSingleNode("//ss:Worksheet[@WorksheetType='Location']", nsmgr);
      if (xmlNode1 == null)
        return (object) null;
      XmlNodeList xmlNodeList = xmlNode1.SelectNodes("descendant::ss:Row[@RowType='Location']", nsmgr);
      int locationId = 0;
      LocationList locationList = new LocationList();
      foreach (XmlNode xmlNode2 in xmlNodeList)
      {
        string empty = string.Empty;
        string str = xmlNode2.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='LocationName']", nsmgr).InnerText.Trim();
        locationList.Add((ILocation) new ModbusMap2Location(locationId)
        {
          Name = str
        });
      }
      return (object) locationList;
    }

    private ZoneConfig ImportZoneConfig(
      XmlDocument doc,
      XmlNode zoneWorkSheetNode,
      XmlNamespaceManager nsmgr,
      CultureInfo cultureInfo)
    {
      if (zoneWorkSheetNode == null)
        return (ZoneConfig) null;
      ModbusMap2Zone zone = this.ReadZoneConfig(zoneWorkSheetNode.SelectSingleNode("descendant::ss:Row[@RowType='Zone']", nsmgr), nsmgr, cultureInfo);
      if (zone == null)
        return (ZoneConfig) null;
      ZoneConfig zoneConfig = new ZoneConfig(zone);
      XmlNode xmlNode1 = doc.SelectSingleNode("//ss:Worksheet[@ss:Name='Locations']", nsmgr);
      if (xmlNode1 != null)
      {
        foreach (XmlNode selectNode in xmlNode1.SelectNodes("descendant::ss:Row[@RowType='Location']", nsmgr))
        {
          ModbusMap2Location modbusMap2Location = new ModbusMap2Location(-1);
          XmlNode xmlNode2 = selectNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ZoneName']", nsmgr);
          if (xmlNode2 != null && string.Compare(xmlNode2.InnerText.Trim(), zone.Name) == 0)
          {
            XmlNode xmlNode3 = selectNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='LocationName']", nsmgr);
            if (xmlNode3 != null)
            {
              modbusMap2Location.Name = xmlNode3.InnerText.Trim();
              zoneConfig.Locations.Add((ILocation) modbusMap2Location);
            }
          }
        }
      }
      if (zoneConfig.Locations.Count == 0)
        return (ZoneConfig) null;
      XmlNode xmlNode4 = doc.SelectSingleNode("//ss:Worksheet[@WorksheetType='Recipes']", nsmgr);
      if (xmlNode4 != null)
      {
        bool viableCounts = false;
        ushort result = 0;
        if (ushort.TryParse(xmlNode4.Attributes["ViableCounts"].Value, out result))
          viableCounts = result == (ushort) 1;
        XmlNode recipeNode = xmlNode4.SelectSingleNode("descendant::ss:Row[@RowType='Recipe']", nsmgr);
        zoneConfig.Recipe = this.ReadRecipeConfig(recipeNode, nsmgr, viableCounts, cultureInfo);
      }
      return zoneConfig;
    }

    private RecipeList ImportRecipeConfig(
      XmlDocument doc,
      XmlNode recipeWorkSheetNode,
      XmlNamespaceManager nsmgr,
      CultureInfo cultureInfo)
    {
      if (recipeWorkSheetNode == null)
        return (RecipeList) null;
      bool viableCounts = false;
      ushort result = 0;
      if (ushort.TryParse(recipeWorkSheetNode.Attributes["ViableCounts"].Value, out result))
        viableCounts = result == (ushort) 1;
      RecipeList recipeList = new RecipeList();
      foreach (XmlNode selectNode in recipeWorkSheetNode.SelectNodes("descendant::ss:Row[@RowType='Recipe']", nsmgr))
      {
        ModbusMap2Recipe modbusMap2Recipe = this.ReadRecipeConfig(selectNode, nsmgr, viableCounts, cultureInfo);
        if (modbusMap2Recipe != null)
          recipeList.Add((IRecipe) modbusMap2Recipe);
      }
      return recipeList;
    }

    private void Read9303File(
      XmlDocument doc,
      XmlNode deviceNode,
      XmlNamespaceManager nsmgr,
      CultureInfo cultureInfo,
      ref Storage_9303 instrument)
    {
      string empty = string.Empty;
      XmlAttribute attribute;
      if ((attribute = deviceNode.Attributes["Serial"]) != null)
        empty = attribute.Value;
      instrument.id = string.Format("{0}{1}", (object) "9303", (object) empty);
      this.ReadLocations(doc, nsmgr, ref instrument);
      this.ReadSampleRecords(deviceNode, nsmgr, ref instrument);
    }

    private string ReadModelNumber(XmlNode deviceNode, XmlNamespaceManager nsmgr)
    {
      string empty = string.Empty;
      XmlAttribute attribute;
      if (deviceNode != null && (attribute = deviceNode.Attributes["Model"]) != null)
        empty = attribute.Value;
      return empty;
    }

    private CultureInfo GetFileCultureInfo(
      XmlDocument doc,
      XmlNamespaceManager nsmgr,
      string worksheetType)
    {
      CultureInfo fileCultureInfo = (CultureInfo) null;
      string xpath = string.Format("//ss:Worksheet[@WorksheetType='{0}']", (object) worksheetType);
      XmlNode xmlNode1 = doc.SelectSingleNode(xpath, nsmgr);
      if (xmlNode1 != null)
      {
        if (xmlNode1.Attributes["CultureInfo"] != null)
        {
          fileCultureInfo = CultureInfo.InvariantCulture;
        }
        else
        {
          string source = string.Empty;
          switch (worksheetType)
          {
            case "Data":
              XmlNode xmlNode2 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@ChannelNumber='1']", nsmgr);
              if (xmlNode2 != null)
              {
                source = xmlNode2.InnerText.Trim();
                break;
              }
              break;
            case "Recipes":
              XmlNode xmlNode3;
              if ((xmlNode3 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ChannelSize']", nsmgr)) != null)
              {
                source = xmlNode3.InnerText.Trim();
                break;
              }
              break;
            case "Zone":
              XmlNode xmlNode4 = doc.SelectSingleNode("//ss:Worksheet[@WorksheetType='Recipes']", nsmgr);
              XmlNode xmlNode5;
              if (xmlNode4 != null && (xmlNode5 = xmlNode4.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ChannelSize']", nsmgr)) != null)
              {
                source = xmlNode5.InnerText.Trim();
                break;
              }
              break;
          }
          fileCultureInfo = !source.Contains<char>(',') ? CultureInfo.InvariantCulture : CultureInfo.CurrentCulture;
        }
      }
      return fileCultureInfo;
    }

    private void ReadDeviceInfo(
      XmlNode deviceNode,
      XmlNamespaceManager nsmgr,
      CultureInfo cultureInfo,
      ref ModbusMap2Device instrument)
    {
      XmlAttribute attribute1;
      if ((attribute1 = deviceNode.Attributes["Model"]) != null)
        instrument.model = attribute1.Value;
      XmlAttribute attribute2;
      if ((attribute2 = deviceNode.Attributes["Serial"]) != null)
        instrument.serial = attribute2.Value;
      XmlAttribute attribute3;
      if ((attribute3 = deviceNode.Attributes["NumChannels"]) != null)
      {
        ushort result = 0;
        ushort.TryParse(attribute3.Value, out result);
        instrument.NumberOfChannels = result;
      }
      XmlAttribute attribute4;
      if ((attribute4 = deviceNode.Attributes["AlgorithmVersion1"]) != null)
        instrument.AlgorithmId1 = attribute4.Value;
      XmlAttribute attribute5;
      if ((attribute5 = deviceNode.Attributes["AlgorithmVersion2"]) != null)
        instrument.AlgorithmId2 = attribute5.Value;
      XmlAttribute attribute6;
      if ((attribute6 = deviceNode.Attributes["FlowRate"]) != null)
        Decimal.TryParse(attribute6.Value, NumberStyles.Float, (IFormatProvider) cultureInfo, out instrument.nominalFlowRate);
      XmlAttribute attribute7;
      if ((attribute7 = deviceNode.Attributes["LastCalibration"]) != null)
      {
        DateTime result = DateTime.MinValue;
        DateTime.TryParse(attribute7.Value, out result);
        instrument.LastCalibrationDate = result;
      }
      XmlAttribute attribute8;
      if ((attribute8 = deviceNode.Attributes["CalibrationDue"]) != null)
      {
        DateTime result = DateTime.MinValue;
        DateTime.TryParse(attribute8.Value, out result);
        instrument.CalibrationDueDate = result;
      }
      XmlAttribute attribute9;
      if ((attribute9 = deviceNode.Attributes["VariableBins"]) != null)
      {
        ushort result = 0;
        ushort.TryParse(attribute9.Value, out result);
        instrument.VariableBins = result == (ushort) 1;
      }
      XmlAttribute attribute10;
      if ((attribute10 = deviceNode.Attributes["FirmwareVersion"]) != null)
      {
        ushort result = 0;
        ushort.TryParse(attribute10.Value, out result);
        instrument.FirmwareVersion = result;
      }
      XmlAttribute attribute11;
      if ((attribute11 = deviceNode.Attributes["MapRev"]) != null)
        ushort.TryParse(attribute11.Value, out instrument.mapRevRegister);
      XmlAttribute attribute12;
      if ((attribute12 = deviceNode.Attributes["ViableCounts"]) != null)
      {
        ushort result = 0;
        ushort.TryParse(attribute12.Value, out result);
        instrument.ViableCounts = result == (ushort) 1;
      }
      XmlAttribute attribute13;
      if ((attribute13 = deviceNode.Attributes["DIMode"]) != null)
      {
        ushort result = 0;
        ushort.TryParse(attribute13.Value, out result);
        instrument.IsDIMode = result == (ushort) 1;
      }
      XmlAttribute attribute14;
      if ((attribute14 = deviceNode.Attributes["DIUser"]) != null)
      {
        ushort result = 0;
        ushort.TryParse(attribute14.Value, out result);
        instrument.diUserId = result;
      }
      XmlNode xmlNode = deviceNode.SelectSingleNode("descendant::ss:Row[@RowType='ChannelCutPoints']", nsmgr);
      if (xmlNode == null)
        return;
      foreach (XmlNode selectNode in xmlNode.SelectNodes("descendant::ss:Cell/ss:Data[@ss:Type='Number']", nsmgr))
      {
        int index = int.Parse(selectNode.Attributes["ChannelNumber"].Value) - 1;
        float num = float.Parse(selectNode.InnerText.Trim(), (IFormatProvider) cultureInfo);
        instrument.channelSize[index] = !instrument.ModelNumber.StartsWith("9001") ? (ushort) ((double) num * 1000.0 + 0.5) : (ushort) num;
        if (instrument.ViableCounts)
          instrument.channelSize[index + 6] = instrument.channelSize[index];
      }
    }

    private void ReadRecipes(
      XmlDocument doc,
      XmlNamespaceManager nsmgr,
      CultureInfo cultureInfo,
      ref ModbusMap2Device instrument)
    {
      XmlNode xmlNode = doc.SelectSingleNode("//ss:Worksheet[@WorksheetType='Recipes']", nsmgr);
      if (xmlNode == null)
        return;
      XmlNodeList xmlNodeList = xmlNode.SelectNodes("descendant::ss:Row[@RowType='Recipe']", nsmgr);
      instrument.rcpCount = (ushort) xmlNodeList.Count;
      instrument.Recipes = new RecipeList();
      int num = 0;
      foreach (XmlNode recipeNode in xmlNodeList)
      {
        ModbusMap2Recipe modbusMap2Recipe = this.ReadRecipeConfig(recipeNode, nsmgr, instrument.ViableCounts, cultureInfo);
        if (modbusMap2Recipe != null)
        {
          modbusMap2Recipe.RecipeId = num;
          instrument.Recipes.Add((IRecipe) modbusMap2Recipe);
          instrument.RecipeLabelLength = (ushort) modbusMap2Recipe.Name.Length;
          ++num;
        }
      }
    }

    private void ReadZones(
      XmlDocument doc,
      XmlNamespaceManager nsmgr,
      CultureInfo cultureInfo,
      ref ModbusMap2Device instrument)
    {
      XmlNode xmlNode = doc.SelectSingleNode("//ss:Worksheet[@ss:Name='Zones']", nsmgr);
      if (xmlNode == null)
        return;
      XmlNodeList xmlNodeList = xmlNode.SelectNodes("descendant::ss:Row[@RowType='Zone']", nsmgr);
      int id = 0;
      instrument.Zones = new ZoneList();
      ModbusMap2Zone zone = new ModbusMap2Zone(id);
      zone.Name = TSIStrings.DefaultZoneName;
      zone.RecipeId = 0;
      instrument.Zones.Add((IZone) zone);
      int num = id + 1;
      foreach (XmlNode zoneNode in xmlNodeList)
      {
        zone = this.ReadZoneConfig(zoneNode, nsmgr, cultureInfo);
        if (zone != null)
        {
          zone.ZoneId = num;
          zone.RecipeId = instrument.Recipes.GetId(zone.RecipeName);
          IRecipe recipe = instrument.Recipes.Find((Predicate<IRecipe>) (r => r.Name.Equals(zone.RecipeName)));
          zone.Recipe = (ModbusMap2Recipe) recipe;
          instrument.Zones.Add((IZone) zone);
          ++num;
        }
      }
    }

    private void ReadLocations(
      XmlDocument doc,
      XmlNamespaceManager nsmgr,
      ref ModbusMap2Device instrument)
    {
      XmlNode xmlNode1 = doc.SelectSingleNode("//ss:Worksheet[@ss:Name='Locations']", nsmgr);
      if (xmlNode1 == null)
        return;
      XmlNodeList xmlNodeList = xmlNode1.SelectNodes("descendant::ss:Row[@RowType='Location']", nsmgr);
      instrument.Locations = new LocationList();
      int locationId1 = 0;
      instrument.Locations.Add((ILocation) new ModbusMap2Location(locationId1)
      {
        Name = TSIStrings.UnknownName,
        ZoneId = (instrument.HasZones ? 0 : -1)
      });
      int locationId2 = locationId1 + 1;
      foreach (XmlNode xmlNode2 in xmlNodeList)
      {
        string empty = string.Empty;
        string str = xmlNode2.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='LocationName']", nsmgr).InnerText.Trim();
        ModbusMap2Location modbusMap2Location = new ModbusMap2Location(locationId2);
        modbusMap2Location.Name = str;
        XmlNode xmlNode3;
        if ((xmlNode3 = xmlNode2.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ZoneName']", nsmgr)) != null)
        {
          string name = xmlNode3.InnerText.Trim();
          int id = instrument.Zones.GetId(name);
          if (id == -1 && (id = instrument.Zones.GetId(TSIStrings.DefaultZoneName)) == -1)
          {
            instrument.Zones.AddNew();
            instrument.Zones[id].Name = TSIStrings.DefaultZoneName;
          }
          modbusMap2Location.ZoneId = id;
        }
        instrument.Locations.Add((ILocation) modbusMap2Location);
        ++locationId2;
      }
    }

    private void ReadLocations(
      XmlDocument doc,
      XmlNamespaceManager nsmgr,
      ref Storage_9303 instrument)
    {
      XmlNode xmlNode1 = doc.SelectSingleNode("//ss:Worksheet[@ss:Name='Locations']", nsmgr);
      if (xmlNode1 == null)
        return;
      XmlNodeList xmlNodeList = xmlNode1.SelectNodes("descendant::ss:Row[@RowType='Location']", nsmgr);
      int locationId = 0;
      foreach (XmlNode xmlNode2 in xmlNodeList)
      {
        string empty = string.Empty;
        string name = xmlNode2.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='LocationName']", nsmgr).InnerText.Trim();
        Location9303 location9303 = new Location9303(locationId, name);
        instrument.Locations.Add((ILocation) location9303);
        ++locationId;
      }
    }

    private void ReadSampleRecords(
      XmlNode deviceNode,
      XmlNamespaceManager nsmgr,
      ref Storage_9303 instrument)
    {
      bool flag1 = false;
      XmlNodeList xmlNodeList = deviceNode.SelectNodes("descendant::ss:Row[@RowType='SampleRecord']", nsmgr);
      if (xmlNodeList == null)
        return;
      foreach (XmlNode xmlNode1 in xmlNodeList)
      {
        Record_9303 record9303 = new Record_9303();
        bool flag2 = false;
        record9303.SampleID = uint.Parse(xmlNode1.Attributes["RecordId"].Value);
        int index = 0;
        XmlNode xmlNode2;
        if ((xmlNode2 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Location']", nsmgr)) != null)
        {
          string name = xmlNode2.InnerText.Trim();
          if ((index = instrument.Locations.Find(name, -1)) == -1)
            index = instrument.Locations.AddNew(name, -1);
        }
        record9303.Loc = int.Parse(instrument.Locations[index].Name);
        record9303.LocationId = (int) (ushort) index;
        instrument.Locations[index].Locked = true;
        DateTime result1 = DateTime.MinValue;
        XmlNode xmlNode3;
        if ((xmlNode3 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='SampleDate']", nsmgr)) != null)
          DateTime.TryParse(xmlNode3.InnerText.Trim(), out result1);
        record9303.DateTime = result1;
        record9303.SampleTime = new TimeSpan();
        XmlNode xmlNode4;
        if ((xmlNode4 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='SampleTime']", nsmgr)) != null)
        {
          int result2 = 0;
          int.TryParse(xmlNode4.InnerText.Trim(), out result2);
          record9303.SampleTime = new TimeSpan(0, 0, result2);
        }
        record9303.RecipeSampleTime = "";
        XmlNode xmlNode5;
        if ((xmlNode5 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='RecipeSampleTime']", nsmgr)) != null)
          record9303.RecipeSampleTime = xmlNode5.InnerText.Trim();
        foreach (XmlNode selectNode in xmlNode1.SelectNodes("descendant::ss:Cell/ss:Data[@DataType='ChannelSize']", nsmgr))
        {
          int result3 = 0;
          if (int.TryParse(selectNode.Attributes["ChannelNumber"].Value, out result3))
          {
            if (result3 > 0)
            {
              try
              {
                string str = selectNode.InnerText.Trim();
                int num = int.Parse(selectNode.Attributes["Count"].Value);
                switch (result3)
                {
                  case 1:
                    record9303.Ch1Count = num;
                    record9303.Ch1Size = str;
                    continue;
                  case 2:
                    record9303.Ch2Count = num;
                    record9303.Ch2Size = str;
                    continue;
                  case 3:
                    record9303.Ch3Count = num;
                    record9303.Ch3Size = str;
                    continue;
                  default:
                    continue;
                }
              }
              catch (Exception ex)
              {
                flag2 = true;
                break;
              }
            }
          }
        }
        if (flag2)
        {
          flag1 = true;
          break;
        }
        record9303.CountMode = RecordType.Differential;
        record9303.UnitType = UnitType.Counts;
        XmlNode xmlNode6;
        if ((xmlNode6 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Volume']", nsmgr)) != null)
          record9303.VolumeUnits = (VolumeType) int.Parse(xmlNode6.Attributes["VolumeUnits"].Value);
        instrument.data.Add(record9303);
      }
      if (!flag1)
        return;
      int num1 = (int) MessageBox.Show("An error occurred reading samples.");
    }

    private void ReadSampleRecords(
      XmlNode deviceNode,
      XmlNamespaceManager nsmgr,
      CultureInfo cultureInfo,
      ref ModbusMap2Device instrument)
    {
      bool flag1 = false;
      XmlNodeList xmlNodeList = deviceNode.SelectNodes("descendant::ss:Row[@RowType='SampleRecord']", nsmgr);
      if (xmlNodeList == null)
        return;
      instrument.recCount = (uint) xmlNodeList.Count;
      foreach (XmlNode xmlNode1 in xmlNodeList)
      {
        ModbusMap2Record modbusMap2Record = new ModbusMap2Record((int) instrument.NumberOfChannels, instrument.ViableCounts ? (int) instrument.NumberOfChannels / 2 : (int) instrument.NumberOfChannels);
        bool flag2 = false;
        modbusMap2Record.recNum = uint.Parse(xmlNode1.Attributes["RecordId"].Value);
        XmlAttribute attribute1;
        if ((attribute1 = xmlNode1.Attributes["SampleFlowRate"]) != null)
        {
          float result = 0.0f;
          if (float.TryParse(attribute1.Value, NumberStyles.Float, (IFormatProvider) cultureInfo, out result))
            modbusMap2Record.PrecisionFlowRate = result;
        }
        XmlAttribute attribute2;
        ushort result1;
        if ((attribute2 = xmlNode1.Attributes["ViableSensitivity"]) != null && ushort.TryParse(attribute2.Value, out result1))
          modbusMap2Record.ViableDetectionSensitivity = result1;
        modbusMap2Record.DeviceStatus = (ushort) 0;
        XmlAttribute attribute3;
        if ((attribute3 = xmlNode1.Attributes["DeviceStatus"]) != null && !string.IsNullOrEmpty(attribute3.Value))
          modbusMap2Record.DeviceStatus = Convert.ToUInt16(attribute3.Value);
        modbusMap2Record.DIUserId = (ushort) 0;
        modbusMap2Record.DIUsername = string.Empty;
        XmlNode xmlNode2;
        if ((xmlNode2 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='DIUser']", nsmgr)) != null)
        {
          string[] strArray = xmlNode2.InnerText.Trim().Split(',');
          ushort result2 = 0;
          if (strArray.Length > 0)
            ushort.TryParse(strArray[0], out result2);
          modbusMap2Record.DIUserId = result2;
          modbusMap2Record.DIUsername = strArray.Length > 1 ? strArray[1] : string.Empty;
        }
        int zoneId = -1;
        XmlNode xmlNode3;
        if ((xmlNode3 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Zone']", nsmgr)) != null)
        {
          modbusMap2Record.Zone = xmlNode3.InnerText.Trim();
          zoneId = instrument.Zones.GetId(modbusMap2Record.Zone);
          if (zoneId == -1 && (zoneId = instrument.Zones.GetId(TSIStrings.DefaultZoneName)) == -1)
            zoneId = 0;
        }
        int index = 0;
        XmlNode xmlNode4;
        if ((xmlNode4 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Location']", nsmgr)) != null)
        {
          string name = xmlNode4.InnerText.Trim();
          if ((index = instrument.Locations.Find(name, zoneId)) == -1)
            index = 0;
        }
        modbusMap2Record.Location = instrument.Locations[index].Name;
        modbusMap2Record.locNumber = (ushort) index;
        instrument.Locations[index].Locked = true;
        DateTime result3 = DateTime.MinValue;
        XmlNode xmlNode5;
        if ((xmlNode5 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='SampleDate']", nsmgr)) != null)
          DateTime.TryParse(xmlNode5.InnerText.Trim(), out result3);
        modbusMap2Record.dateTime = result3;
        XmlNode xmlNode6;
        if ((xmlNode6 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='DeviceStatus']", nsmgr)) != null)
        {
          string str = xmlNode6.InnerText.Trim();
          if (!string.IsNullOrEmpty(str))
            modbusMap2Record.DeviceStatus = Convert.ToUInt16(str);
        }
        XmlNode xmlNode7;
        if ((xmlNode7 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='InstrumentStatus']", nsmgr)) != null)
        {
          string str = xmlNode7.InnerText.Trim();
          if (!str.Equals("OK") && (str.Contains("ERR") || str.Equals("ALRM")))
            modbusMap2Record.DeviceStatus |= (ushort) 16384;
        }
        modbusMap2Record.sampleTime = new TimeSpan();
        XmlNode xmlNode8;
        if ((xmlNode8 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='SampleTime']", nsmgr)) != null)
        {
          int result4 = 0;
          int.TryParse(xmlNode8.InnerText.Trim(), out result4);
          modbusMap2Record.sampleTime = new TimeSpan(0, 0, result4);
          modbusMap2Record.timeUnit = TimeUnits.sec;
        }
        modbusMap2Record.RecipeSampleTime = "";
        XmlNode xmlNode9;
        if ((xmlNode9 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='RecipeSampleTime']", nsmgr)) != null)
          modbusMap2Record.RecipeSampleTime = xmlNode9.InnerText.Trim();
        XmlNode xmlNode10;
        if ((xmlNode10 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='FlowStatus']", nsmgr)) != null)
        {
          string str = xmlNode10.InnerText.Trim();
          modbusMap2Record.flowStatus = str.Equals("OK") ? FlowStatus.OK : FlowStatus.Error;
          if (modbusMap2Record.flowStatus == FlowStatus.Error)
            modbusMap2Record.DeviceStatus |= (ushort) 1;
        }
        XmlNode xmlNode11;
        if ((xmlNode11 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='LaserStatus']", nsmgr)) != null)
        {
          string str = xmlNode11.InnerText.Trim();
          modbusMap2Record.laserStatus = str.Equals("OK") ? LaserStatus.OK : LaserStatus.Error;
          if (!str.Equals("OK"))
            modbusMap2Record.DeviceStatus |= (ushort) 4;
        }
        if ((double) modbusMap2Record.PrecisionFlowRate == 0.0)
        {
          modbusMap2Record.flowRateX100 = Convert.ToUInt16(instrument.nominalFlowRate * 100.0M);
          modbusMap2Record.flowType = FlowType.LPM;
        }
        else
        {
          try
          {
            modbusMap2Record.flowRateX100 = Convert.ToUInt16(modbusMap2Record.PrecisionFlowRate * 100f);
            modbusMap2Record.flowType = FlowType.CFM;
          }
          catch (OverflowException ex)
          {
            modbusMap2Record.flowRateX100 = Convert.ToUInt16(instrument.nominalFlowRate * 100.0M);
            modbusMap2Record.flowType = FlowType.LPM;
            modbusMap2Record.PrecisionFlowRate = 0.0f;
          }
        }
        foreach (XmlNode selectNode in xmlNode1.SelectNodes("descendant::ss:Cell/ss:Data[@DataType='ChannelSize']", nsmgr))
        {
          int result5 = 0;
          if (int.TryParse(selectNode.Attributes["ChannelNumber"].Value, out result5))
          {
            if (result5 > 0)
            {
              try
              {
                modbusMap2Record.counts[result5 - 1] = uint.Parse(selectNode.Attributes["Count"].Value);
                ushort num1 = ushort.Parse(selectNode.Attributes["Alarm"].Value);
                modbusMap2Record.chAlarm[result5 - 1] = num1 == (ushort) 1;
                float num2 = float.Parse(selectNode.InnerText.Trim(), (IFormatProvider) cultureInfo);
                modbusMap2Record.chSizes[result5 - 1] = !instrument.ModelNumber.StartsWith("9001") ? (ushort) ((double) num2 * 1000.0 + 0.5) : (ushort) num2;
              }
              catch (Exception ex)
              {
                flag2 = true;
                break;
              }
            }
          }
        }
        if (flag2)
        {
          flag1 = true;
          break;
        }
        modbusMap2Record.CountMode = RecordType.Differential;
        modbusMap2Record.unitMode = UnitType.Counts;
        XmlNode xmlNode12;
        if ((xmlNode12 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Volume']", nsmgr)) != null)
          modbusMap2Record.VolumeUnits = (VolumeType) int.Parse(xmlNode12.Attributes["VolumeUnits"].Value);
        XmlNode xmlNode13;
        if ((xmlNode13 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Temp']", nsmgr)) != null)
        {
          double result6 = 0.0;
          if (double.TryParse(xmlNode13.InnerText.Trim(), NumberStyles.Number, (IFormatProvider) cultureInfo, out result6))
          {
            modbusMap2Record.temperature = Convert.ToSingle(result6);
            int result7 = 0;
            XmlAttribute attribute4;
            modbusMap2Record.tempUnit = (attribute4 = xmlNode13.Attributes["TempUnits"]) == null ? (CultureInfo.CurrentCulture.Name == "en-US" ? UnitCode.F : UnitCode.C) : (!int.TryParse(attribute4.Value, NumberStyles.Integer, (IFormatProvider) cultureInfo, out result7) ? (CultureInfo.CurrentCulture.Name == "en-US" ? UnitCode.F : UnitCode.C) : (UnitCode) result7);
          }
          else
            modbusMap2Record.tempUnit = UnitCode.NA;
        }
        XmlNode xmlNode14;
        if ((xmlNode14 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='RelativeHumidity']", nsmgr)) != null)
        {
          float result8 = 0.0f;
          if (float.TryParse(xmlNode14.InnerText.Trim(), NumberStyles.Float, (IFormatProvider) cultureInfo, out result8))
          {
            modbusMap2Record.humidity = result8;
            modbusMap2Record.humidityUnit = UnitCode.Percent;
          }
          else
            modbusMap2Record.humidityUnit = UnitCode.NA;
        }
        XmlNode xmlNode15;
        if ((xmlNode15 = xmlNode1.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='AirVelocity']", nsmgr)) != null)
        {
          float result9 = 0.0f;
          if (float.TryParse(xmlNode15.InnerText.Trim(), NumberStyles.Float, (IFormatProvider) cultureInfo, out result9))
          {
            modbusMap2Record.velocity = result9;
            XmlAttribute attribute5;
            modbusMap2Record.velocityUnit = (attribute5 = xmlNode15.Attributes["AirVelocityUnits"]) == null ? (CultureInfo.CurrentCulture.Name == "en-US" ? UnitCode.ft_sec : UnitCode.m_sec) : (UnitCode) int.Parse(attribute5.Value);
          }
          else
            modbusMap2Record.velocityUnit = UnitCode.NA;
        }
        instrument.records.Add(modbusMap2Record);
      }
      if (!flag1)
        return;
      int num = (int) MessageBox.Show("An error occurred reading samples.");
    }

    private ModbusMap2Zone ReadZoneConfig(
      XmlNode zoneNode,
      XmlNamespaceManager nsmgr,
      CultureInfo cultureInfo)
    {
      ModbusMap2Zone modbusMap2Zone = new ModbusMap2Zone(-1);
      XmlNode xmlNode1;
      if ((xmlNode1 = zoneNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ZoneName']", nsmgr)) == null)
        return (ModbusMap2Zone) null;
      modbusMap2Zone.Name = xmlNode1.InnerText.Trim();
      XmlNode xmlNode2;
      if ((xmlNode2 = zoneNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ZoneStandard']", nsmgr)) != null)
      {
        XmlAttribute attribute;
        if ((attribute = xmlNode2.Attributes["StandardValue"]) != null)
        {
          try
          {
            modbusMap2Zone.Standard = ushort.Parse(attribute.Value);
          }
          catch (Exception ex)
          {
            modbusMap2Zone.Standard = (ushort) 4;
          }
        }
      }
      XmlNode xmlNode3;
      if ((xmlNode3 = zoneNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ZoneClass']", nsmgr)) != null)
      {
        XmlAttribute attribute;
        if ((attribute = xmlNode3.Attributes["ClassValue"]) != null)
        {
          try
          {
            modbusMap2Zone.ZoneClass = ushort.Parse(attribute.Value);
          }
          catch (Exception ex)
          {
            modbusMap2Zone.ZoneClass = (ushort) 0;
          }
        }
      }
      XmlNode xmlNode4;
      if ((xmlNode4 = zoneNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ZoneState']", nsmgr)) != null)
      {
        XmlAttribute attribute;
        if ((attribute = xmlNode4.Attributes["StateValue"]) != null)
        {
          try
          {
            modbusMap2Zone.ZoneState = ushort.Parse(attribute.Value);
          }
          catch (Exception ex)
          {
            modbusMap2Zone.ZoneState = (ushort) 0;
          }
        }
      }
      XmlNode xmlNode5;
      if ((xmlNode5 = zoneNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ZoneAirFlow']", nsmgr)) != null)
      {
        XmlAttribute attribute;
        if ((attribute = xmlNode5.Attributes["AirFlowValue"]) != null)
        {
          try
          {
            modbusMap2Zone.Airflow = ushort.Parse(attribute.Value);
          }
          catch (Exception ex)
          {
            modbusMap2Zone.Airflow = (ushort) 0;
          }
        }
      }
      XmlNode xmlNode6;
      if ((xmlNode6 = zoneNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='ZoneArea']", nsmgr)) != null)
      {
        XmlAttribute attribute1;
        if ((attribute1 = xmlNode6.Attributes["AreaValue"]) != null)
        {
          if (attribute1.Value.Contains("E") || attribute1.Value.Contains("e"))
          {
            float num = float.Parse(attribute1.Value, NumberStyles.AllowExponent, (IFormatProvider) cultureInfo);
            modbusMap2Zone.Area = Convert.ToDecimal(num);
          }
          else
            modbusMap2Zone.Area = attribute1.Value == "" || attribute1.Value == "-1" || attribute1.Value == "0" ? 1M : Decimal.Parse(attribute1.Value, (IFormatProvider) cultureInfo);
        }
        XmlAttribute attribute2;
        if ((attribute2 = xmlNode6.Attributes["ZoneAreaUnit"]) != null)
          modbusMap2Zone.AreaUnits = ushort.Parse(attribute2.Value);
      }
      XmlNode xmlNode7;
      if ((xmlNode7 = zoneNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Recipe']", nsmgr)) != null)
        modbusMap2Zone.RecipeName = xmlNode7.InnerText.Trim();
      return modbusMap2Zone;
    }

    private ModbusMap2Recipe ReadRecipeConfig(
      XmlNode recipeNode,
      XmlNamespaceManager nsmgr,
      bool viableCounts,
      CultureInfo cultureInfo)
    {
      ModbusMap2Recipe modbusMap2Recipe = new ModbusMap2Recipe(-1);
      XmlAttribute attribute1 = recipeNode.Attributes["AlarmThresholdMode"];
      XmlAttribute attribute2 = recipeNode.Attributes["AlarmThresholdUnits"];
      if (attribute1 == null || attribute2 == null)
        return (ModbusMap2Recipe) null;
      ushort num1 = ushort.Parse(attribute1.Value);
      modbusMap2Recipe.AlarmThresholdMode = (ushort) ((uint) num1 << 8);
      modbusMap2Recipe.AlarmThresholdMode &= (ushort) 65280;
      ushort num2 = ushort.Parse(attribute2.Value);
      modbusMap2Recipe.AlarmThresholdMode |= num2;
      XmlNode xmlNode1 = recipeNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Name']", nsmgr);
      if (xmlNode1 == null)
        return (ModbusMap2Recipe) null;
      modbusMap2Recipe.Name = xmlNode1.InnerText.Trim();
      XmlNode xmlNode2;
      if ((xmlNode2 = recipeNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='SampleTime']", nsmgr)) != null)
      {
        int seconds = int.Parse(xmlNode2.InnerText.Trim());
        modbusMap2Recipe.SampleTime = new TimeSpan(0, 0, seconds);
      }
      XmlNode xmlNode3;
      if ((xmlNode3 = recipeNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='SampleDelay']", nsmgr)) != null)
      {
        int seconds = int.Parse(xmlNode3.InnerText.Trim());
        modbusMap2Recipe.DelayTime = new TimeSpan(0, 0, seconds);
      }
      XmlNode xmlNode4;
      if ((xmlNode4 = recipeNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='SampleHold']", nsmgr)) != null)
      {
        int seconds = int.Parse(xmlNode4.InnerText.Trim());
        modbusMap2Recipe.HoldTime = new TimeSpan(0, 0, seconds);
      }
      XmlNode xmlNode5;
      if ((xmlNode5 = recipeNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='SampleMode']", nsmgr)) != null)
        modbusMap2Recipe.SamplingMode = (SampleCountMode) int.Parse(xmlNode5.InnerText.Trim());
      XmlNode xmlNode6;
      if ((xmlNode6 = recipeNode.SelectSingleNode("descendant::ss:Cell/ss:Data[@DataType='Cycles']", nsmgr)) != null)
        modbusMap2Recipe.Cycles = uint.Parse(xmlNode6.InnerText.Trim());
      foreach (XmlNode selectNode in recipeNode.SelectNodes("descendant::ss:Cell/ss:Data[@DataType='ChannelSize']", nsmgr))
      {
        uint index = uint.Parse(selectNode.Attributes["ChannelNumber"].Value) - 1U;
        float num3 = float.Parse(selectNode.InnerText.Trim(), (IFormatProvider) cultureInfo);
        modbusMap2Recipe.ChannelSizes[(IntPtr) index] = (ushort) ((double) num3 * 1000.0 + 0.5);
        modbusMap2Recipe.channelEnable[(IntPtr) index] = ushort.Parse(selectNode.Attributes["Enable"].Value) == (ushort) 1;
        if (viableCounts)
        {
          modbusMap2Recipe.ChannelSizes[(IntPtr) (index + 6U)] = modbusMap2Recipe.ChannelSizes[(IntPtr) index];
          modbusMap2Recipe.channelEnable[(IntPtr) (index + 6U)] = modbusMap2Recipe.channelEnable[(IntPtr) index];
        }
      }
      foreach (XmlNode selectNode in recipeNode.SelectNodes("descendant::ss:Cell/ss:Data[@DataType='Threshold']", nsmgr))
      {
        uint num4 = uint.Parse(selectNode.Attributes["ChannelNumber"].Value);
        modbusMap2Recipe.alarmEnable[(IntPtr) (num4 - 1U)] = ushort.Parse(selectNode.Attributes["Alarm"].Value) == (ushort) 1;
        modbusMap2Recipe.alarmValues[(IntPtr) (num4 - 1U)] = uint.Parse(selectNode.InnerText.Trim());
      }
      return modbusMap2Recipe;
    }
  }
}
