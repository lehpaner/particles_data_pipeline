﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ChannelCollectionStatistics
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  internal class ChannelCollectionStatistics : ChannelCollection
  {
    private Decimal cumulativeTotal;

    public void Accumulate(
      ISample sample,
      ParticleCountMode particleCountMode,
      bool normalized,
      VolumeType normalizedParticleVolume)
    {
      this.Clear();
      this.AccumulateViable(sample, particleCountMode, normalized, normalizedParticleVolume);
      ChannelCollection channels = sample.Channels;
      if (particleCountMode == ParticleCountMode.Cumulative)
        this.ZeroCumulative();
      for (int index = channels.Count - 1; index >= 0; --index)
      {
        IChannel channel = channels[index];
        Decimal particleCount = particleCountMode != ParticleCountMode.Cumulative ? this.GetDifferential(sample, channel, normalized, normalizedParticleVolume) : this.Accumulate(sample, channel, normalized, normalizedParticleVolume);
        this.Insert(0, (IChannel) new Channel(channel.AlarmActive, channel.Interpolated, channel.ParticleSizeMicrometres, particleCount));
      }
    }

    public void AccumulateViable(
      ISample sample,
      ParticleCountMode particleCountMode,
      bool normalized,
      VolumeType normalizedParticleVolume)
    {
      ChannelCollection viableChannels = sample.ViableChannels;
      if (particleCountMode == ParticleCountMode.Cumulative)
        this.ZeroCumulative();
      for (int index = viableChannels.Count - 1; index >= 0; --index)
      {
        IChannel channel = viableChannels[index];
        Decimal particleCount = particleCountMode != ParticleCountMode.Cumulative ? this.GetDifferential(sample, channel, normalized, normalizedParticleVolume) : this.Accumulate(sample, channel, normalized, normalizedParticleVolume);
        this.Insert(0, (IChannel) new Channel(channel.AlarmActive, channel.Interpolated, channel.ParticleSizeMicrometres, particleCount));
      }
    }

    protected void ZeroCumulative() => this.cumulativeTotal = 0M;

    protected Decimal Accumulate(
      ISample sample,
      IChannel channel,
      bool normalized,
      VolumeType normalizedParticleConcentration)
    {
      this.cumulativeTotal += channel.ParticleCount;
      if (!normalized)
        return this.cumulativeTotal;
      float num;
      switch (normalizedParticleConcentration)
      {
        case VolumeType.FeetCubed:
          num = 28.3f;
          break;
        case VolumeType.MetresCubed:
          num = 1000f;
          break;
        default:
          num = 1f;
          break;
      }
      return !(sample.VolumeLitres != 0M) ? 0M : (Decimal) (num * (float) this.cumulativeTotal / (float) sample.VolumeLitres);
    }

    protected Decimal GetDifferential(
      ISample sample,
      IChannel channel,
      bool normalized,
      VolumeType normalizedParticleConcentration)
    {
      return sample.GetParticleCount(channel, normalized, normalizedParticleConcentration);
    }
  }
}
