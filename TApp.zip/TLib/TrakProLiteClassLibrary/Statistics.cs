﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.Statistics
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public abstract class Statistics
  {
    private int count;
    private Decimal maximum;
    private Decimal minimum;
    private Decimal sum;

    public Statistics() => this.Zero();

    public virtual int Count => this.count;

    public virtual Decimal Maximum
    {
      get => this.maximum;
      set => this.maximum = value;
    }

    public virtual Decimal Mean => this.Count == 0 ? -1M : this.Sum / (Decimal) this.Count;

    public virtual Decimal Minimum
    {
      get => this.minimum;
      set => this.minimum = value;
    }

    public abstract Decimal RMS { get; }

    public abstract Decimal StandardDeviation { get; }

    public virtual Decimal StandardVariance
    {
      get => this.Count == 0 ? -1M : this.StandardDeviation * this.StandardDeviation;
    }

    public virtual Decimal Sum => this.sum;

    public abstract Decimal UCL95(Decimal uclFactor);

    public virtual void Accumulate(Decimal value)
    {
      this.sum += value;
      ++this.count;
      if (this.minimum > value)
        this.minimum = value;
      if (!(this.maximum < value))
        return;
      this.maximum = value;
    }

    public virtual void Zero()
    {
      this.count = 0;
      this.maximum = Decimal.MinValue;
      this.minimum = Decimal.MaxValue;
      this.sum = 0.0M;
    }

    public static Decimal Round(Decimal input, int decimalPlaces)
    {
      Decimal num = (Decimal) Math.Pow(10.0, (double) decimalPlaces);
      return Statistics.Round(input * num) / num;
    }

    public static Decimal Round(Decimal input) => (Decimal) Math.Floor((double) (input + 0.5M));

    public static Decimal Round(float input) => (Decimal) Math.Floor((double) input + 0.5);
  }
}
