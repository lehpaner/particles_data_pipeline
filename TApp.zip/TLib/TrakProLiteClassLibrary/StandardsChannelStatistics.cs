﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.StandardsChannelStatistics
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class StandardsChannelStatistics : ChannelStatisticsPartialPopulation
  {
    private List<TrakProLiteClassLibrary.StandardsLocationStatistics> standardsLocationStatistics;
    private Decimal minimumVolume;
    private bool metric;
    private bool calculatingStatistics;

    public StandardsChannelStatistics()
    {
      this.metric = true;
      this.calculatingStatistics = false;
    }

    public StandardsChannelStatistics(Decimal cutPointSizeMicrometres, bool metric)
      : base(cutPointSizeMicrometres)
    {
      this.metric = metric;
      this.calculatingStatistics = false;
    }

    public override int Count => this.standardsLocationStatistics.Count;

    public override Decimal CutPointSizeMicrometres
    {
      get => base.CutPointSizeMicrometres;
      set
      {
        base.CutPointSizeMicrometres = value;
        this.Zero();
      }
    }

    public override Decimal Maximum
    {
      get
      {
        this.CalculateStatistics();
        return base.Maximum;
      }
    }

    public override Decimal Mean
    {
      get
      {
        this.CalculateStatistics();
        return base.Mean;
      }
    }

    public override Decimal Minimum
    {
      get
      {
        this.CalculateStatistics();
        return base.Minimum;
      }
    }

    public Decimal MinimumVolume
    {
      get
      {
        this.CalculateStatistics();
        return this.minimumVolume;
      }
    }

    public int SamplesPerZone
    {
      get
      {
        int samplesPerZone = 0;
        foreach (TrakProLiteClassLibrary.StandardsLocationStatistics locationStatistic in this.StandardsLocationStatistics)
          samplesPerZone += locationStatistic.Count;
        return samplesPerZone;
      }
    }

    public int MinSamplesPerZoneLocation
    {
      get
      {
        int samplesPerZoneLocation = 100000;
        foreach (TrakProLiteClassLibrary.StandardsLocationStatistics locationStatistic in this.StandardsLocationStatistics)
        {
          if (locationStatistic.Count < samplesPerZoneLocation)
            samplesPerZoneLocation = locationStatistic.Count;
        }
        return samplesPerZoneLocation;
      }
    }

    public List<TrakProLiteClassLibrary.StandardsLocationStatistics> StandardsLocationStatistics
    {
      get => this.standardsLocationStatistics;
    }

    public Decimal UpperConfidenceLevel95
    {
      get
      {
        if (this.Count <= 1 || this.Count >= 10)
          return 0.0M;
        Decimal uclFactor;
        switch (this.Count)
        {
          case 2:
            uclFactor = 6.3M;
            break;
          case 3:
            uclFactor = 2.9M;
            break;
          case 4:
            uclFactor = 2.4M;
            break;
          case 5:
            uclFactor = 2.1M;
            break;
          case 6:
            uclFactor = 2.0M;
            break;
          case 7:
            uclFactor = 1.9M;
            break;
          case 8:
            uclFactor = 1.90M;
            break;
          default:
            uclFactor = 1.90M;
            break;
        }
        return this.UCL95(uclFactor);
      }
    }

    public void Accumulate(Sample sample)
    {
      int index1 = 0;
      bool flag1 = false;
      while (index1 < sample.Channels.Count && !flag1)
      {
        flag1 = sample.Channels[index1].ParticleSizeMicrometres == this.CutPointSizeMicrometres;
        if (!flag1)
          ++index1;
      }
      if (flag1)
      {
        int index2 = 0;
        bool flag2 = false;
        while (index2 < this.standardsLocationStatistics.Count && !flag2)
        {
          flag2 = 0 == string.Compare(this.standardsLocationStatistics[index2].Location, sample.Location);
          if (!flag2)
            ++index2;
        }
        if (!flag2)
          this.standardsLocationStatistics.Add(new TrakProLiteClassLibrary.StandardsLocationStatistics(sample.Location));
        Decimal particleCount = 0.0M;
        for (; index1 < sample.Channels.Count; ++index1)
          particleCount += Convert.ToDecimal(sample.Channels[index1].ParticleCount);
        Decimal num = Statistics.Round(Sample.Normalize(particleCount, this.metric ? VolumeType.MetresCubed : VolumeType.FeetCubed, sample.VolumeLitres));
        this.standardsLocationStatistics[index2].Accumulate(num);
        this.standardsLocationStatistics[index2].AccumulateTime(sample.SampleTime);
        this.standardsLocationStatistics[index2].AccumulateVolume(sample.VolumeLitres);
      }
      this.needToRecalculate = true;
    }

    protected virtual void AccumulateVolume(Decimal volume)
    {
      if (!(volume < this.minimumVolume))
        return;
      this.minimumVolume = volume;
    }

    protected virtual void AccumulateTime(TimeSpan time)
    {
    }

    protected override void CalculateStatistics()
    {
      if (!this.needToRecalculate || this.calculatingStatistics)
        return;
      this.calculatingStatistics = true;
      base.Zero();
      foreach (TrakProLiteClassLibrary.StandardsLocationStatistics locationStatistic in this.standardsLocationStatistics)
      {
        this.Accumulate(locationStatistic.Mean);
        this.AccumulateVolume(locationStatistic.Volume);
        this.AccumulateTime(locationStatistic.TimeSpan);
      }
      base.CalculateStatistics();
      this.calculatingStatistics = false;
    }

    public override void Zero()
    {
      base.Zero();
      this.standardsLocationStatistics = new List<TrakProLiteClassLibrary.StandardsLocationStatistics>();
      this.minimumVolume = Decimal.MaxValue;
    }
  }
}
