﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.Channel
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class Channel : IChannel
  {
    private bool alarmActive;
    private bool interpolated;
    private Decimal particleSizeMicrometres;
    private Decimal particleCount;
    public static Decimal ChannelResolution = 0.1M;
    public static int Decimals = 1;
    public static string ParticleSizeNumericFormatString = "0.0";
    public static string ParticleCountNumericFormatString = "0";

    public Channel(
      bool alarmActive,
      bool interpolated,
      Decimal particleSizeMicrometres,
      Decimal particleCount)
    {
      this.alarmActive = alarmActive;
      this.interpolated = interpolated;
      this.particleSizeMicrometres = particleSizeMicrometres;
      this.particleCount = particleCount;
    }

    public bool AlarmActive => this.alarmActive;

    public bool Interpolated => this.interpolated;

    public Decimal ParticleSizeMicrometres => this.particleSizeMicrometres;

    public Decimal ParticleCount => this.particleCount;
  }
}
