﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ReportFormatService
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public abstract class ReportFormatService
  {
    protected bool meetsStandardsConcentrationRequirements;
    protected bool meetsStandardsUCLChannelConcentrationLimitRequirements;
    protected bool meetsStandardsSampleAndVolumeRequirements;
    protected static string volumeFormat = "0.###";
    protected static string statisticsFormat = "F1";
    protected static string concentrationFormat = "0.";
    protected static string locationSamplesAverageConcentrationFormat1 = "{0,-8} {1,4} {2,10}";
    protected static string locationSamplesAverageConcentrationFormat2 = "{0,-8}";
    protected static string standardsStatisticsFormat = "0";

    protected bool MeetsStandardsChannelConcentrationLimitRequirements(
      Decimal maximumAcceptableParticlesPerVolume,
      List<StandardsLocationStatistics> standardsLocationStatistics)
    {
      foreach (Statistics locationStatistic in standardsLocationStatistics)
      {
        if (locationStatistic.Mean > maximumAcceptableParticlesPerVolume)
          return false;
      }
      return true;
    }

    protected bool MeetsStandardsUCLChannelConcentrationLimitRequirements(
      Decimal maximumAcceptableParticlesPerVolume,
      StandardsChannelStatistics standardsChannelStatistics)
    {
      return maximumAcceptableParticlesPerVolume >= standardsChannelStatistics.UpperConfidenceLevel95;
    }

    protected bool MeetsStandardsLocationRequirements(
      int minLocationsForAirFlowAndArea,
      StandardsChannelStatistics standardsChannelStatistics)
    {
      return minLocationsForAirFlowAndArea <= standardsChannelStatistics.StandardsLocationStatistics.Count;
    }

    protected bool MeetsStandardsSamplesPerZoneRequirements(
      int minSamplesPerZoneForSamples,
      int totalNumberOfSamplesPerZone)
    {
      return minSamplesPerZoneForSamples <= totalNumberOfSamplesPerZone;
    }

    protected bool MeetsStandardsVolumeRequirements(
      Decimal maxMinChannelVolumeRequired,
      Decimal minUnitVolumeSampled)
    {
      return maxMinChannelVolumeRequired <= minUnitVolumeSampled;
    }

    protected bool MeetsStandardsMinimumSampleTimeRequirements(
      TimeSpan minimumRequiredSampleTimeForStandard,
      TimeSpan minimumSampleTime)
    {
      return minimumRequiredSampleTimeForStandard <= minimumSampleTime;
    }

    protected static string PassFailOrInvalid(
      bool meetsLocalStandardsSampleAndVolumeRequirements,
      bool meetsLocalStandardsParticleCountingRequirements,
      bool instrumentFunctionedCorrectlyAcrossAllSamples)
    {
      if (!meetsLocalStandardsSampleAndVolumeRequirements || !instrumentFunctionedCorrectlyAcrossAllSamples)
        return ReportStrings.ReportStatus[2];
      return meetsLocalStandardsParticleCountingRequirements ? ReportStrings.ReportStatus[0] : ReportStrings.ReportStatus[1];
    }
  }
}
