﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.EUGMP_1999_ReportConfiguration
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class EUGMP_1999_ReportConfiguration : StandardsReportConfiguration
  {
    private static EUGMP_1999_ReportConfiguration instance = new EUGMP_1999_ReportConfiguration();

    private EUGMP_1999_ReportConfiguration()
      : base("EUGMP-ISO:1999")
    {
      this.standardCutPointsMicrometres = new Decimal[2]
      {
        0.5M,
        5.0M
      };
      this.standardConcentrationLimits = new Decimal[4][]
      {
        new Decimal[2]{ 3520M, 20M },
        new Decimal[2]{ 3520M, 29M },
        new Decimal[2]{ 352000M, 2900M },
        new Decimal[2]{ 3520000M, 29000M }
      };
      this.minimumRequiredSampleTimeForStandard = new TimeSpan(0, 1, 0);
      this.minimumRequiredParticleSizeIndexesForClass = new int[4];
      this.maximumRequiredParticleSizeIndexesForClass = new int[4]
      {
        1,
        1,
        1,
        1
      };
      this.minimumRequiredParticleSizesForClass = new Decimal[4]
      {
        0.5M,
        0.5M,
        0.5M,
        0.5M
      };
      this.maximumRequiredParticleSizesForClass = new Decimal[4]
      {
        5.0M,
        5.0M,
        5.0M,
        5.0M
      };
      this.roomStatusStrings = new string[2]
      {
        "AtRest",
        "Operational"
      };
      this.roomStatusIndex = 0;
      this.airFlowStrings = new string[2]
      {
        "Unidirectional",
        "Multidirectional"
      };
      this.classLevelStrings = new string[4]
      {
        "A",
        "B",
        "C",
        "D"
      };
      this.classLevelIndex = 2;
      this.metricMeasurements = true;
      this.allowsSampleExclusion = true;
      this.requiresReplacementOfExcluded = false;
      this.maxAllowedSamplesExcluded = (short) 1;
      this.usesLargestParticleToConsider = false;
    }

    public override bool IsMinimumSampleTimeRequired => true;

    public override bool IsValidRoomStatusAndClass(int roomStatusIndex, int classLevelIndex)
    {
      return roomStatusIndex != 1 || classLevelIndex != 3;
    }

    public override int RoomStatusIndex
    {
      get => base.RoomStatusIndex;
      set
      {
        base.RoomStatusIndex = value;
        this.CalculateConcentrationLimitsAndMinimumSampleVolumesForSpecifiedChannelSizesAndClassLevel();
      }
    }

    protected override Decimal CalculateConcentrationLimitNumberOfParticlePerVolume(
      Decimal particleSize)
    {
      return particleSize > 0M ? StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused : 0.0M;
    }

    protected override Decimal ConcentrationLimitNumberOfParticlesPerVolume(Decimal particleSize)
    {
      Decimal num;
      if (0.5M == particleSize)
      {
        if (this.RoomStatusIndex == 0)
        {
          switch (this.ClassLevelIndex)
          {
            case 0:
              num = 3520M;
              break;
            case 1:
              num = 3520M;
              break;
            case 2:
              num = 352000M;
              break;
            case 3:
              num = 3520000M;
              break;
            default:
              num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
              break;
          }
        }
        else
        {
          switch (this.ClassLevelIndex)
          {
            case 0:
              num = 3520M;
              break;
            case 1:
              num = 352000M;
              break;
            case 2:
              num = 3520000M;
              break;
            default:
              num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
              break;
          }
        }
      }
      else if (5.0M == particleSize)
      {
        if (this.RoomStatusIndex == 0)
        {
          switch (this.ClassLevelIndex)
          {
            case 0:
              num = 20M;
              break;
            case 1:
              num = 29M;
              break;
            case 2:
              num = 2900M;
              break;
            case 3:
              num = 29000M;
              break;
            default:
              num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
              break;
          }
        }
        else
        {
          switch (this.ClassLevelIndex)
          {
            case 0:
              num = 20M;
              break;
            case 1:
              num = 2900M;
              break;
            case 2:
              num = 29000M;
              break;
            default:
              num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
              break;
          }
        }
      }
      else
        num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
      return num;
    }

    protected override Decimal CalculateMinimumSampleVolume(
      Decimal concentrationLimitsNumberOfParticlesPerCubicMetre)
    {
      Decimal minimumSampleVolume;
      if (this.ClassLevelIndex == 0)
      {
        minimumSampleVolume = 1000M;
      }
      else
      {
        minimumSampleVolume = 2M;
        if (concentrationLimitsNumberOfParticlesPerCubicMetre <= 0M)
          return minimumSampleVolume;
        Decimal num = 20M / concentrationLimitsNumberOfParticlesPerCubicMetre * 1000M;
        if (num > minimumSampleVolume)
          minimumSampleVolume = num;
      }
      return minimumSampleVolume;
    }

    public static EUGMP_1999_ReportConfiguration Copy
    {
      get
      {
        EUGMP_1999_ReportConfiguration copy = new EUGMP_1999_ReportConfiguration();
        copy.AirFlowIndex = EUGMP_1999_ReportConfiguration.instance.AirFlowIndex;
        copy.RoomArea = EUGMP_1999_ReportConfiguration.instance.RoomArea;
        copy.RoomStatusIndex = EUGMP_1999_ReportConfiguration.instance.RoomStatusIndex;
        copy.ClassLevelIndex = EUGMP_1999_ReportConfiguration.instance.ClassLevelIndex;
        copy.CutPointsSizesMicrometersSpecified = EUGMP_1999_ReportConfiguration.instance.cutPointsSizesMicrometersSpecified;
        return copy;
      }
    }

    public static EUGMP_1999_ReportConfiguration Instance
    {
      get => EUGMP_1999_ReportConfiguration.instance;
    }

    public override int MinimumNumberOfSampleLocationsForAirFlowAndArea
    {
      get => Convert.ToInt32(Math.Ceiling(Math.Sqrt(Convert.ToDouble(this.RoomArea))));
    }

    public override int MinimumNumberOfSamplesPerZoneForSamples
    {
      get
      {
        int forAirFlowAndArea = this.MinimumNumberOfSampleLocationsForAirFlowAndArea;
        return forAirFlowAndArea == 1 ? 3 : forAirFlowAndArea;
      }
    }

    public override int MinimumNumberOfSamplesPerLocation
    {
      get => this.MinimumNumberOfSampleLocationsForAirFlowAndArea == 1 ? 3 : 1;
    }

    public override Decimal MinimumSampleTimePerLocationSeconds => 60.0M;

    public override bool Uses95UCL => true;

    public override bool UsesStandardError => true;

    public override VolumeType VolumeUnits => VolumeType.Litres;
  }
}
