﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ChannelStatistics
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ChannelStatistics : Statistics
  {
    private Decimal[] particleCount;
    private int numSamples;
    private Decimal sumOfTheSquares;
    private Decimal sum;
    private Decimal cutPointSizeMicrometres;
    private Decimal standardError;
    private bool isVCntChannel;
    private Decimal vCntSum;

    public ChannelStatistics(Decimal cutPointSize, bool isVCnt, int numSamples)
    {
      this.numSamples = numSamples;
      this.cutPointSizeMicrometres = cutPointSize;
      this.isVCntChannel = isVCnt;
      this.Zero();
    }

    public Decimal Total => this.sum;

    public Decimal TCNT => this.sum;

    public Decimal VCNT => this.vCntSum;

    public int NumberOfSamples => this.numSamples;

    public Decimal CutPointSizeMicrometres => this.cutPointSizeMicrometres;

    public override void Zero()
    {
      base.Zero();
      this.particleCount = new Decimal[this.numSamples];
      this.sumOfTheSquares = 0M;
      this.standardError = 0M;
      this.sum = 0M;
      this.vCntSum = 0M;
      if (this.numSamples != 0)
        return;
      this.Maximum = 0M;
      this.Minimum = 0M;
    }

    public override Decimal RMS
    {
      get
      {
        return this.Count == 0 ? -1M : (Decimal) Math.Sqrt(Decimal.ToDouble(this.sumOfTheSquares / (Decimal) this.Count));
      }
    }

    public void Accumulate(int sampleIndex, Decimal value)
    {
      this.Accumulate(value);
      if (!this.isVCntChannel)
        this.sum += value;
      else
        this.vCntSum += value;
      this.sumOfTheSquares += value * value;
      this.particleCount[sampleIndex] = value;
    }

    public override Decimal UCL95(Decimal uclFactor)
    {
      return this.Mean + uclFactor * (this.StandardDeviation / (Decimal) Math.Sqrt((double) this.Count));
    }

    public override Decimal StandardDeviation
    {
      get
      {
        if (this.Count == 0)
          return -1M;
        Decimal d = 0M;
        double num = 0.0;
        for (int index = 0; index < this.particleCount.Length; ++index)
          num += Math.Pow(Decimal.ToDouble(this.particleCount[index] - this.Mean), 2.0);
        if (this.particleCount.Length > 1)
        {
          d = (Decimal) Math.Sqrt(num / (double) (this.particleCount.Length - 1));
          this.standardError = (Decimal) (Decimal.ToDouble(d) / Math.Sqrt((double) this.numSamples));
        }
        else
          this.standardError = 0M;
        return d;
      }
    }

    public Decimal StandardError => this.standardError;

    public Decimal GetStandardError(Decimal standardDeviation, int numValues)
    {
      return numValues == 0 ? -1M : (Decimal) (Decimal.ToDouble(standardDeviation) / Math.Sqrt((double) numValues));
    }
  }
}
