﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.IInstrument
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using TSI;
using TSI.Communication;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public interface IInstrument
  {
    string ModelNumber { get; }

    string SerialNumber { get; }

    string AlgorithmVersion { get; }

    DeviceType DeviceType { get; }

    bool HasZones { get; }

    bool HasRecipes { get; }

    bool VariableBins { get; }

    bool ViableCounts { get; }

    LocationList Locations { get; }

    RecipeList Recipes { get; }

    Decimal FlowRateLitresPerMinute { get; }

    Decimal MinimumCutPointSize { get; }

    Decimal MaximumCutPointSize { get; }

    Decimal[] CalibratedCutPointSizesMicrometres { get; }

    ushort NumberOfChannels { get; }

    DateTime LastCalibrationDate { get; }

    DateTime CalibrationDueDate { get; }

    FlowUnits FlowUnits { get; }

    ZoneList Zones { get; }

    ushort RecipeLabelLength { get; }

    string Name { get; }

    bool Locked { get; set; }

    bool Connected { get; set; }

    bool Unicode { get; }

    bool ZoneLocked(int zoneId);

    bool RecipeLocked(int recipeId);

    ushort[] ChannelSizes { get; }

    ushort FirmwareVersion { get; }

    List<ISample> SampleRecords { get; }

    uint NumberOfSamples { get; }

    bool HasDataIntegrity { get; }

    bool IsDIMode { get; set; }

    bool IsDIUserLoggedIn { get; }

    ushort DIUserId { get; }

    ConnectionType ConnType { get; }

    bool[] IsChannelViable { get; }
  }
}
