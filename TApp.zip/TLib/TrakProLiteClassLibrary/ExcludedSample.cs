﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ExcludedSample
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ExcludedSample : DataTable
  {
    public static string ExcludedSampleTableName = nameof (ExcludedSample);
    public static string SampleHeaderColumnName = "SampleDateTime";
    public static string LocationColumnName = "Location";
    public static string SampleIdColumnName = "SampleId";
    public static string SizeColumnName = "Size";
    public static string ParticleCountColumnName = "ParticleCount";

    public ExcludedSample()
      : base(ExcludedSample.ExcludedSampleTableName)
    {
      this.Columns.Add(new DataColumn(ExcludedSample.SampleHeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ExcludedSample.LocationColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ExcludedSample.SampleIdColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ExcludedSample.SizeColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ExcludedSample.ParticleCountColumnName, typeof (string)));
    }
  }
}
