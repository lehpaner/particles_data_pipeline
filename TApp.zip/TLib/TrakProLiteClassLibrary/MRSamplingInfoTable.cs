﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MRSamplingInfoTable
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MRSamplingInfoTable : DataTable
  {
    public static string SamplingInfoTableName = "SamplingInfoTable";
    public static string HeaderColumnName = "SamplingHeader";
    public static string ValueColumnName = "SamplingValue";

    public MRSamplingInfoTable()
      : base(MRSamplingInfoTable.SamplingInfoTableName)
    {
      this.Columns.Add(new DataColumn(MRSamplingInfoTable.HeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRSamplingInfoTable.ValueColumnName, typeof (string)));
    }
  }
}
