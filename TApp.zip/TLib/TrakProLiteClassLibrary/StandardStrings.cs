﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.StandardStrings
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class StandardStrings
  {
    public static string[] AirFlow = new string[2]
    {
      "Unidirectional",
      "Multidirectional"
    };
    public static string[] AirVelocityUnits = new string[2]
    {
      "mps",
      "fps"
    };
    public static string[] CO2Units = new string[1]{ "ppm" };
    public static string[] HumidityUnits = new string[1]
    {
      "PercentRelativeHumidity"
    };
    public static string[] NormalizedParticleVolume = new string[2]
    {
      "FeetAbbreviation",
      "MeterAbbreviation"
    };
    public static string[] PrintHumidityUnits = new string[1]
    {
      "PercentRelativeHumidity"
    };
    public static string[] ParticleCountMode = new string[2]
    {
      "Δ",
      "Σ"
    };
    public static string[] PrintAirVelocityUnits = new string[2]
    {
      "PrintMetersPerSecond",
      "PrintFeetPerSecond"
    };
    public static string[] PrintCO2LevelUnits = new string[1]
    {
      "PrintCO2LevelPartsPerMillion"
    };
    public static string[] PrintParticleCountMode = new string[2]
    {
      "DifferentialAbbreviation",
      "CumulativeAbbreviation"
    };
    public static string[] PrintTemperatureUnits = new string[2]
    {
      "PrintDegreesFahrenheitAbbreviation",
      "PrintDegreesCelciusAbbreviation"
    };
    public static string[] ZoneStatus = new string[3]
    {
      "AtRest",
      "Operational",
      "AsBuilt"
    };
    public static string[] SampleCountMode = new string[3]
    {
      "Automatic",
      "Manual",
      "Beep"
    };
    public static string[] SamplingState = new string[6]
    {
      "",
      "StartDelay",
      "Holding",
      "Sampling",
      "",
      ""
    };
    public static string[] TemperatureUnits = new string[2]
    {
      "DegreesFahrenheitAbbreviation",
      "DegreesCelciusAbbreviation"
    };
    public static string[] VolumeUnits = new string[4]
    {
      "mL",
      "ft\u00B3",
      "m\u00B3",
      "L"
    };
    public static string[] ReportStatus = new string[3]
    {
      "Pass",
      "Fail",
      "Invalid"
    };
    public static string[] StandardsReportNames = new string[7]
    {
      "ISO 14644-1:1999",
      "EUGMP-ISO:1999",
      "Fed Std 209E F",
      "Fed Std 209E M",
      "Manual",
      "ISO 14644-1:2015",
      "EUGMP-ISO:2015"
    };
    public static string[][] ClassLevel = new string[7][]
    {
      new string[9]{ "1", "2", "3", "4", "5", "6", "7", "8", "9" },
      new string[4]{ "A", "B", "C", "D" },
      new string[6]{ "1", "10", "100", "1000", "10000", "100000" },
      new string[13]
      {
        "M1",
        "M1.5",
        "M2",
        "M2.5",
        "M3",
        "M3.5",
        "M4",
        "M4.5",
        "M5",
        "M5.5",
        "M6",
        "M6.5",
        "M7"
      },
      new string[1]{ "N/A" },
      new string[15]
      {
        "2",
        "2.5",
        "3",
        "3.5",
        "4",
        "4.5",
        "5",
        "5.5",
        "6",
        "6.5",
        "7",
        "7.5",
        "8",
        "8.5",
        "9"
      },
      new string[4]{ "A", "B", "C", "D" }
    };

    private StandardStrings()
    {
    }
  }
}
