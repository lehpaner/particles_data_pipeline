﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MRResultsTable
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MRResultsTable : DataTable
  {
    public static string ResultsTableName = "ResultsTable";
    public static string SampledByColumnName = "SampledBy";
    public static string LocationHeaderColumnName = "LocationHeader";
    public static string LocationColumnName = "Location";
    public static string DateColumnName = "DateTime";
    public static string SampleTimeColName = "SampleTime";
    public static string VolumeColumnName = "Volume";
    public static string SizeColumnName = "Size";
    public static string ConcColumnName = "Conc";
    public static string DeviceStatusColName = "DeviceStatus";
    public static string FlowStatusColName = "FlowStatus";
    public static string LaserStatusColName = "LaserStatus";
    public static string IsActionColName = "IsAction";
    public static string IsAlertColName = "IsAlert";
    public static string IsSampleCompleteColName = "IsSampleComplete";

    public MRResultsTable()
      : base(MRResultsTable.ResultsTableName)
    {
      this.Columns.Add(new DataColumn(MRResultsTable.SampledByColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.LocationColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.DateColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.SampleTimeColName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.VolumeColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.SizeColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.ConcColumnName, typeof (Decimal)));
      this.Columns.Add(new DataColumn(MRResultsTable.DeviceStatusColName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.FlowStatusColName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.LaserStatusColName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsTable.IsActionColName, typeof (bool)));
      this.Columns.Add(new DataColumn(MRResultsTable.IsAlertColName, typeof (bool)));
      this.Columns.Add(new DataColumn(MRResultsTable.IsSampleCompleteColName, typeof (bool)));
    }
  }
}
