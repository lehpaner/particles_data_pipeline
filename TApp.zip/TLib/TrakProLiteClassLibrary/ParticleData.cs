﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ParticleData
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ParticleData : DataTable
  {
    public static string ParticleDataTableName = nameof (ParticleData);
    public static string ParticleHeaderColumnName = "ParticleHeader";
    public static string SizeColumnName = "Size";
    public static string MaxColumnName = "Max";
    public static string MeanColumnName = "Mean";
    public static string StdDevColumnName = "Std Dev";
    public static string UCLColumnName = "95% UCL";
    public static string ConcLimitColumnName = "Conc Limit";

    public ParticleData()
      : base(ParticleData.ParticleDataTableName)
    {
      this.Columns.Add(new DataColumn(ParticleData.ParticleHeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ParticleData.SizeColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ParticleData.MaxColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ParticleData.MeanColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ParticleData.StdDevColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ParticleData.UCLColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(ParticleData.ConcLimitColumnName, typeof (string)));
    }
  }
}
