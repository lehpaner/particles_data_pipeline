﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.EUGMP_2015_ReportConfiguration
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class EUGMP_2015_ReportConfiguration : StandardsReportConfiguration
  {
    private static EUGMP_2015_ReportConfiguration instance = new EUGMP_2015_ReportConfiguration();

    private EUGMP_2015_ReportConfiguration()
      : base("EUGMP-ISO:2015")
    {
      this.standardCutPointsMicrometres = new Decimal[2]
      {
        0.5M,
        5.0M
      };
      this.standardConcentrationLimits = new Decimal[4][]
      {
        new Decimal[2]{ 3520M, 20M },
        new Decimal[2]{ 3520M, 29M },
        new Decimal[2]{ 352000M, 2900M },
        new Decimal[2]{ 3520000M, 29000M }
      };
      this.minimumRequiredSampleTimeForStandard = new TimeSpan(0, 1, 0);
      this.minimumRequiredParticleSizeIndexesForClass = new int[4];
      this.maximumRequiredParticleSizeIndexesForClass = new int[4]
      {
        1,
        1,
        1,
        1
      };
      this.minimumRequiredParticleSizesForClass = new Decimal[4]
      {
        0.5M,
        0.5M,
        0.5M,
        0.5M
      };
      this.maximumRequiredParticleSizesForClass = new Decimal[4]
      {
        5.0M,
        5.0M,
        5.0M,
        5.0M
      };
      this.roomStatusStrings = new string[2]
      {
        "AtRest",
        "Operational"
      };
      this.airFlowStrings = new string[2]
      {
        "Unidirectional",
        "Non-unidirectional"
      };
      this.roomStatusIndex = 0;
      this.classLevelStrings = new string[4]
      {
        "A",
        "B",
        "C",
        "D"
      };
      this.classLevelIndex = 2;
      this.metricMeasurements = true;
      this.allowsSampleExclusion = true;
      this.requiresReplacementOfExcluded = true;
      this.maxAllowedSamplesExcluded = (short) 5;
      this.usesLargestParticleToConsider = false;
    }

    public override bool IsMinimumSampleTimeRequired => true;

    public override bool IsValidRoomStatusAndClass(int roomStatusIndex, int classLevelIndex)
    {
      return roomStatusIndex != 1 || classLevelIndex != 3;
    }

    public override int RoomStatusIndex
    {
      get => base.RoomStatusIndex;
      set
      {
        base.RoomStatusIndex = value;
        this.CalculateConcentrationLimitsAndMinimumSampleVolumesForSpecifiedChannelSizesAndClassLevel();
      }
    }

    protected override Decimal CalculateConcentrationLimitNumberOfParticlePerVolume(
      Decimal particleSize)
    {
      return StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
    }

    protected override Decimal ConcentrationLimitNumberOfParticlesPerVolume(Decimal particleSize)
    {
      Decimal num;
      if (0.5M == particleSize)
      {
        if (this.RoomStatusIndex == 0)
        {
          switch (this.ClassLevelIndex)
          {
            case 0:
              num = 3520M;
              break;
            case 1:
              num = 3520M;
              break;
            case 2:
              num = 352000M;
              break;
            case 3:
              num = 3520000M;
              break;
            default:
              num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
              break;
          }
        }
        else
        {
          switch (this.ClassLevelIndex)
          {
            case 0:
              num = 3520M;
              break;
            case 1:
              num = 352000M;
              break;
            case 2:
              num = 3520000M;
              break;
            default:
              num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
              break;
          }
        }
      }
      else if (5.0M == particleSize)
      {
        if (this.RoomStatusIndex == 0)
        {
          switch (this.ClassLevelIndex)
          {
            case 0:
              num = 20M;
              break;
            case 1:
              num = 29M;
              break;
            case 2:
              num = 2900M;
              break;
            case 3:
              num = 29000M;
              break;
            default:
              num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
              break;
          }
        }
        else
        {
          switch (this.ClassLevelIndex)
          {
            case 0:
              num = 20M;
              break;
            case 1:
              num = 2900M;
              break;
            case 2:
              num = 29000M;
              break;
            default:
              num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
              break;
          }
        }
      }
      else
        num = StandardsReportConfiguration.concentrationLimitsNumberOfParticlesPerCubicMetreUnused;
      return num;
    }

    protected override Decimal CalculateMinimumSampleVolume(
      Decimal concentrationLimitsNumberOfParticlesPerCubicMetre)
    {
      Decimal minimumSampleVolume;
      if (this.ClassLevelIndex == 0)
      {
        minimumSampleVolume = 1000M;
      }
      else
      {
        minimumSampleVolume = 2M;
        if (concentrationLimitsNumberOfParticlesPerCubicMetre <= 0M)
          return minimumSampleVolume;
        Decimal num = 20M / concentrationLimitsNumberOfParticlesPerCubicMetre * 1000M;
        if (num > minimumSampleVolume)
          minimumSampleVolume = num;
      }
      return minimumSampleVolume;
    }

    public static EUGMP_2015_ReportConfiguration Copy
    {
      get
      {
        EUGMP_2015_ReportConfiguration copy = new EUGMP_2015_ReportConfiguration();
        copy.AirFlowIndex = EUGMP_2015_ReportConfiguration.instance.AirFlowIndex;
        copy.RoomArea = EUGMP_2015_ReportConfiguration.instance.RoomArea;
        copy.RoomStatusIndex = EUGMP_2015_ReportConfiguration.instance.RoomStatusIndex;
        copy.ClassLevelIndex = EUGMP_2015_ReportConfiguration.instance.ClassLevelIndex;
        copy.CutPointsSizesMicrometersSpecified = EUGMP_2015_ReportConfiguration.instance.cutPointsSizesMicrometersSpecified;
        return copy;
      }
    }

    public static EUGMP_2015_ReportConfiguration Instance
    {
      get => EUGMP_2015_ReportConfiguration.instance;
    }

    public override int MinimumNumberOfSampleLocationsForAirFlowAndArea
    {
      get
      {
        if (this.RoomArea <= 2M)
          return 1;
        if (this.RoomArea <= 4M)
          return 2;
        if (this.RoomArea <= 6M)
          return 3;
        if (this.RoomArea <= 8M)
          return 4;
        if (this.RoomArea <= 10M)
          return 5;
        if (this.RoomArea <= 24M)
          return 6;
        if (this.RoomArea <= 28M)
          return 7;
        if (this.RoomArea <= 32M)
          return 8;
        if (this.RoomArea <= 36M)
          return 9;
        if (this.RoomArea <= 52M)
          return 10;
        if (this.RoomArea <= 56M)
          return 11;
        if (this.RoomArea <= 64M)
          return 12;
        if (this.RoomArea <= 68M)
          return 13;
        if (this.RoomArea <= 72M)
          return 14;
        if (this.RoomArea <= 76M)
          return 15;
        if (this.RoomArea <= 104M)
          return 16;
        if (this.RoomArea <= 108M)
          return 17;
        if (this.RoomArea <= 116M)
          return 18;
        if (this.RoomArea <= 148M)
          return 19;
        if (this.RoomArea <= 156M)
          return 20;
        if (this.RoomArea <= 192M)
          return 21;
        if (this.RoomArea <= 232M)
          return 22;
        if (this.RoomArea <= 276M)
          return 23;
        if (this.RoomArea <= 352M)
          return 24;
        if (this.RoomArea <= 436M)
          return 25;
        if (this.RoomArea <= 636M)
          return 26;
        return this.RoomArea <= 1000M ? 27 : 27 * (int) (this.RoomArea / 1000M);
      }
    }

    public override int MinimumNumberOfSamplesPerZoneForSamples
    {
      get => this.MinimumNumberOfSampleLocationsForAirFlowAndArea;
    }

    public override int MinimumNumberOfSamplesPerLocation
    {
      get
      {
        int forAirFlowAndArea = this.MinimumNumberOfSampleLocationsForAirFlowAndArea;
        return 1;
      }
    }

    public override Decimal MinimumSampleTimePerLocationSeconds => 60.0M;

    public override bool Uses95UCL => false;

    public override bool UsesStandardError => true;

    public override VolumeType VolumeUnits => VolumeType.Litres;
  }
}
