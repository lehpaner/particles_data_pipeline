﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.Properties.Resources
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace TrakProLiteClassLibrary.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) TrakProLiteClassLibrary.Properties.Resources.resourceMan, (object) null))
          TrakProLiteClassLibrary.Properties.Resources.resourceMan = new ResourceManager("TrakProLiteClassLibrary.Properties.Resources", typeof (TrakProLiteClassLibrary.Properties.Resources).Assembly);
        return TrakProLiteClassLibrary.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => TrakProLiteClassLibrary.Properties.Resources.resourceCulture;
      set => TrakProLiteClassLibrary.Properties.Resources.resourceCulture = value;
    }

    internal static string error
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (error), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }

    internal static string FileNotTPLV2
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (FileNotTPLV2), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }

    internal static string FileOpenError
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (FileOpenError), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }

    internal static string loc
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (loc), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }

    internal static string OpenDataFile
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (OpenDataFile), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }

    internal static string rcp
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (rcp), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }

    internal static string records
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (records), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }

    internal static string unknown
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (unknown), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }

    internal static string zone
    {
      get => TrakProLiteClassLibrary.Properties.Resources.ResourceManager.GetString(nameof (zone), TrakProLiteClassLibrary.Properties.Resources.resourceCulture);
    }
  }
}
