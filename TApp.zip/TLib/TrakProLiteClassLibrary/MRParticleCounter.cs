﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MRParticleCounter
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MRParticleCounter : DataTable
  {
    public static string ParticleCounterTableName = "ParticleCounter";
    public static string HeaderColumnName = "ParticleCounterHeader";
    public static string ValueColumnName = "ParticleCounterValue";

    public MRParticleCounter()
      : base(MRParticleCounter.ParticleCounterTableName)
    {
      this.Columns.Add(new DataColumn(MRParticleCounter.HeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRParticleCounter.ValueColumnName, typeof (string)));
    }
  }
}
