﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.Comments
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class Comments : DataTable
  {
    public static string CommentsTableName = nameof (Comments);
    public static string NameColumnName = "Name";

    public Comments()
      : base(Comments.CommentsTableName)
    {
      this.Columns.Add(new DataColumn(Comments.NameColumnName, typeof (string)));
    }
  }
}
