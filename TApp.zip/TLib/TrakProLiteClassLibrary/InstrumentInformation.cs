﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.InstrumentInformation
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class InstrumentInformation : DataTable
  {
    public static string InstrumentInfoTableName = nameof (InstrumentInformation);
    public static string HeaderColumnName = "InstrumentHeader";
    public static string ValueColumnName = "InstrumentValue";

    public InstrumentInformation()
      : base(InstrumentInformation.InstrumentInfoTableName)
    {
      this.Columns.Add(new DataColumn(InstrumentInformation.HeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(InstrumentInformation.ValueColumnName, typeof (string)));
    }
  }
}
