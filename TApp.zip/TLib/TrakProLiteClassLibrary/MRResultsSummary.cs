﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MRResultsSummary
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MRResultsSummary : DataTable
  {
    public static string ResultsSummaryTableName = "ResultsSummary";
    public static string HeaderColumnName = "ResultsSummaryHeader";
    public static string SizeColumnName = "Size";
    public static string AlertColumnName = "Alert";
    public static string ActionColumnName = "Action";
    public static string MinColumnName = "Min";
    public static string MaxColumnName = "Max";
    public static string MeanColumnName = "Mean";
    public static string LocationAlertColumnName = "LocationAlert";
    public static string LocationActionColumnName = "LocationAction";

    public MRResultsSummary()
      : base(MRResultsSummary.ResultsSummaryTableName)
    {
      this.Columns.Add(new DataColumn(MRResultsSummary.SizeColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsSummary.AlertColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsSummary.ActionColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsSummary.MinColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsSummary.MaxColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsSummary.MeanColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsSummary.LocationAlertColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRResultsSummary.LocationActionColumnName, typeof (string)));
    }
  }
}
