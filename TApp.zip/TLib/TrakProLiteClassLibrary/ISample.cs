﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ISample
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public interface ISample
  {
    ChannelCollection Channels { get; }

    ChannelCollection ViableChannels { get; }

    bool AlarmActive { get; }

    FlowStatus FlowStatus { get; }

    Decimal Humidity { get; }

    UnitCode HumidityUnits { get; }

    ushort DeviceStatus { get; }

    ushort InstrumentStatus { get; }

    bool LaserStatus { get; }

    string Location { get; }

    int LocationId { get; }

    TimeSpan SampleTime { get; }

    Decimal Temperature { get; }

    TemperatureType TemperatureUnits { get; }

    DateTime TimeStamp { get; }

    VolumeType VolumeUnits { get; }

    Decimal VolumeLitres { get; }

    double AverageFlowRateCubicMetresPerSecond { get; }

    float PrecisionFlowRate { get; }

    Decimal GetParticleCount(
      IChannel channel,
      bool normalized,
      VolumeType normalizedParticleVolume);

    Decimal AirVelocity { get; }

    UnitCode AirVelocityUnits { get; }

    uint SampleID { get; }

    bool Normalized { get; }

    RecordType CountMode { get; }

    ushort ViableDetectionSensitivity { get; }

    ushort DIUserId { get; }

    string DIUsername { get; }
  }
}
