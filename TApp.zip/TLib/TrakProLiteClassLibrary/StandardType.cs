﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.StandardType
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TrakProLiteClassLibrary
{
  public enum StandardType
  {
    ISO146441_1999,
    EUGMP_1999,
    FEDFT3,
    FEDM3,
    MANUAL,
    ISO146441_2015,
    EUGMP_2015,
  }
}
