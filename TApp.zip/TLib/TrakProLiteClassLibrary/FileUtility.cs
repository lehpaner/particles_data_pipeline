﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.FileUtility
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using TrakProLiteClassLibrary.Properties;
using TSI;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public static class FileUtility
  {
    public static FileType ReadDataFile(string filename, ref object obj)
    {
      FileType fileType;
      switch (Path.GetExtension(filename).Substring(1))
      {
        case "tplv2":
          FileUtility.RawDataRead(filename, ref obj);
          fileType = FileType.LegacyTPLV;
          break;
        case "xml":
          FileUtility.XmlDataRead(filename, ref obj);
          fileType = FileType.DataXML;
          break;
        default:
          fileType = FileType.Unknown;
          break;
      }
      return fileType;
    }

    public static FileType ReadRecipeFile(string filename, ref object obj, ref string strModel)
    {
      FileType fileType = FileType.Unknown;
      if (Path.GetExtension(filename).Substring(1).Equals("xml"))
      {
        ExcelXMLDataImport excelXmlDataImport = new ExcelXMLDataImport();
        obj = excelXmlDataImport.ImportRecipeFromFile(filename, ref strModel);
        fileType = FileType.DataXML;
      }
      return fileType;
    }

    public static FileType ReadZoneFile(string filename, ref object obj, ref string strModel)
    {
      FileType fileType = FileType.Unknown;
      if (Path.GetExtension(filename).Substring(1).Equals("xml"))
      {
        ExcelXMLDataImport excelXmlDataImport = new ExcelXMLDataImport();
        obj = excelXmlDataImport.ImportZoneFromFile(filename, ref strModel);
        fileType = FileType.DataXML;
      }
      return fileType;
    }

    public static FileType ReadLocationsFile(string filename, ref object obj)
    {
      FileType fileType = FileType.Unknown;
      if (Path.GetExtension(filename).Substring(1).Equals("xml"))
      {
        ExcelXMLDataImport excelXmlDataImport = new ExcelXMLDataImport();
        obj = excelXmlDataImport.ImportLocationsFromFile(filename);
        fileType = FileType.DataXML;
      }
      return fileType;
    }

    public static bool RawDataRead(string filename, ref object tmpObj)
    {
      bool flag = false;
      FileStream serializationStream;
      try
      {
        serializationStream = File.Open(filename, FileMode.Open);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(string.Format("Unable to open file {0}: {1}", (object) filename, (object) ex.Message), Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return flag;
      }
      try
      {
        tmpObj = new BinaryFormatter()
        {
          Binder = ((SerializationBinder) new VersionDeserializationBinder()),
          AssemblyFormat = FormatterAssemblyStyle.Simple
        }.Deserialize((Stream) serializationStream);
        flag = true;
      }
      catch (SerializationException ex)
      {
        int num = (int) MessageBox.Show(string.Format("{0} {1} Reason: {2}", (object) filename, (object) Resources.FileNotTPLV2, (object) ex.Message), Resources.OpenDataFile, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        serializationStream.Close();
      }
      finally
      {
        serializationStream.Close();
      }
      return flag;
    }

    private static bool XmlDataRead(string filename, ref object obj)
    {
      ExcelXMLDataImport excelXmlDataImport = new ExcelXMLDataImport();
      obj = excelXmlDataImport.ImportDataFromFile(filename);
      return obj != null;
    }

    public static bool XmlDataExport(
      string fileName,
      IInstrument instrument,
      List<ISample> sampleRecords,
      ZoneList selectedZones,
      LocationList selectedLocations,
      RecipeList selectedRecipes,
      Preferences preferences,
      string userName)
    {
      new ExcelXMLDataExport().ExportData(fileName, instrument, sampleRecords, selectedZones, selectedLocations, selectedRecipes, preferences, userName);
      return true;
    }

    public static bool XmlDataExport(string fileName, IInstrument instrument, ZoneList zones)
    {
      return new ExcelXMLDataExport().ExportData(fileName, instrument, zones);
    }

    public static bool XmlDataExport(string fileName, IInstrument instrument, RecipeList recipes)
    {
      new ExcelXMLDataExport().ExportData(fileName, instrument, recipes);
      return true;
    }

    public static bool XmlDataExport(
      string fileName,
      IInstrument instrument,
      LocationList locations)
    {
      new ExcelXMLDataExport().ExportData(fileName, instrument, locations);
      return true;
    }

    public static string CreateHash(FileStream fs)
    {
      MD5 md5 = MD5.Create();
      long position = fs.Position;
      fs.Position = 0L;
      byte[] hash = md5.ComputeHash((Stream) fs);
      StringBuilder stringBuilder = new StringBuilder(hash.Length * 2);
      foreach (byte num in hash)
        stringBuilder.AppendFormat("{0:x2}", (object) num);
      fs.Position = position;
      return stringBuilder.ToString();
    }

    public static string CreateHash(byte[] buffer, int offset, int count)
    {
      byte[] hash = MD5.Create().ComputeHash(buffer, offset, count);
      StringBuilder stringBuilder = new StringBuilder(hash.Length * 2);
      foreach (byte num in hash)
        stringBuilder.AppendFormat("{0:x2}", (object) num);
      return stringBuilder.ToString();
    }

    public static bool VerifyMd5Hash(string expectedHash, string filename, string marker)
    {
      bool flag1 = false;
      if (string.IsNullOrEmpty(marker))
        return false;
      byte[] bytes = Encoding.UTF8.GetBytes(marker);
      try
      {
        FileStream fileStream = new FileStream(filename, FileMode.Open, FileAccess.Read);
        int length = (int) fileStream.Length;
        byte[] numArray = new byte[length];
        int offset = 0;
        int num1;
        for (; length > 0; length -= num1)
        {
          num1 = fileStream.Read(numArray, offset, length);
          if (num1 != 0)
            offset += num1;
          else
            break;
        }
        int num2 = FileUtility.IndexOfBytes(numArray, bytes, 0, numArray.Length);
        if (num2 == -1)
          return false;
        int num3 = num2 + bytes.Length;
        bool flag2 = false;
        while (!flag2)
        {
          int num4 = FileUtility.IndexOfBytes(numArray, bytes, num3, numArray.Length);
          if (num4 != -1)
            num3 = num4 + bytes.Length;
          else
            flag2 = true;
        }
        if (FileUtility.CreateHash(numArray, 0, num3).Equals(expectedHash))
          flag1 = true;
      }
      catch (FileNotFoundException ex)
      {
        int num = (int) MessageBox.Show(ex.ToString());
      }
      return flag1;
    }

    private static int IndexOfBytes(byte[] array, byte[] pattern, int startIndex, int count)
    {
      if (array == null || array.Length == 0 || pattern == null || pattern.Length == 0 || count == 0)
        return -1;
      int index1 = startIndex;
      int num1 = count > 0 ? Math.Min(startIndex + count, array.Length) : array.Length;
      int index2 = 0;
      int num2 = 0;
      for (; index1 < num1; ++index1)
      {
        int num3 = index2;
        int num4;
        if ((int) array[index1] != (int) pattern[index2])
        {
          num4 = 0;
        }
        else
        {
          int num5 = num4 = index2 + 1;
        }
        index2 = num4;
        if (index2 == pattern.Length)
          return index1 - index2 + 1;
        if (num3 > 0 && index2 == 0)
        {
          index1 -= num3;
          num2 = 0;
        }
      }
      return -1;
    }
  }
}
