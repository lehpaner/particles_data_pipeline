﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ISO146441_1999_ReportConfigurationCCOPC
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ISO146441_1999_ReportConfigurationCCOPC : ISO146441_1999_ReportConfiguration
  {
    private static ISO146441_1999_ReportConfigurationCCOPC instance = new ISO146441_1999_ReportConfigurationCCOPC();

    private ISO146441_1999_ReportConfigurationCCOPC()
    {
      this.classLevelStrings = new string[8]
      {
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9"
      };
      this.standardConcentrationLimits = new Decimal[8][]
      {
        new Decimal[6]{ 100M, 24M, 10M, 4M, -1M, -1M },
        new Decimal[6]{ 1000M, 237M, 102M, 35M, 8M, -1M },
        new Decimal[6]{ 10000M, 2370M, 1020M, 352M, 83M, -1M },
        new Decimal[6]{ 100000M, 23700M, 10200M, 3520M, 832M, 29M },
        new Decimal[6]
        {
          1000000M,
          237000M,
          102000M,
          35200M,
          8320M,
          293M
        },
        new Decimal[6]{ -1M, -1M, -1M, 352000M, 83200M, 2930M },
        new Decimal[6]{ -1M, -1M, -1M, 3520000M, 832000M, 29300M },
        new Decimal[6]
        {
          -1M,
          -1M,
          -1M,
          35200000M,
          8320000M,
          293000M
        }
      };
      this.minimumRequiredParticleSizeIndexesForClass = new int[8]
      {
        0,
        0,
        0,
        0,
        0,
        3,
        3,
        3
      };
      this.maximumRequiredParticleSizeIndexesForClass = new int[8]
      {
        3,
        4,
        4,
        5,
        5,
        5,
        5,
        5
      };
      this.minimumRequiredParticleSizesForClass = new Decimal[8]
      {
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.5M,
        0.5M,
        0.5M
      };
      this.maximumRequiredParticleSizesForClass = new Decimal[8]
      {
        0.5M,
        1.0M,
        1.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M
      };
    }

    public static ISO146441_1999_ReportConfigurationCCOPC Copy
    {
      get
      {
        ISO146441_1999_ReportConfigurationCCOPC copy = new ISO146441_1999_ReportConfigurationCCOPC();
        copy.AirFlowIndex = ISO146441_1999_ReportConfigurationCCOPC.instance.AirFlowIndex;
        copy.RoomArea = ISO146441_1999_ReportConfigurationCCOPC.instance.RoomArea;
        copy.RoomStatusIndex = ISO146441_1999_ReportConfigurationCCOPC.instance.RoomStatusIndex;
        copy.ClassLevelIndex = ISO146441_1999_ReportConfigurationCCOPC.instance.ClassLevelIndex;
        copy.CutPointsSizesMicrometersSpecified = ISO146441_1999_ReportConfigurationCCOPC.instance.cutPointsSizesMicrometersSpecified;
        return copy;
      }
    }

    public static ISO146441_1999_ReportConfiguration Instance
    {
      get => (ISO146441_1999_ReportConfiguration) ISO146441_1999_ReportConfigurationCCOPC.instance;
    }
  }
}
