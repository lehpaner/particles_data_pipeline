﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.UIManager
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using TrakProLiteClassLibrary.Properties;
using TSI;
using TSI.Communication;
using TSI.Data;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class UIManager
  {
    private TreeView treeView;

    public UIManager(TreeView treeView) => this.treeView = treeView;

    public DeviceType GetDeviceTypeFromNode(TreeNode node)
    {
      TreeNode treeNode = node;
      if (treeNode == null)
        return DeviceType.Unknown;
      while (treeNode.Parent != null)
        treeNode = treeNode.Parent;
      return this.GetDeviceType(treeNode.Tag);
    }

    public IInstrument GetSelectedDevice(TreeNode node)
    {
      TreeNode treeNode = node;
      if (treeNode == null)
        return (IInstrument) null;
      while (treeNode.Parent != null)
        treeNode = treeNode.Parent;
      return (IInstrument) treeNode.Tag;
    }

    public DeviceType GetDeviceType(object obj)
    {
      DeviceType deviceType = DeviceType.Unknown;
      if (obj != null)
      {
        if (obj.GetType() == typeof (Storage_9303))
          deviceType = DeviceType.Tsi9303;
        else if (obj.GetType() == typeof (ModbusMap2Device))
          deviceType = DeviceType.ModbusMap2;
      }
      return deviceType;
    }

    public TreeNode GetDeviceNode(TreeNode selectedNode)
    {
      TreeNode deviceNode = (TreeNode) null;
      if (selectedNode != null)
      {
        deviceNode = selectedNode;
        while (deviceNode.Parent != null)
          deviceNode = deviceNode.Parent;
      }
      return deviceNode;
    }

    public TreeNode CreateDeviceNode(
      TreeView tv,
      string deviceName,
      ConnectionType connType,
      bool isDIMode,
      bool isDIUserLoggedIn,
      ushort diUserId)
    {
      TreeNode[] treeNodeArray = tv.Nodes.Find(deviceName, true);
      TreeNode node = (TreeNode) null;
      if (treeNodeArray.Length == 0)
      {
        string str = deviceName;
        node = new TreeNode(deviceName);
        if (isDIMode && isDIUserLoggedIn)
          str = string.Format("{0} [User Id:{1}]", (object) deviceName, (object) diUserId);
        node.Name = deviceName;
        node.Text = str;
        int num = !isDIMode ? (connType == ConnectionType.Ethernet ? 17 : 13) : (isDIUserLoggedIn ? 19 : 18);
        node.SelectedImageIndex = node.ImageIndex = num;
        if (tv.InvokeRequired)
          tv.Invoke((Delegate) (() => tv.Nodes.Add(node)));
        else
          tv.Nodes.Add(node);
      }
      return node;
    }

    public TreeNode GetDeviceNode(TreeView tv, string deviceName, bool create)
    {
      TreeNode[] treeNodeArray = tv.Nodes.Find(deviceName, true);
      TreeNode node = (TreeNode) null;
      if (treeNodeArray.Length == 0)
      {
        if (create)
        {
          node = new TreeNode(deviceName);
          node.Name = node.Text = deviceName;
          node.SelectedImageIndex = node.ImageIndex = 17;
          if (tv.InvokeRequired)
            tv.Invoke((Delegate) (() => tv.Nodes.Add(node)));
          else
            tv.Nodes.Add(node);
        }
      }
      else
        node = treeNodeArray[0];
      return node;
    }

    public TreeNode GetSampleDataNode(TreeView tv, IInstrument device, bool createNode)
    {
      TreeNode deviceNode = this.GetDeviceNode(tv, device.Name, false);
      return deviceNode == null ? (TreeNode) null : this.GetSampleDataNode(tv, deviceNode, createNode);
    }

    public TreeNode GetSampleDataNode(TreeView tv, TreeNode deviceNode, bool createNode)
    {
      TreeNode[] treeNodeArray = deviceNode.Nodes.Find("Sample Data", true);
      TreeNode sampleDataNode = (TreeNode) null;
      if (treeNodeArray.Length == 0)
      {
        if (createNode)
        {
          sampleDataNode = new TreeNode();
          sampleDataNode.Name = sampleDataNode.Text = "Sample Data";
          sampleDataNode.ImageIndex = 3;
          sampleDataNode.SelectedImageIndex = 4;
          sampleDataNode.Tag = (object) NodeType.SampleData;
          if (tv.InvokeRequired)
            tv.BeginInvoke((Delegate) (() => deviceNode.Nodes.Add(sampleDataNode)));
          else
            deviceNode.Nodes.Add(sampleDataNode);
        }
      }
      else
        sampleDataNode = treeNodeArray[0];
      return sampleDataNode;
    }

    public TreeNode GetRecipeNode(TreeNode deviceNode, string recipeName)
    {
      if (deviceNode == null || deviceNode.Nodes == null)
        return (TreeNode) null;
      TreeNode[] treeNodeArray = deviceNode.Nodes.Find(recipeName, true);
      return treeNodeArray.Length > 0 ? treeNodeArray[0] : (TreeNode) null;
    }

    public TreeNode GetRecipesNode(TreeView tv, TreeNode deviceNode, bool createNode)
    {
      TreeNode[] treeNodeArray = deviceNode.Nodes.Find("Recipes", true);
      TreeNode recipeNode = (TreeNode) null;
      if (treeNodeArray.Length == 0)
      {
        if (createNode)
        {
          recipeNode = new TreeNode();
          recipeNode.Name = recipeNode.Text = "Recipes";
          recipeNode.ImageIndex = 6;
          recipeNode.SelectedImageIndex = 6;
          recipeNode.Tag = (object) NodeType.RecipeParent;
          if (tv.InvokeRequired)
            tv.BeginInvoke((Delegate) (() => deviceNode.Nodes.Add(recipeNode)));
          else
            deviceNode.Nodes.Add(recipeNode);
        }
      }
      else
        recipeNode = treeNodeArray[0];
      return recipeNode;
    }

    public TreeNode GetZoneNode(TreeNode deviceNode, string name)
    {
      TreeNode sampleDataNode = this.GetSampleDataNode(this.treeView, deviceNode, false);
      if (sampleDataNode == null)
        return (TreeNode) null;
      TreeNode zoneNode = (TreeNode) null;
      TreeNode[] treeNodeArray = sampleDataNode.Nodes.Find(name, true);
      if (treeNodeArray.Length > 0)
        zoneNode = treeNodeArray[0];
      return zoneNode;
    }

    public TreeNode GetZoneNode(
      IInstrument device,
      TreeNode sampleDataNode,
      int zoneId,
      bool createNode)
    {
      TreeNode zNode = (TreeNode) null;
      if (sampleDataNode == null)
        return (TreeNode) null;
      string str = zoneId < 0 ? Resources.records : device.Zones[zoneId].Name;
      TreeNode[] treeNodeArray = sampleDataNode.Nodes.Find(str, true);
      if (treeNodeArray.Length == 0)
      {
        if (createNode)
        {
          int num = device.HasZones ? 12 : 4;
          zNode = new TreeNode(str, num, num);
          zNode.Name = zNode.Text;
          zNode.Tag = (object) NodeType.Zone;
          if (this.treeView.InvokeRequired)
            this.treeView.BeginInvoke((Delegate) (() => sampleDataNode.Nodes.Add(zNode)));
          else
            sampleDataNode.Nodes.Add(zNode);
        }
      }
      else
        zNode = treeNodeArray[0];
      return zNode;
    }

    public TreeNode GetLocationNode(
      IInstrument device,
      TreeNode sampleDataNode,
      int locationId,
      string locationName,
      bool createNode)
    {
      int locationId1 = locationId;
      if (!device.HasZones)
      {
        int num = device.Locations.Find(locationName, -1);
        if (num >= 0)
        {
          locationId1 = num;
        }
        else
        {
          if (!createNode)
            return (TreeNode) null;
          locationId1 = device.Locations.AddNew(locationName, -1);
        }
      }
      return this.GetLocationNode(device, sampleDataNode, locationId1, createNode);
    }

    public TreeNode GetLocationNode(
      IInstrument device,
      TreeNode sampleDataNode,
      int locationId,
      bool createNode)
    {
      if (locationId < 0 || locationId >= device.Locations.Count)
        return (TreeNode) null;
      TreeNode locationNode = (TreeNode) null;
      TreeNode zNode = this.GetZoneNode(device, sampleDataNode, device.Locations[locationId].ZoneId, true);
      string name = device.Locations[locationId].Name;
      TreeNode[] treeNodeArray = zNode.Nodes.Find(name, true);
      if (treeNodeArray.Length == 0)
      {
        if (createNode)
        {
          locationNode = new TreeNode(name, 7, 7);
          locationNode.Name = locationNode.Text;
          locationNode.Tag = (object) NodeType.Location;
          if (this.treeView.InvokeRequired)
            this.treeView.BeginInvoke((Delegate) (() => zNode.Nodes.Add(locationNode)));
          else
            zNode.Nodes.Add(locationNode);
        }
      }
      else
        locationNode = treeNodeArray[0];
      return locationNode;
    }

    public void AddChildRecordNodesToDeviceNode(
      TreeNode deviceNode,
      Storage_9303 device,
      Preferences preferences)
    {
      TreeNode sampleDataNode = this.GetSampleDataNode(this.treeView, deviceNode, true);
      TreeNode[] treeNodeArray = sampleDataNode.Nodes.Find(Resources.records, true);
      TreeNode node1;
      if (treeNodeArray.Length != 0)
      {
        node1 = treeNodeArray[0];
      }
      else
      {
        node1 = new TreeNode()
        {
          Tag = (object) NodeType.Zone,
          ImageIndex = 3,
          SelectedImageIndex = 4
        };
        node1.Name = node1.Text = Resources.records;
        sampleDataNode.Nodes.Add(node1);
      }
      foreach (Record_9303 record9303 in device.data)
      {
        string location = record9303.Location;
        TreeNode node2;
        if (node1.Nodes.Find(location, true).Length == 0)
        {
          node2 = new TreeNode();
          node2.Name = node2.Text = location;
          node2.Tag = (object) NodeType.Location;
          node2.ImageIndex = node2.SelectedImageIndex = 7;
          node1.Nodes.Add(node2);
          int count = device.Locations.Count;
          device.Locations.Add((ILocation) new Location9303(count, location));
          device.Locations[count].Locked = true;
          record9303.LocationId = count;
        }
        else
        {
          node2 = node1.Nodes.Find(location, true)[0];
          int num = device.Locations.Find(location, -1);
          record9303.LocationId = num;
        }
        string text = record9303.DateTime.ToString();
        TreeNode node3 = new TreeNode(text);
        node3.Name = text;
        node3.ImageIndex = 8;
        node3.SelectedImageIndex = 9;
        record9303.CountMode = preferences.CountMode;
        record9303.UnitType = preferences.Units;
        record9303.VolumeUnits = preferences.Volume;
        node3.Tag = (object) record9303;
        node2.Nodes.Add(node3);
      }
      node1.Expand();
    }

    public void AddChildRecordNodesToDeviceNode(
      TreeNode deviceNode,
      ModbusMap2Device device,
      Preferences preferences)
    {
      TreeNode sampleDataNode = this.GetSampleDataNode(this.treeView, deviceNode, true);
      foreach (ModbusMap2Record record in device.records)
      {
        TreeNode locNode = this.GetLocationNode((IInstrument) device, sampleDataNode, record.LocationId, record.Location, true);
        if (locNode.Nodes.Find(record.dateTime.ToString("dd/MM/yyyy HH:mm:ss"), true).Length == 0)
        {
          int imageIndex = record.InstrumentStatus == (ushort) 0 ? 8 : 15;
          int selectedImageIndex = record.InstrumentStatus == (ushort) 0 ? 9 : 15;
          TreeNode recordNode = new TreeNode(record.dateTime.ToString("dd/MM/yyyy HH:mm:ss"), imageIndex, selectedImageIndex);
          recordNode.Name = recordNode.Text;
          record.CountMode = preferences.CountMode;
          record.unitMode = preferences.Units;
          record.volumeType = preferences.Volume;
          record.tempType = preferences.Temperature;
          recordNode.Tag = (object) record;
          if (this.treeView.InvokeRequired)
            this.treeView.BeginInvoke((Delegate) (() => locNode.Nodes.Add(recordNode)));
          else
            locNode.Nodes.Add(recordNode);
        }
      }
    }

    public TreeNode AddRecipeNode(TreeNode recipesNode, IRecipe recipe, int recipeLabelLength)
    {
      if (recipe == null)
        return (TreeNode) null;
      if (!recipe.IsValid)
        return (TreeNode) null;
      TreeNode node = new TreeNode();
      string key = recipe.Name;
      int num = 1;
      string str;
      int length;
      for (; recipesNode.Nodes.ContainsKey(key); key = string.Format("{0}{1}", (object) recipe.Name.Substring(0, length), (object) str))
      {
        str = string.Format("({0})", (object) num++);
        length = Math.Min(recipeLabelLength - str.Length, recipe.Name.Length);
      }
      recipe.Name = key;
      node.Name = node.Text = recipe.Name;
      node.ImageIndex = node.SelectedImageIndex = 6;
      node.Tag = (object) NodeType.Recipe;
      if (this.treeView.InvokeRequired)
        this.treeView.Invoke((Delegate) (() => recipesNode.Nodes.Add(node)));
      else
        recipesNode.Nodes.Add(node);
      return node;
    }

    public void AddRecipeNodes(TreeNode recipesNode, List<IRecipe> recipes, int recipeLabelLength)
    {
      if (recipes == null || recipes.Count == 0)
        return;
      foreach (ModbusMap2Recipe recipe in recipes)
        this.AddRecipeNode(recipesNode, (IRecipe) recipe, recipeLabelLength);
    }

    public TreeNode UpdateRecipeNode(
      TreeNode devicenode,
      TreeNode recipeNode,
      IRecipe recipe,
      int recipeLabelLength)
    {
      TreeNode treeNode = (TreeNode) null;
      if (recipeNode != null)
      {
        recipeNode.Name = recipe.Name;
        recipeNode.Text = recipe.Name;
        recipeNode.Tag = (object) NodeType.Recipe;
        treeNode = recipeNode;
      }
      else
      {
        TreeNode recipesNode = this.GetRecipesNode(this.treeView, devicenode, true);
        if (recipesNode != null)
          treeNode = this.AddRecipeNode(recipesNode, recipe, recipeLabelLength);
      }
      return treeNode;
    }

    public TreeNode AddZoneAndLocationNodes(
      TreeNode deviceNode,
      IZone zoneConfig,
      List<ILocation> locations)
    {
      TreeNode sampleDataNode = this.GetSampleDataNode(this.treeView, deviceNode, true);
      TreeNode zNode = new TreeNode(zoneConfig.Name, 4, 4);
      zNode.Name = zNode.Text;
      zNode.Tag = (object) NodeType.Zone;
      if (this.treeView.InvokeRequired)
        this.treeView.Invoke((Delegate) (() => sampleDataNode.Nodes.Add(zNode)));
      else
        sampleDataNode.Nodes.Add(zNode);
      this.AddLocationNodes(zNode, locations);
      return zNode;
    }

    public void AddLocationNodes(TreeNode zoneNode, List<ILocation> locations)
    {
      foreach (ILocation location in locations)
      {
        TreeNode node = new TreeNode(location.Name, 7, 7);
        node.Name = node.Text;
        node.Tag = (object) NodeType.Location;
        if (this.treeView.InvokeRequired)
          this.treeView.Invoke((Delegate) (() => zoneNode.Nodes.Add(node)));
        else
          zoneNode.Nodes.Add(node);
      }
    }

    public TreeNode UpdateZoneAndLocationNodes(
      TreeNode deviceNode,
      TreeNode zoneNode,
      IZone zone,
      List<ILocation> locations)
    {
      this.treeView.BeginUpdate();
      TreeNode treeNode;
      if (zoneNode != null)
      {
        zoneNode.Name = zone.Name;
        zoneNode.Text = zone.Name;
        for (int index1 = zoneNode.Nodes.Count - 1; index1 >= 0; --index1)
        {
          TreeNode locNode = zoneNode.Nodes[index1];
          if (locNode.GetNodeCount(true) > 0)
          {
            int index2 = locations.FindIndex((Predicate<ILocation>) (loc => loc.Name == locNode.Text));
            if (index2 >= 0)
              locations.RemoveAt(index2);
          }
          else
            zoneNode.Nodes.RemoveAt(index1);
        }
        this.AddLocationNodes(zoneNode, locations);
        treeNode = zoneNode;
      }
      else
        treeNode = this.AddZoneAndLocationNodes(deviceNode, zone, locations);
      this.treeView.EndUpdate();
      return treeNode;
    }

    public void CreateZoneAndLocationNodes(TreeNode deviceNode)
    {
      TreeNode sampleDataNode = this.GetSampleDataNode(this.treeView, deviceNode, true);
      TreeNode recordsNode = (TreeNode) null;
      IInstrument tag = (IInstrument) deviceNode.Tag;
      List<IZone> zones = (List<IZone>) tag.Zones;
      LocationList locations = tag.Locations;
      if (tag.HasZones)
      {
        foreach (IZone zone in zones)
        {
          if (zone.IsValid && sampleDataNode.Nodes.Find(zone.Name, true).Length == 0)
          {
            TreeNode zNode = new TreeNode(zone.Name, 12, 12);
            zNode.Name = zNode.Text;
            zNode.Tag = (object) NodeType.Zone;
            if (this.treeView.InvokeRequired)
              this.treeView.Invoke((Delegate) (() => sampleDataNode.Nodes.Add(zNode)));
            else
              sampleDataNode.Nodes.Add(zNode);
          }
        }
        if (this.treeView.InvokeRequired)
        {
          this.treeView.Invoke((Delegate) (() =>
          {
            deviceNode.Expand();
            sampleDataNode.Expand();
          }));
        }
        else
        {
          deviceNode.Expand();
          sampleDataNode.Expand();
        }
      }
      else
      {
        TreeNode[] treeNodeArray = sampleDataNode.Nodes.Find("Records", true);
        if (treeNodeArray.Length == 1)
        {
          recordsNode = treeNodeArray[0];
        }
        else
        {
          recordsNode = new TreeNode("Records", 4, 4);
          recordsNode.Name = recordsNode.Text;
          recordsNode.Tag = (object) NodeType.Zone;
          if (this.treeView.InvokeRequired)
          {
            this.treeView.Invoke((Delegate) (() =>
            {
              sampleDataNode.Nodes.Add(recordsNode);
              deviceNode.Expand();
              sampleDataNode.Expand();
            }));
          }
          else
          {
            sampleDataNode.Nodes.Add(recordsNode);
            deviceNode.Expand();
            sampleDataNode.Expand();
          }
        }
      }
      TreeNode parentNode = recordsNode;
      for (int index = 0; index < locations.Count; ++index)
      {
        if (locations[index].IsValid)
        {
          int zoneId = locations[index].ZoneId;
          if (zoneId >= 0)
          {
            TreeNode[] treeNodeArray = sampleDataNode.Nodes.Find(zones[zoneId].Name, true);
            if (treeNodeArray.Length > 0)
              parentNode = treeNodeArray[0];
          }
          if (parentNode.Nodes.Find(locations[index].Name, true).Length == 0)
          {
            TreeNode node = new TreeNode(locations[index].Name, 7, 7);
            node.Name = node.Text;
            node.Tag = (object) NodeType.Location;
            if (this.treeView.InvokeRequired)
              this.treeView.Invoke((Delegate) (() => parentNode.Nodes.Add(node)));
            else
              parentNode.Nodes.Add(node);
          }
        }
      }
    }

    public void SetChildNodesCheckState(TreeNode parentNode, bool isChecked)
    {
      foreach (TreeNode node in parentNode.Nodes)
      {
        node.Checked = isChecked;
        if (node.Nodes.Count > 0)
          this.SetChildNodesCheckState(node, isChecked);
      }
    }
  }
}
