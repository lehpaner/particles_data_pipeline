﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.FederalStandard209EMetricReportConfiguration
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class FederalStandard209EMetricReportConfiguration : StandardsReportConfiguration
  {
    private static FederalStandard209EMetricReportConfiguration instance = new FederalStandard209EMetricReportConfiguration();

    private FederalStandard209EMetricReportConfiguration()
      : base(StandardsReportConfiguration.fedStandard209EMetric)
    {
      this.standardCutPointsMicrometres = new Decimal[5]
      {
        0.1M,
        0.2M,
        0.3M,
        0.5M,
        5.0M
      };
      this.standardConcentrationLimits = new Decimal[13][]
      {
        new Decimal[5]{ 350M, 75.7M, 30.9M, 10.0M, -1M },
        new Decimal[5]{ 1240M, 265M, 106M, 35.3M, -1M },
        new Decimal[5]{ 3500M, 757M, 309M, 100M, -1M },
        new Decimal[5]{ 12400M, 2650M, 1060M, 353M, -1M },
        new Decimal[5]{ 35000M, 7570M, 3090M, 1000M, -1M },
        new Decimal[5]{ -1M, 26500M, 10600M, 3530M, -1M },
        new Decimal[5]{ -1M, 75700M, 30900M, 10000M, -1M },
        new Decimal[5]{ -1M, -1M, -1M, 35300M, 247M },
        new Decimal[5]{ -1M, -1M, -1M, 100000M, 618M },
        new Decimal[5]{ -1M, -1M, -1M, 353000M, 2470M },
        new Decimal[5]{ -1M, -1M, -1M, 1000000M, 6180M },
        new Decimal[5]{ -1M, -1M, -1M, 3530000M, 24700M },
        new Decimal[5]{ -1M, -1M, -1M, 10000000M, 61800M }
      };
      this.minimumRequiredParticleSizeIndexesForClass = new int[13]
      {
        0,
        0,
        0,
        0,
        0,
        1,
        1,
        3,
        3,
        3,
        3,
        3,
        3
      };
      this.maximumRequiredParticleSizeIndexesForClass = new int[13]
      {
        3,
        3,
        3,
        3,
        3,
        3,
        3,
        4,
        4,
        4,
        4,
        4,
        4
      };
      this.minimumRequiredParticleSizesForClass = new Decimal[13]
      {
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.2M,
        0.2M,
        0.5M,
        0.5M,
        0.5M,
        0.5M,
        0.5M,
        0.5M
      };
      this.maximumRequiredParticleSizesForClass = new Decimal[13]
      {
        0.5M,
        0.5M,
        0.5M,
        0.5M,
        0.5M,
        0.5M,
        0.5M,
        25.0M,
        25.0M,
        25.0M,
        25.0M,
        25.0M,
        25.0M
      };
      this.roomStatusStrings = new string[3]
      {
        "AtRest",
        "Operational",
        "AsBuilt"
      };
      this.airFlowStrings = new string[2]
      {
        "Unidirectional",
        "Multidirectional"
      };
      this.roomStatusIndex = 2;
      this.classLevelStrings = new string[13]
      {
        "M1",
        "M1.5",
        "M2",
        "M2.5",
        "M3",
        "M3.5",
        "M4",
        "M4.5",
        "M5",
        "M5.5",
        "M6",
        "M6.5",
        "M7"
      };
      this.classLevelIndex = 2;
      this.metricMeasurements = true;
      this.allowsSampleExclusion = false;
      this.requiresReplacementOfExcluded = false;
      this.maxAllowedSamplesExcluded = (short) 0;
      StandardsReportConfiguration.concentrationLimitPrintFormat = "0.#";
    }

    protected override Decimal CalculateConcentrationLimitNumberOfParticlePerVolume(
      Decimal particleSize)
    {
      return particleSize > 0M ? StandardsReportConfiguration.SignificantDigits(Math.Pow(10.0, this.ClassLevel) * Math.Pow(0.5 / (double) particleSize, 2.2), 3) : 0.0M;
    }

    protected override Decimal CalculateMinimumSampleVolume(
      Decimal concentrationLimitsNumberOfParticlesPerCubicMetre)
    {
      Decimal minimumSampleVolume = 0.00283M;
      if (concentrationLimitsNumberOfParticlesPerCubicMetre <= 0M)
        return minimumSampleVolume;
      Decimal num = 20M / concentrationLimitsNumberOfParticlesPerCubicMetre;
      if (num > minimumSampleVolume)
        minimumSampleVolume = num;
      return minimumSampleVolume;
    }

    public double ClassLevel => 0.5 * (double) this.ClassLevelIndex + 1.0;

    public static FederalStandard209EMetricReportConfiguration Copy
    {
      get
      {
        FederalStandard209EMetricReportConfiguration copy = new FederalStandard209EMetricReportConfiguration();
        copy.AirFlowIndex = FederalStandard209EMetricReportConfiguration.instance.AirFlowIndex;
        copy.RoomArea = FederalStandard209EMetricReportConfiguration.instance.RoomArea;
        copy.RoomStatusIndex = FederalStandard209EMetricReportConfiguration.instance.RoomStatusIndex;
        copy.ClassLevelIndex = FederalStandard209EMetricReportConfiguration.instance.ClassLevelIndex;
        copy.CutPointsSizesMicrometersSpecified = FederalStandard209EMetricReportConfiguration.instance.cutPointsSizesMicrometersSpecified;
        return copy;
      }
    }

    public static FederalStandard209EMetricReportConfiguration Instance
    {
      get => FederalStandard209EMetricReportConfiguration.instance;
    }

    public override bool IsValidRoomStatusAndClass(int roomStatusIndex, int classLevelIndex)
    {
      return true;
    }

    public override int MinimumNumberOfSampleLocationsForAirFlowAndArea
    {
      get
      {
        int forAirFlowAndArea = 2;
        int num1 = (int) Math.Ceiling(Decimal.ToDouble(this.RoomAreaSquareMetres) * 64.0 / Math.Sqrt(Math.Pow(10.0, this.ClassLevel)));
        if (this.AirFlowIndex == 0)
        {
          int num2 = (int) Math.Ceiling(Decimal.ToDouble(this.RoomAreaSquareMetres) / 2.32);
          if (num2 < num1)
            num1 = num2;
        }
        if (num1 > forAirFlowAndArea)
          forAirFlowAndArea = num1;
        return forAirFlowAndArea;
      }
    }

    public override int MinimumNumberOfSamplesPerZoneForSamples
    {
      get
      {
        int perZoneForSamples = this.MinimumNumberOfSampleLocationsForAirFlowAndArea;
        if (perZoneForSamples < 5)
          perZoneForSamples = 5;
        return perZoneForSamples;
      }
    }

    public override int MinimumNumberOfSamplesPerLocation => 1;

    public override Decimal MinimumSampleTimePerLocationSeconds => -1M;

    public override VolumeType VolumeUnits => VolumeType.MetresCubed;

    public override bool Uses95UCL => true;

    public override bool UsesStandardError => true;
  }
}
