﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.PrintPreviewForm
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class PrintPreviewForm : Form
  {
    private IContainer components;
    private TextBox uxPrintPreview;

    public PrintPreviewForm() => this.InitializeComponent();

    public string Report
    {
      get => this.uxPrintPreview.Text;
      set => this.uxPrintPreview.Text = value;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.uxPrintPreview = new TextBox();
      this.SuspendLayout();
      this.uxPrintPreview.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.uxPrintPreview.Location = new Point(2, 12);
      this.uxPrintPreview.Multiline = true;
      this.uxPrintPreview.Name = "uxPrintPreview";
      this.uxPrintPreview.ScrollBars = ScrollBars.Vertical;
      this.uxPrintPreview.Size = new Size(278, 249);
      this.uxPrintPreview.TabIndex = 0;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(292, 273);
      this.Controls.Add((Control) this.uxPrintPreview);
      this.Name = nameof (PrintPreviewForm);
      this.Text = nameof (PrintPreviewForm);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
