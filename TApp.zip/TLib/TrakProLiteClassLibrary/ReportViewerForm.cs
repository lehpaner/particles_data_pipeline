﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ReportViewerForm
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Xml;
using TrakProLiteClassLibrary.Properties;
using TSI;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ReportViewerForm : Form
  {
    private StandardsReportFormat report;
    private UserPermissions userPermissions;
    private PageSettings pageSettings;
    private IContainer components;
    private ReportViewer standardsReportViewer;
    private BindingSource CleanroomInformationBindingSource;
    private BindingSource HeaderInformationBindingSource;
    private BindingSource InstrumentInformationBindingSource;
    private BindingSource SamplingInformationBindingSource;

    public PageSettings ReportPageSettings => this.pageSettings;

    public ReportViewerForm(UserPermissions userPerms, PageSettings settings)
    {
      this.InitializeComponent();
      this.userPermissions = userPerms;
      this.pageSettings = settings;
    }

    public StandardsReportFormat Report
    {
      set => this.report = value;
    }

    private void displayReport()
    {
      if (this.report == null)
        return;
      this.standardsReportViewer.Clear();
      this.standardsReportViewer.Reset();
      this.standardsReportViewer.ProcessingMode = ProcessingMode.Local;
      this.standardsReportViewer.LocalReport.DataSources.Clear();
      this.standardsReportViewer.LocalReport.ReportEmbeddedResource = "TrakProLiteClassLibrary.StandardCertificateReport.rdlc";
      this.standardsReportViewer.LocalReport.EnableExternalImages = true;
      ReportParameter[] parameters = new ReportParameter[7]
      {
        new ReportParameter("StandardConfigName", this.report.StandardConfigName),
        new ReportParameter("ConcentrationHeading", this.report.ConcentrationHeading),
        new ReportParameter("ReportCulture", CultureInfo.CurrentCulture.Name),
        null,
        null,
        null,
        null
      };
      string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), TSIStrings.TSI, TSIStrings.TrakProLiteSecure, TSIStrings.Settings, Settings.Default.ReportLogo);
      parameters[3] = !File.Exists(path) ? new ReportParameter("ImagePath", string.Empty) : new ReportParameter("ImagePath", "file:\\" + path);
      parameters[4] = new ReportParameter("Username", this.report.Username);
      parameters[5] = new ReportParameter("ReportTitle", this.report.ReportTitle);
      parameters[6] = new ReportParameter("ReviewerSignatureLine", this.report.ReviewerSignatureLine.ToString());
      this.standardsReportViewer.LocalReport.SetParameters((IEnumerable<ReportParameter>) parameters);
      for (int i = 0; i < this.report.Tables.Count; ++i)
        this.standardsReportViewer.LocalReport.DataSources.Add(this.GetDataTable(i));
      this.standardsReportViewer.RefreshReport();
    }

    private ReportDataSource GetDataTable(int i)
    {
      return new ReportDataSource(this.report.Tables[i].TableName, this.report.Tables[i]);
    }

    private void setReportViewerExportOptions()
    {
      foreach (RenderingExtension renderingExtension in this.standardsReportViewer.LocalReport.ListRenderingExtensions())
      {
        if (renderingExtension.Name == ReportViewerExtensions.PDF)
          renderingExtension.GetType().GetField("m_isVisible", BindingFlags.Instance | BindingFlags.NonPublic).SetValue((object) renderingExtension, (object) this.userPermissions.Allow(UserPerm.FormatPDF));
        if (renderingExtension.Name == ReportViewerExtensions.Excel)
          renderingExtension.GetType().GetField("m_isVisible", BindingFlags.Instance | BindingFlags.NonPublic).SetValue((object) renderingExtension, (object) this.userPermissions.Allow(UserPerm.FormatXLS));
        if (renderingExtension.Name == ReportViewerExtensions.Word)
          renderingExtension.GetType().GetField("m_isVisible", BindingFlags.Instance | BindingFlags.NonPublic).SetValue((object) renderingExtension, (object) this.userPermissions.Allow(UserPerm.FormatDOC));
      }
      this.standardsReportViewer.ShowExportButton = this.userPermissions.Allow(UserPerm.FormatDOC) || this.userPermissions.Allow(UserPerm.FormatPDF) || this.userPermissions.Allow(UserPerm.FormatXLS);
      this.standardsReportViewer.ShowPrintButton = this.userPermissions.Allow(UserPerm.ReportPrint);
    }

    private void ReportViewerForm_Load(object sender, EventArgs e)
    {
      this.displayReport();
      if (this.pageSettings != null)
      {
        if (this.pageSettings.Margins != (Margins) null && this.pageSettings.PaperSize != null && this.pageSettings.PaperSource != null)
          this.standardsReportViewer.SetPageSettings(this.pageSettings);
        else
          this.pageSettings = this.standardsReportViewer.GetPageSettings();
      }
      this.setReportViewerExportOptions();
    }

    private string GetStringFromTag(XmlDocument xmlDoc, string tagName)
    {
      string stringFromTag = "";
      if (xmlDoc != null)
      {
        XmlNodeList elementsByTagName = xmlDoc.GetElementsByTagName(tagName);
        if (elementsByTagName.Count > 0)
          stringFromTag = elementsByTagName[0].InnerText;
      }
      return stringFromTag;
    }

    private int GetInt32FromTag(XmlDocument xmlDoc, string tagName)
    {
      string str = "";
      int int32FromTag = 0;
      if (xmlDoc != null)
      {
        XmlNodeList elementsByTagName = xmlDoc.GetElementsByTagName(tagName);
        if (elementsByTagName.Count > 0)
          str = elementsByTagName[0].InnerText;
        try
        {
          if (!string.IsNullOrEmpty(str))
            int32FromTag = Convert.ToInt32(str);
        }
        catch (Exception ex)
        {
        }
      }
      return int32FromTag;
    }

    private void standardsReportViewer_PageSettingsChanged(object sender, EventArgs e)
    {
      this.pageSettings = this.standardsReportViewer.GetPageSettings();
    }

    private void standardsReportViewer_Print(object sender, ReportPrintEventArgs e)
    {
      this.standardsReportViewer.GetPageSettings();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new System.ComponentModel.Container();
      ReportDataSource reportDataSource1 = new ReportDataSource();
      ReportDataSource reportDataSource2 = new ReportDataSource();
      ReportDataSource reportDataSource3 = new ReportDataSource();
      ReportDataSource reportDataSource4 = new ReportDataSource();
      this.CleanroomInformationBindingSource = new BindingSource(this.components);
      this.HeaderInformationBindingSource = new BindingSource(this.components);
      this.InstrumentInformationBindingSource = new BindingSource(this.components);
      this.SamplingInformationBindingSource = new BindingSource(this.components);
      this.standardsReportViewer = new ReportViewer();
      ((ISupportInitialize) this.CleanroomInformationBindingSource).BeginInit();
      ((ISupportInitialize) this.HeaderInformationBindingSource).BeginInit();
      ((ISupportInitialize) this.InstrumentInformationBindingSource).BeginInit();
      ((ISupportInitialize) this.SamplingInformationBindingSource).BeginInit();
      this.SuspendLayout();
      this.CleanroomInformationBindingSource.DataSource = (object) typeof (CleanroomInformation);
      this.HeaderInformationBindingSource.DataSource = (object) typeof (HeaderInformation);
      this.InstrumentInformationBindingSource.DataSource = (object) typeof (InstrumentInformation);
      this.SamplingInformationBindingSource.DataSource = (object) typeof (SamplingInformation);
      this.standardsReportViewer.Dock = DockStyle.Fill;
      reportDataSource1.Name = "CleanroomInformation";
      reportDataSource1.Value = (object) this.CleanroomInformationBindingSource;
      reportDataSource2.Name = "HeaderInformation";
      reportDataSource2.Value = (object) this.HeaderInformationBindingSource;
      reportDataSource3.Name = "InstrumentInformation";
      reportDataSource3.Value = (object) this.InstrumentInformationBindingSource;
      reportDataSource4.Name = "SamplingInformation";
      reportDataSource4.Value = (object) this.SamplingInformationBindingSource;
      this.standardsReportViewer.LocalReport.DataSources.Add(reportDataSource1);
      this.standardsReportViewer.LocalReport.DataSources.Add(reportDataSource2);
      this.standardsReportViewer.LocalReport.DataSources.Add(reportDataSource3);
      this.standardsReportViewer.LocalReport.DataSources.Add(reportDataSource4);
      this.standardsReportViewer.LocalReport.ReportEmbeddedResource = "TrakProLiteClassLibrary.StandardCertificateReport.rdlc";
      this.standardsReportViewer.Location = new Point(0, 0);
      this.standardsReportViewer.Name = "standardsReportViewer";
      this.standardsReportViewer.Size = new Size(907, 616);
      this.standardsReportViewer.TabIndex = 0;
      this.standardsReportViewer.Print += new ReportPrintEventHandler(this.standardsReportViewer_Print);
      this.standardsReportViewer.PageSettingsChanged += new EventHandler(this.standardsReportViewer_PageSettingsChanged);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(907, 616);
      this.Controls.Add((Control) this.standardsReportViewer);
      this.Name = nameof (ReportViewerForm);
      this.Text = nameof (ReportViewerForm);
      this.Load += new EventHandler(this.ReportViewerForm_Load);
      ((ISupportInitialize) this.CleanroomInformationBindingSource).EndInit();
      ((ISupportInitialize) this.HeaderInformationBindingSource).EndInit();
      ((ISupportInitialize) this.InstrumentInformationBindingSource).EndInit();
      ((ISupportInitialize) this.SamplingInformationBindingSource).EndInit();
      this.ResumeLayout(false);
    }
  }
}
