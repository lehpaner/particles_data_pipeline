﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.StatisticsWholePopulation
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class StatisticsWholePopulation : Statistics
  {
    private Decimal sumOfTheSquares;

    public override Decimal RMS
    {
      get
      {
        return this.Count == 0 ? -1M : (Decimal) Math.Sqrt(Decimal.ToDouble(this.sumOfTheSquares / (Decimal) this.Count));
      }
    }

    public override Decimal StandardDeviation
    {
      get
      {
        return this.Count == 0 ? -1M : (Decimal) Math.Sqrt(Decimal.ToDouble(this.sumOfTheSquares / (Decimal) this.Count - this.Mean * this.Mean));
      }
    }

    public Decimal SumOfTheSquares => this.sumOfTheSquares;

    public override Decimal UCL95(Decimal uclFactor)
    {
      return this.Mean + uclFactor * (this.StandardDeviation / (Decimal) Math.Sqrt((double) this.Count));
    }

    public override void Accumulate(Decimal value)
    {
      base.Accumulate(value);
      this.sumOfTheSquares += value * value;
    }

    public override void Zero()
    {
      base.Zero();
      this.sumOfTheSquares = 0.0M;
    }
  }
}
