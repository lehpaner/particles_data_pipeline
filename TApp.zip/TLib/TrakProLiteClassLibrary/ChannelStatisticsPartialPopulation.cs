﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ChannelStatisticsPartialPopulation
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ChannelStatisticsPartialPopulation : StatisticsPartialPopulation
  {
    private Decimal cutPointSizeMicrometres;

    public ChannelStatisticsPartialPopulation() => this.cutPointSizeMicrometres = 0.0M;

    public ChannelStatisticsPartialPopulation(Decimal cutPointSizeMicrometres)
    {
      this.cutPointSizeMicrometres = cutPointSizeMicrometres;
    }

    public virtual Decimal CutPointSizeMicrometres
    {
      get => this.cutPointSizeMicrometres;
      set => this.cutPointSizeMicrometres = value;
    }
  }
}
