﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ISO146441_2015_ReportConfigurationCCOPC
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ISO146441_2015_ReportConfigurationCCOPC : ISO146441_2015_ReportConfiguration
  {
    private static ISO146441_2015_ReportConfigurationCCOPC instance = new ISO146441_2015_ReportConfigurationCCOPC();

    private ISO146441_2015_ReportConfigurationCCOPC()
    {
      this.classLevelStrings = new string[15]
      {
        "2",
        "2.5",
        "3",
        "3.5",
        "4",
        "4.5",
        "5",
        "5.5",
        "6",
        "6.5",
        "7",
        "7.5",
        "8",
        "8.5",
        "9"
      };
      this.standardConcentrationLimits = new Decimal[15][]
      {
        new Decimal[6]{ 100M, 24M, 10M, -1M, -1M, -1M },
        new Decimal[6]{ 316M, 75M, 32M, -1M, -1M, -1M },
        new Decimal[6]{ 1000M, 237M, 102M, 35M, -1M, -1M },
        new Decimal[6]{ 3160M, 748M, 322M, 111M, -1M, -1M },
        new Decimal[6]{ 10000M, 2370M, 1020M, 352M, 83M, -1M },
        new Decimal[6]{ 31600M, 7480M, 3220M, 1110M, 263M, -1M },
        new Decimal[6]{ 100000M, 23700M, 10200M, 3520M, 832M, -1M },
        new Decimal[6]
        {
          316000M,
          74800M,
          32200M,
          11100M,
          2630M,
          -1M
        },
        new Decimal[6]
        {
          1000000M,
          237000M,
          102000M,
          35200M,
          8320M,
          293M
        },
        new Decimal[6]
        {
          3160000M,
          748000M,
          322000M,
          111000M,
          26300M,
          925M
        },
        new Decimal[6]{ -1M, -1M, -1M, 352000M, 83200M, 2930M },
        new Decimal[6]{ -1M, -1M, -1M, 1110000M, 263000M, 9250M },
        new Decimal[6]{ -1M, -1M, -1M, 3520000M, 832000M, 29300M },
        new Decimal[6]{ -1M, -1M, -1M, 11100000M, 2630000M, 92500M },
        new Decimal[6]
        {
          -1M,
          -1M,
          -1M,
          35200000M,
          8320000M,
          293000M
        }
      };
      this.minimumRequiredParticleSizeIndexesForClass = new int[15]
      {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        3,
        3,
        3,
        3,
        3
      };
      this.maximumRequiredParticleSizeIndexesForClass = new int[15]
      {
        2,
        2,
        3,
        3,
        4,
        4,
        4,
        4,
        5,
        5,
        5,
        5,
        5,
        5,
        5
      };
      this.minimumRequiredParticleSizesForClass = new Decimal[15]
      {
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.5M,
        0.5M,
        0.5M,
        0.5M,
        0.5M
      };
      this.maximumRequiredParticleSizesForClass = new Decimal[15]
      {
        0.3M,
        0.3M,
        0.5M,
        0.5M,
        1.0M,
        1.0M,
        1.0M,
        1.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M
      };
    }

    public static ISO146441_2015_ReportConfigurationCCOPC Copy
    {
      get
      {
        ISO146441_2015_ReportConfigurationCCOPC copy = new ISO146441_2015_ReportConfigurationCCOPC();
        copy.AirFlowIndex = ISO146441_2015_ReportConfigurationCCOPC.instance.AirFlowIndex;
        copy.RoomArea = ISO146441_2015_ReportConfigurationCCOPC.instance.RoomArea;
        copy.RoomStatusIndex = ISO146441_2015_ReportConfigurationCCOPC.instance.RoomStatusIndex;
        copy.ClassLevelIndex = ISO146441_2015_ReportConfigurationCCOPC.instance.ClassLevelIndex;
        copy.CutPointsSizesMicrometersSpecified = ISO146441_2015_ReportConfigurationCCOPC.instance.cutPointsSizesMicrometersSpecified;
        return copy;
      }
    }

    public static ISO146441_2015_ReportConfiguration Instance
    {
      get => (ISO146441_2015_ReportConfiguration) ISO146441_2015_ReportConfigurationCCOPC.instance;
    }
  }
}
