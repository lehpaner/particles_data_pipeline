﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ISO146441_2015_ReportConfiguration
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ISO146441_2015_ReportConfiguration : StandardsReportConfiguration
  {
    protected ISO146441_2015_ReportConfiguration()
      : base("ISO 14644-1:2015")
    {
      this.standardCutPointsMicrometres = new Decimal[6]
      {
        0.1M,
        0.2M,
        0.3M,
        0.5M,
        1.0M,
        5.0M
      };
      this.minimumRequiredSampleTimeForStandard = new TimeSpan(0, 1, 0);
      this.roomStatusStrings = new string[3]
      {
        "AtRest",
        "Operational",
        "AsBuilt"
      };
      this.airFlowStrings = new string[2]
      {
        "Unidirectional",
        "Non-unidirectional"
      };
      this.metricMeasurements = true;
      this.roomAreaSquareMetres = 9M;
      this.classLevelIndex = 1;
      this.roomStatusIndex = 1;
      this.allowsSampleExclusion = true;
      this.requiresReplacementOfExcluded = true;
      this.maxAllowedSamplesExcluded = (short) 5;
    }

    protected override Decimal CalculateConcentrationLimitNumberOfParticlePerVolume(
      Decimal particleSize)
    {
      return particleSize > 0M ? StandardsReportConfiguration.SignificantDigits(Math.Pow(10.0, this.ClassLevel) * Math.Pow(0.1 / (double) particleSize, 2.08), 3) : 0.0M;
    }

    protected override Decimal CalculateMinimumSampleVolume(
      Decimal concentrationLimitsNumberOfParticlesPerCubicMetre)
    {
      Decimal minimumSampleVolume = 2.0M;
      if (concentrationLimitsNumberOfParticlesPerCubicMetre <= 0M)
        return minimumSampleVolume;
      Decimal num = 20M / concentrationLimitsNumberOfParticlesPerCubicMetre * 1000M;
      if (num > minimumSampleVolume)
        minimumSampleVolume = num;
      return minimumSampleVolume;
    }

    public double ClassLevel => (double) (this.ClassLevelIndex + 2);

    public override bool IsMinimumSampleTimeRequired => true;

    public override bool IsValidRoomStatusAndClass(int roomStatusIndex, int classLevelIndex)
    {
      return true;
    }

    public override int MinimumNumberOfSampleLocationsForAirFlowAndArea
    {
      get
      {
        if (this.roomAreaSquareMetres <= 2M)
          return 1;
        if (this.roomAreaSquareMetres <= 4M)
          return 2;
        if (this.roomAreaSquareMetres <= 6M)
          return 3;
        if (this.roomAreaSquareMetres <= 8M)
          return 4;
        if (this.roomAreaSquareMetres <= 10M)
          return 5;
        if (this.roomAreaSquareMetres <= 24M)
          return 6;
        if (this.roomAreaSquareMetres <= 28M)
          return 7;
        if (this.roomAreaSquareMetres <= 32M)
          return 8;
        if (this.roomAreaSquareMetres <= 36M)
          return 9;
        if (this.roomAreaSquareMetres <= 52M)
          return 10;
        if (this.roomAreaSquareMetres <= 56M)
          return 11;
        if (this.roomAreaSquareMetres <= 64M)
          return 12;
        if (this.roomAreaSquareMetres <= 68M)
          return 13;
        if (this.roomAreaSquareMetres <= 72M)
          return 14;
        if (this.roomAreaSquareMetres <= 76M)
          return 15;
        if (this.roomAreaSquareMetres <= 104M)
          return 16;
        if (this.roomAreaSquareMetres <= 108M)
          return 17;
        if (this.roomAreaSquareMetres <= 116M)
          return 18;
        if (this.roomAreaSquareMetres <= 148M)
          return 19;
        if (this.roomAreaSquareMetres <= 156M)
          return 20;
        if (this.roomAreaSquareMetres <= 192M)
          return 21;
        if (this.roomAreaSquareMetres <= 232M)
          return 22;
        if (this.roomAreaSquareMetres <= 276M)
          return 23;
        if (this.roomAreaSquareMetres <= 352M)
          return 24;
        if (this.roomAreaSquareMetres <= 436M)
          return 25;
        if (this.roomAreaSquareMetres <= 636M)
          return 26;
        return this.roomAreaSquareMetres <= 1000M ? 27 : Convert.ToInt32(Math.Ceiling(27M * (this.roomAreaSquareMetres / 1000M)));
      }
    }

    public override int MinimumNumberOfSamplesPerZoneForSamples
    {
      get => this.MinimumNumberOfSampleLocationsForAirFlowAndArea;
    }

    public override int MinimumNumberOfSamplesPerLocation
    {
      get
      {
        int forAirFlowAndArea = this.MinimumNumberOfSampleLocationsForAirFlowAndArea;
        return 1;
      }
    }

    public override Decimal MinimumSampleTimePerLocationSeconds => 60.0M;

    public override bool Uses95UCL => false;

    public override bool UsesStandardError => true;

    public override VolumeType VolumeUnits => VolumeType.Litres;
  }
}
