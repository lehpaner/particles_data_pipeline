﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.TextFormatService
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Text;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class TextFormatService : ReportFormatService
  {
    private static TextFormatService instance = new TextFormatService();
    private static string separator = "------------------------";
    public static string eoln = "\r\n";

    public static TextFormatService Instance => TextFormatService.instance;

    public string FormatStandardsReport(
      StandardsReportConfiguration reportConfiguration,
      IInstrument deviceInformation)
    {
      StringBuilder report = new StringBuilder();
      report.Append(string.Format("Standards Report Name: {0}", (object) reportConfiguration.ConfigurationName));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Instrument: Model: {0}, Serial {1}", (object) deviceInformation.ModelNumber, (object) deviceInformation.SerialNumber));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Standards Target Class: {0}", (object) reportConfiguration.ClassLevelText));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Room Area: {0} {1}", (object) reportConfiguration.RoomArea, (object) reportConfiguration.RoomAreaUnitsText));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Room Status: {0}", (object) reportConfiguration.RoomStatusText));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Airflow: {0}", (object) reportConfiguration.AirFlowText));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Current Time: {0}", (object) DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")));
      report.Append(TextFormatService.eoln);
      Decimal[] micrometersSpecified = reportConfiguration.CutPointsSizesMicrometersSpecified;
      Decimal minValue = Decimal.MinValue;
      if (reportConfiguration.StandardsChannelStatistics != null)
      {
        this.PrintStandardsSampleResult(report, reportConfiguration.IsMinimumSampleTimeRequired, reportConfiguration.MinimumRequiredSampleTimeForStandard, reportConfiguration.MinimumSampleTime);
        for (int sizeIndexesForClass = reportConfiguration.MinimumRequiredParticleSizeIndexesForClass; sizeIndexesForClass <= reportConfiguration.MaximumRequiredParticleSizeIndexesForClass; ++sizeIndexesForClass)
        {
          if (Array.IndexOf<Decimal>(micrometersSpecified, reportConfiguration.StandardsChannelStatistics[sizeIndexesForClass].CutPointSizeMicrometres) > -1)
            this.PrintStandardsChannelStatistics(report, reportConfiguration.MetricMeasurements, reportConfiguration.MinimumNumberOfSampleLocationsForAirFlowAndArea, reportConfiguration.MinimumNumberOfSamplesPerZoneForSamples, reportConfiguration.MinimumSampleVolumesPerLocationForClass[sizeIndexesForClass], reportConfiguration.VolumeUnits, reportConfiguration.ConcentrationLimitsNumberOfParticlesPerVolumeForCurrentChannelSizesAndClassLevel[sizeIndexesForClass], reportConfiguration.Uses95UCL, reportConfiguration.UsesStandardError, reportConfiguration.StandardsChannelStatistics[sizeIndexesForClass]);
          if (minValue < reportConfiguration.MinimumSampleVolumesPerLocationForClass[sizeIndexesForClass])
            minValue = reportConfiguration.MinimumSampleVolumesPerLocationForClass[sizeIndexesForClass];
        }
      }
      report.Append(string.Format("meetsStandardsSampleAndVolumeRequirements = {0}", (object) this.meetsStandardsSampleAndVolumeRequirements));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("meetsStandardsConcentrationRequirements = {0}", (object) this.meetsStandardsConcentrationRequirements));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("meetsStandardsUCLChannelConcentrationLimitRequirements = {0}", (object) this.meetsStandardsUCLChannelConcentrationLimitRequirements));
      report.Append(TextFormatService.eoln);
      return report.ToString();
    }

    protected void PrintStandardsSampleResult(
      StringBuilder report,
      bool isMinSampleTimeRequired,
      TimeSpan minRequiredSampleTimeForStandard,
      TimeSpan minSampleTime)
    {
      if (!isMinSampleTimeRequired)
        return;
      bool flag = minRequiredSampleTimeForStandard <= minSampleTime;
      report.Append(string.Format("MinimumSampleTimeEvaluation: Required = {0}", (object) minRequiredSampleTimeForStandard.ToString()));
      report.Append(string.Format("Actual = {0}", (object) minSampleTime.ToString()));
      report.Append(string.Format("Meets Min Sample Time Requirements: {0}", (object) flag));
    }

    protected void PrintStandardsChannelStatistics(
      StringBuilder report,
      bool metric,
      int minLocationsForAirFlowAndArea,
      int minSamplesPerZoneForSamples,
      Decimal minSampleVolumeRequired,
      VolumeType volumeUnits,
      Decimal concentrationLimit,
      bool uses95UCL,
      bool usesStandardErr,
      StandardsChannelStatistics standardsChannelStatistics)
    {
      if (standardsChannelStatistics.Count <= 0)
        return;
      report.Append(string.Format("Particle Size: {0}", (object) standardsChannelStatistics.CutPointSizeMicrometres));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("{0}: P/{1}", (object) ReportStrings.Cumulative, metric ? (object) ReportStrings.M3 : (object) ReportStrings.FT3));
      report.Append(TextFormatService.eoln);
      report.Append(TextFormatService.eoln);
      this.PrintStandardsLocationStatistics(report, standardsChannelStatistics.StandardsLocationStatistics);
      bool meetsStandardsConcentrationRequirements = this.MeetsStandardsChannelConcentrationLimitRequirements(concentrationLimit, standardsChannelStatistics.StandardsLocationStatistics);
      if (!meetsStandardsConcentrationRequirements)
        this.meetsStandardsConcentrationRequirements = false;
      bool meetsStandardsUCLChannelConcentrationLimitRequirements = true;
      if (uses95UCL && standardsChannelStatistics.Count > 1 && standardsChannelStatistics.Count < 10)
        meetsStandardsConcentrationRequirements = this.MeetsStandardsUCLChannelConcentrationLimitRequirements(concentrationLimit, standardsChannelStatistics);
      if (!meetsStandardsConcentrationRequirements)
        this.meetsStandardsUCLChannelConcentrationLimitRequirements = false;
      this.PrintConcentrationEvaluation(report, metric, concentrationLimit, uses95UCL, usesStandardErr, standardsChannelStatistics, meetsStandardsConcentrationRequirements, meetsStandardsUCLChannelConcentrationLimitRequirements);
      bool meetsStandardsSampleRequirements = this.MeetsStandardsLocationRequirements(minLocationsForAirFlowAndArea, standardsChannelStatistics);
      this.PrintLocationEvaluation(report, minLocationsForAirFlowAndArea, standardsChannelStatistics, meetsStandardsSampleRequirements);
      bool meetsLocalStandardsSamplesPerZoneRequirements = this.MeetsStandardsSamplesPerZoneRequirements(minSamplesPerZoneForSamples, standardsChannelStatistics.SamplesPerZone);
      this.PrintSamplesPerZoneEvaluation(report, minSamplesPerZoneForSamples, standardsChannelStatistics, meetsLocalStandardsSamplesPerZoneRequirements);
      Decimal num = volumeUnits != VolumeType.FeetCubed ? minSampleVolumeRequired : minSampleVolumeRequired;
      Decimal minimumVolume = standardsChannelStatistics.MinimumVolume;
      bool meetsStandardsVolumeRequirements = this.MeetsStandardsVolumeRequirements(num, minimumVolume);
      this.PrintVolumeEvaluation(report, num, minimumVolume, volumeUnits, meetsStandardsVolumeRequirements);
      if (meetsStandardsSampleRequirements && meetsLocalStandardsSamplesPerZoneRequirements && meetsStandardsVolumeRequirements)
        return;
      this.meetsStandardsSampleAndVolumeRequirements = false;
    }

    protected void PrintStandardsLocationStatistics(
      StringBuilder report,
      List<StandardsLocationStatistics> standardsLocationStatistics)
    {
      report.Append("Location Sample");
      report.Append(TextFormatService.eoln);
      foreach (StandardsLocationStatistics locationStatistic in standardsLocationStatistics)
        this.PrintLocationStatistics(report, locationStatistic);
    }

    protected void PrintLocationStatistics(
      StringBuilder report,
      StandardsLocationStatistics locationStatistics)
    {
      if (locationStatistics.Location.Length > 8)
      {
        report.Append(string.Format(ReportFormatService.locationSamplesAverageConcentrationFormat1, (object) locationStatistics.Location.Substring(0, 8), (object) locationStatistics.Count.ToString(), (object) locationStatistics.Mean.ToString(ReportFormatService.statisticsFormat)));
        report.Append(TextFormatService.eoln);
        report.Append(string.Format(ReportFormatService.locationSamplesAverageConcentrationFormat2, (object) locationStatistics.Location.Substring(8)));
      }
      else
        report.Append(string.Format(ReportFormatService.locationSamplesAverageConcentrationFormat1, (object) locationStatistics.Location, (object) locationStatistics.Count.ToString(), (object) locationStatistics.Mean.ToString(ReportFormatService.statisticsFormat)));
      report.Append(TextFormatService.eoln);
    }

    protected void PrintConcentrationEvaluation(
      StringBuilder report,
      bool metric,
      Decimal concentrationLimit,
      bool uses95UCL,
      bool usesStandardError,
      StandardsChannelStatistics standardsChannelStatistics,
      bool meetsStandardsConcentrationRequirements,
      bool meetsStandardsUCLChannelConcentrationLimitRequirements)
    {
      report.Append(TextFormatService.eoln);
      if (metric)
        report.Append("ConcentrationEvaluationParticlesPerMetersCubed");
      else
        report.Append("ConcentrationEvaluationParticlesPerFeetCubed");
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("ConcLimit: {0}", concentrationLimit < 0M ? (object) "NotApplicable" : (object) concentrationLimit.ToString(ReportFormatService.concentrationFormat)));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("MaximumAbbreviation: {0}", (object) standardsChannelStatistics.Maximum.ToString(ReportFormatService.standardsStatisticsFormat)));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Mean: {0}", (object) standardsChannelStatistics.Mean.ToString(ReportFormatService.standardsStatisticsFormat)));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("StdDev: {0}", standardsChannelStatistics.StandardDeviation < 0M ? (object) "NotApplicable" : (object) standardsChannelStatistics.StandardDeviation.ToString(ReportFormatService.standardsStatisticsFormat)));
      report.Append(TextFormatService.eoln);
      if (usesStandardError)
      {
        report.Append(string.Format("StdError: {0}", standardsChannelStatistics.RMS < 0M ? (object) "NotApplicable" : (object) standardsChannelStatistics.RMS.ToString(ReportFormatService.standardsStatisticsFormat)));
        report.Append(TextFormatService.eoln);
      }
      if (uses95UCL && standardsChannelStatistics.Count > 1 && standardsChannelStatistics.Count < 10)
      {
        report.Append(string.Format("UCL95: {0}", (object) standardsChannelStatistics.UpperConfidenceLevel95.ToString(ReportFormatService.standardsStatisticsFormat)));
        report.Append(TextFormatService.eoln);
      }
      report.Append(string.Format("PassFail: {0}", !meetsStandardsConcentrationRequirements || !meetsStandardsUCLChannelConcentrationLimitRequirements ? (object) "Fail" : (object) "Pass"));
      report.Append(TextFormatService.eoln);
    }

    protected void PrintLocationEvaluation(
      StringBuilder report,
      int minLocationsForAirFlowAndArea,
      StandardsChannelStatistics standardsChannelStatistics,
      bool meetsStandardsSampleRequirements)
    {
      report.Append(TextFormatService.eoln);
      report.Append("LocationEvaluation");
      report.Append(TextFormatService.eoln);
      report.Append("Required").Append(minLocationsForAirFlowAndArea);
      report.Append(TextFormatService.eoln);
      report.Append("Actual").Append(standardsChannelStatistics.StandardsLocationStatistics.Count);
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("PassInvalid: {0}", meetsStandardsSampleRequirements ? (object) "Pass" : (object) "Fail"));
      report.Append(TextFormatService.eoln);
    }

    protected void PrintSamplesPerZoneEvaluation(
      StringBuilder report,
      int minimumNumberOfSamplesPerZoneForSamples,
      StandardsChannelStatistics standardsChannelStatistics,
      bool meetsLocalStandardsSamplesPerZoneRequirements)
    {
      report.Append(TextFormatService.eoln);
      report.Append("SamplesPerZoneEvaluation");
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Required: {0}", (object) minimumNumberOfSamplesPerZoneForSamples.ToString()));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Actual: {0}", (object) standardsChannelStatistics.SamplesPerZone.ToString()));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("PassInvalid: {0}", meetsLocalStandardsSamplesPerZoneRequirements ? (object) "Pass" : (object) "Fail"));
      report.Append(TextFormatService.eoln);
    }

    protected void PrintVolumeEvaluation(
      StringBuilder report,
      Decimal unitVolumeRequired,
      Decimal minimumUnitVolumeSampled,
      VolumeType volumeUnits,
      bool meetsStandardsVolumeRequirements)
    {
      report.Append(TextFormatService.eoln);
      report.Append("VolumeEvaluation");
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Required: {0} {1}", (object) unitVolumeRequired.ToString(ReportFormatService.volumeFormat), (object) volumeUnits.ToString()));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("Actual: {0} {1}", (object) minimumUnitVolumeSampled.ToString(ReportFormatService.volumeFormat), (object) volumeUnits.ToString()));
      report.Append(TextFormatService.eoln);
      report.Append(string.Format("PassInvalid: {0}", meetsStandardsVolumeRequirements ? (object) "Pass" : (object) "Fail"));
      report.Append(TextFormatService.eoln);
    }

    protected void PrintSeparator(StringBuilder report)
    {
      report.Append(TextFormatService.separator);
      report.Append(TextFormatService.eoln);
    }
  }
}
