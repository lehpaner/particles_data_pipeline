﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.Sample
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using TSI;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class Sample : ISample
  {
    private uint sampleID;
    private string zone;
    private string location;
    private int locationId;
    private TimeSpan sampleTime;
    private DateTime timeStamp;
    private FlowStatus flowStatus;
    private float precisionFlowRate;
    private ChannelCollection channels;
    private ChannelCollection viableChannels;
    private Decimal temperature;
    private TemperatureType temperatureUnits;
    private Decimal volumeLitres;
    private Decimal humidity;
    private UnitCode humidityUnits;
    private Decimal airVelocity;
    private UnitCode airVelocityUnits;
    private ushort deviceStatus;
    private ushort instrumentStatus;
    private bool laserStatus;
    private double averageFlowRateLitresPerMinute;
    private double averageFlowRateCubicMetresPerSecond;
    private bool normalized;
    private RecordType countMode;
    private ushort viableDetectionSensitivity;
    private ushort diUserId;
    private string diUsername = string.Empty;

    public Sample(
      uint sampleID,
      ChannelCollection channels,
      ChannelCollection viableChannels,
      string zone,
      string location,
      int locationId,
      TimeSpan sampleTime,
      DateTime timeStamp,
      FlowStatus flowStatus,
      float precisionFlowRate,
      Decimal temperature,
      TemperatureType temperatureUnits,
      Decimal volume,
      VolumeType volumeUnits,
      Decimal humidity,
      UnitCode humidityUnits,
      Decimal airVelocity,
      UnitCode airVelocityUnits,
      double averageFlowRateCubicMetresPerSecond,
      ushort deviceStatus,
      ushort instrumentStatus,
      bool laserStatus,
      bool normalized,
      RecordType countMode,
      ushort viableSensitivity,
      ushort diUserId,
      string diUsername)
    {
      this.sampleID = sampleID;
      this.locationId = locationId;
      this.channels = channels;
      this.zone = zone;
      this.location = location;
      this.sampleTime = sampleTime;
      this.timeStamp = timeStamp;
      this.flowStatus = flowStatus;
      this.precisionFlowRate = precisionFlowRate;
      this.temperature = temperature;
      this.temperatureUnits = temperatureUnits;
      this.SetVolume(volume, volumeUnits);
      this.humidity = humidity;
      this.humidityUnits = humidityUnits;
      this.airVelocity = airVelocity;
      this.airVelocityUnits = airVelocityUnits;
      this.averageFlowRateLitresPerMinute = averageFlowRateCubicMetresPerSecond * 60.0 / 0.001;
      this.averageFlowRateCubicMetresPerSecond = averageFlowRateCubicMetresPerSecond;
      this.deviceStatus = deviceStatus;
      this.instrumentStatus = instrumentStatus;
      this.laserStatus = laserStatus;
      this.normalized = normalized;
      this.countMode = countMode;
      this.viableChannels = viableChannels;
      this.viableDetectionSensitivity = viableSensitivity;
      this.diUserId = diUserId;
      this.diUsername = diUsername;
    }

    private void SetVolume(Decimal volume, VolumeType volumeUnits)
    {
      this.volumeLitres = Sample.ConvertVolumeLitres(volume, volumeUnits);
    }

    public static Decimal ConvertVolumeLitres(Decimal inputVolume, VolumeType inputVolumeUnits)
    {
      Decimal num;
      switch (inputVolumeUnits)
      {
        case VolumeType.FeetCubed:
          num = inputVolume * 28.3M;
          break;
        case VolumeType.MetresCubed:
          num = inputVolume * 1000.0M;
          break;
        default:
          num = inputVolume;
          break;
      }
      return num;
    }

    public static Decimal ConvertLitresVolume(
      Decimal inputVolumeLitres,
      VolumeType outputVolumeUnits)
    {
      Decimal num;
      switch (outputVolumeUnits)
      {
        case VolumeType.FeetCubed:
          num = inputVolumeLitres / 28.3M;
          break;
        case VolumeType.MetresCubed:
          num = inputVolumeLitres * 0.001M;
          break;
        case VolumeType.Litres:
          num = inputVolumeLitres;
          break;
        default:
          num = inputVolumeLitres * 1000.0M;
          break;
      }
      return num;
    }

    public static Decimal ConvertTemperature(
      Decimal temperature,
      TemperatureType inputTempType,
      TemperatureType outputTempType)
    {
      Decimal num = 0M;
      switch (inputTempType)
      {
        case TemperatureType.F:
          num = outputTempType == TemperatureType.C ? (temperature - 32M) * 5M / 9M : temperature;
          break;
        case TemperatureType.C:
          num = outputTempType == TemperatureType.F ? 1.8M * temperature + 32M : temperature;
          break;
      }
      return num;
    }

    public static Decimal ConvertVelocity(
      Decimal velocity,
      UnitCode inputVelocityUnits,
      UnitCode outputVelocityUnits)
    {
      Decimal num1 = 3.2808399M;
      Decimal num2;
      switch (inputVelocityUnits)
      {
        case UnitCode.ft_min:
          num2 = velocity / 60M;
          if (outputVelocityUnits == UnitCode.m_sec)
          {
            num2 /= num1;
            break;
          }
          break;
        case UnitCode.m_sec:
          num2 = outputVelocityUnits == UnitCode.ft_sec ? velocity * num1 : velocity;
          break;
        case UnitCode.ft_sec:
          num2 = outputVelocityUnits == UnitCode.m_sec ? velocity / num1 : velocity;
          break;
        default:
          num2 = velocity;
          break;
      }
      return num2;
    }

    public bool Normalized => this.normalized;

    public RecordType CountMode => this.countMode;

    public uint SampleID
    {
      get => this.sampleID;
      set => this.sampleID = value;
    }

    public string Location
    {
      get => this.location;
      set => this.location = value;
    }

    public int LocationId => this.locationId;

    public string Zone
    {
      get => this.zone;
      set => this.zone = value;
    }

    public ChannelCollection Channels => this.channels;

    public ChannelCollection ViableChannels => this.viableChannels;

    public bool AlarmActive
    {
      get
      {
        if (this.channels != null)
        {
          foreach (IChannel channel in (List<IChannel>) this.channels)
          {
            if (channel.AlarmActive)
              return true;
          }
        }
        return false;
      }
    }

    public TimeSpan SampleTime => this.sampleTime;

    public DateTime TimeStamp => this.timeStamp;

    public Decimal Temperature => this.temperature;

    public TemperatureType TemperatureUnits => this.temperatureUnits;

    public Decimal Humidity => this.humidity;

    public UnitCode HumidityUnits => this.humidityUnits;

    public FlowStatus FlowStatus => this.flowStatus;

    public float PrecisionFlowRate => this.precisionFlowRate;

    public double AverageFlowRateCubicMetresPerSecond => this.averageFlowRateCubicMetresPerSecond;

    public ushort DeviceStatus => this.deviceStatus;

    public ushort InstrumentStatus => this.instrumentStatus;

    public bool LaserStatus => this.laserStatus;

    public Decimal AirVelocity => this.airVelocity;

    public UnitCode AirVelocityUnits => this.airVelocityUnits;

    public Decimal VolumeLitres => this.volumeLitres;

    public VolumeType VolumeUnits => VolumeType.Litres;

    public static Decimal Normalize(
      Decimal particleCount,
      VolumeType normalizedParticleVolume,
      Decimal volumeLitres)
    {
      float num;
      switch (normalizedParticleVolume)
      {
        case VolumeType.FeetCubed:
          num = 28.3f;
          break;
        case VolumeType.MetresCubed:
          num = 1000f;
          break;
        default:
          num = 1f;
          break;
      }
      return !(volumeLitres != 0M) ? 0M : (Decimal) (num * (float) particleCount / (float) volumeLitres);
    }

    public Decimal GetParticleCount(
      IChannel channel,
      bool normalized,
      VolumeType normalizedParticleVolume)
    {
      Decimal particleCount = Convert.ToDecimal(channel.ParticleCount);
      return normalized ? Sample.Normalize(particleCount, normalizedParticleVolume, this.VolumeLitres) : particleCount;
    }

    public ushort ViableDetectionSensitivity
    {
      get => this.viableDetectionSensitivity;
      set => this.viableDetectionSensitivity = value;
    }

    public ushort DIUserId
    {
      get => this.diUserId;
      set => this.diUserId = value;
    }

    public string DIUsername
    {
      get => this.diUsername;
      set => this.diUsername = value;
    }
  }
}
