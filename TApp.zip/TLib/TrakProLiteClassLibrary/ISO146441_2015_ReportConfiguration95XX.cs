﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ISO146441_2015_ReportConfiguration95XX
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ISO146441_2015_ReportConfiguration95XX : ISO146441_2015_ReportConfiguration
  {
    private static ISO146441_2015_ReportConfiguration95XX instance = new ISO146441_2015_ReportConfiguration95XX();

    private ISO146441_2015_ReportConfiguration95XX()
    {
      this.classLevelStrings = new string[13]
      {
        "3",
        "3.5",
        "4",
        "4.5",
        "5",
        "5.5",
        "6",
        "6.5",
        "7",
        "7.5",
        "8",
        "8.5",
        "9"
      };
      this.standardConcentrationLimits = new Decimal[13][]
      {
        new Decimal[6]{ 1000M, 237M, 102M, 35M, -1M, -1M },
        new Decimal[6]{ 3160M, 748M, 322M, 111M, -1M, -1M },
        new Decimal[6]{ 10000M, 2370M, 1020M, 352M, 83M, -1M },
        new Decimal[6]{ 31600M, 7480M, 3220M, 1110M, 263M, -1M },
        new Decimal[6]{ 100000M, 23700M, 10200M, 3520M, 832M, -1M },
        new Decimal[6]
        {
          316000M,
          74800M,
          32200M,
          11100M,
          2630M,
          -1M
        },
        new Decimal[6]
        {
          1000000M,
          237000M,
          102000M,
          35200M,
          8320M,
          293M
        },
        new Decimal[6]
        {
          3160000M,
          748000M,
          322000M,
          111000M,
          26300M,
          925M
        },
        new Decimal[6]{ -1M, -1M, -1M, 352000M, 83200M, 2930M },
        new Decimal[6]{ -1M, -1M, -1M, 1110000M, 263000M, 9250M },
        new Decimal[6]{ -1M, -1M, -1M, 3520000M, 832000M, 29300M },
        new Decimal[6]{ -1M, -1M, -1M, 11100000M, 2630000M, 92500M },
        new Decimal[6]
        {
          -1M,
          -1M,
          -1M,
          35200000M,
          8320000M,
          293000M
        }
      };
      this.minimumRequiredParticleSizeIndexesForClass = new int[13]
      {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        3,
        3,
        3,
        3,
        3
      };
      this.maximumRequiredParticleSizeIndexesForClass = new int[13]
      {
        3,
        3,
        4,
        4,
        4,
        4,
        5,
        5,
        5,
        5,
        5,
        5,
        5
      };
      this.minimumRequiredParticleSizesForClass = new Decimal[13]
      {
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.1M,
        0.5M,
        0.5M,
        0.5M,
        0.5M,
        0.5M
      };
      this.maximumRequiredParticleSizesForClass = new Decimal[13]
      {
        0.5M,
        0.5M,
        1.0M,
        1.0M,
        1.0M,
        1.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M,
        5.0M
      };
    }

    public static ISO146441_2015_ReportConfiguration95XX Copy
    {
      get
      {
        ISO146441_2015_ReportConfiguration95XX copy = new ISO146441_2015_ReportConfiguration95XX();
        copy.AirFlowIndex = ISO146441_2015_ReportConfiguration95XX.instance.AirFlowIndex;
        copy.RoomArea = ISO146441_2015_ReportConfiguration95XX.instance.RoomArea;
        copy.RoomStatusIndex = ISO146441_2015_ReportConfiguration95XX.instance.RoomStatusIndex;
        copy.ClassLevelIndex = ISO146441_2015_ReportConfiguration95XX.instance.ClassLevelIndex;
        copy.CutPointsSizesMicrometersSpecified = ISO146441_2015_ReportConfiguration95XX.instance.cutPointsSizesMicrometersSpecified;
        return copy;
      }
    }

    public static ISO146441_2015_ReportConfiguration Instance
    {
      get => (ISO146441_2015_ReportConfiguration) ISO146441_2015_ReportConfiguration95XX.instance;
    }
  }
}
