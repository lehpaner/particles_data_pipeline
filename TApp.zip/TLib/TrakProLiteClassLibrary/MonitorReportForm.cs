﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MonitorReportForm
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using TrakProLiteClassLibrary.Properties;
using TSI;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MonitorReportForm : Form
  {
    private UserPermissions userPermissions;
    private MonitorReportFormat report;
    private PageSettings pageSettings;
    private IContainer components;
    private ReportViewer monitorReportViewer;

    public MonitorReportForm(UserPermissions userPerms, PageSettings settings)
    {
      this.InitializeComponent();
      this.userPermissions = userPerms;
      this.pageSettings = settings;
    }

    public MonitorReportFormat Report
    {
      set => this.report = value;
    }

    public PageSettings ReportPageSettings => this.pageSettings;

    private ReportDataSource getDataTable(int i)
    {
      return new ReportDataSource(this.report.Tables[i].TableName, this.report.Tables[i]);
    }

    private void MonitorReportForm_Load(object sender, EventArgs e)
    {
      this.displayReport();
      if (this.pageSettings != null)
      {
        if (this.pageSettings.Margins != (Margins) null && this.pageSettings.PaperSize != null && this.pageSettings.PaperSource != null)
          this.monitorReportViewer.SetPageSettings(this.pageSettings);
        else
          this.pageSettings = this.monitorReportViewer.GetPageSettings();
      }
      this.setReportViewerExportOptions();
    }

    private void displayReport()
    {
      if (this.report == null)
        return;
      this.monitorReportViewer.Clear();
      this.monitorReportViewer.Reset();
      this.monitorReportViewer.ProcessingMode = ProcessingMode.Local;
      this.monitorReportViewer.LocalReport.DataSources.Clear();
      this.monitorReportViewer.LocalReport.ReportEmbeddedResource = "TrakProLiteClassLibrary.MonitorReport.rdlc";
      this.monitorReportViewer.LocalReport.EnableExternalImages = true;
      ReportParameter[] parameters = new ReportParameter[7]
      {
        new ReportParameter("ReportTitle", this.report.ReportTitle),
        new ReportParameter("Username", this.report.Username),
        new ReportParameter("ConcHeading", this.report.ConcHeading),
        null,
        null,
        null,
        null
      };
      string str1 = string.Format("Results Table ({0}, {1})", (object) this.report.CountMode, (object) this.report.Units);
      parameters[3] = new ReportParameter("ResultsHeading", str1);
      string str2 = string.Format("Results Summary ({0}, {1})", (object) this.report.CountMode, (object) this.report.Units);
      parameters[4] = new ReportParameter("ResultsSummaryHeading", str2);
      parameters[5] = new ReportParameter("ReviewerSignatureLine", this.report.ReviewerSignatureLine.ToString());
      string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), TSIStrings.TSI, TSIStrings.TrakProLiteSecure, TSIStrings.Settings, Settings.Default.ReportLogo);
      parameters[6] = !File.Exists(path) ? new ReportParameter("ImagePath", string.Empty) : new ReportParameter("ImagePath", "file:\\" + path);
      this.monitorReportViewer.LocalReport.SetParameters((IEnumerable<ReportParameter>) parameters);
      for (int i = 0; i < this.report.Tables.Count; ++i)
        this.monitorReportViewer.LocalReport.DataSources.Add(this.getDataTable(i));
      this.monitorReportViewer.RefreshReport();
    }

    private void setReportViewerExportOptions()
    {
      foreach (RenderingExtension renderingExtension in this.monitorReportViewer.LocalReport.ListRenderingExtensions())
      {
        if (renderingExtension.Name == ReportViewerExtensions.PDF)
          renderingExtension.GetType().GetField("m_isVisible", BindingFlags.Instance | BindingFlags.NonPublic).SetValue((object) renderingExtension, (object) this.userPermissions.Allow(UserPerm.FormatPDF));
        if (renderingExtension.Name == ReportViewerExtensions.Excel)
          renderingExtension.GetType().GetField("m_isVisible", BindingFlags.Instance | BindingFlags.NonPublic).SetValue((object) renderingExtension, (object) this.userPermissions.Allow(UserPerm.FormatXLS));
        if (renderingExtension.Name == ReportViewerExtensions.Word)
          renderingExtension.GetType().GetField("m_isVisible", BindingFlags.Instance | BindingFlags.NonPublic).SetValue((object) renderingExtension, (object) this.userPermissions.Allow(UserPerm.FormatDOC));
      }
      this.monitorReportViewer.ShowPrintButton = this.userPermissions.Allow(UserPerm.ReportPrint);
      this.monitorReportViewer.ShowExportButton = this.userPermissions.Allow(UserPerm.FormatDOC) || this.userPermissions.Allow(UserPerm.FormatPDF) || this.userPermissions.Allow(UserPerm.FormatXLS);
    }

    private void monitorReportViewer_PageSettingsChanged(object sender, EventArgs e)
    {
      this.pageSettings = this.monitorReportViewer.GetPageSettings();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ReportDataSource reportDataSource1 = new ReportDataSource();
      ReportDataSource reportDataSource2 = new ReportDataSource();
      ReportDataSource reportDataSource3 = new ReportDataSource();
      ReportDataSource reportDataSource4 = new ReportDataSource();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (MonitorReportForm));
      this.monitorReportViewer = new ReportViewer();
      this.SuspendLayout();
      this.monitorReportViewer.Dock = DockStyle.Fill;
      reportDataSource1.Name = "CleanroomInformation";
      reportDataSource1.Value = (object) null;
      reportDataSource2.Name = "HeaderInformation";
      reportDataSource2.Value = (object) null;
      reportDataSource3.Name = "InstrumentInformation";
      reportDataSource3.Value = (object) null;
      reportDataSource4.Name = "SamplingInformation";
      reportDataSource4.Value = (object) null;
      this.monitorReportViewer.LocalReport.DataSources.Add(reportDataSource1);
      this.monitorReportViewer.LocalReport.DataSources.Add(reportDataSource2);
      this.monitorReportViewer.LocalReport.DataSources.Add(reportDataSource3);
      this.monitorReportViewer.LocalReport.DataSources.Add(reportDataSource4);
      this.monitorReportViewer.LocalReport.ReportEmbeddedResource = "TrakProLiteClassLibrary.MonitorReport.rdlc";
      this.monitorReportViewer.Location = new Point(0, 0);
      this.monitorReportViewer.Margin = new Padding(4);
      this.monitorReportViewer.Name = "monitorReportViewer";
      this.monitorReportViewer.Size = new Size(1182, 553);
      this.monitorReportViewer.TabIndex = 1;
      this.monitorReportViewer.PageSettingsChanged += new EventHandler(this.monitorReportViewer_PageSettingsChanged);
      this.AutoScaleDimensions = new SizeF(8f, 16f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1182, 553);
      this.Controls.Add((Control) this.monitorReportViewer);
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.Name = nameof (MonitorReportForm);
      this.Text = nameof (MonitorReportForm);
      this.Load += new EventHandler(this.MonitorReportForm_Load);
      this.ResumeLayout(false);
    }
  }
}
