﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MonitorReportService
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Data;
using TSI;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MonitorReportService
  {
    private static MonitorReportService instance = new MonitorReportService();

    public static MonitorReportService Instance => MonitorReportService.instance;

    public MonitorReportFormat FormatMonitorReport(MonitorReport reportData, string currentUser)
    {
      string units = reportData.Units != UnitType.Concentration ? "#" : (reportData.Volume != VolumeType.FeetCubed ? (reportData.Volume != VolumeType.MetresCubed ? string.Format("#/{0}", (object) ReportStrings.Litres) : string.Format("#/{0}", (object) ReportStrings.M3)) : string.Format("#/{0}", (object) ReportStrings.FT3));
      string countMode = string.Empty;
      if (reportData.CountMode == RecordType.Cumulative)
        countMode = ReportStrings.Cumulative;
      else if (reportData.CountMode == RecordType.Differential)
        countMode = ReportStrings.Differential;
      MonitorReportFormat report = new MonitorReportFormat(reportData.ReportTitle, units, countMode, currentUser, reportData.AddReviewerSignature);
      this.printSamplingInfo(report, reportData.ZoneName, reportData.ZoneStatus, currentUser);
      IInstrument device = reportData.Device;
      this.printParticleCounterTable(report, device.ModelNumber, device.SerialNumber, device.LastCalibrationDate);
      if (reportData.Recipe != null)
        this.printParticleCounterSettings(report, reportData.Recipe.DelayTime, reportData.Recipe.SampleTime, reportData.Recipe.HoldTime, reportData.Recipe.Cycles);
      else
        this.printParticleCounterSettings(report, reportData.SampleList[0].DelayTime, reportData.SampleList[0].SampleTime, reportData.SampleList[0].HoldTime, reportData.SampleList[0].Cycles);
      this.printComments(report, reportData.Comments);
      this.printResultsSummary(report, reportData.SummaryStats, units, device);
      this.printResultsTable(report, reportData.SampleList, reportData.SelectedSizes, reportData.Units, reportData.CountMode, reportData.Volume, device);
      return report;
    }

    private void printSamplingInfo(
      MonitorReportFormat report,
      string zoneName,
      string zoneStatus,
      string username)
    {
      report.Tables[MRSamplingInfoTable.SamplingInfoTableName].Rows.Add((object) ReportStrings.ZoneName, (object) zoneName);
      report.Tables[MRSamplingInfoTable.SamplingInfoTableName].Rows.Add((object) ReportStrings.OccupancyState, (object) zoneStatus);
      report.Tables[MRSamplingInfoTable.SamplingInfoTableName].Rows.Add((object) string.Empty, (object) string.Empty);
    }

    private void printParticleCounterTable(
      MonitorReportFormat report,
      string model,
      string serial,
      DateTime calDate)
    {
      report.Tables[MRParticleCounter.ParticleCounterTableName].Rows.Add((object) ReportStrings.Model, (object) model);
      report.Tables[MRParticleCounter.ParticleCounterTableName].Rows.Add((object) ReportStrings.SerialNum, (object) serial);
      report.Tables[MRParticleCounter.ParticleCounterTableName].Rows.Add((object) ReportStrings.LastCalibrationDate, calDate == DateTime.MinValue ? (object) ReportStrings.Unknown : (object) calDate.ToString("dd'/'MM'/'yyyy"));
    }

    private void printParticleCounterSettings(
      MonitorReportFormat report,
      TimeSpan startDelay,
      TimeSpan sampleTime,
      TimeSpan holdTime,
      uint cycles)
    {
      report.Tables[MRParticleCounterSettings.ParticleCounterSettingsTableName].Rows.Add((object) ReportStrings.StartDelay, (object) startDelay.ToString());
      report.Tables[MRParticleCounterSettings.ParticleCounterSettingsTableName].Rows.Add((object) ReportStrings.SampleTime, (object) sampleTime.ToString());
      report.Tables[MRParticleCounterSettings.ParticleCounterSettingsTableName].Rows.Add((object) ReportStrings.HoldTime, (object) holdTime.ToString());
      report.Tables[MRParticleCounterSettings.ParticleCounterSettingsTableName].Rows.Add((object) ReportStrings.Cycles, (object) cycles.ToString());
    }

    private void printComments(MonitorReportFormat report, string comments)
    {
      int length1 = comments.Length;
      int num = 4;
      string[] strArray = comments.Split('\n');
      for (int index = 0; index < strArray.Length; ++index)
      {
        report.Tables[MRComments.CommentsTableName].Rows.Add((object) strArray[index]);
        if (strArray[index].Length > 80)
          --num;
      }
      for (int length2 = strArray.Length; length2 < num - 1; ++length2)
        report.Tables[MRComments.CommentsTableName].Rows.Add((object) "  \r\n");
    }

    private void printResultsSummary(
      MonitorReportFormat report,
      List<SampleSummaryStats> stats,
      string units,
      IInstrument device)
    {
      for (int index1 = 0; index1 < stats.Count; ++index1)
      {
        DataRow row = report.Tables[MRResultsSummary.ResultsSummaryTableName].NewRow();
        int num = Math.Max(stats[index1].ActionLocations.Count, stats[index1].AlertLocations.Count);
        if (num == 0)
          num = 1;
        bool flag = false;
        for (int index2 = 0; index2 < num; ++index2)
        {
          if (flag)
          {
            row = report.Tables[MRResultsSummary.ResultsSummaryTableName].NewRow();
            row[MRResultsSummary.SizeColumnName] = (object) string.Empty;
            row[MRResultsSummary.AlertColumnName] = (object) string.Empty;
            row[MRResultsSummary.ActionColumnName] = (object) string.Empty;
            row[MRResultsSummary.MinColumnName] = (object) string.Empty;
            row[MRResultsSummary.MaxColumnName] = (object) string.Empty;
            row[MRResultsSummary.MeanColumnName] = (object) string.Empty;
          }
          else
          {
            if (device.ViableCounts)
            {
              int channel = stats[index1].Channel;
              row[MRResultsSummary.SizeColumnName] = (object) (stats[index1].Size.ToString("0.0") + "\n" + (device.IsChannelViable[channel] ? TSIStrings.channelTypeViable : TSIStrings.channelTypeTotal));
            }
            else
              row[MRResultsSummary.SizeColumnName] = (object) stats[index1].Size.ToString("0.0");
            row[MRResultsSummary.AlertColumnName] = stats[index1].Alert < 0M ? (object) ReportStrings.NotApplicable : (object) stats[index1].Alert.ToString("0");
            row[MRResultsSummary.ActionColumnName] = stats[index1].Action < 0M ? (object) ReportStrings.NotApplicable : (object) stats[index1].Action.ToString("0");
            row[MRResultsSummary.MinColumnName] = (object) stats[index1].Min.ToString("0");
            row[MRResultsSummary.MaxColumnName] = (object) stats[index1].Max.ToString("0");
            row[MRResultsSummary.MeanColumnName] = (object) stats[index1].Mean.ToString("0");
          }
          row[MRResultsSummary.LocationAlertColumnName] = index2 >= stats[index1].AlertLocations.Count ? (object) string.Empty : (object) stats[index1].AlertLocations[index2];
          row[MRResultsSummary.LocationActionColumnName] = index2 >= stats[index1].ActionLocations.Count ? (object) string.Empty : (object) stats[index1].ActionLocations[index2];
          report.Tables[MRResultsSummary.ResultsSummaryTableName].Rows.Add(row);
          flag = true;
        }
      }
    }

    private void printResultsTable(
      MonitorReportFormat report,
      IList<ReportSample> sampleList,
      List<ParticleAlerts> selectedSizes,
      UnitType units,
      RecordType countMode,
      VolumeType volType,
      IInstrument device)
    {
      for (int index1 = 0; index1 < sampleList.Count; ++index1)
      {
        DataRow row = report.Tables[MRResultsTable.ResultsTableName].NewRow();
        row[MRResultsTable.SampledByColumnName] = (object) sampleList[index1].DIUsername;
        row[MRResultsTable.LocationColumnName] = (object) sampleList[index1].Location;
        row[MRResultsTable.DateColumnName] = (object) sampleList[index1].TimeStamp;
        row[MRResultsTable.SampleTimeColName] = (object) sampleList[index1].SampleTime.ToString();
        row[MRResultsTable.VolumeColumnName] = (object) sampleList[index1].Volume.ToString("0.0");
        row[MRResultsTable.DeviceStatusColName] = (object) sampleList[index1].DeviceStatus;
        row[MRResultsTable.FlowStatusColName] = (object) sampleList[index1].FlowStatus;
        row[MRResultsTable.LaserStatusColName] = (object) sampleList[index1].LaserStatus;
        bool flag = false;
        for (int index2 = 0; index2 < selectedSizes.Count; ++index2)
        {
          string str1 = selectedSizes[index2].Size.ToString("0.0");
          if (device.ViableCounts)
          {
            int channel = selectedSizes[index2].Channel;
            str1 = str1 + "\n" + (device.IsChannelViable[channel] ? TSIStrings.channelTypeViable : TSIStrings.channelTypeTotal);
          }
          Decimal particleCount = sampleList[index1].GetParticleCount(selectedSizes[index2].Channel, countMode, units, volType);
          string recipeSampleTime = sampleList[index1].RecipeSampleTime;
          string str2 = sampleList[index1].SampleTime.ToString();
          if (flag)
          {
            row = report.Tables[MRResultsTable.ResultsTableName].NewRow();
            row[MRResultsTable.LocationColumnName] = (object) string.Empty;
            row[MRResultsTable.DateColumnName] = (object) string.Empty;
            string empty;
            row[MRResultsTable.SampleTimeColName] = (object) (empty = string.Empty);
            row[MRResultsTable.VolumeColumnName] = (object) string.Empty;
            row[MRResultsTable.DeviceStatusColName] = (object) string.Empty;
            row[MRResultsTable.FlowStatusColName] = (object) string.Empty;
            row[MRResultsTable.LaserStatusColName] = (object) string.Empty;
            row[MRResultsTable.SizeColumnName] = (object) str1;
            row[MRResultsTable.ConcColumnName] = (object) particleCount;
            row[MRResultsTable.IsActionColName] = (object) (bool) (!(particleCount >= selectedSizes[index2].ActionLevel) ? 0 : (selectedSizes[index2].ActionLevel >= 0M ? 1 : 0));
            row[MRResultsTable.IsAlertColName] = (object) (bool) (!(particleCount >= selectedSizes[index2].AlertLevel) ? 0 : (selectedSizes[index2].AlertLevel >= 0M ? 1 : 0));
            row[MRResultsTable.IsSampleCompleteColName] = (object) (bool) (recipeSampleTime == empty || empty == "" ? 1 : (recipeSampleTime == "" ? 1 : 0));
          }
          else
          {
            row[MRResultsTable.SizeColumnName] = (object) str1;
            row[MRResultsTable.ConcColumnName] = (object) particleCount;
            row[MRResultsTable.IsActionColName] = (object) (bool) (!(particleCount >= selectedSizes[index2].ActionLevel) ? 0 : (selectedSizes[index2].ActionLevel >= 0M ? 1 : 0));
            row[MRResultsTable.IsAlertColName] = (object) (bool) (!(particleCount >= selectedSizes[index2].AlertLevel) ? 0 : (selectedSizes[index2].AlertLevel >= 0M ? 1 : 0));
            row[MRResultsTable.IsSampleCompleteColName] = (object) (bool) (recipeSampleTime == str2 || str2 == "" ? 1 : (recipeSampleTime == "" ? 1 : 0));
          }
          report.Tables[MRResultsTable.ResultsTableName].Rows.Add(row);
          flag = true;
        }
      }
    }
  }
}
