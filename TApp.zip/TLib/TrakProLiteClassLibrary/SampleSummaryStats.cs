﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.SampleSummaryStats
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class SampleSummaryStats
  {
    public List<string> AlertLocations;
    public List<string> ActionLocations;

    public Decimal Size { get; set; }

    public Decimal Alert { get; set; }

    public Decimal Action { get; set; }

    public Decimal Min { get; set; }

    public Decimal Max { get; set; }

    public Decimal Mean { get; set; }

    public int Channel { get; set; }
  }
}
