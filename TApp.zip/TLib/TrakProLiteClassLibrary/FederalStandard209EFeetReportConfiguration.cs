﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.FederalStandard209EFeetReportConfiguration
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class FederalStandard209EFeetReportConfiguration : StandardsReportConfiguration
  {
    private static FederalStandard209EFeetReportConfiguration instance = new FederalStandard209EFeetReportConfiguration();

    private FederalStandard209EFeetReportConfiguration()
      : base(StandardsReportConfiguration.fedStandard209EFeet)
    {
      this.standardCutPointsMicrometres = new Decimal[5]
      {
        0.1M,
        0.2M,
        0.3M,
        0.5M,
        5.0M
      };
      this.standardConcentrationLimits = new Decimal[6][]
      {
        new Decimal[5]{ 35.0M, 7.5M, 3.00M, 1.0M, -1M },
        new Decimal[5]{ 350M, 75.0M, 30.0M, 10.0M, -1M },
        new Decimal[5]{ -1M, 750M, 300M, 100M, -1M },
        new Decimal[5]{ -1M, -1M, -1M, 1000M, 7.0M },
        new Decimal[5]{ -1M, -1M, -1M, 10000M, 70.0M },
        new Decimal[5]{ -1M, -1M, -1M, 100000M, 700M }
      };
      this.minimumRequiredParticleSizeIndexesForClass = new int[6]
      {
        0,
        0,
        1,
        3,
        3,
        3
      };
      this.maximumRequiredParticleSizeIndexesForClass = new int[6]
      {
        3,
        3,
        3,
        4,
        4,
        4
      };
      this.minimumRequiredParticleSizesForClass = new Decimal[6]
      {
        0.1M,
        0.1M,
        0.2M,
        0.5M,
        0.5M,
        0.5M
      };
      this.maximumRequiredParticleSizesForClass = new Decimal[6]
      {
        0.5M,
        0.5M,
        0.5M,
        25.0M,
        25.0M,
        25.0M
      };
      this.roomStatusStrings = new string[3]
      {
        "AtRest",
        "Operational",
        "AsBuilt"
      };
      this.airFlowStrings = new string[2]
      {
        "Unidirectional",
        "Multidirectional"
      };
      this.roomStatusIndex = 1;
      this.classLevelStrings = new string[6]
      {
        "1",
        "10",
        "100",
        "1000",
        "10000",
        "100000"
      };
      this.classLevelIndex = 2;
      this.allowsSampleExclusion = false;
      this.requiresReplacementOfExcluded = false;
      this.maxAllowedSamplesExcluded = (short) 0;
      StandardsReportConfiguration.concentrationLimitPrintFormat = "0.#";
    }

    protected override Decimal CalculateConcentrationLimitNumberOfParticlePerVolume(
      Decimal particleSize)
    {
      return particleSize > 0M ? StandardsReportConfiguration.SignificantDigits(this.ClassLevel * Math.Pow(0.5 / (double) particleSize, 2.2), 3) : 0.0M;
    }

    protected override Decimal CalculateMinimumSampleVolume(
      Decimal concentrationLimitsNumberOfParticlesPerVolume)
    {
      Decimal minimumSampleVolume = 0.1M;
      if (concentrationLimitsNumberOfParticlesPerVolume <= 0M)
        return minimumSampleVolume;
      Decimal num = 20M / concentrationLimitsNumberOfParticlesPerVolume;
      if (num > minimumSampleVolume)
        minimumSampleVolume = num;
      return minimumSampleVolume;
    }

    public double ClassLevel => Math.Pow(10.0, (double) this.ClassLevelIndex);

    public static FederalStandard209EFeetReportConfiguration Copy
    {
      get
      {
        FederalStandard209EFeetReportConfiguration copy = new FederalStandard209EFeetReportConfiguration();
        copy.AirFlowIndex = FederalStandard209EFeetReportConfiguration.instance.AirFlowIndex;
        copy.RoomArea = FederalStandard209EFeetReportConfiguration.instance.RoomArea;
        copy.RoomStatusIndex = FederalStandard209EFeetReportConfiguration.instance.RoomStatusIndex;
        copy.ClassLevelIndex = FederalStandard209EFeetReportConfiguration.instance.ClassLevelIndex;
        copy.CutPointsSizesMicrometersSpecified = FederalStandard209EFeetReportConfiguration.instance.cutPointsSizesMicrometersSpecified;
        return copy;
      }
    }

    public static FederalStandard209EFeetReportConfiguration Instance
    {
      get => FederalStandard209EFeetReportConfiguration.instance;
    }

    public override bool IsValidRoomStatusAndClass(int roomStatusIndex, int classLevelIndex)
    {
      return true;
    }

    public override int MinimumNumberOfSampleLocationsForAirFlowAndArea
    {
      get
      {
        int forAirFlowAndArea = 2;
        int num1 = (int) Math.Ceiling(Decimal.ToDouble(this.RoomAreaSquareFeet) / Math.Sqrt(this.ClassLevel));
        if (this.AirFlowIndex == 0)
        {
          int num2 = (int) Math.Ceiling(Decimal.ToDouble(this.RoomAreaSquareFeet) / 25.0);
          if (num2 < num1)
            num1 = num2;
        }
        if (num1 > forAirFlowAndArea)
          forAirFlowAndArea = num1;
        return forAirFlowAndArea;
      }
    }

    public override int MinimumNumberOfSamplesPerZoneForSamples
    {
      get
      {
        int perZoneForSamples = this.MinimumNumberOfSampleLocationsForAirFlowAndArea;
        if (perZoneForSamples < 5)
          perZoneForSamples = 5;
        return perZoneForSamples;
      }
    }

    public override int MinimumNumberOfSamplesPerLocation => 1;

    public override Decimal MinimumSampleTimePerLocationSeconds => -1M;

    public override bool Uses95UCL => true;

    public override bool UsesStandardError => true;

    public override VolumeType VolumeUnits => VolumeType.FeetCubed;
  }
}
