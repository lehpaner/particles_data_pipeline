﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ExcelXMLDataExport
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using TSI;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ExcelXMLDataExport
  {
    private IInstrument instrument;
    private ChannelCollectionStatistics cumulativeChannelCollectionStatistics = new ChannelCollectionStatistics();
    private ChannelCollectionStatistics differentialChannelCollectionStatistics = new ChannelCollectionStatistics();
    private bool normalized;
    private VolumeType normalizedParticleVolume = VolumeType.Litres;
    private UnitCode airVelocityUnits = UnitCode.m_sec;
    private TemperatureType temperatureUnits = TemperatureType.C;

    public void ExportData(
      string fileName,
      IInstrument instrument,
      List<ISample> sampleRecords,
      ZoneList selectedZones,
      LocationList selectedLocations,
      RecipeList selectedRecipes,
      Preferences preferences,
      string userName)
    {
      FileStream fileStream;
      if ((fileStream = this.CreateFileStream(fileName)) == null)
        return;
      this.instrument = instrument;
      this.normalized = preferences.Units == UnitType.Concentration;
      this.normalizedParticleVolume = preferences.Volume;
      this.temperatureUnits = preferences.Temperature;
      if (sampleRecords.Count <= 0)
        return;
      if (sampleRecords[0].AirVelocityUnits != UnitCode.NA)
      {
        this.airVelocityUnits = sampleRecords[0].AirVelocityUnits;
        if (this.airVelocityUnits == UnitCode.ft_min)
          this.airVelocityUnits = UnitCode.ft_sec;
      }
      using (XmlWriter xml = XmlWriter.Create((Stream) fileStream, new XmlWriterSettings()
      {
        Encoding = Encoding.UTF8,
        Indent = true
      }))
      {
        xml.WriteStartDocument();
        xml.WriteProcessingInstruction("mso-application", "progid='Excel.Sheet'");
        this.WriteWorkbook(xml, fileStream, sampleRecords, selectedZones, selectedLocations, selectedRecipes, userName);
        xml.WriteEndDocument();
        xml.Flush();
        xml.Close();
      }
      fileStream.Close();
      try
      {
        File.SetAttributes(fileName, FileAttributes.ReadOnly);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.Message);
      }
    }

    public bool ExportData(string fileNameBase, IInstrument instrument, ZoneList zones)
    {
      if (zones.Count == 0)
        return false;
      this.instrument = instrument;
      bool flag = true;
      for (int i = 0; i < zones.Count; ++i)
      {
        if (zones[i].IsValid)
        {
          string fileName = Path.Combine(Path.GetDirectoryName(fileNameBase), string.Format("{0}_{1}.xml", (object) Path.GetFileNameWithoutExtension(fileNameBase), (object) zones[i].Name));
          FileStream fileStream;
          if ((fileStream = this.CreateFileStream(fileName)) == null)
          {
            flag = false;
            break;
          }
          XmlWriterSettings settings = new XmlWriterSettings();
          settings.Encoding = Encoding.UTF8;
          settings.Indent = true;
          try
          {
            using (XmlWriter xml = XmlWriter.Create((Stream) fileStream, settings))
            {
              xml.WriteStartDocument();
              xml.WriteProcessingInstruction("mso-application", "progid='Excel.Sheet'");
              this.WriteWorkbookElement(xml);
              this.WriteWorkbookDocumentProperties(xml);
              this.WriteWorkbookExcelWorkbook(xml);
              this.WriteWorkbookStyles(xml);
              List<IZone> range = zones.GetRange(i, 1);
              this.WriteZoneWorksheet(xml, range);
              List<ILocation> all = instrument.Locations.FindAll((Predicate<ILocation>) (loc => loc.ZoneId == zones[i].ZoneId));
              this.WriteLocationWorksheet(xml, new LocationList((IEnumerable<ILocation>) all.ToArray()));
              int recipeId = zones[i].RecipeId;
              if (recipeId > 0)
              {
                RecipeList selectedRecipes = new RecipeList();
                selectedRecipes.Add(instrument.Recipes[recipeId]);
                this.WriteRecipeWorksheet(xml, selectedRecipes);
              }
              this.WriteMD5Hash(xml, fileStream);
              xml.WriteEndElement();
              xml.WriteEndDocument();
              xml.Flush();
              xml.Close();
            }
          }
          catch (Exception ex)
          {
            int num = (int) MessageBox.Show(string.Format("Error trying to create zone configuration file: {0}", (object) ex.ToString()), "Zone Configuration File", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            flag = false;
          }
          fileStream.Close();
        }
      }
      return flag;
    }

    public void ExportData(string fileName, IInstrument instrument, RecipeList recipes)
    {
      FileStream fileStream;
      if ((fileStream = this.CreateFileStream(fileName)) == null)
        return;
      this.instrument = instrument;
      using (XmlWriter xml = XmlWriter.Create((Stream) fileStream, new XmlWriterSettings()
      {
        Encoding = Encoding.UTF8,
        Indent = true
      }))
      {
        xml.WriteStartDocument();
        xml.WriteProcessingInstruction("mso-application", "progid='Excel.Sheet'");
        this.WriteWorkbookElement(xml);
        this.WriteWorkbookDocumentProperties(xml);
        this.WriteWorkbookExcelWorkbook(xml);
        this.WriteWorkbookStyles(xml);
        this.WriteRecipeWorksheet(xml, recipes);
        this.WriteMD5Hash(xml, fileStream);
        xml.WriteEndElement();
        xml.WriteEndDocument();
        xml.Flush();
        xml.Close();
      }
      fileStream.Close();
    }

    public void ExportData(string fileName, IInstrument instrument, LocationList locations)
    {
      FileStream fileStream;
      if ((fileStream = this.CreateFileStream(fileName)) == null)
        return;
      this.instrument = instrument;
      using (XmlWriter xml = XmlWriter.Create((Stream) fileStream, new XmlWriterSettings()
      {
        Encoding = Encoding.UTF8,
        Indent = true
      }))
      {
        xml.WriteStartDocument();
        xml.WriteProcessingInstruction("mso-application", "progid='Excel.Sheet'");
        this.WriteWorkbookElement(xml);
        this.WriteWorkbookDocumentProperties(xml);
        this.WriteWorkbookExcelWorkbook(xml);
        this.WriteWorkbookStyles(xml);
        this.WriteLocationWorksheet(xml, locations);
        this.WriteMD5Hash(xml, fileStream);
        xml.WriteEndElement();
        xml.WriteEndDocument();
        xml.Flush();
        xml.Close();
      }
      fileStream.Close();
    }

    private void WriteWorkbookElement(XmlWriter xml)
    {
      xml.WriteStartElement("Workbook", "urn:schemas-microsoft-com:office:spreadsheet");
      xml.WriteAttributeString("xmlns", "o", (string) null, "urn:schemas-microsoft-com:office:office");
      xml.WriteAttributeString("xmlns", "x", (string) null, "urn:schemas-microsoft-com:office:excel");
      xml.WriteAttributeString("xmlns", "ss", (string) null, "urn:schemas-microsoft-com:office:spreadsheet");
      xml.WriteAttributeString("xmlns", "html", (string) null, "http://www.w3.org/TR/REC-html40");
    }

    private void WriteWorkbook(
      XmlWriter xml,
      FileStream fs,
      List<ISample> sampleRecords,
      ZoneList selectedZones,
      LocationList selectedLocations,
      RecipeList selectedRecipes,
      string userName)
    {
      this.WriteWorkbookElement(xml);
      this.WriteWorkbookDocumentProperties(xml);
      this.WriteWorkbookExcelWorkbook(xml);
      this.WriteWorkbookStyles(xml);
      this.WriteDataWorksheet(xml, sampleRecords);
      if (this.instrument.HasRecipes)
        this.WriteRecipeWorksheet(xml, selectedRecipes);
      if (this.instrument.HasZones)
        this.WriteZoneWorksheet(xml, (List<IZone>) selectedZones);
      this.WriteLocationWorksheet(xml, selectedLocations);
      string name = WindowsIdentity.GetCurrent().Name;
      this.WriteUserSignature(xml, userName, name);
      this.WriteMD5Hash(xml, fs);
      xml.WriteEndElement();
    }

    private void WriteWorksheetTag(XmlWriter xml)
    {
      xml.WriteAttributeString((string) null, "Model", (string) null, this.instrument.ModelNumber);
      xml.WriteAttributeString((string) null, "Serial", (string) null, this.instrument.SerialNumber);
      xml.WriteAttributeString((string) null, "NumChannels", (string) null, this.instrument.NumberOfChannels.ToString());
      xml.WriteAttributeString((string) null, "FirmwareVersion", (string) null, this.instrument.FirmwareVersion.ToString());
      xml.WriteAttributeString((string) null, "TPLSVersion", (string) null, Application.ProductVersion);
      xml.WriteAttributeString((string) null, "CultureInfo", (string) null, "en-US");
      if (this.instrument.ViableCounts)
      {
        xml.WriteAttributeString((string) null, "AlgorithmVersion1", (string) null, ((ModbusMap2Device) this.instrument).AlgorithmId1);
        xml.WriteAttributeString((string) null, "AlgorithmVersion2", (string) null, ((ModbusMap2Device) this.instrument).AlgorithmId2);
      }
      xml.WriteAttributeString((string) null, "LastCalibration", (string) null, ExcelXMLDataExport.DateTimeToExcelString(this.instrument.LastCalibrationDate));
      xml.WriteAttributeString((string) null, "CalibrationDue", (string) null, ExcelXMLDataExport.DateTimeToExcelString(this.instrument.CalibrationDueDate));
      if (this.instrument.DeviceType == DeviceType.ModbusMap2)
      {
        xml.WriteAttributeString((string) null, "MapRev", (string) null, ((ModbusMap2Device) this.instrument).mapRevRegister.ToString());
        xml.WriteAttributeString((string) null, "DIMode", (string) null, this.instrument.IsDIMode ? "1" : "0");
        xml.WriteAttributeString((string) null, "DIUser", (string) null, this.instrument.DIUserId.ToString());
      }
      xml.WriteAttributeString((string) null, "FlowRate", (string) null, this.instrument.FlowRateLitresPerMinute.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      xml.WriteAttributeString((string) null, "VariableBins", (string) null, this.instrument.VariableBins ? "1" : "0");
      xml.WriteAttributeString((string) null, "ViableCounts", (string) null, this.instrument.ViableCounts ? "1" : "0");
    }

    private void WriteDataWorksheet(XmlWriter xml, List<ISample> sampleRecords)
    {
      xml.WriteStartElement("Worksheet");
      xml.WriteAttributeString("ss", "Name", (string) null, this.instrument.Name);
      xml.WriteAttributeString((string) null, "WorksheetType", (string) null, "Data");
      this.WriteWorksheetTag(xml);
      this.WriteSampleDataTable(xml, sampleRecords);
      xml.WriteEndElement();
    }

    private void WriteRecipeWorksheet(XmlWriter xml, RecipeList selectedRecipes)
    {
      if (selectedRecipes == null)
        return;
      xml.WriteStartElement("Worksheet");
      xml.WriteAttributeString("ss", "Name", (string) null, "Recipes");
      xml.WriteAttributeString((string) null, "WorksheetType", (string) null, "Recipes");
      this.WriteWorksheetTag(xml);
      this.WriteRecipeTable(xml, selectedRecipes);
      xml.WriteEndElement();
    }

    private void WriteZoneWorksheet(XmlWriter xml, List<IZone> zoneList)
    {
      if (zoneList == null)
        return;
      xml.WriteStartElement("Worksheet");
      xml.WriteAttributeString("ss", "Name", (string) null, "Zones");
      xml.WriteAttributeString((string) null, "WorksheetType", (string) null, "Zone");
      this.WriteWorksheetTag(xml);
      this.WriteZoneTable(xml, zoneList);
      xml.WriteEndElement();
    }

    private void WriteLocationWorksheet(XmlWriter xml, LocationList selectedLocations)
    {
      xml.WriteStartElement("Worksheet");
      xml.WriteAttributeString("ss", "Name", (string) null, "Locations");
      xml.WriteAttributeString((string) null, "WorksheetType", (string) null, "Location");
      this.WriteWorksheetTag(xml);
      this.WriteLocationTable(xml, selectedLocations);
      xml.WriteEndElement();
    }

    private void WriteSampleDataTable(XmlWriter xml, List<ISample> sampleRecords)
    {
      xml.WriteStartElement("Table");
      this.WriteDeviceInfo(xml);
      this.WriteSampleDataHeaderRow(xml);
      foreach (ISample sampleRecord in sampleRecords)
        this.WriteSampleTableRow(xml, sampleRecord);
      xml.WriteEndElement();
    }

    private void WriteRecipeTable(XmlWriter xml, RecipeList selectedRecipes)
    {
      xml.WriteStartElement("Table");
      this.WriteRowNameValuePair(xml, "Model:", this.instrument.ModelNumber, (string) null, "String");
      this.WriteRowNameValuePair(xml, "Serial #:", this.instrument.SerialNumber, (string) null, "String");
      this.WriteRecipeTableHeaderRow(xml);
      foreach (IRecipe selectedRecipe in (List<IRecipe>) selectedRecipes)
      {
        if (selectedRecipe.IsValid)
          this.WriteRecipeTableRow(xml, selectedRecipe);
      }
      xml.WriteEndElement();
    }

    private void WriteZoneTable(XmlWriter xml, List<IZone> zoneList)
    {
      xml.WriteStartElement("Table");
      this.WriteRowNameValuePair(xml, "Model", this.instrument.ModelNumber, (string) null, "String");
      this.WriteRowNameValuePair(xml, "Serial", this.instrument.SerialNumber, (string) null, "String");
      this.WriteZoneTableHeaderRow(xml);
      foreach (IZone zone in zoneList)
      {
        if (zone.IsValid && zone.Name != TSIStrings.DefaultZoneName)
          this.WriteZoneTableRow(xml, zone);
      }
      xml.WriteEndElement();
    }

    private void WriteLocationTable(XmlWriter xml, LocationList selectedLocations)
    {
      xml.WriteStartElement("Table");
      this.WriteLocationTableHeaderRow(xml);
      foreach (ILocation selectedLocation in (List<ILocation>) selectedLocations)
      {
        if (selectedLocation.IsValid)
          this.WriteLocationTableRow(xml, selectedLocation);
      }
      xml.WriteEndElement();
    }

    private void WriteSampleDataHeaderRow(XmlWriter xml)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s1");
      this.WriteTableCell(xml, "Record #");
      if (this.instrument.IsDIMode)
        this.WriteTableCell(xml, "User");
      if (this.instrument.HasZones)
        this.WriteTableCell(xml, "Zone Name");
      this.WriteTableCell(xml, "Location");
      if (this.instrument.HasZones)
      {
        this.WriteTableCell(xml, "Recipe");
        this.WriteTableCell(xml, "Recipe Sample Time");
      }
      this.WriteTableCell(xml, "Date and Time");
      this.WriteTableCell(xml, "Instrument Status");
      this.WriteTableCell(xml, "Sample Time");
      this.WriteTableCell(xml, "Flow Status");
      this.WriteTableCell(xml, "Laser Status");
      if (this.instrument.ViableCounts)
        this.WriteTableCell(xml, "Viable Sensitivity");
      int length = this.instrument.CalibratedCutPointSizesMicrometres.GetLength(0);
      for (int index = 1; index <= length; ++index)
      {
        int num = index;
        string str1 = string.Empty;
        if (this.instrument.ViableCounts && index <= length / 2)
        {
          num = index;
          str1 = "T-CNT ";
        }
        else if (this.instrument.ViableCounts && index > length / 2)
        {
          num -= length / 2;
          str1 = "V-CNT ";
        }
        xml.WriteStartElement("Cell");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        if (this.instrument.ModelNumber.StartsWith("9001"))
          xml.WriteString(string.Format("Ch{0} Size (nm)", (object) num.ToString()));
        else
          xml.WriteString(string.Format("Ch{0} Size (µm)", (object) num.ToString()));
        xml.WriteEndElement();
        xml.WriteEndElement();
        xml.WriteStartElement("Cell");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        string str2 = this.normalized ? "# / " + StandardStrings.VolumeUnits[(int) this.normalizedParticleVolume] : "#";
        string text1;
        if (this.instrument.ModelNumber.StartsWith("9001"))
          text1 = str2;
        else
          text1 = string.Format("{4}{0}{1} {2} ({3})", (object) "Ch", (object) num.ToString(), (object) "Cumul", (object) str2, (object) str1);
        xml.WriteString(text1);
        xml.WriteEndElement();
        xml.WriteEndElement();
        if (!this.instrument.ModelNumber.StartsWith("9001"))
        {
          xml.WriteStartElement("Cell");
          xml.WriteStartElement("Data");
          xml.WriteAttributeString("ss", "Type", (string) null, "String");
          string text2 = string.Format("{4}{0}{1} {2} ({3})", (object) "Ch", (object) num.ToString(), (object) "Diff", (object) str2, (object) str1);
          xml.WriteString(text2);
          xml.WriteEndElement();
          xml.WriteEndElement();
        }
      }
      this.WriteTableCell(xml, "Volume (L)");
      string cellData1 = string.Format("Temperature ({0})", this.temperatureUnits == TemperatureType.C ? (object) "°C" : (object) "°F");
      this.WriteTableCell(xml, cellData1);
      this.WriteTableCell(xml, "Humidity (%RH)");
      string cellData2 = string.Format("Air Velocity ({0})", this.airVelocityUnits == UnitCode.m_sec ? (object) "m/s" : (object) "ft/s");
      this.WriteTableCell(xml, cellData2);
      xml.WriteEndElement();
    }

    private void WriteRecipeTableHeaderRow(XmlWriter xml)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s1");
      this.WriteTableCell(xml, "Recipe");
      this.WriteTableCell(xml, "Sample Time");
      this.WriteTableCell(xml, "Sample Delay");
      this.WriteTableCell(xml, "Sample Hold");
      this.WriteTableCell(xml, "Sample Mode");
      this.WriteTableCell(xml, "Sample Cycles");
      this.WriteTableCell(xml, "Count Units");
      int length = this.instrument.CalibratedCutPointSizesMicrometres.GetLength(0);
      for (int index = 1; index <= length; ++index)
      {
        int num = index;
        string str1 = string.Empty;
        string str2 = string.Empty;
        if (this.instrument.ViableCounts && index <= length / 2)
        {
          num = index;
          str1 = "T-CNT";
          str2 = "V-CNT";
        }
        xml.WriteStartElement("Cell");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        if (this.instrument.ModelNumber.StartsWith("9001"))
          xml.WriteString(string.Format("Ch{0} Size (nm)", (object) num.ToString()));
        else
          xml.WriteString(string.Format("Ch{0} Size (µm)", (object) num.ToString()));
        xml.WriteEndElement();
        xml.WriteEndElement();
        xml.WriteStartElement("Cell");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteString(string.Format("Ch{0} {1} Threshold", (object) num.ToString(), (object) str1));
        xml.WriteEndElement();
        xml.WriteEndElement();
        if (this.instrument.ViableCounts)
        {
          xml.WriteStartElement("Cell");
          xml.WriteStartElement("Data");
          xml.WriteAttributeString("ss", "Type", (string) null, "String");
          xml.WriteString(string.Format("Ch{0} {1} Threshold", (object) num.ToString(), (object) str2));
          xml.WriteEndElement();
          xml.WriteEndElement();
        }
        if (this.instrument.ViableCounts && index == length / 2)
          break;
      }
      xml.WriteEndElement();
    }

    private void WriteZoneTableHeaderRow(XmlWriter xml)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s1");
      this.WriteTableCell(xml, "Zone Name");
      this.WriteTableCell(xml, "Standard");
      this.WriteTableCell(xml, "Class");
      this.WriteTableCell(xml, "Status");
      this.WriteTableCell(xml, "Air Flow");
      this.WriteTableCell(xml, "Area");
      this.WriteTableCell(xml, "Recipe");
      xml.WriteEndElement();
    }

    private void WriteLocationTableHeaderRow(XmlWriter xml)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s1");
      this.WriteTableCell(xml, "Location");
      if (this.instrument.HasZones)
        this.WriteTableCell(xml, "Zone Name");
      xml.WriteEndElement();
    }

    private void WriteSampleTableRow(XmlWriter xml, ISample sample)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString((string) null, "RowType", (string) null, "SampleRecord");
      xml.WriteAttributeString((string) null, "RecordId", (string) null, sample.SampleID.ToString());
      xml.WriteAttributeString((string) null, "SampleFlowRate", (string) null, sample.PrecisionFlowRate.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      xml.WriteAttributeString((string) null, "DeviceStatus", (string) null, Convert.ToString(sample.DeviceStatus));
      if (this.instrument.ViableCounts)
        xml.WriteAttributeString((string) null, "ViableSensitivity", (string) null, sample.ViableDetectionSensitivity.ToString());
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "Number");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "Sample");
      xml.WriteString(sample.SampleID.ToString());
      xml.WriteEndElement();
      xml.WriteEndElement();
      if (this.instrument.IsDIMode)
      {
        string text = sample.DIUserId > (ushort) 0 ? string.Format("{0}, {1}", (object) sample.DIUserId, (object) sample.DIUsername) : sample.DIUserId.ToString();
        xml.WriteStartElement("Cell");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "DIUser");
        xml.WriteString(text);
        xml.WriteEndElement();
        xml.WriteEndElement();
      }
      IZone zone = (IZone) null;
      if (this.instrument.HasZones)
      {
        zone = this.instrument.Zones[this.instrument.Locations[sample.LocationId].ZoneId];
        xml.WriteStartElement("Cell");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "Zone");
        xml.WriteString(zone.Name);
        xml.WriteEndElement();
        xml.WriteEndElement();
      }
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "Location");
      xml.WriteString(sample.Location);
      xml.WriteEndElement();
      xml.WriteEndElement();
      if (this.instrument.HasZones)
      {
        IRecipe recipe = this.instrument.Recipes[zone.RecipeId];
        xml.WriteStartElement("Cell");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "Recipe");
        xml.WriteString(recipe.Name);
        xml.WriteEndElement();
        xml.WriteEndElement();
        xml.WriteStartElement("Cell");
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s8");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "RecipeSampleTime");
        xml.WriteString(recipe.SampleTime.ToString());
        xml.WriteEndElement();
        xml.WriteEndElement();
      }
      xml.WriteStartElement("Cell");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s3");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "DateTime");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "SampleDate");
      xml.WriteString(ExcelXMLDataExport.DateTimeToExcelString(sample.TimeStamp));
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      if (sample.InstrumentStatus != (ushort) 0 || ((int) sample.DeviceStatus & 16384) != 0)
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s2");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "InstrumentStatus");
      bool flag = sample.InstrumentStatus != (ushort) 0 || ((int) sample.DeviceStatus & 16384) == 1;
      xml.WriteAttributeString((string) null, "InstrumentStatus", (string) null, flag ? "0" : "1");
      xml.WriteString(flag ? "ERR" : "OK");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s5");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "Number");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "SampleTime");
      xml.WriteString(sample.SampleTime.TotalSeconds.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      if (sample.FlowStatus != FlowStatus.OK)
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s2");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "FlowStatus");
      xml.WriteString(sample.FlowStatus == FlowStatus.OK ? "OK" : "ALRM");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      if (!sample.LaserStatus)
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s2");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "LaserStatus");
      xml.WriteAttributeString((string) null, "LaserStatus", (string) null, sample.LaserStatus ? "1" : "0");
      xml.WriteString(sample.LaserStatus ? "OK" : "ALRM");
      xml.WriteEndElement();
      xml.WriteEndElement();
      if (this.instrument.ViableCounts)
      {
        xml.WriteStartElement("Cell");
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s5");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "ViableSensitivity");
        xml.WriteString(sample.ViableDetectionSensitivity == (ushort) 1 ? "Normal" : (sample.ViableDetectionSensitivity == (ushort) 2 ? "High" : "Disabled"));
        xml.WriteEndElement();
        xml.WriteEndElement();
      }
      this.cumulativeChannelCollectionStatistics.Accumulate(sample, ParticleCountMode.Cumulative, this.normalized, this.normalizedParticleVolume);
      this.differentialChannelCollectionStatistics.Accumulate(sample, ParticleCountMode.Differential, this.normalized, this.normalizedParticleVolume);
      ChannelCollection channels = sample.Channels;
      channels.AddRange((IEnumerable<IChannel>) sample.ViableChannels);
      for (int index = 0; index < channels.Count; ++index)
      {
        int num1 = index + 1;
        xml.WriteStartElement("Cell");
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s6");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "Number");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "ChannelSize");
        xml.WriteAttributeString((string) null, "ChannelNumber", (string) null, num1.ToString());
        xml.WriteAttributeString((string) null, "Count", (string) null, channels[index].ParticleCount.ToString("0.", (IFormatProvider) CultureInfo.InvariantCulture));
        xml.WriteAttributeString((string) null, "Alarm", (string) null, channels[index].AlarmActive ? "1" : "0");
        if (this.instrument.ModelNumber.StartsWith("9001"))
        {
          Decimal num2 = channels[index].ParticleSizeMicrometres * 1000M;
          xml.WriteString(num2.ToString((IFormatProvider) CultureInfo.InvariantCulture));
        }
        else
          xml.WriteString(channels[index].ParticleSizeMicrometres.ToString((IFormatProvider) CultureInfo.InvariantCulture));
        xml.WriteEndElement();
        xml.WriteEndElement();
        xml.WriteStartElement("Cell");
        string empty = string.Empty;
        string str1 = !this.instrument.ViableCounts || index < sample.Channels.Count ? (channels[index].AlarmActive ? "s4" : "s5") : (channels[index].AlarmActive ? "s10" : "s11");
        xml.WriteAttributeString("ss", "StyleID", (string) null, str1);
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "Number");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "ChannelDataCumulative");
        xml.WriteAttributeString((string) null, "ChannelNumber", (string) null, num1.ToString());
        if (this.instrument.ViableCounts && index >= sample.Channels.Count)
          xml.WriteString(this.cumulativeChannelCollectionStatistics[index].ParticleCount.ToString("0.0", (IFormatProvider) CultureInfo.InvariantCulture));
        else
          xml.WriteString(this.cumulativeChannelCollectionStatistics[index].ParticleCount.ToString("0.", (IFormatProvider) CultureInfo.InvariantCulture));
        xml.WriteEndElement();
        xml.WriteEndElement();
        if (!this.instrument.ModelNumber.StartsWith("9001"))
        {
          string str2 = channels[index].AlarmActive ? "s4" : "s5";
          xml.WriteStartElement("Cell");
          xml.WriteAttributeString("ss", "StyleID", (string) null, str2);
          xml.WriteStartElement("Data");
          xml.WriteAttributeString("ss", "Type", (string) null, "Number");
          xml.WriteAttributeString((string) null, "DataType", (string) null, "ChannelDataDiff");
          xml.WriteAttributeString((string) null, "ChannelNumber", (string) null, num1.ToString());
          xml.WriteString(this.differentialChannelCollectionStatistics[index].ParticleCount.ToString("0.", (IFormatProvider) CultureInfo.InvariantCulture));
          xml.WriteEndElement();
          xml.WriteEndElement();
        }
      }
      xml.WriteStartElement("Cell");
      if (this.normalized)
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s7");
      else
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s5");
      Decimal num = Sample.ConvertLitresVolume(sample.VolumeLitres, sample.VolumeUnits);
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "Number");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "Volume");
      string str = ((int) sample.VolumeUnits).ToString();
      xml.WriteAttributeString((string) null, "VolumeUnits", (string) null, str);
      xml.WriteString(num.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      xml.WriteEndElement();
      xml.WriteEndElement();
      string text1 = "N/A";
      xml.WriteStartElement("Cell");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s6");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "Temp");
      if (sample.TemperatureUnits == TemperatureType.NA)
      {
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteAttributeString((string) null, "TempUnits", (string) null, "0");
        xml.WriteString(text1);
      }
      else
      {
        xml.WriteAttributeString("ss", "Type", (string) null, "Number");
        xml.WriteAttributeString((string) null, "TempUnits", (string) null, this.temperatureUnits.ToString("d"));
        xml.WriteString(Sample.ConvertTemperature(sample.Temperature, sample.TemperatureUnits, this.temperatureUnits).ToString((IFormatProvider) CultureInfo.InvariantCulture));
      }
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s6");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "RelativeHumidity");
      if (sample.HumidityUnits == UnitCode.NA)
      {
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteString(text1);
      }
      else
      {
        xml.WriteAttributeString("ss", "Type", (string) null, "Number");
        xml.WriteString(sample.Humidity.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      }
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s6");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "AirVelocity");
      if (sample.AirVelocityUnits == UnitCode.NA)
      {
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteAttributeString((string) null, "AirVelocityUnits", (string) null, "0");
        xml.WriteString(text1);
      }
      else
      {
        xml.WriteAttributeString("ss", "Type", (string) null, "Number");
        xml.WriteAttributeString((string) null, "AirVelocityUnits", (string) null, ((int) this.airVelocityUnits).ToString());
        xml.WriteString(Sample.ConvertVelocity(sample.AirVelocity, sample.AirVelocityUnits, this.airVelocityUnits).ToString((IFormatProvider) CultureInfo.InvariantCulture));
      }
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteEndElement();
    }

    private void WriteRecipeTableRow(XmlWriter xml, IRecipe recipe)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString((string) null, "RowType", (string) null, "Recipe");
      ushort num1;
      ushort index1 = num1 = (ushort) ((uint) recipe.AlarmThresholdMode & (uint) byte.MaxValue);
      ushort index2 = (ushort) ((uint) recipe.AlarmThresholdMode >> 8);
      xml.WriteAttributeString((string) null, "AlarmThresholdMode", (string) null, index2 == (ushort) 0 ? "0" : "1");
      xml.WriteAttributeString((string) null, "AlarmThresholdUnits", (string) null, index1.ToString());
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "Name");
      xml.WriteString(recipe.Name);
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "Number");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "SampleTime");
      xml.WriteString(recipe.SampleTime.TotalSeconds.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "Number");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "SampleDelay");
      xml.WriteString(recipe.DelayTime.TotalSeconds.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "Number");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "SampleHold");
      xml.WriteString(recipe.HoldTime.TotalSeconds.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "Number");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "SampleMode");
      xml.WriteString(((int) recipe.SamplingMode).ToString());
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "Number");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "Cycles");
      xml.WriteString(recipe.Cycles.ToString());
      xml.WriteEndElement();
      xml.WriteEndElement();
      string[] strArray = new string[4]
      {
        "#",
        "ft\u00B3",
        "m\u00B3",
        "µg/m\u00B3"
      };
      if ((int) index1 >= strArray.Length)
        index1 = (ushort) (strArray.Length - 1);
      string text = !this.instrument.ModelNumber.StartsWith("9001") ? string.Format("{0} ({1})", (object) StandardStrings.ParticleCountMode[(int) index2], (object) strArray[(int) index1]) : (index1 <= (ushort) 0 ? string.Format("{0}", (object) strArray[(int) index1]) : string.Format("#/{0}", (object) strArray[(int) index1]));
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "AlarmThresholdMode");
      xml.WriteString(text);
      xml.WriteEndElement();
      xml.WriteEndElement();
      for (int index3 = 0; index3 < (int) this.instrument.NumberOfChannels && (!this.instrument.ViableCounts || index3 != (int) this.instrument.NumberOfChannels / 2); ++index3)
      {
        int num2 = index3 + 1;
        xml.WriteStartElement("Cell");
        if (!recipe.ChannelEnable[index3])
          xml.WriteAttributeString("ss", "StyleID", (string) null, "s9");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "Number");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "ChannelSize");
        xml.WriteAttributeString((string) null, "ChannelNumber", (string) null, num2.ToString());
        xml.WriteAttributeString((string) null, "Enable", (string) null, recipe.ChannelEnable[index3] ? "1" : "0");
        if (this.instrument.ModelNumber.StartsWith("9001"))
        {
          Decimal num3 = recipe.CutPointsSizesMicrometersSpecified[index3] * 1000M;
          xml.WriteString(num3.ToString((IFormatProvider) CultureInfo.InvariantCulture));
        }
        else
          xml.WriteString(recipe.CutPointsSizesMicrometersSpecified[index3].ToString((IFormatProvider) CultureInfo.InvariantCulture));
        xml.WriteEndElement();
        xml.WriteEndElement();
        xml.WriteStartElement("Cell");
        if (!recipe.AlarmEnable[index3])
          xml.WriteAttributeString("ss", "StyleID", (string) null, "s9");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "Number");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "Threshold");
        xml.WriteAttributeString((string) null, "ChannelNumber", (string) null, num2.ToString());
        xml.WriteAttributeString((string) null, "Alarm", (string) null, recipe.AlarmEnable[index3] ? "1" : "0");
        xml.WriteString(recipe.AlarmThreshold[index3].ToString());
        xml.WriteEndElement();
        xml.WriteEndElement();
        if (this.instrument.ViableCounts)
        {
          xml.WriteStartElement("Cell");
          if (!recipe.AlarmEnable[index3 + 6])
            xml.WriteAttributeString("ss", "StyleID", (string) null, "s9");
          xml.WriteStartElement("Data");
          xml.WriteAttributeString("ss", "Type", (string) null, "Number");
          xml.WriteAttributeString((string) null, "DataType", (string) null, "Threshold");
          xml.WriteAttributeString((string) null, "ChannelNumber", (string) null, (num2 + 6).ToString());
          xml.WriteAttributeString((string) null, "Alarm", (string) null, recipe.AlarmEnable[index3 + 6] ? "1" : "0");
          xml.WriteString(recipe.AlarmThreshold[index3 + 6].ToString());
          xml.WriteEndElement();
          xml.WriteEndElement();
        }
      }
      xml.WriteEndElement();
    }

    private void WriteZoneTableRow(XmlWriter xml, IZone zone)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString((string) null, "RowType", (string) null, "Zone");
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "ZoneName");
      xml.WriteString(zone.Name);
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "ZoneStandard");
      xml.WriteAttributeString((string) null, "StandardValue", (string) null, zone.Standard.ToString());
      xml.WriteString(StandardStrings.StandardsReportNames[(int) zone.Standard]);
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "ZoneClass");
      if (zone.ZoneClass < (ushort) 0)
        zone.ZoneClass = (ushort) 0;
      xml.WriteAttributeString((string) null, "ClassValue", (string) null, zone.ZoneClass.ToString());
      int index = (int) zone.ZoneClass;
      if (zone.Standard == (ushort) 0)
        index = !this.instrument.ModelNumber.StartsWith("9110") ? (int) zone.ZoneClass + 1 : (int) zone.ZoneClass;
      string text1 = index >= StandardStrings.ClassLevel[(int) zone.Standard].GetLength(0) ? "Unknown" : StandardStrings.ClassLevel[(int) zone.Standard][index];
      xml.WriteString(text1);
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "ZoneState");
      if (this.instrument.ModelNumber.StartsWith("9001"))
      {
        xml.WriteAttributeString((string) null, "StateValue", (string) null, "0");
        xml.WriteString("N/A");
      }
      else
      {
        xml.WriteAttributeString((string) null, "StateValue", (string) null, zone.ZoneState >= (ushort) 0 ? zone.ZoneState.ToString() : "0");
        xml.WriteString(StandardStrings.ZoneStatus[(int) zone.ZoneState]);
      }
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "ZoneAirFlow");
      if (this.instrument.ModelNumber.StartsWith("9001"))
      {
        xml.WriteAttributeString((string) null, "AirFlowValue", (string) null, "0");
        xml.WriteString("N/A");
      }
      else
      {
        xml.WriteAttributeString((string) null, "AirFlowValue", (string) null, zone.Airflow >= (ushort) 0 ? zone.Airflow.ToString() : "0");
        xml.WriteString(StandardStrings.AirFlow[(int) zone.Airflow]);
      }
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "ZoneArea");
      xml.WriteAttributeString((string) null, "AreaValue", (string) null, zone.Area.ToString((IFormatProvider) CultureInfo.InvariantCulture));
      xml.WriteAttributeString((string) null, "ZoneAreaUnit", (string) null, zone.AreaUnits.ToString());
      string text2 = string.Format("{0} {1}", (object) zone.Area.ToString((IFormatProvider) CultureInfo.InvariantCulture), zone.AreaUnits > (ushort) 0 ? (object) "m\u00B2" : (object) "ft\u00B2");
      xml.WriteString(text2);
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "Recipe");
      if (zone.RecipeId > 0)
      {
        xml.WriteAttributeString((string) null, "RecipeIndex", (string) null, zone.RecipeId.ToString());
        xml.WriteString(this.instrument.Recipes[zone.RecipeId].Name);
      }
      else
        xml.WriteString(this.instrument.Recipes[0].Name);
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteEndElement();
    }

    private void WriteLocationTableRow(XmlWriter xml, ILocation location)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString((string) null, "RowType", (string) null, "Location");
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteAttributeString((string) null, "DataType", (string) null, "LocationName");
      xml.WriteString(location.Name);
      xml.WriteEndElement();
      xml.WriteEndElement();
      if (this.instrument.HasZones)
      {
        xml.WriteStartElement("Cell");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "String");
        xml.WriteAttributeString((string) null, "DataType", (string) null, "ZoneName");
        xml.WriteString(this.instrument.Zones[location.ZoneId].Name);
        xml.WriteEndElement();
        xml.WriteEndElement();
      }
      xml.WriteEndElement();
    }

    private void WriteDeviceInfo(XmlWriter xml)
    {
      this.WriteRowNameValuePair(xml, "Model #:", this.instrument.ModelNumber, (string) null, "String");
      this.WriteRowNameValuePair(xml, "Serial #:", this.instrument.SerialNumber, (string) null, "String");
      this.WriteRowNameValuePair(xml, "TPLS Application Version", Application.ProductVersion, (string) null, "String");
      if (this.instrument.LastCalibrationDate != DateTime.MinValue)
      {
        this.WriteRowNameValuePair(xml, "Last Calibrated:", ExcelXMLDataExport.DateTimeToExcelString(this.instrument.LastCalibrationDate), "s3", "DateTime");
        this.WriteRowNameValuePair(xml, "Calibration Due:", ExcelXMLDataExport.DateTimeToExcelString(this.instrument.CalibrationDueDate), "s3", "DateTime");
      }
      this.WriteRowNameValuePair(xml, "Firmware Version:", this.instrument.FirmwareVersion.ToString(), (string) null, "String");
      if (this.instrument.IsDIMode)
        this.WriteRowNameValuePair(xml, "Data Integrity User Id:", this.instrument.DIUserId.ToString(), (string) null, "String");
      if (this.instrument.ViableCounts)
        this.WriteRowNameValuePair(xml, "Algorithm Version:", this.instrument.AlgorithmVersion, (string) null, "String");
      this.WriteRowNameValuePair(xml, "Flow (L/Min):", this.instrument.FlowRateLitresPerMinute.ToString((IFormatProvider) CultureInfo.InvariantCulture), (string) null, "Number");
      xml.WriteStartElement("Row");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s1");
      xml.WriteAttributeString((string) null, "RowType", (string) null, "ChannelCutPoints");
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      if (this.instrument.ModelNumber.StartsWith("9001"))
        xml.WriteString("Size (nm)");
      else
        xml.WriteString("Cut Point Sizes (µm):");
      xml.WriteEndElement();
      xml.WriteEndElement();
      if (this.instrument.ModelNumber.StartsWith("9001"))
      {
        int num1 = 1;
        xml.WriteStartElement("Cell");
        xml.WriteAttributeString("ss", "StyleID", (string) null, "s6");
        xml.WriteStartElement("Data");
        xml.WriteAttributeString("ss", "Type", (string) null, "Number");
        xml.WriteAttributeString((string) null, "ChannelNumber", (string) null, num1.ToString());
        Decimal num2 = this.instrument.CalibratedCutPointSizesMicrometres[0] * 1000M;
        xml.WriteString(num2.ToString((IFormatProvider) CultureInfo.InvariantCulture));
        xml.WriteEndElement();
        xml.WriteEndElement();
      }
      else
      {
        int num3 = this.instrument.ViableCounts ? 2 : 1;
        for (int index = 0; index < this.instrument.CalibratedCutPointSizesMicrometres.Length / num3; ++index)
        {
          int num4 = index + 1;
          xml.WriteStartElement("Cell");
          xml.WriteAttributeString("ss", "StyleID", (string) null, "s6");
          xml.WriteStartElement("Data");
          xml.WriteAttributeString("ss", "Type", (string) null, "Number");
          xml.WriteAttributeString((string) null, "ChannelNumber", (string) null, num4.ToString());
          xml.WriteString(this.instrument.CalibratedCutPointSizesMicrometres[index].ToString((IFormatProvider) CultureInfo.InvariantCulture));
          xml.WriteEndElement();
          xml.WriteEndElement();
        }
      }
      xml.WriteEndElement();
    }

    private void WriteTableCell(XmlWriter xml, string cellData)
    {
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteString(cellData);
      xml.WriteEndElement();
      xml.WriteEndElement();
    }

    private FileStream CreateFileStream(string fileName)
    {
      try
      {
        return new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(string.Format("Unable to create data file {0}: {1}", (object) fileName, (object) ex.Message), "Save Data to File", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        return (FileStream) null;
      }
    }

    private void WriteWorkbookDocumentProperties(XmlWriter xml)
    {
      xml.WriteElementString("DocumentProperties", "urn:schemas-microsoft-com:office:office");
    }

    private void WriteWorkbookExcelWorkbook(XmlWriter xml)
    {
      xml.WriteStartElement("ExcelWorkbook", "urn:schemas-microsoft-com:office:excel");
      xml.WriteElementString("ProtectStructure", "False");
      xml.WriteElementString("ProtectWindows", "False");
      xml.WriteEndElement();
    }

    private void WriteWorkbookStyles(XmlWriter xml)
    {
      xml.WriteStartElement("Styles");
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "Default");
      xml.WriteAttributeString("ss", "Name", (string) null, "Normal");
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s1");
      xml.WriteStartElement("Font");
      xml.WriteAttributeString("x", "Family", (string) null, "Swiss");
      xml.WriteAttributeString("ss", "Bold", (string) null, "1");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s2");
      xml.WriteStartElement("Interior");
      xml.WriteAttributeString("ss", "Color", (string) null, "#FF0000");
      xml.WriteAttributeString("ss", "Pattern", (string) null, "Solid");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s3");
      xml.WriteStartElement("NumberFormat");
      xml.WriteAttributeString("ss", "Format", (string) null, "dd/MM/yyyy HH:mm:ss");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s4");
      xml.WriteStartElement("Interior");
      xml.WriteAttributeString("ss", "Color", (string) null, "#FF0000");
      xml.WriteAttributeString("ss", "Pattern", (string) null, "Solid");
      xml.WriteEndElement();
      xml.WriteStartElement("NumberFormat");
      xml.WriteAttributeString("ss", "Format", (string) null, "0");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s5");
      xml.WriteStartElement("NumberFormat");
      xml.WriteAttributeString("ss", "Format", (string) null, "0");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s6");
      xml.WriteStartElement("NumberFormat");
      xml.WriteAttributeString("ss", "Format", (string) null, "0.0");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s7");
      xml.WriteStartElement("NumberFormat");
      xml.WriteAttributeString("ss", "Format", (string) null, "0.0000");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s8");
      xml.WriteStartElement("NumberFormat");
      xml.WriteAttributeString("ss", "Format", (string) null, "HH:mm:ss");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s9");
      xml.WriteStartElement("Font");
      xml.WriteAttributeString("ss", "FontName", (string) null, "Calibri");
      xml.WriteAttributeString("x", "Family", (string) null, "Swiss");
      xml.WriteAttributeString("ss", "Size", (string) null, "11");
      xml.WriteAttributeString("ss", "Color", (string) null, "#A5A5A5");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s10");
      xml.WriteStartElement("Interior");
      xml.WriteAttributeString("ss", "Color", (string) null, "#FF0000");
      xml.WriteAttributeString("ss", "Pattern", (string) null, "Solid");
      xml.WriteEndElement();
      xml.WriteStartElement("NumberFormat");
      xml.WriteAttributeString("ss", "Format", (string) null, "0.0");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Style");
      xml.WriteAttributeString("ss", "ID", (string) null, "s11");
      xml.WriteStartElement("NumberFormat");
      xml.WriteAttributeString("ss", "Format", (string) null, "0.0");
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteEndElement();
    }

    private void WriteRowNameValuePair(
      XmlWriter xml,
      string name,
      string value,
      string cellStyle,
      string dataType)
    {
      xml.WriteStartElement("Row");
      xml.WriteAttributeString("ss", "StyleID", (string) null, "s1");
      xml.WriteStartElement("Cell");
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, "String");
      xml.WriteString(name);
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteStartElement("Cell");
      if (cellStyle != null)
        xml.WriteAttributeString("ss", "StyleID", (string) null, cellStyle);
      xml.WriteStartElement("Data");
      xml.WriteAttributeString("ss", "Type", (string) null, dataType);
      xml.WriteString(value);
      xml.WriteEndElement();
      xml.WriteEndElement();
      xml.WriteEndElement();
    }

    public static string DateTimeToExcelString(DateTime dateTime)
    {
      CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append(dateTime.Year.ToString("00"));
      stringBuilder.AppendFormat((IFormatProvider) currentCulture, "-{0}", (object) dateTime.Month.ToString("00"));
      stringBuilder.AppendFormat((IFormatProvider) currentCulture, "-{0}", (object) dateTime.Day.ToString("00"));
      stringBuilder.AppendFormat((IFormatProvider) currentCulture, "T{0}", (object) dateTime.Hour.ToString("00"));
      stringBuilder.AppendFormat((IFormatProvider) currentCulture, ":{0}", (object) dateTime.Minute.ToString("00"));
      stringBuilder.AppendFormat((IFormatProvider) currentCulture, ":{0}", (object) dateTime.Second.ToString("00"));
      stringBuilder.AppendFormat((IFormatProvider) currentCulture, ".{0}", (object) dateTime.Millisecond.ToString("000"));
      return stringBuilder.ToString();
    }

    public static string TimeSpanToExcelString(CultureInfo cultureInfo, TimeSpan timeSpan)
    {
      return ExcelXMLDataExport.DateTimeToExcelString(new DateTime(1899, 12, 31) + timeSpan);
    }

    private void WriteUserSignature(XmlWriter xml, string tplsUser, string windowsUser)
    {
      xml.WriteStartElement("UserSignature");
      xml.WriteAttributeString("DateTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
      string text = string.IsNullOrEmpty(tplsUser) ? string.Format("{0}", (object) windowsUser) : string.Format("{0}, {1}", (object) tplsUser, (object) windowsUser);
      xml.WriteString(text);
      xml.WriteEndElement();
    }

    private void WriteMD5Hash(XmlWriter xml, FileStream fs)
    {
      xml.Flush();
      string hash = FileUtility.CreateHash(fs);
      xml.WriteStartElement("MD5");
      xml.WriteString(hash);
      xml.WriteEndElement();
    }
  }
}
