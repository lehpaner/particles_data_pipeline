﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MRParticleCounterSettings
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MRParticleCounterSettings : DataTable
  {
    public static string ParticleCounterSettingsTableName = "ParticleCounterSettings";
    public static string HeaderColumnName = "ParticleCounterSettingsHeader";
    public static string ValueColumnName = "ParticleCounterSettingsValue";

    public MRParticleCounterSettings()
      : base(MRParticleCounterSettings.ParticleCounterSettingsTableName)
    {
      this.Columns.Add(new DataColumn(MRParticleCounterSettings.HeaderColumnName, typeof (string)));
      this.Columns.Add(new DataColumn(MRParticleCounterSettings.ValueColumnName, typeof (string)));
    }
  }
}
