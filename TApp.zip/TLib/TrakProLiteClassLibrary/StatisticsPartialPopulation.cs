﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.StatisticsPartialPopulation
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class StatisticsPartialPopulation : Statistics
  {
    private List<Decimal> Samples;
    private double sumOfTheSquares;
    protected bool needToRecalculate;

    public override Decimal RMS
    {
      get
      {
        this.CalculateStatistics();
        return 1 >= this.Count ? -1M : this.StandardDeviation / (Decimal) Math.Sqrt((double) this.Count);
      }
    }

    public override Decimal StandardDeviation
    {
      get
      {
        this.CalculateStatistics();
        return 1 >= this.Count ? -1M : (Decimal) Math.Sqrt(this.sumOfTheSquares / (double) (this.Count - 1));
      }
    }

    public override Decimal StandardVariance => 1 >= this.Count ? -1M : base.StandardVariance;

    public override Decimal UCL95(Decimal uclFactor)
    {
      this.CalculateStatistics();
      Decimal num1 = Decimal.Floor(this.Mean + 0.5M);
      Decimal num2 = Decimal.Floor((Decimal) (Math.Sqrt(Decimal.ToDouble(Decimal.Floor(this.StandardVariance + 0.5M))) + 0.5));
      return Decimal.Floor(num1 + uclFactor * (num2 / (Decimal) Math.Sqrt((double) this.Count)) + 0.5M);
    }

    public override void Accumulate(Decimal value)
    {
      base.Accumulate(value);
      this.Samples.Add(value);
      this.needToRecalculate = true;
    }

    protected virtual void CalculateStatistics()
    {
      if (!this.needToRecalculate)
        return;
      foreach (Decimal sample in this.Samples)
        this.sumOfTheSquares += Decimal.ToDouble((sample - this.Mean) * (sample - this.Mean));
      this.needToRecalculate = false;
    }

    public override void Zero()
    {
      base.Zero();
      this.Samples = new List<Decimal>();
      this.needToRecalculate = true;
      this.sumOfTheSquares = 0.0;
    }
  }
}
