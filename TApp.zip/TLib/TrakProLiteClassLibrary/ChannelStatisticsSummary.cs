﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ChannelStatisticsSummary
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ChannelStatisticsSummary
  {
    private ChannelStatistics[] channelStatistics;

    public ChannelStatisticsSummary(ChannelStatistics[] statistics)
    {
      this.channelStatistics = statistics;
    }

    public Decimal ChannelMin1 => this.channelStatistics[0].Minimum;

    public Decimal ChannelMin2 => this.channelStatistics[1].Minimum;

    public Decimal ChannelMin3 => this.channelStatistics[2].Minimum;

    public Decimal ChannelMin4 => this.channelStatistics[3].Minimum;

    public Decimal ChannelMin5 => this.channelStatistics[4].Minimum;

    public Decimal ChannelMin6 => this.channelStatistics[5].Minimum;

    public Decimal ChannelMin7 => this.channelStatistics[6].Minimum;

    public Decimal ChannelMin8 => this.channelStatistics[7].Minimum;

    public Decimal ChannelMin9 => this.channelStatistics[8].Minimum;

    public Decimal ChannelMin10 => this.channelStatistics[9].Minimum;

    public Decimal ChannelMin11 => this.channelStatistics[10].Minimum;

    public Decimal ChannelMin12 => this.channelStatistics[11].Minimum;

    public Decimal ChannelMax1 => this.channelStatistics[0].Maximum;

    public Decimal ChannelMax2 => this.channelStatistics[1].Maximum;

    public Decimal ChannelMax3 => this.channelStatistics[2].Maximum;

    public Decimal ChannelMax4 => this.channelStatistics[3].Maximum;

    public Decimal ChannelMax5 => this.channelStatistics[4].Maximum;

    public Decimal ChannelMax6 => this.channelStatistics[5].Maximum;

    public Decimal ChannelMax7 => this.channelStatistics[6].Maximum;

    public Decimal ChannelMax8 => this.channelStatistics[7].Maximum;

    public Decimal ChannelMax9 => this.channelStatistics[8].Maximum;

    public Decimal ChannelMax10 => this.channelStatistics[9].Maximum;

    public Decimal ChannelMax11 => this.channelStatistics[10].Maximum;

    public Decimal ChannelMax12 => this.channelStatistics[11].Maximum;

    public Decimal ChannelMean1 => this.channelStatistics[0].Mean;

    public Decimal ChannelMean2 => this.channelStatistics[1].Mean;

    public Decimal ChannelMean3 => this.channelStatistics[2].Mean;

    public Decimal ChannelMean4 => this.channelStatistics[3].Mean;

    public Decimal ChannelMean5 => this.channelStatistics[4].Mean;

    public Decimal ChannelMean6 => this.channelStatistics[5].Mean;

    public Decimal ChannelMean7 => this.channelStatistics[6].Mean;

    public Decimal ChannelMean8 => this.channelStatistics[7].Mean;

    public Decimal ChannelMean9 => this.channelStatistics[8].Mean;

    public Decimal ChannelMean10 => this.channelStatistics[9].Mean;

    public Decimal ChannelMean11 => this.channelStatistics[10].Mean;

    public Decimal ChannelMean12 => this.channelStatistics[11].Mean;

    public Decimal ChannelStdDev1 => this.channelStatistics[0].StandardDeviation;

    public Decimal ChannelStdDev2 => this.channelStatistics[1].StandardDeviation;

    public Decimal ChannelStdDev3 => this.channelStatistics[2].StandardDeviation;

    public Decimal ChannelStdDev4 => this.channelStatistics[3].StandardDeviation;

    public Decimal ChannelStdDev5 => this.channelStatistics[4].StandardDeviation;

    public Decimal ChannelStdDev6 => this.channelStatistics[5].StandardDeviation;

    public Decimal ChannelStdDev7 => this.channelStatistics[6].StandardDeviation;

    public Decimal ChannelStdDev8 => this.channelStatistics[7].StandardDeviation;

    public Decimal ChannelStdDev9 => this.channelStatistics[8].StandardDeviation;

    public Decimal ChannelStdDev10 => this.channelStatistics[9].StandardDeviation;

    public Decimal ChannelStdDev11 => this.channelStatistics[10].StandardDeviation;

    public Decimal ChannelStdDev12 => this.channelStatistics[11].StandardDeviation;

    public Decimal ChannelStdErr1 => this.channelStatistics[0].StandardError;

    public Decimal ChannelStdErr2 => this.channelStatistics[1].StandardError;

    public Decimal ChannelStdErr3 => this.channelStatistics[2].StandardError;

    public Decimal ChannelStdErr4 => this.channelStatistics[3].StandardError;

    public Decimal ChannelStdErr5 => this.channelStatistics[4].StandardError;

    public Decimal ChannelStdErr6 => this.channelStatistics[5].StandardError;

    public Decimal ChannelStdErr7 => this.channelStatistics[6].StandardError;

    public Decimal ChannelStdErr8 => this.channelStatistics[7].StandardError;

    public Decimal ChannelStdErr9 => this.channelStatistics[8].StandardError;

    public Decimal ChannelStdErr10 => this.channelStatistics[9].StandardError;

    public Decimal ChannelStdErr11 => this.channelStatistics[10].StandardError;

    public Decimal ChannelStdErr12 => this.channelStatistics[11].StandardError;
  }
}
