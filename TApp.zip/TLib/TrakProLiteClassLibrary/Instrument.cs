﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.Instrument
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using TSI;
using TSI.Communication;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class Instrument : IInstrument
  {
    private string modelNumber;
    private string serialNumber;
    private string algorithmVersion = string.Empty;
    private Decimal flowRateLitresPerMinute;
    private Decimal[] calibratedCutPointSizesMicrometres;
    private Decimal maximumCutPointSize;
    private Decimal minimumCutPointSize;
    private RecipeList recipes;
    private LocationList locations;
    private bool hasZones;
    private bool hasRecipes;
    private bool variableBins;
    private bool viableCounts;
    private ushort numberOfChannels;
    private DeviceType deviceType;
    private DateTime lastCalibrationDate = DateTime.MinValue;
    private DateTime calibrationDueDate = DateTime.MinValue;
    private ZoneList zones;
    private ushort recipeLabelLength;
    private bool locked;
    private bool connected;
    private bool unicode;
    private ushort firmwareVersion;
    private List<ISample> sampleRecords = new List<ISample>();
    private bool hasDataIntegrity;
    private bool isDIMode;
    private ushort diUserId;
    private ConnectionType connType;
    private bool[] isChannelViable;

    public Instrument()
    {
      this.modelNumber = "Unknown";
      this.serialNumber = "Unknown";
      this.minimumCutPointSize = 0.1M;
      this.maximumCutPointSize = 10.0M;
      this.flowRateLitresPerMinute = 28.3M;
      this.calibratedCutPointSizesMicrometres = new Decimal[8]
      {
        0.1M,
        0.2M,
        0.3M,
        0.5M,
        1.0M,
        3.0M,
        5.0M,
        10.0M
      };
      this.hasZones = false;
      this.hasRecipes = false;
      this.deviceType = DeviceType.Unknown;
      this.lastCalibrationDate = DateTime.MinValue;
      this.calibrationDueDate = DateTime.MinValue;
      this.recipeLabelLength = (ushort) 16;
      this.hasDataIntegrity = false;
      this.isDIMode = false;
      this.diUserId = (ushort) 0;
      this.connType = ConnectionType.USB;
      this.isChannelViable = new bool[8];
    }

    public Instrument(
      string modelNumber,
      string serialNumber,
      DeviceType deviceType,
      DateTime calDate,
      Decimal flowRateLPM,
      Decimal[] calibratedCutPointSizesMicrometres,
      ushort numChannels,
      bool variableBins,
      bool viableCounts,
      bool unicode,
      bool hasZones,
      ZoneList zones,
      bool hasRecipes,
      RecipeList recipes,
      LocationList locations,
      bool[] isChannelViable)
    {
      this.modelNumber = modelNumber;
      this.serialNumber = serialNumber;
      this.deviceType = deviceType;
      this.flowRateLitresPerMinute = flowRateLPM;
      this.calibratedCutPointSizesMicrometres = calibratedCutPointSizesMicrometres;
      this.numberOfChannels = numChannels;
      this.hasRecipes = hasRecipes;
      this.recipes = recipes;
      this.locations = locations;
      this.minimumCutPointSize = calibratedCutPointSizesMicrometres[0];
      this.maximumCutPointSize = calibratedCutPointSizesMicrometres[(int) this.numberOfChannels - 1];
      this.lastCalibrationDate = calDate;
      this.zones = zones;
      this.hasZones = hasZones;
      this.variableBins = variableBins;
      this.viableCounts = viableCounts;
      this.unicode = unicode;
      this.isChannelViable = isChannelViable;
    }

    public bool Locked
    {
      get => this.locked;
      set => this.locked = value;
    }

    public bool Connected
    {
      get => this.connected;
      set => this.connected = value;
    }

    public ConnectionType ConnType
    {
      get => this.connType;
      set => this.connType = value;
    }

    public bool HasZones => this.hasZones;

    public bool HasRecipes
    {
      get => this.hasRecipes;
      set => this.hasRecipes = value;
    }

    public List<ISample> SampleRecords => this.sampleRecords;

    public uint NumberOfSamples => (uint) this.sampleRecords.Count;

    public FlowUnits FlowUnits => FlowUnits.LPM;

    public string Name
    {
      get => string.Format("{0} {1}", (object) this.modelNumber, (object) this.serialNumber);
    }

    public bool VariableBins => this.variableBins;

    public bool ViableCounts => this.viableCounts;

    public DateTime LastCalibrationDate => this.lastCalibrationDate;

    public DateTime CalibrationDueDate => this.calibrationDueDate;

    public DeviceType DeviceType => this.deviceType;

    public Decimal[] CalibratedCutPointSizesMicrometres => this.calibratedCutPointSizesMicrometres;

    public ushort[] ChannelSizes
    {
      get
      {
        ushort[] channelSizes = new ushort[(int) this.NumberOfChannels];
        for (int index = 0; index < (int) this.NumberOfChannels; ++index)
          channelSizes[index] = (ushort) (this.calibratedCutPointSizesMicrometres[index] * 1000M + 0.5M);
        return channelSizes;
      }
    }

    public string ModelNumber
    {
      get => this.modelNumber;
      set => this.modelNumber = value;
    }

    public string SerialNumber
    {
      get => this.serialNumber;
      set => this.serialNumber = value;
    }

    public string AlgorithmVersion
    {
      get => this.algorithmVersion;
      set => this.algorithmVersion = value;
    }

    public ushort FirmwareVersion => this.firmwareVersion;

    public Decimal FlowRateLitresPerMinute
    {
      get => this.flowRateLitresPerMinute;
      set => this.flowRateLitresPerMinute = value;
    }

    public Decimal MinimumCutPointSize
    {
      get => this.minimumCutPointSize;
      set => this.minimumCutPointSize = value;
    }

    public Decimal MaximumCutPointSize
    {
      get => this.maximumCutPointSize;
      set => this.maximumCutPointSize = value;
    }

    public ushort NumberOfChannels => this.numberOfChannels;

    public RecipeList Recipes
    {
      get => this.recipes;
      set => this.recipes = value;
    }

    public ushort RecipeLabelLength => this.recipeLabelLength;

    public bool RecipeLocked(int recipeId)
    {
      return this.Zones.FindAll((Predicate<IZone>) (z => z.RecipeId == recipeId)).Count > 0;
    }

    public LocationList Locations
    {
      get => this.locations;
      set => this.locations = value;
    }

    public ZoneList Zones
    {
      get => this.zones;
      set => this.zones = value;
    }

    public bool ZoneLocked(int zoneId)
    {
      if (this.Locked || this.zones[zoneId].Name == TSIStrings.DefaultZoneName)
        return true;
      foreach (ILocation location in this.locations.FindAll((Predicate<ILocation>) (loc => loc.ZoneId == zoneId)))
      {
        if (location.Locked)
          return true;
      }
      return false;
    }

    public bool Unicode => this.unicode;

    public bool HasDataIntegrity => this.hasDataIntegrity;

    public bool IsDIMode
    {
      get => this.isDIMode;
      set => this.isDIMode = value;
    }

    public bool IsDIUserLoggedIn => this.diUserId != (ushort) 0;

    public ushort DIUserId => this.diUserId;

    public bool[] IsChannelViable => this.isChannelViable;
  }
}
