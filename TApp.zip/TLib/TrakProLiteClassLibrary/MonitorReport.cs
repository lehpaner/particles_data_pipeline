﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MonitorReport
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Linq;
using TSI;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MonitorReport
  {
    private string[] zoneStatusStrings = new string[3]
    {
      "AtRest",
      "Operational",
      "AsBuilt"
    };
    private IInstrument device;
    private List<SampleSummaryStats> summaryStats;
    private IList<ReportSample> sampleList;
    private List<ParticleAlerts> selectedSizes;

    public string ReportTitle { get; set; }

    public UnitType Units { get; set; }

    public RecordType CountMode { get; set; }

    public VolumeType Volume { get; set; }

    public string Comments { get; set; }

    public bool AddReviewerSignature { get; set; }

    public IInstrument Device
    {
      get => this.device;
      set => this.device = value;
    }

    public string ZoneName { get; set; }

    public string ZoneStatus { get; set; }

    public IRecipe Recipe { get; set; }

    public List<SampleSummaryStats> SummaryStats => this.summaryStats;

    public IList<ReportSample> SampleList => this.sampleList;

    public List<ParticleAlerts> SelectedSizes => this.selectedSizes;

    public MonitorReport() => this.summaryStats = new List<SampleSummaryStats>();

    public void GenerateReportDataFromSamples(
      IList<ReportSample> sampleList,
      List<ParticleAlerts> selectedSizes)
    {
      this.summaryStats.Clear();
      this.getChannelStatistics(sampleList, selectedSizes);
      this.sampleList = sampleList;
      this.selectedSizes = selectedSizes;
    }

    private void getChannelStatistics(
      IList<ReportSample> sampleRecords,
      List<ParticleAlerts> selectedSizes)
    {
      ChannelStatistics[] channelStatisticsArray = new ChannelStatistics[selectedSizes.Count];
      for (int index = 0; index < channelStatisticsArray.Length; ++index)
      {
        int channel = selectedSizes[index].Channel;
        channelStatisticsArray[index] = !this.device.ViableCounts || channel < (int) this.device.NumberOfChannels / 2 ? new ChannelStatistics(selectedSizes[index].Size, false, sampleRecords.Count) : new ChannelStatistics(selectedSizes[index].Size, true, sampleRecords.Count);
      }
      int units = (int) this.Units;
      for (int index = 0; index < channelStatisticsArray.Length; ++index)
      {
        List<string> source1 = new List<string>();
        List<string> source2 = new List<string>();
        int channel = selectedSizes[index].Channel;
        for (int sampleIndex = 0; sampleIndex < sampleRecords.Count; ++sampleIndex)
        {
          channelStatisticsArray[index].Accumulate(sampleIndex, sampleRecords[sampleIndex].ParticleCounts[channel]);
          if (selectedSizes[index].ActionLevel >= 0M && sampleRecords[sampleIndex].ParticleCounts[channel] >= selectedSizes[index].ActionLevel)
          {
            if (source2.FirstOrDefault<string>((Func<string, bool>) (loc => loc == sampleRecords[sampleIndex].Location)) == null)
              source2.Add(sampleRecords[sampleIndex].Location);
          }
          else if (selectedSizes[index].AlertLevel >= 0M && sampleRecords[sampleIndex].ParticleCounts[channel] >= selectedSizes[index].AlertLevel && source1.FirstOrDefault<string>((Func<string, bool>) (loc => loc == sampleRecords[sampleIndex].Location)) == null)
            source1.Add(sampleRecords[sampleIndex].Location);
        }
        this.summaryStats.Add(new SampleSummaryStats()
        {
          Size = this.device.CalibratedCutPointSizesMicrometres[channel],
          Alert = selectedSizes[index].AlertLevel,
          Action = selectedSizes[index].ActionLevel,
          Min = channelStatisticsArray[index].Minimum,
          Max = channelStatisticsArray[index].Maximum,
          Mean = channelStatisticsArray[index].Mean,
          AlertLocations = source1,
          ActionLocations = source2,
          Channel = channel
        });
      }
    }
  }
}
