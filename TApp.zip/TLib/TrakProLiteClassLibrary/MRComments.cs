﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.MRComments
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Data;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class MRComments : DataTable
  {
    public static string CommentsTableName = "CommentsTable";
    public static string ColumnName = "Comments";

    public MRComments()
      : base(MRComments.CommentsTableName)
    {
      this.Columns.Add(new DataColumn(MRComments.ColumnName, typeof (string)));
    }
  }
}
