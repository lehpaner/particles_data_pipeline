﻿// Decompiled with JetBrains decompiler
// Type: TrakProLiteClassLibrary.ManualReportConfiguration
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TrakProLiteClassLibrary
{
  public class ManualReportConfiguration : StandardsReportConfiguration
  {
    private static ManualReportConfiguration instance = new ManualReportConfiguration();

    private ManualReportConfiguration()
      : base("Manual Operation")
    {
      this.standardCutPointsMicrometres = new Decimal[21]
      {
        0.1M,
        0.15M,
        0.2M,
        0.25M,
        0.3M,
        0.4M,
        0.5M,
        0.6M,
        0.7M,
        0.8M,
        0.9M,
        1.0M,
        2.0M,
        3.0M,
        4.0M,
        5.0M,
        6.0M,
        7.0M,
        8.0M,
        9.0M,
        10.0M
      };
      this.standardConcentrationLimits = new Decimal[1][]
      {
        new Decimal[1]{ Decimal.MaxValue }
      };
      this.minimumRequiredSampleTimeForStandard = new TimeSpan(0, 0, 1);
      this.minimumRequiredParticleSizeIndexesForClass = new int[1];
      this.maximumRequiredParticleSizeIndexesForClass = new int[1]
      {
        this.standardCutPointsMicrometres.Length - 1
      };
      this.minimumRequiredParticleSizesForClass = new Decimal[1]
      {
        0.0M
      };
      this.maximumRequiredParticleSizesForClass = new Decimal[1]
      {
        10.0M
      };
      this.roomStatusStrings = new string[1]{ "N/A" };
      this.roomStatusIndex = 0;
      this.classLevelStrings = new string[1]{ "N/A" };
      this.classLevelIndex = 0;
      this.airFlowStrings = new string[1]{ "N/A" };
      this.airFlow = 0;
      this.metricMeasurements = false;
      this.allowsSampleExclusion = false;
      this.requiresReplacementOfExcluded = false;
      this.maxAllowedSamplesExcluded = (short) 0;
      this.usesLargestParticleToConsider = false;
      this.RoomAreaSquareFeet = 0M;
    }

    public static ManualReportConfiguration Copy
    {
      get
      {
        ManualReportConfiguration copy = new ManualReportConfiguration();
        copy.AirFlowIndex = ManualReportConfiguration.instance.AirFlowIndex;
        copy.RoomArea = ManualReportConfiguration.instance.RoomArea;
        copy.RoomStatusIndex = ManualReportConfiguration.instance.RoomStatusIndex;
        copy.ClassLevelIndex = ManualReportConfiguration.instance.ClassLevelIndex;
        copy.CutPointsSizesMicrometersSpecified = ManualReportConfiguration.instance.cutPointsSizesMicrometersSpecified;
        return copy;
      }
    }

    public static ManualReportConfiguration Instance => ManualReportConfiguration.instance;

    public override bool IsValidRoomStatusAndClass(int roomStatusIndex, int classLevelIndex)
    {
      return true;
    }

    public override bool IsMinimumSampleTimeRequired => false;

    public override int RoomStatusIndex
    {
      get => base.RoomStatusIndex;
      set
      {
        base.RoomStatusIndex = value;
        this.CalculateConcentrationLimitsAndMinimumSampleVolumesForSpecifiedChannelSizesAndClassLevel();
      }
    }

    protected override Decimal CalculateConcentrationLimitNumberOfParticlePerVolume(
      Decimal particleSize)
    {
      return 0M;
    }

    protected override Decimal CalculateMinimumSampleVolume(
      Decimal concentrationLimitsNumberOfParticlesPerCubicMetre)
    {
      return 0M;
    }

    protected override Decimal ConcentrationLimitNumberOfParticlesPerVolume(Decimal particleSize)
    {
      return 0M;
    }

    public override int MinimumNumberOfSampleLocationsForAirFlowAndArea => 1;

    public override int MinimumNumberOfSamplesPerZoneForSamples => 1;

    public override int MinimumNumberOfSamplesPerLocation => 1;

    public override Decimal MinimumSampleTimePerLocationSeconds => 60M;

    public override bool Uses95UCL => false;

    public override bool UsesStandardError => false;

    public override VolumeType VolumeUnits => VolumeType.FeetCubed;
  }
}
