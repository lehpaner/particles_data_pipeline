﻿// Decompiled with JetBrains decompiler
// Type: TSI.IRecipe
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Globals;

#nullable disable
namespace TSI
{
  public interface IRecipe
  {
    int RecipeId { get; set; }

    string Name { get; set; }

    bool IsValid { get; }

    Decimal[] CutPointsSizesMicrometersSpecified { get; }

    bool[] ChannelEnable { get; }

    bool[] AlarmEnable { get; }

    uint[] AlarmThreshold { get; }

    TimeSpan SampleTime { get; set; }

    TimeSpan HoldTime { get; set; }

    TimeSpan DelayTime { get; set; }

    uint Cycles { get; set; }

    SampleCountMode SamplingMode { get; set; }

    ushort AlarmThresholdMode { get; set; }

    bool Modified { get; set; }

    ushort[] ChannelSizes { get; }

    VolumeType VolumeDisplayUnit { get; set; }
  }
}
