﻿// Decompiled with JetBrains decompiler
// Type: TSI.TSIStrings
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI
{
  public static class TSIStrings
  {
    public static string DefaultZoneName = "None";
    public static string DefaultRecipeName = "Default";
    public static string Location = nameof (Location);
    public static string UnknownName = "unknown";
    public static string Recipe = nameof (Recipe);
    public static string TSIAdmin = nameof (TSIAdmin);
    public static string SuperUser = nameof (SuperUser);
    public static string Settings = nameof (Settings);
    public static string TrakProLiteSecure = "TrakPro Lite Secure";
    public static string TSI = nameof (TSI);
    public static string[] FlowStatusStrings = new string[3]
    {
      "OK",
      "Error",
      "Stopped"
    };
    public static string ConnectMessage = "Connecting to Device...";
    public static string ReadyMessage = "Ready";
    public static string ReadingSampleRecords = "Reading Sample Records...";
    public static string ReadingDeviceConfiguration = "Reading Device Configuration...";
    public static string UpdatingZoneConfiguration = "Updating Zone Configuration...";
    public static string UpdatingRecipeConfiguration = "Updating Recipe Configuration...";
    public static string UpdatingLocationConfiguration = "Updating Location Configuration...";
    public static string DeletingAllSampleRecords = "Deleting All Sample Records...";
    public static string AttemptingToUnlockDevice = "Attempting to unlock device...";
    public static string CleaningUp = "Cleaning up...";
    public static string UnlockConnectedDevices = "Unlocking connected devices...";
    public static string channelTypeTotal = "Total";
    public static string channelTypeViable = "Viable";
  }
}
