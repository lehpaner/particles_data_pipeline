﻿// Decompiled with JetBrains decompiler
// Type: TSI.ZoneConfig
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Collections.Generic;

#nullable disable
namespace TSI
{
  public class ZoneConfig : ModbusMap2Zone
  {
    private List<ILocation> locations;

    public ZoneConfig(ModbusMap2Zone zone)
      : base(zone)
    {
      this.locations = new List<ILocation>();
      this.Recipe = new ModbusMap2Recipe(-1);
    }

    public List<ILocation> Locations
    {
      get => this.locations;
      set => this.locations = value;
    }
  }
}
