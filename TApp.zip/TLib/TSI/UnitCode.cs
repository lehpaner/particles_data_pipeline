﻿// Decompiled with JetBrains decompiler
// Type: TSI.UnitCode
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI
{
  public enum UnitCode
  {
    NA,
    F,
    C,
    Percent,
    ft_min,
    m_sec,
    ft3_min,
    m3_sec,
    m3_hr,
    l_sec,
    ppm,
    inH2O,
    PA,
    hPA,
    kPA,
    mmHg,
    cmHg,
    inHg,
    mmH2O,
    cmH2O,
    ft_sec,
  }
}
