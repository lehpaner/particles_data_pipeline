﻿// Decompiled with JetBrains decompiler
// Type: TSI.ModbusMap2Device
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.Serialization;
using System.Security.Permissions;
using TrakProLiteClassLibrary;
using TSI.Communication;

#nullable disable
namespace TSI
{
  [Serializable]
  public class ModbusMap2Device : IInstrument, ISerializable, IDeserializationCallback
  {
    private bool connected;
    private bool locked;
    public ushort mapRevRegister = 200;
    private ushort firmwareVersion;
    private string algorithmId1 = string.Empty;
    private string algorithmId2 = string.Empty;
    public ushort supportedMeasurements;
    public Decimal nominalFlowRate;
    public FlowUnits flowUnit;
    private ushort numChannels;
    private bool handheld;
    public bool tempProbe;
    public bool humidityProbe;
    public bool printer;
    private bool varBins;
    private bool unicode;
    private ushort deviceFeatures;
    private ushort deviceFeatures2;
    private bool viableCounts;
    public uint recCount;
    private ushort numberOfZones;
    private ushort zoneNameLength;
    private ushort locCount;
    private ushort locLabelLength;
    public ushort rcpCount;
    private ushort rcpLabelLength;
    public ushort state;
    public string model;
    public string serial;
    private DateTime lastCalibrationDate = DateTime.MinValue;
    private DateTime calibrationDueDate = DateTime.MinValue;
    public ushort[] channelSize = new ushort[16];
    private RecipeList recipes;
    [NonSerialized]
    private List<ModbusMap2Recipe> tempRecipeList;
    [NonSerialized]
    private List<string> tempLocationList;
    private LocationList locations;
    public List<ModbusMap2Record> records;
    private ZoneList zones;
    public bool isDImode;
    public ushort diUserId;
    private ConnectionType connType;
    public string diPassword;
    public ushort diPasswordMaxLen;
    public ushort diNumUserPasswords;
    public ushort diTimeout;

    public ModbusMap2Device()
    {
      this.recipes = new RecipeList();
      this.locations = new LocationList();
      this.records = new List<ModbusMap2Record>();
      this.zones = new ZoneList();
    }

    protected ModbusMap2Device(SerializationInfo info, StreamingContext context)
    {
      foreach (MemberInfo field in (MemberInfo[]) this.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
      {
        try
        {
          ((FieldInfo) field).SetValue((object) this, info.GetValue(field.Name, ((FieldInfo) field).FieldType));
        }
        catch (Exception ex)
        {
          switch (field.Name)
          {
            case nameof (recipes):
              this.tempRecipeList = (List<ModbusMap2Recipe>) info.GetValue(nameof (recipes), typeof (List<ModbusMap2Recipe>));
              continue;
            case nameof (locations):
              this.tempLocationList = (List<string>) info.GetValue(nameof (locations), typeof (List<string>));
              continue;
            default:
              continue;
          }
        }
      }
    }

    void IDeserializationCallback.OnDeserialization(object sender)
    {
      if (this.tempRecipeList != null)
      {
        ushort index = 0;
        this.recipes = new RecipeList();
        foreach (IRecipe tempRecipe in this.tempRecipeList)
        {
          this.recipes.Add(tempRecipe);
          this.recipes[(int) index].RecipeId = (int) index++;
        }
      }
      if (this.tempLocationList == null)
        return;
      this.locations = new LocationList();
      ushort locationId = 0;
      foreach (string tempLocation in this.tempLocationList)
      {
        this.locations.Add((ILocation) new ModbusMap2Location((int) locationId, tempLocation, -1));
        ++locationId;
      }
    }

    [SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.SerializationFormatter)]
    public void GetObjectData(SerializationInfo info, StreamingContext context)
    {
    }

    public bool Connected
    {
      get => this.connected;
      set => this.connected = value;
    }

    public bool Locked
    {
      get => this.locked;
      set => this.locked = value;
    }

    public ushort FirmwareVersion
    {
      get => this.firmwareVersion;
      set => this.firmwareVersion = value;
    }

    public string AlgorithmId1
    {
      get => this.algorithmId1;
      set => this.algorithmId1 = value;
    }

    public string AlgorithmId2
    {
      get => this.algorithmId2;
      set => this.algorithmId2 = value;
    }

    public string AlgorithmVersion => this.algorithmId1;

    public FlowUnits FlowUnits
    {
      get => this.flowUnit;
      set => this.flowUnit = value;
    }

    public Decimal FlowRateLitresPerMinute
    {
      get
      {
        if (this.flowUnit == FlowUnits.LPM)
          return this.nominalFlowRate;
        return this.nominalFlowRate == 1.77M ? 50.0M : this.nominalFlowRate * 28.3M;
      }
    }

    public Decimal MinimumCutPointSize => Convert.ToDecimal(this.channelSize[0]);

    public Decimal MaximumCutPointSize
    {
      get => Convert.ToDecimal(this.channelSize[(int) this.numChannels - 1]);
    }

    public Decimal[] CalibratedCutPointSizesMicrometres
    {
      get
      {
        Decimal[] sizesMicrometres = new Decimal[(int) this.numChannels];
        for (int index = 0; index < (int) this.numChannels; ++index)
          sizesMicrometres[index] = (Decimal) this.channelSize[index] / 1000M;
        return sizesMicrometres;
      }
    }

    public ushort NumberOfChannels
    {
      get => this.numChannels;
      set => this.numChannels = value;
    }

    public bool HandHeld
    {
      get => this.handheld;
      set => this.handheld = value;
    }

    public bool VariableBins
    {
      get => this.varBins;
      set => this.varBins = value;
    }

    public bool Unicode
    {
      get => this.unicode;
      set => this.unicode = value;
    }

    public ushort DeviceFeatures
    {
      get => this.deviceFeatures;
      set => this.deviceFeatures = value;
    }

    public ushort DeviceFeatures2
    {
      get => this.deviceFeatures2;
      set => this.deviceFeatures2 = value;
    }

    public bool ViableCounts
    {
      get => this.viableCounts;
      set => this.viableCounts = value;
    }

    public uint NumberOfSamples => (uint) this.records.Count;

    public List<ISample> SampleRecords
    {
      get => new List<ISample>((IEnumerable<ISample>) this.records.ToArray());
    }

    public ushort NumberOfZones
    {
      get => this.numberOfZones;
      set => this.numberOfZones = value;
    }

    public ushort ZoneNameLength
    {
      get => this.zoneNameLength;
      set => this.zoneNameLength = value;
    }

    public ushort NumberOfLocations
    {
      get => this.locCount;
      set => this.locCount = value;
    }

    public ushort LocationLabelLength
    {
      get => this.locLabelLength;
      set => this.locLabelLength = value;
    }

    public ushort NumberOfRecipes
    {
      get => this.rcpCount;
      set => this.rcpCount = value;
    }

    public ushort RecipeLabelLength
    {
      get => this.rcpLabelLength;
      set => this.rcpLabelLength = value;
    }

    public string ModelNumber => this.model;

    public string SerialNumber => this.serial;

    public string Name => string.Format("{0} {1}", (object) this.model, (object) this.serial);

    public DateTime LastCalibrationDate
    {
      get => this.lastCalibrationDate;
      set => this.lastCalibrationDate = value;
    }

    public DateTime CalibrationDueDate
    {
      get => this.calibrationDueDate;
      set => this.calibrationDueDate = value;
    }

    public ushort[] ChannelSizes
    {
      get => this.channelSize;
      set => this.channelSize = value;
    }

    public RecipeList Recipes
    {
      get => this.recipes;
      set => this.recipes = value;
    }

    public LocationList Locations
    {
      get => this.locations;
      set => this.locations = value;
    }

    public ZoneList Zones
    {
      get => this.zones;
      set => this.zones = value;
    }

    public void InitializeConfigurationLists(int numZones, int numLocations, int numRecipes)
    {
      this.InitializeZoneList(numZones);
      this.InitializeLocationList(numLocations);
      this.InitializeRecipeList(numRecipes);
    }

    private void InitializeZoneList(int numZones)
    {
      if (numZones <= 0)
        return;
      this.zones.Add((IZone) new ModbusMap2Zone(0));
      this.zones[0].Name = TSIStrings.DefaultZoneName;
      this.zones[0].RecipeId = 0;
      for (int id = 1; id <= numZones; ++id)
        this.zones.Add((IZone) new ModbusMap2Zone(id));
    }

    private void InitializeLocationList(int numLocations)
    {
      if (numLocations <= 0)
        return;
      this.locations.Add((ILocation) new ModbusMap2Location(0));
      this.locations[0].Name = TSIStrings.UnknownName;
      this.locations[0].ZoneId = this.HasZones ? 0 : -1;
      this.locations[0].Locked = true;
      for (int locationId = 1; locationId <= numLocations; ++locationId)
        this.locations.Add((ILocation) new ModbusMap2Location(locationId));
    }

    private void InitializeRecipeList(int numRecipes)
    {
      if (numRecipes <= 0)
        return;
      for (int id = 0; id < numRecipes; ++id)
        this.recipes.Add((IRecipe) new ModbusMap2Recipe(id, this.ChannelSizes));
      this.recipes[0].Name = TSIStrings.DefaultRecipeName;
    }

    public bool ZoneLocked(int zoneId)
    {
      if (this.Locked || this.zones[zoneId].Name == TSIStrings.DefaultZoneName)
        return true;
      foreach (ILocation location in this.locations.FindAll((Predicate<ILocation>) (loc => loc.ZoneId == zoneId)))
      {
        if (location.Locked)
          return true;
      }
      return false;
    }

    public int FindZone(string zoneName)
    {
      return this.zones.FindIndex((Predicate<IZone>) (z => z.Name == zoneName));
    }

    public void RemoveLocation(string locName)
    {
      int index = this.locations.FindIndex((Predicate<ILocation>) (loc => loc.Name.Equals(locName)));
      if (index == -1)
        return;
      this.Locations[index].Name = string.Empty;
      this.Locations[index].ZoneId = 0;
    }

    public void RemoveAllLocations()
    {
      for (int index = 1; index < this.locations.Count; ++index)
      {
        this.locations[index].Name = string.Empty;
        this.locations[index].ZoneId = 0;
      }
    }

    public bool ReplaceLocationName(string oldName, string newName)
    {
      int index = this.Locations.FindIndex((Predicate<ILocation>) (loc => loc.Name == oldName));
      if (index == -1)
        index = this.Locations.FindIndex((Predicate<ILocation>) (loc => loc.Name == oldName + "\0"));
      if (index == -1)
        return false;
      this.locations[index].Name = newName;
      this.locations[index].Modified = true;
      return true;
    }

    public bool RecipeLocked(int recipeId)
    {
      return this.HasZones && this.Zones.FindAll((Predicate<IZone>) (z => z.RecipeId == recipeId)).Count > 0;
    }

    public DeviceType DeviceType => DeviceType.ModbusMap2;

    public bool HasZones => this.mapRevRegister > (ushort) 200 || this.numberOfZones != (ushort) 0;

    public bool HasRecipes => this.rcpCount > (ushort) 0;

    public bool HasDataIntegrity { get; set; }

    public bool IsDIMode
    {
      get => this.isDImode;
      set => this.isDImode = value;
    }

    public bool IsDIUserLoggedIn
    {
      get => this.diUserId != (ushort) 0 && !string.IsNullOrEmpty(this.diPassword);
    }

    public ushort DIUserId
    {
      get => this.diUserId;
      set => this.diUserId = value;
    }

    public ConnectionType ConnType
    {
      get => this.connType;
      set => this.connType = value;
    }

    public bool[] IsChannelViable
    {
      get
      {
        bool[] isChannelViable = new bool[(int) this.numChannels];
        for (int index = 0; index < (int) this.numChannels; ++index)
        {
          isChannelViable[index] = false;
          if (this.ViableCounts && index >= (int) this.numChannels / 2)
            isChannelViable[index] = true;
        }
        return isChannelViable;
      }
    }
  }
}
