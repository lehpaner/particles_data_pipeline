﻿// Decompiled with JetBrains decompiler
// Type: TSI.ILocation
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI
{
  public interface ILocation
  {
    string Name { get; set; }

    int LocationId { get; }

    int ZoneId { get; set; }

    bool IsValid { get; }

    bool Locked { get; set; }

    bool Modified { get; set; }
  }
}
