﻿// Decompiled with JetBrains decompiler
// Type: TSI.Data.Location9303
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI.Data
{
  public class Location9303 : ILocation
  {
    private int locationId;
    private string name = string.Empty;
    private bool locked;
    private bool modified;

    public Location9303(int locationId, string name)
    {
      this.locationId = locationId;
      this.name = name;
      this.modified = false;
      this.locked = false;
    }

    public int LocationId
    {
      get => this.locationId;
      set => this.locationId = value;
    }

    public string Name
    {
      get => this.name;
      set => this.name = value;
    }

    public int ZoneId
    {
      get => -1;
      set
      {
      }
    }

    public bool Locked
    {
      get => this.locked;
      set => this.locked = value;
    }

    public bool Modified
    {
      get => this.modified;
      set => this.modified = value;
    }

    public bool IsValid => !string.IsNullOrEmpty(this.name);
  }
}
