﻿// Decompiled with JetBrains decompiler
// Type: TSI.Data.Statistics_9303
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.ComponentModel;

#nullable disable
namespace TSI.Data
{
  public class Statistics_9303
  {
    private int ch1Min;
    private int ch2Min;
    private int ch3Min;
    private int ch1Max;
    private int ch2Max;
    private int ch3Max;
    private double ch1Avg;
    private double ch2Avg;
    private double ch3Avg;
    private double ch1StdDev;
    private double ch2StdDev;
    private double ch3StdDev;
    private double ch1StdErr;
    private double ch2StdErr;
    private double ch3StdErr;
    private Decimal ch1UCL95;
    private Decimal ch2UCL95;
    private Decimal ch3UCL95;

    public Statistics_9303(BindingList<Record_9303> tmp)
    {
      double[] lstNum1 = new double[tmp.Count];
      double[] lstNum2 = new double[tmp.Count];
      double[] lstNum3 = new double[tmp.Count];
      for (int index = 0; index < tmp.Count; ++index)
      {
        lstNum1[index] = (double) tmp[index].Ch1Count;
        lstNum2[index] = (double) tmp[index].Ch2Count;
        lstNum3[index] = (double) tmp[index].Ch3Count;
      }
      TSI.Math.Statistics.Statistics statistics = new TSI.Math.Statistics.Statistics();
      this.ch1Min = (int) statistics.Min(lstNum1);
      this.ch2Min = (int) statistics.Min(lstNum2);
      this.ch3Min = (int) statistics.Min(lstNum3);
      this.ch1Max = (int) statistics.Max(lstNum1);
      this.ch2Max = (int) statistics.Max(lstNum2);
      this.ch3Max = (int) statistics.Max(lstNum3);
      this.ch1Avg = statistics.Average(lstNum1);
      this.ch2Avg = statistics.Average(lstNum2);
      this.ch3Avg = statistics.Average(lstNum3);
      this.ch1StdDev = statistics.StandardDeviation(lstNum1);
      this.ch2StdDev = statistics.StandardDeviation(lstNum2);
      this.ch3StdDev = statistics.StandardDeviation(lstNum3);
      this.ch1StdErr = statistics.StandardError(this.ch1StdDev, lstNum1.Length);
      this.ch2StdErr = statistics.StandardError(this.ch2StdDev, lstNum2.Length);
      this.ch3StdErr = statistics.StandardError(this.ch3StdDev, lstNum3.Length);
      this.ch1UCL95 = statistics.UpperConfidenceLevel95(lstNum1);
      this.ch2UCL95 = statistics.UpperConfidenceLevel95(lstNum2);
      this.ch3UCL95 = statistics.UpperConfidenceLevel95(lstNum3);
    }

    public int Ch1Min => this.ch1Min;

    public int Ch2Min => this.ch2Min;

    public int Ch3Min => this.ch3Min;

    public int Ch1Max => this.ch1Max;

    public int Ch2Max => this.ch2Max;

    public int Ch3Max => this.ch3Max;

    public double Ch1Avg => this.ch1Avg;

    public double Ch2Avg => this.ch2Avg;

    public double Ch3Avg => this.ch3Avg;

    public double Ch1StdDev => this.ch1StdDev;

    public double Ch2StdDev => this.ch2StdDev;

    public double Ch3StdDev => this.ch3StdDev;

    public double Ch1StdErr => this.ch1StdErr;

    public double Ch2StdErr => this.ch2StdErr;

    public double Ch3StdErr => this.ch3StdErr;

    public Decimal Ch1UCL95 => this.ch1UCL95;

    public Decimal Ch2UCL95 => this.ch2UCL95;

    public Decimal Ch3UCL95 => this.ch3UCL95;
  }
}
