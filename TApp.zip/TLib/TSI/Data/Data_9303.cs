﻿// Decompiled with JetBrains decompiler
// Type: TSI.Data.Data_9303
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;

#nullable disable
namespace TSI.Data
{
  public class Data_9303
  {
    private char[] delimiters;
    private List<Storage_9303> storage;

    public Data_9303(char[] delimiters)
    {
      Trace.WriteLine("Data_9303: Constructor", "Info");
      this.delimiters = delimiters;
      this.storage = new List<Storage_9303>();
    }

    public Storage_9303 AddStorage(Storage_9303 st)
    {
      if (this.storage != null)
      {
        Storage_9303 storage9303 = this.storage.Find((Predicate<Storage_9303>) (t => t.id == st.id));
        if (storage9303 != null)
        {
          foreach (Record_9303 record9303 in st.data)
          {
            Record_9303 rec = record9303;
            if (storage9303.data.Find((Predicate<Record_9303>) (r => r.DateTime == rec.DateTime && (int) r.SampleID == (int) rec.SampleID)) == null)
              storage9303.data.Add(rec);
          }
          return storage9303;
        }
        this.storage.Add(st);
        return st;
      }
      this.storage = new List<Storage_9303>();
      this.storage.Add(st);
      return st;
    }

    public List<Record_9303> ParseData(string id, string data)
    {
      if (!string.IsNullOrEmpty(data) && data.Length > 0)
      {
        data = data.Remove(0, data.IndexOf('\n') + 1);
        data = data.Remove(0, data.IndexOf('\n') + 1);
        List<Record_9303> data1 = new List<Record_9303>();
        string[] strArray1 = data.Split(this.delimiters, StringSplitOptions.RemoveEmptyEntries);
        if (strArray1.Length > 0)
        {
          for (int index = 0; index < strArray1.Length; ++index)
          {
            string[] strArray2 = strArray1[index].Split(',');
            if (strArray2.Length < 12)
              return (List<Record_9303>) null;
            string s = strArray2[2] + " " + strArray2[3];
            DateTime dateTime = new DateTime();
            DateTime exact = DateTime.ParseExact(s, "MM/dd/yy HH:mm:ss", (IFormatProvider) new DateTimeFormatInfo());
            string[] strArray3 = strArray2[4].Split(':');
            string[] strArray4 = strArray2[5].Split(':');
            strArray2[6] = strArray2[6].Remove(strArray2[6].Length - 2);
            strArray2[8] = strArray2[8].Remove(strArray2[8].Length - 2);
            strArray2[10] = strArray2[10].Remove(strArray2[10].Length - 2);
            int result1 = 0;
            int result2 = 0;
            int result3 = 0;
            int result4 = 0;
            int result5 = 0;
            int.TryParse(strArray2[0], out result1);
            int.TryParse(strArray2[1], out result2);
            int.TryParse(strArray2[7], out result3);
            int.TryParse(strArray2[9], out result4);
            int.TryParse(strArray2[11], out result5);
            Record_9303 record9303 = new Record_9303(result1, result2, exact, new TimeSpan(0, Convert.ToInt32(strArray3[0]), Convert.ToInt32(strArray3[1])), new TimeSpan(0, Convert.ToInt32(strArray4[0]), Convert.ToInt32(strArray4[1])), strArray2[6], result3, strArray2[8], result4, strArray2[10], result5);
            record9303.Ch1Count -= record9303.Ch2Count;
            record9303.Ch2Count -= record9303.Ch3Count;
            data1.Add(record9303);
          }
          if (this.storage == null)
            this.storage = new List<Storage_9303>();
          if (this.storage.Find((Predicate<Storage_9303>) (t => t.id == id)) == null)
            this.storage.Add(new Storage_9303()
            {
              data = data1,
              id = id
            });
          return data1;
        }
      }
      return (List<Record_9303>) null;
    }

    public Record_9303 GetRecord(string id, DateTime dt)
    {
      return this.storage.Find((Predicate<Storage_9303>) (t => t.id == id))?.data.Find((Predicate<Record_9303>) (r => r.DateTime == dt));
    }

    public Record_9303 GetRecord(string id, int recNum)
    {
      return this.storage.Find((Predicate<Storage_9303>) (t => t.id == id))?.data.Find((Predicate<Record_9303>) (r => (int) r.SampleID == recNum));
    }

    public void DeleteData(string id)
    {
      this.storage.Find((Predicate<Storage_9303>) (t => t.id == id))?.data.Clear();
    }

    public void DeleteDevice(string id)
    {
      Storage_9303 storage9303 = this.storage.Find((Predicate<Storage_9303>) (t => t.id == id));
      if (storage9303 == null)
        return;
      this.storage.Remove(storage9303);
    }

    public Storage_9303 GetStorage(string id)
    {
      return this.storage.Find((Predicate<Storage_9303>) (t => t.id == id));
    }
  }
}
