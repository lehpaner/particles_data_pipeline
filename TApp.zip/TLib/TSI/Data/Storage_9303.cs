﻿// Decompiled with JetBrains decompiler
// Type: TSI.Data.Storage_9303
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using TrakProLiteClassLibrary;
using TSI.Communication;

#nullable disable
namespace TSI.Data
{
  [Serializable]
  public class Storage_9303 : IInstrument, IDeserializationCallback
  {
    private const Decimal flowRateLitresPerMinute = 2.83M;
    public string id;
    public List<Record_9303> data = new List<Record_9303>();
    private bool connected;
    private bool locked;
    private LocationList locations = new LocationList();

    void IDeserializationCallback.OnDeserialization(object sender)
    {
      this.locations = new LocationList();
    }

    public bool Connected
    {
      get => this.connected;
      set => this.connected = value;
    }

    public bool Locked
    {
      get => this.locked;
      set => this.locked = value;
    }

    public bool HasZones => false;

    public bool ZoneLocked(int id) => false;

    public bool RecipeLocked(int id) => false;

    public DeviceType DeviceType => DeviceType.Tsi9303;

    public ushort FirmwareVersion => 0;

    public string Name => this.id;

    public FlowUnits FlowUnits => FlowUnits.CFM;

    public List<ISample> SampleRecords
    {
      get => new List<ISample>((IEnumerable<ISample>) this.data.ToArray());
    }

    public LocationList Locations => this.locations;

    public ushort RecipeLabelLength => 0;

    public RecipeList Recipes => new RecipeList();

    public ZoneList Zones => (ZoneList) null;

    public bool HasRecipes => false;

    public bool VariableBins => true;

    public bool ViableCounts => false;

    public bool Unicode => false;

    public Decimal FlowRateLitresPerMinute => 2.83M;

    public string ModelNumber => this.id.Substring(0, 4);

    public string SerialNumber => this.id.Substring(6);

    public string AlgorithmVersion => string.Empty;

    public DateTime LastCalibrationDate => DateTime.MinValue;

    public DateTime CalibrationDueDate => DateTime.MinValue;

    public Decimal MinimumCutPointSize => throw new NotImplementedException();

    public Decimal MaximumCutPointSize => throw new NotImplementedException();

    public ushort NumberOfChannels => 3;

    public Decimal[] CalibratedCutPointSizesMicrometres
    {
      get => new Decimal[3]{ 0.3M, 1.0M, 5.0M };
    }

    public ushort[] ChannelSizes
    {
      get
      {
        return new ushort[3]
        {
          (ushort) 300,
          (ushort) 500,
          (ushort) 1000
        };
      }
    }

    public uint NumberOfSamples => (uint) this.data.Count;

    public bool HasDataIntegrity => false;

    public bool IsDIMode
    {
      get => false;
      set
      {
      }
    }

    public bool IsDIUserLoggedIn => false;

    public ushort DIUserId => 0;

    public ConnectionType ConnType => ConnectionType.USB;

    public bool[] IsChannelViable => new bool[3];
  }
}
