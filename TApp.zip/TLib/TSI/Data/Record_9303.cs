﻿// Decompiled with JetBrains decompiler
// Type: TSI.Data.Record_9303
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Globalization;
using TrakProLiteClassLibrary;
using TSI.Globals;

#nullable disable
namespace TSI.Data
{
  [Serializable]
  public class Record_9303 : ISample
  {
    private const double flow = 0.1;
    private int locationId;
    private int recNum;
    private int loc;
    private DateTime dateTime;
    private TimeSpan sampleT;
    private string recipeSampleTime;
    private TimeSpan holdT;
    private string ch1Size;
    private int ch1Cnt;
    private string ch2Size;
    private int ch2Cnt;
    private string ch3Size;
    private int ch3Cnt;
    private RecordType recType = RecordType.Differential;
    private UnitType unitType = UnitType.Counts;
    private VolumeType volumeType = VolumeType.FeetCubed;

    public Record_9303()
    {
    }

    public Record_9303(
      int r,
      int locId,
      DateTime dt,
      TimeSpan sampleTime,
      TimeSpan holdTime,
      string ch1,
      int ch1c,
      string ch2,
      int ch2c,
      string ch3,
      int ch3c)
    {
      this.recNum = r;
      this.loc = locId;
      this.dateTime = dt;
      this.sampleT = sampleTime;
      this.holdT = holdTime;
      this.ch1Size = ch1;
      this.ch1Cnt = ch1c;
      this.ch2Size = ch2;
      this.ch2Cnt = ch2c;
      this.ch3Size = ch3;
      this.ch3Cnt = ch3c;
    }

    public uint SampleID
    {
      get => (uint) this.recNum;
      set => this.recNum = (int) value;
    }

    public int LocationId
    {
      get => this.locationId;
      set => this.locationId = value;
    }

    public DateTime DateTime
    {
      get => this.dateTime;
      set => this.dateTime = value;
    }

    public TimeSpan SampleTime
    {
      get => this.sampleT;
      set => this.sampleT = value;
    }

    public string RecipeSampleTime
    {
      get => this.recipeSampleTime;
      set => this.recipeSampleTime = value;
    }

    public TimeSpan HoldTime
    {
      get => this.holdT;
      set => this.holdT = value;
    }

    public string Ch1Size
    {
      get => this.ch1Size;
      set => this.ch1Size = value;
    }

    public int Ch1Count
    {
      get
      {
        int ch1Count;
        switch (this.recType)
        {
          case RecordType.Cumulative:
            ch1Count = this.ch1Cnt + this.ch2Cnt + this.ch3Cnt;
            break;
          default:
            ch1Count = this.ch1Cnt;
            break;
        }
        switch (this.unitType)
        {
          case UnitType.Concentration:
            return !(this.Volume > 0M) ? 0 : (int) Math.Round((Decimal) ch1Count / this.Volume);
          default:
            return ch1Count;
        }
      }
      set => this.ch1Cnt = value;
    }

    public string Ch2Size
    {
      get => this.ch2Size;
      set => this.ch2Size = value;
    }

    public int Ch2Count
    {
      get
      {
        int ch2Count;
        switch (this.recType)
        {
          case RecordType.Cumulative:
            ch2Count = this.ch2Cnt + this.ch3Cnt;
            break;
          default:
            ch2Count = this.ch2Cnt;
            break;
        }
        switch (this.unitType)
        {
          case UnitType.Concentration:
            return !(this.Volume > 0M) ? 0 : (int) Math.Round((Decimal) ch2Count / this.Volume);
          default:
            return ch2Count;
        }
      }
      set => this.ch2Cnt = value;
    }

    public string Ch3Size
    {
      get => this.ch3Size;
      set => this.ch3Size = value;
    }

    public int Ch3Count
    {
      get
      {
        switch (this.unitType)
        {
          case UnitType.Concentration:
            return !(this.Volume > 0M) ? 0 : (int) Math.Round((Decimal) this.ch3Cnt / this.Volume);
          default:
            return this.ch3Cnt;
        }
      }
      set => this.ch3Cnt = value;
    }

    public RecordType CountMode
    {
      get => this.recType;
      set => this.recType = value;
    }

    public UnitType UnitType
    {
      get => this.unitType;
      set => this.unitType = value;
    }

    public VolumeType VolumeUnits
    {
      get => this.volumeType;
      set => this.volumeType = value;
    }

    public Decimal Volume
    {
      get
      {
        switch (this.volumeType)
        {
          case VolumeType.FeetCubed:
            return (Decimal) (1.0 / 600.0 * this.sampleT.TotalSeconds);
          case VolumeType.MetresCubed:
            return Convert.ToDecimal(0.1) * 0.0283M / 60M * Convert.ToDecimal(this.sampleT.TotalSeconds);
          case VolumeType.Litres:
            return Convert.ToDecimal(0.1) * 28.3M / 60M * Convert.ToDecimal(this.sampleT.TotalSeconds);
          default:
            return Convert.ToDecimal(double.NaN);
        }
      }
      set
      {
      }
    }

    public int Loc
    {
      get => this.loc;
      set => this.loc = value;
    }

    public ChannelCollection Channels
    {
      get
      {
        ChannelCollection channels = new ChannelCollection();
        channels.Add((IChannel) new Channel(false, false, Convert.ToDecimal(this.ch1Size, (IFormatProvider) CultureInfo.InvariantCulture), (Decimal) this.ch1Cnt));
        channels.Add((IChannel) new Channel(false, false, Convert.ToDecimal(this.ch2Size, (IFormatProvider) CultureInfo.InvariantCulture), (Decimal) this.ch2Cnt));
        channels.Add((IChannel) new Channel(false, false, Convert.ToDecimal(this.ch3Size, (IFormatProvider) CultureInfo.InvariantCulture), (Decimal) this.ch3Cnt));
        return channels;
      }
    }

    public ChannelCollection ViableChannels => new ChannelCollection();

    public bool AlarmActive => false;

    public FlowStatus FlowStatus => FlowStatus.OK;

    public Decimal Humidity => 0M;

    public UnitCode HumidityUnits => UnitCode.NA;

    public ushort DeviceStatus => 0;

    public ushort InstrumentStatus => 0;

    public bool LaserStatus => true;

    public string Location => this.loc.ToString();

    public Decimal Temperature => 0M;

    public TemperatureType TemperatureUnits => TemperatureType.NA;

    public DateTime TimeStamp => this.dateTime;

    public Decimal VolumeLitres
    {
      get => Convert.ToDecimal(0.1) * 28.3M / 60M * Convert.ToDecimal(this.sampleT.TotalSeconds);
    }

    public double AverageFlowRateCubicMetresPerSecond
    {
      get => (double) (Convert.ToDecimal(0.1) * 0.0283M / 60M);
    }

    public float PrecisionFlowRate => 0.0f;

    public Decimal AirVelocity => 0M;

    public UnitCode AirVelocityUnits => UnitCode.NA;

    public Decimal GetParticleCount(
      IChannel channel,
      bool normalized,
      VolumeType normalizedParticleVolume)
    {
      Decimal particleCount = Convert.ToDecimal(channel.ParticleCount);
      return normalized ? Sample.Normalize(particleCount, normalizedParticleVolume, this.VolumeLitres) : particleCount;
    }

    public bool Normalized => this.unitType != UnitType.Counts;

    public ushort ViableDetectionSensitivity => 0;

    public ushort DIUserId => 0;

    public string DIUsername => string.Empty;
  }
}
