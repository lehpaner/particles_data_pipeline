﻿// Decompiled with JetBrains decompiler
// Type: TSI.Globals.Preferences
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using TSI.Communication;

#nullable disable
namespace TSI.Globals
{
  public class Preferences
  {
    private RecordType countMode;
    private UnitType units;
    private VolumeType volume;
    private TemperatureType temperature;
    private string ipAddress;
    private ConnectionType connType;

    public Preferences()
    {
      this.countMode = RecordType.Cumulative;
      this.units = UnitType.Concentration;
      this.volume = VolumeType.MetresCubed;
      this.temperature = TemperatureType.C;
    }

    public RecordType CountMode
    {
      get => this.countMode;
      set => this.countMode = value;
    }

    public UnitType Units
    {
      get => this.units;
      set => this.units = value;
    }

    public VolumeType Volume
    {
      get => this.volume;
      set => this.volume = value;
    }

    public TemperatureType Temperature
    {
      get => this.temperature;
      set => this.temperature = value;
    }

    public string IPAddress
    {
      get => this.ipAddress;
      set => this.ipAddress = value;
    }

    public ConnectionType ConnectUsing
    {
      get => this.connType;
      set => this.connType = value;
    }
  }
}
