﻿// Decompiled with JetBrains decompiler
// Type: TSI.Globals.ChannelList
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Collections.Generic;

#nullable disable
namespace TSI.Globals
{
  public class ChannelList : List<string>
  {
    public string Channel1 => this[0];

    public string Channel2 => this[1];

    public string Channel3 => this[2];

    public string Channel4 => this[3];

    public string Channel5 => this[4];

    public string Channel6 => this[5];
  }
}
