﻿// Decompiled with JetBrains decompiler
// Type: TSI.Globals.UserPermissions
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TSI.Globals
{
  public class UserPermissions
  {
    public static int NumPermissions = 21;
    private bool[] permissions = new bool[UserPermissions.NumPermissions];

    public bool Allow(UserPerm perm) => this.permissions[(int) perm];

    public void Reset() => Array.Clear((Array) this.permissions, 0, this.permissions.Length);

    public void AllowAll()
    {
      for (int index = 0; index < UserPermissions.NumPermissions; ++index)
        this.permissions[index] = true;
    }

    public bool[] Permissions
    {
      get => this.permissions;
      set => value.CopyTo((Array) this.permissions, 0);
    }
  }
}
