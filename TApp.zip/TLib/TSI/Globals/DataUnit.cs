﻿// Decompiled with JetBrains decompiler
// Type: TSI.Globals.DataUnit
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI.Globals
{
  public enum DataUnit
  {
    COUNT,
    FT3,
    M3,
    MASS,
  }
}
