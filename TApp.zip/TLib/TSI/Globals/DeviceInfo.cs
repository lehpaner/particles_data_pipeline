﻿// Decompiled with JetBrains decompiler
// Type: TSI.Globals.DeviceInfo
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TrakProLiteClassLibrary;

#nullable disable
namespace TSI.Globals
{
  public class DeviceInfo
  {
    private string model;
    private string serial;
    private RecordType countMode;
    private TSI.Globals.TemperatureType temp;
    private ushort numChannels;
    private Decimal[] channels;
    private string algorithmVersion;
    private string units;

    public DeviceInfo(IInstrument instrument, Preferences preferences)
    {
      this.model = instrument.ModelNumber;
      this.serial = instrument.SerialNumber;
      this.algorithmVersion = instrument.AlgorithmVersion;
      this.numChannels = instrument.NumberOfChannels;
      this.channels = instrument.CalibratedCutPointSizesMicrometres;
      this.countMode = preferences.CountMode;
      this.temp = preferences.Temperature;
      if (preferences.Units == UnitType.Concentration)
        this.units = string.Format("# / {0}", (object) StandardStrings.VolumeUnits[(int) preferences.Volume]);
      else
        this.units = "#";
    }

    public string AlgorithmVersion => this.algorithmVersion;

    public string Model => this.model;

    public string Serial => this.serial;

    public ChannelList Channels
    {
      get
      {
        ChannelList channels = new ChannelList();
        for (int index = 0; index < this.channels.Length; ++index)
          channels.Add(string.Format("{0} µm", (object) this.channels[index]));
        return channels;
      }
    }

    public string CountMode
    {
      get
      {
        return this.countMode == RecordType.Differential ? StandardStrings.ParticleCountMode[0] : StandardStrings.ParticleCountMode[1];
      }
    }

    public string Units => this.units;

    public string TemperatureType => this.temp == TSI.Globals.TemperatureType.F ? "°F" : "°C";

    public ushort NumChannels
    {
      get => this.numChannels;
      set => this.numChannels = value;
    }
  }
}
