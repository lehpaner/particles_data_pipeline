﻿// Decompiled with JetBrains decompiler
// Type: TSI.Globals.RecordType
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI.Globals
{
  public enum RecordType
  {
    Differential = 1,
    Cumulative = 2,
    count = 3,
    ft3 = 4,
    m3 = 5,
    litre = 6,
  }
}
