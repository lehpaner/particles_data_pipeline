﻿// Decompiled with JetBrains decompiler
// Type: TSI.Globals.ReportViewerExtensions
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI.Globals
{
  public class ReportViewerExtensions
  {
    public static string PDF = nameof (PDF);
    public static string Excel2003 = nameof (Excel);
    public static string Excel = "EXCELOPENXML";
    public static string Word2003 = "WORD";
    public static string Word = "WORDOPENXML";
    public static string ImageTIFF = "IMAGE";
  }
}
