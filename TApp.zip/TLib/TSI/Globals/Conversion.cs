﻿// Decompiled with JetBrains decompiler
// Type: TSI.Globals.Conversion
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TSI.Globals
{
  public static class Conversion
  {
    public const Decimal LitresPerCubicFoot = 28.3M;
    public const Decimal LitresPerCubicMeter = 1000M;
    public const Decimal CubicMetersPerLitre = 0.001M;
    public const Decimal CubicMetersPerCubicFoot = 0.0283M;
    public const Decimal CubicFeetPerLitre = 0.0353356890459363957597173145M;
    public const double CubicFeetPerCubicMeter = 35.3356890459364;
  }
}
