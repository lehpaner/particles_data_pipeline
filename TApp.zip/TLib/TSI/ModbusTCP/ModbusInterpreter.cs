﻿// Decompiled with JetBrains decompiler
// Type: TSI.ModbusTCP.ModbusInterpreter
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Diagnostics;
using System.Text;
using TSI.Communication;
using TSI.Globals;

#nullable disable
namespace TSI.ModbusTCP
{
  public static class ModbusInterpreter
  {
    public static bool InterpretData(byte[] msg, CurrentAction act, ref ModbusMap2Device device)
    {
      if (device == null)
        device = new ModbusMap2Device();
      if (msg == null)
      {
        Trace.WriteLine("Got msg == null");
        return false;
      }
      bool flag1 = true;
      ushort uint16_1 = Convert.ToUInt16(msg[8]);
      if (uint16_1 == (ushort) 0)
      {
        Trace.WriteLine("Got msgLength == 0");
        return false;
      }
      int num1 = 9;
      bool flag2 = false;
      switch (act)
      {
        case CurrentAction.A_GET_MODEL:
          int index1 = 9;
          for (int index2 = index1; index2 < index1 + (int) uint16_1; index2 += 2)
            Array.Reverse((Array) msg, index2, 2);
          device.model = Encoding.ASCII.GetString(msg, index1, 16);
          device.model = device.model.TrimEnd(new char[1]);
          break;
        case CurrentAction.A_GET_SERIAL:
          int index3 = 9;
          for (int index4 = index3; index4 < index3 + (int) uint16_1; index4 += 2)
            Array.Reverse((Array) msg, index4, 2);
          device.serial = Encoding.ASCII.GetString(msg, index3, (int) uint16_1);
          device.serial = device.serial.TrimEnd(new char[1]);
          break;
        case CurrentAction.A_GET_NUMBER_OF_SAMPLES:
          Array.Reverse((Array) msg, 9, (int) uint16_1);
          device.recCount = BitConverter.ToUInt32(msg, 9);
          break;
        case CurrentAction.A_READ_DEVICE_INFO:
          ModbusInterpreter.InterpretDeviceInfo(msg, (int) uint16_1, ref device);
          break;
        case CurrentAction.A_READ_RECORD:
          ModbusMap2Record rec = new ModbusMap2Record((int) device.NumberOfChannels, device.ViableCounts ? (int) device.NumberOfChannels / 2 : (int) device.NumberOfChannels);
          ModbusInterpreter.InterpretRecord(msg, (int) uint16_1, ref rec, device.HasDataIntegrity);
          device.records.Add(rec);
          break;
        case CurrentAction.A_GET_DEVICE_STATUS:
          Array.Reverse((Array) msg, 9, 2);
          device.state = BitConverter.ToUInt16(msg, 9);
          break;
        case CurrentAction.A_READ_MAPREV_REGISTER:
          Array.Reverse((Array) msg, 9, 2);
          device.mapRevRegister = BitConverter.ToUInt16(msg, 9);
          Array.Reverse((Array) msg, 11, 2);
          device.FirmwareVersion = BitConverter.ToUInt16(msg, 11);
          break;
        case CurrentAction.A_READ_LOCATION_AND_RECIPE_GROUP:
          int startIndex1 = 9;
          int num2 = (int) uint16_1;
          if (flag2)
            num2 = (int) uint16_1 - 8;
          for (int index5 = startIndex1; index5 < startIndex1 + num2; index5 += 2)
            Array.Reverse((Array) msg, index5, 2);
          int uint16_2 = (int) BitConverter.ToUInt16(msg, startIndex1);
          if (uint16_2 <= (int) device.NumberOfLocations)
          {
            string str1 = !device.Unicode ? Encoding.ASCII.GetString(msg, startIndex1 += 2, 32) : Encoding.Unicode.GetString(msg, startIndex1 += 2, 32);
            int length = str1.IndexOf("\0");
            string str2 = length >= 0 ? str1.Substring(0, length) : str1;
            if (!string.IsNullOrEmpty(str2))
              device.Locations[uint16_2].Name = str2;
          }
          int startIndex2 = startIndex1 + 32;
          int uint16_3 = (int) BitConverter.ToUInt16(msg, startIndex2);
          if (uint16_3 <= (int) device.NumberOfRecipes)
          {
            string str3 = !device.Unicode ? Encoding.ASCII.GetString(msg, startIndex2 += 2, 32) : Encoding.Unicode.GetString(msg, startIndex2 += 2, 32);
            int length = str3.IndexOf("\0");
            string str4 = length >= 0 ? str3.Substring(0, length) : str3;
            if (!string.IsNullOrEmpty(str4))
              device.Recipes[uint16_3].Name = str4;
          }
          int startIndex3 = startIndex2 + 32;
          if (device.HasZones)
          {
            ushort uint16_4 = BitConverter.ToUInt16(msg, startIndex3);
            if (uint16_2 <= (int) device.NumberOfLocations && device.Locations[uint16_2].IsValid)
              device.Locations[uint16_2].ZoneId = (int) uint16_4;
            if (flag2)
            {
              int num3;
              int uint16_5 = (int) BitConverter.ToUInt16(msg, num3 = startIndex3 + 2);
              if (uint16_5 > 0 && uint16_5 <= (int) device.NumberOfZones)
              {
                string empty = string.Empty;
                int num4;
                string str5 = !device.Unicode ? Encoding.ASCII.GetString(msg, num4 = num3 + 2, 32) : Encoding.Unicode.GetString(msg, num4 = num3 + 2, 32);
                int length = str5.IndexOf("\0");
                string str6 = length >= 0 ? str5.Substring(0, length) : str5;
                if (!string.IsNullOrEmpty(str6))
                {
                  ((ModbusMap2Zone) device.Zones[uint16_5]).Name = str6;
                  int startIndex4 = num4 + 32;
                  device.Zones[uint16_5].Standard = BitConverter.ToUInt16(msg, startIndex4);
                  int num5;
                  device.Zones[uint16_5].ZoneClass = BitConverter.ToUInt16(msg, num5 = startIndex4 + 2);
                  int num6;
                  device.Zones[uint16_5].ZoneState = BitConverter.ToUInt16(msg, num6 = num5 + 2);
                  int num7;
                  device.Zones[uint16_5].Airflow = BitConverter.ToUInt16(msg, num7 = num6 + 2);
                  int num8 = num7 + 2;
                  Array.Reverse((Array) msg, num8, 4);
                  device.Zones[uint16_5].Area = (Decimal) BitConverter.ToSingle(msg, num8);
                  int startIndex5;
                  Array.Reverse((Array) msg, startIndex5 = num8 + 4, 2);
                  device.Zones[uint16_5].AreaUnits = BitConverter.ToUInt16(msg, startIndex5);
                  int startIndex6;
                  Array.Reverse((Array) msg, startIndex6 = startIndex5 + 2, 2);
                  device.Zones[uint16_5].RecipeId = (int) BitConverter.ToUInt16(msg, startIndex6);
                  break;
                }
                break;
              }
              break;
            }
            break;
          }
          break;
        case CurrentAction.A_READ_ZONE_LOCATION_AND_RECIPE_GROUP:
          flag2 = true;
          goto case CurrentAction.A_READ_LOCATION_AND_RECIPE_GROUP;
        case CurrentAction.A_READ_ZONE_CONFIG:
          int sourceIndex1 = 9;
          byte[] destinationArray1 = new byte[2];
          Array.Copy((Array) msg, sourceIndex1, (Array) destinationArray1, 0, 2);
          Array.Reverse((Array) destinationArray1);
          int uint16_6 = (int) BitConverter.ToUInt16(destinationArray1, 0);
          if (uint16_6 > 0 && uint16_6 <= (int) device.NumberOfZones)
          {
            ModbusMap2Zone zone = (ModbusMap2Zone) device.Zones[uint16_6];
            ModbusInterpreter.InterpretZoneConfig(msg, (int) uint16_1, device.Unicode, ref zone);
            break;
          }
          break;
        case CurrentAction.A_READ_RECIPE:
          byte[] destinationArray2 = new byte[2];
          Array.Copy((Array) msg, 147, (Array) destinationArray2, 0, 2);
          Array.Reverse((Array) destinationArray2);
          int uint16_7 = (int) BitConverter.ToUInt16(destinationArray2, 0);
          if (uint16_7 >= 0 && uint16_7 < (int) device.NumberOfRecipes)
          {
            ModbusMap2Recipe recipe = (ModbusMap2Recipe) device.Recipes[uint16_7];
            ModbusInterpreter.InterpretRecipe(msg, (int) uint16_1, ref recipe);
            recipe.VolumeDisplayUnit = device.flowUnit == FlowUnits.LPM ? VolumeType.Litres : (device.flowUnit == FlowUnits.CFM ? VolumeType.FeetCubed : VolumeType.MetresCubed);
            break;
          }
          break;
        case CurrentAction.A_READ_USER_PASSWORD:
          int index6 = 9;
          for (int index7 = index6; index7 < index6 + (int) uint16_1; index7 += 2)
            Array.Reverse((Array) msg, index7, 2);
          device.diPassword = !device.Unicode ? Encoding.ASCII.GetString(msg, index6, (int) uint16_1) : Encoding.Unicode.GetString(msg, index6, (int) uint16_1);
          device.diPassword = device.diPassword.TrimEnd(new char[1]);
          break;
        case CurrentAction.A_READ_USER_ID:
          int sourceIndex2 = 9;
          byte[] destinationArray3 = new byte[2];
          Array.Copy((Array) msg, sourceIndex2, (Array) destinationArray3, 0, 2);
          Array.Reverse((Array) destinationArray3);
          device.diUserId = BitConverter.ToUInt16(destinationArray3, 0);
          break;
        case CurrentAction.A_READ_LOCATION_LABEL:
          int startIndex7 = 9;
          for (int index8 = startIndex7; index8 < startIndex7 + (int) uint16_1; index8 += 2)
            Array.Reverse((Array) msg, index8, 2);
          int uint16_8 = (int) BitConverter.ToUInt16(msg, startIndex7);
          if (uint16_8 <= (int) device.NumberOfLocations)
          {
            string str7 = !device.Unicode ? Encoding.ASCII.GetString(msg, startIndex7 += 2, 32) : Encoding.Unicode.GetString(msg, startIndex7 += 2, 32);
            int length = str7.IndexOf("\0");
            string str8 = length >= 0 ? str7.Substring(0, length) : str7;
            if (!string.IsNullOrEmpty(str8))
              device.Locations[uint16_8].Name = str8;
          }
          if (device.HasZones)
          {
            int startIndex8 = startIndex7 + 66;
            ushort uint16_9 = BitConverter.ToUInt16(msg, startIndex8);
            if (uint16_8 <= (int) device.NumberOfLocations && device.Locations[uint16_8].IsValid)
            {
              device.Locations[uint16_8].ZoneId = (int) uint16_9;
              break;
            }
            break;
          }
          break;
        case CurrentAction.A_READ_RECIPE_LABEL:
          int startIndex9 = 9;
          for (int index9 = startIndex9; index9 < startIndex9 + (int) uint16_1; index9 += 2)
            Array.Reverse((Array) msg, index9, 2);
          int uint16_10 = (int) BitConverter.ToUInt16(msg, startIndex9);
          if (uint16_10 <= (int) device.NumberOfRecipes)
          {
            string str9 = !device.Unicode ? Encoding.ASCII.GetString(msg, num1 = startIndex9 + 2, 32) : Encoding.Unicode.GetString(msg, num1 = startIndex9 + 2, 32);
            int length = str9.IndexOf("\0");
            string str10 = length >= 0 ? str9.Substring(0, length) : str9;
            if (!string.IsNullOrEmpty(str10))
            {
              device.Recipes[uint16_10].Name = str10;
              break;
            }
            break;
          }
          break;
        case CurrentAction.A_READ_DATA_INTEGRITY_MODE:
          int sourceIndex3 = 9;
          byte[] destinationArray4 = new byte[2];
          Array.Copy((Array) msg, sourceIndex3, (Array) destinationArray4, 0, 2);
          Array.Reverse((Array) destinationArray4);
          device.isDImode = BitConverter.ToUInt16(destinationArray4, 0) != (ushort) 0;
          break;
        case CurrentAction.A_READ_DATA_INTEGRITY_TIMEOUT:
          int sourceIndex4 = 9;
          byte[] destinationArray5 = new byte[2];
          Array.Copy((Array) msg, sourceIndex4, (Array) destinationArray5, 0, 2);
          Array.Reverse((Array) destinationArray5);
          device.diTimeout = BitConverter.ToUInt16(destinationArray5, 0);
          break;
      }
      return flag1;
    }

    private static void InterpretDeviceInfo(byte[] msg, int msgLength, ref ModbusMap2Device device)
    {
      int startIndex1 = 9;
      if (msgLength < startIndex1)
        return;
      for (int index = startIndex1; index < startIndex1 + msgLength; index += 2)
        Array.Reverse((Array) msg, index, 2);
      device.FirmwareVersion = BitConverter.ToUInt16(msg, startIndex1);
      int index1 = startIndex1 + 2;
      device.model = Encoding.ASCII.GetString(msg, index1, 16);
      device.model = device.model.TrimEnd(new char[1]);
      int index2 = index1 + 16;
      device.serial = Encoding.ASCII.GetString(msg, index2, 16);
      device.serial = device.serial.TrimEnd(new char[1]);
      int startIndex2 = index2 + 16 + 16;
      int num1;
      int num2;
      DateTime dateTime = new DateTime((int) BitConverter.ToUInt16(msg, startIndex2), (int) BitConverter.ToUInt16(msg, num1 = startIndex2 + 2), (int) BitConverter.ToUInt16(msg, num2 = num1 + 2));
      device.LastCalibrationDate = dateTime;
      int startIndex3 = num2 + 2;
      int num3;
      int num4;
      dateTime = new DateTime((int) BitConverter.ToUInt16(msg, startIndex3), (int) BitConverter.ToUInt16(msg, num3 = startIndex3 + 2), (int) BitConverter.ToUInt16(msg, num4 = num3 + 2));
      device.CalibrationDueDate = dateTime;
      int startIndex4 = num4 + 2;
      ushort uint16 = BitConverter.ToUInt16(msg, startIndex4);
      ushort num5 = (ushort) ((uint) uint16 & (uint) short.MaxValue);
      device.nominalFlowRate = (Decimal) ((double) num5 / 100.0);
      device.flowUnit = ((int) uint16 & 32768) != 0 ? FlowUnits.LPM : FlowUnits.CFM;
      int num6;
      device.NumberOfChannels = BitConverter.ToUInt16(msg, num6 = startIndex4 + 2);
      int num7;
      device.DeviceFeatures = BitConverter.ToUInt16(msg, num7 = num6 + 2);
      device.VariableBins = ((int) device.DeviceFeatures & 512) != 0;
      device.Unicode = ((int) device.DeviceFeatures & 8192) != 0;
      device.HandHeld = ((int) device.DeviceFeatures & 1) != 0;
      int num8 = 0;
      int num9 = num7 + 2;
      for (int startIndex5 = num9; startIndex5 < num9 + 32; startIndex5 += 2)
        device.channelSize[num8++] = BitConverter.ToUInt16(msg, startIndex5);
      int startIndex6 = num9 + 32;
      device.DeviceFeatures2 = BitConverter.ToUInt16(msg, startIndex6);
      device.ViableCounts = ((int) device.DeviceFeatures2 & 1) != 0;
      device.HasDataIntegrity = ((int) device.DeviceFeatures2 & 16) != 0;
      int startIndex7 = startIndex6 + 18;
      device.supportedMeasurements = BitConverter.ToUInt16(msg, startIndex7);
      int num10;
      device.NumberOfLocations = BitConverter.ToUInt16(msg, num10 = startIndex7 + 4);
      int num11;
      device.LocationLabelLength = BitConverter.ToUInt16(msg, num11 = num10 + 2);
      int num12;
      device.NumberOfRecipes = BitConverter.ToUInt16(msg, num12 = num11 + 2);
      int num13;
      device.RecipeLabelLength = BitConverter.ToUInt16(msg, num13 = num12 + 2);
      if (device.mapRevRegister > (ushort) 200)
      {
        int num14;
        device.NumberOfZones = BitConverter.ToUInt16(msg, num14 = num13 + 2);
        int num15;
        device.ZoneNameLength = BitConverter.ToUInt16(msg, num15 = num14 + 2);
        int num16;
        string str1 = Encoding.ASCII.GetString(msg, num16 = num15 + 2, 16);
        int length1 = str1.IndexOf(char.MinValue);
        if (length1 > 0)
          str1 = str1.Substring(0, length1);
        else if (length1 == 0)
          str1 = "0";
        device.AlgorithmId1 = str1;
        int index3 = num16 + 10;
        string str2 = new string(Encoding.ASCII.GetChars(msg, index3, 16));
        int length2 = str2.IndexOf(char.MinValue);
        if (length2 > 0)
          str2 = str2.Substring(0, length2);
        else if (length2 == 0)
          str2 = "0";
        device.AlgorithmId2 = str2;
      }
      if (!device.HasDataIntegrity)
        return;
      device.diNumUserPasswords = (ushort) 1;
      device.diPasswordMaxLen = (ushort) 16;
    }

    private static void InterpretRecipe(byte[] msg, int msgLength, ref ModbusMap2Recipe recipe)
    {
      if (recipe == null)
        return;
      int num1 = 9;
      Array.Reverse((Array) msg, num1 + msgLength - 2, 2);
      if (BitConverter.ToUInt16(msg, num1 + msgLength - 2) != (ushort) 1)
        return;
      Array.Reverse((Array) msg, num1, 4);
      recipe.DelayTime = new TimeSpan(0, 0, BitConverter.ToInt32(msg, num1));
      int startIndex1;
      Array.Reverse((Array) msg, startIndex1 = num1 + 4, 4);
      recipe.HoldTime = new TimeSpan(0, 0, BitConverter.ToInt32(msg, startIndex1));
      int startIndex2;
      Array.Reverse((Array) msg, startIndex2 = startIndex1 + 4, 4);
      recipe.SampleTime = new TimeSpan(0, 0, BitConverter.ToInt32(msg, startIndex2));
      int num2;
      Array.Reverse((Array) msg, num2 = startIndex2 + 4, 4);
      recipe.Cycles = BitConverter.ToUInt32(msg, 21);
      int num3 = num2 + 4;
      Array.Reverse((Array) msg, num3, 2);
      ushort uint16_1 = BitConverter.ToUInt16(msg, num3);
      for (int y = 0; y < 16; ++y)
        recipe.channelEnable[y] = ((int) uint16_1 & (int) Convert.ToUInt16(Math.Pow(2.0, (double) y))) != 0;
      int startIndex3;
      Array.Reverse((Array) msg, startIndex3 = num3 + 2, 2);
      ushort uint16_2 = BitConverter.ToUInt16(msg, startIndex3);
      for (int y = 0; y < 16; ++y)
        recipe.alarmEnable[y] = ((int) uint16_2 & (int) Convert.ToUInt16(Math.Pow(2.0, (double) y))) != 0;
      int startIndex4;
      Array.Reverse((Array) msg, startIndex4 = startIndex3 + 2, 2);
      recipe.AlarmThresholdMode = BitConverter.ToUInt16(msg, startIndex4);
      int num4 = startIndex4 + 2;
      int num5 = 0;
      for (int index = num4; index < num4 + 64; index += 4)
      {
        Array.Reverse((Array) msg, index, 4);
        recipe.alarmValues[num5++] = BitConverter.ToUInt32(msg, index);
      }
      int num6 = num4 + 64;
      Array.Reverse((Array) msg, num6, 2);
      ushort uint16_3 = BitConverter.ToUInt16(msg, num6);
      recipe.SamplingMode = (SampleCountMode) uint16_3;
      int startIndex5 = num6 + 12;
      for (int index = startIndex5; index < msgLength + 9; index += 2)
        Array.Reverse((Array) msg, index, 2);
      recipe.unitTemp = (UnitCode) BitConverter.ToUInt16(msg, startIndex5);
      int num7;
      recipe.unitHumidity = (UnitCode) BitConverter.ToUInt16(msg, num7 = startIndex5 + 2);
      int num8;
      recipe.unitVelocity = (UnitCode) BitConverter.ToUInt16(msg, num8 = num7 + 2);
      int num9;
      recipe.unitFlow = (UnitCode) BitConverter.ToUInt16(msg, num9 = num8 + 2);
      int num10;
      recipe.unitCO2 = (UnitCode) BitConverter.ToUInt16(msg, num10 = num9 + 2);
      int num11;
      recipe.unitCO = (UnitCode) BitConverter.ToUInt16(msg, num11 = num10 + 2);
      int num12;
      recipe.unitPressure = (UnitCode) BitConverter.ToUInt16(msg, num12 = num11 + 2);
      int startIndex6 = num12 + 2;
      recipe.autoStart = ((int) BitConverter.ToUInt16(msg, startIndex6) & 1) == 1;
      int num13 = startIndex6 + 18 + 28;
      int num14 = 0;
      for (int startIndex7 = num13; startIndex7 < num13 + 32; startIndex7 += 2)
        recipe.ChannelSizes[num14++] = BitConverter.ToUInt16(msg, startIndex7);
    }

    private static void InterpretZoneConfig(
      byte[] msg,
      int msgLength,
      bool unicode,
      ref ModbusMap2Zone zone)
    {
      if (zone == null)
        return;
      int num1 = 9;
      int num2 = msgLength - 8;
      for (int index = num1; index < num1 + num2; index += 2)
        Array.Reverse((Array) msg, index, 2);
      int index1 = num1 + 2;
      string empty = string.Empty;
      string str1 = !unicode ? Encoding.ASCII.GetString(msg, index1, 32) : Encoding.Unicode.GetString(msg, index1, 32);
      int length = str1.IndexOf("\0");
      string str2 = length >= 0 ? str1.Substring(0, length) : str1;
      if (string.IsNullOrEmpty(str2))
        return;
      zone.Name = str2;
      int startIndex1 = index1 + 32;
      zone.Standard = BitConverter.ToUInt16(msg, startIndex1);
      int num3;
      zone.ZoneClass = BitConverter.ToUInt16(msg, num3 = startIndex1 + 2);
      int num4;
      zone.ZoneState = BitConverter.ToUInt16(msg, num4 = num3 + 2);
      int num5;
      zone.Airflow = BitConverter.ToUInt16(msg, num5 = num4 + 2);
      int num6 = num5 + 2;
      Array.Reverse((Array) msg, num6, 4);
      zone.Area = (Decimal) BitConverter.ToSingle(msg, num6);
      int startIndex2;
      Array.Reverse((Array) msg, startIndex2 = num6 + 4, 2);
      zone.AreaUnits = BitConverter.ToUInt16(msg, startIndex2);
      int startIndex3;
      Array.Reverse((Array) msg, startIndex3 = startIndex2 + 2, 2);
      zone.RecipeId = (int) BitConverter.ToUInt16(msg, startIndex3);
    }

    private static void InterpretRecord(
      byte[] msg,
      int msgLength,
      ref ModbusMap2Record rec,
      bool hasDataIntegrity)
    {
      int num1 = 9;
      Array.Reverse((Array) msg, num1, 4);
      rec.recNum = BitConverter.ToUInt32(msg, num1);
      int startIndex = num1 + 4;
      for (int index = startIndex; index < startIndex + 12; index += 2)
        Array.Reverse((Array) msg, index, 2);
      ushort uint16_1 = BitConverter.ToUInt16(msg, startIndex);
      int num2;
      ushort uint16_2 = BitConverter.ToUInt16(msg, num2 = startIndex + 2);
      int num3;
      ushort uint16_3 = BitConverter.ToUInt16(msg, num3 = num2 + 2);
      int num4;
      ushort uint16_4 = BitConverter.ToUInt16(msg, num4 = num3 + 2);
      int num5;
      ushort uint16_5 = BitConverter.ToUInt16(msg, num5 = num4 + 2);
      int num6;
      ushort uint16_6 = BitConverter.ToUInt16(msg, num6 = num5 + 2);
      int num7 = num6 + 2;
      rec.dateTime = new DateTime((int) uint16_1, (int) uint16_2, (int) uint16_3, (int) uint16_4, (int) uint16_5, (int) uint16_6);
      int num8 = num7 + 4;
      Array.Reverse((Array) msg, num8, 2);
      rec.ViableDetectionSensitivity = BitConverter.ToUInt16(msg, num8);
      int num9 = num8 + 2;
      Array.Reverse((Array) msg, num9, 4);
      rec.PrecisionFlowRate = BitConverter.ToSingle(msg, num9);
      int num10 = num9 + 4;
      Array.Reverse((Array) msg, num10, 2);
      rec.DeviceStatus = BitConverter.ToUInt16(msg, num10);
      rec.flowStatus = ((int) rec.DeviceStatus & 1) == 0 ? FlowStatus.OK : FlowStatus.Error;
      if (((int) rec.DeviceStatus & 2) != 0)
        rec.flowStatus = FlowStatus.Stopped;
      rec.laserStatus = ((int) rec.DeviceStatus & 4) == 0 ? LaserStatus.OK : LaserStatus.Error;
      rec.scatterAlert = ((int) rec.DeviceStatus & 8) != 0;
      rec.opticsDirty = ((int) rec.DeviceStatus & 16) != 0;
      rec.calibrationCorrupt = ((int) rec.DeviceStatus & 32) != 0;
      rec.serviceAlert = ((int) rec.DeviceStatus & 16384) != 0;
      rec.dataValid = ((int) rec.DeviceStatus & 32768) == 0;
      int num11 = num10 + 2;
      Array.Reverse((Array) msg, num11, 2);
      ushort uint16_7 = BitConverter.ToUInt16(msg, num11);
      for (int y = 0; y < 16; ++y)
        rec.chAlarm[y] = ((int) uint16_7 & (int) Convert.ToUInt16(Math.Pow(2.0, (double) y))) != 0;
      int num12 = num11 + 2;
      Array.Reverse((Array) msg, num12, 2);
      ushort uint16_8 = BitConverter.ToUInt16(msg, num12);
      rec.flowType = ((int) uint16_8 & 32768) == 1 ? FlowType.LPM : FlowType.CFM;
      rec.flowRateX100 = (ushort) ((uint) uint16_8 & (uint) short.MaxValue);
      int num13 = num12 + 2;
      Array.Reverse((Array) msg, num13, 4);
      int int32 = Convert.ToInt32(BitConverter.ToUInt32(msg, num13));
      int num14 = num13 + 4;
      Array.Reverse((Array) msg, num14, 2);
      if (BitConverter.ToUInt16(msg, num14) == (ushort) 0)
      {
        rec.timeUnit = TimeUnits.ms;
        rec.sampleTime = new TimeSpan(0, 0, int32 / 1000);
      }
      else
      {
        rec.timeUnit = TimeUnits.sec;
        rec.sampleTime = new TimeSpan(0, 0, int32);
      }
      int num15 = num14 + 2;
      Array.Reverse((Array) msg, num15, 2);
      ushort uint16_9 = BitConverter.ToUInt16(msg, num15);
      ushort num16;
      rec.CountMode = (num16 = (ushort) ((uint) uint16_9 & 65280U)) == (ushort) 0 ? RecordType.Differential : RecordType.Cumulative;
      ushort num17;
      rec.unitMode = (num17 = (ushort) ((uint) num16 & (uint) byte.MaxValue)) == (ushort) 0 ? UnitType.Counts : UnitType.Concentration;
      int num18 = num15 + 2;
      Array.Reverse((Array) msg, num18, 2);
      rec.locNumber = BitConverter.ToUInt16(msg, num18);
      int num19 = num18 + 2;
      int num20 = 0;
      for (int index = num19; index < num19 + 64; index += 4)
      {
        Array.Reverse((Array) msg, index, 4);
        rec.counts[num20++] = BitConverter.ToUInt32(msg, index);
      }
      int num21 = num19 + 64;
      int num22 = 0;
      for (int index = num21; index < num21 + 32; index += 2)
      {
        Array.Reverse((Array) msg, index, 2);
        rec.chSizes[num22++] = BitConverter.ToUInt16(msg, index);
      }
      int num23 = num21 + 32;
      int num24 = hasDataIntegrity ? msgLength - 4 : msgLength - 2;
      Array.Reverse((Array) msg, 9 + num24, 2);
      rec.measurementEnabled = BitConverter.ToUInt16(msg, 9 + num24);
      if (((int) rec.measurementEnabled & 1) != 0)
      {
        Array.Reverse((Array) msg, num23, 2);
        ushort uint16_10 = BitConverter.ToUInt16(msg, num23);
        rec.tempUnit = (UnitCode) uint16_10;
        int num25 = num23 + 2;
        Array.Reverse((Array) msg, num25, 4);
        rec.temperature = BitConverter.ToSingle(msg, num25);
        num23 = num25 + 4;
      }
      if (((int) rec.measurementEnabled & 2) != 0)
      {
        Array.Reverse((Array) msg, num23, 2);
        ushort uint16_11 = BitConverter.ToUInt16(msg, num23);
        int num26 = num23 + 2;
        rec.humidityUnit = (UnitCode) uint16_11;
        Array.Reverse((Array) msg, num26, 4);
        rec.humidity = BitConverter.ToSingle(msg, num26);
        num23 = num26 + 4;
      }
      if (((int) rec.measurementEnabled & 4) != 0)
      {
        Array.Reverse((Array) msg, num23, 2);
        ushort uint16_12 = BitConverter.ToUInt16(msg, num23);
        int num27 = num23 + 2;
        rec.velocityUnit = (UnitCode) uint16_12;
        Array.Reverse((Array) msg, num27, 4);
        rec.velocity = BitConverter.ToSingle(msg, num27);
        num23 = num27 + 4;
      }
      if (((int) rec.measurementEnabled & 8) != 0)
      {
        Array.Reverse((Array) msg, num23, 2);
        ushort uint16_13 = BitConverter.ToUInt16(msg, num23);
        rec.flowUnit = (UnitCode) uint16_13;
        int num28 = num23 + 2;
        Array.Reverse((Array) msg, num28, 4);
        rec.flow = BitConverter.ToSingle(msg, num28);
        num23 = num28 + 4;
      }
      if (((int) rec.measurementEnabled & 16) != 0)
      {
        Array.Reverse((Array) msg, num23, 2);
        ushort uint16_14 = BitConverter.ToUInt16(msg, num23);
        rec.CO2Unit = (UnitCode) uint16_14;
        int num29 = num23 + 2;
        Array.Reverse((Array) msg, num29, 4);
        rec.CO2 = BitConverter.ToSingle(msg, num29);
        int num30 = num29 + 4;
      }
      if (((int) rec.measurementEnabled & 32) != 0)
      {
        Array.Reverse((Array) msg, 177, 2);
        ushort uint16_15 = BitConverter.ToUInt16(msg, 177);
        rec.COUnit = (UnitCode) uint16_15;
        Array.Reverse((Array) msg, 179, 4);
        rec.CO = BitConverter.ToSingle(msg, 179);
      }
      if (((int) rec.measurementEnabled & 64) != 0)
      {
        Array.Reverse((Array) msg, 183, 2);
        ushort uint16_16 = BitConverter.ToUInt16(msg, 183);
        rec.pressureUnit = (UnitCode) uint16_16;
        Array.Reverse((Array) msg, 185, 4);
        rec.pressure = BitConverter.ToSingle(msg, 185);
      }
      if (rec.CountMode == RecordType.Cumulative)
      {
        for (int index = 0; index < rec.NumberOfChannels - 1; ++index)
          rec.counts[index] -= rec.counts[index + 1];
        rec.CountMode = RecordType.Differential;
      }
      if (!hasDataIntegrity)
        return;
      Array.Reverse((Array) msg, 9 + msgLength - 2, 2);
      rec.DIUserId = BitConverter.ToUInt16(msg, 9 + msgLength - 2);
    }
  }
}
