﻿// Decompiled with JetBrains decompiler
// Type: TSI.ModbusTCP.DataPacket
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using TSI.Communication;

#nullable disable
namespace TSI.ModbusTCP
{
  public struct DataPacket
  {
    private byte[][] pkts;
    private CurrentAction[] actions;

    public DataPacket(byte[][] inPkts, CurrentAction[] acts)
    {
      this.pkts = inPkts;
      this.actions = acts;
    }

    public DataPacket(byte[] inPkt, CurrentAction act)
    {
      this.pkts = new byte[1][];
      this.actions = new CurrentAction[1];
      this.pkts[0] = inPkt;
      this.actions[0] = act;
    }

    public DataPacket(int size)
    {
      this.pkts = new byte[size][];
      this.actions = new CurrentAction[size];
    }

    public void Add(byte[][] inPkts, CurrentAction[] acts)
    {
      if (this.pkts == null)
      {
        this.pkts = inPkts;
        this.actions = acts;
      }
      else
      {
        int length1 = this.pkts.Length;
        int length2 = this.actions.Length;
        Array.Resize<byte[]>(ref this.pkts, length1 + inPkts.Length);
        Array.Resize<CurrentAction>(ref this.actions, length2 + acts.Length);
        for (int index = 0; index < inPkts.Length; ++index)
        {
          this.pkts[length1 + index] = inPkts[index];
          this.actions[length2 + index] = acts[index];
        }
      }
    }

    public byte[][] Packets => this.pkts;

    public CurrentAction[] Actions => this.actions;

    internal void Add(DataPacket tmpPkt) => this.Add(tmpPkt.Packets, tmpPkt.Actions);
  }
}
