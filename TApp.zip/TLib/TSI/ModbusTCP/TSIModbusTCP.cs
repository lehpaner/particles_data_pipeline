﻿// Decompiled with JetBrains decompiler
// Type: TSI.ModbusTCP.TSIModbusTCP
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using TSI.Communication;

#nullable disable
namespace TSI.ModbusTCP
{
  public class TSIModbusTCP
  {
    public DataPacket ReadSerialNumber(byte addr)
    {
      byte[][] inPkts = new byte[1][];
      CurrentAction[] acts = new CurrentAction[1];
      inPkts[0] = this.Read(addr, this.BinaryAddress((ushort) 40011), (ushort) 8);
      acts[0] = CurrentAction.A_GET_SERIAL;
      return new DataPacket(inPkts, acts);
    }

    public DataPacket ReadModelNumber(byte addr)
    {
      byte[][] inPkts = new byte[1][];
      CurrentAction[] acts = new CurrentAction[1];
      inPkts[0] = this.Read(addr, this.BinaryAddress((ushort) 40003), (ushort) 8);
      acts[0] = CurrentAction.A_GET_MODEL;
      return new DataPacket(inPkts, acts);
    }

    public DataPacket ReadNumberOfSamples(byte addr)
    {
      return new DataPacket(this.Read(addr, this.BinaryAddress((ushort) 42001), (ushort) 2), CurrentAction.A_GET_NUMBER_OF_SAMPLES);
    }

    public DataPacket ReadDataRecord(byte addr, uint index)
    {
      byte[] bytes = BitConverter.GetBytes(index);
      byte[][] inPkts = new byte[3][];
      CurrentAction[] acts = new CurrentAction[3];
      inPkts[0] = this.Write(addr, this.BinaryAddress((ushort) 41078), BitConverter.ToUInt16(bytes, 2));
      acts[0] = CurrentAction.A_WRITE_RECORD_INDEX;
      inPkts[1] = this.Write(addr, this.BinaryAddress((ushort) 41079), BitConverter.ToUInt16(bytes, 0));
      acts[1] = CurrentAction.A_WRITE_RECORD_INDEX;
      inPkts[2] = this.Read(addr, this.BinaryAddress((ushort) 42005), (ushort) 118);
      acts[2] = CurrentAction.A_READ_RECORD;
      return new DataPacket(inPkts, acts);
    }

    public DataPacket WriteSampleRecordIndex(byte addr, uint index)
    {
      byte[] bytes = BitConverter.GetBytes(index);
      DataPacket dataPacket = new DataPacket(2);
      dataPacket.Packets[0] = this.Write(addr, this.BinaryAddress((ushort) 41078), BitConverter.ToUInt16(bytes, 2));
      dataPacket.Actions[0] = CurrentAction.A_WRITE_RECORD_INDEX;
      dataPacket.Packets[1] = this.Write(addr, this.BinaryAddress((ushort) 41079), BitConverter.ToUInt16(bytes, 0));
      dataPacket.Actions[1] = CurrentAction.A_WRITE_RECORD_INDEX;
      return dataPacket;
    }

    public DataPacket ReadLocationAndRecipeGroup(
      byte addr,
      ushort numZones,
      ushort numLocations,
      ushort numRecipes)
    {
      int num1 = numZones > (ushort) 0 ? 4 : 3;
      int num2 = (int) Math.Max(numZones, numLocations);
      if ((int) numRecipes > num2)
        num2 = (int) numRecipes;
      DataPacket dataPacket = new DataPacket(num2 * num1);
      ushort num3 = 1;
      ushort length;
      CurrentAction currentAction;
      if (numZones > (ushort) 0)
      {
        length = (ushort) 60;
        currentAction = CurrentAction.A_READ_ZONE_LOCATION_AND_RECIPE_GROUP;
      }
      else
      {
        length = (ushort) 34;
        currentAction = CurrentAction.A_READ_LOCATION_AND_RECIPE_GROUP;
      }
      int num4 = num1 - 1;
      byte[] numArray = this.Read(addr, this.BinaryAddress((ushort) 43001), length);
      for (int index = 0; index < num2 * num1; index += num1)
      {
        dataPacket.Packets[index] = this.Write(addr, this.BinaryAddress((ushort) 43001), index < (int) numLocations ? num3 : (ushort) 1);
        dataPacket.Actions[index] = CurrentAction.A_WRITE_LOCATION_LABEL_INDEX;
        dataPacket.Packets[index + 1] = this.Write(addr, this.BinaryAddress((ushort) 43018), index < (int) numRecipes ? num3 : (ushort) 1);
        dataPacket.Actions[index + 1] = CurrentAction.A_WRITE_RECIPE_LABEL_INDEX;
        if (numZones > (ushort) 0)
        {
          dataPacket.Packets[index + 2] = this.Write(addr, this.BinaryAddress((ushort) 43036), index < (int) numZones ? num3 : (ushort) 1);
          dataPacket.Actions[index + 2] = CurrentAction.A_WRITE_ZONE_CONFIG_SELECT;
        }
        dataPacket.Packets[index + num4] = numArray;
        dataPacket.Actions[index + num4] = currentAction;
        ++num3;
      }
      return dataPacket;
    }

    public DataPacket ReadLocationAndRecipeGroup(
      byte addr,
      ushort numLocations,
      ushort numRecipes,
      bool hasZones)
    {
      int num1 = 3;
      int num2 = (int) Math.Max(numRecipes, numLocations);
      DataPacket dataPacket = new DataPacket(num2 * num1);
      ushort num3 = 1;
      ushort length = !hasZones ? (ushort) 34 : (ushort) 35;
      byte[] numArray = this.Read(addr, this.BinaryAddress((ushort) 43001), length);
      for (int index = 0; index < num2 * num1; index += num1)
      {
        dataPacket.Packets[index] = this.Write(addr, this.BinaryAddress((ushort) 43001), index < (int) numLocations ? num3 : (ushort) 1);
        dataPacket.Actions[index] = CurrentAction.A_WRITE_LOCATION_LABEL_INDEX;
        dataPacket.Packets[index + 1] = this.Write(addr, this.BinaryAddress((ushort) 43018), index < (int) numRecipes ? num3 : (ushort) 1);
        dataPacket.Actions[index + 1] = CurrentAction.A_WRITE_RECIPE_LABEL_INDEX;
        dataPacket.Packets[index + 2] = numArray;
        dataPacket.Actions[index + 2] = CurrentAction.A_READ_LOCATION_AND_RECIPE_GROUP;
        ++num3;
      }
      return dataPacket;
    }

    public DataPacket ReadZoneConfig(byte addr, int[] zoneIds)
    {
      int num = 2;
      int length1 = zoneIds.Length;
      CurrentAction[] acts = new CurrentAction[length1 * num];
      DataPacket dataPacket = new DataPacket();
      byte[][] inPkts = new byte[length1 * num][];
      ushort length2 = 25;
      byte[] numArray = this.Read(addr, this.BinaryAddress((ushort) 43036), length2);
      int index1 = 0;
      for (int index2 = 0; index2 < length1 * num; index2 += num)
      {
        inPkts[index2] = this.Write(addr, this.BinaryAddress((ushort) 43036), (ushort) zoneIds[index1]);
        acts[index2] = CurrentAction.A_WRITE_ZONE_CONFIG_SELECT;
        inPkts[index2 + 1] = numArray;
        acts[index2 + 1] = CurrentAction.A_READ_ZONE_CONFIG;
        ++index1;
      }
      dataPacket.Add(inPkts, acts);
      return dataPacket;
    }

    public DataPacket DeleteLocationLabel(byte addr, ushort idx)
    {
      byte[][] inPkts = new byte[2][];
      CurrentAction[] acts = new CurrentAction[2];
      inPkts[0] = this.Write(addr, this.BinaryAddress((ushort) 41080), idx);
      acts[0] = CurrentAction.A_DELETE_LOCATION_LABEL;
      inPkts[1] = this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 21);
      acts[1] = CurrentAction.A_COMMAND;
      return new DataPacket(inPkts, acts);
    }

    public DataPacket DeleteAllLocationLabels(byte addr, ushort count)
    {
      if (count == (ushort) 0)
        return new DataPacket((byte[][]) null, (CurrentAction[]) null);
      DataPacket dataPacket1 = new DataPacket();
      for (ushort idx = 1; (int) idx <= (int) count; ++idx)
      {
        DataPacket dataPacket2 = this.DeleteLocationLabel(addr, idx);
        dataPacket1.Add(dataPacket2.Packets, dataPacket2.Actions);
      }
      return dataPacket1;
    }

    public DataPacket WriteLocationConfig(byte addr, List<ILocation> locations, bool unicode)
    {
      DataPacket dataPacket1 = new DataPacket();
      foreach (ILocation location in locations)
      {
        if (location.IsValid)
        {
          DataPacket dataPacket2 = this.WriteLocationConfig(addr, (ushort) location.LocationId, location.Name, unicode, (ushort) location.ZoneId);
          dataPacket1.Add(dataPacket2.Packets, dataPacket2.Actions);
        }
      }
      return dataPacket1;
    }

    public DataPacket WriteLocationConfig(
      byte addr,
      ushort locationId,
      string locLabel,
      bool unicode,
      ushort zoneId)
    {
      string s = string.Copy(locLabel) + "\0";
      byte[] numArray = !unicode ? Encoding.ASCII.GetBytes(s) : Encoding.Unicode.GetBytes(s);
      int size = numArray.Length / 2 + 4;
      DataPacket dataPacket = new DataPacket(size);
      for (int index = 0; index < size; ++index)
        dataPacket.Actions[index] = CurrentAction.A_WRITE_LOCATION_CONFIG;
      dataPacket.Packets[0] = this.Write(addr, this.BinaryAddress((ushort) 41080), locationId);
      dataPacket.Packets[1] = this.Write(addr, this.BinaryAddress((ushort) 43001), locationId);
      int index1 = 2;
      if (zoneId >= (ushort) 0)
      {
        dataPacket.Packets[index1] = this.Write(addr, this.BinaryAddress((ushort) 43035), zoneId);
        ++index1;
      }
      for (ushort startIndex = 0; (int) startIndex < numArray.Length; startIndex += (ushort) 2)
        dataPacket.Packets[index1++] = this.Write(addr, this.BinaryAddress((ushort) (43002 + (int) startIndex / 2)), BitConverter.ToUInt16(numArray, (int) startIndex));
      dataPacket.Packets[index1] = this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 20);
      dataPacket.Actions[index1] = CurrentAction.A_COMMAND;
      return dataPacket;
    }

    public DataPacket WriteZoneConfig(byte addr, bool unicode, ModbusMap2Zone zone)
    {
      string s = string.Copy(zone.Name.Trim()) + "\0";
      byte[] numArray1 = !unicode ? Encoding.ASCII.GetBytes(s) : Encoding.Unicode.GetBytes(s);
      int size = numArray1.Length / 2 + 10;
      DataPacket dataPacket = new DataPacket(size);
      for (int index = 0; index < size; ++index)
        dataPacket.Actions[index] = CurrentAction.A_WRITE_ZONE_CONFIG;
      dataPacket.Packets[0] = this.Write(addr, this.BinaryAddress((ushort) 43036), (ushort) zone.ZoneId);
      int num1 = 1;
      for (ushort startIndex = 0; (int) startIndex < numArray1.Length; startIndex += (ushort) 2)
        dataPacket.Packets[num1++] = this.Write(addr, this.BinaryAddress((ushort) (43037 + (int) startIndex / 2)), BitConverter.ToUInt16(numArray1, (int) startIndex));
      byte[][] packets1 = dataPacket.Packets;
      int index1 = num1;
      int num2 = index1 + 1;
      byte[] numArray2 = this.Write(addr, this.BinaryAddress((ushort) 43053), zone.Standard);
      packets1[index1] = numArray2;
      byte[][] packets2 = dataPacket.Packets;
      int index2 = num2;
      int num3 = index2 + 1;
      byte[] numArray3 = this.Write(addr, this.BinaryAddress((ushort) 43054), zone.ZoneClass);
      packets2[index2] = numArray3;
      byte[][] packets3 = dataPacket.Packets;
      int index3 = num3;
      int num4 = index3 + 1;
      byte[] numArray4 = this.Write(addr, this.BinaryAddress((ushort) 43055), zone.ZoneState);
      packets3[index3] = numArray4;
      byte[][] packets4 = dataPacket.Packets;
      int index4 = num4;
      int num5 = index4 + 1;
      byte[] numArray5 = this.Write(addr, this.BinaryAddress((ushort) 43056), zone.Airflow);
      packets4[index4] = numArray5;
      byte[] bytes = BitConverter.GetBytes(Convert.ToSingle(zone.Area));
      ushort uint16_1 = BitConverter.ToUInt16(bytes, 0);
      ushort uint16_2 = BitConverter.ToUInt16(bytes, 2);
      byte[][] packets5 = dataPacket.Packets;
      int index5 = num5;
      int num6 = index5 + 1;
      byte[] numArray6 = this.Write(addr, this.BinaryAddress((ushort) 43057), uint16_2);
      packets5[index5] = numArray6;
      byte[][] packets6 = dataPacket.Packets;
      int index6 = num6;
      int num7 = index6 + 1;
      byte[] numArray7 = this.Write(addr, this.BinaryAddress((ushort) 43058), uint16_1);
      packets6[index6] = numArray7;
      byte[][] packets7 = dataPacket.Packets;
      int index7 = num7;
      int num8 = index7 + 1;
      byte[] numArray8 = this.Write(addr, this.BinaryAddress((ushort) 43059), zone.AreaUnits);
      packets7[index7] = numArray8;
      byte[][] packets8 = dataPacket.Packets;
      int index8 = num8;
      int index9 = index8 + 1;
      byte[] numArray9 = this.Write(addr, this.BinaryAddress((ushort) 43060), (ushort) zone.RecipeId);
      packets8[index8] = numArray9;
      dataPacket.Packets[index9] = this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 27);
      dataPacket.Actions[index9] = CurrentAction.A_COMMAND;
      return dataPacket;
    }

    public DataPacket DeleteZoneConfig(byte addr, ushort zoneId)
    {
      DataPacket dataPacket = new DataPacket(2);
      dataPacket.Packets[0] = this.Write(addr, this.BinaryAddress((ushort) 43036), zoneId);
      dataPacket.Actions[0] = CurrentAction.A_WRITE_ZONE_CONFIG_SELECT;
      dataPacket.Packets[1] = this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 28);
      dataPacket.Actions[1] = CurrentAction.A_COMMAND;
      return dataPacket;
    }

    public DataPacket DeleteLocation(byte addr, ushort locationId)
    {
      DataPacket dataPacket = new DataPacket(2);
      dataPacket.Packets[0] = this.Write(addr, this.BinaryAddress((ushort) 41080), locationId);
      dataPacket.Actions[0] = CurrentAction.A_WRITE_LOCATION_CONFIG;
      dataPacket.Packets[1] = this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 21);
      dataPacket.Actions[1] = CurrentAction.A_COMMAND;
      return dataPacket;
    }

    public DataPacket RemoveLocations(byte addr, List<ILocation> locations)
    {
      int size = 2 * locations.Count + 1;
      DataPacket dataPacket = new DataPacket(size);
      int index1 = 0;
      foreach (ILocation location in locations)
      {
        dataPacket.Packets[index1] = this.Write(addr, this.BinaryAddress((ushort) 41080), (ushort) location.LocationId);
        CurrentAction[] actions1 = dataPacket.Actions;
        int index2 = index1;
        int index3 = index2 + 1;
        actions1[index2] = CurrentAction.A_WRITE_LOCATION_CONFIG;
        dataPacket.Packets[index3] = this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 21);
        CurrentAction[] actions2 = dataPacket.Actions;
        int index4 = index3;
        index1 = index4 + 1;
        actions2[index4] = CurrentAction.A_COMMAND;
      }
      dataPacket.Packets[size - 1] = this.Write(addr, this.BinaryAddress((ushort) 41080), (ushort) 0);
      dataPacket.Actions[size - 1] = CurrentAction.A_WRITE_LOCATION_CONFIG;
      return dataPacket;
    }

    public DataPacket ClearAllData(byte addr)
    {
      byte[][] inPkts = new byte[1][];
      CurrentAction[] acts = new CurrentAction[1];
      inPkts[0] = this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 1);
      acts[0] = CurrentAction.A_COMMAND;
      return new DataPacket(inPkts, acts);
    }

    public DataPacket ReadRecipe(byte addr, ushort rcpIdx)
    {
      byte[][] inPkts = new byte[2][];
      CurrentAction[] acts = new CurrentAction[2];
      inPkts[0] = this.Write(addr, this.BinaryAddress((ushort) 41081), rcpIdx);
      acts[0] = CurrentAction.A_WRITE_RECIPE_INDEX;
      ushort length = 99;
      inPkts[1] = this.Read(addr, this.BinaryAddress((ushort) 41012), length);
      acts[1] = CurrentAction.A_READ_RECIPE;
      return new DataPacket(inPkts, acts);
    }

    public DataPacket WriteRecipe(
      byte addr,
      ModbusMap2Recipe rcp,
      ushort idx,
      bool unicode,
      bool variableBins)
    {
      if (rcp == null)
        return new DataPacket((byte[][]) null, (CurrentAction[]) null);
      DataPacket dataPacket = new DataPacket();
      DataPacket tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41081), idx), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt.Packets, tmpPkt.Actions);
      byte[] bytes1 = BitConverter.GetBytes(Convert.ToUInt32(rcp.DelayTime.TotalSeconds));
      ushort uint16_1 = BitConverter.ToUInt16(bytes1, 0);
      ushort uint16_2 = BitConverter.ToUInt16(bytes1, 2);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41012), uint16_2), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41013), uint16_1), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      byte[] bytes2 = BitConverter.GetBytes(Convert.ToUInt32(rcp.HoldTime.TotalSeconds));
      ushort uint16_3 = BitConverter.ToUInt16(bytes2, 0);
      ushort uint16_4 = BitConverter.ToUInt16(bytes2, 2);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41014), uint16_4), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41015), uint16_3), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      byte[] bytes3 = BitConverter.GetBytes(Convert.ToUInt32(rcp.SampleTime.TotalSeconds));
      ushort uint16_5 = BitConverter.ToUInt16(bytes3, 0);
      ushort uint16_6 = BitConverter.ToUInt16(bytes3, 2);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41016), uint16_6), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41017), uint16_5), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      byte[] bytes4 = BitConverter.GetBytes(rcp.Cycles);
      ushort uint16_7 = BitConverter.ToUInt16(bytes4, 0);
      ushort uint16_8 = BitConverter.ToUInt16(bytes4, 2);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41018), uint16_8), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41019), uint16_7), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      ushort num1 = 0;
      for (int y = 0; y < rcp.channelEnable.Length; ++y)
      {
        if (rcp.channelEnable[y])
          num1 |= Convert.ToUInt16(Math.Pow(2.0, (double) y));
      }
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41020), num1), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      ushort num2 = 0;
      for (int y = 0; y < rcp.alarmEnable.Length; ++y)
      {
        if (rcp.alarmEnable[y])
          num2 |= Convert.ToUInt16(Math.Pow(2.0, (double) y));
      }
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41021), num2), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41022), rcp.AlarmThresholdMode), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      for (int index = 0; index < rcp.alarmValues.Length; ++index)
      {
        byte[] bytes5 = BitConverter.GetBytes(rcp.alarmValues[index]);
        ushort uint16_9 = BitConverter.ToUInt16(bytes5, 0);
        ushort uint16_10 = BitConverter.ToUInt16(bytes5, 2);
        ushort num3 = (ushort) (index * 2);
        tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) (41023U + (uint) num3)), uint16_10), CurrentAction.A_WRITE_RECIPE);
        dataPacket.Add(tmpPkt);
        tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) (41024U + (uint) num3)), uint16_9), CurrentAction.A_WRITE_RECIPE);
        dataPacket.Add(tmpPkt);
      }
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41055), (ushort) rcp.SamplingMode), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      for (int index = 0; index < rcp.ChannelSizes.Length; ++index)
      {
        tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) (41091 + index)), rcp.ChannelSizes[index]), CurrentAction.A_WRITE_RECIPE);
        dataPacket.Add(tmpPkt);
      }
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 43018), idx), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      string s = string.Copy(rcp.Name) + "\0";
      byte[] numArray = !unicode ? Encoding.ASCII.GetBytes(s) : Encoding.Unicode.GetBytes(s);
      for (ushort startIndex = 0; (int) startIndex < numArray.Length; startIndex += (ushort) 2)
      {
        tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) (43019 + (int) startIndex / 2)), BitConverter.ToUInt16(numArray, (int) startIndex)), CurrentAction.A_WRITE_RECIPE);
        dataPacket.Add(tmpPkt.Packets, tmpPkt.Actions);
      }
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 9), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 18), CurrentAction.A_WRITE_RECIPE);
      dataPacket.Add(tmpPkt);
      return dataPacket;
    }

    public DataPacket WriteRecipes(
      byte addr,
      List<IRecipe> rcps,
      ushort maxRcpCount,
      bool unicode,
      bool variableBins)
    {
      DataPacket dataPacket1 = new DataPacket();
      for (int index = 0; index < rcps.Count; ++index)
      {
        if (rcps[index].IsValid)
        {
          DataPacket dataPacket2 = this.WriteRecipe(addr, (ModbusMap2Recipe) rcps[index], (ushort) index, unicode, variableBins);
          dataPacket1.Add(dataPacket2.Packets, dataPacket2.Actions);
        }
      }
      return dataPacket1;
    }

    public DataPacket RenameRecipe(byte addr, string oldName, string newName)
    {
      throw new NotImplementedException();
    }

    public DataPacket DeleteRecipe(byte addr, ushort recipeId)
    {
      DataPacket dataPacket = new DataPacket(3);
      dataPacket.Packets[0] = this.Write(addr, this.BinaryAddress((ushort) 41081), recipeId);
      dataPacket.Actions[0] = CurrentAction.A_WRITE_RECIPE_INDEX;
      dataPacket.Packets[1] = this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 19);
      dataPacket.Actions[1] = CurrentAction.A_COMMAND;
      dataPacket.Packets[2] = this.Write(addr, this.BinaryAddress((ushort) 41081), (ushort) 0);
      dataPacket.Actions[2] = CurrentAction.A_WRITE_RECIPE_INDEX;
      return dataPacket;
    }

    public DataPacket DeleteAllRecipes(byte addr, ushort rcpCount)
    {
      if (rcpCount == (ushort) 0)
        return new DataPacket((byte[][]) null, (CurrentAction[]) null);
      DataPacket dataPacket1 = new DataPacket();
      DataPacket dataPacket2;
      for (ushort index = 1; (int) index <= (int) rcpCount; ++index)
      {
        dataPacket2 = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41081), index), CurrentAction.A_WRITE_RECIPE_INDEX);
        dataPacket1.Add(dataPacket2.Packets, dataPacket2.Actions);
        dataPacket2 = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 19), CurrentAction.A_COMMAND);
        dataPacket1.Add(dataPacket2.Packets, dataPacket2.Actions);
      }
      dataPacket2 = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41081), (ushort) 0), CurrentAction.A_WRITE_RECIPE_INDEX);
      dataPacket1.Add(dataPacket2.Packets, dataPacket2.Actions);
      return dataPacket1;
    }

    public DataPacket GetDeviceStatus(byte addr)
    {
      return new DataPacket(this.Read(addr, this.BinaryAddress((ushort) 41002), (ushort) 1), CurrentAction.A_GET_DEVICE_STATUS);
    }

    public DataPacket ReadMapRevRegister(byte addr)
    {
      return new DataPacket(this.Read(addr, this.BinaryAddress((ushort) 40001), (ushort) 2), CurrentAction.A_READ_MAPREV_REGISTER);
    }

    public DataPacket ReadDIUserId(byte addr)
    {
      return new DataPacket(this.Read(addr, this.BinaryAddress((ushort) 43061), (ushort) 1), CurrentAction.A_READ_USER_ID);
    }

    public DataPacket ReadDIUserPassword(byte addr)
    {
      byte[][] inPkts = new byte[1][];
      CurrentAction[] acts = new CurrentAction[1];
      inPkts[0] = this.Read(addr, this.BinaryAddress((ushort) 43062), (ushort) 16);
      acts[0] = CurrentAction.A_READ_USER_PASSWORD;
      return new DataPacket(inPkts, acts);
    }

    public DataPacket WriteDIUserIdPassword(byte addr, ushort id, string pw, bool unicode)
    {
      DataPacket dataPacket = new DataPacket();
      DataPacket tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 43061), id), CurrentAction.A_WRITE_USER_ID);
      dataPacket.Add(tmpPkt);
      byte[] bytes = new byte[32];
      string s = pw.Substring(0, Math.Min(pw.Length, 16));
      try
      {
        if (unicode)
          Encoding.Unicode.GetBytes(s, 0, s.Length, bytes, 0);
        else
          Encoding.ASCII.GetBytes(s, 0, s.Length, bytes, 0);
      }
      catch (Exception ex)
      {
        Trace.WriteLine("exception from encoding GetBytes: " + ex.Message);
      }
      for (ushort startIndex = 0; (int) startIndex < bytes.Length; startIndex += (ushort) 2)
      {
        tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) (43062 + (int) startIndex / 2)), BitConverter.ToUInt16(bytes, (int) startIndex)), CurrentAction.A_WRITE_USER_PASSWORD);
        dataPacket.Add(tmpPkt.Packets, tmpPkt.Actions);
      }
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 32), CurrentAction.A_COMMAND);
      dataPacket.Add(tmpPkt);
      return dataPacket;
    }

    public DataPacket ReadDataIntegrityMode(byte addr)
    {
      return new DataPacket(this.Read(addr, this.BinaryAddress((ushort) 41171), (ushort) 1), CurrentAction.A_READ_DATA_INTEGRITY_MODE);
    }

    public DataPacket ReadDataIntegrityTimeout(byte addr)
    {
      return new DataPacket(this.Read(addr, this.BinaryAddress((ushort) 41172), (ushort) 1), CurrentAction.A_READ_DATA_INTEGRITY_TIMEOUT);
    }

    public DataPacket WriteDataIntegrityTimeout(byte addr, ushort diIdleTimeMinutes)
    {
      DataPacket dataPacket = new DataPacket();
      DataPacket tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41172), diIdleTimeMinutes), CurrentAction.A_WRITE_DATA_INTEGRITY_TIMEOUT);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 32), CurrentAction.A_COMMAND);
      dataPacket.Add(tmpPkt);
      return dataPacket;
    }

    public DataPacket WriteDateTime(byte addr)
    {
      DataPacket dataPacket = new DataPacket();
      DateTime now = DateTime.Now;
      DataPacket tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41006), (ushort) now.Year), CurrentAction.A_WRITE_DATE_YEAR);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41007), (ushort) now.Month), CurrentAction.A_WRITE_DATE_MONTH);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41008), (ushort) now.Day), CurrentAction.A_WRITE_DATE_DAY);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41009), (ushort) now.Hour), CurrentAction.A_WRITE_DATE_HOUR);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41010), (ushort) now.Minute), CurrentAction.A_WRITE_DATE_MINUTE);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41011), (ushort) now.Second), CurrentAction.A_WRITE_DATE_SECOND);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 8), CurrentAction.A_COMMAND);
      dataPacket.Add(tmpPkt);
      return dataPacket;
    }

    public DataPacket SetDataIntegrityMode(byte addr, ushort enable, ushort diIdleTimeMinutes)
    {
      DataPacket dataPacket = new DataPacket();
      DataPacket tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41171), enable), CurrentAction.A_WRITE_DATA_INTEGRITY_MODE);
      dataPacket.Add(tmpPkt);
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 43061), (ushort) 0), CurrentAction.A_WRITE_USER_ID);
      dataPacket.Add(tmpPkt);
      for (ushort index = 0; index < (ushort) 16; ++index)
      {
        tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) (43062U + (uint) index)), (ushort) 0), CurrentAction.A_WRITE_USER_PASSWORD);
        dataPacket.Add(tmpPkt.Packets, tmpPkt.Actions);
      }
      if (enable == (ushort) 1)
      {
        tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41172), diIdleTimeMinutes), CurrentAction.A_WRITE_DATA_INTEGRITY_TIMEOUT);
        dataPacket.Add(tmpPkt);
      }
      tmpPkt = new DataPacket(this.Write(addr, this.BinaryAddress((ushort) 41001), (ushort) 32), CurrentAction.A_COMMAND);
      dataPacket.Add(tmpPkt);
      return dataPacket;
    }

    public DataPacket DisableLocalControl(byte addr)
    {
      return new DataPacket(this.Write((byte) 1, this.BinaryAddress((ushort) 41001), (ushort) 12), CurrentAction.A_COMMAND);
    }

    public DataPacket EnableLocalControl(byte addr)
    {
      return new DataPacket(this.Write((byte) 1, this.BinaryAddress((ushort) 41001), (ushort) 13), CurrentAction.A_COMMAND);
    }

    public DataPacket ReadDeviceInfo(byte addr, ushort mapRev)
    {
      byte[][] inPkts = new byte[1][];
      CurrentAction[] acts = new CurrentAction[1];
      ushort length = mapRev < (ushort) 207 ? (mapRev <= (ushort) 200 ? (ushort) 65 : (ushort) 77) : (ushort) 89;
      inPkts[0] = this.Read(addr, this.BinaryAddress((ushort) 40002), length);
      acts[0] = CurrentAction.A_READ_DEVICE_INFO;
      return new DataPacket(inPkts, acts);
    }

    public ushort BinaryAddress(ushort regAddr) => (ushort) ((uint) regAddr - 40001U);

    public byte[] Read(byte unit, ushort start, ushort length)
    {
      if (length > (ushort) 125)
        throw new ArgumentOutOfRangeException("Length", (object) length, "Value cannot be larger than 125");
      byte[] numArray = new byte[12];
      ushort uint16 = Convert.ToUInt16(new Random().Next((int) ushort.MaxValue));
      numArray[0] = (byte) (((int) uint16 & 65280) >> 8);
      numArray[1] = (byte) ((uint) uint16 & (uint) byte.MaxValue);
      numArray[2] = (byte) 0;
      numArray[3] = (byte) 0;
      numArray[4] = (byte) 0;
      numArray[5] = (byte) 6;
      numArray[6] = unit;
      numArray[7] = (byte) 3;
      numArray[8] = (byte) (((int) start & 65280) >> 8);
      numArray[9] = (byte) ((uint) start & (uint) byte.MaxValue);
      numArray[10] = (byte) (((int) length & 65280) >> 8);
      numArray[11] = (byte) ((uint) length & (uint) byte.MaxValue);
      return numArray;
    }

    public byte[] Write(byte addr, ushort reg, ushort value)
    {
      byte[] numArray = new byte[12];
      ushort uint16 = Convert.ToUInt16(new Random().Next((int) ushort.MaxValue));
      numArray[0] = (byte) (((int) uint16 & 65280) >> 8);
      numArray[1] = (byte) ((uint) uint16 & (uint) byte.MaxValue);
      numArray[2] = (byte) 0;
      numArray[3] = (byte) 0;
      numArray[4] = (byte) 0;
      numArray[5] = (byte) 6;
      numArray[6] = addr;
      numArray[7] = (byte) 6;
      numArray[8] = (byte) (((int) reg & 65280) >> 8);
      numArray[9] = (byte) ((uint) reg & (uint) byte.MaxValue);
      numArray[10] = (byte) (((int) value & 65280) >> 8);
      numArray[11] = (byte) ((uint) value & (uint) byte.MaxValue);
      return numArray;
    }
  }
}
