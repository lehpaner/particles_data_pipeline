﻿// Decompiled with JetBrains decompiler
// Type: TSI.ZoneList
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Text;

#nullable disable
namespace TSI
{
  public class ZoneList : List<IZone>
  {
    public ZoneList()
    {
    }

    public ZoneList(int count)
      : base(count)
    {
    }

    public ZoneList(IEnumerable<IZone> collection)
      : base(collection)
    {
    }

    public int AddNew(IZone zone)
    {
      int index = this.FindIndex((Predicate<IZone>) (z => !z.IsValid));
      if (index != -1 && index < this.Count)
      {
        this[index].Name = zone.Name;
        this[index].Airflow = zone.Airflow;
        this[index].Area = zone.Area;
        this[index].AreaUnits = zone.AreaUnits;
        this[index].RecipeId = zone.RecipeId;
        this[index].Standard = zone.Standard;
        this[index].ZoneClass = zone.ZoneClass;
        this[index].ZoneState = zone.ZoneState;
        this[index].Modified = true;
      }
      return index;
    }

    public int AddNew() => this.FindIndex((Predicate<IZone>) (z => !z.IsValid));

    public List<IZone> GetValid() => this.FindAll((Predicate<IZone>) (z => z.IsValid));

    public int Find(string name) => this.FindIndex((Predicate<IZone>) (z => z.Name.Equals(name)));

    public void Remove(int zoneId)
    {
      this[zoneId].Name = string.Empty;
      this[zoneId].Modified = false;
      this[zoneId].RecipeId = -1;
      this[zoneId].Area = 0M;
      this[zoneId].Recipe = (ModbusMap2Recipe) null;
    }

    public int GetId(string name) => this.FindIndex((Predicate<IZone>) (z => z.Name.Equals(name)));

    public List<IZone> GetModified() => this.FindAll((Predicate<IZone>) (z => z.Modified));

    public string GetNames()
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (IZone zone in (List<IZone>) this)
      {
        if (zone.IsValid)
          stringBuilder.AppendFormat("{0} ", (object) zone.Name);
      }
      return stringBuilder.ToString();
    }
  }
}
