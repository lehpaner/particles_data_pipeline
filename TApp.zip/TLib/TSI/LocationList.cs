﻿// Decompiled with JetBrains decompiler
// Type: TSI.LocationList
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#nullable disable
namespace TSI
{
  public class LocationList : List<ILocation>
  {
    public LocationList()
    {
    }

    public LocationList(int count)
      : base(count)
    {
    }

    public LocationList(IEnumerable<ILocation> collection)
      : base(collection)
    {
    }

    public void RemoveAll()
    {
      for (int index = 0; index < this.Count; ++index)
      {
        this[index].Name = string.Empty;
        this[index].ZoneId = -1;
      }
    }

    public int Find(string name, int zoneId)
    {
      return this.FindIndex((Predicate<ILocation>) (loc => loc.Name == name && loc.ZoneId == zoneId));
    }

    public void Remove(string name, int zoneId)
    {
      int index = this.FindIndex((Predicate<ILocation>) (loc => loc.Name == name && loc.ZoneId == zoneId));
      if (index == -1)
        return;
      this[index].Name = string.Empty;
      this[index].ZoneId = -1;
      this[index].Modified = false;
    }

    public void RemoveLocations(List<ILocation> locations)
    {
      foreach (ILocation location in locations)
      {
        this[location.LocationId].Name = string.Empty;
        this[location.LocationId].ZoneId = -1;
        this[location.LocationId].Modified = false;
      }
    }

    public int AddNew(string name, int zoneId)
    {
      int index = this.FindIndex((Predicate<ILocation>) (loc => !loc.IsValid));
      if (index != -1)
      {
        this[index].Name = name;
        this[index].ZoneId = zoneId;
      }
      else
      {
        int count = this.Count;
        this.Add((ILocation) new ModbusMap2Location(count)
        {
          Name = name,
          ZoneId = zoneId
        });
        index = count;
      }
      return index;
    }

    public List<ILocation> GetModified()
    {
      return this.FindAll((Predicate<ILocation>) (loc => loc.Modified));
    }

    public List<ILocation> GetValid() => this.FindAll((Predicate<ILocation>) (loc => loc.IsValid));

    public List<ILocation> GetUnlocked()
    {
      return this.FindAll((Predicate<ILocation>) (loc => loc.IsValid && !loc.Locked && loc.Name != TSIStrings.UnknownName));
    }

    public int[] GetValidZones()
    {
      List<ILocation> valid = this.GetValid();
      int[] source = new int[valid.Count];
      for (int index = 0; index < valid.Count; ++index)
        source[index] = valid[index].ZoneId;
      return ((IEnumerable<int>) source).Distinct<int>().ToArray<int>();
    }

    public int GetAvailableLocations()
    {
      return this.FindAll((Predicate<ILocation>) (loc => !loc.IsValid)).Count;
    }

    public string GetNames()
    {
      StringBuilder stringBuilder = new StringBuilder();
      foreach (ILocation location in (List<ILocation>) this)
      {
        if (location.IsValid)
          stringBuilder.AppendFormat("{0} ", (object) location.Name);
      }
      return stringBuilder.ToString();
    }
  }
}
