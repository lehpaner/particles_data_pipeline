﻿// Decompiled with JetBrains decompiler
// Type: TSI.ModbusMap2Record
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Runtime.Serialization;
using TrakProLiteClassLibrary;
using TSI.Globals;

#nullable disable
namespace TSI
{
  [Serializable]
  public class ModbusMap2Record : ISample, IDeserializationCallback
  {
    public uint recNum;
    public DateTime dateTime;
    private ushort viableDetectionSensitivity;
    private float precisionFlowRate;
    private ushort deviceStatus;
    public FlowStatus flowStatus;
    public TSI.LaserStatus laserStatus;
    public bool scatterAlert;
    public bool opticsDirty;
    public bool calibrationCorrupt;
    public bool serviceAlert;
    public bool dataValid;
    public bool[] chAlarm = new bool[16];
    public ushort flowRateX100;
    public FlowType flowType;
    public TimeSpan sampleTime;
    public TimeUnits timeUnit;
    private string recipeSampleTime = string.Empty;
    private RecordType countMode;
    public UnitType unitMode = UnitType.Counts;
    public VolumeType volumeType;
    public ushort locNumber;
    public string locName = string.Empty;
    private string zoneName = string.Empty;
    public uint[] counts = new uint[16];
    public ushort[] chSizes = new ushort[16];
    private int numDeviceChannels = 16;
    private int numNonViableChannels = 16;
    public UnitCode tempUnit;
    public float temperature;
    public UnitCode humidityUnit;
    public float humidity;
    public UnitCode velocityUnit;
    public float velocity;
    public UnitCode flowUnit;
    public float flow;
    public UnitCode CO2Unit;
    public float CO2;
    public UnitCode COUnit;
    public float CO;
    public UnitCode pressureUnit;
    public float pressure;
    public ushort measurementEnabled;
    private ushort diUserId;
    private string diUsername;
    public TemperatureType tempType;

    public ModbusMap2Record(int deviceChannels, int nonViableChannels)
    {
      this.numDeviceChannels = deviceChannels;
      this.numNonViableChannels = nonViableChannels;
    }

    void IDeserializationCallback.OnDeserialization(object sender)
    {
      this.numNonViableChannels = 16;
      this.numDeviceChannels = 16;
    }

    public uint SampleID => this.recNum;

    public DateTime TimeStamp => this.dateTime;

    public ushort ViableDetectionSensitivity
    {
      get => this.viableDetectionSensitivity;
      set => this.viableDetectionSensitivity = value;
    }

    public float PrecisionFlowRate
    {
      get => this.precisionFlowRate;
      set => this.precisionFlowRate = value;
    }

    public ushort DeviceStatus
    {
      get => this.deviceStatus;
      set => this.deviceStatus = value;
    }

    public ushort InstrumentStatus => (ushort) ((uint) this.deviceStatus & 112U);

    public FlowStatus FlowStatus => this.flowStatus;

    public bool LaserStatus => this.laserStatus == TSI.LaserStatus.OK;

    public bool ScatterAlert => this.scatterAlert;

    public bool OpticsDirty => this.opticsDirty;

    public bool CalibrationCorrupt => this.calibrationCorrupt;

    public bool ServiceAlert => this.serviceAlert;

    public bool DataValid => this.dataValid;

    public bool AlarmActive
    {
      get
      {
        for (int index = 0; index < this.chAlarm.Length; ++index)
        {
          if (this.chAlarm[index])
            return true;
        }
        return false;
      }
    }

    public double AverageFlowRateCubicMetresPerSecond => Convert.ToDouble(this.FlowRate);

    public TimeSpan SampleTime => this.sampleTime;

    public string RecipeSampleTime
    {
      get => this.recipeSampleTime;
      set => this.recipeSampleTime = value;
    }

    public RecordType CountMode
    {
      get => this.countMode;
      set => this.countMode = value;
    }

    public bool Normalized => this.unitMode != UnitType.Counts;

    public VolumeType VolumeUnits
    {
      get => this.volumeType;
      set => this.volumeType = value;
    }

    public int LocationId => (int) this.locNumber;

    public string Location
    {
      get => this.locName;
      set => this.locName = value;
    }

    public string Zone
    {
      get => this.zoneName;
      set => this.zoneName = value;
    }

    public int NumberOfChannels => this.numDeviceChannels;

    public int NumberOfNonViableChannels => this.numNonViableChannels;

    public TemperatureType TemperatureUnits
    {
      get
      {
        if (this.tempUnit == UnitCode.F)
          return TemperatureType.F;
        return this.tempUnit == UnitCode.C ? TemperatureType.C : TemperatureType.NA;
      }
    }

    public Decimal Temperature => Convert.ToDecimal(this.temperature);

    public string Temp
    {
      get
      {
        if (this.tempUnit != UnitCode.NA)
        {
          switch (this.tempType)
          {
            case TemperatureType.F:
              if (this.tempUnit == UnitCode.C)
                return ((float) (9.0 * (double) this.temperature / 5.0 + 32.0)).ToString("F1");
              return this.tempUnit == UnitCode.F ? this.temperature.ToString("F1") : "N/A";
            case TemperatureType.C:
              if (this.tempUnit == UnitCode.C)
                return this.temperature.ToString("F1");
              return this.tempUnit == UnitCode.F ? ((float) (((double) this.temperature - 32.0) * 5.0 / 9.0)).ToString("F1") : "N/A";
          }
        }
        return "N/A";
      }
    }

    public UnitCode HumidityUnits => this.humidityUnit;

    public Decimal Humidity => Convert.ToDecimal(this.humidity);

    public UnitCode AirVelocityUnits => this.velocityUnit;

    public Decimal AirVelocity => Convert.ToDecimal(this.velocity);

    public ushort DIUserId
    {
      get => this.diUserId;
      set => this.diUserId = value;
    }

    public string DIUsername
    {
      get => this.diUsername;
      set => this.diUsername = value;
    }

    public Decimal VolumeLitres
    {
      get
      {
        FlowType flowType = this.flowType;
        float num;
        if ((double) this.precisionFlowRate == 0.0)
        {
          num = (float) this.flowRateX100 / 100f;
        }
        else
        {
          flowType = FlowType.CFM;
          num = this.precisionFlowRate;
        }
        switch (flowType)
        {
          case FlowType.CFM:
            return this.flowRateX100 == (ushort) 177 ? Convert.ToDecimal((float) this.sampleTime.TotalMinutes * 50f) : Convert.ToDecimal((float) (this.sampleTime.TotalMinutes * (double) num * 28.299999237060547));
          case FlowType.LPM:
            return Convert.ToDecimal((float) this.sampleTime.TotalMinutes * num);
          default:
            return 0M;
        }
      }
    }

    public Decimal Volume => Sample.ConvertLitresVolume(this.VolumeLitres, this.volumeType);

    public Decimal FlowRate
    {
      get
      {
        FlowType flowType = this.flowType;
        Decimal flowRate;
        if ((double) this.precisionFlowRate == 0.0)
        {
          flowRate = (Decimal) this.flowRateX100 / 100.0M;
        }
        else
        {
          flowRate = Convert.ToDecimal(this.precisionFlowRate);
          flowType = FlowType.CFM;
        }
        switch (this.volumeType)
        {
          case VolumeType.FeetCubed:
            if (flowType == FlowType.CFM)
              return flowRate;
            return flowType == FlowType.LPM ? flowRate * 0.0353356890459363957597173145M : 0M;
          case VolumeType.MetresCubed:
            if (flowType == FlowType.CFM)
              return flowRate * 0.0283M;
            return flowType == FlowType.LPM ? flowRate * 0.001M : 0M;
          case VolumeType.Litres:
            if (flowType == FlowType.CFM)
              return flowRate * 28.3M;
            return flowType == FlowType.LPM ? flowRate : 0M;
          default:
            return 0M;
        }
      }
    }

    public ChannelCollection Channels
    {
      get
      {
        ChannelCollection channels = new ChannelCollection();
        for (int index = 0; index < this.numNonViableChannels; ++index)
        {
          Decimal particleSizeMicrometres = (Decimal) this.chSizes[index] / 1000M;
          Channel channel = new Channel(this.chAlarm[index], false, particleSizeMicrometres, (Decimal) this.counts[index]);
          channels.Add((IChannel) channel);
        }
        return channels;
      }
    }

    public ChannelCollection ViableChannels
    {
      get
      {
        ChannelCollection viableChannels = new ChannelCollection();
        int num = this.numDeviceChannels - this.numNonViableChannels;
        for (int index = 0; index < num; ++index)
        {
          Decimal particleSizeMicrometres = (Decimal) this.chSizes[index + num] / 1000M;
          Channel channel = new Channel(this.chAlarm[index + num], false, particleSizeMicrometres, (Decimal) this.counts[index + num]);
          viableChannels.Add((IChannel) channel);
        }
        return viableChannels;
      }
    }

    public string DeviceStatusText
    {
      get
      {
        string str = "";
        if (this.calibrationCorrupt)
          str += "CAL ";
        if (this.opticsDirty)
          str += "OPT ";
        if (this.scatterAlert)
          str += "SCR ";
        if (this.InstrumentStatus != (ushort) 0)
          str += "Error";
        if (str == "")
          str = "OK";
        return str.Trim();
      }
    }

    public string ViableDetectionSensitiviyString
    {
      get
      {
        if (this.viableDetectionSensitivity == (ushort) 1)
          return "Normal";
        return this.viableDetectionSensitivity == (ushort) 2 ? "High" : "Disabled";
      }
    }

    public string FlowStatusText => TSIStrings.FlowStatusStrings[(int) this.flowStatus];

    public string LaserStatusText => this.laserStatus != TSI.LaserStatus.OK ? "Error" : "OK";

    public string Velocity
    {
      get
      {
        switch (this.velocityUnit)
        {
          case UnitCode.NA:
            return "N/A";
          case UnitCode.ft_min:
            return ((double) this.velocity / 60.0).ToString("F2") + "ft/s";
          case UnitCode.m_sec:
            return this.velocity.ToString("F2") + "m/s";
          case UnitCode.ft_sec:
            return this.velocity.ToString("F2") + "ft/s";
          default:
            return "N/A";
        }
      }
    }

    public Decimal GetParticleCount(
      IChannel channel,
      bool normalized,
      VolumeType normalizedParticleVolume)
    {
      Decimal particleCount = Convert.ToDecimal(channel.ParticleCount);
      return normalized ? Sample.Normalize(particleCount, normalizedParticleVolume, this.VolumeLitres) : particleCount;
    }
  }
}
