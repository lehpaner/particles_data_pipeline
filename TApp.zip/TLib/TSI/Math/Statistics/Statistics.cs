﻿// Decompiled with JetBrains decompiler
// Type: TSI.Math.Statistics.Statistics
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TSI.Math.Statistics
{
  internal class Statistics
  {
    public double Sum(double[] lstNum)
    {
      double num = 0.0;
      for (int index = 0; index < lstNum.Length; ++index)
        num += lstNum[index];
      return num;
    }

    public double Average(double[] lstNum)
    {
      return lstNum.Length == 0 ? 0.0 : this.Sum(lstNum) / (double) lstNum.Length;
    }

    public double StandardDeviation(double[] lstNum)
    {
      if (lstNum.Length <= 1)
        return 0.0;
      double num1 = this.Average(lstNum);
      double num2 = 0.0;
      for (int index = 0; index < lstNum.Length; ++index)
        num2 += System.Math.Pow(lstNum[index] - num1, 2.0);
      return System.Math.Sqrt(num2 / (double) (lstNum.Length - 1));
    }

    public double StandardError(double stdDev, int sCnt)
    {
      return sCnt <= 0 ? 0.0 : stdDev / System.Math.Sqrt((double) sCnt);
    }

    public double Min(double[] lstNum)
    {
      if (lstNum.Length == 0)
        return 0.0;
      double maxValue = double.MaxValue;
      for (int index = 0; index < lstNum.Length; ++index)
      {
        if (maxValue > lstNum[index])
          maxValue = lstNum[index];
      }
      return maxValue;
    }

    public double Max(double[] lstNum)
    {
      if (lstNum.Length == 0)
        return 0.0;
      double minValue = double.MinValue;
      for (int index = 0; index < lstNum.Length; ++index)
      {
        if (minValue < lstNum[index])
          minValue = lstNum[index];
      }
      return minValue;
    }

    public Decimal UpperConfidenceLevel95(double[] lstNum)
    {
      int length = lstNum.Length;
      if (length <= 1 || length >= 10)
        return 0.0M;
      Decimal uclFactor;
      switch (length)
      {
        case 2:
          uclFactor = 6.3M;
          break;
        case 3:
          uclFactor = 2.9M;
          break;
        case 4:
          uclFactor = 2.4M;
          break;
        case 5:
          uclFactor = 2.1M;
          break;
        case 6:
          uclFactor = 2.0M;
          break;
        case 7:
          uclFactor = 1.9M;
          break;
        case 8:
          uclFactor = 1.90M;
          break;
        default:
          uclFactor = 1.90M;
          break;
      }
      return this.UCL95(uclFactor, lstNum);
    }

    private Decimal UCL95(Decimal uclFactor, double[] lstNum)
    {
      Decimal d = Convert.ToDecimal(lstNum.Length);
      return Convert.ToDecimal(this.Average(lstNum)) + uclFactor * (Convert.ToDecimal(this.StandardDeviation(lstNum)) / (Decimal) System.Math.Sqrt((double) d));
    }
  }
}
