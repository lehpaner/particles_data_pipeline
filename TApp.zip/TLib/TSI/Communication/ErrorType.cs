﻿// Decompiled with JetBrains decompiler
// Type: TSI.Communication.ErrorType
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI.Communication
{
  public enum ErrorType
  {
    E_RECEIVE,
    E_SEND,
    E_CONNECTION,
    E_NODEVICEFOUND,
    E_ARGUMENT,
    E_SOCKET,
    E_AUTHORIZATION,
  }
}
