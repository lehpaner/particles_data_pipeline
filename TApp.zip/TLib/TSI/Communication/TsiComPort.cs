﻿// Decompiled with JetBrains decompiler
// Type: TSI.Communication.TsiComPort
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.IO.Ports;

#nullable disable
namespace TSI.Communication
{
  public class TsiComPort : SerialPort
  {
    public string idStr;
    public CurrentAction act;

    public TsiComPort(
      string portName,
      int baudRate,
      Parity parity,
      int dataBits,
      StopBits stopBits)
      : base(portName, baudRate, parity, dataBits, stopBits)
    {
      this.idStr = portName;
    }

    public void Remove()
    {
      if (this.IsOpen)
        this.Close();
      this.Dispose();
    }
  }
}
