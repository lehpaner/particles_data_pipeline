﻿// Decompiled with JetBrains decompiler
// Type: TSI.Communication.TsiIPClient
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System.Net;

#nullable disable
namespace TSI.Communication
{
  public class TsiIPClient
  {
    private string hostName;
    public CurrentAction act;
    private IPAddress ipAddress;
    private int port;
    private CommunicationType comType;
    private ConnectionType connectionType;

    public TsiIPClient(IPAddress address, int port, CommunicationType type)
    {
      this.ipAddress = address;
      this.act = CurrentAction.A_IDLE;
      this.port = port;
      this.comType = type;
    }

    public TsiIPClient(
      IPAddress address,
      int port,
      string hostname,
      CommunicationType type,
      ConnectionType connType)
    {
      this.ipAddress = address;
      this.act = CurrentAction.A_IDLE;
      this.port = port;
      this.comType = type;
      this.hostName = hostname;
      this.connectionType = connType;
    }

    public string HostName
    {
      get => this.hostName;
      set => this.hostName = value;
    }

    public IPAddress IPAddress
    {
      get => this.ipAddress;
      set => this.ipAddress = value;
    }

    public int Port
    {
      get => this.port;
      set => this.port = value;
    }

    public CommunicationType CommunicationType
    {
      get => this.comType;
      set => this.comType = value;
    }

    public ConnectionType ConnectionType
    {
      get => this.connectionType;
      set => this.connectionType = value;
    }
  }
}
