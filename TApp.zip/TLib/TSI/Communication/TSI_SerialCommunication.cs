﻿// Decompiled with JetBrains decompiler
// Type: TSI.Communication.TSI_SerialCommunication
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;
using System.Management;
using System.Threading;

#nullable disable
namespace TSI.Communication
{
  public class TSI_SerialCommunication
  {
    private object serialLock = new object();
    private List<TsiComPort> comPorts;
    private string idStr;

    public event TSI_SerialCommunication.TextReceivedEventHandler TextReceived;

    public event TSI_SerialCommunication.CommunicationErrorEventHandler CommunicationError;

    public TSI_SerialCommunication(
      string portName,
      int baudRate,
      Parity parity,
      int dataBits,
      StopBits stopBits,
      string searchMsg,
      string respMsg,
      string idReq)
    {
      Trace.WriteLine("TSI_SerialCommunication.Constructor", "Info");
      this.comPorts = new List<TsiComPort>();
      Trace.WriteLine("1");
      if (!string.IsNullOrEmpty(idReq))
        this.idStr = idReq;
      Trace.WriteLine("2");
      if (portName == null)
      {
        Trace.WriteLine("3 " + SerialPort.GetPortNames().Length.ToString());
        foreach (string portName1 in SerialPort.GetPortNames())
        {
          Trace.WriteLine("Checking port: " + portName1);
          TsiComPort tsiComPort = new TsiComPort(portName1, baudRate, parity, dataBits, stopBits);
          tsiComPort.DiscardNull = true;
          tsiComPort.NewLine = "\r\n";
          tsiComPort.ReadBufferSize = 1048576;
          tsiComPort.WriteBufferSize = 1024;
          try
          {
            Trace.WriteLine("Before opening port: " + portName1);
            tsiComPort.Open();
            Trace.WriteLine("After opening port: " + portName1);
            try
            {
              tsiComPort.WriteTimeout = 10;
              tsiComPort.Write(searchMsg);
            }
            catch (Exception ex)
            {
            }
            Trace.WriteLine("After writing to port: " + portName1);
            Thread.Sleep(25);
            Trace.WriteLine("After Thread.Sleep(25)");
            if (tsiComPort.BytesToRead > 0 && tsiComPort.ReadExisting() == respMsg)
            {
              Trace.WriteLine("TSI_SerialCommunication.Constructor: adding " + portName1, "Info");
              if (idReq != null)
              {
                for (int startIndex = 0; startIndex < idReq.Length; ++startIndex)
                {
                  tsiComPort.Write(idReq.Substring(startIndex, 1));
                  Thread.Sleep(25);
                }
                int bytesToRead = tsiComPort.BytesToRead;
                Thread.Sleep(25);
                while (bytesToRead < tsiComPort.BytesToRead)
                {
                  bytesToRead = tsiComPort.BytesToRead;
                  Thread.Sleep(25);
                }
                tsiComPort.idStr = tsiComPort.ReadExisting();
                tsiComPort.idStr = tsiComPort.idStr.Replace("\r\n", "");
              }
              else
                tsiComPort.idStr = portName1;
              tsiComPort.DataReceived += new SerialDataReceivedEventHandler(this.OnSerialDataReceived);
              tsiComPort.ErrorReceived += new SerialErrorReceivedEventHandler(this.OnSerialCommunicationErrorReceived);
              tsiComPort.act = CurrentAction.A_IDLE;
              tsiComPort.ReadTimeout = 100;
              this.comPorts.Add(tsiComPort);
            }
            else
              tsiComPort.Remove();
          }
          catch (InvalidOperationException ex)
          {
            if (this.CommunicationError != null)
              this.CommunicationError(ErrorType.E_CONNECTION, CurrentAction.A_IDLE, ex.Message);
          }
          catch (ArgumentOutOfRangeException ex)
          {
            if (this.CommunicationError != null)
              this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_IDLE, ex.Message);
          }
          catch (ArgumentException ex)
          {
            if (this.CommunicationError != null)
              this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_IDLE, ex.Message);
          }
          catch (UnauthorizedAccessException ex)
          {
            if (this.CommunicationError != null)
              this.CommunicationError(ErrorType.E_AUTHORIZATION, CurrentAction.A_IDLE, ex.Message);
          }
          catch (TimeoutException ex)
          {
            if (this.CommunicationError != null)
              this.CommunicationError(ErrorType.E_CONNECTION, CurrentAction.A_IDLE, ex.Message);
          }
          catch (IOException ex)
          {
            if (this.CommunicationError != null)
              this.CommunicationError(ErrorType.E_CONNECTION, CurrentAction.A_IDLE, ex.Message);
          }
          Trace.WriteLine("Done with port: " + portName1);
        }
        Trace.WriteLine("4");
      }
      else
      {
        Trace.WriteLine("TSI_SerialCommunication.Constructor: adding " + portName, "Info");
        TsiComPort tsiComPort = new TsiComPort(portName, baudRate, parity, dataBits, stopBits);
        tsiComPort.idStr = portName;
        tsiComPort.DiscardNull = true;
        tsiComPort.NewLine = "\r\n";
        tsiComPort.ReadBufferSize = 1048576;
        tsiComPort.WriteBufferSize = 1024;
        tsiComPort.DataReceived += new SerialDataReceivedEventHandler(this.OnSerialDataReceived);
        tsiComPort.ErrorReceived += new SerialErrorReceivedEventHandler(this.OnSerialCommunicationErrorReceived);
        this.comPorts.Add(tsiComPort);
      }
      Trace.WriteLine("Out of TSI_SerialCommunication.Constructor(...)", "Info");
    }

    public List<string> GetBluetoothCOMPorts64()
    {
      List<string> bluetoothComPorts64 = new List<string>();
      RegistryKey registryKey1 = (RegistryKey) null;
      RegistryKey registryKey2 = (RegistryKey) null;
      RegistryKey registryKey3;
      try
      {
        registryKey3 = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, "", RegistryView.Registry64);
      }
      catch (Exception ex)
      {
        registryKey1?.Dispose();
        return bluetoothComPorts64;
      }
      if (registryKey3 == null)
        return bluetoothComPorts64;
      RegistryKey registryKey4;
      try
      {
        registryKey4 = registryKey3.OpenSubKey("HARDWARE\\DEVICEMAP\\SERIALCOMM", false);
      }
      catch (Exception ex)
      {
        registryKey2?.Dispose();
        return bluetoothComPorts64;
      }
      if (registryKey4 == null)
        return bluetoothComPorts64;
      string[] valueNames;
      try
      {
        valueNames = registryKey4.GetValueNames();
      }
      catch (Exception ex)
      {
        return bluetoothComPorts64;
      }
      if (valueNames == null)
        return bluetoothComPorts64;
      for (int index = 0; index < valueNames.Length; ++index)
      {
        if (valueNames[index].StartsWith("\\Device\\Bt") || valueNames[index].StartsWith("\\Device\\bt"))
        {
          string str = "";
          object obj = registryKey4.GetValue(valueNames[index]);
          if (obj != null)
            str = obj.ToString();
          if (!string.IsNullOrEmpty(str))
            bluetoothComPorts64.Add(str);
        }
      }
      return bluetoothComPorts64;
    }

    public List<string> GetBluetoothCOMPorts32()
    {
      List<string> bluetoothComPorts32 = new List<string>();
      RegistryKey registryKey1 = (RegistryKey) null;
      RegistryKey registryKey2 = (RegistryKey) null;
      RegistryKey registryKey3;
      try
      {
        registryKey3 = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, "", RegistryView.Registry32);
      }
      catch (Exception ex)
      {
        registryKey1?.Dispose();
        return bluetoothComPorts32;
      }
      if (registryKey3 == null)
        return bluetoothComPorts32;
      RegistryKey registryKey4;
      try
      {
        registryKey4 = registryKey3.OpenSubKey("HARDWARE\\DEVICEMAP\\SERIALCOMM", false);
      }
      catch (Exception ex)
      {
        registryKey2?.Dispose();
        return bluetoothComPorts32;
      }
      if (registryKey4 == null)
        return bluetoothComPorts32;
      string[] valueNames;
      try
      {
        valueNames = registryKey4.GetValueNames();
      }
      catch (Exception ex)
      {
        return bluetoothComPorts32;
      }
      if (valueNames == null)
        return bluetoothComPorts32;
      for (int index = 0; index < valueNames.Length; ++index)
      {
        if (valueNames[index].StartsWith("\\device\\Bt") || valueNames[index].StartsWith("\\device\\bt"))
        {
          string str = "";
          object obj = registryKey4.GetValue(valueNames[index]);
          if (obj != null)
            str = obj.ToString();
          if (!string.IsNullOrEmpty(str))
            bluetoothComPorts32.Add(str);
        }
      }
      return bluetoothComPorts32;
    }

    public List<string> GetFTDICOMPorts()
    {
      List<string> ftdicomPorts = new List<string>();
      ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM WIN32_PnPEntity WHERE Manufacturer=\"FTDI\"");
      try
      {
        foreach (ManagementObject managementObject in managementObjectSearcher.Get())
        {
          string str1 = "";
          string str2 = "";
          if (managementObject["PNPDeviceID"] != null)
            str1 = managementObject["PNPDeviceID"].ToString();
          if (managementObject["Name"] != null)
            str2 = managementObject["Name"].ToString();
          if (str1.StartsWith("FTDI"))
          {
            int startIndex = str2.IndexOf("COM");
            if (startIndex != -1)
            {
              string str3 = str2.Substring(startIndex).Trim(')');
              ftdicomPorts.Add(str3);
            }
          }
        }
      }
      catch (Exception ex)
      {
      }
      return ftdicomPorts;
    }

    public string[] RescanDevices(
      string portName,
      int baudRate,
      Parity parity,
      int dataBits,
      StopBits stopBits,
      string searchMsg,
      string respMsg,
      string idReq)
    {
      Trace.WriteLine("In RescanDevices - SERIAL");
      string[] array = new string[0];
      List<string> ftdicomPorts = this.GetFTDICOMPorts();
      if (portName == null)
      {
        foreach (string str in ftdicomPorts)
        {
          string s = str;
          if (this.comPorts.Find((Predicate<TsiComPort>) (cp => cp.PortName == s)) == null)
          {
            TsiComPort tsiComPort = new TsiComPort(s, baudRate, parity, dataBits, stopBits);
            tsiComPort.DiscardNull = true;
            tsiComPort.NewLine = "\r\n";
            tsiComPort.ReadBufferSize = 1048576;
            tsiComPort.WriteBufferSize = 1024;
            try
            {
              try
              {
                tsiComPort.Open();
              }
              catch (UnauthorizedAccessException ex)
              {
                tsiComPort.Remove();
                continue;
              }
              try
              {
                tsiComPort.WriteTimeout = 10;
                tsiComPort.Write(searchMsg);
              }
              catch (Exception ex)
              {
              }
              Thread.Sleep(25);
              if (tsiComPort.BytesToRead > 0 && tsiComPort.ReadExisting() == respMsg)
              {
                Trace.WriteLine("TSI_SerialCommunication.RescanPorts: adding " + s, "Info");
                if (idReq != null)
                {
                  for (int startIndex = 0; startIndex < idReq.Length; ++startIndex)
                  {
                    tsiComPort.Write(idReq.Substring(startIndex, 1));
                    Thread.Sleep(25);
                  }
                  int bytesToRead = tsiComPort.BytesToRead;
                  Thread.Sleep(25);
                  while (bytesToRead < tsiComPort.BytesToRead)
                  {
                    bytesToRead = tsiComPort.BytesToRead;
                    Thread.Sleep(25);
                  }
                  tsiComPort.idStr = tsiComPort.ReadExisting();
                  tsiComPort.idStr = tsiComPort.idStr.Replace("\r\n", "");
                }
                else
                  tsiComPort.idStr = s;
                tsiComPort.DataReceived += new SerialDataReceivedEventHandler(this.OnSerialDataReceived);
                tsiComPort.ErrorReceived += new SerialErrorReceivedEventHandler(this.OnSerialCommunicationErrorReceived);
                tsiComPort.act = CurrentAction.A_IDLE;
                this.comPorts.Add(tsiComPort);
                Array.Resize<string>(ref array, array.Length + 1);
                array[array.Length - 1] = tsiComPort.idStr;
              }
              else
                tsiComPort.Remove();
            }
            catch (InvalidOperationException ex)
            {
              if (this.CommunicationError != null)
                this.CommunicationError(ErrorType.E_CONNECTION, CurrentAction.A_IDLE, ex.Message);
            }
            catch (ArgumentOutOfRangeException ex)
            {
              if (this.CommunicationError != null)
                this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_IDLE, ex.Message);
            }
            catch (ArgumentException ex)
            {
              if (this.CommunicationError != null)
              {
                if (ex.ParamName != nameof (portName))
                  this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_IDLE, ex.Message);
              }
            }
            catch (UnauthorizedAccessException ex)
            {
              if (this.CommunicationError != null)
                this.CommunicationError(ErrorType.E_AUTHORIZATION, CurrentAction.A_IDLE, ex.Message);
            }
            catch (TimeoutException ex)
            {
              if (this.CommunicationError != null)
                this.CommunicationError(ErrorType.E_CONNECTION, CurrentAction.A_IDLE, ex.Message);
            }
            catch (IOException ex)
            {
              if (this.CommunicationError != null)
                this.CommunicationError(ErrorType.E_CONNECTION, CurrentAction.A_IDLE, ex.Message);
            }
          }
        }
        return array.Length == 0 ? (string[]) null : array;
      }
      if (this.comPorts != null && this.comPorts.Find((Predicate<TsiComPort>) (s => s.PortName == portName)) == null)
      {
        TsiComPort tsiComPort = new TsiComPort(portName, baudRate, parity, dataBits, stopBits);
        tsiComPort.idStr = portName;
        tsiComPort.DiscardNull = true;
        tsiComPort.NewLine = "\r\n";
        tsiComPort.ReadBufferSize = 1048576;
        tsiComPort.WriteBufferSize = 1024;
        tsiComPort.DataReceived += new SerialDataReceivedEventHandler(this.OnSerialDataReceived);
        tsiComPort.ErrorReceived += new SerialErrorReceivedEventHandler(this.OnSerialCommunicationErrorReceived);
        this.comPorts.Add(tsiComPort);
        Array.Resize<string>(ref array, array.Length + 1);
        array[array.Length - 1] = portName;
        return array;
      }
      Trace.WriteLine("Out of RescanDevices - SERIAL");
      return (string[]) null;
    }

    public void Disconnect(string port)
    {
      if (string.IsNullOrEmpty(port) || this.comPorts.Count <= 0)
        return;
      int index = this.comPorts.FindIndex((Predicate<TsiComPort>) (c => c.idStr == port));
      if (index < 0)
        return;
      lock (this.serialLock)
      {
        this.comPorts[index].Close();
        this.comPorts.RemoveAt(index);
      }
    }

    public void ClearAllDevices()
    {
      if (this.comPorts.Count <= 0)
        return;
      foreach (SerialPort comPort in this.comPorts)
      {
        try
        {
          comPort.DiscardInBuffer();
          comPort.DiscardOutBuffer();
          comPort.Close();
        }
        catch
        {
        }
      }
    }

    private void OnSerialDataReceived(object sender, SerialDataReceivedEventArgs args)
    {
      TsiComPort tsiComPort = (TsiComPort) sender;
      Trace.WriteLine("TSI_SerialCommunication: Data received from " + tsiComPort.idStr, "Info");
      if (this.TextReceived != null)
      {
        try
        {
          int bytesToRead = tsiComPort.BytesToRead;
          Thread.Sleep(50);
          while (bytesToRead < tsiComPort.BytesToRead)
          {
            bytesToRead = tsiComPort.BytesToRead;
            Thread.Sleep(50);
          }
          this.TextReceived(tsiComPort.idStr, tsiComPort.act, tsiComPort.ReadExisting());
        }
        catch (InvalidOperationException ex)
        {
          if (this.CommunicationError != null)
            this.CommunicationError(ErrorType.E_CONNECTION, CurrentAction.A_GET_DATA, "The port is not open.");
        }
      }
      tsiComPort.act = CurrentAction.A_IDLE;
    }

    private void OnSerialCommunicationErrorReceived(
      object sender,
      SerialErrorReceivedEventArgs args)
    {
      if (this.CommunicationError == null)
        return;
      this.CommunicationError(ErrorType.E_CONNECTION, CurrentAction.A_GET_DATA, args.EventType.ToString());
    }

    public void GetIDTags(string idCmd)
    {
      int count = this.comPorts.Count;
    }

    public void SendTextData(string idStr, CurrentAction act, string data)
    {
      TsiComPort tsiComPort = (TsiComPort) null;
      foreach (TsiComPort comPort in this.comPorts)
      {
        if (comPort.idStr == idStr)
        {
          tsiComPort = comPort;
          break;
        }
      }
      if (tsiComPort == null || string.IsNullOrEmpty(data))
        return;
      if (!tsiComPort.IsOpen)
        tsiComPort.Open();
      tsiComPort.act = act;
      for (int startIndex = 0; startIndex < data.Length; ++startIndex)
      {
        tsiComPort.Write(data.Substring(startIndex, 1));
        Thread.Sleep(25);
      }
    }

    public string[] ListIDs()
    {
      if (this.comPorts.Count <= 0)
        return (string[]) null;
      string[] strArray = new string[this.comPorts.Count];
      int num = 0;
      foreach (TsiComPort comPort in this.comPorts)
        strArray[num++] = comPort.idStr;
      return strArray;
    }

    public int Count => this.comPorts != null ? this.comPorts.Count : 0;

    public bool ChangeID(string oldId, string newId)
    {
      if (this.comPorts == null)
        return false;
      TsiComPort tsiComPort = this.comPorts.Find((Predicate<TsiComPort>) (c => c.idStr == oldId));
      if (tsiComPort == null)
        return false;
      tsiComPort.idStr = newId;
      return true;
    }

    public delegate void TextReceivedEventHandler(string idStr, CurrentAction act, string strRcv);

    public delegate void CommunicationErrorEventHandler(
      ErrorType errCode,
      CurrentAction act,
      string strErr);
  }
}
