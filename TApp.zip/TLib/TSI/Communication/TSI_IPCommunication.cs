﻿// Decompiled with JetBrains decompiler
// Type: TSI.Communication.TSI_IPCommunication
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using TSI.ModbusTCP;

#nullable disable
namespace TSI.Communication
{
  public class TSI_IPCommunication
  {
    public const int MAX_SAMPLES_TO_READ = 1000;
    public static string UnableToWriteToConnectionInterface = "Unable to write to connection interface.";
    private List<TsiIPClient> tcpClients = new List<TsiIPClient>();
    private List<TsiIPClient> clientRequests = new List<TsiIPClient>();

    public event TSI_IPCommunication.DataReceivedEventHandler DataReceived;

    public event TSI_IPCommunication.CommunicationErrorEventHandler CommunicationError;

    public List<TsiIPClient> ClientRequests => this.clientRequests;

    public TSI_IPCommunication(string addrGrp, int port, CommunicationType type)
    {
      Trace.WriteLine("TSI_IPCommunication.Constructor", "Info");
    }

    public List<TsiIPClient> FindNewDevices(string addrGrp)
    {
      List<TsiIPClient> newDevices = new List<TsiIPClient>();
      foreach (NetworkInterface networkInterface in NetworkInterface.GetAllNetworkInterfaces())
      {
        foreach (GatewayIPAddressInformation gatewayAddress in networkInterface.GetIPProperties().GatewayAddresses)
        {
          string s = gatewayAddress.Address.ToString();
          if (s.StartsWith(addrGrp))
          {
            if (this.tcpClients.Find((Predicate<TsiIPClient>) (cl => cl.IPAddress.ToString() == s)) == null)
            {
              try
              {
                int port = 3601;
                TcpClient tcpClient = new TcpClient(s, port);
                NetworkStream stream = tcpClient.GetStream();
                if (stream.CanWrite)
                {
                  byte[] bytes = Encoding.ASCII.GetBytes("RDTCPPORTINFO 502\r");
                  stream.Write(bytes, 0, bytes.Length);
                  byte[] numArray = new byte[tcpClient.ReceiveBufferSize];
                  stream.Read(numArray, 0, numArray.Length);
                  string str = Encoding.ASCII.GetString(numArray);
                  stream.Close();
                  tcpClient.Close();
                  if (str.Contains("MODBUS,OPC,2.0"))
                    newDevices.Add(new TsiIPClient(gatewayAddress.Address, 502, CommunicationType.CT_MODBUS));
                }
              }
              catch (Exception ex)
              {
                if (this.CommunicationError != null)
                  this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_COMMAND, ex.Message);
              }
            }
          }
        }
      }
      return newDevices;
    }

    public int AddClient(TsiIPClient newClient)
    {
      if (this.tcpClients.Find((Predicate<TsiIPClient>) (c => c.IPAddress.ToString() == newClient.IPAddress.ToString() || c.HostName == newClient.HostName)) != null)
        return -1;
      this.tcpClients.Add(newClient);
      return this.tcpClients.Count - 1;
    }

    public bool RemoveClient(IPAddress ipAddr)
    {
      TsiIPClient tsiIpClient = this.tcpClients.Find((Predicate<TsiIPClient>) (c => c.IPAddress == ipAddr));
      return tsiIpClient != null && this.tcpClients.Remove(tsiIpClient);
    }

    public bool SetHostName(IPAddress ipAddr, string hostName)
    {
      TsiIPClient tsiIpClient = this.tcpClients.Find((Predicate<TsiIPClient>) (c => c.IPAddress == ipAddr));
      if (tsiIpClient == null)
        return false;
      tsiIpClient.HostName = hostName;
      return true;
    }

    public byte[][] ReadLocationLabels(
      TcpClient tcpClient,
      TsiIPClient device,
      int numLocations,
      bool hasZones)
    {
      int num1 = 0;
      byte[] buffer = new byte[64];
      try
      {
        NetworkStream stream = tcpClient.GetStream();
        TSIModbusTCP tsiModbusTcp = new TSIModbusTCP();
        DataPacket dataPacket1 = new DataPacket(1);
        dataPacket1.Actions[0] = CurrentAction.A_WRITE_LOCATION_LABEL_INDEX;
        ushort length = !hasZones ? (ushort) 17 : (ushort) 35;
        DataPacket dataPacket2 = new DataPacket(1);
        dataPacket2.Actions[0] = CurrentAction.A_READ_LOCATION_LABEL;
        dataPacket2.Packets[0] = tsiModbusTcp.Read((byte) 1, tsiModbusTcp.BinaryAddress((ushort) 43001), length);
        byte[][] numArray1 = new byte[numLocations][];
        if (stream.CanWrite)
        {
          tcpClient.ReceiveTimeout = 1000;
          ushort num2 = 1;
          for (int index = 0; index < numArray1.Length; ++index)
          {
            byte[] numArray2 = new byte[tcpClient.ReceiveBufferSize];
            dataPacket1.Packets[0] = tsiModbusTcp.Write((byte) 1, tsiModbusTcp.BinaryAddress((ushort) 43001), num2);
            stream.Write(dataPacket1.Packets[0], 0, dataPacket1.Packets[0].Length);
            num1 = stream.Read(buffer, 0, buffer.Length);
            stream.Write(dataPacket2.Packets[0], 0, dataPacket2.Packets[0].Length);
            int num3 = stream.Read(numArray2, 0, numArray2.Length);
            if (this.DataReceived != null)
            {
              int num4 = this.DataReceived(device, dataPacket2.Actions[0], numArray2);
            }
            if (num3 > 0)
              numArray1[index] = numArray2;
            ++num2;
          }
          return numArray1;
        }
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_LOCATION_LABEL, TSI_IPCommunication.UnableToWriteToConnectionInterface);
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_LOCATION_LABEL, ex.Message);
        return (byte[][]) null;
      }
      return (byte[][]) null;
    }

    public byte[][] ReadRecipeLabels(TcpClient tcpClient, TsiIPClient device, int numRecipes)
    {
      int num1 = 0;
      byte[] buffer = new byte[64];
      try
      {
        NetworkStream stream = tcpClient.GetStream();
        TSIModbusTCP tsiModbusTcp = new TSIModbusTCP();
        DataPacket dataPacket1 = new DataPacket(1);
        dataPacket1.Actions[0] = CurrentAction.A_WRITE_RECIPE_LABEL_INDEX;
        ushort length = 17;
        DataPacket dataPacket2 = new DataPacket(1);
        dataPacket2.Actions[0] = CurrentAction.A_READ_RECIPE_LABEL;
        dataPacket2.Packets[0] = tsiModbusTcp.Read((byte) 1, tsiModbusTcp.BinaryAddress((ushort) 43018), length);
        byte[][] numArray1 = new byte[numRecipes][];
        if (stream.CanWrite)
        {
          tcpClient.ReceiveTimeout = 1000;
          ushort num2 = 1;
          for (int index = 0; index < numArray1.Length; ++index)
          {
            byte[] numArray2 = new byte[tcpClient.ReceiveBufferSize];
            dataPacket1.Packets[0] = tsiModbusTcp.Write((byte) 1, tsiModbusTcp.BinaryAddress((ushort) 43018), num2);
            stream.Write(dataPacket1.Packets[0], 0, dataPacket1.Packets[0].Length);
            num1 = stream.Read(buffer, 0, buffer.Length);
            stream.Write(dataPacket2.Packets[0], 0, dataPacket2.Packets[0].Length);
            int num3 = stream.Read(numArray2, 0, numArray2.Length);
            if (this.DataReceived != null)
            {
              int num4 = this.DataReceived(device, dataPacket2.Actions[0], numArray2);
            }
            if (num3 > 0)
              numArray1[index] = numArray2;
            ++num2;
          }
          return numArray1;
        }
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_RECIPE_LABEL, TSI_IPCommunication.UnableToWriteToConnectionInterface);
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_RECIPE_LABEL, ex.Message);
        return (byte[][]) null;
      }
      return (byte[][]) null;
    }

    public byte[][] ReadRecipes(TcpClient tcpClient, TsiIPClient device, int numRecipes)
    {
      int num1 = 0;
      byte[] buffer = new byte[64];
      try
      {
        NetworkStream stream = tcpClient.GetStream();
        TSIModbusTCP tsiModbusTcp = new TSIModbusTCP();
        DataPacket dataPacket1 = new DataPacket(1);
        ushort length = 99;
        dataPacket1.Packets[0] = tsiModbusTcp.Read((byte) 1, tsiModbusTcp.BinaryAddress((ushort) 41012), length);
        dataPacket1.Actions[0] = CurrentAction.A_READ_RECIPE;
        byte[][] numArray1 = new byte[numRecipes][];
        if (stream.CanWrite)
        {
          tcpClient.ReceiveTimeout = 1000;
          for (ushort index = 0; (int) index < numRecipes; ++index)
          {
            byte[] numArray2 = new byte[tcpClient.ReceiveBufferSize];
            DataPacket dataPacket2 = new DataPacket(1);
            dataPacket2.Packets[0] = tsiModbusTcp.Write((byte) 1, tsiModbusTcp.BinaryAddress((ushort) 41081), index);
            dataPacket2.Actions[0] = CurrentAction.A_WRITE_RECIPE_INDEX;
            stream.Write(dataPacket2.Packets[0], 0, dataPacket2.Packets[0].Length);
            num1 = stream.Read(buffer, 0, buffer.Length);
            stream.Write(dataPacket1.Packets[0], 0, dataPacket1.Packets[0].Length);
            int num2 = stream.Read(numArray2, 0, numArray2.Length);
            if (this.DataReceived != null)
            {
              int num3 = this.DataReceived(device, dataPacket1.Actions[0], numArray2);
            }
            if (num2 > 0)
              numArray1[(int) index] = numArray2;
          }
          return numArray1;
        }
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_RECIPE, TSI_IPCommunication.UnableToWriteToConnectionInterface);
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_RECIPE, ex.Message);
        return (byte[][]) null;
      }
      return (byte[][]) null;
    }

    public bool ReadRecipes(TsiIPClient device, int numRecipes)
    {
      bool flag = true;
      try
      {
        TcpClient tcpClient = new TcpClient(device.IPAddress.ToString(), device.Port);
        this.ReadRecipes(tcpClient, device, numRecipes);
        tcpClient.Close();
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_RECIPE, ex.Message);
        flag = false;
      }
      return flag;
    }

    public bool ReadSampleRecords(
      TcpClient tcpClient,
      TsiIPClient device,
      uint startingIndex,
      uint numRecords,
      bool hasDataIntegrity)
    {
      byte[] buffer = new byte[64];
      bool flag = true;
      if (numRecords <= 0U)
        return flag;
      try
      {
        NetworkStream stream = tcpClient.GetStream();
        DataPacket dataPacket1 = new DataPacket();
        TSIModbusTCP tsiModbusTcp = new TSIModbusTCP();
        if (numRecords > 1000U)
          dataPacket1 = tsiModbusTcp.DisableLocalControl((byte) 1);
        DataPacket dataPacket2 = new DataPacket(1);
        ushort length = (ushort) ((hasDataIntegrity ? 42123 : 42122) - 42005 + 1);
        dataPacket2.Packets[0] = tsiModbusTcp.Read((byte) 1, tsiModbusTcp.BinaryAddress((ushort) 42005), length);
        dataPacket2.Actions[0] = CurrentAction.A_READ_RECORD;
        tcpClient.ReceiveTimeout = 1000;
        uint index1 = startingIndex;
        if (tcpClient.Connected && stream.CanWrite)
        {
          for (uint index2 = 0; index2 < numRecords; ++index2)
          {
            DataPacket dataPacket3 = tsiModbusTcp.WriteSampleRecordIndex((byte) 1, index1);
            byte[] numArray = new byte[tcpClient.ReceiveBufferSize];
            stream.Write(dataPacket3.Packets[0], 0, dataPacket3.Packets[0].Length);
            stream.Read(buffer, 0, buffer.Length);
            stream.Write(dataPacket3.Packets[1], 0, dataPacket3.Packets[1].Length);
            stream.Read(buffer, 0, buffer.Length);
            stream.Write(dataPacket2.Packets[0], 0, dataPacket2.Packets[0].Length);
            stream.Read(numArray, 0, numArray.Length);
            if (this.DataReceived != null)
            {
              int num = this.DataReceived(device, dataPacket2.Actions[0], numArray);
            }
            if (dataPacket1.Packets != null && index2 % 1000U == 0U)
            {
              stream.Write(dataPacket1.Packets[0], 0, dataPacket1.Packets[0].Length);
              stream.Read(numArray, 0, numArray.Length);
            }
            ++index1;
          }
        }
        else if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_RECORD, TSI_IPCommunication.UnableToWriteToConnectionInterface);
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, CurrentAction.A_READ_RECORD, ex.Message);
        flag = false;
      }
      return flag;
    }

    public List<TsiIPClient> GetClientList() => this.tcpClients;

    public void RemoveAllClients() => this.tcpClients.Clear();

    public TsiIPClient GetTsiIPClient(string deviceName)
    {
      return this.tcpClients.Find((Predicate<TsiIPClient>) (c => c.HostName == deviceName));
    }

    public byte[] SendAndReceive(TsiIPClient ipClient, CurrentAction command, byte[] dataToSend)
    {
      if (ipClient == null)
        return (byte[]) null;
      byte[] buffer = (byte[]) null;
      try
      {
        TcpClient tcpClient = new TcpClient(ipClient.IPAddress.ToString(), ipClient.Port);
        NetworkStream stream = tcpClient.GetStream();
        if (tcpClient.Connected && stream.CanWrite)
        {
          tcpClient.ReceiveTimeout = 100;
          stream.Write(dataToSend, 0, dataToSend.Length);
          buffer = new byte[tcpClient.ReceiveBufferSize];
          stream.Read(buffer, 0, buffer.Length);
        }
        else if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, command, TSI_IPCommunication.UnableToWriteToConnectionInterface);
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, command, ex.Message);
      }
      return buffer;
    }

    public byte[] SendAndReceive(TcpClient tcpClient, CurrentAction command, byte[] dataToSend)
    {
      byte[] buffer = (byte[]) null;
      try
      {
        NetworkStream stream = tcpClient.GetStream();
        if (tcpClient.Connected && stream.CanWrite)
        {
          tcpClient.ReceiveTimeout = 2000;
          stream.Write(dataToSend, 0, dataToSend.Length);
          buffer = new byte[tcpClient.ReceiveBufferSize];
          stream.Read(buffer, 0, buffer.Length);
        }
        else if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, command, TSI_IPCommunication.UnableToWriteToConnectionInterface);
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, command, ex.Message);
      }
      return buffer;
    }

    public DataPacket SendAndReceive(TcpClient tcpClient, TsiIPClient device, DataPacket data)
    {
      if (data.Packets == null || data.Packets.Length <= 0)
        return new DataPacket?().Value;
      DataPacket dataPacket = new DataPacket(data.Packets.Length);
      try
      {
        NetworkStream stream = tcpClient.GetStream();
        if (tcpClient.Connected && stream.CanWrite)
        {
          for (int index = 0; index < data.Packets.Length; ++index)
          {
            stream.Write(data.Packets[index], 0, data.Packets[index].Length);
            byte[] numArray = new byte[tcpClient.ReceiveBufferSize];
            stream.ReadTimeout = 1000;
            int num1 = stream.Read(numArray, 0, numArray.Length);
            if (this.DataReceived != null)
            {
              int num2 = this.DataReceived(device, data.Actions[index], numArray);
            }
            if (num1 > 0)
            {
              dataPacket.Packets[index] = numArray;
              dataPacket.Actions[index] = data.Actions[index];
            }
          }
        }
        else if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, data.Actions[0], TSI_IPCommunication.UnableToWriteToConnectionInterface);
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, data.Actions[0], ex.Message);
      }
      return dataPacket;
    }

    public byte[][] SendByteData(string deviceName, DataPacket data)
    {
      if (this.tcpClients.Count == 0)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_SEND, data.Actions[0], "No IP clients available");
        return (byte[][]) null;
      }
      TsiIPClient device = this.tcpClients.Find((Predicate<TsiIPClient>) (c => c.HostName == deviceName));
      if (device != null)
        return this.SendByteData(device, data);
      if (this.CommunicationError != null)
        this.CommunicationError(ErrorType.E_NODEVICEFOUND, data.Actions[0], "Device: " + deviceName + " is not present");
      return (byte[][]) null;
    }

    public byte[][] SendByteData(TsiIPClient device, DataPacket data)
    {
      if (data.Packets == null || data.Packets.Length <= 0)
        return (byte[][]) null;
      byte[][] numArray1 = new byte[data.Packets.Length][];
      try
      {
        TcpClient tcpClient = new TcpClient(device.IPAddress.ToString(), device.Port);
        NetworkStream stream = tcpClient.GetStream();
        if (stream.CanWrite)
        {
          for (int index = 0; index < data.Packets.Length; ++index)
          {
            stream.Write(data.Packets[index], 0, data.Packets[index].Length);
            byte[] numArray2 = new byte[tcpClient.ReceiveBufferSize];
            stream.Read(numArray2, 0, numArray2.Length);
            if (this.DataReceived != null)
            {
              int num = this.DataReceived(device, data.Actions[index], numArray2);
            }
            numArray1[index] = numArray2;
          }
          stream.Close();
          tcpClient.Close();
        }
        else
        {
          if (this.CommunicationError != null)
            this.CommunicationError(ErrorType.E_ARGUMENT, data.Actions[0], TSI_IPCommunication.UnableToWriteToConnectionInterface);
          return (byte[][]) null;
        }
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, data.Actions[0], ex.Message);
        return (byte[][]) null;
      }
      return numArray1;
    }

    public bool Send(TcpClient client, DataPacket data)
    {
      if (data.Packets == null || data.Packets.Length <= 0)
        return false;
      DataPacket dataPacket = new DataPacket(data.Packets.Length);
      try
      {
        NetworkStream stream = client.GetStream();
        if (client.Connected && stream.CanWrite)
        {
          for (int index = 0; index < data.Packets.Length; ++index)
          {
            stream.Write(data.Packets[index], 0, data.Packets[index].Length);
            byte[] buffer = new byte[client.ReceiveBufferSize];
            stream.ReadTimeout = 1000;
            stream.Read(buffer, 0, buffer.Length);
          }
        }
        else
        {
          if (this.CommunicationError != null)
            this.CommunicationError(ErrorType.E_ARGUMENT, data.Actions[0], TSI_IPCommunication.UnableToWriteToConnectionInterface);
          return false;
        }
      }
      catch (Exception ex)
      {
        if (this.CommunicationError != null)
          this.CommunicationError(ErrorType.E_ARGUMENT, data.Actions[0], ex.Message);
        return false;
      }
      return true;
    }

    public delegate int DataReceivedEventHandler(
      TsiIPClient device,
      CurrentAction act,
      byte[] bytesRcv);

    public delegate void CommunicationErrorEventHandler(
      ErrorType errCode,
      CurrentAction act,
      string strErr);
  }
}
