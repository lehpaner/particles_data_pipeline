﻿// Decompiled with JetBrains decompiler
// Type: TSI.ReportSample
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using TrakProLiteClassLibrary;
using TSI.Data;
using TSI.Globals;

#nullable disable
namespace TSI
{
  public class ReportSample
  {
    private int sampleID;
    private string zoneName = string.Empty;
    private string sensitivity = string.Empty;
    private string timeStamp;
    private TimeSpan sampleTime;
    private string recipeSampleTime;
    private string location;
    private string deviceStatus;
    private string laserStatus;
    private string flowStatus;
    private ChannelCollection channels;
    private bool[] channelAlarms;
    private bool doesSampleComplete;
    public Decimal[] ParticleCounts;
    private int numNonViableChannels;
    private int numDeviceChannels;
    private Decimal volumeLitres;
    public UnitCode tempUnit;
    private string diUsername;
    private ushort diUserId;
    private string humidity;
    private string[] temp = new string[2];
    public TemperatureType tempType;
    private string velocity;

    public ReportSample(ModbusMap2Record sample)
    {
      this.sampleID = (int) sample.SampleID;
      this.zoneName = sample.Zone;
      this.timeStamp = sample.TimeStamp.ToString("dd'/'MM'/'yyyy HH:mm:ss");
      this.sampleTime = sample.SampleTime;
      this.recipeSampleTime = sample.RecipeSampleTime;
      this.deviceStatus = sample.DeviceStatusText;
      this.laserStatus = sample.LaserStatusText;
      this.flowStatus = TSIStrings.FlowStatusStrings[(int) sample.FlowStatus];
      this.location = sample.Location;
      this.sensitivity = sample.ViableDetectionSensitiviyString;
      this.channels = sample.Channels;
      this.channels.AddRange((IEnumerable<IChannel>) sample.ViableChannels);
      this.numDeviceChannels = sample.NumberOfChannels;
      this.numNonViableChannels = sample.NumberOfNonViableChannels;
      this.velocity = sample.Velocity;
      this.volumeLitres = sample.VolumeLitres;
      this.tempType = sample.tempType;
      this.diUsername = sample.DIUsername;
      this.diUserId = sample.DIUserId;
      this.ParticleCounts = new Decimal[this.channels.Count];
      for (int channel = 0; channel < this.channels.Count; ++channel)
        this.ParticleCounts[channel] = this.GetParticleCount(channel, sample.CountMode, sample.unitMode, sample.volumeType);
      this.channelAlarms = new bool[this.channels.Count];
      Array.Copy((Array) sample.chAlarm, (Array) this.channelAlarms, this.channels.Count);
      this.doesSampleComplete = this.recipeSampleTime == "" || this.recipeSampleTime == this.sampleTime.ToString();
      this.humidity = sample.HumidityUnits == UnitCode.NA ? "N/A" : sample.Humidity.ToString("F1");
      this.tempUnit = sample.tempUnit;
      if (this.tempUnit == UnitCode.F)
      {
        this.temp[0] = sample.temperature.ToString("F1");
        this.temp[1] = ((float) (((double) sample.temperature - 32.0) * 5.0 / 9.0)).ToString("F1");
      }
      else
      {
        this.temp[0] = ((float) (9.0 * (double) sample.temperature / 5.0 + 32.0)).ToString("F1");
        this.temp[1] = sample.temperature.ToString("F1");
      }
    }

    public ReportSample(Record_9303 sample)
    {
      this.sampleID = (int) sample.SampleID;
      this.zoneName = string.Empty;
      this.timeStamp = sample.TimeStamp.ToString("dd'/'MM'/'yyyy HH:mm:ss");
      this.sampleTime = sample.SampleTime;
      this.recipeSampleTime = sample.RecipeSampleTime;
      this.deviceStatus = string.Format("{0}", sample.DeviceStatus == (ushort) 0 ? (object) "OK" : (object) "Error");
      this.laserStatus = "OK";
      this.flowStatus = TSIStrings.FlowStatusStrings[(int) sample.FlowStatus];
      this.location = sample.Location;
      this.sensitivity = string.Empty;
      this.channels = sample.Channels;
      this.channels.AddRange((IEnumerable<IChannel>) sample.ViableChannels);
      this.numDeviceChannels = 3;
      this.numNonViableChannels = 3;
      this.velocity = string.Empty;
      this.volumeLitres = sample.VolumeLitres;
      this.tempType = TemperatureType.NA;
      this.diUsername = sample.DIUsername;
      this.diUserId = sample.DIUserId;
      this.HoldTime = sample.HoldTime;
      this.Cycles = 0U;
      this.DelayTime = new TimeSpan(0L);
      this.ParticleCounts = new Decimal[this.channels.Count];
      for (int channel = 0; channel < this.channels.Count; ++channel)
        this.ParticleCounts[channel] = this.GetParticleCount(channel, sample.CountMode, sample.UnitType, sample.VolumeUnits);
      if (this.recipeSampleTime == "" || this.recipeSampleTime == this.sampleTime.ToString())
        this.doesSampleComplete = true;
      else
        this.doesSampleComplete = false;
    }

    public int SampleID => this.sampleID;

    public string Zone => this.zoneName;

    public string Sensitivity => this.sensitivity;

    public string TimeStamp => this.timeStamp;

    public TimeSpan SampleTime => this.sampleTime;

    public string RecipeSampleTime => this.recipeSampleTime;

    public TimeSpan HoldTime { get; set; }

    public uint Cycles { get; set; }

    public TimeSpan DelayTime { get; set; }

    public string Location => this.location;

    public string DeviceStatus => this.deviceStatus;

    public string LaserStatus => this.laserStatus;

    public string FlowStatus => this.flowStatus;

    public ChannelCollection Channels => this.channels;

    public string DIUsername => this.diUsername;

    public ushort DIUserId => this.diUserId;

    public Decimal ChSize1 => this.channels[0].ParticleSizeMicrometres;

    public Decimal ChSize2 => this.channels[1].ParticleSizeMicrometres;

    public Decimal ChSize3 => this.channels[2].ParticleSizeMicrometres;

    public Decimal ChSize4 => this.channels[3].ParticleSizeMicrometres;

    public Decimal ChSize5 => this.channels[4].ParticleSizeMicrometres;

    public Decimal ChSize6 => this.channels[5].ParticleSizeMicrometres;

    public Decimal ChSize7 => this.channels[6].ParticleSizeMicrometres;

    public Decimal ChSize8 => this.channels[7].ParticleSizeMicrometres;

    public Decimal ChCount1 => this.ParticleCounts[0];

    public Decimal ChCount2 => this.ParticleCounts[1];

    public Decimal ChCount3 => this.ParticleCounts[2];

    public Decimal ChCount4 => this.ParticleCounts[3];

    public Decimal ChCount5 => this.ParticleCounts[4];

    public Decimal ChCount6 => this.ParticleCounts[5];

    public Decimal ChCount7 => this.ParticleCounts[6];

    public Decimal ChCount8 => this.ParticleCounts[7];

    public Decimal ChCount9 => this.ParticleCounts[8];

    public Decimal ChCount10 => this.ParticleCounts[9];

    public Decimal ChCount11 => this.ParticleCounts[10];

    public Decimal ChCount12 => this.ParticleCounts[11];

    public bool ChAlarm1 => this.channelAlarms[0];

    public bool ChAlarm2 => this.channelAlarms[1];

    public bool ChAlarm3 => this.channelAlarms[2];

    public bool ChAlarm4 => this.channelAlarms[3];

    public bool ChAlarm5 => this.channelAlarms[4];

    public bool ChAlarm6 => this.channelAlarms[5];

    public bool ChAlarm7 => this.channelAlarms[6];

    public bool ChAlarm8 => this.channelAlarms[7];

    public bool ChAlarm9 => this.channelAlarms[8];

    public bool ChAlarm10 => this.channelAlarms[9];

    public bool ChAlarm11 => this.channelAlarms[10];

    public bool ChAlarm12 => this.channelAlarms[11];

    public bool IsSampleComplete => this.doesSampleComplete;

    public string Humidity => this.humidity;

    public string Temp
    {
      get => this.tempUnit != UnitCode.NA ? this.temp[(int) (this.tempType - 1)] : "N/A";
    }

    public string Velocity => this.velocity;

    public Decimal Volume => this.volumeLitres;

    public Decimal GetParticleCount(
      int channel,
      RecordType countMode,
      UnitType unitMode,
      VolumeType volumeType)
    {
      Decimal particleCount = 0M;
      if (countMode == RecordType.Differential)
        particleCount = this.channels[channel].ParticleCount;
      else if (channel < this.numNonViableChannels)
      {
        for (int index = channel; index < this.numNonViableChannels; ++index)
          particleCount += this.channels[index].ParticleCount;
      }
      else
      {
        for (int index = channel; index < this.numDeviceChannels; ++index)
          particleCount += this.channels[index].ParticleCount;
      }
      if (unitMode != UnitType.Counts)
      {
        Decimal input = Sample.Normalize(particleCount, volumeType, this.volumeLitres);
        particleCount = channel >= this.numNonViableChannels ? Statistics.Round(input, 1) : Statistics.Round(input);
      }
      return particleCount;
    }
  }
}
