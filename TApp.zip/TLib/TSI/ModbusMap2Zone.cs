﻿// Decompiled with JetBrains decompiler
// Type: TSI.ModbusMap2Zone
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TSI
{
  public class ModbusMap2Zone : IZone
  {
    private int zoneId = -1;
    private string name = string.Empty;
    private ushort standard = 4;
    private ushort zoneClass;
    private ushort zoneState;
    private ushort airflow;
    private Decimal area;
    private ushort areaUnits;
    private int recipeId = -1;
    private string recipeName = string.Empty;
    private bool modified;
    private ModbusMap2Recipe recipe;

    public ModbusMap2Zone(int id) => this.zoneId = id;

    public ModbusMap2Zone(ModbusMap2Zone zoneCopy)
    {
      this.zoneId = zoneCopy.zoneId;
      this.name = zoneCopy.name;
      this.standard = zoneCopy.standard;
      this.zoneClass = zoneCopy.zoneClass;
      this.zoneState = zoneCopy.zoneState;
      this.airflow = zoneCopy.airflow;
      this.area = zoneCopy.area;
      this.areaUnits = zoneCopy.areaUnits;
      this.recipeId = zoneCopy.recipeId;
      this.recipeName = zoneCopy.recipeName;
      this.modified = zoneCopy.modified;
    }

    public int ZoneId
    {
      get => this.zoneId;
      set => this.zoneId = value;
    }

    public string Name
    {
      get => this.name;
      set => this.name = value;
    }

    public ushort Standard
    {
      get => this.standard;
      set => this.standard = value;
    }

    public ushort ZoneClass
    {
      get => this.zoneClass;
      set => this.zoneClass = value;
    }

    public ushort ZoneState
    {
      get => this.zoneState;
      set => this.zoneState = value;
    }

    public ushort Airflow
    {
      get => this.airflow;
      set => this.airflow = value;
    }

    public Decimal Area
    {
      get => this.area;
      set
      {
        if (value > 1000000M)
          this.area = 1000000M;
        else if (value < 1M)
          this.area = 1M;
        else
          this.area = value;
      }
    }

    public ushort AreaUnits
    {
      get => this.areaUnits;
      set => this.areaUnits = value;
    }

    public int RecipeId
    {
      get => this.recipeId;
      set => this.recipeId = value;
    }

    public string RecipeName
    {
      get => this.recipeName;
      set => this.recipeName = value;
    }

    public bool Modified
    {
      get => this.modified;
      set => this.modified = value;
    }

    public bool IsValid => !string.IsNullOrEmpty(this.name) && this.zoneId >= 0;

    public ModbusMap2Recipe Recipe
    {
      get => this.recipe;
      set
      {
        if (value != null)
          this.recipe = new ModbusMap2Recipe(value);
        else
          this.recipe = (ModbusMap2Recipe) null;
      }
    }
  }
}
