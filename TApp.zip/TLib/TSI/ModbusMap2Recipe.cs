﻿// Decompiled with JetBrains decompiler
// Type: TSI.ModbusMap2Recipe
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;
using System.Linq;
using TSI.Globals;

#nullable disable
namespace TSI
{
  [Serializable]
  public class ModbusMap2Recipe : IRecipe, IEquatable<ModbusMap2Recipe>
  {
    private VolumeType displayUnit = VolumeType.FeetCubed;
    private bool modified;
    public int rcpNum;
    private string name = string.Empty;
    private TimeSpan delayTime;
    private TimeSpan holdTime;
    private TimeSpan sampleTime;
    private uint cycles;
    public bool autoStart;
    public bool[] channelEnable = new bool[16];
    public bool[] alarmEnable = new bool[16];
    private ushort alarmThresholdMode;
    public uint[] alarmValues = new uint[16];
    public UnitCode unitTemp;
    public UnitCode unitHumidity;
    public UnitCode unitVelocity;
    public UnitCode unitFlow;
    public UnitCode unitCO2;
    public UnitCode unitCO;
    public UnitCode unitPressure;
    private ushort[] binVarSizes = new ushort[16];
    private SampleCountMode samplingMode;

    public ModbusMap2Recipe(int id)
    {
      this.rcpNum = id;
      this.name = string.Empty;
    }

    public ModbusMap2Recipe(int id, string name)
    {
      this.rcpNum = (int) (ushort) id;
      this.name = name;
    }

    public ModbusMap2Recipe(int id, ushort[] channels)
    {
      this.rcpNum = (int) (ushort) id;
      this.SetDefaults(channels, channels.Length);
    }

    public ModbusMap2Recipe(ModbusMap2Recipe recipeCopy)
    {
      this.rcpNum = recipeCopy.rcpNum;
      this.name = recipeCopy.name;
      this.delayTime = recipeCopy.delayTime;
      this.sampleTime = recipeCopy.sampleTime;
      this.samplingMode = recipeCopy.samplingMode;
      this.cycles = recipeCopy.cycles;
      this.autoStart = recipeCopy.autoStart;
      this.holdTime = recipeCopy.holdTime;
      this.displayUnit = recipeCopy.displayUnit;
      this.alarmThresholdMode = recipeCopy.alarmThresholdMode;
      this.modified = recipeCopy.Modified;
      Array.Copy((Array) recipeCopy.channelEnable, (Array) this.channelEnable, this.channelEnable.Length);
      Array.Copy((Array) recipeCopy.alarmValues, (Array) this.alarmValues, this.alarmValues.Length);
      Array.Copy((Array) recipeCopy.alarmEnable, (Array) this.alarmEnable, this.alarmEnable.Length);
      Array.Copy((Array) recipeCopy.binVarSizes, (Array) this.binVarSizes, this.binVarSizes.Length);
    }

    public static void Copy(ModbusMap2Recipe src, ModbusMap2Recipe dest)
    {
      dest.SampleTime = src.SampleTime;
      dest.Name = src.Name;
      dest.DelayTime = src.DelayTime;
      dest.SamplingMode = src.SamplingMode;
      dest.Cycles = src.Cycles;
      dest.autoStart = src.autoStart;
      dest.HoldTime = src.HoldTime;
      dest.VolumeDisplayUnit = src.VolumeDisplayUnit;
      dest.AlarmThresholdMode = src.AlarmThresholdMode;
      dest.Modified = src.Modified;
      Array.Copy((Array) src.ChannelEnable, (Array) dest.ChannelEnable, src.ChannelEnable.Length);
      Array.Copy((Array) src.AlarmThreshold, (Array) dest.AlarmThreshold, src.AlarmThreshold.Length);
      Array.Copy((Array) src.AlarmEnable, (Array) dest.AlarmEnable, src.AlarmEnable.Length);
      Array.Copy((Array) src.ChannelSizes, (Array) dest.ChannelSizes, src.ChannelSizes.Length);
    }

    public override int GetHashCode() => base.GetHashCode();

    public override bool Equals(object obj) => this.Equals(obj as ModbusMap2Recipe);

    public bool Equals(ModbusMap2Recipe r)
    {
      return this.Name == r.Name && this.delayTime == r.delayTime && this.sampleTime == r.sampleTime && this.samplingMode == r.samplingMode && (int) this.cycles == (int) r.cycles && this.autoStart == r.autoStart && this.holdTime == r.holdTime && (int) this.alarmThresholdMode == (int) r.alarmThresholdMode && ((IEnumerable<bool>) this.alarmEnable).SequenceEqual<bool>((IEnumerable<bool>) r.alarmEnable) && ((IEnumerable<bool>) this.channelEnable).SequenceEqual<bool>((IEnumerable<bool>) r.channelEnable) && ((IEnumerable<ushort>) this.binVarSizes).SequenceEqual<ushort>((IEnumerable<ushort>) r.binVarSizes) && ((IEnumerable<uint>) this.alarmValues).SequenceEqual<uint>((IEnumerable<uint>) r.alarmValues);
    }

    public VolumeType VolumeDisplayUnit
    {
      get => this.displayUnit;
      set => this.displayUnit = value;
    }

    public bool Modified
    {
      get => this.modified;
      set => this.modified = value;
    }

    public bool IsValid => !string.IsNullOrEmpty(this.Name) && this.RecipeId >= 0;

    public int RecipeId
    {
      get => this.rcpNum;
      set => this.rcpNum = value;
    }

    public string Name
    {
      get => this.name;
      set => this.name = value;
    }

    public TimeSpan DelayTime
    {
      get => this.delayTime;
      set => this.delayTime = value;
    }

    public TimeSpan HoldTime
    {
      get => this.holdTime;
      set => this.holdTime = value;
    }

    public TimeSpan SampleTime
    {
      get => this.sampleTime;
      set => this.sampleTime = value;
    }

    public uint Cycles
    {
      get => this.cycles;
      set => this.cycles = value;
    }

    public bool[] ChannelEnable => this.channelEnable;

    public bool[] AlarmEnable => this.alarmEnable;

    public ushort AlarmThresholdMode
    {
      get => this.alarmThresholdMode;
      set => this.alarmThresholdMode = value;
    }

    public uint[] AlarmThreshold => this.alarmValues;

    public ushort[] ChannelSizes
    {
      get => this.binVarSizes;
      set => this.binVarSizes = value;
    }

    public SampleCountMode SamplingMode
    {
      get => this.samplingMode;
      set => this.samplingMode = value;
    }

    public Decimal[] CutPointsSizesMicrometersSpecified
    {
      get
      {
        Decimal[] micrometersSpecified = new Decimal[this.ChannelSizes.Length];
        for (int index = 0; index < this.ChannelSizes.Length; ++index)
        {
          micrometersSpecified[index] = Convert.ToDecimal(this.ChannelSizes[index]);
          micrometersSpecified[index] /= 1000M;
        }
        return micrometersSpecified;
      }
    }

    public void SetDefaults(ushort[] channelSizes, int numChannels)
    {
      this.name = string.Empty;
      this.sampleTime = new TimeSpan(0, 0, 60);
      this.holdTime = new TimeSpan(0, 0, 0);
      this.delayTime = new TimeSpan(0, 0, 15);
      this.cycles = 1U;
      for (int index = 0; index < channelSizes.Length; ++index)
      {
        this.channelEnable[index] = index < numChannels;
        this.binVarSizes[index] = channelSizes[index];
        this.alarmEnable[index] = false;
        this.alarmValues[index] = 0U;
      }
      this.alarmThresholdMode = (ushort) 256;
      this.alarmThresholdMode |= (ushort) 1;
      this.samplingMode = SampleCountMode.AUTO;
    }
  }
}
