﻿// Decompiled with JetBrains decompiler
// Type: TSI.IZone
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;

#nullable disable
namespace TSI
{
  public interface IZone
  {
    int ZoneId { get; set; }

    string Name { get; set; }

    ushort Standard { get; set; }

    ushort ZoneClass { get; set; }

    ushort ZoneState { get; set; }

    ushort Airflow { get; set; }

    Decimal Area { get; set; }

    ushort AreaUnits { get; set; }

    int RecipeId { get; set; }

    bool IsValid { get; }

    bool Modified { get; set; }

    ModbusMap2Recipe Recipe { get; set; }
  }
}
