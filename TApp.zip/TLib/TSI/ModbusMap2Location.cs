﻿// Decompiled with JetBrains decompiler
// Type: TSI.ModbusMap2Location
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

#nullable disable
namespace TSI
{
  public class ModbusMap2Location : ILocation
  {
    private int locationId;
    private string name = string.Empty;
    private int zoneId = -1;
    private bool locked;
    private bool modified;

    public ModbusMap2Location(int locationId, string name, int zoneId)
    {
      this.locationId = locationId;
      this.name = name;
      this.zoneId = zoneId;
      this.locked = false;
    }

    public ModbusMap2Location(int locationId)
    {
      this.locationId = locationId;
      this.zoneId = -1;
      this.name = string.Empty;
      this.locked = false;
    }

    public ModbusMap2Location(ModbusMap2Location locationCopy)
    {
      this.locationId = locationCopy.locationId;
      this.zoneId = locationCopy.zoneId;
      this.name = locationCopy.name;
      this.locked = locationCopy.locked;
    }

    public int LocationId
    {
      get => this.locationId;
      set => this.locationId = value;
    }

    public string Name
    {
      get => this.name;
      set => this.name = value;
    }

    public int ZoneId
    {
      get => this.zoneId;
      set => this.zoneId = value;
    }

    public bool Locked
    {
      get => this.locked;
      set => this.locked = value;
    }

    public bool Modified
    {
      get => this.modified;
      set => this.modified = value;
    }

    public bool IsValid => !string.IsNullOrEmpty(this.name);
  }
}
