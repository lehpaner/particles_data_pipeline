﻿// Decompiled with JetBrains decompiler
// Type: TSI.RecipeList
// Assembly: TrakProLiteClassLibrary, Version=3.3.0.0, Culture=neutral, PublicKeyToken=null
// MVID: ED74AE80-C506-4C7C-ABB8-AC786EA04773
// Assembly location: C:\Users\Sasa\Desktop\ttsi\TrakProLiteClassLibrary.dll

using System;
using System.Collections.Generic;

#nullable disable
namespace TSI
{
  public class RecipeList : List<IRecipe>
  {
    public RecipeList(IEnumerable<IRecipe> collection)
      : base(collection)
    {
    }

    public RecipeList()
    {
    }

    public RecipeList(int count)
      : base(count)
    {
    }

    public int AddNew() => this.FindIndex((Predicate<IRecipe>) (r => !r.IsValid));

    public int AddNew(ModbusMap2Recipe recipe)
    {
      int index = this.FindIndex((Predicate<IRecipe>) (r => !r.IsValid));
      if (index != -1)
      {
        ModbusMap2Recipe modbusMap2Recipe = (ModbusMap2Recipe) this[index];
        modbusMap2Recipe.Modified = true;
        modbusMap2Recipe.AlarmThresholdMode = recipe.AlarmThresholdMode;
        modbusMap2Recipe.Cycles = recipe.Cycles;
        modbusMap2Recipe.DelayTime = recipe.DelayTime;
        modbusMap2Recipe.HoldTime = recipe.HoldTime;
        modbusMap2Recipe.Name = recipe.Name;
        modbusMap2Recipe.SampleTime = recipe.SampleTime;
        modbusMap2Recipe.SamplingMode = recipe.SamplingMode;
        modbusMap2Recipe.VolumeDisplayUnit = recipe.VolumeDisplayUnit;
        Array.Copy((Array) recipe.ChannelEnable, (Array) modbusMap2Recipe.ChannelEnable, modbusMap2Recipe.ChannelEnable.Length);
        Array.Copy((Array) recipe.AlarmThreshold, (Array) modbusMap2Recipe.AlarmThreshold, modbusMap2Recipe.AlarmThreshold.Length);
        Array.Copy((Array) recipe.ChannelSizes, (Array) modbusMap2Recipe.ChannelSizes, modbusMap2Recipe.ChannelSizes.Length);
        Array.Copy((Array) recipe.AlarmEnable, (Array) modbusMap2Recipe.AlarmEnable, modbusMap2Recipe.AlarmEnable.Length);
      }
      return index;
    }

    public int Find(string name) => this.FindIndex((Predicate<IRecipe>) (r => r.Name.Equals(name)));

    public void Remove(int recipeId)
    {
      this[recipeId].Name = string.Empty;
      this[recipeId].Modified = false;
    }

    public int GetId(string name)
    {
      int index = this.FindIndex((Predicate<IRecipe>) (r => r.Name.Equals(name)));
      return index != -1 && index < this.Count ? this[index].RecipeId : -1;
    }

    public List<IRecipe> GetModified()
    {
      return this.FindAll((Predicate<IRecipe>) (recipe => recipe.Modified));
    }

    public List<IRecipe> GetValid()
    {
      return this.FindAll((Predicate<IRecipe>) (recipe => recipe.IsValid));
    }
  }
}
