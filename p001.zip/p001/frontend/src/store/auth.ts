/**
 * Auth store (Zustand)
 *
 * Holds the user profile returned by GET /auth/me.
 * Schedules a proactive token refresh 2 minutes before expiry,
 * calling POST /auth/refresh and updating the stored profile.
 */

import { create } from 'zustand'

// ── Types ─────────────────────────────────────────────────────────────────────

export interface UserProfile {
  oid: string
  display_name: string | null
  given_name: string | null
  surname: string | null
  email: string | null
  job_title: string | null
  office_location: string | null
  mobile_phone: string | null
  preferred_language: string | null
  user_principal_name: string | null
  photo_data_uri: string | null
  access_token_expires_at: string   // ISO UTC
  claims: Record<string, string>
}

interface AuthState {
  user: UserProfile | null
  loading: boolean
  error: string | null

  // Actions
  setUser: (user: UserProfile | null) => void
  setLoading: (v: boolean) => void
  setError: (msg: string | null) => void
  logout: () => void
}

// ── Store ─────────────────────────────────────────────────────────────────────

export const useAuthStore = create<AuthState>((set) => ({
  user:    null,
  loading: false,
  error:   null,

  setUser:    (user)  => set({ user, error: null }),
  setLoading: (v)     => set({ loading: v }),
  setError:   (msg)   => set({ error: msg }),
  logout:     ()      => set({ user: null, error: null }),
}))

// ── Token refresh scheduler ───────────────────────────────────────────────────

let refreshTimer: ReturnType<typeof setTimeout> | null = null

/**
 * Schedule a proactive token refresh.
 * Called whenever the user profile is loaded or refreshed.
 * Clears any existing timer before scheduling a new one.
 */
export function scheduleTokenRefresh(expiresAtIso: string): void {
  if (refreshTimer !== null) {
    clearTimeout(refreshTimer)
    refreshTimer = null
  }

  const expiresAt  = new Date(expiresAtIso).getTime()
  const now        = Date.now()
  const msUntilExp = expiresAt - now
  // Refresh 2 minutes before expiry; if already < 30s, refresh immediately
  const delay      = Math.max(0, msUntilExp - 2 * 60 * 1000)

  refreshTimer = setTimeout(async () => {
    try {
      const resp = await fetch('/auth/refresh', {
        method:      'POST',
        credentials: 'include',
      })
      if (resp.ok) {
        const profile: UserProfile = await resp.json()
        useAuthStore.getState().setUser(profile)
        scheduleTokenRefresh(profile.access_token_expires_at)
      } else {
        // Refresh failed — treat as logged out
        useAuthStore.getState().logout()
      }
    } catch {
      useAuthStore.getState().logout()
    }
  }, delay)
}

/** Cancel any pending refresh timer (call on logout). */
export function cancelRefreshTimer(): void {
  if (refreshTimer !== null) {
    clearTimeout(refreshTimer)
    refreshTimer = null
  }
}
