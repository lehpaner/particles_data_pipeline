import { useState } from 'react'
import {
  User, Mail, Briefcase, MapPin, Phone, Globe,
  ShieldCheck, ChevronDown, ChevronUp, Clock,
} from 'lucide-react'
import { Avatar }          from '@/components/Avatar'
import { TokenCountdown }  from '@/components/TokenCountdown'
import { ClaimBadge }      from '@/components/ClaimBadge'
import { TopNav }          from '@/components/TopNav'
import { useAuthStore }    from '@/store/auth'

// ── Helpers ───────────────────────────────────────────────────────────────────

function ProfileRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType
  label: string
  value: string | null | undefined
}) {
  if (!value) return null
  return (
    <div className="flex items-start gap-3 py-2.5 border-b border-slate-50 last:border-0">
      <Icon className="h-4 w-4 text-slate-400 mt-0.5 flex-shrink-0" />
      <div className="min-w-0">
        <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
          {label}
        </p>
        <p className="text-sm text-slate-800 break-all">{value}</p>
      </div>
    </div>
  )
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function HomePage() {
  const { user } = useAuthStore()
  const [showAllClaims, setShowAllClaims] = useState(false)

  if (!user) return null

  // Decide which claims to show by default (exclude verbose ones)
  const claimEntries = Object.entries(user.claims)
  const priorityClaims = ['oid', 'tid', 'preferred_username', 'email', 'name', 'roles', 'scp']
  const visibleClaims  = showAllClaims
    ? claimEntries
    : claimEntries.filter(([k]) => priorityClaims.includes(k))

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <TopNav />

      <main className="flex-1 mx-auto w-full max-w-5xl px-4 sm:px-6 py-8 space-y-6">

        {/* ── Hero profile card ─────────────────────────────────────────────── */}
        <div className="card overflow-hidden">
          {/* Banner */}
          <div className="h-24 bg-gradient-to-r from-brand-600 to-brand-700" />

          <div className="px-6 pb-6">
            {/* Avatar overlapping banner */}
            <div className="-mt-12 mb-4 flex items-end justify-between">
              <Avatar
                photoDataUri={user.photo_data_uri}
                displayName={user.display_name}
                size="xl"
                className="ring-4 ring-white shadow-xl"
              />
              <TokenCountdown expiresAtIso={user.access_token_expires_at} />
            </div>

            <h2 className="text-2xl font-bold text-slate-900">
              {user.display_name ?? user.email}
            </h2>
            {user.job_title && (
              <p className="text-slate-500 text-sm mt-0.5">{user.job_title}</p>
            )}
            {user.email && user.display_name && (
              <p className="text-slate-400 text-xs mt-1">{user.email}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

          {/* ── Profile details ─────────────────────────────────────────────── */}
          <div className="card p-6">
            <h3 className="text-sm font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <User className="h-4 w-4 text-brand-500" />
              Profile
            </h3>

            <ProfileRow icon={Mail}     label="Email"           value={user.email} />
            <ProfileRow icon={User}     label="Given name"      value={user.given_name} />
            <ProfileRow icon={User}     label="Surname"         value={user.surname} />
            <ProfileRow icon={Briefcase} label="Job title"      value={user.job_title} />
            <ProfileRow icon={MapPin}   label="Office"          value={user.office_location} />
            <ProfileRow icon={Phone}    label="Mobile"          value={user.mobile_phone} />
            <ProfileRow icon={Globe}    label="Language"        value={user.preferred_language} />
            <ProfileRow
              icon={User}
              label="User principal name"
              value={user.user_principal_name}
            />
            <ProfileRow icon={ShieldCheck} label="Object ID (OID)" value={user.oid} />
          </div>

          {/* ── Token info ──────────────────────────────────────────────────── */}
          <div className="card p-6 flex flex-col gap-6">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <Clock className="h-4 w-4 text-brand-500" />
                Token status
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between py-2 border-b border-slate-50">
                  <span className="text-xs text-slate-500 font-medium">Expires at (UTC)</span>
                  <span className="text-xs font-mono text-slate-700">
                    {new Date(user.access_token_expires_at).toUTCString()}
                  </span>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-xs text-slate-500 font-medium">Time remaining</span>
                  <TokenCountdown expiresAtIso={user.access_token_expires_at} />
                </div>
              </div>
              <p className="text-[11px] text-slate-400 mt-4 leading-relaxed">
                The token is proactively refreshed 2 minutes before expiry.
                You can also trigger a manual refresh from the user menu.
              </p>
            </div>
          </div>
        </div>

        {/* ── Auth claims ──────────────────────────────────────────────────── */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-brand-500" />
              ID Token claims
              <span className="ml-1 text-[10px] font-normal text-slate-400 bg-slate-100
                               px-2 py-0.5 rounded-full">
                {claimEntries.length} total
              </span>
            </h3>
            <button
              onClick={() => setShowAllClaims(v => !v)}
              className="btn-ghost text-xs py-1 px-2"
            >
              {showAllClaims ? (
                <><ChevronUp className="h-3.5 w-3.5" /> Show less</>
              ) : (
                <><ChevronDown className="h-3.5 w-3.5" /> Show all</>
              )}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {visibleClaims.map(([key, val]) => (
              <ClaimBadge key={key} label={key} value={val} />
            ))}
          </div>

          {!showAllClaims && claimEntries.length > priorityClaims.length && (
            <p className="text-xs text-slate-400 mt-3">
              {claimEntries.length - visibleClaims.length} more claims hidden.{' '}
              <button
                className="underline hover:text-slate-600"
                onClick={() => setShowAllClaims(true)}
              >
                Show all
              </button>
            </p>
          )}
        </div>

      </main>
    </div>
  )
}
