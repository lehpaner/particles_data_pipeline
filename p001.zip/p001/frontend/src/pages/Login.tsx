import { useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { ShieldCheck, AlertCircle } from 'lucide-react'
import { useAuthStore } from '@/store/auth'

// Microsoft logo SVG (official brand mark, public domain for integration use)
function MsLogo() {
  return (
    <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="1"  y="1"  width="9" height="9" fill="#F25022"/>
      <rect x="11" y="1"  width="9" height="9" fill="#7FBA00"/>
      <rect x="1"  y="11" width="9" height="9" fill="#00A4EF"/>
      <rect x="11" y="11" width="9" height="9" fill="#FFB900"/>
    </svg>
  )
}

export default function LoginPage() {
  const { user } = useAuthStore()
  const navigate  = useNavigate()
  const [params]  = useSearchParams()

  const error            = params.get('error')
  const errorDescription = params.get('error_description')

  // Already authenticated → go home
  useEffect(() => {
    if (user) navigate('/', { replace: true })
  }, [user, navigate])

  const handleLogin = () => {
    window.location.href = '/auth/login'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-brand-50
                    flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Card */}
        <div className="card p-8 flex flex-col items-center gap-6">
          {/* Logo / brand */}
          <div className="flex flex-col items-center gap-3">
            <div className="h-16 w-16 rounded-2xl bg-brand-600 flex items-center justify-center
                            shadow-lg shadow-brand-200">
              <ShieldCheck className="h-9 w-9 text-white" strokeWidth={1.5} />
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">p001</h1>
              <p className="text-sm text-slate-500 mt-1">Sign in to continue</p>
            </div>
          </div>

          {/* Error banner */}
          {error && (
            <div className="w-full flex items-start gap-2.5 rounded-xl bg-red-50 border
                            border-red-100 px-4 py-3 text-sm text-red-700">
              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold">Authentication failed</p>
                <p className="text-xs mt-0.5 text-red-500">
                  {errorDescription ?? error}
                </p>
              </div>
            </div>
          )}

          {/* Sign-in button */}
          <button
            onClick={handleLogin}
            className="btn-primary w-full h-11 text-base"
          >
            <MsLogo />
            Sign in with Microsoft
          </button>

          <p className="text-xs text-center text-slate-400 leading-relaxed">
            Authentication is handled by Microsoft Entra ID.
            Your credentials are never stored by this application.
          </p>
        </div>

        <p className="text-center text-xs text-slate-400 mt-6">
          © {new Date().getFullYear()} p001
        </p>
      </div>
    </div>
  )
}
