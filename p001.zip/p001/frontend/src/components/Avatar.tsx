import { cn } from '@/lib/utils'

interface AvatarProps {
  photoDataUri: string | null
  displayName:  string | null
  size?:        'sm' | 'md' | 'lg' | 'xl'
  className?:   string
}

const sizes = {
  sm: 'h-8 w-8 text-xs',
  md: 'h-10 w-10 text-sm',
  lg: 'h-14 w-14 text-lg',
  xl: 'h-24 w-24 text-3xl',
}

function initials(name: string | null): string {
  if (!name) return '?'
  const parts = name.trim().split(/\s+/)
  if (parts.length === 1) return parts[0][0].toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

export function Avatar({ photoDataUri, displayName, size = 'md', className }: AvatarProps) {
  const ring = cn(
    'rounded-full flex items-center justify-center flex-shrink-0',
    'ring-2 ring-white shadow-sm',
    sizes[size],
    className,
  )

  if (photoDataUri) {
    return (
      <img
        src={photoDataUri}
        alt={displayName ?? 'User'}
        className={cn(ring, 'object-cover')}
      />
    )
  }

  return (
    <div className={cn(ring, 'bg-brand-600 text-white font-semibold select-none')}>
      {initials(displayName)}
    </div>
  )
}
