import { Navigate } from 'react-router-dom'
import { useAuthStore } from '@/store/auth'

interface Props {
  children: React.ReactNode
}

/**
 * Wraps a route that requires authentication.
 * While loading shows nothing (the AuthLoader in App handles the spinner).
 * If unauthenticated redirects to /login.
 */
export function ProtectedRoute({ children }: Props) {
  const { user, loading } = useAuthStore()

  if (loading) return null
  if (!user)   return <Navigate to="/login" replace />

  return <>{children}</>
}
