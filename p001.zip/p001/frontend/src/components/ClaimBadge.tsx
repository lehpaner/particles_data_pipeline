interface Props {
  label: string
  value: string
}

export function ClaimBadge({ label, value }: Props) {
  return (
    <div className="flex flex-col gap-0.5 bg-slate-50 border border-slate-100
                    rounded-lg px-3 py-2 text-xs break-all">
      <span className="font-semibold text-slate-500 uppercase tracking-wider text-[10px]">
        {label}
      </span>
      <span className="text-slate-800 font-mono">{value}</span>
    </div>
  )
}
