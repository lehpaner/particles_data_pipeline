import { useEffect, useState } from 'react'
import { Clock } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Props {
  expiresAtIso: string
}

function formatDuration(ms: number): string {
  if (ms <= 0) return 'Expired'
  const totalSec = Math.floor(ms / 1000)
  const h = Math.floor(totalSec / 3600)
  const m = Math.floor((totalSec % 3600) / 60)
  const s = totalSec % 60
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${s}s`
  return `${s}s`
}

/**
 * Displays a live countdown to the token expiry / next proactive refresh.
 * Updates every second.
 */
export function TokenCountdown({ expiresAtIso }: Props) {
  const [msLeft, setMsLeft] = useState(() => new Date(expiresAtIso).getTime() - Date.now())

  useEffect(() => {
    const iv = setInterval(() => {
      setMsLeft(new Date(expiresAtIso).getTime() - Date.now())
    }, 1000)
    return () => clearInterval(iv)
  }, [expiresAtIso])

  const isWarning = msLeft < 5 * 60 * 1000   // < 5 min
  const isDanger  = msLeft < 60 * 1000        // < 1 min

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 text-xs font-mono px-2.5 py-1 rounded-full',
        isDanger  ? 'bg-red-50   text-red-600'    :
        isWarning ? 'bg-amber-50 text-amber-700'  :
                    'bg-slate-100 text-slate-500',
      )}
    >
      <Clock className="h-3 w-3" />
      {formatDuration(msLeft)}
    </span>
  )
}
