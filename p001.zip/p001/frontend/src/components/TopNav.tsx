import { useState, useRef, useEffect } from 'react'
import { LogOut, ChevronDown, RefreshCw, User } from 'lucide-react'
import { Avatar } from '@/components/Avatar'
import { useAuth } from '@/hooks/useAuth'
import { cn } from '@/lib/utils'

export function TopNav() {
  const { user, logout, refetch } = useAuth()
  const [open, setOpen]           = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const menuRef = useRef<HTMLDivElement>(null)

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [])

  const handleRefresh = async () => {
    setRefreshing(true)
    setOpen(false)
    try {
      const resp = await fetch('/auth/refresh', {
        method: 'POST', credentials: 'include',
      })
      if (resp.ok) await refetch()
    } finally {
      setRefreshing(false)
    }
  }

  if (!user) return null

  return (
    <header className="sticky top-0 z-30 h-14 bg-white border-b border-slate-100 shadow-sm">
      <div className="mx-auto max-w-7xl h-full px-4 sm:px-6 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <span className="text-brand-600 font-bold text-xl tracking-tight select-none">
            p001
          </span>
        </div>

        {/* User menu */}
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setOpen(v => !v)}
            className={cn(
              'flex items-center gap-2.5 rounded-xl px-2.5 py-1.5',
              'hover:bg-slate-50 transition-colors duration-150',
              'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500',
            )}
          >
            <Avatar
              photoDataUri={user.photo_data_uri}
              displayName={user.display_name}
              size="sm"
            />
            <span className="hidden sm:block text-sm font-medium text-slate-700 max-w-[160px] truncate">
              {user.display_name ?? user.email}
            </span>
            <ChevronDown
              className={cn(
                'h-4 w-4 text-slate-400 transition-transform duration-200',
                open && 'rotate-180',
              )}
            />
          </button>

          {/* Dropdown */}
          {open && (
            <div className={cn(
              'absolute right-0 top-full mt-2 w-52',
              'bg-white rounded-xl shadow-lg border border-slate-100',
              'py-1 z-50',
            )}>
              <div className="px-3 py-2 border-b border-slate-100">
                <p className="text-xs font-semibold text-slate-900 truncate">
                  {user.display_name}
                </p>
                <p className="text-xs text-slate-500 truncate mt-0.5">{user.email}</p>
              </div>

              <button
                onClick={handleRefresh}
                disabled={refreshing}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700
                           hover:bg-slate-50 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={cn('h-4 w-4 text-slate-400', refreshing && 'animate-spin')} />
                {refreshing ? 'Refreshing…' : 'Refresh token'}
              </button>

              <button
                onClick={() => { setOpen(false); logout() }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-red-600
                           hover:bg-red-50 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
