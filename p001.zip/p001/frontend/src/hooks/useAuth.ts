/**
 * useAuth
 *
 * Fetches GET /auth/me on mount to rehydrate auth state from the
 * HttpOnly session cookie.  Provides login() and logout() helpers.
 */

import { useEffect, useCallback } from 'react'
import {
  useAuthStore,
  scheduleTokenRefresh,
  cancelRefreshTimer,
  type UserProfile,
} from '@/store/auth'

export function useAuth() {
  const { user, loading, error, setUser, setLoading, setError, logout: storeLogout } =
    useAuthStore()

  // ── Fetch current user from session cookie ────────────────────────────────
  const fetchMe = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const resp = await fetch('/auth/me', { credentials: 'include' })
      if (resp.ok) {
        const profile: UserProfile = await resp.json()
        setUser(profile)
        scheduleTokenRefresh(profile.access_token_expires_at)
      } else if (resp.status === 401) {
        storeLogout()
      } else {
        setError('Failed to load profile')
      }
    } catch {
      setError('Network error')
    } finally {
      setLoading(false)
    }
  }, [setLoading, setError, setUser, storeLogout])

  // Run once on mount
  useEffect(() => {
    if (!user) {
      fetchMe()
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // ── Login ─────────────────────────────────────────────────────────────────
  const login = useCallback(() => {
    // Redirect to backend which will redirect to Microsoft Entra
    window.location.href = '/auth/login'
  }, [])

  // ── Logout ────────────────────────────────────────────────────────────────
  const logout = useCallback(async () => {
    cancelRefreshTimer()
    try {
      // POST /auth/logout returns a redirect to MS logout; follow it
      const resp = await fetch('/auth/logout', {
        method:      'POST',
        credentials: 'include',
        redirect:    'manual',  // we'll handle the redirect ourselves
      })
      storeLogout()
      // Redirect to Microsoft logout URL (sent as Location header)
      const location = resp.headers.get('location')
      if (location) {
        window.location.href = location
      } else {
        window.location.href = '/login'
      }
    } catch {
      storeLogout()
      window.location.href = '/login'
    }
  }, [storeLogout])

  return {
    user,
    loading,
    error,
    isAuthenticated: !!user,
    login,
    logout,
    refetch: fetchMe,
  }
}
