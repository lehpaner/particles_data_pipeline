import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useEffect } from 'react'
import { Loader2 } from 'lucide-react'
import { useAuthStore, scheduleTokenRefresh, type UserProfile } from '@/store/auth'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import LoginPage from '@/pages/Login'
import HomePage  from '@/pages/Home'

/**
 * AuthLoader
 * Runs once on app mount: calls GET /auth/me to rehydrate auth state
 * from the HttpOnly session cookie. Shows a full-page spinner while loading.
 */
function AuthLoader({ children }: { children: React.ReactNode }) {
  const { user, loading, setUser, setLoading } = useAuthStore()

  useEffect(() => {
    if (user !== null) return   // already loaded

    setLoading(true)
    fetch('/auth/me', { credentials: 'include' })
      .then(async (resp) => {
        if (resp.ok) {
          const profile: UserProfile = await resp.json()
          setUser(profile)
          scheduleTokenRefresh(profile.access_token_expires_at)
        }
        // 401 → stay unauthenticated (no error)
      })
      .catch(() => { /* network error: stay unauthenticated */ })
      .finally(() => setLoading(false))
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-brand-500" />
          <p className="text-sm text-slate-500">Loading…</p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthLoader>
        <Routes>
          {/* Public */}
          <Route path="/login" element={<LoginPage />} />

          {/* Protected */}
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <HomePage />
              </ProtectedRoute>
            }
          />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthLoader>
    </BrowserRouter>
  )
}
