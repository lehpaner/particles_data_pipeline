# p001 — FastAPI + React + Microsoft Entra Auth

Full-stack application with Microsoft Entra ID (OAuth2/OIDC) authentication,
MS Graph profile + photo loading, proactive token refresh, and SQLite audit log.

## Architecture

```
p001/
├── backend/          FastAPI (Python)
│   ├── main.py       Routes: /auth/login  /auth/callback  /auth/me
│   │                         /auth/refresh  /auth/logout  /health
│   ├── auth_service.py   OAuth flow, token exchange, MS Graph calls
│   ├── database.py       SQLAlchemy async models + engine
│   ├── config.py         Pydantic-settings (reads .env)
│   └── requirements.txt
│
└── frontend/         React + Vite + Tailwind
    └── src/
        ├── pages/
        │   ├── Login.tsx   Sign-in page with Microsoft button
        │   └── Home.tsx    Profile, photo, claims, token countdown
        ├── components/
        │   ├── TopNav.tsx         Header with user avatar + dropdown
        │   ├── Avatar.tsx         Photo or initials fallback
        │   ├── TokenCountdown.tsx Live countdown to token expiry
        │   ├── ClaimBadge.tsx     Single claim pill
        │   └── ProtectedRoute.tsx Auth guard
        ├── hooks/useAuth.ts       Auth state + login/logout helpers
        └── store/auth.ts          Zustand store + refresh scheduler
```

## Database schema (SQLite)

| Table           | Purpose                                              |
|-----------------|------------------------------------------------------|
| `auth_sessions` | Active browser sessions (tokens, expiry, oid)        |
| `user_profiles` | MS Graph profile + photo (data-URI), raw JSON        |
| `auth_claims`   | id_token JWT claims as key/value pairs               |
| `auth_events`   | Audit log: login · logout · token_refresh · failures |

## Quick start

### 1. Azure app registration

In the Azure portal, register an app and configure:
- **Redirect URI** (Web): `http://localhost:8000/auth/callback`
- **Post-logout redirect URI**: `http://localhost:5173/login`
- **API permissions** (delegated): `openid`, `profile`, `email`, `offline_access`, `User.Read`
- Create a **client secret** and copy it

### 2. Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Edit .env — fill in AZURE_CLIENT_ID, AZURE_CLIENT_SECRET, AZURE_TENANT_ID, SECRET_KEY

python main.py
# → http://localhost:8000
# → http://localhost:8000/docs
```

### 3. Frontend

```bash
cd frontend
npm install
npm run dev
# → http://localhost:5173
```

Open http://localhost:5173 — you'll be redirected to /login.
Click "Sign in with Microsoft" to start the Entra flow.

## Auth flow

```
Browser                  Frontend          Backend           Microsoft Entra
   |                        |                 |                      |
   |── GET /  ─────────────>|                 |                      |
   |<─ redirect /login ─────|                 |                      |
   |── click "Sign in" ────>|                 |                      |
   |                        |── GET /auth/login ──────────────────>  |
   |<────────── redirect to Microsoft login ──────────────────────── |
   |── user authenticates ─────────────────────────────────────────> |
   |<─ redirect /auth/callback?code=…&state=… ─────────────────────  |
   |                        |── exchange code ─────────────────────> |
   |                        |<─ access_token + refresh_token + id_token
   |                        |── fetch /me + photo (MS Graph) ──────> |
   |                        |── save session, profile, claims to DB  |
   |                        |── set HttpOnly session cookie          |
   |<── redirect / ─────────|                 |                      |
   |── GET /auth/me ────────────────────────> |                      |
   |<─ profile JSON ──────────────────────────|                      |
   |                        |                 |                      |
   |                     [2 min before expiry, auto-refresh]         |
   |── POST /auth/refresh ──────────────────> |                      |
   |                        |── refresh_token grant ───────────────> |
   |                        |<─ new access_token                     |
   |                        |── update DB, re-fetch profile          |
   |<─ updated profile ──────────────────────|                      |
```

## Token refresh strategy

- The backend marks `access_token_expires_at` 30 seconds early (safety margin).
- On the frontend, `scheduleTokenRefresh()` sets a timer to call `POST /auth/refresh`
  **2 minutes before** the stored expiry.
- The backend's `ensure_fresh_token()` dependency also silently refreshes on any
  authenticated request if the token is already expired (defensive fallback).
- If refresh fails, the session is revoked in the DB and the user is redirected to login.

## Environment variables

| Variable              | Required | Description                                |
|-----------------------|----------|--------------------------------------------|
| `AZURE_CLIENT_ID`     | ✅       | App registration client ID                 |
| `AZURE_CLIENT_SECRET` | ✅       | App registration client secret             |
| `AZURE_TENANT_ID`     | ✅       | Azure tenant ID                            |
| `SECRET_KEY`          | ✅       | 32-byte hex string for signing             |
| `REDIRECT_URI`        | —        | OAuth callback (default: localhost:8000)   |
| `FRONTEND_ORIGIN`     | —        | CORS origin (default: localhost:5173)      |
| `DATABASE_URL`        | —        | SQLite path (default: ./p001.db)           |
| `PORT`                | —        | Server port (default: 8000)                |
| `DEBUG`               | —        | SQLAlchemy echo (default: false)           |
