"""
Auth service
============
Encapsulates every interaction with Microsoft Entra and MS Graph:

  build_auth_url()          → redirect user to Microsoft login
  exchange_code()           → POST /token with authorization code
  refresh_access_token()    → POST /token with refresh_token grant
  fetch_graph_profile()     → GET https://graph.microsoft.com/v1.0/me
  fetch_graph_photo()       → GET https://graph.microsoft.com/v1.0/me/photo/$value
  decode_id_token_claims()  → base64-decode JWT payload (claims)
  create_or_update_session()→ persist tokens + profile + claims to DB
  get_session_by_key()      → load AuthSession with eager relations
  revoke_session()          → mark session inactive, log logout event
  touch_session()           → update last_activity timestamp
"""

from __future__ import annotations

import base64
import hashlib
import json
import secrets
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

import httpx
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from config import settings
from database import AuthSession, AuthClaim, AuthEvent, UserProfile


# ── helpers ───────────────────────────────────────────────────────────────────

def _now() -> datetime:
    return datetime.now(timezone.utc)


def _b64pad(s: str) -> str:
    return s + "=" * (-len(s) % 4)


def decode_id_token_claims(id_token: str) -> dict[str, Any]:
    """
    Base64url-decode the JWT payload section.
    Does NOT verify the signature — token was received directly from
    Microsoft's HTTPS token endpoint, so TLS provides implicit authenticity.
    For a production system add RS256 JWKS verification here.
    """
    try:
        parts = id_token.split(".")
        if len(parts) != 3:
            return {}
        payload = json.loads(base64.urlsafe_b64decode(_b64pad(parts[1])))
        return payload
    except Exception:
        return {}


def _expires_at(expires_in: int) -> datetime:
    """Convert expires_in seconds to UTC datetime with 30-second safety margin."""
    return _now() + timedelta(seconds=max(0, expires_in - 30))


# ── OAuth / token exchange ────────────────────────────────────────────────────

def build_auth_url(state: str, nonce: str) -> str:
    """Build the Microsoft Entra authorization URL."""
    import urllib.parse
    params = {
        "client_id":     settings.azure_client_id,
        "response_type": "code",
        "redirect_uri":  settings.redirect_uri,
        "scope":         settings.scopes,
        "state":         state,
        "nonce":         nonce,
        "response_mode": "query",
        "prompt":        "select_account",
    }
    return settings.auth_url + "?" + urllib.parse.urlencode(params)


async def exchange_code(code: str) -> dict[str, Any]:
    """
    Exchange an authorization code for access + refresh + id tokens.
    Returns the full token response dict.
    Raises httpx.HTTPStatusError on failure.
    """
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(
            settings.token_url,
            data={
                "client_id":     settings.azure_client_id,
                "client_secret": settings.azure_client_secret,
                "grant_type":    "authorization_code",
                "code":          code,
                "redirect_uri":  settings.redirect_uri,
                "scope":         settings.scopes,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        resp.raise_for_status()
        return resp.json()


async def refresh_access_token(refresh_token: str) -> dict[str, Any]:
    """
    Use a refresh token to get a new access token (and optionally a new
    refresh token — Microsoft may rotate it).
    Returns the new token response dict.
    Raises httpx.HTTPStatusError on failure.
    """
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.post(
            settings.token_url,
            data={
                "client_id":     settings.azure_client_id,
                "client_secret": settings.azure_client_secret,
                "grant_type":    "refresh_token",
                "refresh_token": refresh_token,
                "scope":         settings.scopes,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        resp.raise_for_status()
        return resp.json()


# ── MS Graph ──────────────────────────────────────────────────────────────────

GRAPH_ME_URL    = "https://graph.microsoft.com/v1.0/me"
GRAPH_PHOTO_URL = "https://graph.microsoft.com/v1.0/me/photo/$value"

GRAPH_SELECT_FIELDS = ",".join([
    "id", "displayName", "givenName", "surname",
    "mail", "userPrincipalName", "jobTitle",
    "officeLocation", "mobilePhone", "preferredLanguage",
])


async def fetch_graph_profile(access_token: str) -> dict[str, Any]:
    """
    GET /me from MS Graph.
    Returns the profile dict (keys match Graph API field names).
    """
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(
            GRAPH_ME_URL,
            params={"$select": GRAPH_SELECT_FIELDS},
            headers={
                "Authorization": f"Bearer {access_token}",
                "Accept": "application/json",
            },
        )
        resp.raise_for_status()
        return resp.json()


async def fetch_graph_photo(access_token: str) -> Optional[str]:
    """
    GET /me/photo/$value from MS Graph.
    Returns a base64 data-URI string, or None if no photo is available.
    """
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(
            GRAPH_PHOTO_URL,
            headers={"Authorization": f"Bearer {access_token}"},
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        mime = resp.headers.get("Content-Type", "image/jpeg")
        b64  = base64.b64encode(resp.content).decode()
        return f"data:{mime};base64,{b64}"


# ── Session persistence ───────────────────────────────────────────────────────

async def create_or_update_session(
    db: AsyncSession,
    token_response: dict[str, Any],
    request_ip: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> AuthSession:
    """
    Given a token response dict (from exchange_code or refresh_access_token):
    1. Decode claims from the id_token.
    2. Upsert AuthSession (create if new oid, update tokens if existing).
    3. Fetch and store MS Graph profile + photo.
    4. Store all id_token claims as AuthClaim rows.
    5. Append an AuthEvent.
    Returns the persisted AuthSession with profile and claims loaded.
    """
    access_token  = token_response["access_token"]
    refresh_token = token_response.get("refresh_token")
    id_token      = token_response.get("id_token", "")
    expires_in    = int(token_response.get("expires_in", 3600))

    claims = decode_id_token_claims(id_token)
    oid    = claims.get("oid") or claims.get("sub", "unknown")
    tid    = claims.get("tid", "")

    # Generate a unique, unguessable session key
    session_key = secrets.token_urlsafe(48)

    # Build AuthSession
    auth_session = AuthSession(
        session_key             = session_key,
        oid                     = oid,
        tid                     = tid,
        access_token            = access_token,
        refresh_token           = refresh_token,
        id_token                = id_token,
        token_type              = token_response.get("token_type", "Bearer"),
        access_token_expires_at = _expires_at(expires_in),
        is_active               = True,
    )
    db.add(auth_session)
    await db.flush()  # get auth_session.id

    # Store all id_token claims
    for key, value in claims.items():
        db.add(AuthClaim(
            session_id  = auth_session.id,
            claim_key   = key,
            claim_value = json.dumps(value) if not isinstance(value, str) else value,
        ))

    # Fetch MS Graph profile
    try:
        profile_data = await fetch_graph_profile(access_token)
        photo_uri    = await fetch_graph_photo(access_token)
    except Exception:
        profile_data = {}
        photo_uri    = None

    db.add(UserProfile(
        session_id           = auth_session.id,
        oid                  = oid,
        display_name         = profile_data.get("displayName"),
        given_name           = profile_data.get("givenName"),
        surname              = profile_data.get("surname"),
        email                = profile_data.get("mail") or profile_data.get("userPrincipalName"),
        job_title            = profile_data.get("jobTitle"),
        office_location      = profile_data.get("officeLocation"),
        mobile_phone         = profile_data.get("mobilePhone"),
        preferred_language   = profile_data.get("preferredLanguage"),
        user_principal_name  = profile_data.get("userPrincipalName"),
        photo_data_uri       = photo_uri,
        photo_fetched_at     = _now() if photo_uri else None,
        raw_profile_json     = json.dumps(profile_data),
    ))

    # Audit event
    db.add(AuthEvent(
        session_id  = auth_session.id,
        oid         = oid,
        event_type  = "login",
        detail      = json.dumps({"claims_count": len(claims)}),
        ip_address  = request_ip,
        user_agent  = user_agent,
    ))

    await db.commit()
    await db.refresh(auth_session)
    return auth_session


async def update_session_tokens(
    db: AsyncSession,
    session: AuthSession,
    token_response: dict[str, Any],
    request_ip: Optional[str] = None,
) -> AuthSession:
    """
    Update an existing session's tokens after a successful refresh.
    Also re-fetches MS Graph profile + photo and updates stored claims.
    """
    access_token  = token_response["access_token"]
    refresh_token = token_response.get("refresh_token") or session.refresh_token
    id_token      = token_response.get("id_token", session.id_token or "")
    expires_in    = int(token_response.get("expires_in", 3600))
    claims        = decode_id_token_claims(id_token) if token_response.get("id_token") else {}

    session.access_token            = access_token
    session.refresh_token           = refresh_token
    session.id_token                = id_token
    session.access_token_expires_at = _expires_at(expires_in)
    session.updated_at              = _now()
    session.last_activity           = _now()

    # Refresh Graph profile + photo
    try:
        profile_data = await fetch_graph_profile(access_token)
        photo_uri    = await fetch_graph_photo(access_token)
        if session.profile:
            session.profile.display_name        = profile_data.get("displayName")
            session.profile.given_name          = profile_data.get("givenName")
            session.profile.surname             = profile_data.get("surname")
            session.profile.email               = (profile_data.get("mail")
                                                    or profile_data.get("userPrincipalName"))
            session.profile.job_title           = profile_data.get("jobTitle")
            session.profile.office_location     = profile_data.get("officeLocation")
            session.profile.mobile_phone        = profile_data.get("mobilePhone")
            session.profile.preferred_language  = profile_data.get("preferredLanguage")
            session.profile.user_principal_name = profile_data.get("userPrincipalName")
            session.profile.raw_profile_json    = json.dumps(profile_data)
            if photo_uri:
                session.profile.photo_data_uri  = photo_uri
                session.profile.photo_fetched_at = _now()
    except Exception:
        pass

    # Update claims if a new id_token was issued
    if claims:
        # Delete old claims for this session
        old_claims = await db.execute(
            select(AuthClaim).where(AuthClaim.session_id == session.id)
        )
        for c in old_claims.scalars():
            await db.delete(c)
        # Insert new claims
        for key, value in claims.items():
            db.add(AuthClaim(
                session_id  = session.id,
                claim_key   = key,
                claim_value = json.dumps(value) if not isinstance(value, str) else value,
            ))

    # Audit event
    db.add(AuthEvent(
        session_id = session.id,
        oid        = session.oid,
        event_type = "token_refresh",
        detail     = json.dumps({"new_expires_in": expires_in}),
        ip_address = request_ip,
    ))

    await db.commit()
    await db.refresh(session)
    return session


async def get_session_by_key(
    db: AsyncSession,
    session_key: str,
) -> Optional[AuthSession]:
    """Load an active AuthSession with profile and claims eagerly loaded."""
    result = await db.execute(
        select(AuthSession)
        .where(AuthSession.session_key == session_key, AuthSession.is_active == True)
        .options(
            selectinload(AuthSession.profile),
            selectinload(AuthSession.claims),
        )
    )
    return result.scalar_one_or_none()


async def revoke_session(
    db: AsyncSession,
    session: AuthSession,
    request_ip: Optional[str] = None,
) -> None:
    """Mark a session as inactive and log the logout event."""
    session.is_active = False
    session.updated_at = _now()
    db.add(AuthEvent(
        session_id = session.id,
        oid        = session.oid,
        event_type = "logout",
        ip_address = request_ip,
    ))
    await db.commit()


async def touch_session(db: AsyncSession, session: AuthSession) -> None:
    """Update last_activity without a full refresh."""
    await db.execute(
        update(AuthSession)
        .where(AuthSession.id == session.id)
        .values(last_activity=_now())
    )
    await db.commit()


async def ensure_fresh_token(
    db: AsyncSession,
    session: AuthSession,
    request_ip: Optional[str] = None,
) -> AuthSession:
    """
    If the access token is expired (or within 30s of expiry) and a refresh
    token exists, silently refresh and return the updated session.
    If refresh fails, marks session inactive and raises RuntimeError.
    """
    if session.access_token_expires_at > _now():
        return session  # still valid

    if not session.refresh_token:
        await revoke_session(db, session, request_ip)
        raise RuntimeError("Access token expired and no refresh token available")

    try:
        token_response = await refresh_access_token(session.refresh_token)
        session = await update_session_tokens(db, session, token_response, request_ip)
        return session
    except httpx.HTTPStatusError as exc:
        # Log failure
        db.add(AuthEvent(
            session_id = session.id,
            oid        = session.oid,
            event_type = "token_refresh_failed",
            detail     = json.dumps({"status": exc.response.status_code,
                                     "body":   exc.response.text[:500]}),
            ip_address = request_ip,
        ))
        await db.commit()
        await revoke_session(db, session, request_ip)
        raise RuntimeError(f"Token refresh failed: {exc.response.status_code}") from exc
