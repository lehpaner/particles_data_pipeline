"""
Application configuration — loaded from environment variables or .env file.

Required environment variables
───────────────────────────────
AZURE_CLIENT_ID       Azure app registration client ID
AZURE_CLIENT_SECRET   Azure app registration client secret
AZURE_TENANT_ID       Azure tenant ID
SECRET_KEY            Random 32-byte hex string for session signing

Optional
────────
DATABASE_URL          SQLite path  (default: sqlite+aiosqlite:///./p001.db)
FRONTEND_ORIGIN       CORS origin  (default: http://localhost:5173)
PORT                  Uvicorn port (default: 8000)
"""

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
import secrets


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Azure / Entra ──────────────────────────────────────────────────────
    azure_client_id: str = Field(..., description="App registration client ID")
    azure_client_secret: str = Field(..., description="App registration client secret")
    azure_tenant_id: str = Field(..., description="Tenant ID")

    # Derived Azure endpoints
    @property
    def authority(self) -> str:
        return f"https://login.microsoftonline.com/{self.azure_tenant_id}"

    @property
    def auth_url(self) -> str:
        return f"{self.authority}/oauth2/v2.0/authorize"

    @property
    def token_url(self) -> str:
        return f"{self.authority}/oauth2/v2.0/token"

    @property
    def jwks_uri(self) -> str:
        return f"{self.authority}/discovery/v2.0/keys"

    @property
    def logout_url(self) -> str:
        return f"{self.authority}/oauth2/v2.0/logout"

    # ── Redirect / origins ─────────────────────────────────────────────────
    redirect_uri: str = "http://localhost:8000/auth/callback"
    frontend_origin: str = "http://localhost:5173"
    post_logout_redirect: str = "http://localhost:5173/login"

    # OAuth scopes  (openid + profile + email + MS Graph delegated)
    scopes: str = "openid profile email offline_access User.Read"

    # ── Security ───────────────────────────────────────────────────────────
    secret_key: str = Field(default_factory=lambda: secrets.token_hex(32))

    # ── Database ───────────────────────────────────────────────────────────
    database_url: str = "sqlite+aiosqlite:///./p001.db"

    # ── Server ─────────────────────────────────────────────────────────────
    port: int = 8000
    debug: bool = False


settings = Settings()  # type: ignore[call-arg]  — populated from env/.env
