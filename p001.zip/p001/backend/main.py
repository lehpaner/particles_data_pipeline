"""
p001 FastAPI Backend
====================
Routes
──────
GET  /auth/login             → redirect to Microsoft Entra login page
GET  /auth/callback          → OAuth callback; sets session cookie
POST /auth/refresh           → force-refresh access token (called by frontend)
POST /auth/logout            → revoke session, redirect to MS logout
GET  /auth/me                → return current user profile JSON
GET  /health                 → liveness check
"""

from __future__ import annotations

import json
import secrets
from datetime import timedelta
from typing import Optional

from fastapi import (
    Cookie, Depends, FastAPI, HTTPException, Query, Request, Response,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from database import get_db, init_db, AuthSession
from auth_service import (
    build_auth_url,
    exchange_code,
    get_session_by_key,
    revoke_session,
    touch_session,
    ensure_fresh_token,
    create_or_update_session,
)

# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="p001 API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin],
    allow_credentials=True,   # required for cookies
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup() -> None:
    await init_db()


# ── Cookie config ─────────────────────────────────────────────────────────────

SESSION_COOKIE = "p001_session"
COOKIE_MAX_AGE = 60 * 60 * 8   # 8 hours


def _set_session_cookie(response: Response, session_key: str) -> None:
    response.set_cookie(
        key      = SESSION_COOKIE,
        value    = session_key,
        max_age  = COOKIE_MAX_AGE,
        httponly = True,
        samesite = "lax",
        secure   = False,   # set True behind HTTPS in production
    )


def _clear_session_cookie(response: Response) -> None:
    response.delete_cookie(SESSION_COOKIE, httponly=True, samesite="lax")


# ── Auth dependency ───────────────────────────────────────────────────────────

async def get_current_session(
    request: Request,
    db: AsyncSession = Depends(get_db),
    session_key: Optional[str] = Cookie(default=None, alias=SESSION_COOKIE),
) -> AuthSession:
    """
    FastAPI dependency.
    1. Reads session cookie.
    2. Loads AuthSession from DB.
    3. Auto-refreshes access token if expired.
    4. Touches last_activity.
    Raises 401 if no valid session.
    """
    if not session_key:
        raise HTTPException(401, detail="Not authenticated")

    session = await get_session_by_key(db, session_key)
    if not session:
        raise HTTPException(401, detail="Session not found or expired")

    ip = request.client.host if request.client else None

    try:
        session = await ensure_fresh_token(db, session, ip)
    except RuntimeError as exc:
        raise HTTPException(401, detail=str(exc))

    await touch_session(db, session)
    return session


# ── Helpers ───────────────────────────────────────────────────────────────────

def _profile_response(session: AuthSession) -> dict:
    """Build the user profile dict sent to the frontend."""
    p = session.profile
    claims = {c.claim_key: c.claim_value for c in session.claims}
    return {
        "oid":                  session.oid,
        "display_name":         p.display_name if p else None,
        "given_name":           p.given_name if p else None,
        "surname":              p.surname if p else None,
        "email":                p.email if p else None,
        "job_title":            p.job_title if p else None,
        "office_location":      p.office_location if p else None,
        "mobile_phone":         p.mobile_phone if p else None,
        "preferred_language":   p.preferred_language if p else None,
        "user_principal_name":  p.user_principal_name if p else None,
        "photo_data_uri":       p.photo_data_uri if p else None,
        "access_token_expires_at": session.access_token_expires_at.isoformat(),
        "claims":               claims,
    }


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}


@app.get("/auth/login")
async def auth_login(request: Request, response: Response) -> RedirectResponse:
    """
    Generate state + nonce, store them in short-lived cookies,
    redirect to Microsoft Entra.
    """
    state = secrets.token_urlsafe(32)
    nonce = secrets.token_urlsafe(32)
    url   = build_auth_url(state, nonce)

    resp = RedirectResponse(url=url, status_code=302)
    # CSRF protection cookies (short-lived)
    resp.set_cookie("oauth_state", state, max_age=600, httponly=True, samesite="lax")
    resp.set_cookie("oauth_nonce", nonce, max_age=600, httponly=True, samesite="lax")
    return resp


@app.get("/auth/callback")
async def auth_callback(
    request: Request,
    code:  Optional[str] = Query(None),
    state: Optional[str] = Query(None),
    error: Optional[str] = Query(None),
    error_description: Optional[str] = Query(None),
    db:    AsyncSession = Depends(get_db),
    stored_state: Optional[str] = Cookie(default=None, alias="oauth_state"),
) -> Response:
    """
    Microsoft redirects here after authentication.
    1. Validate state (CSRF).
    2. Exchange code for tokens.
    3. Persist session to DB.
    4. Set session cookie and redirect to frontend home.
    """
    # ── Error from Microsoft ──────────────────────────────────────────────
    if error:
        return RedirectResponse(
            url=f"{settings.frontend_origin}/login?error={error}"
                f"&error_description={error_description or ''}",
            status_code=302,
        )

    # ── CSRF state check ──────────────────────────────────────────────────
    if not stored_state or stored_state != state:
        return RedirectResponse(
            url=f"{settings.frontend_origin}/login?error=state_mismatch",
            status_code=302,
        )

    if not code:
        return RedirectResponse(
            url=f"{settings.frontend_origin}/login?error=no_code",
            status_code=302,
        )

    # ── Token exchange ────────────────────────────────────────────────────
    try:
        token_response = await exchange_code(code)
    except Exception as exc:
        return RedirectResponse(
            url=f"{settings.frontend_origin}/login?error=token_exchange_failed",
            status_code=302,
        )

    # ── Persist ───────────────────────────────────────────────────────────
    ip         = request.client.host if request.client else None
    user_agent = request.headers.get("user-agent")
    session    = await create_or_update_session(db, token_response, ip, user_agent)

    # ── Set cookie and redirect to home ───────────────────────────────────
    resp = RedirectResponse(url=f"{settings.frontend_origin}/", status_code=302)
    _set_session_cookie(resp, session.session_key)
    # Clear CSRF cookies
    resp.delete_cookie("oauth_state")
    resp.delete_cookie("oauth_nonce")
    return resp


@app.get("/auth/me")
async def auth_me(
    response: Response,
    session: AuthSession = Depends(get_current_session),
) -> dict:
    """Return the current user's profile. Rotates cookie on each call."""
    _set_session_cookie(response, session.session_key)
    return _profile_response(session)


@app.post("/auth/refresh")
async def auth_refresh(
    request: Request,
    response: Response,
    db: AsyncSession = Depends(get_db),
    session_key: Optional[str] = Cookie(default=None, alias=SESSION_COOKIE),
) -> dict:
    """
    Explicitly refresh the access token.
    Called by the frontend before the token expires.
    Returns updated profile with new expiry timestamp.
    """
    if not session_key:
        raise HTTPException(401, detail="Not authenticated")

    session = await get_session_by_key(db, session_key)
    if not session:
        raise HTTPException(401, detail="Session not found")

    if not session.refresh_token:
        raise HTTPException(400, detail="No refresh token available")

    ip = request.client.host if request.client else None

    try:
        from auth_service import refresh_access_token, update_session_tokens
        token_response = await refresh_access_token(session.refresh_token)
        session = await update_session_tokens(db, session, token_response, ip)
    except Exception as exc:
        raise HTTPException(401, detail=f"Token refresh failed: {exc}")

    _set_session_cookie(response, session.session_key)
    return _profile_response(session)


@app.post("/auth/logout")
async def auth_logout(
    request: Request,
    response: Response,
    db: AsyncSession = Depends(get_db),
    session: AuthSession = Depends(get_current_session),
) -> RedirectResponse:
    """
    Revoke the session in DB, clear cookie, redirect to Microsoft logout.
    """
    ip = request.client.host if request.client else None
    await revoke_session(db, session, ip)

    ms_logout = (
        f"{settings.logout_url}"
        f"?client_id={settings.azure_client_id}"
        f"&post_logout_redirect_uri={settings.post_logout_redirect}"
    )
    resp = RedirectResponse(url=ms_logout, status_code=302)
    _clear_session_cookie(resp)
    return resp


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=settings.port, reload=True)
