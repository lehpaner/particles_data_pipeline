"""
SQLite database via SQLAlchemy async + aiosqlite.

Tables
──────
auth_sessions   One row per active browser session (holds encrypted tokens).
auth_events     Append-only audit log of every auth/token event.
user_profiles   Cached MS Graph profile data (updated on each login / refresh).
auth_claims     Individual claims from the id_token, keyed per session.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    String, Integer, Boolean, Text, DateTime, ForeignKey, Index,
    event,
)
from sqlalchemy.ext.asyncio import (
    AsyncSession, async_sessionmaker, create_async_engine,
)
from sqlalchemy.orm import (
    DeclarativeBase, Mapped, mapped_column, relationship,
)

from config import settings


# ── Engine ────────────────────────────────────────────────────────────────────

engine = create_async_engine(
    settings.database_url,
    echo=settings.debug,
    connect_args={"check_same_thread": False},
)

# Enable WAL mode and foreign-keys for every new connection
@event.listens_for(engine.sync_engine, "connect")
def _set_sqlite_pragmas(dbapi_conn, _):
    cur = dbapi_conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL")
    cur.execute("PRAGMA foreign_keys=ON")
    cur.close()

AsyncSessionLocal = async_sessionmaker(
    engine, expire_on_commit=False, class_=AsyncSession
)


# ── Base ──────────────────────────────────────────────────────────────────────

class Base(DeclarativeBase):
    pass


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ── Models ────────────────────────────────────────────────────────────────────

class AuthSession(Base):
    """
    One row per browser session.
    access_token and refresh_token are stored here (in production, encrypt them
    at rest using a KMS key; for this reference implementation they are stored
    as-is).
    """
    __tablename__ = "auth_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_key: Mapped[str] = mapped_column(String(128), unique=True, index=True,
                                             nullable=False)
    oid: Mapped[str] = mapped_column(String(64), nullable=False, index=True,
                                     comment="Entra object ID (stable per user+tenant)")
    tid: Mapped[str] = mapped_column(String(64), nullable=False,
                                     comment="Tenant ID")

    # Tokens
    access_token: Mapped[str] = mapped_column(Text, nullable=False)
    refresh_token: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    id_token: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    token_type: Mapped[str] = mapped_column(String(32), default="Bearer")

    # Expiry (UTC)
    access_token_expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                               nullable=False)
    # State
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                  default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                  default=_now, onupdate=_now)
    last_activity: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                     default=_now)

    # Relations
    profile: Mapped[Optional["UserProfile"]] = relationship(
        "UserProfile", back_populates="session", uselist=False,
        cascade="all, delete-orphan",
    )
    claims: Mapped[list["AuthClaim"]] = relationship(
        "AuthClaim", back_populates="session",
        cascade="all, delete-orphan",
    )
    events: Mapped[list["AuthEvent"]] = relationship(
        "AuthEvent", back_populates="session",
    )

    __table_args__ = (
        Index("ix_auth_sessions_oid_active", "oid", "is_active"),
    )


class UserProfile(Base):
    """
    MS Graph /me profile + photo metadata.
    Updated on every successful login and token refresh.
    """
    __tablename__ = "user_profiles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("auth_sessions.id", ondelete="CASCADE"),
        unique=True, nullable=False,
    )

    # Core identity
    oid: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    display_name: Mapped[Optional[str]] = mapped_column(String(256))
    given_name: Mapped[Optional[str]] = mapped_column(String(128))
    surname: Mapped[Optional[str]] = mapped_column(String(128))
    email: Mapped[Optional[str]] = mapped_column(String(256))
    job_title: Mapped[Optional[str]] = mapped_column(String(256))
    office_location: Mapped[Optional[str]] = mapped_column(String(256))
    mobile_phone: Mapped[Optional[str]] = mapped_column(String(64))
    preferred_language: Mapped[Optional[str]] = mapped_column(String(16))
    user_principal_name: Mapped[Optional[str]] = mapped_column(String(256))

    # Photo: stored as data-URI (base64) — for production use blob storage
    photo_data_uri: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    photo_fetched_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # Raw MS Graph /me response (JSON)
    raw_profile_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                  default=_now, onupdate=_now)

    session: Mapped["AuthSession"] = relationship("AuthSession", back_populates="profile")


class AuthClaim(Base):
    """
    Individual claims from the id_token JWT payload.
    Stored as key/value pairs so new claims don't require schema changes.
    """
    __tablename__ = "auth_claims"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("auth_sessions.id", ondelete="CASCADE"),
        nullable=False,
    )
    claim_key: Mapped[str] = mapped_column(String(128), nullable=False)
    claim_value: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                   default=_now)

    session: Mapped["AuthSession"] = relationship("AuthSession", back_populates="claims")

    __table_args__ = (
        Index("ix_auth_claims_session_key", "session_id", "claim_key"),
    )


class AuthEvent(Base):
    """
    Append-only audit log: login, logout, token_refresh, token_refresh_failed, etc.
    """
    __tablename__ = "auth_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("auth_sessions.id", ondelete="SET NULL"),
        nullable=True,
    )
    oid: Mapped[Optional[str]] = mapped_column(String(64), nullable=True, index=True)
    event_type: Mapped[str] = mapped_column(
        String(64), nullable=False,
        comment="login | logout | token_refresh | token_refresh_failed | profile_update",
    )
    detail: Mapped[Optional[str]] = mapped_column(Text, nullable=True,
                                                   comment="JSON detail blob")
    ip_address: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True),
                                                   default=_now, index=True)

    session: Mapped[Optional["AuthSession"]] = relationship(
        "AuthSession", back_populates="events"
    )


# ── DB init ───────────────────────────────────────────────────────────────────

async def init_db() -> None:
    """Create all tables if they don't exist (dev-friendly; use Alembic in prod)."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_db() -> AsyncSession:  # type: ignore[misc]
    """FastAPI dependency that yields an async session."""
    async with AsyncSessionLocal() as session:
        yield session
