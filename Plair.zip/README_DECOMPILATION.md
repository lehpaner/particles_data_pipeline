# PlairGrid 1.6.0 — decompiled source

Recovered from `PlairGrid1.6.0.exe`, a PyInstaller-frozen Flask app built with
Python 3.8 (PyInstaller "2.1+" bootloader). This folder is the app's own code;
the many bundled third-party packages (Flask, Werkzeug, requests, zeroconf,
Jinja2, etc.) are not included since they're stock library code, not
PlairGrid's own — reinstall them with `pip install -r requirements.txt`.

## What the app does

- `main.py` — entry point. Creates the Flask app, serves the pre-built
  Angular SPA (the `dist/` folder next to the exe) for any non-API route,
  and exposes `/api/shutdown` to terminate the process.
- `app.py` — Flask app factory (`create_app`), registers CORS and the two
  blueprints below.
- `endpoints/local.py` — `GET /api/machine`: lists "Rapid-C+" machines
  discovered on the local network via mDNS.
- `endpoints/remote.py` — `GET|POST /api/machine/<machine_id>/<subpath>`:
  proxies requests through to a discovered machine's own HTTP API
  (`/api/v2/...`), forwarding an `Authorization` query param as a header.
- `services/discover.py` — `Discover` class wrapping `zeroconf` to browse
  the `_plair._tcp.local.` service type and keep a live table of machines
  (serial → ip/port) as they appear/update/disappear on the network.

So: PlairGrid is a small local web server (default `localhost:5104`) that
serves a bundled Angular UI and brokers that UI's requests out to nearby
"Rapid-C+" hardware units it finds via mDNS.

## How this was produced

1. `pyinstxtractor` (github.com/extremecoders-re/pyinstxtractor) unpacked
   the CArchive and PYZ archive out of the exe. This had to be run under
   **Python 3.8** specifically — the PYZ's marshalled code objects are
   version-specific and fail to unmarshal under any other interpreter
   version, even though the extractor script itself runs fine on newer
   Pythons for the outer archive.
2. The app's own compiled modules (`main.pyc`, `app.pyc`,
   `endpoints/*.pyc`, `services/*.pyc`) were decompiled back to Python
   source with `decompyle3` (a specific commit was needed — see note
   below; current PyPI-published `decompyle3`/`xdis` releases are not
   mutually compatible with each other for this at the time of writing).
   All 6 files decompiled cleanly with 0 failures.

## Known decompiler artifacts

- In `app.py`, `create_app()` contains a `nonlocal app` statement that
  decompyle3 emitted from the bytecode; at module scope this reads oddly
  (Python would reject a bare `nonlocal` with no enclosing binding). It's
  a decompiler quirk from how `app` gets bound as a de-facto module
  global from inside the factory function — functionally the code still
  runs as compiled, but if you're cleaning this up by hand, that line is
  the one to double check against your own understanding of the original
  intent (most likely it should just be a plain assignment, or `app` was
  read back as a global elsewhere via `current_app`).
- Comments and any original docstrings beyond the two that survived in
  `local.py`/`remote.py` are gone — pyc files don't retain source
  comments, so this is everything recoverable.
- Original file layout (`endpoints\__init__.py`-style backslashes in the
  decompiler's embedded-filename header) confirms this was built on
  Windows.

## Not included here

- `dist/` — the pre-built Angular frontend (176 static files, ~15 MB:
  JS bundles, CSS, fonts, images). This is compiled/minified JS, not
  Python, so it's outside the scope of a Python decompile; ask if you'd
  like it copied over as well — it's a straight file copy, not a
  decompilation.
