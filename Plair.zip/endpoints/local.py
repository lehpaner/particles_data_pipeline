# decompyle3 version 3.9.4.dev0
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.11.15 (main, Mar  3 2026, 09:26:23) [GCC 13.3.0]
# Embedded file name: endpoints\local.py
import json
from flask import Blueprint, Response, abort, current_app
bp = Blueprint("local", __name__)

@bp.route("/api/machine", methods=["GET"])
def list_machines():
    """Get a list of all Rapid-C+ discovered using mDNS.

    :>jsonarr string ip: Rapid-C+ IP Address
    :>jsonarr string serial: Rapid-C+ Identifier
    """
    nonlocal discover
    discover = current_app.config["machine_discovery"]
    machines = [{'ip':discover.rapidcp_discovered[serial]["ip"], 
     'serial':serial} for serial in discover.rapidcp_discovered]
    return Response((json.dumps(machines)), mimetype="application/json")
