# decompyle3 version 3.9.4.dev0
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.11.15 (main, Mar  3 2026, 09:26:23) [GCC 13.3.0]
# Embedded file name: endpoints\remote.py
import ipaddress, logging, requests
from flask import Blueprint, Response, abort, current_app, request
bp = Blueprint("remote", __name__)
API_URL = "api/v2"

@bp.route("/api/machine/<string:machine_id>/<path:subpath>", methods=["GET", "POST"])
def proxy_to_machine(machine_id, subpath):
    """Get or post data request to a machine.

    The request is converted and transferred to the machine and the machine's
    response is sent back.

    All query parameters (except Authorization) are kept in the request sent to
    the machine. `Authorization` query parameter is converted to Authorization
    header.

    :query string Authorization: the machine token

    :param machine_id: The target machine idenfifier (serial number) or IP address
    :param subpath: The requested subpath from Rapid-C+ API (not including /api/v2)

    """
    machines = current_app.config["machine_discovery"].rapidcp_discovered
    params = request.args.copy()
    if "Authorization" not in params:
        logging.error(f"Missing Authorization header to access {machine_id}")
        abort(401)
    try:
        machine_ip = machines[machine_id]["ip"]
        machine_port = machines[machine_id]["port"]
    except KeyError:
        try:
            ipaddress.ip_address(machine_id)
            machine_ip = machine_id
            machine_port = 80
        except ValueError:
            logging.error(f"Requested machine {machine_id} not found")
            abort(404)
        else:
            logging.debug(f"Using direct IP {machine_id} ")
    else:
        target_url = f"http://{machine_ip}:{machine_port}/{API_URL}/{subpath}"
        headers = {"Authorization": (params.pop("Authorization"))}
        data = request.get_data()
        request_response = requests.request(method=(request.method),
          url=target_url,
          headers=headers,
          params=params,
          data=data)
        if "Content-Type" in request_response.headers:
            content_type = request_response.headers["Content-Type"]
        else:
            content_type = None
        return Response(response=(request_response.content),
          status=(request_response.status_code),
          content_type=content_type)
