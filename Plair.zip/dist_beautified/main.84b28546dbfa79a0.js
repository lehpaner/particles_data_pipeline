"use strict";
(self.webpackChunkplairgrid = self.webpackChunkplairgrid || []).push([
  [792], {
    5312: (nt, Se, x) => {
      x.d(Se, {
        c: () => g
      });
      const g = {
        production: !0,
        apiBaseUrl: location.origin
      }
    },
    541: (nt, Se, x) => {
      var g = x(345),
        c = x(4438),
        ee = x(177),
        ae = x(5779),
        A = x(2183);
      let k = (() => {
          class C {
            constructor(a) {
              this.primengConfig = a
            }
            ngOnInit() {
              this.primengConfig.ripple = !0
            }
            static #e = this.\u0275fac = function(m) {
              return new(m || C)(c.rXU(ae.r1))
            };
            static #t = this.\u0275cmp = c.VBU({
              type: C,
              selectors: [
                ["app-root"]
              ],
              decls: 1,
              vars: 0,
              template: function(m, b) {
                1 & m && c.nrm(0, "router-outlet")
              },
              dependencies: [A.n3],
              encapsulation: 2
            })
          }
          return C
        })(),
        M = (() => {
          class C {
            static #e = this.\u0275fac = function(m) {
              return new(m || C)
            };
            static #t = this.\u0275cmp = c.VBU({
              type: C,
              selectors: [
                ["app-notfound"]
              ],
              decls: 11,
              vars: 0,
              consts: [
                [1, "surface-ground", "flex", "align-items-center", "justify-content-center",
                  "min-h-screen", "min-w-screen", "overflow-hidden"
                ],
                [1, "flex", "flex-column", "align-items-center", "justify-content-center"],
                ["src", "assets/layout/images/star.png", "alt", "Plair logo", 1, "mb-5", "w-6rem",
                  "flex-shrink-0"
                ],
                [2, "border-radius", "56px", "padding", "0.3rem", "background",
                  "linear-gradient(180deg, rgba(33, 150, 243, 0.4) 10%, rgba(33, 150, 243, 0) 30%)"
                ],
                [1, "w-full", "surface-card", "py-8", "px-5", "sm:px-8", "flex", "flex-column",
                  "align-items-center", 2, "border-radius", "53px"
                ],
                [1, "text-blue-500", "font-bold", "text-3xl"],
                [1, "text-900", "font-bold", "text-3xl", "lg:text-5xl", "mb-2"],
                [1, "text-600", "mb-5"]
              ],
              template: function(m, b) {
                1 & m && (c.j41(0, "div", 0)(1, "div", 1), c.nrm(2, "img", 2), c.j41(3, "div", 3)(4,
                  "div", 4)(5, "span", 5), c.EFF(6, "404"), c.k0s(), c.j41(7, "h1", 6), c.EFF(8,
                  "Not Found"), c.k0s(), c.j41(9, "div", 7), c.EFF(10,
                  "Requested resource is not available."), c.k0s()()()()())
              },
              encapsulation: 2
            })
          }
          return C
        })();
      var V = x(5964),
        $ = x(1413);
      let X = (() => {
        class C {
          constructor() {
            this._config = {
                ripple: !1,
                inputStyle: "outlined",
                menuMode: "static",
                colorScheme: "light",
                theme: "lara-light-indigo",
                scale: 14
              }, this.config = (0, c.vPA)(this._config), this.state = {
                staticMenuDesktopInactive: !0,
                overlayMenuActive: !1,
                profileSidebarVisible: !1,
                configSidebarVisible: !1,
                staticMenuMobileActive: !1,
                menuHoverActive: !1
              }, this.configUpdate = new $.B, this.overlayOpen = new $.B, this.configUpdate$ = this
              .configUpdate.asObservable(), this.overlayOpen$ = this.overlayOpen.asObservable(), (0, c.QZP)(
                () => {
                  const a = this.config();
                  this.updateStyle(a) && this.changeTheme(), this.changeScale(a.scale), this
                  .onConfigUpdate()
                })
          }
          updateStyle(a) {
            return a.theme !== this._config.theme || a.colorScheme !== this._config.colorScheme
          }
          onMenuToggle() {
            this.isOverlay() && (this.state.overlayMenuActive = !this.state.overlayMenuActive, this.state
                .overlayMenuActive && this.overlayOpen.next(null)), this.isDesktop() ? this.state
              .staticMenuDesktopInactive = !this.state.staticMenuDesktopInactive : (this.state
                .staticMenuMobileActive = !this.state.staticMenuMobileActive, this.state
                .staticMenuMobileActive && this.overlayOpen.next(null))
          }
          showProfileSidebar() {
            this.state.profileSidebarVisible = !this.state.profileSidebarVisible, this.state
              .profileSidebarVisible && this.overlayOpen.next(null)
          }
          showConfigSidebar() {
            this.state.configSidebarVisible = !0
          }
          isOverlay() {
            return "overlay" === this.config().menuMode
          }
          isDesktop() {
            return window.innerWidth > 991
          }
          isMobile() {
            return !this.isDesktop()
          }
          onConfigUpdate() {
            this._config = {
              ...this.config()
            }, this.configUpdate.next(this.config())
          }
          changeTheme() {
            const a = this.config(),
              R = document.getElementById("theme-css").getAttribute("href").split("/").map(j => j == this
                ._config.theme ? j = a.theme : j == `theme-${this._config.colorScheme}` ? j =
                `theme-${a.colorScheme}` : j).join("/");
            this.replaceThemeLink(R)
          }
          replaceThemeLink(a) {
            const m = "theme-css";
            let b = document.getElementById(m);
            const R = b.cloneNode(!0);
            R.setAttribute("href", a), R.setAttribute("id", m + "-clone"), b.parentNode.insertBefore(R, b
              .nextSibling), R.addEventListener("load", () => {
              b.remove(), R.setAttribute("id", m)
            })
          }
          changeScale(a) {
            document.documentElement.style.fontSize = `${a}px`
          }
          static #e = this.\u0275fac = function(m) {
            return new(m || C)
          };
          static #t = this.\u0275prov = c.jDH({
            token: C,
            factory: C.\u0275fac,
            providedIn: "root"
          })
        }
        return C
      })();
      var U = x(9969);
      let le = (() => {
        class C {
          constructor() {
            this.menuSource = new $.B, this.resetSource = new $.B, this.menuSource$ = this.menuSource
              .asObservable(), this.resetSource$ = this.resetSource.asObservable()
          }
          onMenuStateChange(a) {
            this.menuSource.next(a)
          }
          reset() {
            this.resetSource.next(!0)
          }
          static #e = this.\u0275fac = function(m) {
            return new(m || C)
          };
          static #t = this.\u0275prov = c.jDH({
            token: C,
            factory: C.\u0275fac,
            providedIn: "root"
          })
        }
        return C
      })();
      var Ne = x(563);
      const me = ["app-menuitem", ""],
        Ae = () => ({
          paths: "exact",
          queryParams: "ignored",
          matrixParams: "ignored",
          fragment: "ignored"
        });

      function qe(C, d) {
        if (1 & C && (c.j41(0, "div", 4), c.EFF(1), c.k0s()), 2 & C) {
          const a = c.XpG();
          c.R7$(), c.JRh(a.item.label)
        }
      }

      function we(C, d) {
        1 & C && c.nrm(0, "i", 9)
      }

      function Ve(C, d) {
        if (1 & C) {
          const a = c.RV6();
          c.j41(0, "a", 5), c.bIt("click", function(b) {
            c.eBV(a);
            const R = c.XpG();
            return c.Njj(R.itemClick(b))
          }), c.nrm(1, "i", 6), c.j41(2, "span", 7), c.EFF(3), c.k0s(), c.DNE(4, we, 1, 0, "i", 8), c.k0s()
        }
        if (2 & C) {
          const a = c.XpG();
          c.Y8G("ngClass", a.item.class), c.BMQ("href", a.item.url, c.B4B)("target", a.item.target), c.R7$(), c
            .Y8G("ngClass", a.item.icon), c.R7$(2), c.JRh(a.item.label), c.R7$(), c.Y8G("ngIf", a.item.items)
        }
      }

      function Ze(C, d) {
        1 & C && c.nrm(0, "i", 9)
      }

      function vt(C, d) {
        if (1 & C) {
          const a = c.RV6();
          c.j41(0, "a", 10), c.bIt("click", function(b) {
            c.eBV(a);
            const R = c.XpG();
            return c.Njj(R.itemClick(b))
          }), c.nrm(1, "i", 6), c.j41(2, "span", 7), c.EFF(3), c.k0s(), c.DNE(4, Ze, 1, 0, "i", 8), c.k0s()
        }
        if (2 & C) {
          const a = c.XpG();
          c.Y8G("ngClass", a.item.class)("routerLink", a.item.routerLink)("routerLinkActiveOptions", a.item
              .routerLinkActiveOptions || c.lJ4(14, Ae))("fragment", a.item.fragment)("queryParamsHandling", a
              .item.queryParamsHandling)("preserveFragment", a.item.preserveFragment)("skipLocationChange", a.item
              .skipLocationChange)("replaceUrl", a.item.replaceUrl)("state", a.item.state)("queryParams", a.item
              .queryParams), c.BMQ("target", a.item.target), c.R7$(), c.Y8G("ngClass", a.item.icon), c.R7$(2), c
            .JRh(a.item.label), c.R7$(), c.Y8G("ngIf", a.item.items)
        }
      }

      function ue(C, d) {
        if (1 & C && c.nrm(0, "li", 12), 2 & C) {
          const a = d.$implicit,
            m = d.index,
            b = c.XpG(2);
          c.HbH(a.badgeClass), c.Y8G("item", a)("index", m)("parentKey", b.key)
        }
      }

      function Pe(C, d) {
        if (1 & C && (c.j41(0, "ul"), c.DNE(1, ue, 1, 5, "ng-template", 11), c.k0s()), 2 & C) {
          const a = c.XpG();
          c.Y8G("@children", a.submenuAnimation), c.R7$(), c.Y8G("ngForOf", a.item.items)
        }
      }
      let ie = (() => {
        class C {
          constructor(a, m, b, R) {
            this.layoutService = a, this.cd = m, this.router = b, this.menuService = R, this.active = !1,
              this.key = "", this.menuSourceSubscription = this.menuService.menuSource$.subscribe(j => {
                Promise.resolve(null).then(() => {
                  j.routeEvent ? this.active = !(j.key !== this.key && !j.key.startsWith(this.key +
                    "-")) : j.key !== this.key && !j.key.startsWith(this.key + "-") && (this
                    .active = !1)
                })
              }), this.menuResetSubscription = this.menuService.resetSource$.subscribe(() => {
                this.active = !1
              }), this.router.events.pipe((0, V.p)(j => j instanceof A.wF)).subscribe(j => {
                this.item.routerLink && this.updateActiveStateFromRoute()
              })
          }
          ngOnInit() {
            this.key = this.parentKey ? this.parentKey + "-" + this.index : String(this.index), this.item
              .routerLink && this.updateActiveStateFromRoute()
          }
          updateActiveStateFromRoute() {
            this.router.isActive(this.item.routerLink[0], {
              paths: "exact",
              queryParams: "ignored",
              matrixParams: "ignored",
              fragment: "ignored"
            }) && this.menuService.onMenuStateChange({
              key: this.key,
              routeEvent: !0
            })
          }
          itemClick(a) {
            this.item.disabled ? a.preventDefault() : (this.item.command && this.item.command({
              originalEvent: a,
              item: this.item
            }), this.item.items && (this.active = !this.active), this.menuService.onMenuStateChange({
              key: this.key
            }))
          }
          get submenuAnimation() {
            return this.root || this.active ? "expanded" : "collapsed"
          }
          get activeClass() {
            return this.active && !this.root
          }
          ngOnDestroy() {
            this.menuSourceSubscription && this.menuSourceSubscription.unsubscribe(), this
              .menuResetSubscription && this.menuResetSubscription.unsubscribe()
          }
          static #e = this.\u0275fac = function(m) {
            return new(m || C)(c.rXU(X), c.rXU(c.gRc), c.rXU(A.Ix), c.rXU(le))
          };
          static #t = this.\u0275cmp = c.VBU({
            type: C,
            selectors: [
              ["", "app-menuitem", ""]
            ],
            hostVars: 4,
            hostBindings: function(m, b) {
              2 & m && c.AVh("layout-root-menuitem", b.root)("active-menuitem", b.activeClass)
            },
            inputs: {
              item: "item",
              index: "index",
              root: "root",
              parentKey: "parentKey"
            },
            attrs: me,
            decls: 5,
            vars: 4,
            consts: [
              ["class", "layout-menuitem-root-text", 4, "ngIf"],
              ["tabindex", "0", "pRipple", "", 3, "ngClass", "click", 4, "ngIf"],
              ["routerLinkActive", "active-route", "tabindex", "0", "pRipple", "", 3, "ngClass",
                "routerLink", "routerLinkActiveOptions", "fragment", "queryParamsHandling",
                "preserveFragment", "skipLocationChange", "replaceUrl", "state", "queryParams", "click",
                4, "ngIf"
              ],
              [4, "ngIf"],
              [1, "layout-menuitem-root-text"],
              ["tabindex", "0", "pRipple", "", 3, "click", "ngClass"],
              [1, "layout-menuitem-icon", 3, "ngClass"],
              [1, "layout-menuitem-text"],
              ["class", "pi pi-fw pi-angle-down layout-submenu-toggler", 4, "ngIf"],
              [1, "pi", "pi-fw", "pi-angle-down", "layout-submenu-toggler"],
              ["routerLinkActive", "active-route", "tabindex", "0", "pRipple", "", 3, "click",
                "ngClass", "routerLink", "routerLinkActiveOptions", "fragment", "queryParamsHandling",
                "preserveFragment", "skipLocationChange", "replaceUrl", "state", "queryParams"
              ],
              ["ngFor", "", 3, "ngForOf"],
              ["app-menuitem", "", 3, "item", "index", "parentKey"]
            ],
            template: function(m, b) {
              1 & m && (c.qex(0), c.DNE(1, qe, 2, 1, "div", 0)(2, Ve, 5, 6, "a", 1)(3, vt, 5, 15, "a",
                2)(4, Pe, 2, 2, "ul", 3), c.bVm()), 2 & m && (c.R7$(), c.Y8G("ngIf", b.root && !1 !==
                b.item.visible), c.R7$(), c.Y8G("ngIf", (!b.item.routerLink || b.item.items) && !
                1 !== b.item.visible), c.R7$(), c.Y8G("ngIf", b.item.routerLink && !b.item.items &&
                !1 !== b.item.visible), c.R7$(), c.Y8G("ngIf", b.item.items && !1 !== b.item
                .visible))
            },
            dependencies: [ee.YU, ee.Sq, ee.bT, Ne.n, A.Wk, A.wQ, C],
            encapsulation: 2,
            data: {
              animation: [(0, U.hZ)("children", [(0, U.wk)("collapsed", (0, U.iF)({
                height: "0"
              })), (0, U.wk)("expanded", (0, U.iF)({
                height: "*"
              })), (0, U.kY)("collapsed <=> expanded", (0, U.i0)(
                "400ms cubic-bezier(0.86, 0, 0.07, 1)"))])]
            }
          })
        }
        return C
      })();

      function se(C, d) {
        if (1 & C && c.nrm(0, "li", 4), 2 & C) {
          const a = c.XpG(),
            b = a.index;
          c.Y8G("item", a.$implicit)("index", b)("root", !0)
        }
      }

      function Re(C, d) {
        1 & C && c.nrm(0, "li", 5)
      }

      function Be(C, d) {
        if (1 & C && (c.qex(0), c.DNE(1, se, 1, 3, "li", 2)(2, Re, 1, 0, "li", 3), c.bVm()), 2 & C) {
          const a = d.$implicit;
          c.R7$(), c.Y8G("ngIf", !a.separator), c.R7$(), c.Y8G("ngIf", a.separator)
        }
      }
      let De = (() => {
          class C {
            constructor(a) {
              this.layoutService = a, this.model = []
            }
            ngOnInit() {
              this.model = [{
                label: "Machines",
                items: [{
                  label: "Rapid C+",
                  icon: "pi pi-fw pi-home",
                  routerLink: ["/machines"]
                }]
              }]
            }
            static #e = this.\u0275fac = function(m) {
              return new(m || C)(c.rXU(X))
            };
            static #t = this.\u0275cmp = c.VBU({
              type: C,
              selectors: [
                ["app-menu"]
              ],
              decls: 2,
              vars: 1,
              consts: [
                [1, "layout-menu"],
                [4, "ngFor", "ngForOf"],
                ["app-menuitem", "", 3, "item", "index", "root", 4, "ngIf"],
                ["class", "menu-separator", 4, "ngIf"],
                ["app-menuitem", "", 3, "item", "index", "root"],
                [1, "menu-separator"]
              ],
              template: function(m, b) {
                1 & m && (c.j41(0, "ul", 0), c.DNE(1, Be, 3, 2, "ng-container", 1), c.k0s()), 2 & m && (c
                  .R7$(), c.Y8G("ngForOf", b.model))
              },
              dependencies: [ee.Sq, ee.bT, ie],
              encapsulation: 2
            })
          }
          return C
        })(),
        Z = (() => {
          class C {
            constructor(a, m) {
              this.layoutService = a, this.el = m
            }
            static #e = this.\u0275fac = function(m) {
              return new(m || C)(c.rXU(X), c.rXU(c.aKT))
            };
            static #t = this.\u0275cmp = c.VBU({
              type: C,
              selectors: [
                ["app-sidebar"]
              ],
              decls: 1,
              vars: 0,
              template: function(m, b) {
                1 & m && c.nrm(0, "app-menu")
              },
              dependencies: [De],
              encapsulation: 2
            })
          }
          return C
        })();
      var xe = x(9437),
        be = x(8810),
        et = x(5312),
        Et = x(1626);
      let Ht = (() => {
        class C {
          constructor(a) {
            this.http = a
          }
          shutdownServer() {
            return this.http.get(`${et.c.apiBaseUrl}/api/shutdown`).pipe((0, xe.W)(this.handleError))
          }
          handleError(a) {
            return 0 !== a.status ? 401 === (console.error(`Backend returned code ${a.status}, body was: `,
              a.error), a.status) ? (0, be.$)(() => new Error("Not Authorized", {
              cause: a
            })) : (0, be.$)(() => new Error("Host not reachable", {
              cause: a
            })) : (console.error("An error occurred:", a.error), (0, be.$)(() => new Error(
              "Host not reachable", {
                cause: a
              })))
          }
          static #e = this.\u0275fac = function(m) {
            return new(m || C)(c.KVO(Et.Qq))
          };
          static #t = this.\u0275prov = c.jDH({
            token: C,
            factory: C.\u0275fac,
            providedIn: "root"
          })
        }
        return C
      })();
      const Zt = ["menubutton"],
        Yn = ["topbarmenubutton"],
        he = ["topbarmenu"],
        ye = C => ({
          "layout-topbar-menu-mobile-active": C
        });
      let ve = (() => {
        class C {
          constructor(a, m, b) {
            this.layoutService = a, this.serverService = m, this.router = b
          }
          shutdownServer() {
            this.serverService.shutdownServer().subscribe({
              next: a => {
                console.log(a), window.top.close(), this.redirectTo(this.router, "/")
              },
              error: a => {
                this.redirectTo(this.router, "/")
              }
            })
          }
          redirectTo(a, m, b = !1, R) {
            a.navigate([m], {
              skipLocationChange: b,
              queryParams: R
            }).then(() => {
              window.location.reload()
            })
          }
          static #e = this.\u0275fac = function(m) {
            return new(m || C)(c.rXU(X), c.rXU(Ht), c.rXU(A.Ix))
          };
          static #t = this.\u0275cmp = c.VBU({
            type: C,
            selectors: [
              ["app-topbar"]
            ],
            viewQuery: function(m, b) {
              if (1 & m && (c.GBs(Zt, 5), c.GBs(Yn, 5), c.GBs(he, 5)), 2 & m) {
                let R;
                c.mGM(R = c.lsd()) && (b.menuButton = R.first), c.mGM(R = c.lsd()) && (b
                  .topbarMenuButton = R.first), c.mGM(R = c.lsd()) && (b.menu = R.first)
              }
            },
            decls: 17,
            vars: 5,
            consts: [
              ["menubutton", ""],
              ["topbarmenubutton", ""],
              ["topbarmenu", ""],
              [1, "layout-topbar"],
              ["routerLink", "", 1, "layout-topbar-logo"],
              ["alt", "logo", 3, "src"],
              [1, "p-link", "layout-menu-button", "layout-topbar-button", 3, "click"],
              [1, "pi", "pi-bars"],
              [1, "p-link", "layout-topbar-menu-button", "layout-topbar-button", 3, "click"],
              [1, "pi", "pi-ellipsis-v"],
              [1, "layout-topbar-menu", 3, "ngClass"],
              [1, "p-link", "layout-topbar-button", 3, "click"],
              [1, "fa-solid", "fa-power-off"]
            ],
            template: function(m, b) {
              if (1 & m) {
                const R = c.RV6();
                c.j41(0, "div", 3)(1, "a", 4), c.nrm(2, "img", 5), c.j41(3, "span"), c.EFF(4,
                  "PLAIRGRID"), c.k0s()(), c.j41(5, "button", 6, 0), c.bIt("click", function() {
                  return c.eBV(R), c.Njj(b.layoutService.onMenuToggle())
                }), c.nrm(7, "i", 7), c.k0s(), c.j41(8, "button", 8, 1), c.bIt("click", function() {
                  return c.eBV(R), c.Njj(b.layoutService.showProfileSidebar())
                }), c.nrm(10, "i", 9), c.k0s(), c.j41(11, "div", 10, 2)(13, "button", 11), c.bIt(
                  "click",
                  function() {
                    return c.eBV(R), c.Njj(b.shutdownServer())
                  }), c.nrm(14, "i", 12), c.j41(15, "span"), c.EFF(16, "Shutdown"), c.k0s()()()()
              }
              2 & m && (c.R7$(2), c.Mz_("src", "assets/layout/images/", "light" === b.layoutService
                .config().colorScheme ? "logo-dark" : "logo-white", ".svg", c.B4B), c.R7$(9), c.Y8G(
                "ngClass", c.eq3(3, ye, b.layoutService.state.profileSidebarVisible)))
            },
            dependencies: [ee.YU, A.Wk],
            encapsulation: 2
          })
        }
        return C
      })();
      let ke = (() => {
          class C {
            constructor(a) {
              this.layoutService = a, this.version = "1.6.0"
            }
            static #e = this.\u0275fac = function(m) {
              return new(m || C)(c.rXU(X))
            };
            static #t = this.\u0275cmp = c.VBU({
              type: C,
              selectors: [
                ["app-footer"]
              ],
              decls: 6,
              vars: 3,
              consts: [
                [1, "layout-footer"],
                ["alt", "Logo", "height", "20", 1, "mr-2", 3, "src"],
                [1, "font-medium", "ml-2"],
                ["href", "http://www.plair.ch/"]
              ],
              template: function(m, b) {
                1 & m && (c.j41(0, "div", 0), c.nrm(1, "img", 1), c.EFF(2), c.j41(3, "span", 2)(4, "a",
                  3), c.EFF(5, "Plair SA"), c.k0s()()()), 2 & m && (c.R7$(), c.Mz_("src",
                  "assets/layout/images/", "light" === b.layoutService.config().colorScheme ?
                  "logo-dark" : "logo-white", ".svg", c.B4B), c.R7$(), c.SpI(" v", b.version, " by "))
              },
              encapsulation: 2
            })
          }
          return C
        })(),
        Le = (() => {
          class C {
            constructor(a, m, b) {
              this.layoutService = a, this.renderer = m, this.router = b, this.overlayMenuOpenSubscription =
                this.layoutService.overlayOpen$.subscribe(() => {
                  this.menuOutsideClickListener || (this.menuOutsideClickListener = this.renderer.listen(
                    "document", "click", R => {
                      !(this.appSidebar.el.nativeElement.isSameNode(R.target) || this.appSidebar.el
                        .nativeElement.contains(R.target) || this.appTopbar.menuButton.nativeElement
                        .isSameNode(R.target) || this.appTopbar.menuButton.nativeElement.contains(R
                          .target)) && this.hideMenu()
                    })), this.profileMenuOutsideClickListener || (this.profileMenuOutsideClickListener =
                    this.renderer.listen("document", "click", R => {
                      !(this.appTopbar.menu.nativeElement.isSameNode(R.target) || this.appTopbar.menu
                        .nativeElement.contains(R.target) || this.appTopbar.topbarMenuButton
                        .nativeElement.isSameNode(R.target) || this.appTopbar.topbarMenuButton
                        .nativeElement.contains(R.target)) && this.hideProfileMenu()
                    })), this.layoutService.state.staticMenuMobileActive && this.blockBodyScroll()
                }), this.router.events.pipe((0, V.p)(R => R instanceof A.wF)).subscribe(() => {
                  this.hideMenu(), this.hideProfileMenu()
                })
            }
            hideMenu() {
              this.layoutService.state.overlayMenuActive = !1, this.layoutService.state
                .staticMenuMobileActive = !1, this.layoutService.state.menuHoverActive = !1, this
                .menuOutsideClickListener && (this.menuOutsideClickListener(), this.menuOutsideClickListener =
                  null), this.unblockBodyScroll()
            }
            hideProfileMenu() {
              this.layoutService.state.profileSidebarVisible = !1, this.profileMenuOutsideClickListener && (
                this.profileMenuOutsideClickListener(), this.profileMenuOutsideClickListener = null)
            }
            blockBodyScroll() {
              document.body.classList ? document.body.classList.add("blocked-scroll") : document.body
                .className += " blocked-scroll"
            }
            unblockBodyScroll() {
              document.body.classList ? document.body.classList.remove("blocked-scroll") : document.body
                .className = document.body.className.replace(new RegExp("(^|\\b)" + "blocked-scroll".split(
                  " ").join("|") + "(\\b|$)", "gi"), " ")
            }
            get containerClass() {
              return {
                "layout-theme-light": "light" === this.layoutService.config().colorScheme,
                "layout-theme-dark": "dark" === this.layoutService.config().colorScheme,
                "layout-overlay": "overlay" === this.layoutService.config().menuMode,
                "layout-static": "static" === this.layoutService.config().menuMode,
                "layout-static-inactive": this.layoutService.state.staticMenuDesktopInactive && "static" ===
                  this.layoutService.config().menuMode,
                "layout-overlay-active": this.layoutService.state.overlayMenuActive,
                "layout-mobile-active": this.layoutService.state.staticMenuMobileActive,
                "p-input-filled": "filled" === this.layoutService.config().inputStyle,
                "p-ripple-disabled": !this.layoutService.config().ripple
              }
            }
            ngOnDestroy() {
              this.overlayMenuOpenSubscription && this.overlayMenuOpenSubscription.unsubscribe(), this
                .menuOutsideClickListener && this.menuOutsideClickListener()
            }
            static #e = this.\u0275fac = function(m) {
              return new(m || C)(c.rXU(X), c.rXU(c.sFG), c.rXU(A.Ix))
            };
            static #t = this.\u0275cmp = c.VBU({
              type: C,
              selectors: [
                ["app-layout"]
              ],
              viewQuery: function(m, b) {
                if (1 & m && (c.GBs(Z, 5), c.GBs(ve, 5)), 2 & m) {
                  let R;
                  c.mGM(R = c.lsd()) && (b.appSidebar = R.first), c.mGM(R = c.lsd()) && (b.appTopbar = R
                    .first)
                }
              },
              decls: 9,
              vars: 1,
              consts: [
                [1, "layout-wrapper", 3, "ngClass"],
                [1, "layout-sidebar"],
                [1, "layout-main-container"],
                [1, "layout-main"],
                [1, "layout-mask"]
              ],
              template: function(m, b) {
                1 & m && (c.j41(0, "div", 0), c.nrm(1, "app-topbar"), c.j41(2, "div", 1), c.nrm(3,
                      "app-sidebar"), c.k0s(), c.j41(4, "div", 2)(5, "div", 3), c.nrm(6, "router-outlet"),
                    c.k0s(), c.nrm(7, "app-footer"), c.k0s(), c.nrm(8, "div", 4), c.k0s()), 2 & m && c
                  .Y8G("ngClass", b.containerClass)
              },
              dependencies: [ee.YU, A.n3, ve, ke, Z],
              encapsulation: 2
            })
          }
          return C
        })(),
        rt = (() => {
          class C {
            static #e = this.\u0275fac = function(m) {
              return new(m || C)
            };
            static #t = this.\u0275mod = c.$C({
              type: C
            });
            static #n = this.\u0275inj = c.G2t({
              imports: [A.iI.forRoot([{
                path: "",
                component: Le,
                children: [{
                  path: "",
                  redirectTo: "/machines",
                  pathMatch: "full"
                }, {
                  path: "machines",
                  loadChildren: () => x.e(191).then(x.bind(x, 7191)).then(a => a.MachinesModule)
                }]
              }, {
                path: "notfound",
                component: M
              }, {
                path: "**",
                redirectTo: "/notfound"
              }], {
                scrollPositionRestoration: "enabled",
                anchorScrolling: "enabled",
                onSameUrlNavigation: "reload"
              }), A.iI]
            })
          }
          return C
        })();
      var Nt = x(9417);

      function ht(C) {
        return new c.wOt(3e3, !1)
      }

      function J(C) {
        switch (C.length) {
          case 0:
            return new U.sf;
          case 1:
            return C[0];
          default:
            return new U.ui(C)
        }
      }

      function Oe(C, d, a = new Map, m = new Map) {
        const b = [],
          R = [];
        let j = -1,
          q = null;
        if (d.forEach(de => {
            const fe = de.get("offset"),
              $e = fe == j,
              Ge = $e && q || new Map;
            de.forEach((We, Mt) => {
              let gt = Mt,
                Dt = We;
              if ("offset" !== Mt) switch (gt = C.normalizePropertyName(gt, b), Dt) {
                case U.FX:
                  Dt = a.get(Mt);
                  break;
                case U.kp:
                  Dt = m.get(Mt);
                  break;
                default:
                  Dt = C.normalizeStyleValue(Mt, gt, Dt, b)
              }
              Ge.set(gt, Dt)
            }), $e || R.push(Ge), q = Ge, j = fe
          }), b.length) throw function dt(C) {
          return new c.wOt(3502, !1)
        }();
        return R
      }

      function Qe(C, d, a, m) {
        switch (d) {
          case "start":
            C.onStart(() => m(a && ct(a, "start", C)));
            break;
          case "done":
            C.onDone(() => m(a && ct(a, "done", C)));
            break;
          case "destroy":
            C.onDestroy(() => m(a && ct(a, "destroy", C)))
        }
      }

      function ct(C, d, a) {
        const R = qt(C.element, C.triggerName, C.fromState, C.toState, d || C.phaseName, a.totalTime ?? C
            .totalTime, !!a.disabled),
          j = C._data;
        return null != j && (R._data = j), R
      }

      function qt(C, d, a, m, b = "", R = 0, j) {
        return {
          element: C,
          triggerName: d,
          fromState: a,
          toState: m,
          phaseName: b,
          totalTime: R,
          disabled: !!j
        }
      }

      function Wt(C, d, a) {
        let m = C.get(d);
        return m || C.set(d, m = a), m
      }

      function bn(C) {
        const d = C.indexOf(":");
        return [C.substring(1, d), C.slice(d + 1)]
      }
      const Zn = typeof document > "u" ? null : document.documentElement;

      function yn(C) {
        const d = C.parentNode || C.host || null;
        return d === Zn ? null : d
      }
      let cr = null,
        qr = !1;

      function Qr(C, d) {
        for (; d;) {
          if (d === C) return !0;
          d = yn(d)
        }
        return !1
      }

      function ii(C, d, a) {
        if (a) return Array.from(C.querySelectorAll(d));
        const m = C.querySelector(d);
        return m ? [m] : []
      }
      let Vr = (() => {
        class C {
          validateStyleProperty(a) {
            return function fn(C) {
              cr || (cr = function Gi() {
                return typeof document < "u" ? document.body : null
              }() || {}, qr = !!cr.style && "WebkitAppearance" in cr.style);
              let d = !0;
              return cr.style && ! function lr(C) {
                return "ebkit" == C.substring(1, 6)
              }(C) && (d = C in cr.style, !d && qr && (d = "Webkit" + C.charAt(0).toUpperCase() + C
                .slice(1) in cr.style)), d
            }(a)
          }
          matchesElement(a, m) {
            return !1
          }
          containsElement(a, m) {
            return Qr(a, m)
          }
          getParentElement(a) {
            return yn(a)
          }
          query(a, m, b) {
            return ii(a, m, b)
          }
          computeStyle(a, m, b) {
            return b || ""
          }
          animate(a, m, b, R, j, q = [], de) {
            return new U.sf(b, R)
          }
          static #e = this.\u0275fac = function(m) {
            return new(m || C)
          };
          static #t = this.\u0275prov = c.jDH({
            token: C,
            factory: C.\u0275fac
          })
        }
        return C
      })();
      class Gt {
        static #e = this.NOOP = new Vr
      }
      class zi {}
      const oi = 1e3,
        ai = "ng-enter",
        Xr = "ng-leave",
        B = "ng-trigger",
        z = ".ng-trigger",
        K = "ng-animating",
        Ee = ".ng-animating";

      function pe(C) {
        if ("number" == typeof C) return C;
        const d = C.match(/^(-?[\.\d]+)(m?s)/);
        return !d || d.length < 2 ? 0 : je(parseFloat(d[1]), d[2])
      }

      function je(C, d) {
        return "s" === d ? C * oi : C
      }

      function He(C, d, a) {
        return C.hasOwnProperty("duration") ? C : function _t(C, d, a) {
          let b, R = 0,
            j = "";
          if ("string" == typeof C) {
            const q = C.match(/^(-?[\.\d]+)(m?s)(?:\s+(-?[\.\d]+)(m?s))?(?:\s+([-a-z]+(?:\(.+?\))?))?$/i);
            if (null === q) return d.push(ht()), {
              duration: 0,
              delay: 0,
              easing: ""
            };
            b = je(parseFloat(q[1]), q[2]);
            const de = q[3];
            null != de && (R = je(parseFloat(de), q[4]));
            const fe = q[5];
            fe && (j = fe)
          } else b = C;
          if (!a) {
            let q = !1,
              de = d.length;
            b < 0 && (d.push(function Ut() {
              return new c.wOt(3100, !1)
            }()), q = !0), R < 0 && (d.push(function nn() {
              return new c.wOt(3101, !1)
            }()), q = !0), q && d.splice(de, 0, ht())
          }
          return {
            duration: b,
            delay: R,
            easing: j
          }
        }(C, d, a)
      }

      function Xt(C, d, a) {
        d.forEach((m, b) => {
          const R = Dr(b);
          a && !a.has(b) && a.set(b, C.style[R]), C.style[R] = m
        })
      }

      function Ft(C, d) {
        d.forEach((a, m) => {
          const b = Dr(m);
          C.style[b] = ""
        })
      }

      function sn(C) {
        return Array.isArray(C) ? 1 == C.length ? C[0] : (0, U.K2)(C) : C
      }
      const Rn = new RegExp("{{\\s*(.+?)\\s*}}", "g");

      function jt(C) {
        let d = [];
        if ("string" == typeof C) {
          let a;
          for (; a = Rn.exec(C);) d.push(a[1]);
          Rn.lastIndex = 0
        }
        return d
      }

      function kt(C, d, a) {
        const m = `${C}`,
          b = m.replace(Rn, (R, j) => {
            let q = d[j];
            return null == q && (a.push(function Ct(C) {
              return new c.wOt(3003, !1)
            }()), q = ""), q.toString()
          });
        return b == m ? C : b
      }
      const Dn = /-+([a-z0-9])/g;

      function Dr(C) {
        return C.replace(Dn, (...d) => d[1].toUpperCase())
      }

      function gn(C, d, a) {
        switch (d.type) {
          case U.If.Trigger:
            return C.visitTrigger(d, a);
          case U.If.State:
            return C.visitState(d, a);
          case U.If.Transition:
            return C.visitTransition(d, a);
          case U.If.Sequence:
            return C.visitSequence(d, a);
          case U.If.Group:
            return C.visitGroup(d, a);
          case U.If.Animate:
            return C.visitAnimate(d, a);
          case U.If.Keyframes:
            return C.visitKeyframes(d, a);
          case U.If.Style:
            return C.visitStyle(d, a);
          case U.If.Reference:
            return C.visitReference(d, a);
          case U.If.AnimateChild:
            return C.visitAnimateChild(d, a);
          case U.If.AnimateRef:
            return C.visitAnimateRef(d, a);
          case U.If.Query:
            return C.visitQuery(d, a);
          case U.If.Stagger:
            return C.visitStagger(d, a);
          default:
            throw function dn(C) {
              return new c.wOt(3004, !1)
            }()
        }
      }

      function lt(C, d) {
        return window.getComputedStyle(C)[d]
      }
      const Ye = new Set(["width", "height", "minWidth", "minHeight", "maxWidth", "maxHeight", "left", "top",
        "bottom", "right", "fontSize", "outlineWidth", "outlineOffset", "paddingTop", "paddingLeft",
        "paddingBottom", "paddingRight", "marginTop", "marginLeft", "marginBottom", "marginRight",
        "borderRadius", "borderWidth", "borderTopWidth", "borderLeftWidth", "borderRightWidth",
        "borderBottomWidth", "textIndent", "perspective"
      ]);
      class Fr extends zi {
        normalizePropertyName(d, a) {
          return Dr(d)
        }
        normalizeStyleValue(d, a, m, b) {
          let R = "";
          const j = m.toString().trim();
          if (Ye.has(a) && 0 !== m && "0" !== m)
            if ("number" == typeof m) R = "px";
            else {
              const q = m.match(/^[+-]?[\d\.]+([a-z]*)$/);
              q && 0 == q[1].length && b.push(function Un(C, d) {
                return new c.wOt(3005, !1)
              }())
            } return j + R
        }
      }
      const Br = "*";
      const qi = new Set(["true", "1"]),
        rs = new Set(["false", "0"]);

      function Ur(C, d) {
        const a = qi.has(C) || rs.has(C),
          m = qi.has(d) || rs.has(d);
        return (b, R) => {
          let j = C == Br || C == b,
            q = d == Br || d == R;
          return !j && a && "boolean" == typeof b && (j = b ? qi.has(C) : rs.has(C)), !q && m && "boolean" ==
            typeof R && (q = R ? qi.has(d) : rs.has(d)), j && q
        }
      }
      const Ci = new RegExp("s*:selfs*,?", "g");

      function is(C, d, a, m) {
        return new Is(C).build(d, a, m)
      }
      class Is {
        constructor(d) {
          this._driver = d
        }
        build(d, a, m) {
          const b = new Yi(a);
          return this._resetContextStyleTimingState(b), gn(this, sn(d), b)
        }
        _resetContextStyleTimingState(d) {
          d.currentQuerySelector = "", d.collectedStyles = new Map, d.collectedStyles.set("", new Map), d
            .currentTime = 0
        }
        visitTrigger(d, a) {
          let m = a.queryCount = 0,
            b = a.depCount = 0;
          const R = [],
            j = [];
          return "@" == d.name.charAt(0) && a.errors.push(function rn() {
            return new c.wOt(3006, !1)
          }()), d.definitions.forEach(q => {
            if (this._resetContextStyleTimingState(a), q.type == U.If.State) {
              const de = q,
                fe = de.name;
              fe.toString().split(/\s*,\s*/).forEach($e => {
                de.name = $e, R.push(this.visitState(de, a))
              }), de.name = fe
            } else if (q.type == U.If.Transition) {
              const de = this.visitTransition(q, a);
              m += de.queryCount, b += de.depCount, j.push(de)
            } else a.errors.push(function Nn() {
              return new c.wOt(3007, !1)
            }())
          }), {
            type: U.If.Trigger,
            name: d.name,
            states: R,
            transitions: j,
            queryCount: m,
            depCount: b,
            options: null
          }
        }
        visitState(d, a) {
          const m = this.visitStyle(d.styles, a),
            b = d.options && d.options.params || null;
          if (m.containsDynamicStyles) {
            const R = new Set,
              j = b || {};
            m.styles.forEach(q => {
              q instanceof Map && q.forEach(de => {
                jt(de).forEach(fe => {
                  j.hasOwnProperty(fe) || R.add(fe)
                })
              })
            }), R.size && a.errors.push(function Ke(C, d) {
              return new c.wOt(3008, !1)
            }(0, R.values()))
          }
          return {
            type: U.If.State,
            name: d.name,
            style: m,
            options: b ? {
              params: b
            } : null
          }
        }
        visitTransition(d, a) {
          a.queryCount = 0, a.depCount = 0;
          const m = gn(this, sn(d.animation), a),
            b = function Ki(C, d) {
              const a = [];
              return "string" == typeof C ? C.split(/\s*,\s*/).forEach(m => function Vn(C, d, a) {
                if (":" == C[0]) {
                  const de = function Ss(C, d) {
                    switch (C) {
                      case ":enter":
                        return "void => *";
                      case ":leave":
                        return "* => void";
                      case ":increment":
                        return (a, m) => parseFloat(m) > parseFloat(a);
                      case ":decrement":
                        return (a, m) => parseFloat(m) < parseFloat(a);
                      default:
                        return d.push(function mn(C) {
                          return new c.wOt(3016, !1)
                        }()), "* => *"
                    }
                  }(C, a);
                  if ("function" == typeof de) return void d.push(de);
                  C = de
                }
                const m = C.match(/^(\*|[-\w]+)\s*(<?[=-]>)\s*(\*|[-\w]+)$/);
                if (null == m || m.length < 4) return a.push(function vr(C) {
                  return new c.wOt(3015, !1)
                }()), d;
                const b = m[1],
                  R = m[2],
                  j = m[3];
                d.push(Ur(b, j)), "<" == R[0] && (b != Br || j != Br) && d.push(Ur(j, b))
              }(m, a, d)) : a.push(C), a
            }(d.expr, a.errors);
          return {
            type: U.If.Transition,
            matchers: b,
            animation: m,
            queryCount: a.queryCount,
            depCount: a.depCount,
            options: en(d.options)
          }
        }
        visitSequence(d, a) {
          return {
            type: U.If.Sequence,
            steps: d.steps.map(m => gn(this, m, a)),
            options: en(d.options)
          }
        }
        visitGroup(d, a) {
          const m = a.currentTime;
          let b = 0;
          const R = d.steps.map(j => {
            a.currentTime = m;
            const q = gn(this, j, a);
            return b = Math.max(b, a.currentTime), q
          });
          return a.currentTime = b, {
            type: U.If.Group,
            steps: R,
            options: en(d.options)
          }
        }
        visitAnimate(d, a) {
          const m = function zs(C, d) {
            if (C.hasOwnProperty("duration")) return C;
            if ("number" == typeof C) return ci(He(C, d).duration, 0, "");
            const a = C;
            if (a.split(/\s+/).some(R => "{" == R.charAt(0) && "{" == R.charAt(1))) {
              const R = ci(0, 0, "");
              return R.dynamic = !0, R.strValue = a, R
            }
            const b = He(a, d);
            return ci(b.duration, b.delay, b.easing)
          }(d.timings, a.errors);
          a.currentAnimateTimings = m;
          let b, R = d.styles ? d.styles : (0, U.iF)({});
          if (R.type == U.If.Keyframes) b = this.visitKeyframes(R, a);
          else {
            let j = d.styles,
              q = !1;
            if (!j) {
              q = !0;
              const fe = {};
              m.easing && (fe.easing = m.easing), j = (0, U.iF)(fe)
            }
            a.currentTime += m.duration + m.delay;
            const de = this.visitStyle(j, a);
            de.isEmptyStep = q, b = de
          }
          return a.currentAnimateTimings = null, {
            type: U.If.Animate,
            timings: m,
            style: b,
            options: null
          }
        }
        visitStyle(d, a) {
          const m = this._makeStyleAst(d, a);
          return this._validateStyleAst(m, a), m
        }
        _makeStyleAst(d, a) {
          const m = [],
            b = Array.isArray(d.styles) ? d.styles : [d.styles];
          for (let q of b) "string" == typeof q ? q === U.kp ? m.push(q) : a.errors.push(new c.wOt(3002, !1)) :
            m.push(new Map(Object.entries(q)));
          let R = !1,
            j = null;
          return m.forEach(q => {
            if (q instanceof Map && (q.has("easing") && (j = q.get("easing"), q.delete("easing")), !R))
              for (let de of q.values())
                if (de.toString().indexOf("{{") >= 0) {
                  R = !0;
                  break
                }
          }), {
            type: U.If.Style,
            styles: m,
            easing: j,
            offset: d.offset,
            containsDynamicStyles: R,
            options: null
          }
        }
        _validateStyleAst(d, a) {
          const m = a.currentAnimateTimings;
          let b = a.currentTime,
            R = a.currentTime;
          m && R > 0 && (R -= m.duration + m.delay), d.styles.forEach(j => {
            "string" != typeof j && j.forEach((q, de) => {
              const fe = a.collectedStyles.get(a.currentQuerySelector),
                $e = fe.get(de);
              let Ge = !0;
              $e && (R != b && R >= $e.startTime && b <= $e.endTime && (a.errors.push(function _i(C, d,
                a, m, b) {
                return new c.wOt(3010, !1)
              }()), Ge = !1), R = $e.startTime), Ge && fe.set(de, {
                startTime: R,
                endTime: b
              }), a.options && function ur(C, d, a) {
                const m = d.params || {},
                  b = jt(C);
                b.length && b.forEach(R => {
                  m.hasOwnProperty(R) || a.push(function bt(C) {
                    return new c.wOt(3001, !1)
                  }())
                })
              }(q, a.options, a.errors)
            })
          })
        }
        visitKeyframes(d, a) {
          const m = {
            type: U.If.Keyframes,
            styles: [],
            options: null
          };
          if (!a.currentAnimateTimings) return a.errors.push(function ti() {
            return new c.wOt(3011, !1)
          }()), m;
          let R = 0;
          const j = [];
          let q = !1,
            de = !1,
            fe = 0;
          const $e = d.steps.map(Tn => {
            const An = this._makeStyleAst(Tn, a);
            let _n = null != An.offset ? An.offset : function Yr(C) {
                if ("string" == typeof C) return null;
                let d = null;
                if (Array.isArray(C)) C.forEach(a => {
                  if (a instanceof Map && a.has("offset")) {
                    const m = a;
                    d = parseFloat(m.get("offset")), m.delete("offset")
                  }
                });
                else if (C instanceof Map && C.has("offset")) {
                  const a = C;
                  d = parseFloat(a.get("offset")), a.delete("offset")
                }
                return d
              }(An.styles),
              Fn = 0;
            return null != _n && (R++, Fn = An.offset = _n), de = de || Fn < 0 || Fn > 1, q = q || Fn < fe,
              fe = Fn, j.push(Fn), An
          });
          de && a.errors.push(function St() {
            return new c.wOt(3012, !1)
          }()), q && a.errors.push(function jn() {
            return new c.wOt(3200, !1)
          }());
          const Ge = d.steps.length;
          let We = 0;
          R > 0 && R < Ge ? a.errors.push(function Tt() {
            return new c.wOt(3202, !1)
          }()) : 0 == R && (We = 1 / (Ge - 1));
          const Mt = Ge - 1,
            gt = a.currentTime,
            Dt = a.currentAnimateTimings,
            ft = Dt.duration;
          return $e.forEach((Tn, An) => {
            const _n = We > 0 ? An == Mt ? 1 : We * An : j[An],
              Fn = _n * ft;
            a.currentTime = gt + Dt.delay + Fn, Dt.duration = Fn, this._validateStyleAst(Tn, a), Tn.offset =
              _n, m.styles.push(Tn)
          }), m
        }
        visitReference(d, a) {
          return {
            type: U.If.Reference,
            animation: gn(this, sn(d.animation), a),
            options: en(d.options)
          }
        }
        visitAnimateChild(d, a) {
          return a.depCount++, {
            type: U.If.AnimateChild,
            options: en(d.options)
          }
        }
        visitAnimateRef(d, a) {
          return {
            type: U.If.AnimateRef,
            animation: this.visitReference(d.animation, a),
            options: en(d.options)
          }
        }
        visitQuery(d, a) {
          const m = a.currentQuerySelector,
            b = d.options || {};
          a.queryCount++, a.currentQuery = d;
          const [R, j] = function ss(C) {
            const d = !!C.split(/\s*,\s*/).find(a => ":self" == a);
            return d && (C = C.replace(Ci, "")), C = C.replace(/@\*/g, z).replace(/@\w+/g, a => z + "-" + a
              .slice(1)).replace(/:animating/g, Ee), [C, d]
          }(d.selector);
          a.currentQuerySelector = m.length ? m + " " + R : R, Wt(a.collectedStyles, a.currentQuerySelector,
            new Map);
          const q = gn(this, sn(d.animation), a);
          return a.currentQuery = null, a.currentQuerySelector = m, {
            type: U.If.Query,
            selector: R,
            limit: b.limit || 0,
            optional: !!b.optional,
            includeSelf: j,
            animation: q,
            originalSelector: d.selector,
            options: en(d.options)
          }
        }
        visitStagger(d, a) {
          a.currentQuery || a.errors.push(function It() {
            return new c.wOt(3013, !1)
          }());
          const m = "full" === d.timings ? {
            duration: 0,
            delay: 0,
            easing: "full"
          } : He(d.timings, a.errors, !0);
          return {
            type: U.If.Stagger,
            animation: gn(this, sn(d.animation), a),
            timings: m,
            options: null
          }
        }
      }
      class Yi {
        constructor(d) {
          this.errors = d, this.queryCount = 0, this.depCount = 0, this.currentTransition = null, this
            .currentQuery = null, this.currentQuerySelector = null, this.currentAnimateTimings = null, this
            .currentTime = 0, this.collectedStyles = new Map, this.options = null, this
            .unsupportedCSSPropertiesFound = new Set
        }
      }

      function en(C) {
        return C ? (C = {
          ...C
        }).params && (C.params = function Cr(C) {
          return C ? {
            ...C
          } : null
        }(C.params)) : C = {}, C
      }

      function ci(C, d, a) {
        return {
          duration: C,
          delay: d,
          easing: a
        }
      }

      function pt(C, d, a, m, b, R, j = null, q = !1) {
        return {
          type: 1,
          element: C,
          keyframes: d,
          preStyleProps: a,
          postStyleProps: m,
          duration: b,
          delay: R,
          totalTime: b + R,
          easing: j,
          subTimeline: q
        }
      }
      class jr {
        constructor() {
          this._map = new Map
        }
        get(d) {
          return this._map.get(d) || []
        }
        append(d, a) {
          let m = this._map.get(d);
          m || this._map.set(d, m = []), m.push(...a)
        }
        has(d) {
          return this._map.has(d)
        }
        clear() {
          this._map.clear()
        }
      }
      const Ri = new RegExp(":enter", "g"),
        Ts = new RegExp(":leave", "g");

      function Lr(C, d, a, m, b, R = new Map, j = new Map, q, de, fe = []) {
        return (new er).buildKeyframes(C, d, a, m, b, R, j, q, de, fe)
      }
      class er {
        buildKeyframes(d, a, m, b, R, j, q, de, fe, $e = []) {
          fe = fe || new jr;
          const Ge = new ui(d, a, fe, b, R, $e, []);
          Ge.options = de;
          const We = de.delay ? pe(de.delay) : 0;
          Ge.currentTimeline.delayNextStep(We), Ge.currentTimeline.setStyles([j], null, Ge.errors, de), gn(this,
            m, Ge);
          const Mt = Ge.timelines.filter(gt => gt.containsAnimation());
          if (Mt.length && q.size) {
            let gt;
            for (let Dt = Mt.length - 1; Dt >= 0; Dt--) {
              const ft = Mt[Dt];
              if (ft.element === a) {
                gt = ft;
                break
              }
            }
            gt && !gt.allowOnlyTimelineStyles() && gt.setStyles([q], null, Ge.errors, de)
          }
          return Mt.length ? Mt.map(gt => gt.buildKeyframes()) : [pt(a, [], [], [], 0, We, "", !1)]
        }
        visitTrigger(d, a) {}
        visitState(d, a) {}
        visitTransition(d, a) {}
        visitAnimateChild(d, a) {
          const m = a.subInstructions.get(a.element);
          if (m) {
            const b = a.createSubContext(d.options),
              R = a.currentTimeline.currentTime,
              j = this._visitSubInstructions(m, b, b.options);
            R != j && a.transformIntoNewTimeline(j)
          }
          a.previousNode = d
        }
        visitAnimateRef(d, a) {
          const m = a.createSubContext(d.options);
          m.transformIntoNewTimeline(), this._applyAnimationRefDelays([d.options, d.animation.options], a, m),
            this.visitReference(d.animation, m), a.transformIntoNewTimeline(m.currentTimeline.currentTime), a
            .previousNode = d
        }
        _applyAnimationRefDelays(d, a, m) {
          for (const b of d) {
            const R = b?.delay;
            if (R) {
              const j = "number" == typeof R ? R : pe(kt(R, b?.params ?? {}, a.errors));
              m.delayNextStep(j)
            }
          }
        }
        _visitSubInstructions(d, a, m) {
          let R = a.currentTimeline.currentTime;
          const j = null != m.duration ? pe(m.duration) : null,
            q = null != m.delay ? pe(m.delay) : null;
          return 0 !== j && d.forEach(de => {
            const fe = a.appendInstructionToTimeline(de, j, q);
            R = Math.max(R, fe.duration + fe.delay)
          }), R
        }
        visitReference(d, a) {
          a.updateOptions(d.options, !0), gn(this, d.animation, a), a.previousNode = d
        }
        visitSequence(d, a) {
          const m = a.subContextCount;
          let b = a;
          const R = d.options;
          if (R && (R.params || R.delay) && (b = a.createSubContext(R), b.transformIntoNewTimeline(), null != R
              .delay)) {
            b.previousNode.type == U.If.Style && (b.currentTimeline.snapshotCurrentStyles(), b.previousNode =
              bi);
            const j = pe(R.delay);
            b.delayNextStep(j)
          }
          d.steps.length && (d.steps.forEach(j => gn(this, j, b)), b.currentTimeline.applyStylesToKeyframe(), b
            .subContextCount > m && b.transformIntoNewTimeline()), a.previousNode = d
        }
        visitGroup(d, a) {
          const m = [];
          let b = a.currentTimeline.currentTime;
          const R = d.options && d.options.delay ? pe(d.options.delay) : 0;
          d.steps.forEach(j => {
              const q = a.createSubContext(d.options);
              R && q.delayNextStep(R), gn(this, j, q), b = Math.max(b, q.currentTimeline.currentTime), m.push(
                q.currentTimeline)
            }), m.forEach(j => a.currentTimeline.mergeTimelineCollectedStyles(j)), a.transformIntoNewTimeline(
            b), a.previousNode = d
        }
        _visitTiming(d, a) {
          if (d.dynamic) {
            const m = d.strValue;
            return He(a.params ? kt(m, a.params, a.errors) : m, a.errors)
          }
          return {
            duration: d.duration,
            delay: d.delay,
            easing: d.easing
          }
        }
        visitAnimate(d, a) {
          const m = a.currentAnimateTimings = this._visitTiming(d.timings, a),
            b = a.currentTimeline;
          m.delay && (a.incrementTime(m.delay), b.snapshotCurrentStyles());
          const R = d.style;
          R.type == U.If.Keyframes ? this.visitKeyframes(R, a) : (a.incrementTime(m.duration), this.visitStyle(
            R, a), b.applyStylesToKeyframe()), a.currentAnimateTimings = null, a.previousNode = d
        }
        visitStyle(d, a) {
          const m = a.currentTimeline,
            b = a.currentAnimateTimings;
          !b && m.hasCurrentStyleProperties() && m.forwardFrame();
          const R = b && b.easing || d.easing;
          d.isEmptyStep ? m.applyEmptyStep(R) : m.setStyles(d.styles, R, a.errors, a.options), a.previousNode =
            d
        }
        visitKeyframes(d, a) {
          const m = a.currentAnimateTimings,
            b = a.currentTimeline.duration,
            R = m.duration,
            q = a.createSubContext().currentTimeline;
          q.easing = m.easing, d.styles.forEach(de => {
              q.forwardTime((de.offset || 0) * R), q.setStyles(de.styles, de.easing, a.errors, a.options), q
                .applyStylesToKeyframe()
            }), a.currentTimeline.mergeTimelineCollectedStyles(q), a.transformIntoNewTimeline(b + R), a
            .previousNode = d
        }
        visitQuery(d, a) {
          const m = a.currentTimeline.currentTime,
            b = d.options || {},
            R = b.delay ? pe(b.delay) : 0;
          R && (a.previousNode.type === U.If.Style || 0 == m && a.currentTimeline
          .hasCurrentStyleProperties()) && (a.currentTimeline.snapshotCurrentStyles(), a.previousNode = bi);
          let j = m;
          const q = a.invokeQuery(d.selector, d.originalSelector, d.limit, d.includeSelf, !!b.optional, a
            .errors);
          a.currentQueryTotal = q.length;
          let de = null;
          q.forEach((fe, $e) => {
              a.currentQueryIndex = $e;
              const Ge = a.createSubContext(d.options, fe);
              R && Ge.delayNextStep(R), fe === a.element && (de = Ge.currentTimeline), gn(this, d.animation,
                Ge), Ge.currentTimeline.applyStylesToKeyframe(), j = Math.max(j, Ge.currentTimeline
                .currentTime)
            }), a.currentQueryIndex = 0, a.currentQueryTotal = 0, a.transformIntoNewTimeline(j), de && (a
              .currentTimeline.mergeTimelineCollectedStyles(de), a.currentTimeline.snapshotCurrentStyles()), a
            .previousNode = d
        }
        visitStagger(d, a) {
          const m = a.parentContext,
            b = a.currentTimeline,
            R = d.timings,
            j = Math.abs(R.duration),
            q = j * (a.currentQueryTotal - 1);
          let de = j * a.currentQueryIndex;
          switch (R.duration < 0 ? "reverse" : R.easing) {
            case "reverse":
              de = q - de;
              break;
            case "full":
              de = m.currentStaggerTime
          }
          const $e = a.currentTimeline;
          de && $e.delayNextStep(de);
          const Ge = $e.currentTime;
          gn(this, d.animation, a), a.previousNode = d, m.currentStaggerTime = b.currentTime - Ge + (b
            .startTime - m.currentTimeline.startTime)
        }
      }
      const bi = {};
      class ui {
        constructor(d, a, m, b, R, j, q, de) {
          this._driver = d, this.element = a, this.subInstructions = m, this._enterClassName = b, this
            ._leaveClassName = R, this.errors = j, this.timelines = q, this.parentContext = null, this
            .currentAnimateTimings = null, this.previousNode = bi, this.subContextCount = 0, this.options = {},
            this.currentQueryIndex = 0, this.currentQueryTotal = 0, this.currentStaggerTime = 0, this
            .currentTimeline = de || new Pi(this._driver, a, 0), q.push(this.currentTimeline)
        }
        get params() {
          return this.options.params
        }
        updateOptions(d, a) {
          if (!d) return;
          const m = d;
          let b = this.options;
          null != m.duration && (b.duration = pe(m.duration)), null != m.delay && (b.delay = pe(m.delay));
          const R = m.params;
          if (R) {
            let j = b.params;
            j || (j = this.options.params = {}), Object.keys(R).forEach(q => {
              (!a || !j.hasOwnProperty(q)) && (j[q] = kt(R[q], j, this.errors))
            })
          }
        }
        _copyOptions() {
          const d = {};
          if (this.options) {
            const a = this.options.params;
            if (a) {
              const m = d.params = {};
              Object.keys(a).forEach(b => {
                m[b] = a[b]
              })
            }
          }
          return d
        }
        createSubContext(d = null, a, m) {
          const b = a || this.element,
            R = new ui(this._driver, b, this.subInstructions, this._enterClassName, this._leaveClassName, this
              .errors, this.timelines, this.currentTimeline.fork(b, m || 0));
          return R.previousNode = this.previousNode, R.currentAnimateTimings = this.currentAnimateTimings, R
            .options = this._copyOptions(), R.updateOptions(d), R.currentQueryIndex = this.currentQueryIndex, R
            .currentQueryTotal = this.currentQueryTotal, R.parentContext = this, this.subContextCount++, R
        }
        transformIntoNewTimeline(d) {
          return this.previousNode = bi, this.currentTimeline = this.currentTimeline.fork(this.element, d), this
            .timelines.push(this.currentTimeline), this.currentTimeline
        }
        appendInstructionToTimeline(d, a, m) {
          const b = {
              duration: a ?? d.duration,
              delay: this.currentTimeline.currentTime + (m ?? 0) + d.delay,
              easing: ""
            },
            R = new Zr(this._driver, d.element, d.keyframes, d.preStyleProps, d.postStyleProps, b, d
              .stretchStartingKeyframe);
          return this.timelines.push(R), b
        }
        incrementTime(d) {
          this.currentTimeline.forwardTime(this.currentTimeline.duration + d)
        }
        delayNextStep(d) {
          d > 0 && this.currentTimeline.delayNextStep(d)
        }
        invokeQuery(d, a, m, b, R, j) {
          let q = [];
          if (b && q.push(this.element), d.length > 0) {
            d = (d = d.replace(Ri, "." + this._enterClassName)).replace(Ts, "." + this._leaveClassName);
            let fe = this._driver.query(this.element, d, 1 != m);
            0 !== m && (fe = m < 0 ? fe.slice(fe.length + m, fe.length) : fe.slice(0, m)), q.push(...fe)
          }
          return !R && 0 == q.length && j.push(function zr(C) {
            return new c.wOt(3014, !1)
          }()), q
        }
      }
      class Pi {
        constructor(d, a, m, b) {
          this._driver = d, this.element = a, this.startTime = m, this._elementTimelineStylesLookup = b, this
            .duration = 0, this.easing = null, this._previousKeyframe = new Map, this._currentKeyframe =
            new Map, this._keyframes = new Map, this._styleSummary = new Map, this._localTimelineStyles =
            new Map, this._pendingStyles = new Map, this._backFill = new Map, this._currentEmptyStepKeyframe =
            null, this._elementTimelineStylesLookup || (this._elementTimelineStylesLookup = new Map), this
            ._globalTimelineStyles = this._elementTimelineStylesLookup.get(a), this._globalTimelineStyles || (
              this._globalTimelineStyles = this._localTimelineStyles, this._elementTimelineStylesLookup.set(a,
                this._localTimelineStyles)), this._loadKeyframe()
        }
        containsAnimation() {
          switch (this._keyframes.size) {
            case 0:
              return !1;
            case 1:
              return this.hasCurrentStyleProperties();
            default:
              return !0
          }
        }
        hasCurrentStyleProperties() {
          return this._currentKeyframe.size > 0
        }
        get currentTime() {
          return this.startTime + this.duration
        }
        delayNextStep(d) {
          const a = 1 === this._keyframes.size && this._pendingStyles.size;
          this.duration || a ? (this.forwardTime(this.currentTime + d), a && this.snapshotCurrentStyles()) :
            this.startTime += d
        }
        fork(d, a) {
          return this.applyStylesToKeyframe(), new Pi(this._driver, d, a || this.currentTime, this
            ._elementTimelineStylesLookup)
        }
        _loadKeyframe() {
          this._currentKeyframe && (this._previousKeyframe = this._currentKeyframe), this._currentKeyframe =
            this._keyframes.get(this.duration), this._currentKeyframe || (this._currentKeyframe = new Map, this
              ._keyframes.set(this.duration, this._currentKeyframe))
        }
        forwardFrame() {
          this.duration += 1, this._loadKeyframe()
        }
        forwardTime(d) {
          this.applyStylesToKeyframe(), this.duration = d, this._loadKeyframe()
        }
        _updateStyle(d, a) {
          this._localTimelineStyles.set(d, a), this._globalTimelineStyles.set(d, a), this._styleSummary.set(d, {
            time: this.currentTime,
            value: a
          })
        }
        allowOnlyTimelineStyles() {
          return this._currentEmptyStepKeyframe !== this._currentKeyframe
        }
        applyEmptyStep(d) {
          d && this._previousKeyframe.set("easing", d);
          for (let [a, m] of this._globalTimelineStyles) this._backFill.set(a, m || U.kp), this._currentKeyframe
            .set(a, U.kp);
          this._currentEmptyStepKeyframe = this._currentKeyframe
        }
        setStyles(d, a, m, b) {
          a && this._previousKeyframe.set("easing", a);
          const R = b && b.params || {},
            j = function Bn(C, d) {
              const a = new Map;
              let m;
              return C.forEach(b => {
                if ("*" === b) {
                  m ??= d.keys();
                  for (let R of m) a.set(R, U.kp)
                } else
                  for (let [R, j] of b) a.set(R, j)
              }), a
            }(d, this._globalTimelineStyles);
          for (let [q, de] of j) {
            const fe = kt(de, R, m);
            this._pendingStyles.set(q, fe), this._localTimelineStyles.has(q) || this._backFill.set(q, this
              ._globalTimelineStyles.get(q) ?? U.kp), this._updateStyle(q, fe)
          }
        }
        applyStylesToKeyframe() {
          0 != this._pendingStyles.size && (this._pendingStyles.forEach((d, a) => {
            this._currentKeyframe.set(a, d)
          }), this._pendingStyles.clear(), this._localTimelineStyles.forEach((d, a) => {
            this._currentKeyframe.has(a) || this._currentKeyframe.set(a, d)
          }))
        }
        snapshotCurrentStyles() {
          for (let [d, a] of this._localTimelineStyles) this._pendingStyles.set(d, a), this._updateStyle(d, a)
        }
        getFinalKeyframe() {
          return this._keyframes.get(this.duration)
        }
        get properties() {
          const d = [];
          for (let a in this._currentKeyframe) d.push(a);
          return d
        }
        mergeTimelineCollectedStyles(d) {
          d._styleSummary.forEach((a, m) => {
            const b = this._styleSummary.get(m);
            (!b || a.time > b.time) && this._updateStyle(m, a.value)
          })
        }
        buildKeyframes() {
          this.applyStylesToKeyframe();
          const d = new Set,
            a = new Set,
            m = 1 === this._keyframes.size && 0 === this.duration;
          let b = [];
          this._keyframes.forEach((q, de) => {
            const fe = new Map([...this._backFill, ...q]);
            fe.forEach(($e, Ge) => {
              $e === U.FX ? d.add(Ge) : $e === U.kp && a.add(Ge)
            }), m || fe.set("offset", de / this.duration), b.push(fe)
          });
          const R = [...d.values()],
            j = [...a.values()];
          if (m) {
            const q = b[0],
              de = new Map(q);
            q.set("offset", 0), de.set("offset", 1), b = [q, de]
          }
          return pt(this.element, b, R, j, this.duration, this.startTime, this.easing, !1)
        }
      }
      class Zr extends Pi {
        constructor(d, a, m, b, R, j, q = !1) {
          super(d, a, j.delay), this.keyframes = m, this.preStyleProps = b, this.postStyleProps = R, this
            ._stretchStartingKeyframe = q, this.timings = {
              duration: j.duration,
              delay: j.delay,
              easing: j.easing
            }
        }
        containsAnimation() {
          return this.keyframes.length > 1
        }
        buildKeyframes() {
          let d = this.keyframes,
            {
              delay: a,
              duration: m,
              easing: b
            } = this.timings;
          if (this._stretchStartingKeyframe && a) {
            const R = [],
              j = m + a,
              q = a / j,
              de = new Map(d[0]);
            de.set("offset", 0), R.push(de);
            const fe = new Map(d[0]);
            fe.set("offset", Zi(q)), R.push(fe);
            const $e = d.length - 1;
            for (let Ge = 1; Ge <= $e; Ge++) {
              let We = new Map(d[Ge]);
              const Mt = We.get("offset");
              We.set("offset", Zi((a + Mt * m) / j)), R.push(We)
            }
            m = j, a = 0, b = "", d = R
          }
          return pt(this.element, d, this.preStyleProps, this.postStyleProps, m, a, b, !0)
        }
      }

      function Zi(C, d = 3) {
        const a = Math.pow(10, d - 1);
        return Math.round(C * a) / a
      }

      function br(C, d, a, m, b, R, j, q, de, fe, $e, Ge, We) {
        return {
          type: 0,
          element: C,
          triggerName: d,
          isRemovalTransition: b,
          fromState: a,
          fromStyles: R,
          toState: m,
          toStyles: j,
          timelines: q,
          queriedElements: de,
          preStyleProps: fe,
          postStyleProps: $e,
          totalTime: Ge,
          errors: We
        }
      }
      const di = {};
      class fi {
        constructor(d, a, m) {
          this._triggerName = d, this.ast = a, this._stateStyles = m
        }
        match(d, a, m, b) {
          return function os(C, d, a, m, b) {
            return C.some(R => R(d, a, m, b))
          }(this.ast.matchers, d, a, m, b)
        }
        buildStyles(d, a, m) {
          let b = this._stateStyles.get("*");
          return void 0 !== d && (b = this._stateStyles.get(d?.toString()) || b), b ? b.buildStyles(a, m) :
            new Map
        }
        build(d, a, m, b, R, j, q, de, fe, $e) {
          const Ge = [],
            We = this.ast.options && this.ast.options.params || di,
            gt = this.buildStyles(m, q && q.params || di, Ge),
            Dt = de && de.params || di,
            ft = this.buildStyles(b, Dt, Ge),
            Tn = new Set,
            An = new Map,
            _n = new Map,
            Fn = "void" === b,
            ps = {
              params: Fi(Dt, We),
              delay: this.ast.options?.delay
            },
            Xn = $e ? [] : Lr(d, a, this.ast.animation, R, j, gt, ft, ps, fe, Ge);
          let ir = 0;
          return Xn.forEach(Wn => {
            ir = Math.max(Wn.duration + Wn.delay, ir)
          }), Ge.length ? br(a, this._triggerName, m, b, Fn, gt, ft, [], [], An, _n, ir, Ge) : (Xn.forEach(
            Wn => {
              const yt = Wn.element,
                Si = Wt(An, yt, new Set);
              Wn.preStyleProps.forEach(Mr => Si.add(Mr));
              const gs = Wt(_n, yt, new Set);
              Wn.postStyleProps.forEach(Mr => gs.add(Mr)), yt !== a && Tn.add(yt)
            }), br(a, this._triggerName, m, b, Fn, gt, ft, Xn, [...Tn.values()], An, _n, ir))
        }
      }

      function Fi(C, d) {
        const a = {
          ...d
        };
        return Object.entries(C).forEach(([m, b]) => {
          null != b && (a[m] = b)
        }), a
      }
      class xi {
        constructor(d, a, m) {
          this.styles = d, this.defaultParams = a, this.normalizer = m
        }
        buildStyles(d, a) {
          const m = new Map,
            b = Fi(d, this.defaultParams);
          return this.styles.styles.forEach(R => {
            "string" != typeof R && R.forEach((j, q) => {
              j && (j = kt(j, b, a));
              const de = this.normalizer.normalizePropertyName(q, a);
              j = this.normalizer.normalizeStyleValue(q, de, j, a), m.set(q, j)
            })
          }), m
        }
      }
      class tr {
        constructor(d, a, m) {
          this.name = d, this.ast = a, this._normalizer = m, this.transitionFactories = [], this.states =
            new Map, a.states.forEach(b => {
              this.states.set(b.name, new xi(b.style, b.options && b.options.params || {}, m))
            }), wr(this.states, "true", "1"), wr(this.states, "false", "0"), a.transitions.forEach(b => {
              this.transitionFactories.push(new fi(d, b, this.states))
            }), this.fallbackTransition = function Li(C, d, a) {
              return new fi(C, {
                type: U.If.Transition,
                animation: {
                  type: U.If.Sequence,
                  steps: [],
                  options: null
                },
                matchers: [(j, q) => !0],
                options: null,
                queryCount: 0,
                depCount: 0
              }, d)
            }(d, this.states)
        }
        get containsQueries() {
          return this.ast.queryCount > 0
        }
        matchTransition(d, a, m, b) {
          return this.transitionFactories.find(j => j.match(d, a, m, b)) || null
        }
        matchStyles(d, a, m) {
          return this.fallbackTransition.buildStyles(d, a, m)
        }
      }

      function wr(C, d, a) {
        C.has(d) ? C.has(a) || C.set(a, C.get(d)) : C.has(a) && C.set(d, C.get(a))
      }
      const Ks = new jr;
      class co {
        constructor(d, a, m) {
          this.bodyNode = d, this._driver = a, this._normalizer = m, this._animations = new Map, this
            ._playersById = new Map, this.players = []
        }
        register(d, a) {
          const m = [],
            R = is(this._driver, a, m, []);
          if (m.length) throw function Kr(C) {
            return new c.wOt(3503, !1)
          }();
          this._animations.set(d, R)
        }
        _buildPlayer(d, a, m) {
          const b = d.element,
            R = Oe(this._normalizer, d.keyframes, a, m);
          return this._driver.animate(b, R, d.duration, d.delay, d.easing, [], !0)
        }
        create(d, a, m = {}) {
          const b = [],
            R = this._animations.get(d);
          let j;
          const q = new Map;
          if (R ? (j = Lr(this._driver, a, R, ai, Xr, new Map, new Map, m, Ks, b), j.forEach($e => {
              const Ge = Wt(q, $e.element, new Map);
              $e.postStyleProps.forEach(We => Ge.set(We, null))
            })) : (b.push(function zt() {
              return new c.wOt(3300, !1)
            }()), j = []), b.length) throw function Pt(C) {
            return new c.wOt(3504, !1)
          }();
          q.forEach(($e, Ge) => {
            $e.forEach((We, Mt) => {
              $e.set(Mt, this._driver.computeStyle(Ge, Mt, U.kp))
            })
          });
          const fe = J(j.map($e => {
            const Ge = q.get($e.element);
            return this._buildPlayer($e, new Map, Ge)
          }));
          return this._playersById.set(d, fe), fe.onDestroy(() => this.destroy(d)), this.players.push(fe), fe
        }
        destroy(d) {
          const a = this._getPlayer(d);
          a.destroy(), this._playersById.delete(d);
          const m = this.players.indexOf(a);
          m >= 0 && this.players.splice(m, 1)
        }
        _getPlayer(d) {
          const a = this._playersById.get(d);
          if (!a) throw function _r(C) {
            return new c.wOt(3301, !1)
          }();
          return a
        }
        listen(d, a, m, b) {
          const R = qt(a, "", "", "");
          return Qe(this._getPlayer(d), m, R, b), () => {}
        }
        command(d, a, m, b) {
          if ("register" == m) return void this.register(d, b[0]);
          if ("create" == m) return void this.create(d, a, b[0] || {});
          const R = this._getPlayer(d);
          switch (m) {
            case "play":
              R.play();
              break;
            case "pause":
              R.pause();
              break;
            case "reset":
              R.reset();
              break;
            case "restart":
              R.restart();
              break;
            case "finish":
              R.finish();
              break;
            case "init":
              R.init();
              break;
            case "setPosition":
              R.setPosition(parseFloat(b[0]));
              break;
            case "destroy":
              this.destroy(d)
          }
        }
      }
      const nr = "ng-animate-queued",
        hi = "ng-animate-disabled",
        Ns = [],
        pi = {
          namespaceId: "",
          setForRemoval: !1,
          setForMove: !1,
          hasAnimation: !1,
          removedBeforeQueried: !1
        },
        ki = {
          namespaceId: "",
          setForMove: !1,
          setForRemoval: !1,
          hasAnimation: !1,
          removedBeforeQueried: !0
        },
        Sr = "__ng_removed";
      class Vi {
        get params() {
          return this.options.params
        }
        constructor(d, a = "") {
          this.namespaceId = a;
          const m = d && d.hasOwnProperty("value");
          if (this.value = function Rt(C) {
              return C ?? null
            }(m ? d.value : d), m) {
            const {
              value: R,
              ...j
            } = d;
            this.options = j
          } else this.options = {};
          this.options.params || (this.options.params = {})
        }
        absorbOptions(d) {
          const a = d.params;
          if (a) {
            const m = this.options.params;
            Object.keys(a).forEach(b => {
              null == m[b] && (m[b] = a[b])
            })
          }
        }
      }
      const I = "void",
        T = new Vi(I);
      class _ {
        constructor(d, a, m) {
          this.id = d, this.hostElement = a, this._engine = m, this.players = [], this._triggers = new Map, this
            ._queue = [], this._elementListeners = new Map, this._hostClassName = "ng-tns-" + d, $n(a, this
              ._hostClassName)
        }
        listen(d, a, m, b) {
          if (!this._triggers.has(a)) throw function Jt(C, d) {
            return new c.wOt(3302, !1)
          }();
          if (null == m || 0 == m.length) throw function Kn(C) {
            return new c.wOt(3303, !1)
          }();
          if (! function gi(C) {
              return "start" == C || "done" == C
            }(m)) throw function ri(C, d) {
            return new c.wOt(3400, !1)
          }();
          const R = Wt(this._elementListeners, d, []),
            j = {
              name: a,
              phase: m,
              callback: b
            };
          R.push(j);
          const q = Wt(this._engine.statesByElement, d, new Map);
          return q.has(a) || ($n(d, B), $n(d, B + "-" + a), q.set(a, T)), () => {
            this._engine.afterFlush(() => {
              const de = R.indexOf(j);
              de >= 0 && R.splice(de, 1), this._triggers.has(a) || q.delete(a)
            })
          }
        }
        register(d, a) {
          return !this._triggers.has(d) && (this._triggers.set(d, a), !0)
        }
        _getTrigger(d) {
          const a = this._triggers.get(d);
          if (!a) throw function Di(C) {
            return new c.wOt(3401, !1)
          }();
          return a
        }
        trigger(d, a, m, b = !0) {
          const R = this._getTrigger(a),
            j = new Y(this.id, a, d);
          let q = this._engine.statesByElement.get(d);
          q || ($n(d, B), $n(d, B + "-" + a), this._engine.statesByElement.set(d, q = new Map));
          let de = q.get(a);
          const fe = new Vi(m, this.id);
          if (!(m && m.hasOwnProperty("value")) && de && fe.absorbOptions(de.options), q.set(a, fe), de || (de =
              T), fe.value !== I && de.value === fe.value) {
            if (! function ea(C, d) {
                const a = Object.keys(C),
                  m = Object.keys(d);
                if (a.length != m.length) return !1;
                for (let b = 0; b < a.length; b++) {
                  const R = a[b];
                  if (!d.hasOwnProperty(R) || C[R] !== d[R]) return !1
                }
                return !0
              }(de.params, fe.params)) {
              const Dt = [],
                ft = R.matchStyles(de.value, de.params, Dt),
                Tn = R.matchStyles(fe.value, fe.params, Dt);
              Dt.length ? this._engine.reportError(Dt) : this._engine.afterFlush(() => {
                Ft(d, ft), Xt(d, Tn)
              })
            }
            return
          }
          const We = Wt(this._engine.playersByElement, d, []);
          We.forEach(Dt => {
            Dt.namespaceId == this.id && Dt.triggerName == a && Dt.queued && Dt.destroy()
          });
          let Mt = R.matchTransition(de.value, fe.value, d, fe.params),
            gt = !1;
          if (!Mt) {
            if (!b) return;
            Mt = R.fallbackTransition, gt = !0
          }
          return this._engine.totalQueuedPlayers++, this._queue.push({
            element: d,
            triggerName: a,
            transition: Mt,
            fromState: de,
            toState: fe,
            player: j,
            isFallbackTransition: gt
          }), gt || ($n(d, nr), j.onStart(() => {
            Ji(d, nr)
          })), j.onDone(() => {
            let Dt = this.players.indexOf(j);
            Dt >= 0 && this.players.splice(Dt, 1);
            const ft = this._engine.playersByElement.get(d);
            if (ft) {
              let Tn = ft.indexOf(j);
              Tn >= 0 && ft.splice(Tn, 1)
            }
          }), this.players.push(j), We.push(j), j
        }
        deregister(d) {
          this._triggers.delete(d), this._engine.statesByElement.forEach(a => a.delete(d)), this
            ._elementListeners.forEach((a, m) => {
              this._elementListeners.set(m, a.filter(b => b.name != d))
            })
        }
        clearElementCache(d) {
          this._engine.statesByElement.delete(d), this._elementListeners.delete(d);
          const a = this._engine.playersByElement.get(d);
          a && (a.forEach(m => m.destroy()), this._engine.playersByElement.delete(d))
        }
        _signalRemovalForInnerTriggers(d, a) {
          const m = this._engine.driver.query(d, z, !0);
          m.forEach(b => {
            if (b[Sr]) return;
            const R = this._engine.fetchNamespacesByElement(b);
            R.size ? R.forEach(j => j.triggerLeaveAnimation(b, a, !1, !0)) : this.clearElementCache(b)
          }), this._engine.afterFlushAnimationsDone(() => m.forEach(b => this.clearElementCache(b)))
        }
        triggerLeaveAnimation(d, a, m, b) {
          const R = this._engine.statesByElement.get(d),
            j = new Map;
          if (R) {
            const q = [];
            if (R.forEach((de, fe) => {
                if (j.set(fe, de.value), this._triggers.has(fe)) {
                  const $e = this.trigger(d, fe, I, b);
                  $e && q.push($e)
                }
              }), q.length) return this._engine.markElementAsRemoved(this.id, d, !0, a, j), m && J(q).onDone(
            () => this._engine.processLeaveNode(d)), !0
          }
          return !1
        }
        prepareLeaveAnimationListeners(d) {
          const a = this._elementListeners.get(d),
            m = this._engine.statesByElement.get(d);
          if (a && m) {
            const b = new Set;
            a.forEach(R => {
              const j = R.name;
              if (b.has(j)) return;
              b.add(j);
              const de = this._triggers.get(j).fallbackTransition,
                fe = m.get(j) || T,
                $e = new Vi(I),
                Ge = new Y(this.id, j, d);
              this._engine.totalQueuedPlayers++, this._queue.push({
                element: d,
                triggerName: j,
                transition: de,
                fromState: fe,
                toState: $e,
                player: Ge,
                isFallbackTransition: !0
              })
            })
          }
        }
        removeNode(d, a) {
          const m = this._engine;
          if (d.childElementCount && this._signalRemovalForInnerTriggers(d, a), this.triggerLeaveAnimation(d, a,
              !0)) return;
          let b = !1;
          if (m.totalAnimations) {
            const R = m.players.length ? m.playersByQueriedElement.get(d) : [];
            if (R && R.length) b = !0;
            else {
              let j = d;
              for (; j = j.parentNode;)
                if (m.statesByElement.get(j)) {
                  b = !0;
                  break
                }
            }
          }
          if (this.prepareLeaveAnimationListeners(d), b) m.markElementAsRemoved(this.id, d, !1, a);
          else {
            const R = d[Sr];
            (!R || R === pi) && (m.afterFlush(() => this.clearElementCache(d)), m.destroyInnerAnimations(d), m
              ._onRemovalComplete(d, a))
          }
        }
        insertNode(d, a) {
          $n(d, this._hostClassName)
        }
        drainQueuedTransitions(d) {
          const a = [];
          return this._queue.forEach(m => {
            const b = m.player;
            if (b.destroyed) return;
            const R = m.element,
              j = this._elementListeners.get(R);
            j && j.forEach(q => {
              if (q.name == m.triggerName) {
                const de = qt(R, m.triggerName, m.fromState.value, m.toState.value);
                de._data = d, Qe(m.player, q.phase, de, q.callback)
              }
            }), b.markedForDestroy ? this._engine.afterFlush(() => {
              b.destroy()
            }) : a.push(m)
          }), this._queue = [], a.sort((m, b) => {
            const R = m.transition.ast.depCount,
              j = b.transition.ast.depCount;
            return 0 == R || 0 == j ? R - j : this._engine.driver.containsElement(m.element, b.element) ?
              1 : -1
          })
        }
        destroy(d) {
          this.players.forEach(a => a.destroy()), this._signalRemovalForInnerTriggers(this.hostElement, d)
        }
      }
      class F {
        _onRemovalComplete(d, a) {
          this.onRemovalComplete(d, a)
        }
        constructor(d, a, m, b) {
          this.bodyNode = d, this.driver = a, this._normalizer = m, this.scheduler = b, this.players = [], this
            .newHostElements = new Map, this.playersByElement = new Map, this.playersByQueriedElement = new Map,
            this.statesByElement = new Map, this.disabledNodes = new Set, this.totalAnimations = 0, this
            .totalQueuedPlayers = 0, this._namespaceLookup = {}, this._namespaceList = [], this._flushFns = [],
            this._whenQuietFns = [], this.namespacesByHostElement = new Map, this.collectedEnterElements = [],
            this.collectedLeaveElements = [], this.onRemovalComplete = (R, j) => {}
        }
        get queuedPlayers() {
          const d = [];
          return this._namespaceList.forEach(a => {
            a.players.forEach(m => {
              m.queued && d.push(m)
            })
          }), d
        }
        createNamespace(d, a) {
          const m = new _(d, a, this);
          return this.bodyNode && this.driver.containsElement(this.bodyNode, a) ? this._balanceNamespaceList(m,
            a) : (this.newHostElements.set(a, m), this.collectEnterElement(a)), this._namespaceLookup[d] = m
        }
        _balanceNamespaceList(d, a) {
          const m = this._namespaceList,
            b = this.namespacesByHostElement;
          if (m.length - 1 >= 0) {
            let j = !1,
              q = this.driver.getParentElement(a);
            for (; q;) {
              const de = b.get(q);
              if (de) {
                const fe = m.indexOf(de);
                m.splice(fe + 1, 0, d), j = !0;
                break
              }
              q = this.driver.getParentElement(q)
            }
            j || m.unshift(d)
          } else m.push(d);
          return b.set(a, d), d
        }
        register(d, a) {
          let m = this._namespaceLookup[d];
          return m || (m = this.createNamespace(d, a)), m
        }
        registerTrigger(d, a, m) {
          let b = this._namespaceLookup[d];
          b && b.register(a, m) && this.totalAnimations++
        }
        destroy(d, a) {
          d && (this.afterFlush(() => {}), this.afterFlushAnimationsDone(() => {
            const m = this._fetchNamespace(d);
            this.namespacesByHostElement.delete(m.hostElement);
            const b = this._namespaceList.indexOf(m);
            b >= 0 && this._namespaceList.splice(b, 1), m.destroy(a), delete this._namespaceLookup[d]
          }))
        }
        _fetchNamespace(d) {
          return this._namespaceLookup[d]
        }
        fetchNamespacesByElement(d) {
          const a = new Set,
            m = this.statesByElement.get(d);
          if (m)
            for (let b of m.values())
              if (b.namespaceId) {
                const R = this._fetchNamespace(b.namespaceId);
                R && a.add(R)
              } return a
        }
        trigger(d, a, m, b) {
          if (hr(a)) {
            const R = this._fetchNamespace(d);
            if (R) return R.trigger(a, m, b), !0
          }
          return !1
        }
        insertNode(d, a, m, b) {
          if (!hr(a)) return;
          const R = a[Sr];
          if (R && R.setForRemoval) {
            R.setForRemoval = !1, R.setForMove = !0;
            const j = this.collectedLeaveElements.indexOf(a);
            j >= 0 && this.collectedLeaveElements.splice(j, 1)
          }
          if (d) {
            const j = this._fetchNamespace(d);
            j && j.insertNode(a, m)
          }
          b && this.collectEnterElement(a)
        }
        collectEnterElement(d) {
          this.collectedEnterElements.push(d)
        }
        markElementAsDisabled(d, a) {
          a ? this.disabledNodes.has(d) || (this.disabledNodes.add(d), $n(d, hi)) : this.disabledNodes.has(d) &&
            (this.disabledNodes.delete(d), Ji(d, hi))
        }
        removeNode(d, a, m) {
          if (hr(a)) {
            this.scheduler?.notify();
            const b = d ? this._fetchNamespace(d) : null;
            b ? b.removeNode(a, m) : this.markElementAsRemoved(d, a, !1, m);
            const R = this.namespacesByHostElement.get(a);
            R && R.id !== d && R.removeNode(a, m)
          } else this._onRemovalComplete(a, m)
        }
        markElementAsRemoved(d, a, m, b, R) {
          this.collectedLeaveElements.push(a), a[Sr] = {
            namespaceId: d,
            setForRemoval: b,
            hasAnimation: m,
            removedBeforeQueried: !1,
            previousTriggersValues: R
          }
        }
        listen(d, a, m, b, R) {
          return hr(a) ? this._fetchNamespace(d).listen(a, m, b, R) : () => {}
        }
        _buildInstruction(d, a, m, b, R) {
          return d.transition.build(this.driver, d.element, d.fromState.value, d.toState.value, m, b, d
            .fromState.options, d.toState.options, a, R)
        }
        destroyInnerAnimations(d) {
          let a = this.driver.query(d, z, !0);
          a.forEach(m => this.destroyActiveAnimationsForElement(m)), 0 != this.playersByQueriedElement.size && (
            a = this.driver.query(d, Ee, !0), a.forEach(m => this.finishActiveQueriedAnimationOnElement(m)))
        }
        destroyActiveAnimationsForElement(d) {
          const a = this.playersByElement.get(d);
          a && a.forEach(m => {
            m.queued ? m.markedForDestroy = !0 : m.destroy()
          })
        }
        finishActiveQueriedAnimationOnElement(d) {
          const a = this.playersByQueriedElement.get(d);
          a && a.forEach(m => m.finish())
        }
        whenRenderingDone() {
          return new Promise(d => {
            if (this.players.length) return J(this.players).onDone(() => d());
            d()
          })
        }
        processLeaveNode(d) {
          const a = d[Sr];
          if (a && a.setForRemoval) {
            if (d[Sr] = pi, a.namespaceId) {
              this.destroyInnerAnimations(d);
              const m = this._fetchNamespace(a.namespaceId);
              m && m.clearElementCache(d)
            }
            this._onRemovalComplete(d, a.setForRemoval)
          }
          d.classList?.contains(hi) && this.markElementAsDisabled(d, !1), this.driver.query(d,
            ".ng-animate-disabled", !0).forEach(m => {
            this.markElementAsDisabled(m, !1)
          })
        }
        flush(d = -1) {
          let a = [];
          if (this.newHostElements.size && (this.newHostElements.forEach((m, b) => this._balanceNamespaceList(m,
              b)), this.newHostElements.clear()), this.totalAnimations && this.collectedEnterElements.length)
            for (let m = 0; m < this.collectedEnterElements.length; m++) $n(this.collectedEnterElements[m],
              "ng-star-inserted");
          if (this._namespaceList.length && (this.totalQueuedPlayers || this.collectedLeaveElements.length)) {
            const m = [];
            try {
              a = this._flushAnimations(m, d)
            } finally {
              for (let b = 0; b < m.length; b++) m[b]()
            }
          } else
            for (let m = 0; m < this.collectedLeaveElements.length; m++) this.processLeaveNode(this
              .collectedLeaveElements[m]);
          if (this.totalQueuedPlayers = 0, this.collectedEnterElements.length = 0, this.collectedLeaveElements
            .length = 0, this._flushFns.forEach(m => m()), this._flushFns = [], this._whenQuietFns.length) {
            const m = this._whenQuietFns;
            this._whenQuietFns = [], a.length ? J(a).onDone(() => {
              m.forEach(b => b())
            }) : m.forEach(b => b())
          }
        }
        reportError(d) {
          throw function qn(C) {
            return new c.wOt(3402, !1)
          }()
        }
        _flushAnimations(d, a) {
          const m = new jr,
            b = [],
            R = new Map,
            j = [],
            q = new Map,
            de = new Map,
            fe = new Map,
            $e = new Set;
          this.disabledNodes.forEach(st => {
            $e.add(st);
            const tt = this.driver.query(st, ".ng-animate-queued", !0);
            for (let ot = 0; ot < tt.length; ot++) $e.add(tt[ot])
          });
          const Ge = this.bodyNode,
            We = Array.from(this.statesByElement.keys()),
            Mt = Bi(We, this.collectedEnterElements),
            gt = new Map;
          let Dt = 0;
          Mt.forEach((st, tt) => {
            const ot = ai + Dt++;
            gt.set(tt, ot), st.forEach(Kt => $n(Kt, ot))
          });
          const ft = [],
            Tn = new Set,
            An = new Set;
          for (let st = 0; st < this.collectedLeaveElements.length; st++) {
            const tt = this.collectedLeaveElements[st],
              ot = tt[Sr];
            ot && ot.setForRemoval && (ft.push(tt), Tn.add(tt), ot.hasAnimation ? this.driver.query(tt,
              ".ng-star-inserted", !0).forEach(Kt => Tn.add(Kt)) : An.add(tt))
          }
          const _n = new Map,
            Fn = Bi(We, Array.from(Tn));
          Fn.forEach((st, tt) => {
            const ot = Xr + Dt++;
            _n.set(tt, ot), st.forEach(Kt => $n(Kt, ot))
          }), d.push(() => {
            Mt.forEach((st, tt) => {
              const ot = gt.get(tt);
              st.forEach(Kt => Ji(Kt, ot))
            }), Fn.forEach((st, tt) => {
              const ot = _n.get(tt);
              st.forEach(Kt => Ji(Kt, ot))
            }), ft.forEach(st => {
              this.processLeaveNode(st)
            })
          });
          const ps = [],
            Xn = [];
          for (let st = this._namespaceList.length - 1; st >= 0; st--) this._namespaceList[st]
            .drainQueuedTransitions(a).forEach(ot => {
              const Kt = ot.player,
                En = ot.element;
              if (ps.push(Kt), this.collectedEnterElements.length) {
                const gr = En[Sr];
                if (gr && gr.setForMove) {
                  if (gr.previousTriggersValues && gr.previousTriggersValues.has(ot.triggerName)) {
                    const Ls = gr.previousTriggersValues.get(ot.triggerName),
                      Gr = this.statesByElement.get(ot.element);
                    if (Gr && Gr.has(ot.triggerName)) {
                      const Bo = Gr.get(ot.triggerName);
                      Bo.value = Ls, Gr.set(ot.triggerName, Bo)
                    }
                  }
                  return void Kt.destroy()
                }
              }
              const Tr = !Ge || !this.driver.containsElement(Ge, En),
                On = _n.get(En),
                Ii = gt.get(En),
                Ln = this._buildInstruction(ot, m, Ii, On, Tr);
              if (Ln.errors && Ln.errors.length) return void Xn.push(Ln);
              if (Tr) return Kt.onStart(() => Ft(En, Ln.fromStyles)), Kt.onDestroy(() => Xt(En, Ln.toStyles)),
                void b.push(Kt);
              if (ot.isFallbackTransition) return Kt.onStart(() => Ft(En, Ln.fromStyles)), Kt.onDestroy(() =>
                Xt(En, Ln.toStyles)), void b.push(Kt);
              const ko = [];
              Ln.timelines.forEach(gr => {
                gr.stretchStartingKeyframe = !0, this.disabledNodes.has(gr.element) || ko.push(gr)
              }), Ln.timelines = ko, m.append(En, Ln.timelines), j.push({
                instruction: Ln,
                player: Kt,
                element: En
              }), Ln.queriedElements.forEach(gr => Wt(q, gr, []).push(Kt)), Ln.preStyleProps.forEach((gr,
                Ls) => {
                if (gr.size) {
                  let Gr = de.get(Ls);
                  Gr || de.set(Ls, Gr = new Set), gr.forEach((Bo, sa) => Gr.add(sa))
                }
              }), Ln.postStyleProps.forEach((gr, Ls) => {
                let Gr = fe.get(Ls);
                Gr || fe.set(Ls, Gr = new Set), gr.forEach((Bo, sa) => Gr.add(sa))
              })
            });
          if (Xn.length) {
            const st = [];
            Xn.forEach(tt => {
              st.push(function te(C, d) {
                return new c.wOt(3505, !1)
              }())
            }), ps.forEach(tt => tt.destroy()), this.reportError(st)
          }
          const ir = new Map,
            Wn = new Map;
          j.forEach(st => {
            const tt = st.element;
            m.has(tt) && (Wn.set(tt, tt), this._beforeAnimationBuild(st.player.namespaceId, st.instruction,
              ir))
          }), b.forEach(st => {
            const tt = st.element;
            this._getPreviousPlayers(tt, !1, st.namespaceId, st.triggerName, null).forEach(Kt => {
              Wt(ir, tt, []).push(Kt), Kt.destroy()
            })
          });
          const yt = ft.filter(st => Io(st, de, fe)),
            Si = new Map;
          uo(Si, this.driver, An, fe, U.kp).forEach(st => {
            Io(st, de, fe) && yt.push(st)
          });
          const Mr = new Map;
          Mt.forEach((st, tt) => {
            uo(Mr, this.driver, new Set(st), de, U.FX)
          }), yt.forEach(st => {
            const tt = Si.get(st),
              ot = Mr.get(st);
            Si.set(st, new Map([...tt?.entries() ?? [], ...ot?.entries() ?? []]))
          });
          const ms = [],
            pr = [],
            xn = {};
          j.forEach(st => {
            const {
              element: tt,
              player: ot,
              instruction: Kt
            } = st;
            if (m.has(tt)) {
              if ($e.has(tt)) return ot.onDestroy(() => Xt(tt, Kt.toStyles)), ot.disabled = !0, ot
                .overrideTotalTime(Kt.totalTime), void b.push(ot);
              let En = xn;
              if (Wn.size > 1) {
                let On = tt;
                const Ii = [];
                for (; On = On.parentNode;) {
                  const Ln = Wn.get(On);
                  if (Ln) {
                    En = Ln;
                    break
                  }
                  Ii.push(On)
                }
                Ii.forEach(Ln => Wn.set(Ln, En))
              }
              const Tr = this._buildAnimation(ot.namespaceId, Kt, ir, R, Mr, Si);
              if (ot.setRealPlayer(Tr), En === xn) ms.push(ot);
              else {
                const On = this.playersByElement.get(En);
                On && On.length && (ot.parentPlayer = J(On)), b.push(ot)
              }
            } else Ft(tt, Kt.fromStyles), ot.onDestroy(() => Xt(tt, Kt.toStyles)), pr.push(ot), $e.has(
              tt) && b.push(ot)
          }), pr.forEach(st => {
            const tt = R.get(st.element);
            if (tt && tt.length) {
              const ot = J(tt);
              st.setRealPlayer(ot)
            }
          }), b.forEach(st => {
            st.parentPlayer ? st.syncPlayerEvents(st.parentPlayer) : st.destroy()
          });
          for (let st = 0; st < ft.length; st++) {
            const tt = ft[st],
              ot = tt[Sr];
            if (Ji(tt, Xr), ot && ot.hasAnimation) continue;
            let Kt = [];
            if (q.size) {
              let Tr = q.get(tt);
              Tr && Tr.length && Kt.push(...Tr);
              let On = this.driver.query(tt, Ee, !0);
              for (let Ii = 0; Ii < On.length; Ii++) {
                let Ln = q.get(On[Ii]);
                Ln && Ln.length && Kt.push(...Ln)
              }
            }
            const En = Kt.filter(Tr => !Tr.destroyed);
            En.length ? hn(this, tt, En) : this.processLeaveNode(tt)
          }
          return ft.length = 0, ms.forEach(st => {
            this.players.push(st), st.onDone(() => {
              st.destroy();
              const tt = this.players.indexOf(st);
              this.players.splice(tt, 1)
            }), st.play()
          }), ms
        }
        afterFlush(d) {
          this._flushFns.push(d)
        }
        afterFlushAnimationsDone(d) {
          this._whenQuietFns.push(d)
        }
        _getPreviousPlayers(d, a, m, b, R) {
          let j = [];
          if (a) {
            const q = this.playersByQueriedElement.get(d);
            q && (j = q)
          } else {
            const q = this.playersByElement.get(d);
            if (q) {
              const de = !R || R == I;
              q.forEach(fe => {
                fe.queued || !de && fe.triggerName != b || j.push(fe)
              })
            }
          }
          return (m || b) && (j = j.filter(q => !(m && m != q.namespaceId || b && b != q.triggerName))), j
        }
        _beforeAnimationBuild(d, a, m) {
          const R = a.element,
            j = a.isRemovalTransition ? void 0 : d,
            q = a.isRemovalTransition ? void 0 : a.triggerName;
          for (const de of a.timelines) {
            const fe = de.element,
              $e = fe !== R,
              Ge = Wt(m, fe, []);
            this._getPreviousPlayers(fe, $e, j, q, a.toState).forEach(Mt => {
              const gt = Mt.getRealPlayer();
              gt.beforeDestroy && gt.beforeDestroy(), Mt.destroy(), Ge.push(Mt)
            })
          }
          Ft(R, a.fromStyles)
        }
        _buildAnimation(d, a, m, b, R, j) {
          const q = a.triggerName,
            de = a.element,
            fe = [],
            $e = new Set,
            Ge = new Set,
            We = a.timelines.map(gt => {
              const Dt = gt.element;
              $e.add(Dt);
              const ft = Dt[Sr];
              if (ft && ft.removedBeforeQueried) return new U.sf(gt.duration, gt.delay);
              const Tn = Dt !== de,
                An = function Rs(C) {
                  const d = [];
                  return es(C, d), d
                }((m.get(Dt) || Ns).map(ir => ir.getRealPlayer())).filter(ir => !!ir.element && ir.element ===
                  Dt),
                _n = R.get(Dt),
                Fn = j.get(Dt),
                ps = Oe(this._normalizer, gt.keyframes, _n, Fn),
                Xn = this._buildPlayer(gt, ps, An);
              if (gt.subTimeline && b && Ge.add(Dt), Tn) {
                const ir = new Y(d, q, Dt);
                ir.setRealPlayer(Xn), fe.push(ir)
              }
              return Xn
            });
          fe.forEach(gt => {
            Wt(this.playersByQueriedElement, gt.element, []).push(gt), gt.onDone(() => function ut(C, d,
            a) {
              let m = C.get(d);
              if (m) {
                if (m.length) {
                  const b = m.indexOf(a);
                  m.splice(b, 1)
                }
                0 == m.length && C.delete(d)
              }
              return m
            }(this.playersByQueriedElement, gt.element, gt))
          }), $e.forEach(gt => $n(gt, K));
          const Mt = J(We);
          return Mt.onDestroy(() => {
            $e.forEach(gt => Ji(gt, K)), Xt(de, a.toStyles)
          }), Ge.forEach(gt => {
            Wt(b, gt, []).push(Mt)
          }), Mt
        }
        _buildPlayer(d, a, m) {
          return a.length > 0 ? this.driver.animate(d.element, a, d.duration, d.delay, d.easing, m) : new U.sf(d
            .duration, d.delay)
        }
      }
      class Y {
        constructor(d, a, m) {
          this.namespaceId = d, this.triggerName = a, this.element = m, this._player = new U.sf, this
            ._containsRealPlayer = !1, this._queuedCallbacks = new Map, this.destroyed = !1, this.parentPlayer =
            null, this.markedForDestroy = !1, this.disabled = !1, this.queued = !0, this.totalTime = 0
        }
        setRealPlayer(d) {
          this._containsRealPlayer || (this._player = d, this._queuedCallbacks.forEach((a, m) => {
            a.forEach(b => Qe(d, m, void 0, b))
          }), this._queuedCallbacks.clear(), this._containsRealPlayer = !0, this.overrideTotalTime(d
            .totalTime), this.queued = !1)
        }
        getRealPlayer() {
          return this._player
        }
        overrideTotalTime(d) {
          this.totalTime = d
        }
        syncPlayerEvents(d) {
          const a = this._player;
          a.triggerCallback && d.onStart(() => a.triggerCallback("start")), d.onDone(() => this.finish()), d
            .onDestroy(() => this.destroy())
        }
        _queueEvent(d, a) {
          Wt(this._queuedCallbacks, d, []).push(a)
        }
        onDone(d) {
          this.queued && this._queueEvent("done", d), this._player.onDone(d)
        }
        onStart(d) {
          this.queued && this._queueEvent("start", d), this._player.onStart(d)
        }
        onDestroy(d) {
          this.queued && this._queueEvent("destroy", d), this._player.onDestroy(d)
        }
        init() {
          this._player.init()
        }
        hasStarted() {
          return !this.queued && this._player.hasStarted()
        }
        play() {
          !this.queued && this._player.play()
        }
        pause() {
          !this.queued && this._player.pause()
        }
        restart() {
          !this.queued && this._player.restart()
        }
        finish() {
          this._player.finish()
        }
        destroy() {
          this.destroyed = !0, this._player.destroy()
        }
        reset() {
          !this.queued && this._player.reset()
        }
        setPosition(d) {
          this.queued || this._player.setPosition(d)
        }
        getPosition() {
          return this.queued ? 0 : this._player.getPosition()
        }
        triggerCallback(d) {
          const a = this._player;
          a.triggerCallback && a.triggerCallback(d)
        }
      }

      function hr(C) {
        return C && 1 === C.nodeType
      }

      function Qn(C, d) {
        const a = C.style.display;
        return C.style.display = d ?? "none", a
      }

      function uo(C, d, a, m, b) {
        const R = [];
        a.forEach(de => R.push(Qn(de)));
        const j = [];
        m.forEach((de, fe) => {
          const $e = new Map;
          de.forEach(Ge => {
            const We = d.computeStyle(fe, Ge, b);
            $e.set(Ge, We), (!We || 0 == We.length) && (fe[Sr] = ki, j.push(fe))
          }), C.set(fe, $e)
        });
        let q = 0;
        return a.forEach(de => Qn(de, R[q++])), j
      }

      function Bi(C, d) {
        const a = new Map;
        if (C.forEach(q => a.set(q, [])), 0 == d.length) return a;
        const b = new Set(d),
          R = new Map;

        function j(q) {
          if (!q) return 1;
          let de = R.get(q);
          if (de) return de;
          const fe = q.parentNode;
          return de = a.has(fe) ? fe : b.has(fe) ? 1 : j(fe), R.set(q, de), de
        }
        return d.forEach(q => {
          const de = j(q);
          1 !== de && a.get(de).push(q)
        }), a
      }

      function $n(C, d) {
        C.classList?.add(d)
      }

      function Ji(C, d) {
        C.classList?.remove(d)
      }

      function hn(C, d, a) {
        J(a).onDone(() => C.processLeaveNode(d))
      }

      function es(C, d) {
        for (let a = 0; a < C.length; a++) {
          const m = C[a];
          m instanceof U.ui ? es(m.players, d) : d.push(m)
        }
      }

      function Io(C, d, a) {
        const m = a.get(C);
        if (!m) return !1;
        let b = d.get(C);
        return b ? m.forEach(R => b.add(R)) : d.set(C, m), a.delete(C), !0
      }
      class Ps {
        constructor(d, a, m, b) {
          this._driver = a, this._normalizer = m, this._triggerCache = {}, this.onRemovalComplete = (R,
            j) => {}, this._transitionEngine = new F(d.body, a, m, b), this._timelineEngine = new co(d.body, a,
              m), this._transitionEngine.onRemovalComplete = (R, j) => this.onRemovalComplete(R, j)
        }
        registerTrigger(d, a, m, b, R) {
          const j = d + "-" + b;
          let q = this._triggerCache[j];
          if (!q) {
            const de = [],
              $e = is(this._driver, R, de, []);
            if (de.length) throw function ni(C, d) {
              return new c.wOt(3404, !1)
            }();
            q = function As(C, d, a) {
              return new tr(C, d, a)
            }(b, $e, this._normalizer), this._triggerCache[j] = q
          }
          this._transitionEngine.registerTrigger(a, b, q)
        }
        register(d, a) {
          this._transitionEngine.register(d, a)
        }
        destroy(d, a) {
          this._transitionEngine.destroy(d, a)
        }
        onInsert(d, a, m, b) {
          this._transitionEngine.insertNode(d, a, m, b)
        }
        onRemove(d, a, m) {
          this._transitionEngine.removeNode(d, a, m)
        }
        disableAnimations(d, a) {
          this._transitionEngine.markElementAsDisabled(d, a)
        }
        process(d, a, m, b) {
          if ("@" == m.charAt(0)) {
            const [R, j] = bn(m);
            this._timelineEngine.command(R, a, j, b)
          } else this._transitionEngine.trigger(d, a, m, b)
        }
        listen(d, a, m, b, R) {
          if ("@" == m.charAt(0)) {
            const [j, q] = bn(m);
            return this._timelineEngine.listen(j, a, q, R)
          }
          return this._transitionEngine.listen(d, a, m, b, R)
        }
        flush(d = -1) {
          this._transitionEngine.flush(d)
        }
        get players() {
          return [...this._transitionEngine.players, ...this._timelineEngine.players]
        }
        whenRenderingDone() {
          return this._transitionEngine.whenRenderingDone()
        }
        afterFlushAnimationsDone(d) {
          this._transitionEngine.afterFlushAnimationsDone(d)
        }
      }
      class Fs {
        static #e = this.initialStylesByElement = new WeakMap;
        constructor(d, a, m) {
          this._element = d, this._startStyles = a, this._endStyles = m, this._state = 0;
          let b = Fs.initialStylesByElement.get(d);
          b || Fs.initialStylesByElement.set(d, b = new Map), this._initialStyles = b
        }
        start() {
          this._state < 1 && (this._startStyles && Xt(this._element, this._startStyles, this._initialStyles),
            this._state = 1)
        }
        finish() {
          this.start(), this._state < 2 && (Xt(this._element, this._initialStyles), this._endStyles && (Xt(this
            ._element, this._endStyles), this._endStyles = null), this._state = 1)
        }
        destroy() {
          this.finish(), this._state < 3 && (Fs.initialStylesByElement.delete(this._element), this
            ._startStyles && (Ft(this._element, this._startStyles), this._endStyles = null), this
            ._endStyles && (Ft(this._element, this._endStyles), this._endStyles = null), Xt(this._element,
              this._initialStyles), this._state = 3)
        }
      }

      function Qs(C) {
        let d = null;
        return C.forEach((a, m) => {
          (function Xs(C) {
            return "display" === C || "position" === C
          })(m) && (d = d || new Map, d.set(m, a))
        }), d
      }
      class as {
        constructor(d, a, m, b) {
          this.element = d, this.keyframes = a, this.options = m, this._specialStyles = b, this._onDoneFns = [],
            this._onStartFns = [], this._onDestroyFns = [], this._initialized = !1, this._finished = !1, this
            ._started = !1, this._destroyed = !1, this._originalOnDoneFns = [], this._originalOnStartFns = [],
            this.time = 0, this.parentPlayer = null, this.currentSnapshot = new Map, this._duration = m
            .duration, this._delay = m.delay || 0, this.time = this._duration + this._delay
        }
        _onFinish() {
          this._finished || (this._finished = !0, this._onDoneFns.forEach(d => d()), this._onDoneFns = [])
        }
        init() {
          this._buildPlayer(), this._preparePlayerBeforeStart()
        }
        _buildPlayer() {
          if (this._initialized) return;
          this._initialized = !0;
          const d = this.keyframes;
          this.domPlayer = this._triggerWebAnimation(this.element, d, this.options), this._finalKeyframe = d
            .length ? d[d.length - 1] : new Map;
          const a = () => this._onFinish();
          this.domPlayer.addEventListener("finish", a), this.onDestroy(() => {
            this.domPlayer.removeEventListener("finish", a)
          })
        }
        _preparePlayerBeforeStart() {
          this._delay ? this._resetDomPlayerState() : this.domPlayer.pause()
        }
        _convertKeyframesToObject(d) {
          const a = [];
          return d.forEach(m => {
            a.push(Object.fromEntries(m))
          }), a
        }
        _triggerWebAnimation(d, a, m) {
          return d.animate(this._convertKeyframesToObject(a), m)
        }
        onStart(d) {
          this._originalOnStartFns.push(d), this._onStartFns.push(d)
        }
        onDone(d) {
          this._originalOnDoneFns.push(d), this._onDoneFns.push(d)
        }
        onDestroy(d) {
          this._onDestroyFns.push(d)
        }
        play() {
          this._buildPlayer(), this.hasStarted() || (this._onStartFns.forEach(d => d()), this._onStartFns = [],
            this._started = !0, this._specialStyles && this._specialStyles.start()), this.domPlayer.play()
        }
        pause() {
          this.init(), this.domPlayer.pause()
        }
        finish() {
          this.init(), this._specialStyles && this._specialStyles.finish(), this._onFinish(), this.domPlayer
            .finish()
        }
        reset() {
          this._resetDomPlayerState(), this._destroyed = !1, this._finished = !1, this._started = !1, this
            ._onStartFns = this._originalOnStartFns, this._onDoneFns = this._originalOnDoneFns
        }
        _resetDomPlayerState() {
          this.domPlayer && this.domPlayer.cancel()
        }
        restart() {
          this.reset(), this.play()
        }
        hasStarted() {
          return this._started
        }
        destroy() {
          this._destroyed || (this._destroyed = !0, this._resetDomPlayerState(), this._onFinish(), this
            ._specialStyles && this._specialStyles.destroy(), this._onDestroyFns.forEach(d => d()), this
            ._onDestroyFns = [])
        }
        setPosition(d) {
          void 0 === this.domPlayer && this.init(), this.domPlayer.currentTime = d * this.time
        }
        getPosition() {
          return +(this.domPlayer.currentTime ?? 0) / this.time
        }
        get totalTime() {
          return this._delay + this._duration
        }
        beforeDestroy() {
          const d = new Map;
          this.hasStarted() && this._finalKeyframe.forEach((m, b) => {
            "offset" !== b && d.set(b, this._finished ? m : lt(this.element, b))
          }), this.currentSnapshot = d
        }
        triggerCallback(d) {
          const a = "start" === d ? this._onStartFns : this._onDoneFns;
          a.forEach(m => m()), a.length = 0
        }
      }
      class Ui {
        validateStyleProperty(d) {
          return !0
        }
        validateAnimatableStyleProperty(d) {
          return !0
        }
        matchesElement(d, a) {
          return !1
        }
        containsElement(d, a) {
          return Qr(d, a)
        }
        getParentElement(d) {
          return yn(d)
        }
        query(d, a, m) {
          return ii(d, a, m)
        }
        computeStyle(d, a, m) {
          return lt(d, a)
        }
        animate(d, a, m, b, R, j = []) {
          const de = {
            duration: m,
            delay: b,
            fill: 0 == b ? "both" : "forwards"
          };
          R && (de.easing = R);
          const fe = new Map,
            $e = j.filter(Mt => Mt instanceof as);
          (function Hn(C, d) {
            return 0 === C || 0 === d
          })(m, b) && $e.forEach(Mt => {
            Mt.currentSnapshot.forEach((gt, Dt) => fe.set(Dt, gt))
          });
          let Ge = function it(C) {
            return C.length ? C[0] instanceof Map ? C : C.map(d => new Map(Object.entries(d))) : []
          }(a).map(Mt => new Map(Mt));
          Ge = function dr(C, d, a) {
            if (a.size && d.length) {
              let m = d[0],
                b = [];
              if (a.forEach((R, j) => {
                  m.has(j) || b.push(j), m.set(j, R)
                }), b.length)
                for (let R = 1; R < d.length; R++) {
                  let j = d[R];
                  b.forEach(q => j.set(q, lt(C, q)))
                }
            }
            return d
          }(d, Ge, fe);
          const We = function Mo(C, d) {
            let a = null,
              m = null;
            return Array.isArray(d) && d.length ? (a = Qs(d[0]), d.length > 1 && (m = Qs(d[d.length - 1]))) :
              d instanceof Map && (a = Qs(d)), a || m ? new Fs(C, a, m) : null
          }(d, Ge);
          return new as(d, Ge, de, We)
        }
      }
      const Pn = "@.disabled";
      class Ir {
        constructor(d, a, m, b) {
          this.namespaceId = d, this.delegate = a, this.engine = m, this._onDestroy = b, this.\u0275type = 0
        }
        get data() {
          return this.delegate.data
        }
        destroyNode(d) {
          this.delegate.destroyNode?.(d)
        }
        destroy() {
          this.engine.destroy(this.namespaceId, this.delegate), this.engine.afterFlushAnimationsDone(() => {
            queueMicrotask(() => {
              this.delegate.destroy()
            })
          }), this._onDestroy?.()
        }
        createElement(d, a) {
          return this.delegate.createElement(d, a)
        }
        createComment(d) {
          return this.delegate.createComment(d)
        }
        createText(d) {
          return this.delegate.createText(d)
        }
        appendChild(d, a) {
          this.delegate.appendChild(d, a), this.engine.onInsert(this.namespaceId, a, d, !1)
        }
        insertBefore(d, a, m, b = !0) {
          this.delegate.insertBefore(d, a, m), this.engine.onInsert(this.namespaceId, a, d, b)
        }
        removeChild(d, a, m) {
          this.engine.onRemove(this.namespaceId, a, this.delegate)
        }
        selectRootElement(d, a) {
          return this.delegate.selectRootElement(d, a)
        }
        parentNode(d) {
          return this.delegate.parentNode(d)
        }
        nextSibling(d) {
          return this.delegate.nextSibling(d)
        }
        setAttribute(d, a, m, b) {
          this.delegate.setAttribute(d, a, m, b)
        }
        removeAttribute(d, a, m) {
          this.delegate.removeAttribute(d, a, m)
        }
        addClass(d, a) {
          this.delegate.addClass(d, a)
        }
        removeClass(d, a) {
          this.delegate.removeClass(d, a)
        }
        setStyle(d, a, m, b) {
          this.delegate.setStyle(d, a, m, b)
        }
        removeStyle(d, a, m) {
          this.delegate.removeStyle(d, a, m)
        }
        setProperty(d, a, m) {
          "@" == a.charAt(0) && a == Pn ? this.disableAnimations(d, !!m) : this.delegate.setProperty(d, a, m)
        }
        setValue(d, a) {
          this.delegate.setValue(d, a)
        }
        listen(d, a, m) {
          return this.delegate.listen(d, a, m)
        }
        disableAnimations(d, a) {
          this.engine.disableAnimations(d, a)
        }
      }
      class rr extends Ir {
        constructor(d, a, m, b, R) {
          super(a, m, b, R), this.factory = d, this.namespaceId = a
        }
        setProperty(d, a, m) {
          "@" == a.charAt(0) ? "." == a.charAt(1) && a == Pn ? this.disableAnimations(d, m = void 0 === m || !!
            m) : this.engine.process(this.namespaceId, d, a.slice(1), m) : this.delegate.setProperty(d, a, m)
        }
        listen(d, a, m) {
          if ("@" == a.charAt(0)) {
            const b = function To(C) {
              switch (C) {
                case "body":
                  return document.body;
                case "document":
                  return document;
                case "window":
                  return window;
                default:
                  return C
              }
            }(d);
            let R = a.slice(1),
              j = "";
            return "@" != R.charAt(0) && ([R, j] = function Ys(C) {
              const d = C.indexOf(".");
              return [C.substring(0, d), C.slice(d + 1)]
            }(R)), this.engine.listen(this.namespaceId, b, R, j, q => {
              this.factory.scheduleListenerCallback(q._data || -1, m, q)
            })
          }
          return this.delegate.listen(d, a, m)
        }
      }
      class ls {
        constructor(d, a, m) {
          this.delegate = d, this.engine = a, this._zone = m, this._currentId = 0, this._microtaskId = 1, this
            ._animationCallbacksBuffer = [], this._rendererCache = new Map, this._cdRecurDepth = 0, a
            .onRemovalComplete = (b, R) => {
              const j = R?.parentNode(b);
              j && R.removeChild(j, b)
            }
        }
        createRenderer(d, a) {
          const b = this.delegate.createRenderer(d, a);
          if (!d || !a?.data?.animation) {
            const fe = this._rendererCache;
            let $e = fe.get(b);
            return $e || ($e = new Ir("", b, this.engine, () => fe.delete(b)), fe.set(b, $e)), $e
          }
          const R = a.id,
            j = a.id + "-" + this._currentId;
          this._currentId++, this.engine.register(j, d);
          const q = fe => {
            Array.isArray(fe) ? fe.forEach(q) : this.engine.registerTrigger(R, j, d, fe.name, fe)
          };
          return a.data.animation.forEach(q), new rr(this, j, b, this.engine)
        }
        begin() {
          this._cdRecurDepth++, this.delegate.begin && this.delegate.begin()
        }
        _scheduleCountTask() {
          queueMicrotask(() => {
            this._microtaskId++
          })
        }
        scheduleListenerCallback(d, a, m) {
          if (d >= 0 && d < this._microtaskId) return void this._zone.run(() => a(m));
          const b = this._animationCallbacksBuffer;
          0 == b.length && queueMicrotask(() => {
            this._zone.run(() => {
              b.forEach(R => {
                const [j, q] = R;
                j(q)
              }), this._animationCallbacksBuffer = []
            })
          }), b.push([a, m])
        }
        end() {
          this._cdRecurDepth--, 0 == this._cdRecurDepth && this._zone.runOutsideAngular(() => {
            this._scheduleCountTask(), this.engine.flush(this._microtaskId)
          }), this.delegate.end && this.delegate.end()
        }
        whenRenderingDone() {
          return this.engine.whenRenderingDone()
        }
      }
      const cs = [{
          provide: zi,
          useFactory: function ta() {
            return new Fr
          }
        }, {
          provide: Ps,
          useClass: (() => {
            class C extends Ps {
              constructor(a, m, b) {
                super(a, m, b, (0, c.WQX)(c.An2, {
                  optional: !0
                }))
              }
              ngOnDestroy() {
                this.flush()
              }
              static #e = this.\u0275fac = function(m) {
                return new(m || C)(c.KVO(ee.qQ), c.KVO(Gt), c.KVO(zi))
              };
              static #t = this.\u0275prov = c.jDH({
                token: C,
                factory: C.\u0275fac
              })
            }
            return C
          })()
        }, {
          provide: c._9s,
          useFactory: function ts(C, d, a) {
            return new ls(C, d, a)
          },
          deps: [g.B7, Ps, c.SKi]
        }],
        $r = [{
          provide: Gt,
          useFactory: () => new Ui
        }, {
          provide: c.bc$,
          useValue: "BrowserAnimations"
        }, ...cs],
        ho = [{
          provide: Gt,
          useClass: Vr
        }, {
          provide: c.bc$,
          useValue: "NoopAnimations"
        }, ...cs];
      let Zs = (() => {
        class C {
          static withConfig(a) {
            return {
              ngModule: C,
              providers: a.disableAnimations ? ho : $r
            }
          }
          static #e = this.\u0275fac = function(m) {
            return new(m || C)
          };
          static #t = this.\u0275mod = c.$C({
            type: C
          });
          static #n = this.\u0275inj = c.G2t({
            providers: $r,
            imports: [g.Bb]
          })
        }
        return C
      })();
      var po = x(2242),
        Js = x(1512);
      (0, U.lY)([(0, U.iF)({
        transform: "{{transform}}",
        opacity: 0
      }), (0, U.i0)("{{transition}}")]), (0, U.lY)([(0, U.i0)("{{transition}}", (0, U.iF)({
        transform: "{{transform}}",
        opacity: 0
      }))]);
      let mo = (() => {
          class C {
            static \u0275fac = function(m) {
              return new(m || C)
            };
            static \u0275mod = c.$C({
              type: C
            });
            static \u0275inj = c.G2t({
              imports: [ee.MD, Ne.Z, ae.Gg, Js.A, ae.Gg]
            })
          }
          return C
        })(),
        D = (() => {
          class C {
            static \u0275fac = function(m) {
              return new(m || C)
            };
            static \u0275mod = c.$C({
              type: C
            });
            static \u0275inj = c.G2t({
              imports: [ee.MD, ae.Gg]
            })
          }
          return C
        })();
      var S = x(494),
        W = x(1880);
      const _e = ["input"],
        Me = (C, d, a) => ({
          "p-inputswitch p-component": !0,
          "p-inputswitch-checked": C,
          "p-disabled": d,
          "p-focus": a
        }),
        Je = {
          provide: Nt.kq,
          useExisting: (0, c.Rfq)(() => cn),
          multi: !0
        };
      let cn = (() => {
          class C {
            cd;
            style;
            styleClass;
            tabindex;
            inputId;
            name;
            disabled;
            readonly;
            trueValue = !0;
            falseValue = !1;
            ariaLabel;
            ariaLabelledBy;
            autofocus;
            onChange = new c.bkB;
            input;
            modelValue = !1;
            focused = !1;
            onModelChange = () => {};
            onModelTouched = () => {};
            constructor(a) {
              this.cd = a
            }
            onClick(a) {
              !this.disabled && !this.readonly && (this.modelValue = this.checked() ? this.falseValue : this
                .trueValue, this.onModelChange(this.modelValue), this.onChange.emit({
                  originalEvent: a,
                  checked: this.modelValue
                }), this.input.nativeElement.focus())
            }
            onFocus() {
              this.focused = !0
            }
            onBlur() {
              this.focused = !1, this.onModelTouched()
            }
            writeValue(a) {
              this.modelValue = a, this.cd.markForCheck()
            }
            registerOnChange(a) {
              this.onModelChange = a
            }
            registerOnTouched(a) {
              this.onModelTouched = a
            }
            setDisabledState(a) {
              this.disabled = a, this.cd.markForCheck()
            }
            checked() {
              return this.modelValue === this.trueValue
            }
            static \u0275fac = function(m) {
              return new(m || C)(c.rXU(c.gRc))
            };
            static \u0275cmp = c.VBU({
              type: C,
              selectors: [
                ["p-inputSwitch"]
              ],
              viewQuery: function(m, b) {
                if (1 & m && c.GBs(_e, 5), 2 & m) {
                  let R;
                  c.mGM(R = c.lsd()) && (b.input = R.first)
                }
              },
              hostAttrs: [1, "p-element"],
              inputs: {
                style: "style",
                styleClass: "styleClass",
                tabindex: [c.Mj6.HasDecoratorInputTransform, "tabindex", "tabindex", c.Udg],
                inputId: "inputId",
                name: "name",
                disabled: [c.Mj6.HasDecoratorInputTransform, "disabled", "disabled", c.L39],
                readonly: [c.Mj6.HasDecoratorInputTransform, "readonly", "readonly", c.L39],
                trueValue: "trueValue",
                falseValue: "falseValue",
                ariaLabel: "ariaLabel",
                ariaLabelledBy: "ariaLabelledBy",
                autofocus: [c.Mj6.HasDecoratorInputTransform, "autofocus", "autofocus", c.L39]
              },
              outputs: {
                onChange: "onChange"
              },
              features: [c.Jv_([Je]), c.GFd],
              decls: 5,
              vars: 23,
              consts: [
                ["input", ""],
                [3, "click", "ngClass", "ngStyle"],
                [1, "p-hidden-accessible"],
                ["type", "checkbox", "role", "switch", "pAutoFocus", "", 3, "focus", "blur", "checked",
                  "disabled", "autofocus"
                ],
                [1, "p-inputswitch-slider"]
              ],
              template: function(m, b) {
                if (1 & m) {
                  const R = c.RV6();
                  c.j41(0, "div", 1), c.bIt("click", function(q) {
                    return c.eBV(R), c.Njj(b.onClick(q))
                  }), c.j41(1, "div", 2)(2, "input", 3, 0), c.bIt("focus", function() {
                    return c.eBV(R), c.Njj(b.onFocus())
                  })("blur", function() {
                    return c.eBV(R), c.Njj(b.onBlur())
                  }), c.k0s()(), c.nrm(4, "span", 4), c.k0s()
                }
                2 & m && (c.HbH(b.styleClass), c.Y8G("ngClass", c.sMw(19, Me, b.checked(), b.disabled, b
                  .focused))("ngStyle", b.style), c.BMQ("data-pc-name", "inputswitch")(
                  "data-pc-section", "root"), c.R7$(), c.BMQ("data-pc-section", "hiddenInputWrapper")(
                  "data-p-hidden-accessible", !0), c.R7$(), c.Y8G("checked", b.checked())("disabled",
                  b.disabled)("autofocus", b.autofocus), c.BMQ("id", b.inputId)("aria-checked", b
                  .checked())("aria-labelledby", b.ariaLabelledBy)("aria-label", b.ariaLabel)("name",
                  b.name)("tabindex", b.tabindex)("data-pc-section", "hiddenInput"), c.R7$(2), c.BMQ(
                  "data-pc-section", "slider"))
              },
              dependencies: [ee.YU, ee.B3, W.q],
              styles: [
                '@layer primeng{.p-inputswitch{position:relative;display:inline-block;-webkit-user-select:none;user-select:none}.p-inputswitch-slider{position:absolute;cursor:pointer;inset:0;border:1px solid transparent}.p-inputswitch-slider:before{position:absolute;content:"";top:50%}}\n'
              ],
              encapsulation: 2,
              changeDetection: 0
            })
          }
          return C
        })(),
        on = (() => {
          class C {
            static \u0275fac = function(m) {
              return new(m || C)
            };
            static \u0275mod = c.$C({
              type: C
            });
            static \u0275inj = c.G2t({
              imports: [ee.MD, W.u]
            })
          }
          return C
        })();
      var un = x(1141);
      let xt = (() => {
          class C {
            static #e = this.\u0275fac = function(m) {
              return new(m || C)
            };
            static #t = this.\u0275mod = c.$C({
              type: C
            });
            static #n = this.\u0275inj = c.G2t({
              imports: [ee.MD, Nt.YN, mo, S.Ko, un.tm, on]
            })
          }
          return C
        })(),
        vn = (() => {
          class C {
            static #e = this.\u0275fac = function(m) {
              return new(m || C)
            };
            static #t = this.\u0275mod = c.$C({
              type: C
            });
            static #n = this.\u0275inj = c.G2t({
              imports: [g.Bb, Nt.YN, Et.q1, Zs, po.u, mo, D, S.Ko, on, Ne.Z, A.iI, xt]
            })
          }
          return C
        })(),
        tn = (() => {
          class C {
            static #e = this.\u0275fac = function(m) {
              return new(m || C)
            };
            static #t = this.\u0275mod = c.$C({
              type: C,
              bootstrap: [k]
            });
            static #n = this.\u0275inj = c.G2t({
              providers: [{
                provide: ee.hb,
                useClass: ee.Sm
              }],
              imports: [rt, vn]
            })
          }
          return C
        })();
      et.c.production && (0, c.SmG)(), g.sG().bootstrapModule(tn).catch(C => console.error(C))
    },
    4412: (nt, Se, x) => {
      x.d(Se, {
        t: () => c
      });
      var g = x(1413);
      class c extends g.B {
        constructor(ae) {
          super(), this._value = ae
        }
        get value() {
          return this.getValue()
        }
        _subscribe(ae) {
          const A = super._subscribe(ae);
          return !A.closed && ae.next(this._value), A
        }
        getValue() {
          const {
            hasError: ae,
            thrownError: A,
            _value: k
          } = this;
          if (ae) throw A;
          return this._throwIfClosed(), k
        }
        next(ae) {
          super.next(this._value = ae)
        }
      }
    },
    1985: (nt, Se, x) => {
      x.d(Se, {
        c: () => V
      });
      var g = x(7707),
        c = x(8359),
        ee = x(3494),
        ae = x(1203),
        A = x(1026),
        k = x(8071),
        M = x(9786);
      let V = (() => {
        class le {
          constructor(me) {
            me && (this._subscribe = me)
          }
          lift(me) {
            const Ae = new le;
            return Ae.source = this, Ae.operator = me, Ae
          }
          subscribe(me, Ae, qe) {
            const we = function U(le) {
              return le && le instanceof g.vU || function X(le) {
                return le && (0, k.T)(le.next) && (0, k.T)(le.error) && (0, k.T)(le.complete)
              }(le) && (0, c.Uv)(le)
            }(me) ? me : new g.Ms(me, Ae, qe);
            return (0, M.Y)(() => {
              const {
                operator: Ve,
                source: Ze
              } = this;
              we.add(Ve ? Ve.call(we, Ze) : Ze ? this._subscribe(we) : this._trySubscribe(we))
            }), we
          }
          _trySubscribe(me) {
            try {
              return this._subscribe(me)
            } catch (Ae) {
              me.error(Ae)
            }
          }
          forEach(me, Ae) {
            return new(Ae = $(Ae))((qe, we) => {
              const Ve = new g.Ms({
                next: Ze => {
                  try {
                    me(Ze)
                  } catch (vt) {
                    we(vt), Ve.unsubscribe()
                  }
                },
                error: we,
                complete: qe
              });
              this.subscribe(Ve)
            })
          }
          _subscribe(me) {
            var Ae;
            return null === (Ae = this.source) || void 0 === Ae ? void 0 : Ae.subscribe(me)
          } [ee.s]() {
            return this
          }
          pipe(...me) {
            return (0, ae.m)(me)(this)
          }
          toPromise(me) {
            return new(me = $(me))((Ae, qe) => {
              let we;
              this.subscribe(Ve => we = Ve, Ve => qe(Ve), () => Ae(we))
            })
          }
        }
        return le.create = Ne => new le(Ne), le
      })();

      function $(le) {
        var Ne;
        return null !== (Ne = le ?? A.$.Promise) && void 0 !== Ne ? Ne : Promise
      }
    },
    1413: (nt, Se, x) => {
      x.d(Se, {
        B: () => M
      });
      var g = x(1985),
        c = x(8359);
      const ae = (0, x(1853).L)($ => function() {
        $(this), this.name = "ObjectUnsubscribedError", this.message = "object unsubscribed"
      });
      var A = x(7908),
        k = x(9786);
      let M = (() => {
        class $ extends g.c {
          constructor() {
            super(), this.closed = !1, this.currentObservers = null, this.observers = [], this
              .isStopped = !1, this.hasError = !1, this.thrownError = null
          }
          lift(U) {
            const le = new V(this, this);
            return le.operator = U, le
          }
          _throwIfClosed() {
            if (this.closed) throw new ae
          }
          next(U) {
            (0, k.Y)(() => {
              if (this._throwIfClosed(), !this.isStopped) {
                this.currentObservers || (this.currentObservers = Array.from(this.observers));
                for (const le of this.currentObservers) le.next(U)
              }
            })
          }
          error(U) {
            (0, k.Y)(() => {
              if (this._throwIfClosed(), !this.isStopped) {
                this.hasError = this.isStopped = !0, this.thrownError = U;
                const {
                  observers: le
                } = this;
                for (; le.length;) le.shift().error(U)
              }
            })
          }
          complete() {
            (0, k.Y)(() => {
              if (this._throwIfClosed(), !this.isStopped) {
                this.isStopped = !0;
                const {
                  observers: U
                } = this;
                for (; U.length;) U.shift().complete()
              }
            })
          }
          unsubscribe() {
            this.isStopped = this.closed = !0, this.observers = this.currentObservers = null
          }
          get observed() {
            var U;
            return (null === (U = this.observers) || void 0 === U ? void 0 : U.length) > 0
          }
          _trySubscribe(U) {
            return this._throwIfClosed(), super._trySubscribe(U)
          }
          _subscribe(U) {
            return this._throwIfClosed(), this._checkFinalizedStatuses(U), this._innerSubscribe(U)
          }
          _innerSubscribe(U) {
            const {
              hasError: le,
              isStopped: Ne,
              observers: me
            } = this;
            return le || Ne ? c.Kn : (this.currentObservers = null, me.push(U), new c.yU(() => {
              this.currentObservers = null, (0, A.o)(me, U)
            }))
          }
          _checkFinalizedStatuses(U) {
            const {
              hasError: le,
              thrownError: Ne,
              isStopped: me
            } = this;
            le ? U.error(Ne) : me && U.complete()
          }
          asObservable() {
            const U = new g.c;
            return U.source = this, U
          }
        }
        return $.create = (X, U) => new V(X, U), $
      })();
      class V extends M {
        constructor(X, U) {
          super(), this.destination = X, this.source = U
        }
        next(X) {
          var U, le;
          null === (le = null === (U = this.destination) || void 0 === U ? void 0 : U.next) || void 0 === le ||
            le.call(U, X)
        }
        error(X) {
          var U, le;
          null === (le = null === (U = this.destination) || void 0 === U ? void 0 : U.error) || void 0 === le ||
            le.call(U, X)
        }
        complete() {
          var X, U;
          null === (U = null === (X = this.destination) || void 0 === X ? void 0 : X.complete) || void 0 ===
            U || U.call(X)
        }
        _subscribe(X) {
          var U, le;
          return null !== (le = null === (U = this.source) || void 0 === U ? void 0 : U.subscribe(X)) &&
            void 0 !== le ? le : c.Kn
        }
      }
    },
    7707: (nt, Se, x) => {
      x.d(Se, {
        Ms: () => qe,
        vU: () => le
      });
      var g = x(8071),
        c = x(8359),
        ee = x(1026),
        ae = x(5334),
        A = x(5343);
      const k = $("C", void 0, void 0);

      function $(ue, Pe, ie) {
        return {
          kind: ue,
          value: Pe,
          error: ie
        }
      }
      var X = x(9270),
        U = x(9786);
      class le extends c.yU {
        constructor(Pe) {
          super(), this.isStopped = !1, Pe ? (this.destination = Pe, (0, c.Uv)(Pe) && Pe.add(this)) : this
            .destination = vt
        }
        static create(Pe, ie, se) {
          return new qe(Pe, ie, se)
        }
        next(Pe) {
          this.isStopped ? Ze(function V(ue) {
            return $("N", ue, void 0)
          }(Pe), this) : this._next(Pe)
        }
        error(Pe) {
          this.isStopped ? Ze(function M(ue) {
            return $("E", void 0, ue)
          }(Pe), this) : (this.isStopped = !0, this._error(Pe))
        }
        complete() {
          this.isStopped ? Ze(k, this) : (this.isStopped = !0, this._complete())
        }
        unsubscribe() {
          this.closed || (this.isStopped = !0, super.unsubscribe(), this.destination = null)
        }
        _next(Pe) {
          this.destination.next(Pe)
        }
        _error(Pe) {
          try {
            this.destination.error(Pe)
          } finally {
            this.unsubscribe()
          }
        }
        _complete() {
          try {
            this.destination.complete()
          } finally {
            this.unsubscribe()
          }
        }
      }
      const Ne = Function.prototype.bind;

      function me(ue, Pe) {
        return Ne.call(ue, Pe)
      }
      class Ae {
        constructor(Pe) {
          this.partialObserver = Pe
        }
        next(Pe) {
          const {
            partialObserver: ie
          } = this;
          if (ie.next) try {
            ie.next(Pe)
          } catch (se) {
            we(se)
          }
        }
        error(Pe) {
          const {
            partialObserver: ie
          } = this;
          if (ie.error) try {
            ie.error(Pe)
          } catch (se) {
            we(se)
          } else we(Pe)
        }
        complete() {
          const {
            partialObserver: Pe
          } = this;
          if (Pe.complete) try {
            Pe.complete()
          } catch (ie) {
            we(ie)
          }
        }
      }
      class qe extends le {
        constructor(Pe, ie, se) {
          let Re;
          if (super(), (0, g.T)(Pe) || !Pe) Re = {
            next: Pe ?? void 0,
            error: ie ?? void 0,
            complete: se ?? void 0
          };
          else {
            let Be;
            this && ee.$.useDeprecatedNextContext ? (Be = Object.create(Pe), Be.unsubscribe = () => this
              .unsubscribe(), Re = {
                next: Pe.next && me(Pe.next, Be),
                error: Pe.error && me(Pe.error, Be),
                complete: Pe.complete && me(Pe.complete, Be)
              }) : Re = Pe
          }
          this.destination = new Ae(Re)
        }
      }

      function we(ue) {
        ee.$.useDeprecatedSynchronousErrorHandling ? (0, U.l)(ue) : (0, ae.m)(ue)
      }

      function Ze(ue, Pe) {
        const {
          onStoppedNotification: ie
        } = ee.$;
        ie && X.f.setTimeout(() => ie(ue, Pe))
      }
      const vt = {
        closed: !0,
        next: A.l,
        error: function Ve(ue) {
          throw ue
        },
        complete: A.l
      }
    },
    8359: (nt, Se, x) => {
      x.d(Se, {
        Kn: () => k,
        yU: () => A,
        Uv: () => M
      });
      var g = x(8071);
      const ee = (0, x(1853).L)($ => function(U) {
        $(this), this.message = U ?
          `${U.length} errors occurred during unsubscription:\n${U.map((le,Ne)=>`${Ne+1}) ${le.toString()}`).join("\n  ")}` :
          "", this.name = "UnsubscriptionError", this.errors = U
      });
      var ae = x(7908);
      class A {
        constructor(X) {
          this.initialTeardown = X, this.closed = !1, this._parentage = null, this._finalizers = null
        }
        unsubscribe() {
          let X;
          if (!this.closed) {
            this.closed = !0;
            const {
              _parentage: U
            } = this;
            if (U)
              if (this._parentage = null, Array.isArray(U))
                for (const me of U) me.remove(this);
              else U.remove(this);
            const {
              initialTeardown: le
            } = this;
            if ((0, g.T)(le)) try {
              le()
            } catch (me) {
              X = me instanceof ee ? me.errors : [me]
            }
            const {
              _finalizers: Ne
            } = this;
            if (Ne) {
              this._finalizers = null;
              for (const me of Ne) try {
                V(me)
              } catch (Ae) {
                X = X ?? [], Ae instanceof ee ? X = [...X, ...Ae.errors] : X.push(Ae)
              }
            }
            if (X) throw new ee(X)
          }
        }
        add(X) {
          var U;
          if (X && X !== this)
            if (this.closed) V(X);
            else {
              if (X instanceof A) {
                if (X.closed || X._hasParent(this)) return;
                X._addParent(this)
              }(this._finalizers = null !== (U = this._finalizers) && void 0 !== U ? U : []).push(X)
            }
        }
        _hasParent(X) {
          const {
            _parentage: U
          } = this;
          return U === X || Array.isArray(U) && U.includes(X)
        }
        _addParent(X) {
          const {
            _parentage: U
          } = this;
          this._parentage = Array.isArray(U) ? (U.push(X), U) : U ? [U, X] : X
        }
        _removeParent(X) {
          const {
            _parentage: U
          } = this;
          U === X ? this._parentage = null : Array.isArray(U) && (0, ae.o)(U, X)
        }
        remove(X) {
          const {
            _finalizers: U
          } = this;
          U && (0, ae.o)(U, X), X instanceof A && X._removeParent(this)
        }
      }
      A.EMPTY = (() => {
        const $ = new A;
        return $.closed = !0, $
      })();
      const k = A.EMPTY;

      function M($) {
        return $ instanceof A || $ && "closed" in $ && (0, g.T)($.remove) && (0, g.T)($.add) && (0, g.T)($
          .unsubscribe)
      }

      function V($) {
        (0, g.T)($) ? $(): $.unsubscribe()
      }
    },
    1026: (nt, Se, x) => {
      x.d(Se, {
        $: () => g
      });
      const g = {
        onUnhandledError: null,
        onStoppedNotification: null,
        Promise: void 0,
        useDeprecatedSynchronousErrorHandling: !1,
        useDeprecatedNextContext: !1
      }
    },
    7468: (nt, Se, x) => {
      x.d(Se, {
        p: () => V
      });
      var g = x(1985),
        c = x(3073),
        ee = x(8750),
        ae = x(9326),
        A = x(4360),
        k = x(6450),
        M = x(8496);

      function V(...$) {
        const X = (0, ae.ms)($),
          {
            args: U,
            keys: le
          } = (0, c.D)($),
          Ne = new g.c(me => {
            const {
              length: Ae
            } = U;
            if (!Ae) return void me.complete();
            const qe = new Array(Ae);
            let we = Ae,
              Ve = Ae;
            for (let Ze = 0; Ze < Ae; Ze++) {
              let vt = !1;
              (0, ee.Tg)(U[Ze]).subscribe((0, A._)(me, ue => {
                vt || (vt = !0, Ve--), qe[Ze] = ue
              }, () => we--, void 0, () => {
                (!we || !vt) && (Ve || me.next(le ? (0, M.e)(le, qe) : qe), me.complete())
              }))
            }
          });
        return X ? Ne.pipe((0, k.I)(X)) : Ne
      }
    },
    6648: (nt, Se, x) => {
      x.d(Se, {
        H: () => se
      });
      var g = x(8750),
        c = x(5225),
        ee = x(9974),
        ae = x(4360);

      function A(Re, Be = 0) {
        return (0, ee.N)((De, Z) => {
          De.subscribe((0, ae._)(Z, xe => (0, c.N)(Z, Re, () => Z.next(xe), Be), () => (0, c.N)(Z, Re, () => Z
            .complete(), Be), xe => (0, c.N)(Z, Re, () => Z.error(xe), Be)))
        })
      }

      function k(Re, Be = 0) {
        return (0, ee.N)((De, Z) => {
          Z.add(Re.schedule(() => De.subscribe(Z), Be))
        })
      }
      var $ = x(1985),
        U = x(4761),
        le = x(8071);

      function me(Re, Be) {
        if (!Re) throw new Error("Iterable cannot be null");
        return new $.c(De => {
          (0, c.N)(De, Be, () => {
            const Z = Re[Symbol.asyncIterator]();
            (0, c.N)(De, Be, () => {
              Z.next().then(xe => {
                xe.done ? De.complete() : De.next(xe.value)
              })
            }, 0, !0)
          })
        })
      }
      var Ae = x(5055),
        qe = x(9858),
        we = x(7441),
        Ve = x(5397),
        Ze = x(7953),
        vt = x(591),
        ue = x(5196);

      function se(Re, Be) {
        return Be ? function ie(Re, Be) {
          if (null != Re) {
            if ((0, Ae.l)(Re)) return function M(Re, Be) {
              return (0, g.Tg)(Re).pipe(k(Be), A(Be))
            }(Re, Be);
            if ((0, we.X)(Re)) return function X(Re, Be) {
              return new $.c(De => {
                let Z = 0;
                return Be.schedule(function() {
                  Z === Re.length ? De.complete() : (De.next(Re[Z++]), De.closed || this.schedule())
                })
              })
            }(Re, Be);
            if ((0, qe.y)(Re)) return function V(Re, Be) {
              return (0, g.Tg)(Re).pipe(k(Be), A(Be))
            }(Re, Be);
            if ((0, Ze.T)(Re)) return me(Re, Be);
            if ((0, Ve.x)(Re)) return function Ne(Re, Be) {
              return new $.c(De => {
                let Z;
                return (0, c.N)(De, Be, () => {
                  Z = Re[U.l](), (0, c.N)(De, Be, () => {
                    let xe, be;
                    try {
                      ({
                        value: xe,
                        done: be
                      } = Z.next())
                    } catch (et) {
                      return void De.error(et)
                    }
                    be ? De.complete() : De.next(xe)
                  }, 0, !0)
                }), () => (0, le.T)(Z?.return) && Z.return()
              })
            }(Re, Be);
            if ((0, ue.U)(Re)) return function Pe(Re, Be) {
              return me((0, ue.C)(Re), Be)
            }(Re, Be)
          }
          throw (0, vt.L)(Re)
        }(Re, Be) : (0, g.Tg)(Re)
      }
    },
    8750: (nt, Se, x) => {
      x.d(Se, {
        Tg: () => Ne
      });
      var g = x(1635),
        c = x(7441),
        ee = x(9858),
        ae = x(1985),
        A = x(5055),
        k = x(7953),
        M = x(591),
        V = x(5397),
        $ = x(5196),
        X = x(8071),
        U = x(5334),
        le = x(3494);

      function Ne(ue) {
        if (ue instanceof ae.c) return ue;
        if (null != ue) {
          if ((0, A.l)(ue)) return function me(ue) {
            return new ae.c(Pe => {
              const ie = ue[le.s]();
              if ((0, X.T)(ie.subscribe)) return ie.subscribe(Pe);
              throw new TypeError("Provided object does not correctly implement Symbol.observable")
            })
          }(ue);
          if ((0, c.X)(ue)) return function Ae(ue) {
            return new ae.c(Pe => {
              for (let ie = 0; ie < ue.length && !Pe.closed; ie++) Pe.next(ue[ie]);
              Pe.complete()
            })
          }(ue);
          if ((0, ee.y)(ue)) return function qe(ue) {
            return new ae.c(Pe => {
              ue.then(ie => {
                Pe.closed || (Pe.next(ie), Pe.complete())
              }, ie => Pe.error(ie)).then(null, U.m)
            })
          }(ue);
          if ((0, k.T)(ue)) return Ve(ue);
          if ((0, V.x)(ue)) return function we(ue) {
            return new ae.c(Pe => {
              for (const ie of ue)
                if (Pe.next(ie), Pe.closed) return;
              Pe.complete()
            })
          }(ue);
          if ((0, $.U)(ue)) return function Ze(ue) {
            return Ve((0, $.C)(ue))
          }(ue)
        }
        throw (0, M.L)(ue)
      }

      function Ve(ue) {
        return new ae.c(Pe => {
          (function vt(ue, Pe) {
            var ie, se, Re, Be;
            return (0, g.sH)(this, void 0, void 0, function*() {
              try {
                for (ie = (0, g.xN)(ue); !(se = yield ie.next()).done;)
                  if (Pe.next(se.value), Pe.closed) return
              } catch (De) {
                Re = {
                  error: De
                }
              } finally {
                try {
                  se && !se.done && (Be = ie.return) && (yield Be.call(ie))
                } finally {
                  if (Re) throw Re.error
                }
              }
              Pe.complete()
            })
          })(ue, Pe).catch(ie => Pe.error(ie))
        })
      }
    },
    7673: (nt, Se, x) => {
      x.d(Se, {
        of: () => ee
      });
      var g = x(9326),
        c = x(6648);

      function ee(...ae) {
        const A = (0, g.lI)(ae);
        return (0, c.H)(ae, A)
      }
    },
    8810: (nt, Se, x) => {
      x.d(Se, {
        $: () => ee
      });
      var g = x(1985),
        c = x(8071);

      function ee(ae, A) {
        const k = (0, c.T)(ae) ? ae : () => ae,
          M = V => V.error(k());
        return new g.c(A ? V => A.schedule(M, 0, V) : M)
      }
    },
    4360: (nt, Se, x) => {
      x.d(Se, {
        _: () => c
      });
      var g = x(7707);

      function c(ae, A, k, M, V) {
        return new ee(ae, A, k, M, V)
      }
      class ee extends g.vU {
        constructor(A, k, M, V, $, X) {
          super(A), this.onFinalize = $, this.shouldUnsubscribe = X, this._next = k ? function(U) {
            try {
              k(U)
            } catch (le) {
              A.error(le)
            }
          } : super._next, this._error = V ? function(U) {
            try {
              V(U)
            } catch (le) {
              A.error(le)
            } finally {
              this.unsubscribe()
            }
          } : super._error, this._complete = M ? function() {
            try {
              M()
            } catch (U) {
              A.error(U)
            } finally {
              this.unsubscribe()
            }
          } : super._complete
        }
        unsubscribe() {
          var A;
          if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
            const {
              closed: k
            } = this;
            super.unsubscribe(), !k && (null === (A = this.onFinalize) || void 0 === A || A.call(this))
          }
        }
      }
    },
    9437: (nt, Se, x) => {
      x.d(Se, {
        W: () => ae
      });
      var g = x(8750),
        c = x(4360),
        ee = x(9974);

      function ae(A) {
        return (0, ee.N)((k, M) => {
          let X, V = null,
            $ = !1;
          V = k.subscribe((0, c._)(M, void 0, void 0, U => {
            X = (0, g.Tg)(A(U, ae(A)(k))), V ? (V.unsubscribe(), V = null, X.subscribe(M)) : $ = !0
          })), $ && (V.unsubscribe(), V = null, X.subscribe(M))
        })
      }
    },
    274: (nt, Se, x) => {
      x.d(Se, {
        H: () => ee
      });
      var g = x(1397),
        c = x(8071);

      function ee(ae, A) {
        return (0, c.T)(A) ? (0, g.Z)(ae, A, 1) : (0, g.Z)(ae, 1)
      }
    },
    5964: (nt, Se, x) => {
      x.d(Se, {
        p: () => ee
      });
      var g = x(9974),
        c = x(4360);

      function ee(ae, A) {
        return (0, g.N)((k, M) => {
          let V = 0;
          k.subscribe((0, c._)(M, $ => ae.call(A, $, V++) && M.next($)))
        })
      }
    },
    980: (nt, Se, x) => {
      x.d(Se, {
        j: () => c
      });
      var g = x(9974);

      function c(ee) {
        return (0, g.N)((ae, A) => {
          try {
            ae.subscribe(A)
          } finally {
            A.add(ee)
          }
        })
      }
    },
    6354: (nt, Se, x) => {
      x.d(Se, {
        T: () => ee
      });
      var g = x(9974),
        c = x(4360);

      function ee(ae, A) {
        return (0, g.N)((k, M) => {
          let V = 0;
          k.subscribe((0, c._)(M, $ => {
            M.next(ae.call(A, $, V++))
          }))
        })
      }
    },
    1397: (nt, Se, x) => {
      x.d(Se, {
        Z: () => V
      });
      var g = x(6354),
        c = x(8750),
        ee = x(9974),
        ae = x(5225),
        A = x(4360),
        M = x(8071);

      function V($, X, U = 1 / 0) {
        return (0, M.T)(X) ? V((le, Ne) => (0, g.T)((me, Ae) => X(le, me, Ne, Ae))((0, c.Tg)($(le, Ne))), U) : (
          "number" == typeof X && (U = X), (0, ee.N)((le, Ne) => function k($, X, U, le, Ne, me, Ae, qe) {
            const we = [];
            let Ve = 0,
              Ze = 0,
              vt = !1;
            const ue = () => {
                vt && !we.length && !Ve && X.complete()
              },
              Pe = se => Ve < le ? ie(se) : we.push(se),
              ie = se => {
                me && X.next(se), Ve++;
                let Re = !1;
                (0, c.Tg)(U(se, Ze++)).subscribe((0, A._)(X, Be => {
                  Ne?.(Be), me ? Pe(Be) : X.next(Be)
                }, () => {
                  Re = !0
                }, void 0, () => {
                  if (Re) try {
                    for (Ve--; we.length && Ve < le;) {
                      const Be = we.shift();
                      Ae ? (0, ae.N)(X, Ae, () => ie(Be)) : ie(Be)
                    }
                    ue()
                  } catch (Be) {
                    X.error(Be)
                  }
                }))
              };
            return $.subscribe((0, A._)(X, Pe, () => {
              vt = !0, ue()
            })), () => {
              qe?.()
            }
          }(le, Ne, $, U)))
      }
    },
    5558: (nt, Se, x) => {
      x.d(Se, {
        n: () => ae
      });
      var g = x(8750),
        c = x(9974),
        ee = x(4360);

      function ae(A, k) {
        return (0, c.N)((M, V) => {
          let $ = null,
            X = 0,
            U = !1;
          const le = () => U && !$ && V.complete();
          M.subscribe((0, ee._)(V, Ne => {
            $?.unsubscribe();
            let me = 0;
            const Ae = X++;
            (0, g.Tg)(A(Ne, Ae)).subscribe($ = (0, ee._)(V, qe => V.next(k ? k(Ne, qe, Ae, me++) : qe),
              () => {
                $ = null, le()
              }))
          }, () => {
            U = !0, le()
          }))
        })
      }
    },
    8141: (nt, Se, x) => {
      x.d(Se, {
        M: () => A
      });
      var g = x(8071),
        c = x(9974),
        ee = x(4360),
        ae = x(3669);

      function A(k, M, V) {
        const $ = (0, g.T)(k) || M || V ? {
          next: k,
          error: M,
          complete: V
        } : k;
        return $ ? (0, c.N)((X, U) => {
          var le;
          null === (le = $.subscribe) || void 0 === le || le.call($);
          let Ne = !0;
          X.subscribe((0, ee._)(U, me => {
            var Ae;
            null === (Ae = $.next) || void 0 === Ae || Ae.call($, me), U.next(me)
          }, () => {
            var me;
            Ne = !1, null === (me = $.complete) || void 0 === me || me.call($), U.complete()
          }, me => {
            var Ae;
            Ne = !1, null === (Ae = $.error) || void 0 === Ae || Ae.call($, me), U.error(me)
          }, () => {
            var me, Ae;
            Ne && (null === (me = $.unsubscribe) || void 0 === me || me.call($)), null === (Ae = $
              .finalize) || void 0 === Ae || Ae.call($)
          }))
        }) : ae.D
      }
    },
    9270: (nt, Se, x) => {
      x.d(Se, {
        f: () => g
      });
      const g = {
        setTimeout(c, ee, ...ae) {
          const {
            delegate: A
          } = g;
          return A?.setTimeout ? A.setTimeout(c, ee, ...ae) : setTimeout(c, ee, ...ae)
        },
        clearTimeout(c) {
          const {
            delegate: ee
          } = g;
          return (ee?.clearTimeout || clearTimeout)(c)
        },
        delegate: void 0
      }
    },
    4761: (nt, Se, x) => {
      x.d(Se, {
        l: () => c
      });
      const c = function g() {
        return "function" == typeof Symbol && Symbol.iterator ? Symbol.iterator : "@@iterator"
      }()
    },
    3494: (nt, Se, x) => {
      x.d(Se, {
        s: () => g
      });
      const g = "function" == typeof Symbol && Symbol.observable || "@@observable"
    },
    9326: (nt, Se, x) => {
      x.d(Se, {
        lI: () => A,
        ms: () => ae
      });
      var g = x(8071),
        c = x(9470);

      function ee(M) {
        return M[M.length - 1]
      }

      function ae(M) {
        return (0, g.T)(ee(M)) ? M.pop() : void 0
      }

      function A(M) {
        return (0, c.m)(ee(M)) ? M.pop() : void 0
      }
    },
    3073: (nt, Se, x) => {
      x.d(Se, {
        D: () => A
      });
      const {
        isArray: g
      } = Array, {
        getPrototypeOf: c,
        prototype: ee,
        keys: ae
      } = Object;

      function A(M) {
        if (1 === M.length) {
          const V = M[0];
          if (g(V)) return {
            args: V,
            keys: null
          };
          if (function k(M) {
              return M && "object" == typeof M && c(M) === ee
            }(V)) {
            const $ = ae(V);
            return {
              args: $.map(X => V[X]),
              keys: $
            }
          }
        }
        return {
          args: M,
          keys: null
        }
      }
    },
    7908: (nt, Se, x) => {
      function g(c, ee) {
        if (c) {
          const ae = c.indexOf(ee);
          0 <= ae && c.splice(ae, 1)
        }
      }
      x.d(Se, {
        o: () => g
      })
    },
    1853: (nt, Se, x) => {
      function g(c) {
        const ae = c(A => {
          Error.call(A), A.stack = (new Error).stack
        });
        return ae.prototype = Object.create(Error.prototype), ae.prototype.constructor = ae, ae
      }
      x.d(Se, {
        L: () => g
      })
    },
    8496: (nt, Se, x) => {
      function g(c, ee) {
        return c.reduce((ae, A, k) => (ae[A] = ee[k], ae), {})
      }
      x.d(Se, {
        e: () => g
      })
    },
    9786: (nt, Se, x) => {
      x.d(Se, {
        Y: () => ee,
        l: () => ae
      });
      var g = x(1026);
      let c = null;

      function ee(A) {
        if (g.$.useDeprecatedSynchronousErrorHandling) {
          const k = !c;
          if (k && (c = {
              errorThrown: !1,
              error: null
            }), A(), k) {
            const {
              errorThrown: M,
              error: V
            } = c;
            if (c = null, M) throw V
          }
        } else A()
      }

      function ae(A) {
        g.$.useDeprecatedSynchronousErrorHandling && c && (c.errorThrown = !0, c.error = A)
      }
    },
    5225: (nt, Se, x) => {
      function g(c, ee, ae, A = 0, k = !1) {
        const M = ee.schedule(function() {
          ae(), k ? c.add(this.schedule(null, A)) : this.unsubscribe()
        }, A);
        if (c.add(M), !k) return M
      }
      x.d(Se, {
        N: () => g
      })
    },
    3669: (nt, Se, x) => {
      function g(c) {
        return c
      }
      x.d(Se, {
        D: () => g
      })
    },
    7441: (nt, Se, x) => {
      x.d(Se, {
        X: () => g
      });
      const g = c => c && "number" == typeof c.length && "function" != typeof c
    },
    7953: (nt, Se, x) => {
      x.d(Se, {
        T: () => c
      });
      var g = x(8071);

      function c(ee) {
        return Symbol.asyncIterator && (0, g.T)(ee?.[Symbol.asyncIterator])
      }
    },
    8071: (nt, Se, x) => {
      function g(c) {
        return "function" == typeof c
      }
      x.d(Se, {
        T: () => g
      })
    },
    5055: (nt, Se, x) => {
      x.d(Se, {
        l: () => ee
      });
      var g = x(3494),
        c = x(8071);

      function ee(ae) {
        return (0, c.T)(ae[g.s])
      }
    },
    5397: (nt, Se, x) => {
      x.d(Se, {
        x: () => ee
      });
      var g = x(4761),
        c = x(8071);

      function ee(ae) {
        return (0, c.T)(ae?.[g.l])
      }
    },
    9858: (nt, Se, x) => {
      x.d(Se, {
        y: () => c
      });
      var g = x(8071);

      function c(ee) {
        return (0, g.T)(ee?.then)
      }
    },
    5196: (nt, Se, x) => {
      x.d(Se, {
        C: () => ee,
        U: () => ae
      });
      var g = x(1635),
        c = x(8071);

      function ee(A) {
        return (0, g.AQ)(this, arguments, function*() {
          const M = A.getReader();
          try {
            for (;;) {
              const {
                value: V,
                done: $
              } = yield(0, g.N3)(M.read());
              if ($) return yield(0, g.N3)(void 0);
              yield yield(0, g.N3)(V)
            }
          } finally {
            M.releaseLock()
          }
        })
      }

      function ae(A) {
        return (0, c.T)(A?.getReader)
      }
    },
    9470: (nt, Se, x) => {
      x.d(Se, {
        m: () => c
      });
      var g = x(8071);

      function c(ee) {
        return ee && (0, g.T)(ee.schedule)
      }
    },
    9974: (nt, Se, x) => {
      x.d(Se, {
        N: () => ee,
        S: () => c
      });
      var g = x(8071);

      function c(ae) {
        return (0, g.T)(ae?.lift)
      }

      function ee(ae) {
        return A => {
          if (c(A)) return A.lift(function(k) {
            try {
              return ae(k, this)
            } catch (M) {
              this.error(M)
            }
          });
          throw new TypeError("Unable to lift unknown Observable type")
        }
      }
    },
    6450: (nt, Se, x) => {
      x.d(Se, {
        I: () => ae
      });
      var g = x(6354);
      const {
        isArray: c
      } = Array;

      function ae(A) {
        return (0, g.T)(k => function ee(A, k) {
          return c(k) ? A(...k) : A(k)
        }(A, k))
      }
    },
    5343: (nt, Se, x) => {
      function g() {}
      x.d(Se, {
        l: () => g
      })
    },
    1203: (nt, Se, x) => {
      x.d(Se, {
        F: () => c,
        m: () => ee
      });
      var g = x(3669);

      function c(...ae) {
        return ee(ae)
      }

      function ee(ae) {
        return 0 === ae.length ? g.D : 1 === ae.length ? ae[0] : function(k) {
          return ae.reduce((M, V) => V(M), k)
        }
      }
    },
    5334: (nt, Se, x) => {
      x.d(Se, {
        m: () => ee
      });
      var g = x(1026),
        c = x(9270);

      function ee(ae) {
        c.f.setTimeout(() => {
          const {
            onUnhandledError: A
          } = g.$;
          if (!A) throw ae;
          A(ae)
        })
      }
    },
    591: (nt, Se, x) => {
      function g(c) {
        return new TypeError(
          `You provided ${null!==c&&"object"==typeof c?"an invalid object":`'${c}'`} where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.`
          )
      }
      x.d(Se, {
        L: () => g
      })
    },
    9969: (nt, Se, x) => {
      x.d(Se, {
        FX: () => Be,
        If: () => g,
        K2: () => k,
        MA: () => le,
        P: () => me,
        hZ: () => ee,
        i0: () => ae,
        iF: () => M,
        kY: () => X,
        kp: () => c,
        lY: () => U,
        sM: () => Ne,
        sf: () => se,
        ui: () => Re,
        wk: () => V
      });
      var g = function(De) {
        return De[De.State = 0] = "State", De[De.Transition = 1] = "Transition", De[De.Sequence = 2] =
          "Sequence", De[De.Group = 3] = "Group", De[De.Animate = 4] = "Animate", De[De.Keyframes = 5] =
          "Keyframes", De[De.Style = 6] = "Style", De[De.Trigger = 7] = "Trigger", De[De.Reference = 8] =
          "Reference", De[De.AnimateChild = 9] = "AnimateChild", De[De.AnimateRef = 10] = "AnimateRef", De[De
            .Query = 11] = "Query", De[De.Stagger = 12] = "Stagger", De
      }(g || {});
      const c = "*";

      function ee(De, Z) {
        return {
          type: g.Trigger,
          name: De,
          definitions: Z,
          options: {}
        }
      }

      function ae(De, Z = null) {
        return {
          type: g.Animate,
          styles: Z,
          timings: De
        }
      }

      function k(De, Z = null) {
        return {
          type: g.Sequence,
          steps: De,
          options: Z
        }
      }

      function M(De) {
        return {
          type: g.Style,
          styles: De,
          offset: null
        }
      }

      function V(De, Z, xe) {
        return {
          type: g.State,
          name: De,
          styles: Z,
          options: xe
        }
      }

      function X(De, Z, xe = null) {
        return {
          type: g.Transition,
          expr: De,
          animation: Z,
          options: xe
        }
      }

      function U(De, Z = null) {
        return {
          type: g.Reference,
          animation: De,
          options: Z
        }
      }

      function le(De = null) {
        return {
          type: g.AnimateChild,
          options: De
        }
      }

      function Ne(De, Z = null) {
        return {
          type: g.AnimateRef,
          animation: De,
          options: Z
        }
      }

      function me(De, Z, xe = null) {
        return {
          type: g.Query,
          selector: De,
          animation: Z,
          options: xe
        }
      }
      class se {
        constructor(Z = 0, xe = 0) {
          this._onDoneFns = [], this._onStartFns = [], this._onDestroyFns = [], this._originalOnDoneFns = [],
            this._originalOnStartFns = [], this._started = !1, this._destroyed = !1, this._finished = !1, this
            ._position = 0, this.parentPlayer = null, this.totalTime = Z + xe
        }
        _onFinish() {
          this._finished || (this._finished = !0, this._onDoneFns.forEach(Z => Z()), this._onDoneFns = [])
        }
        onStart(Z) {
          this._originalOnStartFns.push(Z), this._onStartFns.push(Z)
        }
        onDone(Z) {
          this._originalOnDoneFns.push(Z), this._onDoneFns.push(Z)
        }
        onDestroy(Z) {
          this._onDestroyFns.push(Z)
        }
        hasStarted() {
          return this._started
        }
        init() {}
        play() {
          this.hasStarted() || (this._onStart(), this.triggerMicrotask()), this._started = !0
        }
        triggerMicrotask() {
          queueMicrotask(() => this._onFinish())
        }
        _onStart() {
          this._onStartFns.forEach(Z => Z()), this._onStartFns = []
        }
        pause() {}
        restart() {}
        finish() {
          this._onFinish()
        }
        destroy() {
          this._destroyed || (this._destroyed = !0, this.hasStarted() || this._onStart(), this.finish(), this
            ._onDestroyFns.forEach(Z => Z()), this._onDestroyFns = [])
        }
        reset() {
          this._started = !1, this._finished = !1, this._onStartFns = this._originalOnStartFns, this
            ._onDoneFns = this._originalOnDoneFns
        }
        setPosition(Z) {
          this._position = this.totalTime ? Z * this.totalTime : 1
        }
        getPosition() {
          return this.totalTime ? this._position / this.totalTime : 1
        }
        triggerCallback(Z) {
          const xe = "start" == Z ? this._onStartFns : this._onDoneFns;
          xe.forEach(be => be()), xe.length = 0
        }
      }
      class Re {
        constructor(Z) {
          this._onDoneFns = [], this._onStartFns = [], this._finished = !1, this._started = !1, this
            ._destroyed = !1, this._onDestroyFns = [], this.parentPlayer = null, this.totalTime = 0, this
            .players = Z;
          let xe = 0,
            be = 0,
            et = 0;
          const Et = this.players.length;
          0 == Et ? queueMicrotask(() => this._onFinish()) : this.players.forEach(Ht => {
            Ht.onDone(() => {
              ++xe == Et && this._onFinish()
            }), Ht.onDestroy(() => {
              ++be == Et && this._onDestroy()
            }), Ht.onStart(() => {
              ++et == Et && this._onStart()
            })
          }), this.totalTime = this.players.reduce((Ht, Zt) => Math.max(Ht, Zt.totalTime), 0)
        }
        _onFinish() {
          this._finished || (this._finished = !0, this._onDoneFns.forEach(Z => Z()), this._onDoneFns = [])
        }
        init() {
          this.players.forEach(Z => Z.init())
        }
        onStart(Z) {
          this._onStartFns.push(Z)
        }
        _onStart() {
          this.hasStarted() || (this._started = !0, this._onStartFns.forEach(Z => Z()), this._onStartFns = [])
        }
        onDone(Z) {
          this._onDoneFns.push(Z)
        }
        onDestroy(Z) {
          this._onDestroyFns.push(Z)
        }
        hasStarted() {
          return this._started
        }
        play() {
          this.parentPlayer || this.init(), this._onStart(), this.players.forEach(Z => Z.play())
        }
        pause() {
          this.players.forEach(Z => Z.pause())
        }
        restart() {
          this.players.forEach(Z => Z.restart())
        }
        finish() {
          this._onFinish(), this.players.forEach(Z => Z.finish())
        }
        destroy() {
          this._onDestroy()
        }
        _onDestroy() {
          this._destroyed || (this._destroyed = !0, this._onFinish(), this.players.forEach(Z => Z.destroy()),
            this._onDestroyFns.forEach(Z => Z()), this._onDestroyFns = [])
        }
        reset() {
          this.players.forEach(Z => Z.reset()), this._destroyed = !1, this._finished = !1, this._started = !1
        }
        setPosition(Z) {
          const xe = Z * this.totalTime;
          this.players.forEach(be => {
            const et = be.totalTime ? Math.min(1, xe / be.totalTime) : 1;
            be.setPosition(et)
          })
        }
        getPosition() {
          const Z = this.players.reduce((xe, be) => null === xe || be.totalTime > xe.totalTime ? be : xe, null);
          return null != Z ? Z.getPosition() : 0
        }
        beforeDestroy() {
          this.players.forEach(Z => {
            Z.beforeDestroy && Z.beforeDestroy()
          })
        }
        triggerCallback(Z) {
          const xe = "start" == Z ? this._onStartFns : this._onDoneFns;
          xe.forEach(be => be()), xe.length = 0
        }
      }
      const Be = "!"
    },
    177: (nt, Se, x) => {
      x.d(Se, {
        AJ: () => Ri,
        B3: () => lt,
        MD: () => Hr,
        N0: () => fi,
        QT: () => ee,
        Sm: () => qe,
        Sq: () => it,
        T3: () => Ye,
        UE: () => er,
        VF: () => A,
        Vy: () => bi,
        Xr: () => Zi,
        YU: () => pe,
        ZD: () => ae,
        _b: () => z,
        aZ: () => Ve,
        bT: () => Ft,
        fw: () => we,
        hb: () => me,
        hj: () => $,
        lG: () => Cr,
        qQ: () => M
      });
      var g = x(4438);
      let c = null;

      function ee() {
        return c
      }

      function ae(p) {
        c ??= p
      }
      class A {}
      const M = new g.nKC("");
      let V = (() => {
        class p {
          historyGo(D) {
            throw new Error("")
          }
          static #e = this.\u0275fac = function(S) {
            return new(S || p)
          };
          static #t = this.\u0275prov = g.jDH({
            token: p,
            factory: () => (0, g.WQX)(X),
            providedIn: "platform"
          })
        }
        return p
      })();
      const $ = new g.nKC("");
      let X = (() => {
        class p extends V {
          constructor() {
            super(), this._doc = (0, g.WQX)(M), this._location = window.location, this._history = window
              .history
          }
          getBaseHrefFromDOM() {
            return ee().getBaseHref(this._doc)
          }
          onPopState(D) {
            const S = ee().getGlobalEventTarget(this._doc, "window");
            return S.addEventListener("popstate", D, !1), () => S.removeEventListener("popstate", D)
          }
          onHashChange(D) {
            const S = ee().getGlobalEventTarget(this._doc, "window");
            return S.addEventListener("hashchange", D, !1), () => S.removeEventListener("hashchange", D)
          }
          get href() {
            return this._location.href
          }
          get protocol() {
            return this._location.protocol
          }
          get hostname() {
            return this._location.hostname
          }
          get port() {
            return this._location.port
          }
          get pathname() {
            return this._location.pathname
          }
          get search() {
            return this._location.search
          }
          get hash() {
            return this._location.hash
          }
          set pathname(D) {
            this._location.pathname = D
          }
          pushState(D, S, W) {
            this._history.pushState(D, S, W)
          }
          replaceState(D, S, W) {
            this._history.replaceState(D, S, W)
          }
          forward() {
            this._history.forward()
          }
          back() {
            this._history.back()
          }
          historyGo(D = 0) {
            this._history.go(D)
          }
          getState() {
            return this._history.state
          }
          static #e = this.\u0275fac = function(S) {
            return new(S || p)
          };
          static #t = this.\u0275prov = g.jDH({
            token: p,
            factory: () => new p,
            providedIn: "platform"
          })
        }
        return p
      })();

      function U(p, N) {
        if (0 == p.length) return N;
        if (0 == N.length) return p;
        let D = 0;
        return p.endsWith("/") && D++, N.startsWith("/") && D++, 2 == D ? p + N.substring(1) : 1 == D ? p + N :
          p + "/" + N
      }

      function le(p) {
        const N = p.match(/#|\?|$/),
          D = N && N.index || p.length;
        return p.slice(0, D - ("/" === p[D - 1] ? 1 : 0)) + p.slice(D)
      }

      function Ne(p) {
        return p && "?" !== p[0] ? "?" + p : p
      }
      let me = (() => {
        class p {
          historyGo(D) {
            throw new Error("")
          }
          static #e = this.\u0275fac = function(S) {
            return new(S || p)
          };
          static #t = this.\u0275prov = g.jDH({
            token: p,
            factory: () => (0, g.WQX)(qe),
            providedIn: "root"
          })
        }
        return p
      })();
      const Ae = new g.nKC("");
      let qe = (() => {
          class p extends me {
            constructor(D, S) {
              super(), this._platformLocation = D, this._removeListenerFns = [], this._baseHref = S ?? this
                ._platformLocation.getBaseHrefFromDOM() ?? (0, g.WQX)(M).location?.origin ?? ""
            }
            ngOnDestroy() {
              for (; this._removeListenerFns.length;) this._removeListenerFns.pop()()
            }
            onPopState(D) {
              this._removeListenerFns.push(this._platformLocation.onPopState(D), this._platformLocation
                .onHashChange(D))
            }
            getBaseHref() {
              return this._baseHref
            }
            prepareExternalUrl(D) {
              return U(this._baseHref, D)
            }
            path(D = !1) {
              const S = this._platformLocation.pathname + Ne(this._platformLocation.search),
                W = this._platformLocation.hash;
              return W && D ? `${S}${W}` : S
            }
            pushState(D, S, W, _e) {
              const Me = this.prepareExternalUrl(W + Ne(_e));
              this._platformLocation.pushState(D, S, Me)
            }
            replaceState(D, S, W, _e) {
              const Me = this.prepareExternalUrl(W + Ne(_e));
              this._platformLocation.replaceState(D, S, Me)
            }
            forward() {
              this._platformLocation.forward()
            }
            back() {
              this._platformLocation.back()
            }
            getState() {
              return this._platformLocation.getState()
            }
            historyGo(D = 0) {
              this._platformLocation.historyGo?.(D)
            }
            static #e = this.\u0275fac = function(S) {
              return new(S || p)(g.KVO(V), g.KVO(Ae, 8))
            };
            static #t = this.\u0275prov = g.jDH({
              token: p,
              factory: p.\u0275fac,
              providedIn: "root"
            })
          }
          return p
        })(),
        we = (() => {
          class p extends me {
            constructor(D, S) {
              super(), this._platformLocation = D, this._baseHref = "", this._removeListenerFns = [], null !=
                S && (this._baseHref = S)
            }
            ngOnDestroy() {
              for (; this._removeListenerFns.length;) this._removeListenerFns.pop()()
            }
            onPopState(D) {
              this._removeListenerFns.push(this._platformLocation.onPopState(D), this._platformLocation
                .onHashChange(D))
            }
            getBaseHref() {
              return this._baseHref
            }
            path(D = !1) {
              const S = this._platformLocation.hash ?? "#";
              return S.length > 0 ? S.substring(1) : S
            }
            prepareExternalUrl(D) {
              const S = U(this._baseHref, D);
              return S.length > 0 ? "#" + S : S
            }
            pushState(D, S, W, _e) {
              let Me = this.prepareExternalUrl(W + Ne(_e));
              0 == Me.length && (Me = this._platformLocation.pathname), this._platformLocation.pushState(D, S,
                Me)
            }
            replaceState(D, S, W, _e) {
              let Me = this.prepareExternalUrl(W + Ne(_e));
              0 == Me.length && (Me = this._platformLocation.pathname), this._platformLocation.replaceState(D,
                S, Me)
            }
            forward() {
              this._platformLocation.forward()
            }
            back() {
              this._platformLocation.back()
            }
            getState() {
              return this._platformLocation.getState()
            }
            historyGo(D = 0) {
              this._platformLocation.historyGo?.(D)
            }
            static #e = this.\u0275fac = function(S) {
              return new(S || p)(g.KVO(V), g.KVO(Ae, 8))
            };
            static #t = this.\u0275prov = g.jDH({
              token: p,
              factory: p.\u0275fac
            })
          }
          return p
        })(),
        Ve = (() => {
          class p {
            constructor(D) {
              this._subject = new g.bkB, this._urlChangeListeners = [], this._urlChangeSubscription = null,
                this._locationStrategy = D;
              const S = this._locationStrategy.getBaseHref();
              this._basePath = function Pe(p) {
                if (new RegExp("^(https?:)?//").test(p)) {
                  const [, D] = p.split(/\/\/[^\/]+/);
                  return D
                }
                return p
              }(le(ue(S))), this._locationStrategy.onPopState(W => {
                this._subject.emit({
                  url: this.path(!0),
                  pop: !0,
                  state: W.state,
                  type: W.type
                })
              })
            }
            ngOnDestroy() {
              this._urlChangeSubscription?.unsubscribe(), this._urlChangeListeners = []
            }
            path(D = !1) {
              return this.normalize(this._locationStrategy.path(D))
            }
            getState() {
              return this._locationStrategy.getState()
            }
            isCurrentPathEqualTo(D, S = "") {
              return this.path() == this.normalize(D + Ne(S))
            }
            normalize(D) {
              return p.stripTrailingSlash(function vt(p, N) {
                if (!p || !N.startsWith(p)) return N;
                const D = N.substring(p.length);
                return "" === D || ["/", ";", "?", "#"].includes(D[0]) ? D : N
              }(this._basePath, ue(D)))
            }
            prepareExternalUrl(D) {
              return D && "/" !== D[0] && (D = "/" + D), this._locationStrategy.prepareExternalUrl(D)
            }
            go(D, S = "", W = null) {
              this._locationStrategy.pushState(W, "", D, S), this._notifyUrlChangeListeners(this
                .prepareExternalUrl(D + Ne(S)), W)
            }
            replaceState(D, S = "", W = null) {
              this._locationStrategy.replaceState(W, "", D, S), this._notifyUrlChangeListeners(this
                .prepareExternalUrl(D + Ne(S)), W)
            }
            forward() {
              this._locationStrategy.forward()
            }
            back() {
              this._locationStrategy.back()
            }
            historyGo(D = 0) {
              this._locationStrategy.historyGo?.(D)
            }
            onUrlChange(D) {
              return this._urlChangeListeners.push(D), this._urlChangeSubscription ??= this.subscribe(S => {
                this._notifyUrlChangeListeners(S.url, S.state)
              }), () => {
                const S = this._urlChangeListeners.indexOf(D);
                this._urlChangeListeners.splice(S, 1), 0 === this._urlChangeListeners.length && (this
                  ._urlChangeSubscription?.unsubscribe(), this._urlChangeSubscription = null)
              }
            }
            _notifyUrlChangeListeners(D = "", S) {
              this._urlChangeListeners.forEach(W => W(D, S))
            }
            subscribe(D, S, W) {
              return this._subject.subscribe({
                next: D,
                error: S,
                complete: W
              })
            }
            static #e = this.normalizeQueryParams = Ne;
            static #t = this.joinWithSlash = U;
            static #n = this.stripTrailingSlash = le;
            static #r = this.\u0275fac = function(S) {
              return new(S || p)(g.KVO(me))
            };
            static #i = this.\u0275prov = g.jDH({
              token: p,
              factory: () => function Ze() {
                return new Ve((0, g.KVO)(me))
              }(),
              providedIn: "root"
            })
          }
          return p
        })();

      function ue(p) {
        return p.replace(/\/index.html$/, "")
      }

      function z(p, N) {
        N = encodeURIComponent(N);
        for (const D of p.split(";")) {
          const S = D.indexOf("="),
            [W, _e] = -1 == S ? [D, ""] : [D.slice(0, S), D.slice(S + 1)];
          if (W.trim() === N) return decodeURIComponent(_e)
        }
        return null
      }
      const K = /\s+/,
        Ee = [];
      let pe = (() => {
        class p {
          constructor(D, S) {
            this._ngEl = D, this._renderer = S, this.initialClasses = Ee, this.stateMap = new Map
          }
          set klass(D) {
            this.initialClasses = null != D ? D.trim().split(K) : Ee
          }
          set ngClass(D) {
            this.rawClass = "string" == typeof D ? D.trim().split(K) : D
          }
          ngDoCheck() {
            for (const S of this.initialClasses) this._updateState(S, !0);
            const D = this.rawClass;
            if (Array.isArray(D) || D instanceof Set)
              for (const S of D) this._updateState(S, !0);
            else if (null != D)
              for (const S of Object.keys(D)) this._updateState(S, !!D[S]);
            this._applyStateDiff()
          }
          _updateState(D, S) {
            const W = this.stateMap.get(D);
            void 0 !== W ? (W.enabled !== S && (W.changed = !0, W.enabled = S), W.touched = !0) : this
              .stateMap.set(D, {
                enabled: S,
                changed: !0,
                touched: !0
              })
          }
          _applyStateDiff() {
            for (const D of this.stateMap) {
              const S = D[0],
                W = D[1];
              W.changed ? (this._toggleClass(S, W.enabled), W.changed = !1) : W.touched || (W.enabled &&
                this._toggleClass(S, !1), this.stateMap.delete(S)), W.touched = !1
            }
          }
          _toggleClass(D, S) {
            (D = D.trim()).length > 0 && D.split(K).forEach(W => {
              S ? this._renderer.addClass(this._ngEl.nativeElement, W) : this._renderer.removeClass(this
                ._ngEl.nativeElement, W)
            })
          }
          static #e = this.\u0275fac = function(S) {
            return new(S || p)(g.rXU(g.aKT), g.rXU(g.sFG))
          };
          static #t = this.\u0275dir = g.FsC({
            type: p,
            selectors: [
              ["", "ngClass", ""]
            ],
            inputs: {
              klass: [g.Mj6.None, "class", "klass"],
              ngClass: "ngClass"
            },
            standalone: !0
          })
        }
        return p
      })();
      class _t {
        constructor(N, D, S, W) {
          this.$implicit = N, this.ngForOf = D, this.index = S, this.count = W
        }
        get first() {
          return 0 === this.index
        }
        get last() {
          return this.index === this.count - 1
        }
        get even() {
          return this.index % 2 == 0
        }
        get odd() {
          return !this.even
        }
      }
      let it = (() => {
        class p {
          set ngForOf(D) {
            this._ngForOf = D, this._ngForOfDirty = !0
          }
          set ngForTrackBy(D) {
            this._trackByFn = D
          }
          get ngForTrackBy() {
            return this._trackByFn
          }
          constructor(D, S, W) {
            this._viewContainer = D, this._template = S, this._differs = W, this._ngForOf = null, this
              ._ngForOfDirty = !0, this._differ = null
          }
          set ngForTemplate(D) {
            D && (this._template = D)
          }
          ngDoCheck() {
            if (this._ngForOfDirty) {
              this._ngForOfDirty = !1;
              const D = this._ngForOf;
              !this._differ && D && (this._differ = this._differs.find(D).create(this.ngForTrackBy))
            }
            if (this._differ) {
              const D = this._differ.diff(this._ngForOf);
              D && this._applyChanges(D)
            }
          }
          _applyChanges(D) {
            const S = this._viewContainer;
            D.forEachOperation((W, _e, Me) => {
              if (null == W.previousIndex) S.createEmbeddedView(this._template, new _t(W.item, this
                ._ngForOf, -1, -1), null === Me ? void 0 : Me);
              else if (null == Me) S.remove(null === _e ? void 0 : _e);
              else if (null !== _e) {
                const Je = S.get(_e);
                S.move(Je, Me), Qt(Je, W)
              }
            });
            for (let W = 0, _e = S.length; W < _e; W++) {
              const Je = S.get(W).context;
              Je.index = W, Je.count = _e, Je.ngForOf = this._ngForOf
            }
            D.forEachIdentityChange(W => {
              Qt(S.get(W.currentIndex), W)
            })
          }
          static ngTemplateContextGuard(D, S) {
            return !0
          }
          static #e = this.\u0275fac = function(S) {
            return new(S || p)(g.rXU(g.c1b), g.rXU(g.C4Q), g.rXU(g._q3))
          };
          static #t = this.\u0275dir = g.FsC({
            type: p,
            selectors: [
              ["", "ngFor", "", "ngForOf", ""]
            ],
            inputs: {
              ngForOf: "ngForOf",
              ngForTrackBy: "ngForTrackBy",
              ngForTemplate: "ngForTemplate"
            },
            standalone: !0
          })
        }
        return p
      })();

      function Qt(p, N) {
        p.context.$implicit = N.item
      }
      let Ft = (() => {
        class p {
          constructor(D, S) {
            this._viewContainer = D, this._context = new sn, this._thenTemplateRef = null, this
              ._elseTemplateRef = null, this._thenViewRef = null, this._elseViewRef = null, this
              ._thenTemplateRef = S
          }
          set ngIf(D) {
            this._context.$implicit = this._context.ngIf = D, this._updateView()
          }
          set ngIfThen(D) {
            ur("ngIfThen", D), this._thenTemplateRef = D, this._thenViewRef = null, this._updateView()
          }
          set ngIfElse(D) {
            ur("ngIfElse", D), this._elseTemplateRef = D, this._elseViewRef = null, this._updateView()
          }
          _updateView() {
            this._context.$implicit ? this._thenViewRef || (this._viewContainer.clear(), this._elseViewRef =
              null, this._thenTemplateRef && (this._thenViewRef = this._viewContainer.createEmbeddedView(
                this._thenTemplateRef, this._context))) : this._elseViewRef || (this._viewContainer
            .clear(), this._thenViewRef = null, this._elseTemplateRef && (this._elseViewRef = this
              ._viewContainer.createEmbeddedView(this._elseTemplateRef, this._context)))
          }
          static ngTemplateContextGuard(D, S) {
            return !0
          }
          static #e = this.\u0275fac = function(S) {
            return new(S || p)(g.rXU(g.c1b), g.rXU(g.C4Q))
          };
          static #t = this.\u0275dir = g.FsC({
            type: p,
            selectors: [
              ["", "ngIf", ""]
            ],
            inputs: {
              ngIf: "ngIf",
              ngIfThen: "ngIfThen",
              ngIfElse: "ngIfElse"
            },
            standalone: !0
          })
        }
        return p
      })();
      class sn {
        constructor() {
          this.$implicit = null, this.ngIf = null
        }
      }

      function ur(p, N) {
        if (N && !N.createEmbeddedView) throw new Error(
          `${p} must be a TemplateRef, but received '${(0,g.Tbb)(N)}'.`)
      }
      let lt = (() => {
          class p {
            constructor(D, S, W) {
              this._ngEl = D, this._differs = S, this._renderer = W, this._ngStyle = null, this._differ = null
            }
            set ngStyle(D) {
              this._ngStyle = D, !this._differ && D && (this._differ = this._differs.find(D).create())
            }
            ngDoCheck() {
              if (this._differ) {
                const D = this._differ.diff(this._ngStyle);
                D && this._applyChanges(D)
              }
            }
            _setStyle(D, S) {
              const [W, _e] = D.split("."), Me = -1 === W.indexOf("-") ? void 0 : g.czy.DashCase;
              null != S ? this._renderer.setStyle(this._ngEl.nativeElement, W, _e ? `${S}${_e}` : S, Me) :
                this._renderer.removeStyle(this._ngEl.nativeElement, W, Me)
            }
            _applyChanges(D) {
              D.forEachRemovedItem(S => this._setStyle(S.key, null)), D.forEachAddedItem(S => this._setStyle(S
                .key, S.currentValue)), D.forEachChangedItem(S => this._setStyle(S.key, S.currentValue))
            }
            static #e = this.\u0275fac = function(S) {
              return new(S || p)(g.rXU(g.aKT), g.rXU(g.MKu), g.rXU(g.sFG))
            };
            static #t = this.\u0275dir = g.FsC({
              type: p,
              selectors: [
                ["", "ngStyle", ""]
              ],
              inputs: {
                ngStyle: "ngStyle"
              },
              standalone: !0
            })
          }
          return p
        })(),
        Ye = (() => {
          class p {
            constructor(D) {
              this._viewContainerRef = D, this._viewRef = null, this.ngTemplateOutletContext = null, this
                .ngTemplateOutlet = null, this.ngTemplateOutletInjector = null
            }
            ngOnChanges(D) {
              if (this._shouldRecreateView(D)) {
                const S = this._viewContainerRef;
                if (this._viewRef && S.remove(S.indexOf(this._viewRef)), !this.ngTemplateOutlet) return void(
                  this._viewRef = null);
                const W = this._createContextForwardProxy();
                this._viewRef = S.createEmbeddedView(this.ngTemplateOutlet, W, {
                  injector: this.ngTemplateOutletInjector ?? void 0
                })
              }
            }
            _shouldRecreateView(D) {
              return !!D.ngTemplateOutlet || !!D.ngTemplateOutletInjector
            }
            _createContextForwardProxy() {
              return new Proxy({}, {
                set: (D, S, W) => !!this.ngTemplateOutletContext && Reflect.set(this
                  .ngTemplateOutletContext, S, W),
                get: (D, S, W) => {
                  if (this.ngTemplateOutletContext) return Reflect.get(this.ngTemplateOutletContext, S,
                    W)
                }
              })
            }
            static #e = this.\u0275fac = function(S) {
              return new(S || p)(g.rXU(g.c1b))
            };
            static #t = this.\u0275dir = g.FsC({
              type: p,
              selectors: [
                ["", "ngTemplateOutlet", ""]
              ],
              inputs: {
                ngTemplateOutletContext: "ngTemplateOutletContext",
                ngTemplateOutlet: "ngTemplateOutlet",
                ngTemplateOutletInjector: "ngTemplateOutletInjector"
              },
              standalone: !0,
              features: [g.OA$]
            })
          }
          return p
        })(),
        Cr = (() => {
          class p {
            constructor(D) {
              this.differs = D, this.keyValues = [], this.compareFn = Yi
            }
            transform(D, S = Yi) {
              if (!D || !(D instanceof Map) && "object" != typeof D) return null;
              this.differ ??= this.differs.find(D).create();
              const W = this.differ.diff(D),
                _e = S !== this.compareFn;
              return W && (this.keyValues = [], W.forEachItem(Me => {
                this.keyValues.push(function ss(p, N) {
                  return {
                    key: p,
                    value: N
                  }
                }(Me.key, Me.currentValue))
              })), (W || _e) && (this.keyValues.sort(S), this.compareFn = S), this.keyValues
            }
            static #e = this.\u0275fac = function(S) {
              return new(S || p)(g.rXU(g.MKu, 16))
            };
            static #t = this.\u0275pipe = g.EJ8({
              name: "keyvalue",
              type: p,
              pure: !1,
              standalone: !0
            })
          }
          return p
        })();

      function Yi(p, N) {
        const D = p.key,
          S = N.key;
        if (D === S) return 0;
        if (void 0 === D) return 1;
        if (void 0 === S) return -1;
        if (null === D) return 1;
        if (null === S) return -1;
        if ("string" == typeof D && "string" == typeof S) return D < S ? -1 : 1;
        if ("number" == typeof D && "number" == typeof S) return D - S;
        if ("boolean" == typeof D && "boolean" == typeof S) return D < S ? -1 : 1;
        const W = String(D),
          _e = String(S);
        return W == _e ? 0 : W < _e ? -1 : 1
      }
      let Hr = (() => {
        class p {
          static #e = this.\u0275fac = function(S) {
            return new(S || p)
          };
          static #t = this.\u0275mod = g.$C({
            type: p
          });
          static #n = this.\u0275inj = g.G2t({})
        }
        return p
      })();
      const Ri = "browser",
        Ms = "server";

      function er(p) {
        return p === Ri
      }

      function bi(p) {
        return p === Ms
      }
      let Zi = (() => {
        class p {
          static #e = this.\u0275prov = (0, g.jDH)({
            token: p,
            providedIn: "root",
            factory: () => er((0, g.WQX)(g.Agw)) ? new Bn((0, g.WQX)(M), window) : new di
          })
        }
        return p
      })();
      class Bn {
        constructor(N, D) {
          this.document = N, this.window = D, this.offset = () => [0, 0]
        }
        setOffset(N) {
          this.offset = Array.isArray(N) ? () => N : N
        }
        getScrollPosition() {
          return [this.window.scrollX, this.window.scrollY]
        }
        scrollToPosition(N) {
          this.window.scrollTo(N[0], N[1])
        }
        scrollToAnchor(N) {
          const D = function br(p, N) {
            const D = p.getElementById(N) || p.getElementsByName(N)[0];
            if (D) return D;
            if ("function" == typeof p.createTreeWalker && p.body && "function" == typeof p.body
              .attachShadow) {
              const S = p.createTreeWalker(p.body, NodeFilter.SHOW_ELEMENT);
              let W = S.currentNode;
              for (; W;) {
                const _e = W.shadowRoot;
                if (_e) {
                  const Me = _e.getElementById(N) || _e.querySelector(`[name="${N}"]`);
                  if (Me) return Me
                }
                W = S.nextNode()
              }
            }
            return null
          }(this.document, N);
          D && (this.scrollToElement(D), D.focus())
        }
        setHistoryScrollRestoration(N) {
          this.window.history.scrollRestoration = N
        }
        scrollToElement(N) {
          const D = N.getBoundingClientRect(),
            S = D.left + this.window.pageXOffset,
            W = D.top + this.window.pageYOffset,
            _e = this.offset();
          this.window.scrollTo(S - _e[0], W - _e[1])
        }
      }
      class di {
        setOffset(N) {}
        getScrollPosition() {
          return [0, 0]
        }
        scrollToPosition(N) {}
        scrollToAnchor(N) {}
        setHistoryScrollRestoration(N) {}
      }
      class fi {}
    },
    1626: (nt, Se, x) => {
      x.d(Se, {
        Nl: () => Pe,
        Qq: () => ve,
        q1: () => cr
      }), x(467);
      var c = x(4438),
        ee = x(7673),
        ae = x(1985),
        A = x(6648),
        k = x(274),
        M = x(5964),
        V = x(6354),
        $ = x(980),
        X = x(5558),
        U = x(177);
      class le {}
      class Ne {}
      class me {
        constructor(z) {
          this.normalizedNames = new Map, this.lazyUpdate = null, z ? "string" == typeof z ? this.lazyInit =
          () => {
              this.headers = new Map, z.split("\n").forEach(K => {
                const Ee = K.indexOf(":");
                if (Ee > 0) {
                  const pe = K.slice(0, Ee),
                    je = pe.toLowerCase(),
                    He = K.slice(Ee + 1).trim();
                  this.maybeSetNormalizedName(pe, je), this.headers.has(je) ? this.headers.get(je).push(
                    He) : this.headers.set(je, [He])
                }
              })
            } : typeof Headers < "u" && z instanceof Headers ? (this.headers = new Map, z.forEach((K, Ee) => {
              this.setHeaderEntries(Ee, K)
            })) : this.lazyInit = () => {
              this.headers = new Map, Object.entries(z).forEach(([K, Ee]) => {
                this.setHeaderEntries(K, Ee)
              })
            } : this.headers = new Map
        }
        has(z) {
          return this.init(), this.headers.has(z.toLowerCase())
        }
        get(z) {
          this.init();
          const K = this.headers.get(z.toLowerCase());
          return K && K.length > 0 ? K[0] : null
        }
        keys() {
          return this.init(), Array.from(this.normalizedNames.values())
        }
        getAll(z) {
          return this.init(), this.headers.get(z.toLowerCase()) || null
        }
        append(z, K) {
          return this.clone({
            name: z,
            value: K,
            op: "a"
          })
        }
        set(z, K) {
          return this.clone({
            name: z,
            value: K,
            op: "s"
          })
        }
        delete(z, K) {
          return this.clone({
            name: z,
            value: K,
            op: "d"
          })
        }
        maybeSetNormalizedName(z, K) {
          this.normalizedNames.has(K) || this.normalizedNames.set(K, z)
        }
        init() {
          this.lazyInit && (this.lazyInit instanceof me ? this.copyFrom(this.lazyInit) : this.lazyInit(), this
            .lazyInit = null, this.lazyUpdate && (this.lazyUpdate.forEach(z => this.applyUpdate(z)), this
              .lazyUpdate = null))
        }
        copyFrom(z) {
          z.init(), Array.from(z.headers.keys()).forEach(K => {
            this.headers.set(K, z.headers.get(K)), this.normalizedNames.set(K, z.normalizedNames.get(K))
          })
        }
        clone(z) {
          const K = new me;
          return K.lazyInit = this.lazyInit && this.lazyInit instanceof me ? this.lazyInit : this, K
            .lazyUpdate = (this.lazyUpdate || []).concat([z]), K
        }
        applyUpdate(z) {
          const K = z.name.toLowerCase();
          switch (z.op) {
            case "a":
            case "s":
              let Ee = z.value;
              if ("string" == typeof Ee && (Ee = [Ee]), 0 === Ee.length) return;
              this.maybeSetNormalizedName(z.name, K);
              const pe = ("a" === z.op ? this.headers.get(K) : void 0) || [];
              pe.push(...Ee), this.headers.set(K, pe);
              break;
            case "d":
              const je = z.value;
              if (je) {
                let He = this.headers.get(K);
                if (!He) return;
                He = He.filter(_t => -1 === je.indexOf(_t)), 0 === He.length ? (this.headers.delete(K), this
                  .normalizedNames.delete(K)) : this.headers.set(K, He)
              } else this.headers.delete(K), this.normalizedNames.delete(K)
          }
        }
        setHeaderEntries(z, K) {
          const Ee = (Array.isArray(K) ? K : [K]).map(je => je.toString()),
            pe = z.toLowerCase();
          this.headers.set(pe, Ee), this.maybeSetNormalizedName(z, pe)
        }
        forEach(z) {
          this.init(), Array.from(this.normalizedNames.keys()).forEach(K => z(this.normalizedNames.get(K), this
            .headers.get(K)))
        }
      }
      class qe {
        encodeKey(z) {
          return vt(z)
        }
        encodeValue(z) {
          return vt(z)
        }
        decodeKey(z) {
          return decodeURIComponent(z)
        }
        decodeValue(z) {
          return decodeURIComponent(z)
        }
      }
      const Ve = /%(\d[a-f0-9])/gi,
        Ze = {
          40: "@",
          "3A": ":",
          24: "$",
          "2C": ",",
          "3B": ";",
          "3D": "=",
          "3F": "?",
          "2F": "/"
        };

      function vt(B) {
        return encodeURIComponent(B).replace(Ve, (z, K) => Ze[K] ?? z)
      }

      function ue(B) {
        return `${B}`
      }
      class Pe {
        constructor(z = {}) {
          if (this.updates = null, this.cloneFrom = null, this.encoder = z.encoder || new qe, z.fromString) {
            if (z.fromObject) throw new Error("Cannot specify both fromString and fromObject.");
            this.map = function we(B, z) {
              const K = new Map;
              return B.length > 0 && B.replace(/^\?/, "").split("&").forEach(pe => {
                const je = pe.indexOf("="),
                  [He, _t] = -1 == je ? [z.decodeKey(pe), ""] : [z.decodeKey(pe.slice(0, je)), z
                    .decodeValue(pe.slice(je + 1))
                  ],
                  it = K.get(He) || [];
                it.push(_t), K.set(He, it)
              }), K
            }(z.fromString, this.encoder)
          } else z.fromObject ? (this.map = new Map, Object.keys(z.fromObject).forEach(K => {
            const Ee = z.fromObject[K],
              pe = Array.isArray(Ee) ? Ee.map(ue) : [ue(Ee)];
            this.map.set(K, pe)
          })) : this.map = null
        }
        has(z) {
          return this.init(), this.map.has(z)
        }
        get(z) {
          this.init();
          const K = this.map.get(z);
          return K ? K[0] : null
        }
        getAll(z) {
          return this.init(), this.map.get(z) || null
        }
        keys() {
          return this.init(), Array.from(this.map.keys())
        }
        append(z, K) {
          return this.clone({
            param: z,
            value: K,
            op: "a"
          })
        }
        appendAll(z) {
          const K = [];
          return Object.keys(z).forEach(Ee => {
            const pe = z[Ee];
            Array.isArray(pe) ? pe.forEach(je => {
              K.push({
                param: Ee,
                value: je,
                op: "a"
              })
            }) : K.push({
              param: Ee,
              value: pe,
              op: "a"
            })
          }), this.clone(K)
        }
        set(z, K) {
          return this.clone({
            param: z,
            value: K,
            op: "s"
          })
        }
        delete(z, K) {
          return this.clone({
            param: z,
            value: K,
            op: "d"
          })
        }
        toString() {
          return this.init(), this.keys().map(z => {
            const K = this.encoder.encodeKey(z);
            return this.map.get(z).map(Ee => K + "=" + this.encoder.encodeValue(Ee)).join("&")
          }).filter(z => "" !== z).join("&")
        }
        clone(z) {
          const K = new Pe({
            encoder: this.encoder
          });
          return K.cloneFrom = this.cloneFrom || this, K.updates = (this.updates || []).concat(z), K
        }
        init() {
          null === this.map && (this.map = new Map), null !== this.cloneFrom && (this.cloneFrom.init(), this
            .cloneFrom.keys().forEach(z => this.map.set(z, this.cloneFrom.map.get(z))), this.updates.forEach(
              z => {
                switch (z.op) {
                  case "a":
                  case "s":
                    const K = ("a" === z.op ? this.map.get(z.param) : void 0) || [];
                    K.push(ue(z.value)), this.map.set(z.param, K);
                    break;
                  case "d":
                    if (void 0 === z.value) {
                      this.map.delete(z.param);
                      break
                    } {
                      let Ee = this.map.get(z.param) || [];
                      const pe = Ee.indexOf(ue(z.value)); - 1 !== pe && Ee.splice(pe, 1), Ee.length > 0 ? this
                        .map.set(z.param, Ee) : this.map.delete(z.param)
                    }
                }
              }), this.cloneFrom = this.updates = null)
        }
      }
      class se {
        constructor() {
          this.map = new Map
        }
        set(z, K) {
          return this.map.set(z, K), this
        }
        get(z) {
          return this.map.has(z) || this.map.set(z, z.defaultValue()), this.map.get(z)
        }
        delete(z) {
          return this.map.delete(z), this
        }
        has(z) {
          return this.map.has(z)
        }
        keys() {
          return this.map.keys()
        }
      }

      function Be(B) {
        return typeof ArrayBuffer < "u" && B instanceof ArrayBuffer
      }

      function De(B) {
        return typeof Blob < "u" && B instanceof Blob
      }

      function Z(B) {
        return typeof FormData < "u" && B instanceof FormData
      }
      class be {
        constructor(z, K, Ee, pe) {
          let je;
          if (this.url = K, this.body = null, this.reportProgress = !1, this.withCredentials = !1, this
            .responseType = "json", this.method = z.toUpperCase(),
            function Re(B) {
              switch (B) {
                case "DELETE":
                case "GET":
                case "HEAD":
                case "OPTIONS":
                case "JSONP":
                  return !1;
                default:
                  return !0
              }
            }(this.method) || pe ? (this.body = void 0 !== Ee ? Ee : null, je = pe) : je = Ee, je && (this
              .reportProgress = !!je.reportProgress, this.withCredentials = !!je.withCredentials, je
              .responseType && (this.responseType = je.responseType), je.headers && (this.headers = je.headers),
              je.context && (this.context = je.context), je.params && (this.params = je.params), this
              .transferCache = je.transferCache), this.headers ??= new me, this.context ??= new se, this.params
            ) {
            const He = this.params.toString();
            if (0 === He.length) this.urlWithParams = K;
            else {
              const _t = K.indexOf("?");
              this.urlWithParams = K + (-1 === _t ? "?" : _t < K.length - 1 ? "&" : "") + He
            }
          } else this.params = new Pe, this.urlWithParams = K
        }
        serializeBody() {
          return null === this.body ? null : "string" == typeof this.body || Be(this.body) || De(this.body) ||
            Z(this.body) || function xe(B) {
              return typeof URLSearchParams < "u" && B instanceof URLSearchParams
            }(this.body) ? this.body : this.body instanceof Pe ? this.body.toString() : "object" == typeof this
            .body || "boolean" == typeof this.body || Array.isArray(this.body) ? JSON.stringify(this.body) :
            this.body.toString()
        }
        detectContentTypeHeader() {
          return null === this.body || Z(this.body) ? null : De(this.body) ? this.body.type || null : Be(this
              .body) ? null : "string" == typeof this.body ? "text/plain" : this.body instanceof Pe ?
            "application/x-www-form-urlencoded;charset=UTF-8" : "object" == typeof this.body || "number" ==
            typeof this.body || "boolean" == typeof this.body ? "application/json" : null
        }
        clone(z = {}) {
          const K = z.method || this.method,
            Ee = z.url || this.url,
            pe = z.responseType || this.responseType,
            je = z.transferCache ?? this.transferCache,
            He = void 0 !== z.body ? z.body : this.body,
            _t = z.withCredentials ?? this.withCredentials,
            it = z.reportProgress ?? this.reportProgress;
          let Qt = z.headers || this.headers,
            Xt = z.params || this.params;
          const Ft = z.context ?? this.context;
          return void 0 !== z.setHeaders && (Qt = Object.keys(z.setHeaders).reduce((sn, ur) => sn.set(ur, z
            .setHeaders[ur]), Qt)), z.setParams && (Xt = Object.keys(z.setParams).reduce((sn, ur) => sn.set(
            ur, z.setParams[ur]), Xt)), new be(K, Ee, He, {
            params: Xt,
            headers: Qt,
            context: Ft,
            reportProgress: it,
            responseType: pe,
            withCredentials: _t,
            transferCache: je
          })
        }
      }
      var et = function(B) {
        return B[B.Sent = 0] = "Sent", B[B.UploadProgress = 1] = "UploadProgress", B[B.ResponseHeader = 2] =
          "ResponseHeader", B[B.DownloadProgress = 3] = "DownloadProgress", B[B.Response = 4] = "Response", B[B
            .User = 5] = "User", B
      }(et || {});
      class Et {
        constructor(z, K = he.Ok, Ee = "OK") {
          this.headers = z.headers || new me, this.status = void 0 !== z.status ? z.status : K, this
            .statusText = z.statusText || Ee, this.url = z.url || null, this.ok = this.status >= 200 && this
            .status < 300
        }
      }
      class Ht extends Et {
        constructor(z = {}) {
          super(z), this.type = et.ResponseHeader
        }
        clone(z = {}) {
          return new Ht({
            headers: z.headers || this.headers,
            status: void 0 !== z.status ? z.status : this.status,
            statusText: z.statusText || this.statusText,
            url: z.url || this.url || void 0
          })
        }
      }
      class Zt extends Et {
        constructor(z = {}) {
          super(z), this.type = et.Response, this.body = void 0 !== z.body ? z.body : null
        }
        clone(z = {}) {
          return new Zt({
            body: void 0 !== z.body ? z.body : this.body,
            headers: z.headers || this.headers,
            status: void 0 !== z.status ? z.status : this.status,
            statusText: z.statusText || this.statusText,
            url: z.url || this.url || void 0
          })
        }
      }
      class Yn extends Et {
        constructor(z) {
          super(z, 0, "Unknown Error"), this.name = "HttpErrorResponse", this.ok = !1, this.message = this
            .status >= 200 && this.status < 300 ? `Http failure during parsing for ${z.url||"(unknown url)"}` :
            `Http failure response for ${z.url||"(unknown url)"}: ${z.status} ${z.statusText}`, this.error = z
            .error || null
        }
      }
      var he = function(B) {
        return B[B.Continue = 100] = "Continue", B[B.SwitchingProtocols = 101] = "SwitchingProtocols", B[B
            .Processing = 102] = "Processing", B[B.EarlyHints = 103] = "EarlyHints", B[B.Ok = 200] = "Ok", B[B
            .Created = 201] = "Created", B[B.Accepted = 202] = "Accepted", B[B.NonAuthoritativeInformation =
            203] = "NonAuthoritativeInformation", B[B.NoContent = 204] = "NoContent", B[B.ResetContent = 205] =
          "ResetContent", B[B.PartialContent = 206] = "PartialContent", B[B.MultiStatus = 207] = "MultiStatus",
          B[B.AlreadyReported = 208] = "AlreadyReported", B[B.ImUsed = 226] = "ImUsed", B[B.MultipleChoices =
            300] = "MultipleChoices", B[B.MovedPermanently = 301] = "MovedPermanently", B[B.Found = 302] =
          "Found", B[B.SeeOther = 303] = "SeeOther", B[B.NotModified = 304] = "NotModified", B[B.UseProxy =
          305] = "UseProxy", B[B.Unused = 306] = "Unused", B[B.TemporaryRedirect = 307] = "TemporaryRedirect",
          B[B.PermanentRedirect = 308] = "PermanentRedirect", B[B.BadRequest = 400] = "BadRequest", B[B
            .Unauthorized = 401] = "Unauthorized", B[B.PaymentRequired = 402] = "PaymentRequired", B[B
            .Forbidden = 403] = "Forbidden", B[B.NotFound = 404] = "NotFound", B[B.MethodNotAllowed = 405] =
          "MethodNotAllowed", B[B.NotAcceptable = 406] = "NotAcceptable", B[B.ProxyAuthenticationRequired =
          407] = "ProxyAuthenticationRequired", B[B.RequestTimeout = 408] = "RequestTimeout", B[B.Conflict =
            409] = "Conflict", B[B.Gone = 410] = "Gone", B[B.LengthRequired = 411] = "LengthRequired", B[B
            .PreconditionFailed = 412] = "PreconditionFailed", B[B.PayloadTooLarge = 413] = "PayloadTooLarge",
          B[B.UriTooLong = 414] = "UriTooLong", B[B.UnsupportedMediaType = 415] = "UnsupportedMediaType", B[B
            .RangeNotSatisfiable = 416] = "RangeNotSatisfiable", B[B.ExpectationFailed = 417] =
          "ExpectationFailed", B[B.ImATeapot = 418] = "ImATeapot", B[B.MisdirectedRequest = 421] =
          "MisdirectedRequest", B[B.UnprocessableEntity = 422] = "UnprocessableEntity", B[B.Locked = 423] =
          "Locked", B[B.FailedDependency = 424] = "FailedDependency", B[B.TooEarly = 425] = "TooEarly", B[B
            .UpgradeRequired = 426] = "UpgradeRequired", B[B.PreconditionRequired = 428] =
          "PreconditionRequired", B[B.TooManyRequests = 429] = "TooManyRequests", B[B
            .RequestHeaderFieldsTooLarge = 431] = "RequestHeaderFieldsTooLarge", B[B
            .UnavailableForLegalReasons = 451] = "UnavailableForLegalReasons", B[B.InternalServerError = 500] =
          "InternalServerError", B[B.NotImplemented = 501] = "NotImplemented", B[B.BadGateway = 502] =
          "BadGateway", B[B.ServiceUnavailable = 503] = "ServiceUnavailable", B[B.GatewayTimeout = 504] =
          "GatewayTimeout", B[B.HttpVersionNotSupported = 505] = "HttpVersionNotSupported", B[B
            .VariantAlsoNegotiates = 506] = "VariantAlsoNegotiates", B[B.InsufficientStorage = 507] =
          "InsufficientStorage", B[B.LoopDetected = 508] = "LoopDetected", B[B.NotExtended = 510] =
          "NotExtended", B[B.NetworkAuthenticationRequired = 511] = "NetworkAuthenticationRequired", B
      }(he || {});

      function ye(B, z) {
        return {
          body: z,
          headers: B.headers,
          context: B.context,
          observe: B.observe,
          params: B.params,
          reportProgress: B.reportProgress,
          responseType: B.responseType,
          withCredentials: B.withCredentials,
          transferCache: B.transferCache
        }
      }
      let ve = (() => {
        class B {
          constructor(K) {
            this.handler = K
          }
          request(K, Ee, pe = {}) {
            let je;
            if (K instanceof be) je = K;
            else {
              let it, Qt;
              it = pe.headers instanceof me ? pe.headers : new me(pe.headers), pe.params && (Qt = pe
                .params instanceof Pe ? pe.params : new Pe({
                  fromObject: pe.params
                })), je = new be(K, Ee, void 0 !== pe.body ? pe.body : null, {
                headers: it,
                context: pe.context,
                params: Qt,
                reportProgress: pe.reportProgress,
                responseType: pe.responseType || "json",
                withCredentials: pe.withCredentials,
                transferCache: pe.transferCache
              })
            }
            const He = (0, ee.of)(je).pipe((0, k.H)(it => this.handler.handle(it)));
            if (K instanceof be || "events" === pe.observe) return He;
            const _t = He.pipe((0, M.p)(it => it instanceof Zt));
            switch (pe.observe || "body") {
              case "body":
                switch (je.responseType) {
                  case "arraybuffer":
                    return _t.pipe((0, V.T)(it => {
                      if (null !== it.body && !(it.body instanceof ArrayBuffer)) throw new Error(
                        "Response is not an ArrayBuffer.");
                      return it.body
                    }));
                  case "blob":
                    return _t.pipe((0, V.T)(it => {
                      if (null !== it.body && !(it.body instanceof Blob)) throw new Error(
                        "Response is not a Blob.");
                      return it.body
                    }));
                  case "text":
                    return _t.pipe((0, V.T)(it => {
                      if (null !== it.body && "string" != typeof it.body) throw new Error(
                        "Response is not a string.");
                      return it.body
                    }));
                  default:
                    return _t.pipe((0, V.T)(it => it.body))
                }
              case "response":
                return _t;
              default:
                throw new Error(`Unreachable: unhandled observe type ${pe.observe}}`)
            }
          }
          delete(K, Ee = {}) {
            return this.request("DELETE", K, Ee)
          }
          get(K, Ee = {}) {
            return this.request("GET", K, Ee)
          }
          head(K, Ee = {}) {
            return this.request("HEAD", K, Ee)
          }
          jsonp(K, Ee) {
            return this.request("JSONP", K, {
              params: (new Pe).append(Ee, "JSONP_CALLBACK"),
              observe: "body",
              responseType: "json"
            })
          }
          options(K, Ee = {}) {
            return this.request("OPTIONS", K, Ee)
          }
          patch(K, Ee, pe = {}) {
            return this.request("PATCH", K, ye(pe, Ee))
          }
          post(K, Ee, pe = {}) {
            return this.request("POST", K, ye(pe, Ee))
          }
          put(K, Ee, pe = {}) {
            return this.request("PUT", K, ye(pe, Ee))
          }
          static #e = this.\u0275fac = function(Ee) {
            return new(Ee || B)(c.KVO(le))
          };
          static #t = this.\u0275prov = c.jDH({
            token: B,
            factory: B.\u0275fac
          })
        }
        return B
      })();

      function Ut(B, z) {
        return z(B)
      }

      function nn(B, z) {
        return (K, Ee) => z.intercept(K, {
          handle: pe => B(pe, Ee)
        })
      }
      const Ct = new c.nKC(""),
        dn = new c.nKC(""),
        Un = new c.nKC(""),
        rn = new c.nKC("");

      function Nn() {
        let B = null;
        return (z, K) => {
          null === B && (B = ((0, c.WQX)(Ct, {
            optional: !0
          }) ?? []).reduceRight(nn, Ut));
          const Ee = (0, c.WQX)(c.TgB),
            pe = Ee.add();
          return B(z, K).pipe((0, $.j)(() => Ee.remove(pe)))
        }
      }
      let yr = (() => {
        class B extends le {
          constructor(K, Ee) {
            super(), this.backend = K, this.injector = Ee, this.chain = null, this.pendingTasks = (0, c.WQX)
              (c.TgB);
            const pe = (0, c.WQX)(rn, {
              optional: !0
            });
            this.backend = pe ?? K
          }
          handle(K) {
            if (null === this.chain) {
              const pe = Array.from(new Set([...this.injector.get(dn), ...this.injector.get(Un, [])]));
              this.chain = pe.reduceRight((je, He) => function bt(B, z, K) {
                return (Ee, pe) => (0, c.N4e)(K, () => z(Ee, je => B(je, pe)))
              }(je, He, this.injector), Ut)
            }
            const Ee = this.pendingTasks.add();
            return this.chain(K, pe => this.backend.handle(pe)).pipe((0, $.j)(() => this.pendingTasks
              .remove(Ee)))
          }
          static #e = this.\u0275fac = function(Ee) {
            return new(Ee || B)(c.KVO(Ne), c.KVO(c.uvJ))
          };
          static #t = this.\u0275prov = c.jDH({
            token: B,
            factory: B.\u0275fac
          })
        }
        return B
      })();
      const ni = /^\)\]\}',?\n/;
      let Kr = (() => {
        class B {
          constructor(K) {
            this.xhrFactory = K
          }
          handle(K) {
            if ("JSONP" === K.method) throw new c.wOt(-2800, !1);
            const Ee = this.xhrFactory;
            return (Ee.\u0275loadImpl ? (0, A.H)(Ee.\u0275loadImpl()) : (0, ee.of)(null)).pipe((0, X.n)(
            () => new ae.c(je => {
                const He = Ee.build();
                if (He.open(K.method, K.urlWithParams), K.withCredentials && (He.withCredentials = !
                  0), K.headers.forEach((jt, kt) => He.setRequestHeader(jt, kt.join(","))), K.headers
                  .has("Accept") || He.setRequestHeader("Accept",
                  "application/json, text/plain, */*"), !K.headers.has("Content-Type")) {
                  const jt = K.detectContentTypeHeader();
                  null !== jt && He.setRequestHeader("Content-Type", jt)
                }
                if (K.responseType) {
                  const jt = K.responseType.toLowerCase();
                  He.responseType = "json" !== jt ? jt : "text"
                }
                const _t = K.serializeBody();
                let it = null;
                const Qt = () => {
                    if (null !== it) return it;
                    const jt = He.statusText || "OK",
                      kt = new me(He.getAllResponseHeaders()),
                      Dn = function dt(B) {
                        return "responseURL" in B && B.responseURL ? B.responseURL :
                          /^X-Request-URL:/m.test(B.getAllResponseHeaders()) ? B.getResponseHeader(
                            "X-Request-URL") : null
                      }(He) || K.url;
                    return it = new Ht({
                      headers: kt,
                      status: He.status,
                      statusText: jt,
                      url: Dn
                    }), it
                  },
                  Xt = () => {
                    let {
                      headers: jt,
                      status: kt,
                      statusText: Dn,
                      url: Dr
                    } = Qt(), wn = null;
                    kt !== he.NoContent && (wn = typeof He.response > "u" ? He.responseText : He
                      .response), 0 === kt && (kt = wn ? he.Ok : 0);
                    let Hn = kt >= 200 && kt < 300;
                    if ("json" === K.responseType && "string" == typeof wn) {
                      const dr = wn;
                      wn = wn.replace(ni, "");
                      try {
                        wn = "" !== wn ? JSON.parse(wn) : null
                      } catch (gn) {
                        wn = dr, Hn && (Hn = !1, wn = {
                          error: gn,
                          text: wn
                        })
                      }
                    }
                    Hn ? (je.next(new Zt({
                      body: wn,
                      headers: jt,
                      status: kt,
                      statusText: Dn,
                      url: Dr || void 0
                    })), je.complete()) : je.error(new Yn({
                      error: wn,
                      headers: jt,
                      status: kt,
                      statusText: Dn,
                      url: Dr || void 0
                    }))
                  },
                  Ft = jt => {
                    const {
                      url: kt
                    } = Qt(), Dn = new Yn({
                      error: jt,
                      status: He.status || 0,
                      statusText: He.statusText || "Unknown Error",
                      url: kt || void 0
                    });
                    je.error(Dn)
                  };
                let sn = !1;
                const ur = jt => {
                    sn || (je.next(Qt()), sn = !0);
                    let kt = {
                      type: et.DownloadProgress,
                      loaded: jt.loaded
                    };
                    jt.lengthComputable && (kt.total = jt.total), "text" === K.responseType && He
                      .responseText && (kt.partialText = He.responseText), je.next(kt)
                  },
                  Rn = jt => {
                    let kt = {
                      type: et.UploadProgress,
                      loaded: jt.loaded
                    };
                    jt.lengthComputable && (kt.total = jt.total), je.next(kt)
                  };
                return He.addEventListener("load", Xt), He.addEventListener("error", Ft), He
                  .addEventListener("timeout", Ft), He.addEventListener("abort", Ft), K
                  .reportProgress && (He.addEventListener("progress", ur), null !== _t && He.upload &&
                    He.upload.addEventListener("progress", Rn)), He.send(_t), je.next({
                    type: et.Sent
                  }), () => {
                    He.removeEventListener("error", Ft), He.removeEventListener("abort", Ft), He
                      .removeEventListener("load", Xt), He.removeEventListener("timeout", Ft), K
                      .reportProgress && (He.removeEventListener("progress", ur), null !== _t && He
                        .upload && He.upload.removeEventListener("progress", Rn)), He.readyState !==
                      He.DONE && He.abort()
                  }
              })))
          }
          static #e = this.\u0275fac = function(Ee) {
            return new(Ee || B)(c.KVO(U.N0))
          };
          static #t = this.\u0275prov = c.jDH({
            token: B,
            factory: B.\u0275fac
          })
        }
        return B
      })();
      const zt = new c.nKC(""),
        _r = new c.nKC("", {
          providedIn: "root",
          factory: () => "XSRF-TOKEN"
        }),
        Kn = new c.nKC("", {
          providedIn: "root",
          factory: () => "X-XSRF-TOKEN"
        });
      class ri {}
      let Di = (() => {
        class B {
          constructor(K, Ee, pe) {
            this.doc = K, this.platform = Ee, this.cookieName = pe, this.lastCookieString = "", this
              .lastToken = null, this.parseCount = 0
          }
          getToken() {
            if ("server" === this.platform) return null;
            const K = this.doc.cookie || "";
            return K !== this.lastCookieString && (this.parseCount++, this.lastToken = (0, U._b)(K, this
              .cookieName), this.lastCookieString = K), this.lastToken
          }
          static #e = this.\u0275fac = function(Ee) {
            return new(Ee || B)(c.KVO(U.qQ), c.KVO(c.Agw), c.KVO(_r))
          };
          static #t = this.\u0275prov = c.jDH({
            token: B,
            factory: B.\u0275fac
          })
        }
        return B
      })();

      function qn(B, z) {
        const K = B.url.toLowerCase();
        if (!(0, c.WQX)(zt) || "GET" === B.method || "HEAD" === B.method || K.startsWith("http://") || K
          .startsWith("https://")) return z(B);
        const Ee = (0, c.WQX)(ri).getToken(),
          pe = (0, c.WQX)(Kn);
        return null != Ee && !B.headers.has(pe) && (B = B.clone({
          headers: B.headers.set(pe, Ee)
        })), z(B)
      }
      var te = function(B) {
        return B[B.Interceptors = 0] = "Interceptors", B[B.LegacyInterceptors = 1] = "LegacyInterceptors", B[B
            .CustomXsrfConfiguration = 2] = "CustomXsrfConfiguration", B[B.NoXsrfProtection = 3] =
          "NoXsrfProtection", B[B.JsonpSupport = 4] = "JsonpSupport", B[B.RequestsMadeViaParent = 5] =
          "RequestsMadeViaParent", B[B.Fetch = 6] = "Fetch", B
      }(te || {});

      function J(...B) {
        const z = [ve, Kr, yr, {
          provide: le,
          useExisting: yr
        }, {
          provide: Ne,
          useExisting: Kr
        }, {
          provide: dn,
          useValue: qn,
          multi: !0
        }, {
          provide: zt,
          useValue: !0
        }, {
          provide: ri,
          useClass: Di
        }];
        for (const K of B) z.push(...K.\u0275providers);
        return (0, c.EmA)(z)
      }
      const Qe = new c.nKC("");

      function ct() {
        return function H(B, z) {
          return {
            \u0275kind: B,
            \u0275providers: z
          }
        }(te.LegacyInterceptors, [{
          provide: Qe,
          useFactory: Nn
        }, {
          provide: dn,
          useExisting: Qe,
          multi: !0
        }])
      }
      let cr = (() => {
        class B {
          static #e = this.\u0275fac = function(Ee) {
            return new(Ee || B)
          };
          static #t = this.\u0275mod = c.$C({
            type: B
          });
          static #n = this.\u0275inj = c.G2t({
            providers: [J(ct())]
          })
        }
        return B
      })()
    },
    4438: (nt, Se, x) => {
      function c(e, t) {
        return Object.is(e, t)
      }
      x.d(Se, {
        bc$: () => vC,
        iLQ: () => hh,
        sZ2: () => Bp,
        hnV: () => oD,
        Hbi: () => MA,
        o8S: () => bo,
        BIS: () => _C,
        gRc: () => _D,
        Ql9: () => JT,
        Ocv: () => aA,
        Z63: () => hi,
        aKT: () => sl,
        uvJ: () => Wr,
        zcH: () => so,
        bkB: () => js,
        $GK: () => At,
        nKC: () => pe,
        zZn: () => Hi,
        _q3: () => Eh,
        MKu: () => Ch,
        xe9: () => Du,
        Co$: () => ty,
        Vns: () => qo,
        SKi: () => mr,
        Xx1: () => er,
        Agw: () => rd,
        PLl: () => Up,
        sFG: () => Ww,
        _9s: () => cm,
        czy: () => Ic,
        WPN: () => Go,
        kdw: () => ui,
        C4Q: () => bl,
        NYb: () => zT,
        giA: () => iD,
        RxE: () => X_,
        c1b: () => zc,
        gXe: () => pi,
        mal: () => mm,
        L39: () => nO,
        EWP: () => sO,
        Ol2: () => vf,
        w6W: () => $0,
        oH4: () => gD,
        QZP: () => XD,
        SmG: () => fA,
        Rfq: () => qn,
        WQX: () => pt,
        QuC: () => Ir,
        EmA: () => ts,
        Udg: () => rO,
        fpN: () => IA,
        HJs: () => dO,
        N4e: () => hs,
        vPA: () => km,
        O8t: () => oO,
        An2: () => jc,
        H3F: () => Y_,
        H8p: () => eo,
        KH2: () => Wa,
        TgB: () => Sa,
        wOt: () => Ke,
        WHO: () => nD,
        e01: () => rD,
        lNU: () => Nn,
        h9k: () => sg,
        $MX: () => Cc,
        ZF7: () => ya,
        Kcf: () => BC,
        e5t: () => $C,
        UyX: () => jC,
        cWb: () => UC,
        osQ: () => HC,
        H5H: () => Wf,
        Zy3: () => zn,
        mq5: () => rv,
        JZv: () => dt,
        LfX: () => Ni,
        plB: () => _o,
        jNT: () => dh,
        zjR: () => sD,
        TL$: () => mC,
        Tbb: () => Jt,
        rcV: () => oo,
        Vt3: () => gf,
        Mj6: () => ki,
        GFd: () => ey,
        OA$: () => y,
        Jv_: () => g_,
        aNF: () => m_,
        R7$: () => Rg,
        BMQ: () => Af,
        HbH: () => Hy,
        AVh: () => Lf,
        wni: () => Wv,
        VBU: () => Mo,
        FsC: () => Ui,
        jDH: () => Gt,
        G2t: () => si,
        $C: () => Xs,
        EJ8: () => fo,
        rXU: () => Da,
        nrm: () => Hf,
        eu8: () => $f,
        bVm: () => lu,
        qex: () => au,
        k0s: () => ou,
        j41: () => su,
        RV6: () => ev,
        xGo: () => lp,
        KVO: () => en,
        kS0: () => cc,
        QTQ: () => Fg,
        bIt: () => Kf,
        lsd: () => Kv,
        qSk: () => qh,
        XpG: () => Fv,
        nI1: () => R_,
        bMT: () => P_,
        SdG: () => Lv,
        NAR: () => xv,
        Y8G: () => Pf,
        FS9: () => Qf,
        Mz_: () => hu,
        FCK: () => Xf,
        lJ4: () => v_,
        eq3: () => __,
        l_i: () => D_,
        sMw: () => E_,
        ziG: () => C_,
        s1E: () => b_,
        l4e: () => w_,
        sGs: () => S_,
        zJS: () => I_,
        mGM: () => zv,
        sdS: () => qv,
        Njj: () => Vh,
        EBC: () => fg,
        eBV: () => kh,
        npT: () => og,
        B4B: () => Dd,
        n$t: () => lg,
        Aen: () => Ds,
        xc7: () => xf,
        DNE: () => Ia,
        C5r: () => F_,
        EFF: () => i_,
        JRh: () => Yf,
        SpI: () => pu,
        Lme: () => Zf,
        DH7: () => h_,
        mxI: () => eh,
        R50: () => Jf,
        GBs: () => Gv
      }), x(467);
      let ee = null,
        ae = !1,
        A = 1;
      const k = Symbol("SIGNAL");

      function M(e) {
        const t = ee;
        return ee = e, t
      }
      const U = {
        version: 0,
        lastCleanEpoch: 0,
        dirty: !1,
        producerNode: void 0,
        producerLastReadVersion: void 0,
        producerIndexOfThis: void 0,
        nextProducerIndex: 0,
        liveConsumerNode: void 0,
        liveConsumerIndexOfThis: void 0,
        consumerAllowSignalWrites: !1,
        consumerIsAlwaysLive: !1,
        producerMustRecompute: () => !1,
        producerRecomputeValue: () => {},
        consumerMarkedDirty: () => {},
        consumerOnSignalRead: () => {}
      };

      function le(e) {
        if (ae) throw new Error("");
        if (null === ee) return;
        ee.consumerOnSignalRead(e);
        const t = ee.nextProducerIndex++;
        Re(ee), t < ee.producerNode.length && ee.producerNode[t] !== e && se(ee) && ie(ee.producerNode[t], ee
          .producerIndexOfThis[t]), ee.producerNode[t] !== e && (ee.producerNode[t] = e, ee.producerIndexOfThis[
          t] = se(ee) ? Pe(e, ee, t) : 0), ee.producerLastReadVersion[t] = e.version
      }

      function me(e) {
        if ((!se(e) || e.dirty) && (e.dirty || e.lastCleanEpoch !== A)) {
          if (!e.producerMustRecompute(e) && !vt(e)) return e.dirty = !1, void(e.lastCleanEpoch = A);
          e.producerRecomputeValue(e), e.dirty = !1, e.lastCleanEpoch = A
        }
      }

      function Ae(e) {
        if (void 0 === e.liveConsumerNode) return;
        const t = ae;
        ae = !0;
        try {
          for (const n of e.liveConsumerNode) n.dirty || we(n)
        } finally {
          ae = t
        }
      }

      function qe() {
        return !1 !== ee?.consumerAllowSignalWrites
      }

      function we(e) {
        e.dirty = !0, Ae(e), e.consumerMarkedDirty?.(e)
      }

      function Ve(e) {
        return e && (e.nextProducerIndex = 0), M(e)
      }

      function Ze(e, t) {
        if (M(t), e && void 0 !== e.producerNode && void 0 !== e.producerIndexOfThis && void 0 !== e
          .producerLastReadVersion) {
          if (se(e))
            for (let n = e.nextProducerIndex; n < e.producerNode.length; n++) ie(e.producerNode[n], e
              .producerIndexOfThis[n]);
          for (; e.producerNode.length > e.nextProducerIndex;) e.producerNode.pop(), e.producerLastReadVersion
            .pop(), e.producerIndexOfThis.pop()
        }
      }

      function vt(e) {
        Re(e);
        for (let t = 0; t < e.producerNode.length; t++) {
          const n = e.producerNode[t],
            r = e.producerLastReadVersion[t];
          if (r !== n.version || (me(n), r !== n.version)) return !0
        }
        return !1
      }

      function ue(e) {
        if (Re(e), se(e))
          for (let t = 0; t < e.producerNode.length; t++) ie(e.producerNode[t], e.producerIndexOfThis[t]);
        e.producerNode.length = e.producerLastReadVersion.length = e.producerIndexOfThis.length = 0, e
          .liveConsumerNode && (e.liveConsumerNode.length = e.liveConsumerIndexOfThis.length = 0)
      }

      function Pe(e, t, n) {
        if (Be(e), Re(e), 0 === e.liveConsumerNode.length)
          for (let r = 0; r < e.producerNode.length; r++) e.producerIndexOfThis[r] = Pe(e.producerNode[r], e, r);
        return e.liveConsumerIndexOfThis.push(n), e.liveConsumerNode.push(t) - 1
      }

      function ie(e, t) {
        if (Be(e), Re(e), 1 === e.liveConsumerNode.length)
          for (let r = 0; r < e.producerNode.length; r++) ie(e.producerNode[r], e.producerIndexOfThis[r]);
        const n = e.liveConsumerNode.length - 1;
        if (e.liveConsumerNode[t] = e.liveConsumerNode[n], e.liveConsumerIndexOfThis[t] = e
          .liveConsumerIndexOfThis[n], e.liveConsumerNode.length--, e.liveConsumerIndexOfThis.length--, t < e
          .liveConsumerNode.length) {
          const r = e.liveConsumerIndexOfThis[t],
            i = e.liveConsumerNode[t];
          Re(i), i.producerIndexOfThis[r] = t
        }
      }

      function se(e) {
        return e.consumerIsAlwaysLive || (e?.liveConsumerNode?.length ?? 0) > 0
      }

      function Re(e) {
        e.producerNode ??= [], e.producerIndexOfThis ??= [], e.producerLastReadVersion ??= []
      }

      function Be(e) {
        e.liveConsumerNode ??= [], e.liveConsumerIndexOfThis ??= []
      }
      const Z = Symbol("UNSET"),
        xe = Symbol("COMPUTING"),
        be = Symbol("ERRORED"),
        et = {
          ...U,
          value: Z,
          dirty: !0,
          error: null,
          equal: c,
          producerMustRecompute: e => e.value === Z || e.value === xe,
          producerRecomputeValue(e) {
            if (e.value === xe) throw new Error("Detected cycle in computations.");
            const t = e.value;
            e.value = xe;
            const n = Ve(e);
            let r;
            try {
              r = e.computation()
            } catch (i) {
              r = be, e.error = i
            } finally {
              Ze(e, n)
            }
            t !== Z && t !== be && r !== be && e.equal(t, r) ? e.value = t : (e.value = r, e.version++)
          }
        };
      let Ht = function Et() {
        throw new Error
      };

      function Zt() {
        Ht()
      }
      let he = null;

      function ke(e, t) {
        qe() || Zt(), e.equal(e.value, t) || (e.value = t, function Nt(e) {
          e.version++,
            function Ne() {
              A++
            }(), Ae(e), he?.()
        }(e))
      }
      const rt = {
        ...U,
        equal: c,
        value: void 0
      };
      const ht = () => {},
        Ut = {
          ...U,
          consumerIsAlwaysLive: !0,
          consumerAllowSignalWrites: !1,
          consumerMarkedDirty: e => {
            null !== e.schedule && e.schedule(e.ref)
          },
          hasRun: !1,
          cleanupFn: ht
        };
      var bt = x(1413),
        Ct = x(8359),
        dn = x(4412),
        Un = x(6354);
      const Nn = "https://g.co/ng/security#xss";
      class Ke extends Error {
        constructor(t, n) {
          super(zn(t, n)), this.code = t
        }
      }

      function zn(e, t) {
        return `NG0${Math.abs(e)}${t?": "+t:""}`
      }

      function Tt(e) {
        return {
          toString: e
        }.toString()
      }
      const zr = "__parameters__";

      function Mn(e, t, n) {
        return Tt(() => {
          const r = function Pr(e) {
            return function(...n) {
              if (e) {
                const r = e(...n);
                for (const i in r) this[i] = r[i]
              }
            }
          }(t);

          function i(...s) {
            if (this instanceof i) return r.apply(this, s), this;
            const o = new i(...s);
            return l.annotation = o, l;

            function l(h, E, O) {
              const L = h.hasOwnProperty(zr) ? h[zr] : Object.defineProperty(h, zr, {
                value: []
              })[zr];
              for (; L.length <= O;) L.push(null);
              return (L[O] = L[O] || []).push(o), h
            }
          }
          return n && (i.prototype = Object.create(n.prototype)), i.prototype.ngMetadataName = e, i
            .annotationCls = i, i
        })
      }
      const dt = globalThis;

      function Pt(e) {
        for (let t in e)
          if (e[t] === Pt) return t;
        throw Error("Could not find renamed property on target object.")
      }

      function _r(e, t) {
        for (const n in t) t.hasOwnProperty(n) && !e.hasOwnProperty(n) && (e[n] = t[n])
      }

      function Jt(e) {
        if ("string" == typeof e) return e;
        if (Array.isArray(e)) return "[" + e.map(Jt).join(", ") + "]";
        if (null == e) return "" + e;
        if (e.overriddenName) return `${e.overriddenName}`;
        if (e.name) return `${e.name}`;
        const t = e.toString();
        if (null == t) return "" + t;
        const n = t.indexOf("\n");
        return -1 === n ? t : t.substring(0, n)
      }

      function Kn(e, t) {
        return null == e || "" === e ? null === t ? "" : t : null == t || "" === t ? e : e + " " + t
      }
      const Di = Pt({
        __forward_ref__: Pt
      });

      function qn(e) {
        return e.__forward_ref__ = qn, e.toString = function() {
          return Jt(this())
        }, e
      }

      function re(e) {
        return te(e) ? e() : e
      }

      function te(e) {
        return "function" == typeof e && e.hasOwnProperty(Di) && e.__forward_ref__ === qn
      }

      function Gt(e) {
        return {
          token: e.token,
          providedIn: e.providedIn || null,
          factory: e.factory,
          value: void 0
        }
      }

      function si(e) {
        return {
          providers: e.providers || [],
          imports: e.imports || []
        }
      }

      function oi(e) {
        return Ei(e, B) || Ei(e, K)
      }

      function Ni(e) {
        return null !== oi(e)
      }

      function Ei(e, t) {
        return e.hasOwnProperty(t) ? e[t] : null
      }

      function Xr(e) {
        return e && (e.hasOwnProperty(z) || e.hasOwnProperty(Ee)) ? e[z] : null
      }
      const B = Pt({
          \u0275prov: Pt
        }),
        z = Pt({
          \u0275inj: Pt
        }),
        K = Pt({
          ngInjectableDef: Pt
        }),
        Ee = Pt({
          ngInjectorDef: Pt
        });
      class pe {
        constructor(t, n) {
          this._desc = t, this.ngMetadataName = "InjectionToken", this.\u0275prov = void 0, "number" ==
            typeof n ? this.__NG_ELEMENT_ID__ = n : void 0 !== n && (this.\u0275prov = Gt({
              token: this,
              providedIn: n.providedIn || "root",
              factory: n.factory
            }))
        }
        get multi() {
          return this
        }
        toString() {
          return `InjectionToken ${this._desc}`
        }
      }

      function jt(e) {
        return e && !!e.\u0275providers
      }
      const kt = Pt({
          \u0275cmp: Pt
        }),
        Dn = Pt({
          \u0275dir: Pt
        }),
        Dr = Pt({
          \u0275pipe: Pt
        }),
        wn = Pt({
          \u0275mod: Pt
        }),
        Hn = Pt({
          \u0275fac: Pt
        }),
        dr = Pt({
          __NG_ELEMENT_ID__: Pt
        }),
        gn = Pt({
          __NG_ENV_ID__: Pt
        });

      function lt(e) {
        return "string" == typeof e ? e : null == e ? "" : String(e)
      }

      function li(e, t) {
        throw new Ke(-201, !1)
      }
      var At = function(e) {
        return e[e.Default = 0] = "Default", e[e.Host = 1] = "Host", e[e.Self = 2] = "Self", e[e.SkipSelf = 4] =
          "SkipSelf", e[e.Optional = 8] = "Optional", e
      }(At || {});
      let Br;

      function Ki() {
        return Br
      }

      function Vn(e) {
        const t = Br;
        return Br = e, t
      }

      function Ss(e, t, n) {
        const r = oi(e);
        return r && "root" == r.providedIn ? void 0 === r.value ? r.value = r.factory() : r.value : n & At
          .Optional ? null : void 0 !== t ? t : void li()
      }
      const Ur = {},
        Qi = "__NG_DI_FLAG__",
        Ci = "ngTempTokenPath",
        Xi = /\n/gm,
        ss = "__source";
      let Cr;

      function Yr(e) {
        const t = Cr;
        return Cr = e, t
      }

      function zs(e, t = At.Default) {
        if (void 0 === Cr) throw new Ke(-203, !1);
        return null === Cr ? Ss(e, void 0, t) : Cr.get(e, t & At.Optional ? null : void 0, t)
      }

      function en(e, t = At.Default) {
        return (Ki() || zs)(re(e), t)
      }

      function pt(e, t = At.Default) {
        return en(e, jr(t))
      }

      function jr(e) {
        return typeof e > "u" || "number" == typeof e ? e : (e.optional && 8) | (e.host && 1) | (e.self && 2) | (e
          .skipSelf && 4)
      }

      function fr(e) {
        const t = [];
        for (let n = 0; n < e.length; n++) {
          const r = re(e[n]);
          if (Array.isArray(r)) {
            if (0 === r.length) throw new Ke(900, !1);
            let i, s = At.Default;
            for (let o = 0; o < r.length; o++) {
              const l = r[o],
                h = Ri(l);
              "number" == typeof h ? -1 === h ? i = l.token : s |= h : i = l
            }
            t.push(en(i, s))
          } else t.push(en(r))
        }
        return t
      }

      function Hr(e, t) {
        return e[Qi] = t, e.prototype[Qi] = t, e
      }

      function Ri(e) {
        return e[Qi]
      }
      const er = Hr(Mn("Optional"), 8),
        ui = Hr(Mn("SkipSelf"), 4);

      function Zr(e, t) {
        return e.hasOwnProperty(Hn) ? e[Hn] : null
      }

      function br(e, t) {
        e.forEach(n => Array.isArray(n) ? br(n, t) : t(n))
      }

      function di(e, t, n) {
        t >= e.length ? e.push(n) : e.splice(t, 0, n)
      }

      function fi(e, t) {
        return t >= e.length - 1 ? e.pop() : e.splice(t, 1)[0]
      }

      function tr(e, t, n) {
        let r = wr(e, t);
        return r >= 0 ? e[1 | r] = n : (r = ~r, function xi(e, t, n, r) {
          let i = e.length;
          if (i == t) e.push(n, r);
          else if (1 === i) e.push(r, e[0]), e[0] = n;
          else {
            for (i--, e.push(e[i - 1], e[i]); i > t;) e[i] = e[i - 2], i--;
            e[t] = n, e[t + 1] = r
          }
        }(e, r, t, n)), r
      }

      function Li(e, t) {
        const n = wr(e, t);
        if (n >= 0) return e[1 | n]
      }

      function wr(e, t) {
        return function co(e, t, n) {
          let r = 0,
            i = e.length >> n;
          for (; i !== r;) {
            const s = r + (i - r >> 1),
              o = e[s << n];
            if (t === o) return s << n;
            o > t ? i = s : r = s + 1
          }
          return ~(i << n)
        }(e, t, 1)
      }
      const nr = {},
        $t = [],
        hi = new pe(""),
        So = new pe("", -1),
        qs = new pe("");
      class Os {
        get(t, n = Ur) {
          if (n === Ur) {
            const r = new Error(`NullInjectorError: No provider for ${Jt(t)}!`);
            throw r.name = "NullInjectorError", r
          }
          return n
        }
      }
      var Ns = function(e) {
          return e[e.OnPush = 0] = "OnPush", e[e.Default = 1] = "Default", e
        }(Ns || {}),
        pi = function(e) {
          return e[e.Emulated = 0] = "Emulated", e[e.None = 2] = "None", e[e.ShadowDom = 3] = "ShadowDom", e
        }(pi || {}),
        ki = function(e) {
          return e[e.None = 0] = "None", e[e.SignalBased = 1] = "SignalBased", e[e.HasDecoratorInputTransform =
            2] = "HasDecoratorInputTransform", e
        }(ki || {});

      function Sr(e, t, n) {
        let r = e.length;
        for (;;) {
          const i = e.indexOf(t, n);
          if (-1 === i) return i;
          if (0 === i || e.charCodeAt(i - 1) <= 32) {
            const s = t.length;
            if (i + s === r || e.charCodeAt(i + s) <= 32) return i
          }
          n = i + 1
        }
      }

      function Vi(e, t, n) {
        let r = 0;
        for (; r < n.length;) {
          const i = n[r];
          if ("number" == typeof i) {
            if (0 !== i) break;
            r++;
            const s = n[r++],
              o = n[r++],
              l = n[r++];
            e.setAttribute(t, o, l, s)
          } else {
            const s = i,
              o = n[++r];
            T(s) ? e.setProperty(t, s, o) : e.setAttribute(t, s, o), r++
          }
        }
        return r
      }

      function I(e) {
        return 3 === e || 4 === e || 6 === e
      }

      function T(e) {
        return 64 === e.charCodeAt(0)
      }

      function _(e, t) {
        if (null !== t && 0 !== t.length)
          if (null === e || 0 === e.length) e = t.slice();
          else {
            let n = -1;
            for (let r = 0; r < t.length; r++) {
              const i = t[r];
              "number" == typeof i ? n = i : 0 === n || F(e, n, i, null, -1 === n || 2 === n ? t[++r] : null)
            }
          } return e
      }

      function F(e, t, n, r, i) {
        let s = 0,
          o = e.length;
        if (-1 === t) o = -1;
        else
          for (; s < e.length;) {
            const l = e[s++];
            if ("number" == typeof l) {
              if (l === t) {
                o = -1;
                break
              }
              if (l > t) {
                o = s - 1;
                break
              }
            }
          }
        for (; s < e.length;) {
          const l = e[s];
          if ("number" == typeof l) break;
          if (l === n) {
            if (null === r) return void(null !== i && (e[s + 1] = i));
            if (r === e[s + 1]) return void(e[s + 2] = i)
          }
          s++, null !== r && s++, null !== i && s++
        } - 1 !== o && (e.splice(o, 0, t), s = o + 1), e.splice(s++, 0, n), null !== r && e.splice(s++, 0, r),
          null !== i && e.splice(s++, 0, i)
      }
      const Y = "ng-template";

      function ut(e, t, n, r) {
        let i = 0;
        if (r) {
          for (; i < t.length && "string" == typeof t[i]; i += 2)
            if ("class" === t[i] && -1 !== Sr(t[i + 1].toLowerCase(), n, 0)) return !0
        } else if (Rt(e)) return !1;
        if (i = t.indexOf(1, i), i > -1) {
          let s;
          for (; ++i < t.length && "string" == typeof(s = t[i]);)
            if (s.toLowerCase() === n) return !0
        }
        return !1
      }

      function Rt(e) {
        return 4 === e.type && e.value !== Y
      }

      function hr(e, t, n) {
        return t === (4 !== e.type || n ? e.value : Y)
      }

      function gi(e, t, n) {
        let r = 4;
        const i = e.attrs,
          s = null !== i ? function Ji(e) {
            for (let t = 0; t < e.length; t++)
              if (I(e[t])) return t;
            return e.length
          }(i) : 0;
        let o = !1;
        for (let l = 0; l < t.length; l++) {
          const h = t[l];
          if ("number" != typeof h) {
            if (!o)
              if (4 & r) {
                if (r = 2 | 1 & r, "" !== h && !hr(e, h, n) || "" === h && 1 === t.length) {
                  if (Qn(r)) return !1;
                  o = !0
                }
              } else if (8 & r) {
              if (null === i || !ut(e, i, h, n)) {
                if (Qn(r)) return !1;
                o = !0
              }
            } else {
              const E = t[++l],
                O = uo(h, i, Rt(e), n);
              if (-1 === O) {
                if (Qn(r)) return !1;
                o = !0;
                continue
              }
              if ("" !== E) {
                let L;
                if (L = O > s ? "" : i[O + 1].toLowerCase(), 2 & r && E !== L) {
                  if (Qn(r)) return !1;
                  o = !0
                }
              }
            }
          } else {
            if (!o && !Qn(r) && !Qn(h)) return !1;
            if (o && Qn(h)) continue;
            o = !1, r = h | 1 & r
          }
        }
        return Qn(r) || o
      }

      function Qn(e) {
        return !(1 & e)
      }

      function uo(e, t, n, r) {
        if (null === t) return -1;
        let i = 0;
        if (r || !n) {
          let s = !1;
          for (; i < t.length;) {
            const o = t[i];
            if (o === e) return i;
            if (3 === o || 6 === o) s = !0;
            else {
              if (1 === o || 2 === o) {
                let l = t[++i];
                for (;
                  "string" == typeof l;) l = t[++i];
                continue
              }
              if (4 === o) break;
              if (0 === o) {
                i += 4;
                continue
              }
            }
            i += s ? 1 : 2
          }
          return -1
        }
        return function hn(e, t) {
          let n = e.indexOf(4);
          if (n > -1)
            for (n++; n < e.length;) {
              const r = e[n];
              if ("number" == typeof r) return -1;
              if (r === t) return n;
              n++
            }
          return -1
        }(t, e)
      }

      function Bi(e, t, n = !1) {
        for (let r = 0; r < t.length; r++)
          if (gi(e, t[r], n)) return !0;
        return !1
      }

      function Rs(e, t) {
        e: for (let n = 0; n < t.length; n++) {
          const r = t[n];
          if (e.length === r.length) {
            for (let i = 0; i < e.length; i++)
              if (e[i] !== r[i]) continue e;
            return !0
          }
        }
        return !1
      }

      function es(e, t) {
        return e ? ":not(" + t.trim() + ")" : t
      }

      function ea(e) {
        let t = e[0],
          n = 1,
          r = 2,
          i = "",
          s = !1;
        for (; n < e.length;) {
          let o = e[n];
          if ("string" == typeof o)
            if (2 & r) {
              const l = e[++n];
              i += "[" + o + (l.length > 0 ? '="' + l + '"' : "") + "]"
            } else 8 & r ? i += "." + o : 4 & r && (i += " " + o);
          else "" !== i && !Qn(o) && (t += es(s, i), i = ""), r = o, s = s || !Qn(r);
          n++
        }
        return "" !== i && (t += es(s, i)), t
      }

      function Mo(e) {
        return Tt(() => {
          const t = To(e),
            n = {
              ...t,
              decls: e.decls,
              vars: e.vars,
              template: e.template,
              consts: e.consts || null,
              ngContentSelectors: e.ngContentSelectors,
              onPush: e.changeDetection === Ns.OnPush,
              directiveDefs: null,
              pipeDefs: null,
              dependencies: t.standalone && e.dependencies || null,
              getStandaloneInjector: null,
              signals: e.signals ?? !1,
              data: e.data || {},
              encapsulation: e.encapsulation || pi.Emulated,
              styles: e.styles || $t,
              _: null,
              schemas: e.schemas || null,
              tView: null,
              id: ""
            };
          Ys(n);
          const r = e.dependencies;
          return n.directiveDefs = ls(r, !1), n.pipeDefs = ls(r, !0), n.id = function ta(e) {
            let t = 0;
            const n = [e.selectors, e.ngContentSelectors, e.hostVars, e.hostAttrs, e.consts, e.vars, e
              .decls, e.encapsulation, e.standalone, e.signals, e.exportAs, JSON.stringify(e.inputs), JSON
              .stringify(e.outputs), Object.getOwnPropertyNames(e.type.prototype), !!e.contentQueries, !!e
              .viewQuery
            ].join("|");
            for (const i of n) t = Math.imul(31, t) + i.charCodeAt(0) | 0;
            return t += 2147483648, "c" + t
          }(n), n
        })
      }

      function Fs(e) {
        return Vt(e) || Sn(e)
      }

      function Qs(e) {
        return null !== e
      }

      function Xs(e) {
        return Tt(() => ({
          type: e.type,
          bootstrap: e.bootstrap || $t,
          declarations: e.declarations || $t,
          imports: e.imports || $t,
          exports: e.exports || $t,
          transitiveCompileScopes: null,
          schemas: e.schemas || null,
          id: e.id || null
        }))
      }

      function as(e, t) {
        if (null == e) return nr;
        const n = {};
        for (const r in e)
          if (e.hasOwnProperty(r)) {
            const i = e[r];
            let s, o, l = ki.None;
            Array.isArray(i) ? (l = i[0], s = i[1], o = i[2] ?? s) : (s = i, o = i), t ? (n[s] = l !== ki.None ? [
              r, l
            ] : r, t[s] = o) : n[s] = r
          } return n
      }

      function Ui(e) {
        return Tt(() => {
          const t = To(e);
          return Ys(t), t
        })
      }

      function fo(e) {
        return {
          type: e.type,
          name: e.name,
          factory: null,
          pure: !1 !== e.pure,
          standalone: !0 === e.standalone,
          onDestroy: e.type.prototype.ngOnDestroy || null
        }
      }

      function Vt(e) {
        return e[kt] || null
      }

      function Sn(e) {
        return e[Dn] || null
      }

      function Pn(e) {
        return e[Dr] || null
      }

      function Ir(e) {
        const t = Vt(e) || Sn(e) || Pn(e);
        return null !== t && t.standalone
      }

      function rr(e, t) {
        const n = e[wn] || null;
        if (!n && !0 === t) throw new Error(`Type ${Jt(e)} does not have '\u0275mod' property.`);
        return n
      }

      function To(e) {
        const t = {};
        return {
          type: e.type,
          providersResolver: null,
          factory: null,
          hostBindings: e.hostBindings || null,
          hostVars: e.hostVars || 0,
          hostAttrs: e.hostAttrs || null,
          contentQueries: e.contentQueries || null,
          declaredInputs: t,
          inputTransforms: null,
          inputConfig: e.inputs || nr,
          exportAs: e.exportAs || null,
          standalone: !0 === e.standalone,
          signals: !0 === e.signals,
          selectors: e.selectors || $t,
          viewQuery: e.viewQuery || null,
          features: e.features || null,
          setInput: null,
          findHostDirectiveDefs: null,
          hostDirectives: null,
          inputs: as(e.inputs, t),
          outputs: as(e.outputs),
          debugInfo: null
        }
      }

      function Ys(e) {
        e.features?.forEach(t => t(e))
      }

      function ls(e, t) {
        if (!e) return null;
        const n = t ? Pn : Fs;
        return () => ("function" == typeof e ? e() : e).map(r => n(r)).filter(Qs)
      }

      function ts(e) {
        return {
          \u0275providers: e
        }
      }

      function cs(...e) {
        return {
          \u0275providers: $r(0, e),
          \u0275fromNgModule: !0
        }
      }

      function $r(e, ...t) {
        const n = [],
          r = new Set;
        let i;
        const s = o => {
          n.push(o)
        };
        return br(t, o => {
          const l = o;
          Zs(l, s, [], r) && (i ||= [], i.push(l))
        }), void 0 !== i && ho(i, s), n
      }

      function ho(e, t) {
        for (let n = 0; n < e.length; n++) {
          const {
            ngModule: r,
            providers: i
          } = e[n];
          Oo(i, s => {
            t(s, r)
          })
        }
      }

      function Zs(e, t, n, r) {
        if (!(e = re(e))) return !1;
        let i = null,
          s = Xr(e);
        const o = !s && Vt(e);
        if (s || o) {
          if (o && !o.standalone) return !1;
          i = e
        } else {
          const h = e.ngModule;
          if (s = Xr(h), !s) return !1;
          i = h
        }
        const l = r.has(i);
        if (o) {
          if (l) return !1;
          if (r.add(i), o.dependencies) {
            const h = "function" == typeof o.dependencies ? o.dependencies() : o.dependencies;
            for (const E of h) Zs(E, t, n, r)
          }
        } else {
          if (!s) return !1;
          {
            if (null != s.imports && !l) {
              let E;
              r.add(i);
              try {
                br(s.imports, O => {
                  Zs(O, t, n, r) && (E ||= [], E.push(O))
                })
              } finally {}
              void 0 !== E && ho(E, t)
            }
            if (!l) {
              const E = Zr(i) || (() => new i);
              t({
                provide: i,
                useFactory: E,
                deps: $t
              }, i), t({
                provide: qs,
                useValue: i,
                multi: !0
              }, i), t({
                provide: hi,
                useValue: () => en(i),
                multi: !0
              }, i)
            }
            const h = s.providers;
            if (null != h && !l) {
              const E = e;
              Oo(h, O => {
                t(O, E)
              })
            }
          }
        }
        return i !== e && void 0 !== e.providers
      }

      function Oo(e, t) {
        for (let n of e) jt(n) && (n = n.\u0275providers), Array.isArray(n) ? Oo(n, t) : t(n)
      }
      const No = Pt({
        provide: String,
        useValue: Pt
      });

      function po(e) {
        return null !== e && "object" == typeof e && No in e
      }

      function wi(e) {
        return "function" == typeof e
      }
      const eo = new pe(""),
        to = {},
        Po = {};
      let us;

      function xs() {
        return void 0 === us && (us = new Os), us
      }
      class Wr {}
      class ds extends Wr {
        get destroyed() {
          return this._destroyed
        }
        constructor(t, n, r, i) {
          super(), this.parent = n, this.source = r, this.scopes = i, this.records = new Map, this
            ._ngOnDestroyHooks = new Set, this._onDestroyHooks = [], this._destroyed = !1, Lo(t, o => this
              .processProvider(o)), this.records.set(So, fs(void 0, this)), i.has("environment") && this.records
            .set(Wr, fs(void 0, this));
          const s = this.records.get(eo);
          null != s && "string" == typeof s.value && this.scopes.add(s.value), this.injectorDefTypes = new Set(
            this.get(qs, $t, At.Self))
        }
        destroy() {
          this.assertNotDestroyed(), this._destroyed = !0;
          const t = M(null);
          try {
            for (const r of this._ngOnDestroyHooks) r.ngOnDestroy();
            const n = this._onDestroyHooks;
            this._onDestroyHooks = [];
            for (const r of n) r()
          } finally {
            this.records.clear(), this._ngOnDestroyHooks.clear(), this.injectorDefTypes.clear(), M(t)
          }
        }
        onDestroy(t) {
          return this.assertNotDestroyed(), this._onDestroyHooks.push(t), () => this.removeOnDestroy(t)
        }
        runInContext(t) {
          this.assertNotDestroyed();
          const n = Yr(this),
            r = Vn(void 0);
          try {
            return t()
          } finally {
            Yr(n), Vn(r)
          }
        }
        get(t, n = Ur, r = At.Default) {
          if (this.assertNotDestroyed(), t.hasOwnProperty(gn)) return t[gn](this);
          r = jr(r);
          const s = Yr(this),
            o = Vn(void 0);
          try {
            if (!(r & At.SkipSelf)) {
              let h = this.records.get(t);
              if (void 0 === h) {
                const E = function Xa(e) {
                  return "function" == typeof e || "object" == typeof e && e instanceof pe
                }(t) && oi(t);
                h = E && this.injectableDefInScope(E) ? fs(go(t), to) : null, this.records.set(t, h)
              }
              if (null != h) return this.hydrate(t, h)
            }
            return (r & At.Self ? xs() : this.parent).get(t, n = r & At.Optional && n === Ur ? null : n)
          } catch (l) {
            if ("NullInjectorError" === l.name) {
              if ((l[Ci] = l[Ci] || []).unshift(Jt(t)), s) throw l;
              return function Ms(e, t, n, r) {
                const i = e[Ci];
                throw t[ss] && i.unshift(t[ss]), e.message = function Ts(e, t, n, r = null) {
                  e = e && "\n" === e.charAt(0) && "\u0275" == e.charAt(1) ? e.slice(2) : e;
                  let i = Jt(t);
                  if (Array.isArray(t)) i = t.map(Jt).join(" -> ");
                  else if ("object" == typeof t) {
                    let s = [];
                    for (let o in t)
                      if (t.hasOwnProperty(o)) {
                        let l = t[o];
                        s.push(o + ":" + ("string" == typeof l ? JSON.stringify(l) : Jt(l)))
                      } i = `{${s.join(", ")}}`
                  }
                  return `${n}${r?"("+r+")":""}[${i}]: ${e.replace(Xi,"\n  ")}`
                }("\n" + e.message, i, n, r), e.ngTokenPath = i, e[Ci] = null, e
              }(l, t, "R3InjectorError", this.source)
            }
            throw l
          } finally {
            Vn(o), Yr(s)
          }
        }
        resolveInjectorInitializers() {
          const t = M(null),
            n = Yr(this),
            r = Vn(void 0);
          try {
            const s = this.get(hi, $t, At.Self);
            for (const o of s) o()
          } finally {
            Yr(n), Vn(r), M(t)
          }
        }
        toString() {
          const t = [],
            n = this.records;
          for (const r of n.keys()) t.push(Jt(r));
          return `R3Injector[${t.join(", ")}]`
        }
        assertNotDestroyed() {
          if (this._destroyed) throw new Ke(205, !1)
        }
        processProvider(t) {
          let n = wi(t = re(t)) ? t : re(t && t.provide);
          const r = function ia(e) {
            return po(e) ? fs(void 0, e.useValue) : fs(Fo(e), to)
          }(t);
          if (!wi(t) && !0 === t.multi) {
            let i = this.records.get(n);
            i || (i = fs(void 0, to, !0), i.factory = () => fr(i.multi), this.records.set(n, i)), n = t, i.multi
              .push(t)
          }
          this.records.set(n, r)
        }
        hydrate(t, n) {
          const r = M(null);
          try {
            return n.value === to && (n.value = Po, n.value = n.factory()), "object" == typeof n.value && n
              .value && function Zl(e) {
                return null !== e && "object" == typeof e && "function" == typeof e.ngOnDestroy
              }(n.value) && this._ngOnDestroyHooks.add(n.value), n.value
          } finally {
            M(r)
          }
        }
        injectableDefInScope(t) {
          if (!t.providedIn) return !1;
          const n = re(t.providedIn);
          return "string" == typeof n ? "any" === n || this.scopes.has(n) : this.injectorDefTypes.has(n)
        }
        removeOnDestroy(t) {
          const n = this._onDestroyHooks.indexOf(t); - 1 !== n && this._onDestroyHooks.splice(n, 1)
        }
      }

      function go(e) {
        const t = oi(e),
          n = null !== t ? t.factory : Zr(e);
        if (null !== n) return n;
        if (e instanceof pe) throw new Ke(204, !1);
        if (e instanceof Function) return function ra(e) {
          if (e.length > 0) throw new Ke(204, !1);
          const n = function ai(e) {
            return e && (e[B] || e[K]) || null
          }(e);
          return null !== n ? () => n.factory(e) : () => new e
        }(e);
        throw new Ke(204, !1)
      }

      function Fo(e, t, n) {
        let r;
        if (wi(e)) {
          const i = re(e);
          return Zr(i) || go(i)
        }
        if (po(e)) r = () => re(e.useValue);
        else if (function na(e) {
            return !(!e || !e.useFactory)
          }(e)) r = () => e.useFactory(...fr(e.deps || []));
        else if (function Js(e) {
            return !(!e || !e.useExisting)
          }(e)) r = () => en(re(e.useExisting));
        else {
          const i = re(e && (e.useClass || e.provide));
          if (! function xo(e) {
              return !!e.deps
            }(e)) return Zr(i) || go(i);
          r = () => new i(...fr(e.deps))
        }
        return r
      }

      function fs(e, t, n = !1) {
        return {
          factory: e,
          value: t,
          multi: n ? [] : void 0
        }
      }

      function Lo(e, t) {
        for (const n of e) Array.isArray(n) ? Lo(n, t) : n && jt(n) ? Lo(n.\u0275providers, t) : t(n)
      }

      function hs(e, t) {
        e instanceof ds && e.assertNotDestroyed();
        const r = Yr(e),
          i = Vn(void 0);
        try {
          return t()
        } finally {
          Yr(r), Vn(i)
        }
      }

      function mo() {
        return void 0 !== Ki() || null != function Yi() {
          return Cr
        }()
      }

      function no(e) {
        if (!mo()) throw new Ke(-203, !1)
      }
      const d = 0,
        a = 1,
        m = 2,
        b = 3,
        R = 4,
        j = 5,
        q = 6,
        de = 7,
        fe = 8,
        $e = 9,
        Ge = 10,
        We = 11,
        Mt = 12,
        gt = 13,
        Dt = 14,
        ft = 15,
        Tn = 16,
        An = 17,
        _n = 18,
        Fn = 19,
        ps = 20,
        Xn = 21,
        ir = 22,
        Wn = 23,
        yt = 25,
        Si = 1,
        Mr = 7,
        pr = 9,
        xn = 10;
      var st = function(e) {
        return e[e.None = 0] = "None", e[e.HasTransplantedViews = 2] = "HasTransplantedViews", e
      }(st || {});

      function tt(e) {
        return Array.isArray(e) && "object" == typeof e[Si]
      }

      function ot(e) {
        return Array.isArray(e) && !0 === e[Si]
      }

      function Kt(e) {
        return !!(4 & e.flags)
      }

      function En(e) {
        return e.componentOffset > -1
      }

      function Tr(e) {
        return !(1 & ~e.flags)
      }

      function On(e) {
        return !!e.template
      }

      function Ii(e) {
        return !!(512 & e[m])
      }
      class Rh {
        constructor(t, n, r) {
          this.previousValue = t, this.currentValue = n, this.firstChange = r
        }
        isFirstChange() {
          return this.firstChange
        }
      }

      function u(e, t, n, r) {
        null !== t ? t.applyValueToInputSignal(t, r) : e[n] = r
      }

      function y() {
        return f
      }

      function f(e) {
        return e.type.prototype.ngOnChanges && (e.setInput = w), v
      }

      function v() {
        const e = G(this),
          t = e?.current;
        if (t) {
          const n = e.previous;
          if (n === nr) e.previous = t;
          else
            for (let r in t) n[r] = t[r];
          e.current = null, this.ngOnChanges(t)
        }
      }

      function w(e, t, n, r, i) {
        const s = this.declaredInputs[r],
          o = G(e) || function ge(e, t) {
            return e[P] = t
          }(e, {
            previous: nr,
            current: null
          }),
          l = o.current || (o.current = {}),
          h = o.previous,
          E = h[s];
        l[s] = new Rh(E && E.currentValue, n, h === nr), u(e, t, i, n)
      }
      y.ngInherit = !0;
      const P = "__ngSimpleChanges__";

      function G(e) {
        return e[P] || null
      }
      const mt = function(e, t, n) {},
        Lt = "svg";
      let yo = !1;

      function pn(e) {
        for (; Array.isArray(e);) e = e[d];
        return e
      }

      function Ya(e, t) {
        return pn(t[e])
      }

      function mi(e, t) {
        return pn(t[e.index])
      }

      function Za(e, t) {
        return e.data[t]
      }

      function aa(e, t) {
        return e[t]
      }

      function ji(e, t) {
        const n = t[e];
        return tt(n) ? n : n[d]
      }

      function Nu(e) {
        return !(128 & ~e[m])
      }

      function ks(e, t) {
        return null == t ? null : e[t]
      }

      function Ph(e) {
        e[An] = 0
      }

      function oE(e) {
        1024 & e[m] || (e[m] |= 1024, Nu(e) && Ja(e))
      }

      function Ru(e) {
        return !!(9216 & e[m] || e[Wn]?.dirty)
      }

      function Pu(e) {
        e[Ge].changeDetectionScheduler?.notify(1), Ru(e) ? Ja(e) : 64 & e[m] && (function Uo() {
          return yo
        }() ? (e[m] |= 1024, Ja(e)) : e[Ge].changeDetectionScheduler?.notify())
      }

      function Ja(e) {
        e[Ge].changeDetectionScheduler?.notify();
        let t = jo(e);
        for (; null !== t && !(8192 & t[m]) && (t[m] |= 8192, Nu(t));) t = jo(t)
      }

      function ec(e, t) {
        if (!(256 & ~e[m])) throw new Ke(911, !1);
        null === e[Xn] && (e[Xn] = []), e[Xn].push(t)
      }

      function jo(e) {
        const t = e[b];
        return ot(t) ? t[b] : t
      }
      const Ot = {
        lFrame: Gh(null),
        bindingsEnabled: !0,
        skipHydrationRootTNode: null
      };

      function Lh() {
        return Ot.bindingsEnabled
      }

      function la() {
        return null !== Ot.skipHydrationRootTNode
      }

      function Te() {
        return Ot.lFrame.lView
      }

      function Yt() {
        return Ot.lFrame.tView
      }

      function kh(e) {
        return Ot.lFrame.contextLView = e, e[fe]
      }

      function Vh(e) {
        return Ot.lFrame.contextLView = null, e
      }

      function Cn() {
        let e = Bh();
        for (; null !== e && 64 === e.type;) e = e.parent;
        return e
      }

      function Bh() {
        return Ot.lFrame.currentTNode
      }

      function Vs(e, t) {
        const n = Ot.lFrame;
        n.currentTNode = e, n.isParent = t
      }

      function xu() {
        return Ot.lFrame.isParent
      }

      function Lu() {
        Ot.lFrame.isParent = !1
      }

      function yi() {
        const e = Ot.lFrame;
        let t = e.bindingRootIndex;
        return -1 === t && (t = e.bindingRootIndex = e.tView.bindingStartIndex), t
      }

      function vs() {
        return Ot.lFrame.bindingIndex++
      }

      function io(e) {
        const t = Ot.lFrame,
          n = t.bindingIndex;
        return t.bindingIndex = t.bindingIndex + e, n
      }

      function yE(e, t) {
        const n = Ot.lFrame;
        n.bindingIndex = n.bindingRootIndex = e, ku(t)
      }

      function ku(e) {
        Ot.lFrame.currentDirectiveIndex = e
      }

      function Bu() {
        return Ot.lFrame.currentQueryIndex
      }

      function tc(e) {
        Ot.lFrame.currentQueryIndex = e
      }

      function _E(e) {
        const t = e[a];
        return 2 === t.type ? t.declTNode : 1 === t.type ? e[j] : null
      }

      function $h(e, t, n) {
        if (n & At.SkipSelf) {
          let i = t,
            s = e;
          for (; !(i = i.parent, null !== i || n & At.Host || (i = _E(s), null === i || (s = s[Dt], 10 & i
            .type))););
          if (null === i) return !1;
          t = i, e = s
        }
        const r = Ot.lFrame = Wh();
        return r.currentTNode = t, r.lView = e, !0
      }

      function Uu(e) {
        const t = Wh(),
          n = e[a];
        Ot.lFrame = t, t.currentTNode = n.firstChild, t.lView = e, t.tView = n, t.contextLView = e, t
          .bindingIndex = n.bindingStartIndex, t.inI18n = !1
      }

      function Wh() {
        const e = Ot.lFrame,
          t = null === e ? null : e.child;
        return null === t ? Gh(e) : t
      }

      function Gh(e) {
        const t = {
          currentTNode: null,
          isParent: !0,
          lView: null,
          tView: null,
          selectedIndex: -1,
          contextLView: null,
          elementDepthCount: 0,
          currentNamespace: null,
          currentDirectiveIndex: -1,
          bindingRootIndex: -1,
          bindingIndex: -1,
          currentQueryIndex: 0,
          parent: e,
          child: null,
          inI18n: !1
        };
        return null !== e && (e.child = t), t
      }

      function zh() {
        const e = Ot.lFrame;
        return Ot.lFrame = e.parent, e.currentTNode = null, e.lView = null, e
      }
      const Kh = zh;

      function ju() {
        const e = zh();
        e.isParent = !0, e.tView = null, e.selectedIndex = -1, e.contextLView = null, e.elementDepthCount = 0, e
          .currentDirectiveIndex = -1, e.currentNamespace = null, e.bindingRootIndex = -1, e.bindingIndex = -1, e
          .currentQueryIndex = 0
      }

      function Jr() {
        return Ot.lFrame.selectedIndex
      }

      function Ho(e) {
        Ot.lFrame.selectedIndex = e
      }

      function kn() {
        const e = Ot.lFrame;
        return Za(e.tView, e.selectedIndex)
      }

      function qh() {
        Ot.lFrame.currentNamespace = Lt
      }
      let Xh = !0;

      function tl() {
        return Xh
      }

      function Bs(e) {
        Xh = e
      }

      function nc(e, t) {
        for (let n = t.directiveStart, r = t.directiveEnd; n < r; n++) {
          const s = e.data[n].type.prototype,
            {
              ngAfterContentInit: o,
              ngAfterContentChecked: l,
              ngAfterViewInit: h,
              ngAfterViewChecked: E,
              ngOnDestroy: O
            } = s;
          o && (e.contentHooks ??= []).push(-n, o), l && ((e.contentHooks ??= []).push(n, l), (e
            .contentCheckHooks ??= []).push(n, l)), h && (e.viewHooks ??= []).push(-n, h), E && ((e
            .viewHooks ??= []).push(n, E), (e.viewCheckHooks ??= []).push(n, E)), null != O && (e
            .destroyHooks ??= []).push(n, O)
        }
      }

      function rc(e, t, n) {
        Yh(e, t, 3, n)
      }

      function ic(e, t, n, r) {
        (3 & e[m]) === n && Yh(e, t, n, r)
      }

      function Hu(e, t) {
        let n = e[m];
        (3 & n) === t && (n &= 16383, n += 1, e[m] = n)
      }

      function Yh(e, t, n, r) {
        const s = r ?? -1,
          o = t.length - 1;
        let l = 0;
        for (let h = void 0 !== r ? 65535 & e[An] : 0; h < o; h++)
          if ("number" == typeof t[h + 1]) {
            if (l = t[h], null != r && l >= r) break
          } else t[h] < 0 && (e[An] += 65536), (l < s || -1 == s) && (SE(e, n, t, h), e[An] = (4294901760 & e[
            An]) + h + 2), h++
      }

      function Zh(e, t) {
        mt(4, e, t);
        const n = M(null);
        try {
          t.call(e)
        } finally {
          M(n), mt(5, e, t)
        }
      }

      function SE(e, t, n, r) {
        const i = n[r] < 0,
          s = n[r + 1],
          l = e[i ? -n[r] : n[r]];
        i ? e[m] >> 14 < e[An] >> 16 && (3 & e[m]) === t && (e[m] += 16384, Zh(l, s)) : Zh(l, s)
      }
      const ca = -1;
      class nl {
        constructor(t, n, r) {
          this.factory = t, this.resolving = !1, this.canSeeViewProviders = n, this.injectImpl = r
        }
      }

      function Wu(e) {
        return e !== ca
      }

      function rl(e) {
        return 32767 & e
      }

      function il(e, t) {
        let n = function OE(e) {
            return e >> 16
          }(e),
          r = t;
        for (; n > 0;) r = r[Dt], n--;
        return r
      }
      let Gu = !0;

      function sc(e) {
        const t = Gu;
        return Gu = e, t
      }
      const Jh = 255,
        ep = 5;
      let NE = 0;
      const Us = {};

      function oc(e, t) {
        const n = tp(e, t);
        if (-1 !== n) return n;
        const r = t[a];
        r.firstCreatePass && (e.injectorIndex = t.length, zu(r.data, e), zu(t, null), zu(r.blueprint, null));
        const i = ac(e, t),
          s = e.injectorIndex;
        if (Wu(i)) {
          const o = rl(i),
            l = il(i, t),
            h = l[a].data;
          for (let E = 0; E < 8; E++) t[s + E] = l[o + E] | h[o + E]
        }
        return t[s + 8] = i, s
      }

      function zu(e, t) {
        e.push(0, 0, 0, 0, 0, 0, 0, 0, t)
      }

      function tp(e, t) {
        return -1 === e.injectorIndex || e.parent && e.parent.injectorIndex === e.injectorIndex || null === t[e
          .injectorIndex + 8] ? -1 : e.injectorIndex
      }

      function ac(e, t) {
        if (e.parent && -1 !== e.parent.injectorIndex) return e.parent.injectorIndex;
        let n = 0,
          r = null,
          i = t;
        for (; null !== i;) {
          if (r = cp(i), null === r) return ca;
          if (n++, i = i[Dt], -1 !== r.injectorIndex) return r.injectorIndex | n << 16
        }
        return ca
      }

      function Ku(e, t, n) {
        ! function RE(e, t, n) {
          let r;
          "string" == typeof n ? r = n.charCodeAt(0) || 0 : n.hasOwnProperty(dr) && (r = n[dr]), null == r && (r =
            n[dr] = NE++);
          const i = r & Jh;
          t.data[e + (i >> ep)] |= 1 << i
        }(e, t, n)
      }

      function np(e, t, n) {
        if (n & At.Optional || void 0 !== e) return e;
        li()
      }

      function rp(e, t, n, r) {
        if (n & At.Optional && void 0 === r && (r = null), !(n & (At.Self | At.Host))) {
          const i = e[$e],
            s = Vn(void 0);
          try {
            return i ? i.get(t, r, n & At.Optional) : Ss(t, r, n & At.Optional)
          } finally {
            Vn(s)
          }
        }
        return np(r, 0, n)
      }

      function ip(e, t, n, r = At.Default, i) {
        if (null !== e) {
          if (2048 & t[m] && !(r & At.Self)) {
            const o = function kE(e, t, n, r, i) {
              let s = e,
                o = t;
              for (; null !== s && null !== o && 2048 & o[m] && !(512 & o[m]);) {
                const l = sp(s, o, n, r | At.Self, Us);
                if (l !== Us) return l;
                let h = s.parent;
                if (!h) {
                  const E = o[ps];
                  if (E) {
                    const O = E.get(n, Us, r);
                    if (O !== Us) return O
                  }
                  h = cp(o), o = o[Dt]
                }
                s = h
              }
              return i
            }(e, t, n, r, Us);
            if (o !== Us) return o
          }
          const s = sp(e, t, n, r, Us);
          if (s !== Us) return s
        }
        return rp(t, n, r, i)
      }

      function sp(e, t, n, r, i) {
        const s = function xE(e) {
          if ("string" == typeof e) return e.charCodeAt(0) || 0;
          const t = e.hasOwnProperty(dr) ? e[dr] : void 0;
          return "number" == typeof t ? t >= 0 ? t & Jh : LE : t
        }(n);
        if ("function" == typeof s) {
          if (!$h(t, e, r)) return r & At.Host ? np(i, 0, r) : rp(t, n, r, i);
          try {
            let o;
            if (o = s(r), null != o || r & At.Optional) return o;
            li()
          } finally {
            Kh()
          }
        } else if ("number" == typeof s) {
          let o = null,
            l = tp(e, t),
            h = ca,
            E = r & At.Host ? t[ft][j] : null;
          for ((-1 === l || r & At.SkipSelf) && (h = -1 === l ? ac(e, t) : t[l + 8], h !== ca && ap(r, !1) ? (o =
              t[a], l = rl(h), t = il(h, t)) : l = -1); - 1 !== l;) {
            const O = t[a];
            if (op(s, l, O.data)) {
              const L = FE(l, t, n, o, r, E);
              if (L !== Us) return L
            }
            h = t[l + 8], h !== ca && ap(r, t[a].data[l + 8] === E) && op(s, l, t) ? (o = O, l = rl(h), t = il(h,
              t)) : l = -1
          }
        }
        return i
      }

      function FE(e, t, n, r, i, s) {
        const o = t[a],
          l = o.data[e + 8],
          O = lc(l, o, n, null == r ? En(l) && Gu : r != o && !!(3 & l.type), i & At.Host && s === l);
        return null !== O ? $o(t, o, O, l) : Us
      }

      function lc(e, t, n, r, i) {
        const s = e.providerIndexes,
          o = t.data,
          l = 1048575 & s,
          h = e.directiveStart,
          O = s >> 20,
          Q = i ? l + O : e.directiveEnd;
        for (let ne = r ? l : l + O; ne < Q; ne++) {
          const ce = o[ne];
          if (ne < h && n === ce || ne >= h && ce.type === n) return ne
        }
        if (i) {
          const ne = o[h];
          if (ne && On(ne) && ne.type === n) return h
        }
        return null
      }

      function $o(e, t, n, r) {
        let i = e[n];
        const s = t.data;
        if (function IE(e) {
            return e instanceof nl
          }(i)) {
          const o = i;
          o.resolving && function xr(e, t) {
            throw t && t.join(" > "), new Ke(-200, e)
          }(function Ye(e) {
            return "function" == typeof e ? e.name || e.toString() : "object" == typeof e && null != e &&
              "function" == typeof e.type ? e.type.name || e.type.toString() : lt(e)
          }(s[n]));
          const l = sc(o.canSeeViewProviders);
          o.resolving = !0;
          const E = o.injectImpl ? Vn(o.injectImpl) : null;
          $h(e, r, At.Default);
          try {
            i = e[n] = o.factory(void 0, s, e, r), t.firstCreatePass && n >= r.directiveStart && function wE(e, t,
              n) {
              const {
                ngOnChanges: r,
                ngOnInit: i,
                ngDoCheck: s
              } = t.type.prototype;
              if (r) {
                const o = f(t);
                (n.preOrderHooks ??= []).push(e, o), (n.preOrderCheckHooks ??= []).push(e, o)
              }
              i && (n.preOrderHooks ??= []).push(0 - e, i), s && ((n.preOrderHooks ??= []).push(e, s), (n
                .preOrderCheckHooks ??= []).push(e, s))
            }(n, s[n], t)
          } finally {
            null !== E && Vn(E), sc(l), o.resolving = !1, Kh()
          }
        }
        return i
      }

      function op(e, t, n) {
        return !!(n[t + (e >> ep)] & 1 << e)
      }

      function ap(e, t) {
        return !(e & At.Self || e & At.Host && t)
      }
      class Ar {
        constructor(t, n) {
          this._tNode = t, this._lView = n
        }
        get(t, n, r) {
          return ip(this._tNode, this._lView, t, jr(r), n)
        }
      }

      function LE() {
        return new Ar(Cn(), Te())
      }

      function lp(e) {
        return Tt(() => {
          const t = e.prototype.constructor,
            n = t[Hn] || qu(t),
            r = Object.prototype;
          let i = Object.getPrototypeOf(e.prototype).constructor;
          for (; i && i !== r;) {
            const s = i[Hn] || qu(i);
            if (s && s !== n) return s;
            i = Object.getPrototypeOf(i)
          }
          return s => new s
        })
      }

      function qu(e) {
        return te(e) ? () => {
          const t = qu(re(e));
          return t && t()
        } : Zr(e)
      }

      function cp(e) {
        const t = e[a],
          n = t.type;
        return 2 === n ? t.declTNode : 1 === n ? e[j] : null
      }

      function cc(e) {
        return function PE(e, t) {
          if ("class" === t) return e.classes;
          if ("style" === t) return e.styles;
          const n = e.attrs;
          if (n) {
            const r = n.length;
            let i = 0;
            for (; i < r;) {
              const s = n[i];
              if (I(s)) break;
              if (0 === s) i += 2;
              else if ("number" == typeof s)
                for (i++; i < r && "string" == typeof n[i];) i++;
              else {
                if (s === t) return n[i + 1];
                i += 2
              }
            }
          }
          return null
        }(Cn(), e)
      }

      function pp(e, t = null, n = null, r) {
        const i = gp(e, t, n, r);
        return i.resolveInjectorInitializers(), i
      }

      function gp(e, t = null, n = null, r, i = new Set) {
        const s = [n || $t, cs(e)];
        return r = r || ("object" == typeof e ? void 0 : Jt(e)), new ds(s, t || xs(), r || null, i)
      }
      let Hi = (() => {
        class e {
          static #e = this.THROW_IF_NOT_FOUND = Ur;
          static #t = this.NULL = new Os;
          static create(n, r) {
            if (Array.isArray(n)) return pp({
              name: ""
            }, r, n, "");
            {
              const i = n.name ?? "";
              return pp({
                name: i
              }, n.parent, n.providers, i)
            }
          }
          static #n = this.\u0275prov = Gt({
            token: e,
            providedIn: "any",
            factory: () => en(So)
          });
          static #r = this.__NG_ELEMENT_ID__ = -1
        }
        return e
      })();

      function Xu(e) {
        return e.ngOriginalError
      }
      class so {
        constructor() {
          this._console = console
        }
        handleError(t) {
          const n = this._findOriginalError(t);
          this._console.error("ERROR", t), n && this._console.error("ORIGINAL ERROR", n)
        }
        _findOriginalError(t) {
          let n = t && Xu(t);
          for (; n && Xu(n);) n = Xu(n);
          return n || null
        }
      }
      const yp = new pe("", {
        providedIn: "root",
        factory: () => pt(so).handleError.bind(void 0)
      });
      let fa = (() => {
        class e {
          static #e = this.__NG_ELEMENT_ID__ = zE;
          static #t = this.__NG_ENV_ID__ = n => n
        }
        return e
      })();
      class GE extends fa {
        constructor(t) {
          super(), this._lView = t
        }
        onDestroy(t) {
          return ec(this._lView, t), () => function Fu(e, t) {
            if (null === e[Xn]) return;
            const n = e[Xn].indexOf(t); - 1 !== n && e[Xn].splice(n, 1)
          }(this._lView, t)
        }
      }

      function zE() {
        return new GE(Te())
      }

      function KE() {
        return ha(Cn(), Te())
      }

      function ha(e, t) {
        return new sl(mi(e, t))
      }
      let sl = (() => {
        class e {
          constructor(n) {
            this.nativeElement = n
          }
          static #e = this.__NG_ELEMENT_ID__ = KE
        }
        return e
      })();

      function _p(e) {
        return e instanceof sl ? e.nativeElement : e
      }

      function Yu(e) {
        return t => {
          setTimeout(e, void 0, t)
        }
      }
      const js = class qE extends bt.B {
        constructor(t = !1) {
          super(), this.destroyRef = void 0, this.__isAsync = t, mo() && (this.destroyRef = pt(fa, {
            optional: !0
          }) ?? void 0)
        }
        emit(t) {
          const n = M(null);
          try {
            super.next(t)
          } finally {
            M(n)
          }
        }
        subscribe(t, n, r) {
          let i = t,
            s = n || (() => null),
            o = r;
          if (t && "object" == typeof t) {
            const h = t;
            i = h.next?.bind(h), s = h.error?.bind(h), o = h.complete?.bind(h)
          }
          this.__isAsync && (s = Yu(s), i && (i = Yu(i)), o && (o = Yu(o)));
          const l = super.subscribe({
            next: i,
            error: s,
            complete: o
          });
          return t instanceof Ct.yU && t.add(l), l
        }
      };

      function QE() {
        return this._results[Symbol.iterator]()
      }
      class Zu {
        static #e = Symbol.iterator;
        get changes() {
          return this._changes ??= new js
        }
        constructor(t = !1) {
          this._emitDistinctChangesOnly = t, this.dirty = !0, this._onDirty = void 0, this._results = [], this
            ._changesDetected = !1, this._changes = void 0, this.length = 0, this.first = void 0, this.last =
            void 0;
          const n = Zu.prototype;
          n[Symbol.iterator] || (n[Symbol.iterator] = QE)
        }
        get(t) {
          return this._results[t]
        }
        map(t) {
          return this._results.map(t)
        }
        filter(t) {
          return this._results.filter(t)
        }
        find(t) {
          return this._results.find(t)
        }
        reduce(t, n) {
          return this._results.reduce(t, n)
        }
        forEach(t) {
          this._results.forEach(t)
        }
        some(t) {
          return this._results.some(t)
        }
        toArray() {
          return this._results.slice()
        }
        toString() {
          return this._results.toString()
        }
        reset(t, n) {
          this.dirty = !1;
          const r = function Bn(e) {
            return e.flat(Number.POSITIVE_INFINITY)
          }(t);
          (this._changesDetected = ! function Zi(e, t, n) {
            if (e.length !== t.length) return !1;
            for (let r = 0; r < e.length; r++) {
              let i = e[r],
                s = t[r];
              if (n && (i = n(i), s = n(s)), s !== i) return !1
            }
            return !0
          }(this._results, r, n)) && (this._results = r, this.length = r.length, this.last = r[this.length - 1],
            this.first = r[0])
        }
        notifyOnChanges() {
          void 0 !== this._changes && (this._changesDetected || !this._emitDistinctChangesOnly) && this._changes
            .emit(this)
        }
        onDirty(t) {
          this._onDirty = t
        }
        setDirty() {
          this.dirty = !0, this._onDirty?.()
        }
        destroy() {
          void 0 !== this._changes && (this._changes.complete(), this._changes.unsubscribe())
        }
      }

      function dc(e) {
        return !(128 & ~e.flags)
      }
      const Ju = new Map;
      let YE = 0;
      const td = "__ngContext__";

      function ei(e, t) {
        tt(t) ? (e[td] = t[Fn], function JE(e) {
          Ju.set(e[Fn], e)
        }(t)) : e[td] = t
      }

      function Ap(e) {
        return Np(e[Mt])
      }

      function Op(e) {
        return Np(e[R])
      }

      function Np(e) {
        for (; null !== e && !ot(e);) e = e[R];
        return e
      }
      let nd;

      function mC(e) {
        nd = e
      }

      function vo() {
        if (void 0 !== nd) return nd;
        if (typeof document < "u") return document;
        throw new Ke(210, !1)
      }
      const Bp = new pe("", {
          providedIn: "root",
          factory: () => yC
        }),
        yC = "ng",
        Up = new pe(""),
        rd = new pe("", {
          providedIn: "platform",
          factory: () => "unknown"
        }),
        vC = new pe(""),
        _C = new pe("", {
          providedIn: "root",
          factory: () => vo().body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") || null
        });
      let jp = () => null;

      function dd(e, t, n = !1) {
        return jp(e, t, n)
      }
      const zp = new pe("", {
        providedIn: "root",
        factory: () => !1
      });
      let Dc, Ec;

      function ma(e) {
        return function gd() {
          if (void 0 === Dc && (Dc = null, dt.trustedTypes)) try {
            Dc = dt.trustedTypes.createPolicy("angular", {
              createHTML: e => e,
              createScript: e => e,
              createScriptURL: e => e
            })
          } catch {}
          return Dc
        }()?.createHTML(e) || e
      }

      function md() {
        if (void 0 === Ec && (Ec = null, dt.trustedTypes)) try {
          Ec = dt.trustedTypes.createPolicy("angular#unsafe-bypass", {
            createHTML: e => e,
            createScript: e => e,
            createScriptURL: e => e
          })
        } catch {}
        return Ec
      }

      function qp(e) {
        return md()?.createHTML(e) || e
      }

      function Xp(e) {
        return md()?.createScriptURL(e) || e
      }
      class Wo {
        constructor(t) {
          this.changingThisBreaksApplicationSecurity = t
        }
        toString() {
          return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity} (see ${Nn})`
        }
      }
      class PC extends Wo {
        getTypeName() {
          return "HTML"
        }
      }
      class FC extends Wo {
        getTypeName() {
          return "Style"
        }
      }
      class xC extends Wo {
        getTypeName() {
          return "Script"
        }
      }
      class LC extends Wo {
        getTypeName() {
          return "URL"
        }
      }
      class kC extends Wo {
        getTypeName() {
          return "ResourceURL"
        }
      }

      function oo(e) {
        return e instanceof Wo ? e.changingThisBreaksApplicationSecurity : e
      }

      function ya(e, t) {
        const n = function VC(e) {
          return e instanceof Wo && e.getTypeName() || null
        }(e);
        if (null != n && n !== t) {
          if ("ResourceURL" === n && "URL" === t) return !0;
          throw new Error(`Required a safe ${t}, got a ${n} (see ${Nn})`)
        }
        return n === t
      }

      function BC(e) {
        return new PC(e)
      }

      function UC(e) {
        return new FC(e)
      }

      function jC(e) {
        return new xC(e)
      }

      function HC(e) {
        return new LC(e)
      }

      function $C(e) {
        return new kC(e)
      }
      class WC {
        constructor(t) {
          this.inertDocumentHelper = t
        }
        getInertBodyElement(t) {
          t = "<body><remove></remove>" + t;
          try {
            const n = (new window.DOMParser).parseFromString(ma(t), "text/html").body;
            return null === n ? this.inertDocumentHelper.getInertBodyElement(t) : (n.removeChild(n.firstChild),
              n)
          } catch {
            return null
          }
        }
      }
      class GC {
        constructor(t) {
          this.defaultDoc = t, this.inertDocument = this.defaultDoc.implementation.createHTMLDocument(
            "sanitization-inert")
        }
        getInertBodyElement(t) {
          const n = this.inertDocument.createElement("template");
          return n.innerHTML = ma(t), n
        }
      }
      const KC = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;

      function Cc(e) {
        return (e = String(e)).match(KC) ? e : "unsafe:" + e
      }

      function ao(e) {
        const t = {};
        for (const n of e.split(",")) t[n] = !0;
        return t
      }

      function fl(...e) {
        const t = {};
        for (const n of e)
          for (const r in n) n.hasOwnProperty(r) && (t[r] = !0);
        return t
      }
      const Zp = ao("area,br,col,hr,img,wbr"),
        Jp = ao("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr"),
        eg = ao("rp,rt"),
        yd = fl(Zp, fl(Jp, ao(
          "address,article,aside,blockquote,caption,center,del,details,dialog,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,main,map,menu,nav,ol,pre,section,summary,table,ul"
          )), fl(eg, ao(
          "a,abbr,acronym,audio,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,picture,q,ruby,rp,rt,s,samp,small,source,span,strike,strong,sub,sup,time,track,tt,u,var,video"
          )), fl(eg, Jp)),
        vd = ao("background,cite,href,itemtype,longdesc,poster,src,xlink:href"),
        tg = fl(vd, ao(
          "abbr,accesskey,align,alt,autoplay,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,controls,coords,datetime,default,dir,download,face,headers,height,hidden,hreflang,hspace,ismap,itemscope,itemprop,kind,label,lang,language,loop,media,muted,nohref,nowrap,open,preload,rel,rev,role,rows,rowspan,rules,scope,scrolling,shape,size,sizes,span,srclang,srcset,start,summary,tabindex,target,title,translate,type,usemap,valign,value,vspace,width"
          ), ao(
          "aria-activedescendant,aria-atomic,aria-autocomplete,aria-busy,aria-checked,aria-colcount,aria-colindex,aria-colspan,aria-controls,aria-current,aria-describedby,aria-details,aria-disabled,aria-dropeffect,aria-errormessage,aria-expanded,aria-flowto,aria-grabbed,aria-haspopup,aria-hidden,aria-invalid,aria-keyshortcuts,aria-label,aria-labelledby,aria-level,aria-live,aria-modal,aria-multiline,aria-multiselectable,aria-orientation,aria-owns,aria-placeholder,aria-posinset,aria-pressed,aria-readonly,aria-relevant,aria-required,aria-roledescription,aria-rowcount,aria-rowindex,aria-rowspan,aria-selected,aria-setsize,aria-sort,aria-valuemax,aria-valuemin,aria-valuenow,aria-valuetext"
          )),
        qC = ao("script,style,template");
      class QC {
        constructor() {
          this.sanitizedSomething = !1, this.buf = []
        }
        sanitizeChildren(t) {
          let n = t.firstChild,
            r = !0,
            i = [];
          for (; n;)
            if (n.nodeType === Node.ELEMENT_NODE ? r = this.startElement(n) : n.nodeType === Node.TEXT_NODE ?
              this.chars(n.nodeValue) : this.sanitizedSomething = !0, r && n.firstChild) i.push(n), n = ZC(n);
            else
              for (; n;) {
                n.nodeType === Node.ELEMENT_NODE && this.endElement(n);
                let s = YC(n);
                if (s) {
                  n = s;
                  break
                }
                n = i.pop()
              }
          return this.buf.join("")
        }
        startElement(t) {
          const n = ng(t).toLowerCase();
          if (!yd.hasOwnProperty(n)) return this.sanitizedSomething = !0, !qC.hasOwnProperty(n);
          this.buf.push("<"), this.buf.push(n);
          const r = t.attributes;
          for (let i = 0; i < r.length; i++) {
            const s = r.item(i),
              o = s.name,
              l = o.toLowerCase();
            if (!tg.hasOwnProperty(l)) {
              this.sanitizedSomething = !0;
              continue
            }
            let h = s.value;
            vd[l] && (h = Cc(h)), this.buf.push(" ", o, '="', ig(h), '"')
          }
          return this.buf.push(">"), !0
        }
        endElement(t) {
          const n = ng(t).toLowerCase();
          yd.hasOwnProperty(n) && !Zp.hasOwnProperty(n) && (this.buf.push("</"), this.buf.push(n), this.buf
            .push(">"))
        }
        chars(t) {
          this.buf.push(ig(t))
        }
      }

      function YC(e) {
        const t = e.nextSibling;
        if (t && e !== t.previousSibling) throw rg(t);
        return t
      }

      function ZC(e) {
        const t = e.firstChild;
        if (t && function XC(e, t) {
            return (e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY) !== Node
              .DOCUMENT_POSITION_CONTAINED_BY
          }(e, t)) throw rg(t);
        return t
      }

      function ng(e) {
        const t = e.nodeName;
        return "string" == typeof t ? t : "FORM"
      }

      function rg(e) {
        return new Error(`Failed to sanitize html because the element is clobbered: ${e.outerHTML}`)
      }
      const JC = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g,
        eb = /([^\#-~ |!])/g;

      function ig(e) {
        return e.replace(/&/g, "&amp;").replace(JC, function(t) {
          return "&#" + (1024 * (t.charCodeAt(0) - 55296) + (t.charCodeAt(1) - 56320) + 65536) + ";"
        }).replace(eb, function(t) {
          return "&#" + t.charCodeAt(0) + ";"
        }).replace(/</g, "&lt;").replace(/>/g, "&gt;")
      }
      let bc;

      function sg(e, t) {
        let n = null;
        try {
          bc = bc || function Yp(e) {
            const t = new GC(e);
            return function zC() {
              try {
                return !!(new window.DOMParser).parseFromString(ma(""), "text/html")
              } catch {
                return !1
              }
            }() ? new WC(t) : t
          }(e);
          let r = t ? String(t) : "";
          n = bc.getInertBodyElement(r);
          let i = 5,
            s = r;
          do {
            if (0 === i) throw new Error("Failed to sanitize html because the input is unstable");
            i--, r = s, s = n.innerHTML, n = bc.getInertBodyElement(r)
          } while (r !== s);
          return ma((new QC).sanitizeChildren(_d(n) || n))
        } finally {
          if (n) {
            const r = _d(n) || n;
            for (; r.firstChild;) r.removeChild(r.firstChild)
          }
        }
      }

      function _d(e) {
        return "content" in e && function tb(e) {
          return e.nodeType === Node.ELEMENT_NODE && "TEMPLATE" === e.nodeName
        }(e) ? e.content : null
      }
      var Go = function(e) {
        return e[e.NONE = 0] = "NONE", e[e.HTML = 1] = "HTML", e[e.STYLE = 2] = "STYLE", e[e.SCRIPT = 3] =
          "SCRIPT", e[e.URL = 4] = "URL", e[e.RESOURCE_URL = 5] = "RESOURCE_URL", e
      }(Go || {});

      function og(e) {
        const t = hl();
        return t ? qp(t.sanitize(Go.HTML, e) || "") : ya(e, "HTML") ? qp(oo(e)) : sg(vo(), lt(e))
      }

      function Dd(e) {
        const t = hl();
        return t ? t.sanitize(Go.URL, e) || "" : ya(e, "URL") ? oo(e) : Cc(lt(e))
      }

      function ag(e) {
        const t = hl();
        if (t) return Xp(t.sanitize(Go.RESOURCE_URL, e) || "");
        if (ya(e, "ResourceURL")) return Xp(oo(e));
        throw new Ke(904, !1)
      }

      function lg(e, t, n) {
        return function ob(e, t) {
          return "src" === t && ("embed" === e || "frame" === e || "iframe" === e || "media" === e ||
            "script" === e) || "href" === t && ("base" === e || "link" === e) ? ag : Dd
        }(t, n)(e)
      }

      function hl() {
        const e = Te();
        return e && e[Ge].sanitizer
      }
      const ab = /^>|^->|<!--|-->|--!>|<!-$/g,
        lb = /(<|>)/g,
        cb = "\u200b$1\u200b";

      function fg(e) {
        return e.ownerDocument
      }

      function $i(e) {
        return e instanceof Function ? e() : e
      }
      var Ic = function(e) {
        return e[e.Important = 1] = "Important", e[e.DashCase = 2] = "DashCase", e
      }(Ic || {});
      let wd;

      function Sd(e, t) {
        return wd(e, t)
      }

      function _a(e, t, n, r, i) {
        if (null != r) {
          let s, o = !1;
          ot(r) ? s = r : tt(r) && (o = !0, r = r[d]);
          const l = pn(r);
          0 === e && null !== n ? null == i ? Eg(t, n, l) : zo(t, n, l, i || null, !0) : 1 === e && null !== n ?
            zo(t, n, l, i || null, !0) : 2 === e ? function ml(e, t, n) {
              const r = Ac(e, t);
              r && function Mb(e, t, n, r) {
                e.removeChild(t, n, r)
              }(e, r, t, n)
            }(t, l, o) : 3 === e && t.destroyNode(l), null != s && function Ob(e, t, n, r, i) {
              const s = n[Mr];
              s !== pn(n) && _a(t, e, r, s, i);
              for (let l = xn; l < n.length; l++) {
                const h = n[l];
                Nc(h[a], h, e, t, r, s)
              }
            }(t, e, s, n, i)
        }
      }

      function Md(e, t) {
        return e.createComment(function cg(e) {
          return e.replace(ab, t => t.replace(lb, cb))
        }(t))
      }

      function Mc(e, t, n) {
        return e.createElement(t, n)
      }

      function vg(e, t) {
        t[Ge].changeDetectionScheduler?.notify(1), Nc(e, t, t[We], 2, null, null)
      }

      function _g(e, t) {
        const n = e[pr],
          r = n.indexOf(t);
        n.splice(r, 1)
      }

      function pl(e, t) {
        if (e.length <= xn) return;
        const n = xn + t,
          r = e[n];
        if (r) {
          const i = r[Tn];
          null !== i && i !== e && _g(i, r), t > 0 && (e[n - 1][R] = r[R]);
          const s = fi(e, xn + t);
          ! function Db(e, t) {
            vg(e, t), t[d] = null, t[j] = null
          }(r[a], r);
          const o = s[_n];
          null !== o && o.detachView(s[a]), r[b] = null, r[R] = null, r[m] &= -129
        }
        return r
      }

      function Tc(e, t) {
        if (!(256 & t[m])) {
          const n = t[We];
          n.destroyNode && Nc(e, t, n, 3, null, null),
            function Cb(e) {
              let t = e[Mt];
              if (!t) return Td(e[a], e);
              for (; t;) {
                let n = null;
                if (tt(t)) n = t[Mt];
                else {
                  const r = t[xn];
                  r && (n = r)
                }
                if (!n) {
                  for (; t && !t[R] && t !== e;) tt(t) && Td(t[a], t), t = t[b];
                  null === t && (t = e), tt(t) && Td(t[a], t), n = t && t[R]
                }
                t = n
              }
            }(t)
        }
      }

      function Td(e, t) {
        if (256 & t[m]) return;
        const n = M(null);
        try {
          t[m] &= -129, t[m] |= 256, t[Wn] && ue(t[Wn]),
            function Ib(e, t) {
              let n;
              if (null != e && null != (n = e.destroyHooks))
                for (let r = 0; r < n.length; r += 2) {
                  const i = t[n[r]];
                  if (!(i instanceof nl)) {
                    const s = n[r + 1];
                    if (Array.isArray(s))
                      for (let o = 0; o < s.length; o += 2) {
                        const l = i[s[o]],
                          h = s[o + 1];
                        mt(4, l, h);
                        try {
                          h.call(l)
                        } finally {
                          mt(5, l, h)
                        }
                      } else {
                        mt(4, i, s);
                        try {
                          s.call(i)
                        } finally {
                          mt(5, i, s)
                        }
                      }
                  }
                }
            }(e, t),
            function Sb(e, t) {
              const n = e.cleanup,
                r = t[de];
              if (null !== n)
                for (let s = 0; s < n.length - 1; s += 2)
                  if ("string" == typeof n[s]) {
                    const o = n[s + 3];
                    o >= 0 ? r[o]() : r[-o].unsubscribe(), s += 2
                  } else n[s].call(r[n[s + 1]]);
              null !== r && (t[de] = null);
              const i = t[Xn];
              if (null !== i) {
                t[Xn] = null;
                for (let s = 0; s < i.length; s++)(0, i[s])()
              }
            }(e, t), 1 === t[a].type && t[We].destroy();
          const r = t[Tn];
          if (null !== r && ot(t[b])) {
            r !== t[b] && _g(r, t);
            const i = t[_n];
            null !== i && i.detachView(e)
          }! function eC(e) {
            Ju.delete(e[Fn])
          }(t)
        } finally {
          M(n)
        }
      }

      function Ad(e, t, n) {
        return function Dg(e, t, n) {
          let r = t;
          for (; null !== r && 40 & r.type;) r = (t = r).parent;
          if (null === r) return n[d];
          {
            const {
              componentOffset: i
            } = r;
            if (i > -1) {
              const {
                encapsulation: s
              } = e.data[r.directiveStart + i];
              if (s === pi.None || s === pi.Emulated) return null
            }
            return mi(r, n)
          }
        }(e, t.parent, n)
      }

      function zo(e, t, n, r, i) {
        e.insertBefore(t, n, r, i)
      }

      function Eg(e, t, n) {
        e.appendChild(t, n)
      }

      function Cg(e, t, n, r, i) {
        null !== r ? zo(e, t, n, r, i) : Eg(e, t, n)
      }

      function Ac(e, t) {
        return e.parentNode(t)
      }

      function bg(e, t, n) {
        return Sg(e, t, n)
      }
      let Od, Sg = function wg(e, t, n) {
        return 40 & e.type ? mi(e, n) : null
      };

      function Oc(e, t, n, r) {
        const i = Ad(e, r, t),
          s = t[We],
          l = bg(r.parent || t[j], r, t);
        if (null != i)
          if (Array.isArray(n))
            for (let h = 0; h < n.length; h++) Cg(s, i, n[h], l, !1);
          else Cg(s, i, n, l, !1);
        void 0 !== Od && Od(s, r, t, n, i)
      }

      function gl(e, t) {
        if (null !== t) {
          const n = t.type;
          if (3 & n) return mi(t, e);
          if (4 & n) return Nd(-1, e[t.index]);
          if (8 & n) {
            const r = t.child;
            if (null !== r) return gl(e, r);
            {
              const i = e[t.index];
              return ot(i) ? Nd(-1, i) : pn(i)
            }
          }
          if (32 & n) return Sd(t, e)() || pn(e[t.index]);
          {
            const r = Mg(e, t);
            return null !== r ? Array.isArray(r) ? r[0] : gl(jo(e[ft]), r) : gl(e, t.next)
          }
        }
        return null
      }

      function Mg(e, t) {
        return null !== t ? e[ft][j].projection[t.projection] : null
      }

      function Nd(e, t) {
        const n = xn + e + 1;
        if (n < t.length) {
          const r = t[n],
            i = r[a].firstChild;
          if (null !== i) return gl(r, i)
        }
        return t[Mr]
      }

      function Rd(e, t, n, r, i, s, o) {
        for (; null != n;) {
          const l = r[n.index],
            h = n.type;
          if (o && 0 === t && (l && ei(pn(l), r), n.flags |= 2), 32 & ~n.flags)
            if (8 & h) Rd(e, t, n.child, r, i, s, !1), _a(t, e, i, l, s);
            else if (32 & h) {
            const E = Sd(n, r);
            let O;
            for (; O = E();) _a(t, e, i, O, s);
            _a(t, e, i, l, s)
          } else 16 & h ? Ag(e, t, r, n, i, s) : _a(t, e, i, l, s);
          n = o ? n.projectionNext : n.next
        }
      }

      function Nc(e, t, n, r, i, s) {
        Rd(n, r, e.firstChild, t, i, s, !1)
      }

      function Ag(e, t, n, r, i, s) {
        const o = n[ft],
          h = o[j].projection[r.projection];
        if (Array.isArray(h))
          for (let E = 0; E < h.length; E++) _a(t, e, i, h[E], s);
        else {
          let E = h;
          const O = o[b];
          dc(r) && (E.flags |= 128), Rd(e, t, E, O, i, s, !0)
        }
      }

      function Og(e, t, n) {
        "" === n ? e.removeAttribute(t, "class") : e.setAttribute(t, "class", n)
      }

      function Ng(e, t, n) {
        const {
          mergedAttrs: r,
          classes: i,
          styles: s
        } = n;
        null !== r && Vi(e, t, r), null !== i && Og(e, t, i), null !== s && function Rb(e, t, n) {
          e.setAttribute(t, "style", n)
        }(e, t, s)
      }
      const Bt = {};

      function Rg(e = 1) {
        Pg(Yt(), Te(), Jr() + e, !1)
      }

      function Pg(e, t, n, r) {
        if (!r)
          if (3 & ~t[m]) {
            const s = e.preOrderHooks;
            null !== s && ic(t, s, 0, n)
          } else {
            const s = e.preOrderCheckHooks;
            null !== s && rc(t, s, n)
          } Ho(n)
      }

      function Da(e, t = At.Default) {
        const n = Te();
        return null === n ? en(e, t) : ip(Cn(), n, re(e), t)
      }

      function Fg() {
        throw new Error("invalid")
      }

      function xg(e, t, n, r, i, s) {
        const o = M(null);
        try {
          let l = null;
          i & ki.SignalBased && (l = t[r][k]), null !== l && void 0 !== l.transformFn && (s = l.transformFn(s)),
            i & ki.HasDecoratorInputTransform && (s = e.inputTransforms[r].call(t, s)), null !== e.setInput ? e
            .setInput(t, l, s, n, r) : u(t, l, r, s)
        } finally {
          M(o)
        }
      }

      function Rc(e, t, n, r, i, s, o, l, h, E, O) {
        const L = t.blueprint.slice();
        return L[d] = i, L[m] = 204 | r, (null !== E || e && 2048 & e[m]) && (L[m] |= 2048), Ph(L), L[b] = L[Dt] =
          e, L[fe] = n, L[Ge] = o || e && e[Ge], L[We] = l || e && e[We], L[$e] = h || e && e[$e] || null, L[j] =
          s, L[Fn] = function ZE() {
            return YE++
          }(), L[q] = O, L[ps] = E, L[ft] = 2 == t.type ? e[ft] : L, L
      }

      function Ea(e, t, n, r, i) {
        let s = e.data[t];
        if (null === s) s = function Pd(e, t, n, r, i) {
            const s = Bh(),
              o = xu(),
              h = e.data[t] = function Ub(e, t, n, r, i, s) {
                let o = t ? t.injectorIndex : -1,
                  l = 0;
                return la() && (l |= 128), {
                  type: n,
                  index: r,
                  insertBeforeIndex: null,
                  injectorIndex: o,
                  directiveStart: -1,
                  directiveEnd: -1,
                  directiveStylingLast: -1,
                  componentOffset: -1,
                  propertyBindings: null,
                  flags: l,
                  providerIndexes: 0,
                  value: i,
                  attrs: s,
                  mergedAttrs: null,
                  localNames: null,
                  initialInputs: void 0,
                  inputs: null,
                  outputs: null,
                  tView: null,
                  next: null,
                  prev: null,
                  projectionNext: null,
                  child: null,
                  parent: t,
                  projection: null,
                  styles: null,
                  stylesWithoutHost: null,
                  residualStyles: void 0,
                  classes: null,
                  classesWithoutHost: null,
                  residualClasses: void 0,
                  classBindings: 0,
                  styleBindings: 0
                }
              }(0, o ? s : s && s.parent, n, t, r, i);
            return null === e.firstChild && (e.firstChild = h), null !== s && (o ? null == s.child && null !== h
              .parent && (s.child = h) : null === s.next && (s.next = h, h.prev = s)), h
          }(e, t, n, r, i),
          function mE() {
            return Ot.lFrame.inI18n
          }() && (s.flags |= 32);
        else if (64 & s.type) {
          s.type = n, s.value = r, s.attrs = i;
          const o = function el() {
            const e = Ot.lFrame,
              t = e.currentTNode;
            return e.isParent ? t : t.parent
          }();
          s.injectorIndex = null === o ? -1 : o.injectorIndex
        }
        return Vs(s, !0), s
      }

      function yl(e, t, n, r) {
        if (0 === n) return -1;
        const i = t.length;
        for (let s = 0; s < n; s++) t.push(r), e.blueprint.push(r), e.data.push(null);
        return i
      }

      function Lg(e, t, n, r, i) {
        const s = Jr(),
          o = 2 & r;
        try {
          Ho(-1), o && t.length > yt && Pg(e, t, yt, !1), mt(o ? 2 : 0, i), n(r, i)
        } finally {
          Ho(s), mt(o ? 3 : 1, i)
        }
      }

      function Fd(e, t, n) {
        if (Kt(t)) {
          const r = M(null);
          try {
            const s = t.directiveEnd;
            for (let o = t.directiveStart; o < s; o++) {
              const l = e.data[o];
              l.contentQueries && l.contentQueries(1, n[o], o)
            }
          } finally {
            M(r)
          }
        }
      }

      function xd(e, t, n) {
        Lh() && (function Kb(e, t, n, r) {
          const i = n.directiveStart,
            s = n.directiveEnd;
          En(n) && function ew(e, t, n) {
            const r = mi(t, e),
              i = kg(n);
            let o = 16;
            n.signals ? o = 4096 : n.onPush && (o = 64);
            const l = Pc(e, Rc(e, i, null, o, r, t, null, e[Ge].rendererFactory.createRenderer(r, n), null,
              null, null));
            e[t.index] = l
          }(t, n, e.data[i + n.componentOffset]), e.firstCreatePass || oc(n, t), ei(r, t);
          const o = n.initialInputs;
          for (let l = i; l < s; l++) {
            const h = e.data[l],
              E = $o(t, e, l, n);
            ei(E, t), null !== o && tw(0, l - i, E, h, 0, o), On(h) && (ji(n.index, t)[fe] = $o(t, e, l, n))
          }
        }(e, t, n, mi(n, t)), !(64 & ~n.flags) && Hg(e, t, n))
      }

      function Ld(e, t, n = mi) {
        const r = t.localNames;
        if (null !== r) {
          let i = t.index + 1;
          for (let s = 0; s < r.length; s += 2) {
            const o = r[s + 1],
              l = -1 === o ? n(t, e) : e[o];
            e[i++] = l
          }
        }
      }

      function kg(e) {
        const t = e.tView;
        return null === t || t.incompleteFirstPass ? e.tView = kd(1, null, e.template, e.decls, e.vars, e
          .directiveDefs, e.pipeDefs, e.viewQuery, e.schemas, e.consts, e.id) : t
      }

      function kd(e, t, n, r, i, s, o, l, h, E, O) {
        const L = yt + r,
          Q = L + i,
          ne = function Fb(e, t) {
            const n = [];
            for (let r = 0; r < t; r++) n.push(r < e ? null : Bt);
            return n
          }(L, Q),
          ce = "function" == typeof E ? E() : E;
        return ne[a] = {
          type: e,
          blueprint: ne,
          template: n,
          queries: null,
          viewQuery: l,
          declTNode: t,
          data: ne.slice().fill(null, L),
          bindingStartIndex: L,
          expandoStartIndex: Q,
          hostBindingOpCodes: null,
          firstCreatePass: !0,
          firstUpdatePass: !0,
          staticViewQueries: !1,
          staticContentQueries: !1,
          preOrderHooks: null,
          preOrderCheckHooks: null,
          contentHooks: null,
          contentCheckHooks: null,
          viewHooks: null,
          viewCheckHooks: null,
          destroyHooks: null,
          cleanup: null,
          contentQueries: null,
          components: null,
          directiveRegistry: "function" == typeof s ? s() : s,
          pipeRegistry: "function" == typeof o ? o() : o,
          firstChild: null,
          schemas: h,
          consts: ce,
          incompleteFirstPass: !1,
          ssrId: O
        }
      }
      let Vg = () => null;

      function Bg(e, t, n, r, i) {
        for (let s in t) {
          if (!t.hasOwnProperty(s)) continue;
          const o = t[s];
          if (void 0 === o) continue;
          r ??= {};
          let l, h = ki.None;
          Array.isArray(o) ? (l = o[0], h = o[1]) : l = o;
          let E = s;
          if (null !== i) {
            if (!i.hasOwnProperty(s)) continue;
            E = i[s]
          }
          0 === e ? Ug(r, n, E, l, h) : Ug(r, n, E, l)
        }
        return r
      }

      function Ug(e, t, n, r, i) {
        let s;
        e.hasOwnProperty(n) ? (s = e[n]).push(t, r) : s = e[n] = [t, r], void 0 !== i && s.push(i)
      }

      function Ti(e, t, n, r, i, s, o, l) {
        const h = mi(t, n);
        let O, E = t.inputs;
        !l && null != E && (O = E[r]) ? (Hd(e, n, O, r, i), En(t) && function $b(e, t) {
          const n = ji(t, e);
          16 & n[m] || (n[m] |= 64)
        }(n, t.index)) : 3 & t.type && (r = function Hb(e) {
          return "class" === e ? "className" : "for" === e ? "htmlFor" : "formaction" === e ? "formAction" :
            "innerHtml" === e ? "innerHTML" : "readonly" === e ? "readOnly" : "tabindex" === e ? "tabIndex" :
            e
        }(r), i = null != o ? o(i, t.value || "", r) : i, s.setProperty(h, r, i))
      }

      function Vd(e, t, n, r) {
        if (Lh()) {
          const i = null === r ? null : {
              "": -1
            },
            s = function Qb(e, t) {
              const n = e.directiveRegistry;
              let r = null,
                i = null;
              if (n)
                for (let s = 0; s < n.length; s++) {
                  const o = n[s];
                  if (Bi(t, o.selectors, !1))
                    if (r || (r = []), On(o))
                      if (null !== o.findHostDirectiveDefs) {
                        const l = [];
                        i = i || new Map, o.findHostDirectiveDefs(o, l, i), r.unshift(...l, o), Bd(e, t, l.length)
                      } else r.unshift(o), Bd(e, t, 0);
                  else i = i || new Map, o.findHostDirectiveDefs?.(o, r, i), r.push(o)
                }
              return null === r ? null : [r, i]
            }(e, n);
          let o, l;
          null === s ? o = l = null : [o, l] = s, null !== o && jg(e, t, n, o, i, l), i && function Xb(e, t, n) {
            if (t) {
              const r = e.localNames = [];
              for (let i = 0; i < t.length; i += 2) {
                const s = n[t[i + 1]];
                if (null == s) throw new Ke(-301, !1);
                r.push(t[i], s)
              }
            }
          }(n, r, i)
        }
        n.mergedAttrs = _(n.mergedAttrs, n.attrs)
      }

      function jg(e, t, n, r, i, s) {
        for (let E = 0; E < r.length; E++) Ku(oc(n, t), e, r[E].type);
        ! function Zb(e, t, n) {
          e.flags |= 1, e.directiveStart = t, e.directiveEnd = t + n, e.providerIndexes = t
        }(n, e.data.length, r.length);
        for (let E = 0; E < r.length; E++) {
          const O = r[E];
          O.providersResolver && O.providersResolver(O)
        }
        let o = !1,
          l = !1,
          h = yl(e, t, r.length, null);
        for (let E = 0; E < r.length; E++) {
          const O = r[E];
          n.mergedAttrs = _(n.mergedAttrs, O.hostAttrs), Jb(e, n, t, h, O), Yb(h, O, i), null !== O
            .contentQueries && (n.flags |= 4), (null !== O.hostBindings || null !== O.hostAttrs || 0 !== O
              .hostVars) && (n.flags |= 64);
          const L = O.type.prototype;
          !o && (L.ngOnChanges || L.ngOnInit || L.ngDoCheck) && ((e.preOrderHooks ??= []).push(n.index), o = !0),
            !l && (L.ngOnChanges || L.ngDoCheck) && ((e.preOrderCheckHooks ??= []).push(n.index), l = !0), h++
        }! function jb(e, t, n) {
          const i = t.directiveEnd,
            s = e.data,
            o = t.attrs,
            l = [];
          let h = null,
            E = null;
          for (let O = t.directiveStart; O < i; O++) {
            const L = s[O],
              Q = n ? n.get(L) : null,
              ce = Q ? Q.outputs : null;
            h = Bg(0, L.inputs, O, h, Q ? Q.inputs : null), E = Bg(1, L.outputs, O, E, ce);
            const Ie = null === h || null === o || Rt(t) ? null : nw(h, O, o);
            l.push(Ie)
          }
          null !== h && (h.hasOwnProperty("class") && (t.flags |= 8), h.hasOwnProperty("style") && (t.flags |=
            16)), t.initialInputs = l, t.inputs = h, t.outputs = E
        }(e, n, s)
      }

      function Hg(e, t, n) {
        const r = n.directiveStart,
          i = n.directiveEnd,
          s = n.index,
          o = function vE() {
            return Ot.lFrame.currentDirectiveIndex
          }();
        try {
          Ho(s);
          for (let l = r; l < i; l++) {
            const h = e.data[l],
              E = t[l];
            ku(l), (null !== h.hostBindings || 0 !== h.hostVars || null !== h.hostAttrs) && qb(h, E)
          }
        } finally {
          Ho(-1), ku(o)
        }
      }

      function qb(e, t) {
        null !== e.hostBindings && e.hostBindings(1, t)
      }

      function Bd(e, t, n) {
        t.componentOffset = n, (e.components ??= []).push(t.index)
      }

      function Yb(e, t, n) {
        if (n) {
          if (t.exportAs)
            for (let r = 0; r < t.exportAs.length; r++) n[t.exportAs[r]] = e;
          On(t) && (n[""] = e)
        }
      }

      function Jb(e, t, n, r, i) {
        e.data[r] = i;
        const s = i.factory || (i.factory = Zr(i.type)),
          o = new nl(s, On(i), Da);
        e.blueprint[r] = o, n[r] = o,
          function Gb(e, t, n, r, i) {
            const s = i.hostBindings;
            if (s) {
              let o = e.hostBindingOpCodes;
              null === o && (o = e.hostBindingOpCodes = []);
              const l = ~t.index;
              (function zb(e) {
                let t = e.length;
                for (; t > 0;) {
                  const n = e[--t];
                  if ("number" == typeof n && n < 0) return n
                }
                return 0
              })(o) != l && o.push(l), o.push(n, r, s)
            }
          }(e, t, r, yl(e, n, i.hostVars, Bt), i)
      }

      function Hs(e, t, n, r, i, s) {
        const o = mi(e, t);
        ! function Ud(e, t, n, r, i, s, o) {
          if (null == s) e.removeAttribute(t, i, n);
          else {
            const l = null == o ? lt(s) : o(s, r || "", i);
            e.setAttribute(t, i, l, n)
          }
        }(t[We], o, s, e.value, n, r, i)
      }

      function tw(e, t, n, r, i, s) {
        const o = s[t];
        if (null !== o)
          for (let l = 0; l < o.length;) xg(r, n, o[l++], o[l++], o[l++], o[l++])
      }

      function nw(e, t, n) {
        let r = null,
          i = 0;
        for (; i < n.length;) {
          const s = n[i];
          if (0 !== s)
            if (5 !== s) {
              if ("number" == typeof s) break;
              if (e.hasOwnProperty(s)) {
                null === r && (r = []);
                const o = e[s];
                for (let l = 0; l < o.length; l += 3)
                  if (o[l] === t) {
                    r.push(s, o[l + 1], o[l + 2], n[i + 1]);
                    break
                  }
              }
              i += 2
            } else i += 2;
          else i += 4
        }
        return r
      }

      function $g(e, t, n, r) {
        return [e, !0, 0, t, null, r, null, n, null, null]
      }

      function Wg(e, t) {
        const n = e.contentQueries;
        if (null !== n) {
          const r = M(null);
          try {
            for (let i = 0; i < n.length; i += 2) {
              const o = n[i + 1];
              if (-1 !== o) {
                const l = e.data[o];
                tc(n[i]), l.contentQueries(2, t[o], o)
              }
            }
          } finally {
            M(r)
          }
        }
      }

      function Pc(e, t) {
        return e[Mt] ? e[gt][R] = t : e[Mt] = t, e[gt] = t, t
      }

      function jd(e, t, n) {
        tc(0);
        const r = M(null);
        try {
          t(e, n)
        } finally {
          M(r)
        }
      }

      function Gg(e) {
        return e[de] || (e[de] = [])
      }

      function zg(e) {
        return e.cleanup || (e.cleanup = [])
      }

      function Fc(e, t) {
        const n = e[$e],
          r = n ? n.get(so, null) : null;
        r && r.handleError(t)
      }

      function Hd(e, t, n, r, i) {
        for (let s = 0; s < n.length;) {
          const o = n[s++],
            l = n[s++],
            h = n[s++];
          xg(e.data[o], t[o], r, l, h, i)
        }
      }

      function lo(e, t, n) {
        const r = Ya(t, e);
        ! function yg(e, t, n) {
          e.setValue(t, n)
        }(e[We], r, n)
      }

      function rw(e, t) {
        const n = ji(t, e),
          r = n[a];
        ! function iw(e, t) {
          for (let n = t.length; n < e.blueprint.length; n++) t.push(e.blueprint[n])
        }(r, n);
        const i = n[d];
        null !== i && null === n[q] && (n[q] = dd(i, n[$e])), $d(r, n, n[fe])
      }

      function $d(e, t, n) {
        Uu(t);
        try {
          const r = e.viewQuery;
          null !== r && jd(1, r, n);
          const i = e.template;
          null !== i && Lg(e, t, i, 1, n), e.firstCreatePass && (e.firstCreatePass = !1), t[_n]
            ?.finishViewCreation(e), e.staticContentQueries && Wg(e, t), e.staticViewQueries && jd(2, e.viewQuery,
              n);
          const s = e.components;
          null !== s && function sw(e, t) {
            for (let n = 0; n < t.length; n++) rw(e, t[n])
          }(t, s)
        } catch (r) {
          throw e.firstCreatePass && (e.incompleteFirstPass = !0, e.firstCreatePass = !1), r
        } finally {
          t[m] &= -5, ju()
        }
      }

      function Ca(e, t) {
        return !t || null === t.firstChild || dc(e)
      }

      function _l(e, t, n, r = !0) {
        const i = t[a];
        if (function bb(e, t, n, r) {
            const i = xn + r,
              s = n.length;
            r > 0 && (n[i - 1][R] = t), r < s - xn ? (t[R] = n[i], di(n, xn + r, t)) : (n.push(t), t[R] = null),
              t[b] = n;
            const o = t[Tn];
            null !== o && n !== o && function wb(e, t) {
              const n = e[pr];
              t[ft] !== t[b][b][ft] && (e[m] |= st.HasTransplantedViews), null === n ? e[pr] = [t] : n.push(t)
            }(o, t);
            const l = t[_n];
            null !== l && l.insertView(e), Pu(t), t[m] |= 128
          }(i, t, e, n), r) {
          const o = Nd(n, e),
            l = t[We],
            h = Ac(l, e[Mr]);
          null !== h && function Eb(e, t, n, r, i, s) {
            r[d] = i, r[j] = t, Nc(e, r, n, 1, i, s)
          }(i, e[j], l, t, h, o)
        }
        const s = t[q];
        null !== s && null !== s.firstChild && (s.firstChild = null)
      }

      function Dl(e, t, n, r, i = !1) {
        for (; null !== n;) {
          const s = t[n.index];
          null !== s && r.push(pn(s)), ot(s) && Qg(s, r);
          const o = n.type;
          if (8 & o) Dl(e, t, n.child, r);
          else if (32 & o) {
            const l = Sd(n, t);
            let h;
            for (; h = l();) r.push(h)
          } else if (16 & o) {
            const l = Mg(t, n);
            if (Array.isArray(l)) r.push(...l);
            else {
              const h = jo(t[ft]);
              Dl(h[a], h, l, r, !0)
            }
          }
          n = i ? n.projectionNext : n.next
        }
        return r
      }

      function Qg(e, t) {
        for (let n = xn; n < e.length; n++) {
          const r = e[n],
            i = r[a].firstChild;
          null !== i && Dl(r[a], r, i, t)
        }
        e[Mr] !== e[d] && t.push(e[Mr])
      }
      let Xg = [];
      const cw = {
          ...U,
          consumerIsAlwaysLive: !0,
          consumerMarkedDirty: e => {
            Ja(e.lView)
          },
          consumerOnSignalRead() {
            this.lView[Wn] = this
          }
        },
        Yg = 100;

      function xc(e, t = !0, n = 0) {
        const r = e[Ge],
          i = r.rendererFactory;
        i.begin?.();
        try {
          ! function uw(e, t) {
            Gd(e, t);
            let n = 0;
            for (; Ru(e);) {
              if (n === Yg) throw new Ke(103, !1);
              n++, Gd(e, 1)
            }
          }(e, n)
        } catch (o) {
          throw t && Fc(e, o), o
        } finally {
          i.end?.(), r.inlineEffectRunner?.flush()
        }
      }

      function dw(e, t, n, r) {
        const i = t[m];
        if (!(256 & ~i)) return;
        t[Ge].inlineEffectRunner?.flush(), Uu(t);
        let o = null,
          l = null;
        (function fw(e) {
          return 2 !== e.type
        })(e) && (l = function ow(e) {
          return e[Wn] ?? function aw(e) {
            const t = Xg.pop() ?? Object.create(cw);
            return t.lView = e, t
          }(e)
        }(t), o = Ve(l));
        try {
          Ph(t),
            function jh(e) {
              return Ot.lFrame.bindingIndex = e
            }(e.bindingStartIndex), null !== n && Lg(e, t, n, 2, r);
          const h = !(3 & ~i);
          if (h) {
            const L = e.preOrderCheckHooks;
            null !== L && rc(t, L, null)
          } else {
            const L = e.preOrderHooks;
            null !== L && ic(t, L, 0, null), Hu(t, 0)
          }
          if (function hw(e) {
              for (let t = Ap(e); null !== t; t = Op(t)) {
                if (!(t[m] & st.HasTransplantedViews)) continue;
                const n = t[pr];
                for (let r = 0; r < n.length; r++) {
                  oE(n[r])
                }
              }
            }(t), Zg(t, 0), null !== e.contentQueries && Wg(e, t), h) {
            const L = e.contentCheckHooks;
            null !== L && rc(t, L)
          } else {
            const L = e.contentHooks;
            null !== L && ic(t, L, 1), Hu(t, 1)
          }! function Pb(e, t) {
            const n = e.hostBindingOpCodes;
            if (null !== n) try {
              for (let r = 0; r < n.length; r++) {
                const i = n[r];
                if (i < 0) Ho(~i);
                else {
                  const s = i,
                    o = n[++r],
                    l = n[++r];
                  yE(o, s), l(2, t[s])
                }
              }
            } finally {
              Ho(-1)
            }
          }(e, t);
          const E = e.components;
          null !== E && em(t, E, 0);
          const O = e.viewQuery;
          if (null !== O && jd(2, O, r), h) {
            const L = e.viewCheckHooks;
            null !== L && rc(t, L)
          } else {
            const L = e.viewHooks;
            null !== L && ic(t, L, 2), Hu(t, 2)
          }
          if (!0 === e.firstUpdatePass && (e.firstUpdatePass = !1), t[ir]) {
            for (const L of t[ir]) L();
            t[ir] = null
          }
          t[m] &= -73
        } catch (h) {
          throw Ja(t), h
        } finally {
          null !== l && (Ze(l, o), function lw(e) {
            e.lView[Wn] !== e && (e.lView = null, Xg.push(e))
          }(l)), ju()
        }
      }

      function Zg(e, t) {
        for (let n = Ap(e); null !== n; n = Op(n))
          for (let r = xn; r < n.length; r++) Jg(n[r], t)
      }

      function pw(e, t, n) {
        Jg(ji(t, e), n)
      }

      function Jg(e, t) {
        Nu(e) && Gd(e, t)
      }

      function Gd(e, t) {
        const r = e[a],
          i = e[m],
          s = e[Wn];
        let o = !!(0 === t && 16 & i);
        if (o ||= !!(64 & i && 0 === t), o ||= !!(1024 & i), o ||= !(!s?.dirty || !vt(s)), s && (s.dirty = !1), e[
            m] &= -9217, o) dw(r, e, r.template, e[fe]);
        else if (8192 & i) {
          Zg(e, 1);
          const l = r.components;
          null !== l && em(e, l, 1)
        }
      }

      function em(e, t, n) {
        for (let r = 0; r < t.length; r++) pw(e, t[r], n)
      }

      function El(e) {
        for (e[Ge].changeDetectionScheduler?.notify(); e;) {
          e[m] |= 64;
          const t = jo(e);
          if (Ii(e) && !t) return e;
          e = t
        }
        return null
      }
      class Cl {
        get rootNodes() {
          const t = this._lView,
            n = t[a];
          return Dl(n, t, n.firstChild, [])
        }
        constructor(t, n, r = !0) {
          this._lView = t, this._cdRefInjectingView = n, this.notifyErrorHandler = r, this._appRef = null, this
            ._attachedToViewContainer = !1
        }
        get context() {
          return this._lView[fe]
        }
        set context(t) {
          this._lView[fe] = t
        }
        get destroyed() {
          return !(256 & ~this._lView[m])
        }
        destroy() {
          if (this._appRef) this._appRef.detachView(this);
          else if (this._attachedToViewContainer) {
            const t = this._lView[b];
            if (ot(t)) {
              const n = t[8],
                r = n ? n.indexOf(this) : -1;
              r > -1 && (pl(t, r), fi(n, r))
            }
            this._attachedToViewContainer = !1
          }
          Tc(this._lView[a], this._lView)
        }
        onDestroy(t) {
          ec(this._lView, t)
        }
        markForCheck() {
          El(this._cdRefInjectingView || this._lView)
        }
        detach() {
          this._lView[m] &= -129
        }
        reattach() {
          Pu(this._lView), this._lView[m] |= 128
        }
        detectChanges() {
          this._lView[m] |= 1024, xc(this._lView, this.notifyErrorHandler)
        }
        checkNoChanges() {}
        attachToViewContainerRef() {
          if (this._appRef) throw new Ke(902, !1);
          this._attachedToViewContainer = !0
        }
        detachFromAppRef() {
          this._appRef = null, vg(this._lView[a], this._lView)
        }
        attachToAppRef(t) {
          if (this._attachedToViewContainer) throw new Ke(902, !1);
          this._appRef = t, Pu(this._lView)
        }
      }
      let bl = (() => {
        class e {
          static #e = this.__NG_ELEMENT_ID__ = yw
        }
        return e
      })();
      const gw = bl,
        mw = class extends gw {
          constructor(t, n, r) {
            super(), this._declarationLView = t, this._declarationTContainer = n, this.elementRef = r
          }
          get ssrId() {
            return this._declarationTContainer.tView?.ssrId || null
          }
          createEmbeddedView(t, n) {
            return this.createEmbeddedViewImpl(t, n)
          }
          createEmbeddedViewImpl(t, n, r) {
            const i = function vl(e, t, n, r) {
              const i = M(null);
              try {
                const s = t.tView,
                  h = Rc(e, s, n, 4096 & e[m] ? 4096 : 16, null, t, null, null, r?.injector ?? null, r
                    ?.embeddedViewInjector ?? null, r?.dehydratedView ?? null);
                h[Tn] = e[t.index];
                const O = e[_n];
                return null !== O && (h[_n] = O.createEmbeddedView(s)), $d(s, h, n), h
              } finally {
                M(i)
              }
            }(this._declarationLView, this._declarationTContainer, t, {
              embeddedViewInjector: n,
              dehydratedView: r
            });
            return new Cl(i)
          }
        };

      function yw() {
        return Lc(Cn(), Te())
      }

      function Lc(e, t) {
        return 4 & e.type ? new mw(t, e, ha(e, t)) : null
      }
      class jc {}
      class jw {}
      class am {}
      class $w {
        resolveComponentFactory(t) {
          throw function Hw(e) {
            const t = Error(`No component factory found for ${Jt(e)}.`);
            return t.ngComponent = e, t
          }(t)
        }
      }
      let Hc = (() => {
        class e {
          static #e = this.NULL = new $w
        }
        return e
      })();
      class cm {}
      let Ww = (() => {
          class e {
            constructor() {
              this.destroyNode = null
            }
            static #e = this.__NG_ELEMENT_ID__ = () => function Gw() {
              const e = Te(),
                n = ji(Cn().index, e);
              return (tt(n) ? n : e)[We]
            }()
          }
          return e
        })(),
        zw = (() => {
          class e {
            static #e = this.\u0275prov = Gt({
              token: e,
              providedIn: "root",
              factory: () => null
            })
          }
          return e
        })();
      const Yd = {},
        um = new Set;

      function $s(e) {
        um.has(e) || (um.add(e), performance?.mark?.("mark_feature_usage", {
          detail: {
            feature: e
          }
        }))
      }

      function dm(...e) {}
      class mr {
        constructor({
          enableLongStackTrace: t = !1,
          shouldCoalesceEventChangeDetection: n = !1,
          shouldCoalesceRunChangeDetection: r = !1
        }) {
          if (this.hasPendingMacrotasks = !1, this.hasPendingMicrotasks = !1, this.isStable = !0, this
            .onUnstable = new js(!1), this.onMicrotaskEmpty = new js(!1), this.onStable = new js(!1), this
            .onError = new js(!1), typeof Zone > "u") throw new Ke(908, !1);
          Zone.assertZonePatched();
          const i = this;
          i._nesting = 0, i._outer = i._inner = Zone.current, Zone.TaskTrackingZoneSpec && (i._inner = i._inner
              .fork(new Zone.TaskTrackingZoneSpec)), t && Zone.longStackTraceZoneSpec && (i._inner = i._inner
              .fork(Zone.longStackTraceZoneSpec)), i.shouldCoalesceEventChangeDetection = !r && n, i
            .shouldCoalesceRunChangeDetection = r, i.lastRequestAnimationFrameId = -1, i
            .nativeRequestAnimationFrame = function Kw() {
              const e = "function" == typeof dt.requestAnimationFrame;
              let t = dt[e ? "requestAnimationFrame" : "setTimeout"],
                n = dt[e ? "cancelAnimationFrame" : "clearTimeout"];
              if (typeof Zone < "u" && t && n) {
                const r = t[Zone.__symbol__("OriginalDelegate")];
                r && (t = r);
                const i = n[Zone.__symbol__("OriginalDelegate")];
                i && (n = i)
              }
              return {
                nativeRequestAnimationFrame: t,
                nativeCancelAnimationFrame: n
              }
            }().nativeRequestAnimationFrame,
            function Xw(e) {
              const t = () => {
                ! function Qw(e) {
                  e.isCheckStableRunning || -1 !== e.lastRequestAnimationFrameId || (e
                    .lastRequestAnimationFrameId = e.nativeRequestAnimationFrame.call(dt, () => {
                      e.fakeTopEventTask || (e.fakeTopEventTask = Zone.root.scheduleEventTask(
                        "fakeTopEventTask", () => {
                          e.lastRequestAnimationFrameId = -1, Jd(e), e.isCheckStableRunning = !0, Zd(
                            e), e.isCheckStableRunning = !1
                        }, void 0, () => {}, () => {})), e.fakeTopEventTask.invoke()
                    }), Jd(e))
                }(e)
              };
              e._inner = e._inner.fork({
                name: "angular",
                properties: {
                  isAngularZone: !0
                },
                onInvokeTask: (n, r, i, s, o, l) => {
                  if (function Yw(e) {
                      return !(!Array.isArray(e) || 1 !== e.length) && !0 === e[0].data
                        ?.__ignore_ng_zone__
                    }(l)) return n.invokeTask(i, s, o, l);
                  try {
                    return fm(e), n.invokeTask(i, s, o, l)
                  } finally {
                    (e.shouldCoalesceEventChangeDetection && "eventTask" === s.type || e
                      .shouldCoalesceRunChangeDetection) && t(), hm(e)
                  }
                },
                onInvoke: (n, r, i, s, o, l, h) => {
                  try {
                    return fm(e), n.invoke(i, s, o, l, h)
                  } finally {
                    e.shouldCoalesceRunChangeDetection && t(), hm(e)
                  }
                },
                onHasTask: (n, r, i, s) => {
                  n.hasTask(i, s), r === i && ("microTask" == s.change ? (e._hasPendingMicrotasks = s
                    .microTask, Jd(e), Zd(e)) : "macroTask" == s.change && (e.hasPendingMacrotasks = s
                    .macroTask))
                },
                onHandleError: (n, r, i, s) => (n.handleError(i, s), e.runOutsideAngular(() => e.onError
                  .emit(s)), !1)
              })
            }(i)
        }
        static isInAngularZone() {
          return typeof Zone < "u" && !0 === Zone.current.get("isAngularZone")
        }
        static assertInAngularZone() {
          if (!mr.isInAngularZone()) throw new Ke(909, !1)
        }
        static assertNotInAngularZone() {
          if (mr.isInAngularZone()) throw new Ke(909, !1)
        }
        run(t, n, r) {
          return this._inner.run(t, n, r)
        }
        runTask(t, n, r, i) {
          const s = this._inner,
            o = s.scheduleEventTask("NgZoneEvent: " + i, t, qw, dm, dm);
          try {
            return s.runTask(o, n, r)
          } finally {
            s.cancelTask(o)
          }
        }
        runGuarded(t, n, r) {
          return this._inner.runGuarded(t, n, r)
        }
        runOutsideAngular(t) {
          return this._outer.run(t)
        }
      }
      const qw = {};

      function Zd(e) {
        if (0 == e._nesting && !e.hasPendingMicrotasks && !e.isStable) try {
          e._nesting++, e.onMicrotaskEmpty.emit(null)
        } finally {
          if (e._nesting--, !e.hasPendingMicrotasks) try {
            e.runOutsideAngular(() => e.onStable.emit(null))
          } finally {
            e.isStable = !0
          }
        }
      }

      function Jd(e) {
        e.hasPendingMicrotasks = !!(e._hasPendingMicrotasks || (e.shouldCoalesceEventChangeDetection || e
          .shouldCoalesceRunChangeDetection) && -1 !== e.lastRequestAnimationFrameId)
      }

      function fm(e) {
        e._nesting++, e.isStable && (e.isStable = !1, e.onUnstable.emit(null))
      }

      function hm(e) {
        e._nesting--, Zd(e)
      }
      class pm {
        constructor() {
          this.hasPendingMicrotasks = !1, this.hasPendingMacrotasks = !1, this.isStable = !0, this.onUnstable =
            new js, this.onMicrotaskEmpty = new js, this.onStable = new js, this.onError = new js
        }
        run(t, n, r) {
          return t.apply(n, r)
        }
        runGuarded(t, n, r) {
          return t.apply(n, r)
        }
        runOutsideAngular(t) {
          return t()
        }
        runTask(t, n, r, i) {
          return t.apply(n, r)
        }
      }
      var Ko = function(e) {
        return e[e.EarlyRead = 0] = "EarlyRead", e[e.Write = 1] = "Write", e[e.MixedReadWrite = 2] =
          "MixedReadWrite", e[e.Read = 3] = "Read", e
      }(Ko || {});
      const gm = {
        destroy() {}
      };

      function mm(e, t) {
        !t && no();
        const n = t?.injector ?? pt(Hi);
        if (! function _s(e) {
            return "browser" === (e ?? pt(Hi)).get(rd)
          }(n)) return gm;
        $s("NgAfterNextRender");
        const r = n.get(Tl),
          i = r.handler ??= new vm,
          s = t?.phase ?? Ko.MixedReadWrite,
          o = () => {
            i.unregister(h), l()
          },
          l = n.get(fa).onDestroy(o),
          h = hs(n, () => new ym(s, () => {
            o(), e()
          }));
        return i.register(h), {
          destroy: o
        }
      }
      class ym {
        constructor(t, n) {
          this.phase = t, this.callbackFn = n, this.zone = pt(mr), this.errorHandler = pt(so, {
            optional: !0
          }), pt(jc, {
            optional: !0
          })?.notify(1)
        }
        invoke() {
          try {
            this.zone.runOutsideAngular(this.callbackFn)
          } catch (t) {
            this.errorHandler?.handleError(t)
          }
        }
      }
      class vm {
        constructor() {
          this.executingCallbacks = !1, this.buckets = {
            [Ko.EarlyRead]: new Set,
            [Ko.Write]: new Set,
            [Ko.MixedReadWrite]: new Set,
            [Ko.Read]: new Set
          }, this.deferredCallbacks = new Set
        }
        register(t) {
          (this.executingCallbacks ? this.deferredCallbacks : this.buckets[t.phase]).add(t)
        }
        unregister(t) {
          this.buckets[t.phase].delete(t), this.deferredCallbacks.delete(t)
        }
        execute() {
          this.executingCallbacks = !0;
          for (const t of Object.values(this.buckets))
            for (const n of t) n.invoke();
          this.executingCallbacks = !1;
          for (const t of this.deferredCallbacks) this.buckets[t.phase].add(t);
          this.deferredCallbacks.clear()
        }
        destroy() {
          for (const t of Object.values(this.buckets)) t.clear();
          this.deferredCallbacks.clear()
        }
      }
      let Tl = (() => {
        class e {
          constructor() {
            this.handler = null, this.internalCallbacks = []
          }
          execute() {
            this.executeInternalCallbacks(), this.handler?.execute()
          }
          executeInternalCallbacks() {
            const n = [...this.internalCallbacks];
            this.internalCallbacks.length = 0;
            for (const r of n) r()
          }
          ngOnDestroy() {
            this.handler?.destroy(), this.handler = null, this.internalCallbacks.length = 0
          }
          static #e = this.\u0275prov = Gt({
            token: e,
            providedIn: "root",
            factory: () => new e
          })
        }
        return e
      })();

      function _o(e) {
        return !!rr(e)
      }

      function Wc(e, t, n) {
        let r = n ? e.styles : null,
          i = n ? e.classes : null,
          s = 0;
        if (null !== t)
          for (let o = 0; o < t.length; o++) {
            const l = t[o];
            "number" == typeof l ? s = l : 1 == s ? i = Kn(i, l) : 2 == s && (r = Kn(r, l + ": " + t[++o] + ";"))
          }
        n ? e.styles = r : e.stylesWithoutHost = r, n ? e.classes = i : e.classesWithoutHost = i
      }
      class Em extends Hc {
        constructor(t) {
          super(), this.ngModule = t
        }
        resolveComponentFactory(t) {
          const n = Vt(t);
          return new Nl(n, this.ngModule)
        }
      }

      function Cm(e) {
        const t = [];
        for (const n in e) {
          if (!e.hasOwnProperty(n)) continue;
          const r = e[n];
          void 0 !== r && t.push({
            propName: Array.isArray(r) ? r[0] : r,
            templateName: n
          })
        }
        return t
      }
      class Gc {
        constructor(t, n) {
          this.injector = t, this.parentInjector = n
        }
        get(t, n, r) {
          r = jr(r);
          const i = this.injector.get(t, Yd, r);
          return i !== Yd || n === Yd ? i : this.parentInjector.get(t, n, r)
        }
      }
      class Nl extends am {
        get inputs() {
          const t = this.componentDef,
            n = t.inputTransforms,
            r = Cm(t.inputs);
          if (null !== n)
            for (const i of r) n.hasOwnProperty(i.propName) && (i.transform = n[i.propName]);
          return r
        }
        get outputs() {
          return Cm(this.componentDef.outputs)
        }
        constructor(t, n) {
          super(), this.componentDef = t, this.ngModule = n, this.componentType = t.type, this.selector =
            function Io(e) {
              return e.map(ea).join(",")
            }(t.selectors), this.ngContentSelectors = t.ngContentSelectors ? t.ngContentSelectors : [], this
            .isBoundToModule = !!n
        }
        create(t, n, r, i) {
          const s = M(null);
          try {
            let o = (i = i || this.ngModule) instanceof Wr ? i : i?.injector;
            o && null !== this.componentDef.getStandaloneInjector && (o = this.componentDef.getStandaloneInjector(
              o) || o);
            const l = o ? new Gc(t, o) : t,
              h = l.get(cm, null);
            if (null === h) throw new Ke(407, !1);
            const E = l.get(zw, null),
              Q = {
                rendererFactory: h,
                sanitizer: E,
                inlineEffectRunner: null,
                afterRenderEventManager: l.get(Tl, null),
                changeDetectionScheduler: l.get(jc, null)
              },
              ne = h.createRenderer(null, this.componentDef),
              ce = this.componentDef.selectors[0][0] || "div",
              Ie = r ? function xb(e, t, n, r) {
                const s = r.get(zp, !1) || n === pi.ShadowDom,
                  o = e.selectRootElement(t, s);
                return function Lb(e) {
                  Vg(e)
                }(o), o
              }(ne, r, this.componentDef.encapsulation, l) : Mc(ne, ce, function n0(e) {
                const t = e.toLowerCase();
                return "svg" === t ? Lt : "math" === t ? "math" : null
              }(ce));
            let Ue = 512;
            this.componentDef.signals ? Ue |= 4096 : this.componentDef.onPush || (Ue |= 16);
            let ze = null;
            null !== Ie && (ze = dd(Ie, l, !0));
            const Fe = kd(0, null, null, 1, 0, null, null, null, null, null, null),
              wt = Rc(null, Fe, null, Ue, null, null, Q, ne, l, null, ze);
            let an, In;
            Uu(wt);
            try {
              const Rr = this.componentDef;
              let Oi, Qa = null;
              Rr.findHostDirectiveDefs ? (Oi = [], Qa = new Map, Rr.findHostDirectiveDefs(Rr, Oi, Qa), Oi.push(
                Rr)) : Oi = [Rr];
              const YD = function s0(e, t) {
                  const n = e[a],
                    r = yt;
                  return e[r] = t, Ea(n, r, 2, "#host", null)
                }(wt, Ie),
                fO = function o0(e, t, n, r, i, s, o) {
                  const l = i[a];
                  ! function a0(e, t, n, r) {
                    for (const i of e) t.mergedAttrs = _(t.mergedAttrs, i.hostAttrs);
                    null !== t.mergedAttrs && (Wc(t, t.mergedAttrs, !0), null !== n && Ng(r, n, t))
                  }(r, e, t, o);
                  let h = null;
                  null !== t && (h = dd(t, i[$e]));
                  const E = s.rendererFactory.createRenderer(t, n);
                  let O = 16;
                  n.signals ? O = 4096 : n.onPush && (O = 64);
                  const L = Rc(i, kg(n), null, O, i[e.index], e, s, E, null, null, h);
                  return l.firstCreatePass && Bd(l, e, r.length - 1), Pc(i, L), i[e.index] = L
                }(YD, Ie, Rr, Oi, wt, Q, ne);
              In = Za(Fe, yt), Ie && function c0(e, t, n, r) {
                if (r) Vi(e, n, ["ng-version", "17.3.11"]);
                else {
                  const {
                    attrs: i,
                    classes: s
                  } = function Ps(e) {
                    const t = [],
                      n = [];
                    let r = 1,
                      i = 2;
                    for (; r < e.length;) {
                      let s = e[r];
                      if ("string" == typeof s) 2 === i ? "" !== s && t.push(s, e[++r]) : 8 === i && n.push(s);
                      else {
                        if (!Qn(i)) break;
                        i = s
                      }
                      r++
                    }
                    return {
                      attrs: t,
                      classes: n
                    }
                  }(t.selectors[0]);
                  i && Vi(e, n, i), s && s.length > 0 && Og(e, n, s.join(" "))
                }
              }(ne, Rr, Ie, r), void 0 !== n && function u0(e, t, n) {
                const r = e.projection = [];
                for (let i = 0; i < t.length; i++) {
                  const s = n[i];
                  r.push(null != s ? Array.from(s) : null)
                }
              }(In, this.ngContentSelectors, n), an = function l0(e, t, n, r, i, s) {
                const o = Cn(),
                  l = i[a],
                  h = mi(o, i);
                jg(l, i, o, n, null, r);
                for (let O = 0; O < n.length; O++) ei($o(i, l, o.directiveStart + O, o), i);
                Hg(l, i, o), h && ei(h, i);
                const E = $o(i, l, o.directiveStart + o.componentOffset, o);
                if (e[fe] = i[fe] = E, null !== s)
                  for (const O of s) O(E, t);
                return Fd(l, o, i), E
              }(fO, Rr, Oi, Qa, wt, [d0]), $d(Fe, wt, null)
            } finally {
              ju()
            }
            return new r0(this.componentType, an, ha(In, wt), wt, In)
          } finally {
            M(s)
          }
        }
      }
      class r0 extends jw {
        constructor(t, n, r, i, s) {
          super(), this.location = r, this._rootLView = i, this._tNode = s, this.previousInputValues = null,
            this.instance = n, this.hostView = this.changeDetectorRef = new Cl(i, void 0, !1), this
            .componentType = t
        }
        setInput(t, n) {
          const r = this._tNode.inputs;
          let i;
          if (null !== r && (i = r[t])) {
            if (this.previousInputValues ??= new Map, this.previousInputValues.has(t) && Object.is(this
                .previousInputValues.get(t), n)) return;
            const s = this._rootLView;
            Hd(s[a], s, i, t, n), this.previousInputValues.set(t, n), El(ji(this._tNode.index, s))
          }
        }
        get injector() {
          return new Ar(this._tNode, this._rootLView)
        }
        destroy() {
          this.hostView.destroy()
        }
        onDestroy(t) {
          this.hostView.onDestroy(t)
        }
      }

      function d0() {
        const e = Cn();
        nc(Te()[a], e)
      }
      let zc = (() => {
        class e {
          static #e = this.__NG_ELEMENT_ID__ = f0
        }
        return e
      })();

      function f0() {
        return Sm(Cn(), Te())
      }
      const h0 = zc,
        bm = class extends h0 {
          constructor(t, n, r) {
            super(), this._lContainer = t, this._hostTNode = n, this._hostLView = r
          }
          get element() {
            return ha(this._hostTNode, this._hostLView)
          }
          get injector() {
            return new Ar(this._hostTNode, this._hostLView)
          }
          get parentInjector() {
            const t = ac(this._hostTNode, this._hostLView);
            if (Wu(t)) {
              const n = il(t, this._hostLView),
                r = rl(t);
              return new Ar(n[a].data[r + 8], n)
            }
            return new Ar(null, this._hostLView)
          }
          clear() {
            for (; this.length > 0;) this.remove(this.length - 1)
          }
          get(t) {
            const n = wm(this._lContainer);
            return null !== n && n[t] || null
          }
          get length() {
            return this._lContainer.length - xn
          }
          createEmbeddedView(t, n, r) {
            let i, s;
            "number" == typeof r ? i = r : null != r && (i = r.index, s = r.injector);
            const l = t.createEmbeddedViewImpl(n || {}, s, null);
            return this.insertImpl(l, i, Ca(this._hostTNode, null)), l
          }
          createComponent(t, n, r, i, s) {
            const o = t && ! function Me(e) {
              return "function" == typeof e
            }(t);
            let l;
            if (o) l = n;
            else {
              const ce = n || {};
              l = ce.index, r = ce.injector, i = ce.projectableNodes, s = ce.environmentInjector || ce
                .ngModuleRef
            }
            const h = o ? t : new Nl(Vt(t)),
              E = r || this.parentInjector;
            if (!s && null == h.ngModule) {
              const Ie = (o ? E : this.parentInjector).get(Wr, null);
              Ie && (s = Ie)
            }
            Vt(h.componentType ?? {});
            const ne = h.create(E, i, null, s);
            return this.insertImpl(ne.hostView, l, Ca(this._hostTNode, null)), ne
          }
          insert(t, n) {
            return this.insertImpl(t, n, !0)
          }
          insertImpl(t, n, r) {
            const i = t._lView;
            if (function sE(e) {
                return ot(e[b])
              }(i)) {
              const l = this.indexOf(t);
              if (-1 !== l) this.detach(l);
              else {
                const h = i[b],
                  E = new bm(h, h[j], h[b]);
                E.detach(E.indexOf(t))
              }
            }
            const s = this._adjustIndex(n),
              o = this._lContainer;
            return _l(o, i, s, r), t.attachToViewContainerRef(), di(rf(o), s, t), t
          }
          move(t, n) {
            return this.insert(t, n)
          }
          indexOf(t) {
            const n = wm(this._lContainer);
            return null !== n ? n.indexOf(t) : -1
          }
          remove(t) {
            const n = this._adjustIndex(t, -1),
              r = pl(this._lContainer, n);
            r && (fi(rf(this._lContainer), n), Tc(r[a], r))
          }
          detach(t) {
            const n = this._adjustIndex(t, -1),
              r = pl(this._lContainer, n);
            return r && null != fi(rf(this._lContainer), n) ? new Cl(r) : null
          }
          _adjustIndex(t, n = 0) {
            return t ?? this.length + n
          }
        };

      function wm(e) {
        return e[8]
      }

      function rf(e) {
        return e[8] || (e[8] = [])
      }

      function Sm(e, t) {
        let n;
        const r = t[e.index];
        return ot(r) ? n = r : (n = $g(r, t, null, e), t[e.index] = n, Pc(t, n)), Im(n, t, e, r), new bm(n, e, t)
      }
      let Im = function Tm(e, t, n, r) {
          if (e[Mr]) return;
          let i;
          i = 8 & n.type ? pn(r) : function p0(e, t) {
            const n = e[We],
              r = n.createComment(""),
              i = mi(t, e);
            return zo(n, Ac(n, i), r, function Tb(e, t) {
              return e.nextSibling(t)
            }(n, i), !1), r
          }(t, n), e[Mr] = i
        },
        sf = () => !1;
      class af {
        constructor(t) {
          this.queryList = t, this.matches = null
        }
        clone() {
          return new af(this.queryList)
        }
        setDirty() {
          this.queryList.setDirty()
        }
      }
      class lf {
        constructor(t = []) {
          this.queries = t
        }
        createEmbeddedView(t) {
          const n = t.queries;
          if (null !== n) {
            const r = null !== t.contentQueries ? t.contentQueries[0] : n.length,
              i = [];
            for (let s = 0; s < r; s++) {
              const o = n.getByIndex(s);
              i.push(this.queries[o.indexInDeclarationView].clone())
            }
            return new lf(i)
          }
          return null
        }
        insertView(t) {
          this.dirtyQueriesWithMatches(t)
        }
        detachView(t) {
          this.dirtyQueriesWithMatches(t)
        }
        finishViewCreation(t) {
          this.dirtyQueriesWithMatches(t)
        }
        dirtyQueriesWithMatches(t) {
          for (let n = 0; n < this.queries.length; n++) null !== hf(t, n).matches && this.queries[n].setDirty()
        }
      }
      class Am {
        constructor(t, n, r = null) {
          this.flags = n, this.read = r, this.predicate = "string" == typeof t ? function C0(e) {
            return e.split(",").map(t => t.trim())
          }(t) : t
        }
      }
      class cf {
        constructor(t = []) {
          this.queries = t
        }
        elementStart(t, n) {
          for (let r = 0; r < this.queries.length; r++) this.queries[r].elementStart(t, n)
        }
        elementEnd(t) {
          for (let n = 0; n < this.queries.length; n++) this.queries[n].elementEnd(t)
        }
        embeddedTView(t) {
          let n = null;
          for (let r = 0; r < this.length; r++) {
            const i = null !== n ? n.length : 0,
              s = this.getByIndex(r).embeddedTView(t, i);
            s && (s.indexInDeclarationView = r, null !== n ? n.push(s) : n = [s])
          }
          return null !== n ? new cf(n) : null
        }
        template(t, n) {
          for (let r = 0; r < this.queries.length; r++) this.queries[r].template(t, n)
        }
        getByIndex(t) {
          return this.queries[t]
        }
        get length() {
          return this.queries.length
        }
        track(t) {
          this.queries.push(t)
        }
      }
      class uf {
        constructor(t, n = -1) {
          this.metadata = t, this.matches = null, this.indexInDeclarationView = -1, this.crossesNgTemplate = !1,
            this._appliesToNextNode = !0, this._declarationNodeIndex = n
        }
        elementStart(t, n) {
          this.isApplyingToNode(n) && this.matchTNode(t, n)
        }
        elementEnd(t) {
          this._declarationNodeIndex === t.index && (this._appliesToNextNode = !1)
        }
        template(t, n) {
          this.elementStart(t, n)
        }
        embeddedTView(t, n) {
          return this.isApplyingToNode(t) ? (this.crossesNgTemplate = !0, this.addMatch(-t.index, n), new uf(
            this.metadata)) : null
        }
        isApplyingToNode(t) {
          if (this._appliesToNextNode && 1 & ~this.metadata.flags) {
            const n = this._declarationNodeIndex;
            let r = t.parent;
            for (; null !== r && 8 & r.type && r.index !== n;) r = r.parent;
            return n === (null !== r ? r.index : -1)
          }
          return this._appliesToNextNode
        }
        matchTNode(t, n) {
          const r = this.metadata.predicate;
          if (Array.isArray(r))
            for (let i = 0; i < r.length; i++) {
              const s = r[i];
              this.matchTNodeWithReadOption(t, n, v0(n, s)), this.matchTNodeWithReadOption(t, n, lc(n, t, s, !1,
                !1))
            } else r === bl ? 4 & n.type && this.matchTNodeWithReadOption(t, n, -1) : this
              .matchTNodeWithReadOption(t, n, lc(n, t, r, !1, !1))
        }
        matchTNodeWithReadOption(t, n, r) {
          if (null !== r) {
            const i = this.metadata.read;
            if (null !== i)
              if (i === sl || i === zc || i === bl && 4 & n.type) this.addMatch(n.index, -2);
              else {
                const s = lc(n, t, i, !1, !1);
                null !== s && this.addMatch(n.index, s)
              }
            else this.addMatch(n.index, r)
          }
        }
        addMatch(t, n) {
          null === this.matches ? this.matches = [t, n] : this.matches.push(t, n)
        }
      }

      function v0(e, t) {
        const n = e.localNames;
        if (null !== n)
          for (let r = 0; r < n.length; r += 2)
            if (n[r] === t) return n[r + 1];
        return null
      }

      function D0(e, t, n, r) {
        return -1 === n ? function _0(e, t) {
          return 11 & e.type ? ha(e, t) : 4 & e.type ? Lc(e, t) : null
        }(t, e) : -2 === n ? function E0(e, t, n) {
          return n === sl ? ha(t, e) : n === bl ? Lc(t, e) : n === zc ? Sm(t, e) : void 0
        }(e, t, r) : $o(e, e[a], n, t)
      }

      function Om(e, t, n, r) {
        const i = t[_n].queries[r];
        if (null === i.matches) {
          const s = e.data,
            o = n.matches,
            l = [];
          for (let h = 0; null !== o && h < o.length; h += 2) {
            const E = o[h];
            l.push(E < 0 ? null : D0(t, s[E], o[h + 1], n.metadata.read))
          }
          i.matches = l
        }
        return i.matches
      }

      function df(e, t, n, r) {
        const i = e.queries.getByIndex(n),
          s = i.matches;
        if (null !== s) {
          const o = Om(e, t, i, n);
          for (let l = 0; l < s.length; l += 2) {
            const h = s[l];
            if (h > 0) r.push(o[l / 2]);
            else {
              const E = s[l + 1],
                O = t[-h];
              for (let L = xn; L < O.length; L++) {
                const Q = O[L];
                Q[Tn] === Q[b] && df(Q[a], Q, E, r)
              }
              if (null !== O[pr]) {
                const L = O[pr];
                for (let Q = 0; Q < L.length; Q++) {
                  const ne = L[Q];
                  df(ne[a], ne, E, r)
                }
              }
            }
          }
        }
        return r
      }

      function Nm(e, t, n) {
        const r = new Zu(!(4 & ~n));
        return function Bb(e, t, n, r) {
          const i = Gg(t);
          i.push(n), e.firstCreatePass && zg(e).push(r, i.length - 1)
        }(e, t, r, r.destroy), (t[_n] ??= new lf).queries.push(new af(r)) - 1
      }

      function Fm(e, t, n) {
        null === e.queries && (e.queries = new cf), e.queries.track(new uf(t, n))
      }

      function hf(e, t) {
        return e.queries.getByIndex(t)
      }

      function xm(e, t) {
        const n = e[a],
          r = hf(n, t);
        return r.crossesNgTemplate ? df(n, e, t, []) : Om(n, e, r, t)
      }

      function km(e, t) {
        $s("NgSignals");
        const n = function ye(e) {
            const t = Object.create(rt);
            t.value = e;
            const n = () => (le(t), t.value);
            return n[k] = t, n
          }(e),
          r = n[k];
        return t?.equal && (r.equal = t.equal), n.set = i => ke(r, i), n.update = i => function Le(e, t) {
          qe() || Zt(), ke(e, t(e.value))
        }(r, i), n.asReadonly = Vm.bind(n), n
      }

      function Vm() {
        const e = this[k];
        if (void 0 === e.readonlyFn) {
          const t = () => this();
          t[k] = e, e.readonlyFn = t
        }
        return e.readonlyFn
      }

      function Bm(e) {
        return function Lm(e) {
          return "function" == typeof e && void 0 !== e[k]
        }(e) && "function" == typeof e.set
      }

      function gf(e) {
        let t = function Xm(e) {
            return Object.getPrototypeOf(e.prototype).constructor
          }(e.type),
          n = !0;
        const r = [e];
        for (; t;) {
          let i;
          if (On(e)) i = t.\u0275cmp || t.\u0275dir;
          else {
            if (t.\u0275cmp) throw new Ke(903, !1);
            i = t.\u0275dir
          }
          if (i) {
            if (n) {
              r.push(i);
              const o = e;
              o.inputs = qc(e.inputs), o.inputTransforms = qc(e.inputTransforms), o.declaredInputs = qc(e
                .declaredInputs), o.outputs = qc(e.outputs);
              const l = i.hostBindings;
              l && k0(e, l);
              const h = i.viewQuery,
                E = i.contentQueries;
              if (h && x0(e, h), E && L0(e, E), P0(e, i), _r(e.outputs, i.outputs), On(i) && i.data.animation) {
                const O = e.data;
                O.animation = (O.animation || []).concat(i.data.animation)
              }
            }
            const s = i.features;
            if (s)
              for (let o = 0; o < s.length; o++) {
                const l = s[o];
                l && l.ngInherit && l(e), l === gf && (n = !1)
              }
          }
          t = Object.getPrototypeOf(t)
        }! function F0(e) {
          let t = 0,
            n = null;
          for (let r = e.length - 1; r >= 0; r--) {
            const i = e[r];
            i.hostVars = t += i.hostVars, i.hostAttrs = _(i.hostAttrs, n = _(n, i.hostAttrs))
          }
        }(r)
      }

      function P0(e, t) {
        for (const n in t.inputs) {
          if (!t.inputs.hasOwnProperty(n) || e.inputs.hasOwnProperty(n)) continue;
          const r = t.inputs[n];
          if (void 0 !== r && (e.inputs[n] = r, e.declaredInputs[n] = t.declaredInputs[n], null !== t
              .inputTransforms)) {
            const i = Array.isArray(r) ? r[0] : r;
            if (!t.inputTransforms.hasOwnProperty(i)) continue;
            e.inputTransforms ??= {}, e.inputTransforms[i] = t.inputTransforms[i]
          }
        }
      }

      function qc(e) {
        return e === nr ? {} : e === $t ? [] : e
      }

      function x0(e, t) {
        const n = e.viewQuery;
        e.viewQuery = n ? (r, i) => {
          t(r, i), n(r, i)
        } : t
      }

      function L0(e, t) {
        const n = e.contentQueries;
        e.contentQueries = n ? (r, i, s) => {
          t(r, i, s), n(r, i, s)
        } : t
      }

      function k0(e, t) {
        const n = e.hostBindings;
        e.hostBindings = n ? (r, i) => {
          t(r, i), n(r, i)
        } : t
      }

      function ey(e) {
        const t = e.inputConfig,
          n = {};
        for (const r in t)
          if (t.hasOwnProperty(r)) {
            const i = t[r];
            Array.isArray(i) && i[3] && (n[r] = i[3])
          } e.inputTransforms = n
      }
      class qo {}
      class ty {}

      function $0(e, t) {
        return new mf(e, t ?? null, [])
      }
      class mf extends qo {
        constructor(t, n, r) {
          super(), this._parent = n, this._bootstrapComponents = [], this.destroyCbs = [], this
            .componentFactoryResolver = new Em(this);
          const i = rr(t);
          this._bootstrapComponents = $i(i.bootstrap), this._r3Injector = gp(t, n, [{
              provide: qo,
              useValue: this
            }, {
              provide: Hc,
              useValue: this.componentFactoryResolver
            }, ...r], Jt(t), new Set(["environment"])), this._r3Injector.resolveInjectorInitializers(), this
            .instance = this._r3Injector.get(t)
        }
        get injector() {
          return this._r3Injector
        }
        destroy() {
          const t = this._r3Injector;
          !t.destroyed && t.destroy(), this.destroyCbs.forEach(n => n()), this.destroyCbs = null
        }
        onDestroy(t) {
          this.destroyCbs.push(t)
        }
      }
      class yf extends ty {
        constructor(t) {
          super(), this.moduleType = t
        }
        create(t) {
          return new mf(this.moduleType, t, [])
        }
      }
      class ny extends qo {
        constructor(t) {
          super(), this.componentFactoryResolver = new Em(this), this.instance = null;
          const n = new ds([...t.providers, {
            provide: qo,
            useValue: this
          }, {
            provide: Hc,
            useValue: this.componentFactoryResolver
          }], t.parent || xs(), t.debugName, new Set(["environment"]));
          this.injector = n, t.runEnvironmentInitializers && n.resolveInjectorInitializers()
        }
        destroy() {
          this.injector.destroy()
        }
        onDestroy(t) {
          this.injector.onDestroy(t)
        }
      }

      function vf(e, t, n = null) {
        return new ny({
          providers: e,
          parent: t,
          debugName: n,
          runEnvironmentInitializers: !0
        }).injector
      }
      let Sa = (() => {
        class e {
          constructor() {
            this.taskId = 0, this.pendingTasks = new Set, this.hasPendingTasks = new dn.t(!1)
          }
          get _hasPendingTasks() {
            return this.hasPendingTasks.value
          }
          add() {
            this._hasPendingTasks || this.hasPendingTasks.next(!0);
            const n = this.taskId++;
            return this.pendingTasks.add(n), n
          }
          remove(n) {
            this.pendingTasks.delete(n), 0 === this.pendingTasks.size && this._hasPendingTasks && this
              .hasPendingTasks.next(!1)
          }
          ngOnDestroy() {
            this.pendingTasks.clear(), this._hasPendingTasks && this.hasPendingTasks.next(!1)
          }
          static #e = this.\u0275fac = function(r) {
            return new(r || e)
          };
          static #t = this.\u0275prov = Gt({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
          })
        }
        return e
      })();

      function Xc(e) {
        return !!_f(e) && (Array.isArray(e) || !(e instanceof Map) && Symbol.iterator in e)
      }

      function _f(e) {
        return null !== e && ("function" == typeof e || "object" == typeof e)
      }

      function Ws(e, t, n) {
        return e[t] = n
      }

      function Pl(e, t) {
        return e[t]
      }

      function sr(e, t, n) {
        return !Object.is(e[t], n) && (e[t] = n, !0)
      }

      function Qo(e, t, n, r) {
        const i = sr(e, t, n);
        return sr(e, t + 1, r) || i
      }

      function Yc(e, t, n, r, i) {
        const s = Qo(e, t, n, r);
        return sr(e, t + 2, i) || s
      }

      function ns(e, t, n, r, i, s) {
        const o = Qo(e, t, n, r);
        return Qo(e, t + 2, i, s) || o
      }

      function Ia(e, t, n, r, i, s, o, l) {
        const h = Te(),
          E = Yt(),
          O = e + yt,
          L = E.firstCreatePass ? function X0(e, t, n, r, i, s, o, l, h) {
            const E = t.consts,
              O = Ea(t, e, 4, o || null, ks(E, l));
            Vd(t, n, O, ks(E, h)), nc(t, O);
            const L = O.tView = kd(2, O, r, i, s, t.directiveRegistry, t.pipeRegistry, null, t.schemas, E, null);
            return null !== t.queries && (t.queries.template(t, O), L.queries = t.queries.embeddedTView(O)), O
          }(O, E, h, t, n, r, i, s, o) : E.data[O];
        Vs(L, !1);
        const Q = ry(E, h, L, e);
        tl() && Oc(E, h, Q, L), ei(Q, h);
        const ne = $g(Q, h, Q, L);
        return h[O] = ne, Pc(h, ne),
          function Mm(e, t, n) {
            return sf(e, t, n)
          }(ne, L, h), Tr(L) && xd(E, h, L), null != o && Ld(h, L, l), Ia
      }
      let ry = function iy(e, t, n, r) {
        return Bs(!0), t[We].createComment("")
      };

      function Af(e, t, n, r) {
        const i = Te();
        return sr(i, vs(), t) && (Yt(), Hs(kn(), i, e, t, n, r)), Af
      }

      function Fa(e, t, n, r) {
        return sr(e, vs(), n) ? t + lt(n) + r : Bt
      }

      function xa(e, t, n, r, i, s) {
        const l = Qo(e, function ro() {
          return Ot.lFrame.bindingIndex
        }(), n, i);
        return io(2), l ? t + lt(n) + r + lt(i) + s : Bt
      }

      function ru(e, t) {
        return e << 17 | t << 2
      }

      function Co(e) {
        return e >> 17 & 32767
      }

      function Of(e) {
        return 2 | e
      }

      function Yo(e) {
        return (131068 & e) >> 2
      }

      function Nf(e, t) {
        return -131069 & e | t << 2
      }

      function Rf(e) {
        return 1 | e
      }

      function xy(e, t, n, r) {
        const i = e[n + 1],
          s = null === t;
        let o = r ? Co(i) : Yo(i),
          l = !1;
        for (; 0 !== o && (!1 === l || s);) {
          const E = e[o + 1];
          LS(e[o], t) && (l = !0, e[o + 1] = r ? Rf(E) : Of(E)), o = r ? Co(E) : Yo(E)
        }
        l && (e[n + 1] = r ? Of(i) : Rf(i))
      }

      function LS(e, t) {
        return null === e || null == t || (Array.isArray(e) ? e[1] : e) === t || !(!Array.isArray(e) ||
          "string" != typeof t) && wr(e, t) >= 0
      }
      const Or = {
        textEnd: 0,
        key: 0,
        keyEnd: 0,
        value: 0,
        valueEnd: 0
      };

      function Ly(e) {
        return e.substring(Or.key, Or.keyEnd)
      }

      function kS(e) {
        return e.substring(Or.value, Or.valueEnd)
      }

      function ky(e, t) {
        const n = Or.textEnd;
        return n === t ? -1 : (t = Or.keyEnd = function US(e, t, n) {
          for (; t < n && e.charCodeAt(t) > 32;) t++;
          return t
        }(e, Or.key = t, n), Ha(e, t, n))
      }

      function Vy(e, t) {
        const n = Or.textEnd;
        let r = Or.key = Ha(e, t, n);
        return n === r ? -1 : (r = Or.keyEnd = function jS(e, t, n) {
          let r;
          for (; t < n && (45 === (r = e.charCodeAt(t)) || 95 === r || (-33 & r) >= 65 && (-33 & r) <= 90 ||
              r >= 48 && r <= 57);) t++;
          return t
        }(e, r, n), r = Uy(e, r, n), r = Or.value = Ha(e, r, n), r = Or.valueEnd = function HS(e, t, n) {
          let r = -1,
            i = -1,
            s = -1,
            o = t,
            l = o;
          for (; o < n;) {
            const h = e.charCodeAt(o++);
            if (59 === h) return l;
            34 === h || 39 === h ? l = o = jy(e, h, o, n) : t === o - 4 && 85 === s && 82 === i && 76 === r &&
              40 === h ? l = o = jy(e, 41, o, n) : h > 32 && (l = o), s = i, i = r, r = -33 & h
          }
          return l
        }(e, r, n), Uy(e, r, n))
      }

      function By(e) {
        Or.key = 0, Or.keyEnd = 0, Or.value = 0, Or.valueEnd = 0, Or.textEnd = e.length
      }

      function Ha(e, t, n) {
        for (; t < n && e.charCodeAt(t) <= 32;) t++;
        return t
      }

      function Uy(e, t, n, r) {
        return (t = Ha(e, t, n)) < n && t++, t
      }

      function jy(e, t, n, r) {
        let i = -1,
          s = n;
        for (; s < r;) {
          const o = e.charCodeAt(s++);
          if (o == t && 92 !== i) return s;
          i = 92 == o && 92 === i ? 0 : o
        }
        throw new Error
      }

      function Pf(e, t, n) {
        const r = Te();
        return sr(r, vs(), t) && Ti(Yt(), kn(), r, e, t, r[We], n, !1), Pf
      }

      function Ff(e, t, n, r, i) {
        const o = i ? "class" : "style";
        Hd(e, n, t.inputs[o], o, r)
      }

      function xf(e, t, n) {
        return Es(e, t, n, !1), xf
      }

      function Lf(e, t) {
        return Es(e, t, null, !0), Lf
      }

      function Ds(e) {
        Cs(Gy, $S, e, !1)
      }

      function $S(e, t) {
        for (let n = function BS(e) {
            return By(e), Vy(e, Ha(e, 0, Or.textEnd))
          }(t); n >= 0; n = Vy(t, n)) Gy(e, Ly(t), kS(t))
      }

      function Hy(e) {
        Cs(QS, Gs, e, !0)
      }

      function Gs(e, t) {
        for (let n = function VS(e) {
            return By(e), ky(e, Ha(e, 0, Or.textEnd))
          }(t); n >= 0; n = ky(t, n)) tr(e, Ly(t), !0)
      }

      function Es(e, t, n, r) {
        const i = Te(),
          s = Yt(),
          o = io(2);
        s.firstUpdatePass && Wy(s, e, o, r), t !== Bt && sr(i, o, t) && zy(s, s.data[Jr()], i, i[We], e, i[o +
          1] = function YS(e, t) {
            return null == e || "" === e || ("string" == typeof t ? e += t : "object" == typeof e && (e = Jt(oo(
              e)))), e
          }(t, n), r, o)
      }

      function Cs(e, t, n, r) {
        const i = Yt(),
          s = io(2);
        i.firstUpdatePass && Wy(i, null, s, r);
        const o = Te();
        if (n !== Bt && sr(o, s, n)) {
          const l = i.data[Jr()];
          if (qy(l, r) && !$y(i, s)) {
            let h = r ? l.classesWithoutHost : l.stylesWithoutHost;
            null !== h && (n = Kn(h, n || "")), Ff(i, l, o, n, r)
          } else ! function XS(e, t, n, r, i, s, o, l) {
            i === Bt && (i = $t);
            let h = 0,
              E = 0,
              O = 0 < i.length ? i[0] : null,
              L = 0 < s.length ? s[0] : null;
            for (; null !== O || null !== L;) {
              const Q = h < i.length ? i[h + 1] : void 0,
                ne = E < s.length ? s[E + 1] : void 0;
              let Ie, ce = null;
              O === L ? (h += 2, E += 2, Q !== ne && (ce = L, Ie = ne)) : null === L || null !== O && O < L ? (
                  h += 2, ce = O) : (E += 2, ce = L, Ie = ne), null !== ce && zy(e, t, n, r, ce, Ie, o, l), O =
                h < i.length ? i[h] : null, L = E < s.length ? s[E] : null
            }
          }(i, l, o, o[We], o[s + 1], o[s + 1] = function qS(e, t, n) {
            if (null == n || "" === n) return $t;
            const r = [],
              i = oo(n);
            if (Array.isArray(i))
              for (let s = 0; s < i.length; s++) e(r, i[s], !0);
            else if ("object" == typeof i)
              for (const s in i) i.hasOwnProperty(s) && e(r, s, i[s]);
            else "string" == typeof i && t(r, i);
            return r
          }(e, t, n), r, s)
        }
      }

      function $y(e, t) {
        return t >= e.expandoStartIndex
      }

      function Wy(e, t, n, r) {
        const i = e.data;
        if (null === i[n + 1]) {
          const s = i[Jr()],
            o = $y(e, n);
          qy(s, r) && null === t && !o && (t = !1), t = function WS(e, t, n, r) {
              const i = function Vu(e) {
                const t = Ot.lFrame.currentDirectiveIndex;
                return -1 === t ? null : e[t]
              }(e);
              let s = r ? t.residualClasses : t.residualStyles;
              if (null === i) 0 === (r ? t.classBindings : t.styleBindings) && (n = Vl(n = kf(null, e, t, n, r), t
                .attrs, r), s = null);
              else {
                const o = t.directiveStylingLast;
                if (-1 === o || e[o] !== i)
                  if (n = kf(i, e, t, n, r), null === s) {
                    let h = function GS(e, t, n) {
                      const r = n ? t.classBindings : t.styleBindings;
                      if (0 !== Yo(r)) return e[Co(r)]
                    }(e, t, r);
                    void 0 !== h && Array.isArray(h) && (h = kf(null, e, t, h[1], r), h = Vl(h, t.attrs, r),
                      function zS(e, t, n, r) {
                        e[Co(n ? t.classBindings : t.styleBindings)] = r
                      }(e, t, r, h))
                  } else s = function KS(e, t, n) {
                    let r;
                    const i = t.directiveEnd;
                    for (let s = 1 + t.directiveStylingLast; s < i; s++) r = Vl(r, e[s].hostAttrs, n);
                    return Vl(r, t.attrs, n)
                  }(e, t, r)
              }
              return void 0 !== s && (r ? t.residualClasses = s : t.residualStyles = s), n
            }(i, s, t, r),
            function FS(e, t, n, r, i, s) {
              let o = s ? t.classBindings : t.styleBindings,
                l = Co(o),
                h = Yo(o);
              e[r] = n;
              let O, E = !1;
              if (Array.isArray(n) ? (O = n[1], (null === O || wr(n, O) > 0) && (E = !0)) : O = n, i)
                if (0 !== h) {
                  const Q = Co(e[l + 1]);
                  e[r + 1] = ru(Q, l), 0 !== Q && (e[Q + 1] = Nf(e[Q + 1], r)), e[l + 1] = function RS(e, t) {
                    return 131071 & e | t << 17
                  }(e[l + 1], r)
                } else e[r + 1] = ru(l, 0), 0 !== l && (e[l + 1] = Nf(e[l + 1], r)), l = r;
              else e[r + 1] = ru(h, 0), 0 === l ? l = r : e[h + 1] = Nf(e[h + 1], r), h = r;
              E && (e[r + 1] = Of(e[r + 1])), xy(e, O, r, !0), xy(e, O, r, !1),
                function xS(e, t, n, r, i) {
                  const s = i ? e.residualClasses : e.residualStyles;
                  null != s && "string" == typeof t && wr(s, t) >= 0 && (n[r + 1] = Rf(n[r + 1]))
                }(t, O, e, r, s), o = ru(l, h), s ? t.classBindings = o : t.styleBindings = o
            }(i, s, t, n, o, r)
        }
      }

      function kf(e, t, n, r, i) {
        let s = null;
        const o = n.directiveEnd;
        let l = n.directiveStylingLast;
        for (-1 === l ? l = n.directiveStart : l++; l < o && (s = t[l], r = Vl(r, s.hostAttrs, i), s !== e);) l++;
        return null !== e && (n.directiveStylingLast = l), r
      }

      function Vl(e, t, n) {
        const r = n ? 1 : 2;
        let i = -1;
        if (null !== t)
          for (let s = 0; s < t.length; s++) {
            const o = t[s];
            "number" == typeof o ? i = o : i === r && (Array.isArray(e) || (e = void 0 === e ? [] : ["", e]), tr(
              e, o, !!n || t[++s]))
          }
        return void 0 === e ? null : e
      }

      function Gy(e, t, n) {
        tr(e, t, oo(n))
      }

      function QS(e, t, n) {
        const r = String(t);
        "" !== r && !r.includes(" ") && tr(e, r, n)
      }

      function zy(e, t, n, r, i, s, o, l) {
        if (!(3 & t.type)) return;
        const h = e.data,
          E = h[l + 1],
          O = function PS(e) {
            return !(1 & ~e)
          }(E) ? Ky(h, t, n, i, Yo(E), o) : void 0;
        iu(O) || (iu(s) || function NS(e) {
          return !(2 & ~e)
        }(E) && (s = Ky(h, null, n, i, l, o)), function Nb(e, t, n, r, i) {
          if (t) i ? e.addClass(n, r) : e.removeClass(n, r);
          else {
            let s = -1 === r.indexOf("-") ? void 0 : Ic.DashCase;
            null == i ? e.removeStyle(n, r, s) : ("string" == typeof i && i.endsWith("!important") && (i = i
              .slice(0, -10), s |= Ic.Important), e.setStyle(n, r, i, s))
          }
        }(r, o, Ya(Jr(), n), i, s))
      }

      function Ky(e, t, n, r, i, s) {
        const o = null === t;
        let l;
        for (; i > 0;) {
          const h = e[i],
            E = Array.isArray(h),
            O = E ? h[1] : h,
            L = null === O;
          let Q = n[i + 1];
          Q === Bt && (Q = L ? $t : void 0);
          let ne = L ? Li(Q, r) : O === r ? Q : void 0;
          if (E && !iu(ne) && (ne = Li(h, r)), iu(ne) && (l = ne, o)) return l;
          const ce = e[i + 1];
          i = o ? Co(ce) : Yo(ce)
        }
        if (null !== t) {
          let h = s ? t.residualClasses : t.residualStyles;
          null != h && (l = Li(h, r))
        }
        return l
      }

      function iu(e) {
        return void 0 !== e
      }

      function qy(e, t) {
        return !!(e.flags & (t ? 8 : 16))
      }

      function su(e, t, n, r) {
        const i = Te(),
          s = Yt(),
          o = yt + e,
          l = i[We],
          h = s.firstCreatePass ? function DI(e, t, n, r, i, s) {
            const o = t.consts,
              h = Ea(t, e, 2, r, ks(o, i));
            return Vd(t, n, h, ks(o, s)), null !== h.attrs && Wc(h, h.attrs, !1), null !== h.mergedAttrs && Wc(h,
              h.mergedAttrs, !0), null !== t.queries && t.queries.elementStart(t, h), h
          }(o, s, i, t, n, r) : s.data[o],
          E = Zy(s, i, h, l, t, e);
        i[o] = E;
        const O = Tr(h);
        return Vs(h, !0), Ng(l, E, h), ! function Fl(e) {
            return !(32 & ~e.flags)
          }(h) && tl() && Oc(s, i, E, h), 0 === function aE() {
            return Ot.lFrame.elementDepthCount
          }() && ei(E, i),
          function lE() {
            Ot.lFrame.elementDepthCount++
          }(), O && (xd(s, i, h), Fd(s, h, i)), null !== r && Ld(i, h), su
      }

      function ou() {
        let e = Cn();
        xu() ? Lu() : (e = e.parent, Vs(e, !1));
        const t = e;
        (function uE(e) {
          return Ot.skipHydrationRootTNode === e
        })(t) && function pE() {
          Ot.skipHydrationRootTNode = null
        }(),
        function cE() {
          Ot.lFrame.elementDepthCount--
        }();
        const n = Yt();
        return n.firstCreatePass && (nc(n, e), Kt(e) && n.queries.elementEnd(e)), null != t.classesWithoutHost &&
          function TE(e) {
            return !!(8 & e.flags)
          }(t) && Ff(n, t, Te(), t.classesWithoutHost, !0), null != t.stylesWithoutHost && function AE(e) {
            return !!(16 & e.flags)
          }(t) && Ff(n, t, Te(), t.stylesWithoutHost, !1), ou
      }

      function Hf(e, t, n, r) {
        return su(e, t, n, r), ou(), Hf
      }
      let Zy = (e, t, n, r, i, s) => (Bs(!0), Mc(r, i, function Qh() {
        return Ot.lFrame.currentNamespace
      }()));

      function au(e, t, n) {
        const r = Te(),
          i = Yt(),
          s = e + yt,
          o = i.firstCreatePass ? function bI(e, t, n, r, i) {
            const s = t.consts,
              o = ks(s, r),
              l = Ea(t, e, 8, "ng-container", o);
            return null !== o && Wc(l, o, !0), Vd(t, n, l, ks(s, i)), null !== t.queries && t.queries
              .elementStart(t, l), l
          }(s, i, r, t, n) : i.data[s];
        Vs(o, !0);
        const l = Jy(i, r, o, e);
        return r[s] = l, tl() && Oc(i, r, l, o), ei(l, r), Tr(o) && (xd(i, r, o), Fd(i, o, r)), null != n && Ld(r,
          o), au
      }

      function lu() {
        let e = Cn();
        const t = Yt();
        return xu() ? Lu() : (e = e.parent, Vs(e, !1)), t.firstCreatePass && (nc(t, e), Kt(e) && t.queries
          .elementEnd(e)), lu
      }

      function $f(e, t, n) {
        return au(e, t, n), lu(), $f
      }
      let Jy = (e, t, n, r) => (Bs(!0), Md(t[We], ""));

      function ev() {
        return Te()
      }
      const Zo = void 0;
      var MI = ["en", [
          ["a", "p"],
          ["AM", "PM"], Zo
        ],
        [
          ["AM", "PM"], Zo, Zo
        ],
        [
          ["S", "M", "T", "W", "T", "F", "S"],
          ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
          ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
          ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]
        ], Zo, [
          ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
          ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
          ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
            "November", "December"
          ]
        ], Zo, [
          ["B", "A"],
          ["BC", "AD"],
          ["Before Christ", "Anno Domini"]
        ], 0, [6, 0],
        ["M/d/yy", "MMM d, y", "MMMM d, y", "EEEE, MMMM d, y"],
        ["h:mm a", "h:mm:ss a", "h:mm:ss a z", "h:mm:ss a zzzz"],
        ["{1}, {0}", Zo, "{1} 'at' {0}", Zo],
        [".", ",", ";", "%", "+", "-", "E", "\xd7", "\u2030", "\u221e", "NaN", ":"],
        ["#,##0.###", "#,##0%", "\xa4#,##0.00", "#E0"], "USD", "$", "US Dollar", {}, "ltr",
        function II(e) {
          const n = Math.floor(Math.abs(e)),
            r = e.toString().replace(/^[^.]*\.?/, "").length;
          return 1 === n && 0 === r ? 1 : 5
        }
      ];
      let $a = {};

      function Wf(e) {
        const t = function TI(e) {
          return e.toLowerCase().replace(/_/g, "-")
        }(e);
        let n = iv(t);
        if (n) return n;
        const r = t.split("-")[0];
        if (n = iv(r), n) return n;
        if ("en" === r) return MI;
        throw new Ke(701, !1)
      }

      function rv(e) {
        return Wf(e)[Wa.PluralCase]
      }

      function iv(e) {
        return e in $a || ($a[e] = dt.ng && dt.ng.common && dt.ng.common.locales && dt.ng.common.locales[e]), $a[
          e]
      }
      var Wa = function(e) {
        return e[e.LocaleId = 0] = "LocaleId", e[e.DayPeriodsFormat = 1] = "DayPeriodsFormat", e[e
            .DayPeriodsStandalone = 2] = "DayPeriodsStandalone", e[e.DaysFormat = 3] = "DaysFormat", e[e
            .DaysStandalone = 4] = "DaysStandalone", e[e.MonthsFormat = 5] = "MonthsFormat", e[e
            .MonthsStandalone = 6] = "MonthsStandalone", e[e.Eras = 7] = "Eras", e[e.FirstDayOfWeek = 8] =
          "FirstDayOfWeek", e[e.WeekendRange = 9] = "WeekendRange", e[e.DateFormat = 10] = "DateFormat", e[e
            .TimeFormat = 11] = "TimeFormat", e[e.DateTimeFormat = 12] = "DateTimeFormat", e[e.NumberSymbols =
            13] = "NumberSymbols", e[e.NumberFormats = 14] = "NumberFormats", e[e.CurrencyCode = 15] =
          "CurrencyCode", e[e.CurrencySymbol = 16] = "CurrencySymbol", e[e.CurrencyName = 17] = "CurrencyName",
          e[e.Currencies = 18] = "Currencies", e[e.Directionality = 19] = "Directionality", e[e.PluralCase =
          20] = "PluralCase", e[e.ExtraData = 21] = "ExtraData", e
      }(Wa || {});
      const Ga = "en-US";
      let sv = Ga;

      function Kf(e, t, n, r) {
        const i = Te(),
          s = Yt(),
          o = Cn();
        return qf(s, i, i[We], o, e, t, r), Kf
      }

      function qf(e, t, n, r, i, s, o) {
        const l = Tr(r),
          E = e.firstCreatePass && zg(e),
          O = t[fe],
          L = Gg(t);
        let Q = !0;
        if (3 & r.type || o) {
          const Ie = mi(r, t),
            Ue = o ? o(Ie) : Ie,
            ze = L.length,
            Fe = o ? an => o(pn(an[r.index])) : r.index;
          let wt = null;
          if (!o && l && (wt = function wM(e, t, n, r) {
              const i = e.cleanup;
              if (null != i)
                for (let s = 0; s < i.length - 1; s += 2) {
                  const o = i[s];
                  if (o === n && i[s + 1] === r) {
                    const l = t[de],
                      h = i[s + 2];
                    return l.length > h ? l[h] : null
                  }
                  "string" == typeof o && (s += 2)
                }
              return null
            }(e, t, i, r.index)), null !== wt)(wt.__ngLastListenerFn__ || wt).__ngNextListenerFn__ = s, wt
            .__ngLastListenerFn__ = s, Q = !1;
          else {
            s = Pv(r, t, O, s, !1);
            const an = n.listen(Ue, i, s);
            L.push(s, an), E && E.push(i, Fe, ze, ze + 1)
          }
        } else s = Pv(r, t, O, s, !1);
        const ne = r.outputs;
        let ce;
        if (Q && null !== ne && (ce = ne[i])) {
          const Ie = ce.length;
          if (Ie)
            for (let Ue = 0; Ue < Ie; Ue += 2) {
              const In = t[ce[Ue]][ce[Ue + 1]].subscribe(s),
                Rr = L.length;
              L.push(s, In), E && E.push(i, r.index, Rr, -(Rr + 1))
            }
        }
      }

      function Rv(e, t, n, r) {
        const i = M(null);
        try {
          return mt(6, t, n), !1 !== n(r)
        } catch (s) {
          return Fc(e, s), !1
        } finally {
          mt(7, t, n), M(i)
        }
      }

      function Pv(e, t, n, r, i) {
        return function s(o) {
          if (o === Function) return r;
          El(e.componentOffset > -1 ? ji(e.index, t) : t);
          let h = Rv(t, n, r, o),
            E = s.__ngNextListenerFn__;
          for (; E;) h = Rv(t, n, E, o) && h, E = E.__ngNextListenerFn__;
          return i && !1 === h && o.preventDefault(), h
        }
      }

      function Fv(e = 1) {
        return function DE(e) {
          return (Ot.lFrame.contextLView = function Fh(e, t) {
            for (; e > 0;) t = t[Dt], e--;
            return t
          }(e, Ot.lFrame.contextLView))[fe]
        }(e)
      }

      function SM(e, t) {
        let n = null;
        const r = function $n(e) {
          const t = e.attrs;
          if (null != t) {
            const n = t.indexOf(5);
            if (!(1 & n)) return t[n + 1]
          }
          return null
        }(e);
        for (let i = 0; i < t.length; i++) {
          const s = t[i];
          if ("*" !== s) {
            if (null === r ? Bi(e, s, !0) : Rs(r, s)) return i
          } else n = i
        }
        return n
      }

      function xv(e) {
        const t = Te()[ft][j];
        if (!t.projection) {
          const r = t.projection = function kr(e, t) {
              const n = [];
              for (let r = 0; r < e; r++) n.push(t);
              return n
            }(e ? e.length : 1, null),
            i = r.slice();
          let s = t.child;
          for (; null !== s;) {
            const o = e ? SM(s, e) : 0;
            null !== o && (i[o] ? i[o].projectionNext = s : r[o] = s, i[o] = s), s = s.next
          }
        }
      }

      function Lv(e, t = 0, n) {
        const r = Te(),
          i = Yt(),
          s = Ea(i, yt + e, 16, null, n || null);
        null === s.projection && (s.projection = t), Lu(), (!r[q] || la()) && 32 & ~s.flags && function Ab(e, t,
          n) {
          Ag(t[We], 0, t, n, Ad(e, n, t), bg(n.parent || t[j], n, t))
        }(i, r, s)
      }

      function Qf(e, t, n) {
        return hu(e, "", t, "", n), Qf
      }

      function hu(e, t, n, r, i) {
        const s = Te(),
          o = Fa(s, t, n, r);
        return o !== Bt && Ti(Yt(), kn(), s, e, o, s[We], i, !1), hu
      }

      function Xf(e, t, n, r, i, s, o) {
        const l = Te(),
          h = xa(l, t, n, r, i, s);
        return h !== Bt && Ti(Yt(), kn(), l, e, h, l[We], o, !1), Xf
      }

      function Wv(e, t, n, r) {
        ! function Pm(e, t, n, r) {
          const i = Yt();
          if (i.firstCreatePass) {
            const s = Cn();
            Fm(i, new Am(t, n, r), s.index),
              function b0(e, t) {
                const n = e.contentQueries || (e.contentQueries = []);
                t !== (n.length ? n[n.length - 1] : -1) && n.push(e.queries.length - 1, t)
              }(i, e), !(2 & ~n) && (i.staticContentQueries = !0)
          }
          return Nm(i, Te(), n)
        }(e, t, n, r)
      }

      function Gv(e, t, n) {
        ! function Rm(e, t, n) {
          const r = Yt();
          return r.firstCreatePass && (Fm(r, new Am(e, t, n), -1), !(2 & ~t) && (r.staticViewQueries = !0)), Nm(r,
            Te(), t)
        }(e, t, n)
      }

      function zv(e) {
        const t = Te(),
          n = Yt(),
          r = Bu();
        tc(r + 1);
        const i = hf(n, r);
        if (e.dirty && function iE(e) {
            return !(4 & ~e[m])
          }(t) === !(2 & ~i.metadata.flags)) {
          if (null === i.matches) e.reset([]);
          else {
            const s = xm(t, r);
            e.reset(s, _p), e.notifyOnChanges()
          }
          return !0
        }
        return !1
      }

      function Kv() {
        return function ff(e, t) {
          return e[_n].queries[t].queryList
        }(Te(), Bu())
      }

      function qv(e) {
        return aa(function gE() {
          return Ot.lFrame.contextLView
        }(), yt + e)
      }

      function i_(e, t = "") {
        const n = Te(),
          r = Yt(),
          i = e + yt,
          s = r.firstCreatePass ? Ea(r, i, 1, t, null) : r.data[i],
          o = s_(r, n, s, t, e);
        n[i] = o, tl() && Oc(r, n, o, s), Vs(s, !1)
      }
      let s_ = (e, t, n, r, i) => (Bs(!0), function Id(e, t) {
        return e.createText(t)
      }(t[We], r));

      function Yf(e) {
        return pu("", e, ""), Yf
      }

      function pu(e, t, n) {
        const r = Te(),
          i = Fa(r, e, t, n);
        return i !== Bt && lo(r, Jr(), i), pu
      }

      function Zf(e, t, n, r, i) {
        const s = Te(),
          o = xa(s, e, t, n, r, i);
        return o !== Bt && lo(s, Jr(), o), Zf
      }

      function Jf(e, t, n) {
        Bm(t) && (t = t());
        const r = Te();
        return sr(r, vs(), t) && Ti(Yt(), kn(), r, e, t, r[We], n, !1), Jf
      }

      function h_(e, t) {
        const n = Bm(e);
        return n && e.set(t), n
      }

      function eh(e, t) {
        const n = Te(),
          r = Yt(),
          i = Cn();
        return qf(r, n, n[We], i, e, t), eh
      }

      function th(e, t, n, r, i) {
        if (e = re(e), Array.isArray(e))
          for (let s = 0; s < e.length; s++) th(e[s], t, n, r, i);
        else {
          const s = Yt(),
            o = Te(),
            l = Cn();
          let h = wi(e) ? e : re(e.provide);
          const E = Fo(e),
            O = 1048575 & l.providerIndexes,
            L = l.directiveStart,
            Q = l.providerIndexes >> 20;
          if (wi(e) || !e.multi) {
            const ne = new nl(E, i, Da),
              ce = rh(h, t, i ? O : O + Q, L); - 1 === ce ? (Ku(oc(l, o), s, h), nh(s, e, t.length), t.push(h), l
                .directiveStart++, l.directiveEnd++, i && (l.providerIndexes += 1048576), n.push(ne), o.push(ne)
                ) : (n[ce] = ne, o[ce] = ne)
          } else {
            const ne = rh(h, t, O + Q, L),
              ce = rh(h, t, O, O + Q),
              Ue = ce >= 0 && n[ce];
            if (i && !Ue || !i && !(ne >= 0 && n[ne])) {
              Ku(oc(l, o), s, h);
              const ze = function WM(e, t, n, r, i) {
                const s = new nl(e, n, Da);
                return s.multi = [], s.index = t, s.componentProviders = 0, p_(s, i, r && !n), s
              }(i ? $M : HM, n.length, i, r, E);
              !i && Ue && (n[ce].providerFactory = ze), nh(s, e, t.length, 0), t.push(h), l.directiveStart++, l
                .directiveEnd++, i && (l.providerIndexes += 1048576), n.push(ze), o.push(ze)
            } else nh(s, e, ne > -1 ? ne : ce, p_(n[i ? ce : ne], E, !i && r));
            !i && r && Ue && n[ce].componentProviders++
          }
        }
      }

      function nh(e, t, n, r) {
        const i = wi(t),
          s = function Ro(e) {
            return !!e.useClass
          }(t);
        if (i || s) {
          const h = (s ? re(t.useClass) : t).prototype.ngOnDestroy;
          if (h) {
            const E = e.destroyHooks || (e.destroyHooks = []);
            if (!i && t.multi) {
              const O = E.indexOf(n); - 1 === O ? E.push(n, [r, h]) : E[O + 1].push(r, h)
            } else E.push(n, h)
          }
        }
      }

      function p_(e, t, n) {
        return n && e.componentProviders++, e.multi.push(t) - 1
      }

      function rh(e, t, n, r) {
        for (let i = n; i < r; i++)
          if (t[i] === e) return i;
        return -1
      }

      function HM(e, t, n, r) {
        return ih(this.multi, [])
      }

      function $M(e, t, n, r) {
        const i = this.multi;
        let s;
        if (this.providerFactory) {
          const o = this.providerFactory.componentProviders,
            l = $o(n, n[a], this.providerFactory.index, r);
          s = l.slice(0, o), ih(i, s);
          for (let h = o; h < l.length; h++) s.push(l[h])
        } else s = [], ih(i, s);
        return s
      }

      function ih(e, t) {
        for (let n = 0; n < e.length; n++) t.push((0, e[n])());
        return t
      }

      function g_(e, t = []) {
        return n => {
          n.providersResolver = (r, i) => function jM(e, t, n) {
            const r = Yt();
            if (r.firstCreatePass) {
              const i = On(e);
              th(n, r.data, r.blueprint, i, !0), th(t, r.data, r.blueprint, i, !1)
            }
          }(r, i ? i(e) : e, t)
        }
      }
      let GM = (() => {
        class e {
          constructor(n) {
            this._injector = n, this.cachedInjectors = new Map
          }
          getOrCreateStandaloneInjector(n) {
            if (!n.standalone) return null;
            if (!this.cachedInjectors.has(n)) {
              const r = $r(0, n.type),
                i = r.length > 0 ? vf([r], this._injector, `Standalone[${n.type.name}]`) : null;
              this.cachedInjectors.set(n, i)
            }
            return this.cachedInjectors.get(n)
          }
          ngOnDestroy() {
            try {
              for (const n of this.cachedInjectors.values()) null !== n && n.destroy()
            } finally {
              this.cachedInjectors.clear()
            }
          }
          static #e = this.\u0275prov = Gt({
            token: e,
            providedIn: "environment",
            factory: () => new e(en(Wr))
          })
        }
        return e
      })();

      function m_(e) {
        $s("NgStandalone"), e.getStandaloneInjector = t => t.get(GM).getOrCreateStandaloneInjector(e)
      }

      function v_(e, t, n) {
        const r = yi() + e,
          i = Te();
        return i[r] === Bt ? Ws(i, r, n ? t.call(n) : t()) : Pl(i, r)
      }

      function __(e, t, n, r) {
        return M_(Te(), yi(), e, t, n, r)
      }

      function D_(e, t, n, r, i) {
        return function T_(e, t, n, r, i, s, o) {
          const l = t + n;
          return Qo(e, l, i, s) ? Ws(e, l + 2, o ? r.call(o, i, s) : r(i, s)) : Gl(e, l + 2)
        }(Te(), yi(), e, t, n, r, i)
      }

      function E_(e, t, n, r, i, s) {
        return function A_(e, t, n, r, i, s, o, l) {
          const h = t + n;
          return Yc(e, h, i, s, o) ? Ws(e, h + 3, l ? r.call(l, i, s, o) : r(i, s, o)) : Gl(e, h + 3)
        }(Te(), yi(), e, t, n, r, i, s)
      }

      function C_(e, t, n, r, i, s, o) {
        return function O_(e, t, n, r, i, s, o, l, h) {
          const E = t + n;
          return ns(e, E, i, s, o, l) ? Ws(e, E + 4, h ? r.call(h, i, s, o, l) : r(i, s, o, l)) : Gl(e, E + 4)
        }(Te(), yi(), e, t, n, r, i, s, o)
      }

      function b_(e, t, n, r, i, s, o, l) {
        const h = yi() + e,
          E = Te(),
          O = ns(E, h, n, r, i, s);
        return sr(E, h + 4, o) || O ? Ws(E, h + 5, l ? t.call(l, n, r, i, s, o) : t(n, r, i, s, o)) : Pl(E, h + 5)
      }

      function w_(e, t, n, r, i, s, o, l, h) {
        const E = yi() + e,
          O = Te(),
          L = ns(O, E, n, r, i, s);
        return Qo(O, E + 4, o, l) || L ? Ws(O, E + 6, h ? t.call(h, n, r, i, s, o, l) : t(n, r, i, s, o, l)) : Pl(
          O, E + 6)
      }

      function S_(e, t, n, r, i, s, o, l, h, E) {
        const O = yi() + e,
          L = Te();
        let Q = ns(L, O, n, r, i, s);
        return Yc(L, O + 4, o, l, h) || Q ? Ws(L, O + 7, E ? t.call(E, n, r, i, s, o, l, h) : t(n, r, i, s, o, l,
          h)) : Pl(L, O + 7)
      }

      function I_(e, t, n, r) {
        return function N_(e, t, n, r, i, s) {
          let o = t + n,
            l = !1;
          for (let h = 0; h < i.length; h++) sr(e, o++, i[h]) && (l = !0);
          return l ? Ws(e, o, r.apply(s, i)) : Gl(e, o)
        }(Te(), yi(), e, t, n, r)
      }

      function Gl(e, t) {
        const n = e[t];
        return n === Bt ? void 0 : n
      }

      function M_(e, t, n, r, i, s) {
        const o = t + n;
        return sr(e, o, i) ? Ws(e, o + 1, s ? r.call(s, i) : r(i)) : Gl(e, o + 1)
      }

      function R_(e, t) {
        const n = Yt();
        let r;
        const i = e + yt;
        n.firstCreatePass ? (r = function QM(e, t) {
            if (t)
              for (let n = t.length - 1; n >= 0; n--) {
                const r = t[n];
                if (e === r.name) return r
              }
          }(t, n.pipeRegistry), n.data[i] = r, r.onDestroy && (n.destroyHooks ??= []).push(i, r.onDestroy)) : r =
          n.data[i];
        const s = r.factory || (r.factory = Zr(r.type)),
          l = Vn(Da);
        try {
          const h = sc(!1),
            E = s();
          return sc(h),
            function AM(e, t, n, r) {
              n >= e.data.length && (e.data[n] = null, e.blueprint[n] = null), t[n] = r
            }(n, Te(), i, E), E
        } finally {
          Vn(l)
        }
      }

      function P_(e, t, n) {
        const r = e + yt,
          i = Te(),
          s = aa(i, r);
        return function zl(e, t) {
          return e[a].data[t].pure
        }(i, r) ? M_(i, yi(), t, s.transform, n, s) : s.transform(n)
      }

      function F_(e, t) {
        return Lc(e, t)
      }
      class X_ {
        constructor(t) {
          this.full = t;
          const n = t.split(".");
          this.major = n[0], this.minor = n[1], this.patch = n.slice(2).join(".")
        }
      }
      let Y_ = (() => {
        class e {
          log(n) {
            console.log(n)
          }
          warn(n) {
            console.warn(n)
          }
          static #e = this.\u0275fac = function(r) {
            return new(r || e)
          };
          static #t = this.\u0275prov = Gt({
            token: e,
            factory: e.\u0275fac,
            providedIn: "platform"
          })
        }
        return e
      })();
      const nD = new pe(""),
        rD = new pe("");
      let uh, zT = (() => {
          class e {
            constructor(n, r, i) {
              this._ngZone = n, this.registry = r, this._pendingCount = 0, this._isZoneStable = !0, this
                ._callbacks = [], this.taskTrackingZone = null, uh || (function KT(e) {
                  uh = e
                }(i), i.addToWindow(r)), this._watchAngularEvents(), n.run(() => {
                  this.taskTrackingZone = typeof Zone > "u" ? null : Zone.current.get("TaskTrackingZone")
                })
            }
            _watchAngularEvents() {
              this._ngZone.onUnstable.subscribe({
                next: () => {
                  this._isZoneStable = !1
                }
              }), this._ngZone.runOutsideAngular(() => {
                this._ngZone.onStable.subscribe({
                  next: () => {
                    mr.assertNotInAngularZone(), queueMicrotask(() => {
                      this._isZoneStable = !0, this._runCallbacksIfReady()
                    })
                  }
                })
              })
            }
            increasePendingRequestCount() {
              return this._pendingCount += 1, this._pendingCount
            }
            decreasePendingRequestCount() {
              if (this._pendingCount -= 1, this._pendingCount < 0) throw new Error(
                "pending async requests below zero");
              return this._runCallbacksIfReady(), this._pendingCount
            }
            isStable() {
              return this._isZoneStable && 0 === this._pendingCount && !this._ngZone.hasPendingMacrotasks
            }
            _runCallbacksIfReady() {
              if (this.isStable()) queueMicrotask(() => {
                for (; 0 !== this._callbacks.length;) {
                  let n = this._callbacks.pop();
                  clearTimeout(n.timeoutId), n.doneCb()
                }
              });
              else {
                let n = this.getPendingTasks();
                this._callbacks = this._callbacks.filter(r => !r.updateCb || !r.updateCb(n) || (clearTimeout(r
                  .timeoutId), !1))
              }
            }
            getPendingTasks() {
              return this.taskTrackingZone ? this.taskTrackingZone.macroTasks.map(n => ({
                source: n.source,
                creationLocation: n.creationLocation,
                data: n.data
              })) : []
            }
            addCallback(n, r, i) {
              let s = -1;
              r && r > 0 && (s = setTimeout(() => {
                this._callbacks = this._callbacks.filter(o => o.timeoutId !== s), n()
              }, r)), this._callbacks.push({
                doneCb: n,
                timeoutId: s,
                updateCb: i
              })
            }
            whenStable(n, r, i) {
              if (i && !this.taskTrackingZone) throw new Error(
                'Task tracking zone is required when passing an update callback to whenStable(). Is "zone.js/plugins/task-tracking" loaded?'
                );
              this.addCallback(n, r, i), this._runCallbacksIfReady()
            }
            getPendingRequestCount() {
              return this._pendingCount
            }
            registerApplication(n) {
              this.registry.registerApplication(n, this)
            }
            unregisterApplication(n) {
              this.registry.unregisterApplication(n)
            }
            findProviders(n, r, i) {
              return []
            }
            static #e = this.\u0275fac = function(r) {
              return new(r || e)(en(mr), en(iD), en(rD))
            };
            static #t = this.\u0275prov = Gt({
              token: e,
              factory: e.\u0275fac
            })
          }
          return e
        })(),
        iD = (() => {
          class e {
            constructor() {
              this._applications = new Map
            }
            registerApplication(n, r) {
              this._applications.set(n, r)
            }
            unregisterApplication(n) {
              this._applications.delete(n)
            }
            unregisterAllApplications() {
              this._applications.clear()
            }
            getTestability(n) {
              return this._applications.get(n) || null
            }
            getAllTestabilities() {
              return Array.from(this._applications.values())
            }
            getAllRootElements() {
              return Array.from(this._applications.keys())
            }
            findTestabilityInTree(n, r = !0) {
              return uh?.findTestabilityInTree(this, n, r) ?? null
            }
            static #e = this.\u0275fac = function(r) {
              return new(r || e)
            };
            static #t = this.\u0275prov = Gt({
              token: e,
              factory: e.\u0275fac,
              providedIn: "platform"
            })
          }
          return e
        })();

      function dh(e) {
        return !!e && "function" == typeof e.then
      }

      function sD(e) {
        return !!e && "function" == typeof e.subscribe
      }
      const oD = new pe("");
      let fh = (() => {
        class e {
          constructor() {
            this.initialized = !1, this.done = !1, this.donePromise = new Promise((n, r) => {
              this.resolve = n, this.reject = r
            }), this.appInits = pt(oD, {
              optional: !0
            }) ?? []
          }
          runInitializers() {
            if (this.initialized) return;
            const n = [];
            for (const i of this.appInits) {
              const s = i();
              if (dh(s)) n.push(s);
              else if (sD(s)) {
                const o = new Promise((l, h) => {
                  s.subscribe({
                    complete: l,
                    error: h
                  })
                });
                n.push(o)
              }
            }
            const r = () => {
              this.done = !0, this.resolve()
            };
            Promise.all(n).then(() => {
              r()
            }).catch(i => {
              this.reject(i)
            }), 0 === n.length && r(), this.initialized = !0
          }
          static #e = this.\u0275fac = function(r) {
            return new(r || e)
          };
          static #t = this.\u0275prov = Gt({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
          })
        }
        return e
      })();
      const hh = new pe("");

      function cD(e, t) {
        return Array.isArray(t) ? t.reduce(cD, e) : {
          ...e,
          ...t
        }
      }
      let bo = (() => {
        class e {
          constructor() {
            this._bootstrapListeners = [], this._runningTick = !1, this._destroyed = !1, this
              ._destroyListeners = [], this._views = [], this.internalErrorHandler = pt(yp), this
              .afterRenderEffectManager = pt(Tl), this.externalTestViews = new Set, this.beforeRender =
              new bt.B, this.afterTick = new bt.B, this.componentTypes = [], this.components = [], this
              .isStable = pt(Sa).hasPendingTasks.pipe((0, Un.T)(n => !n)), this._injector = pt(Wr)
          }
          get destroyed() {
            return this._destroyed
          }
          get injector() {
            return this._injector
          }
          bootstrap(n, r) {
            const i = n instanceof am;
            if (!this._injector.get(fh).done) throw !i && Ir(n), new Ke(405, !1);
            let o;
            o = i ? n : this._injector.get(Hc).resolveComponentFactory(n), this.componentTypes.push(o
              .componentType);
            const l = function qT(e) {
                return e.isBoundToModule
              }(o) ? void 0 : this._injector.get(qo),
              E = o.create(Hi.NULL, [], r || o.selector, l),
              O = E.location.nativeElement,
              L = E.injector.get(nD, null);
            return L?.registerApplication(O), E.onDestroy(() => {
              this.detachView(E.hostView), vu(this.components, E), L?.unregisterApplication(O)
            }), this._loadComponent(E), E
          }
          tick() {
            this._tick(!0)
          }
          _tick(n) {
            if (this._runningTick) throw new Ke(101, !1);
            const r = M(null);
            try {
              this._runningTick = !0, this.detectChangesInAttachedViews(n)
            } catch (i) {
              this.internalErrorHandler(i)
            } finally {
              this.afterTick.next(), this._runningTick = !1, M(r)
            }
          }
          detectChangesInAttachedViews(n) {
            let r = 0;
            const i = this.afterRenderEffectManager;
            for (;;) {
              if (r === Yg) throw new Ke(103, !1);
              if (n) {
                const s = 0 === r;
                this.beforeRender.next(s);
                for (let {
                    _lView: o,
                    notifyErrorHandler: l
                  }
                  of this._views) XT(o, s, l)
              }
              if (r++, i.executeInternalCallbacks(), ![...this.externalTestViews.keys(), ...this._views]
                .some(({
                  _lView: s
                }) => ph(s)) && (i.execute(), ![...this.externalTestViews.keys(), ...this._views].some(({
                  _lView: s
                }) => ph(s)))) break
            }
          }
          attachView(n) {
            const r = n;
            this._views.push(r), r.attachToAppRef(this)
          }
          detachView(n) {
            const r = n;
            vu(this._views, r), r.detachFromAppRef()
          }
          _loadComponent(n) {
            this.attachView(n.hostView), this.tick(), this.components.push(n);
            const r = this._injector.get(hh, []);
            [...this._bootstrapListeners, ...r].forEach(i => i(n))
          }
          ngOnDestroy() {
            if (!this._destroyed) try {
              this._destroyListeners.forEach(n => n()), this._views.slice().forEach(n => n.destroy())
            } finally {
              this._destroyed = !0, this._views = [], this._bootstrapListeners = [], this
                ._destroyListeners = []
            }
          }
          onDestroy(n) {
            return this._destroyListeners.push(n), () => vu(this._destroyListeners, n)
          }
          destroy() {
            if (this._destroyed) throw new Ke(406, !1);
            const n = this._injector;
            n.destroy && !n.destroyed && n.destroy()
          }
          get viewCount() {
            return this._views.length
          }
          warnIfDestroyed() {}
          static #e = this.\u0275fac = function(r) {
            return new(r || e)
          };
          static #t = this.\u0275prov = Gt({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
          })
        }
        return e
      })();

      function vu(e, t) {
        const n = e.indexOf(t);
        n > -1 && e.splice(n, 1)
      }

      function XT(e, t, n) {
        !t && !ph(e) || function YT(e, t, n) {
          let r;
          n ? (r = 0, e[m] |= 1024) : r = 64 & e[m] ? 0 : 1, xc(e, t, r)
        }(e, n, t)
      }

      function ph(e) {
        return Ru(e)
      }
      class ZT {
        constructor(t, n) {
          this.ngModuleFactory = t, this.componentFactories = n
        }
      }
      let JT = (() => {
          class e {
            compileModuleSync(n) {
              return new yf(n)
            }
            compileModuleAsync(n) {
              return Promise.resolve(this.compileModuleSync(n))
            }
            compileModuleAndAllComponentsSync(n) {
              const r = this.compileModuleSync(n),
                s = $i(rr(n).declarations).reduce((o, l) => {
                  const h = Vt(l);
                  return h && o.push(new Nl(h)), o
                }, []);
              return new ZT(r, s)
            }
            compileModuleAndAllComponentsAsync(n) {
              return Promise.resolve(this.compileModuleAndAllComponentsSync(n))
            }
            clearCache() {}
            clearCacheFor(n) {}
            getModuleId(n) {}
            static #e = this.\u0275fac = function(r) {
              return new(r || e)
            };
            static #t = this.\u0275prov = Gt({
              token: e,
              factory: e.\u0275fac,
              providedIn: "root"
            })
          }
          return e
        })(),
        nA = (() => {
          class e {
            constructor() {
              this.zone = pt(mr), this.applicationRef = pt(bo)
            }
            initialize() {
              this._onMicrotaskEmptySubscription || (this._onMicrotaskEmptySubscription = this.zone
                .onMicrotaskEmpty.subscribe({
                  next: () => {
                    this.zone.run(() => {
                      this.applicationRef.tick()
                    })
                  }
                }))
            }
            ngOnDestroy() {
              this._onMicrotaskEmptySubscription?.unsubscribe()
            }
            static #e = this.\u0275fac = function(r) {
              return new(r || e)
            };
            static #t = this.\u0275prov = Gt({
              token: e,
              factory: e.\u0275fac,
              providedIn: "root"
            })
          }
          return e
        })();

      function rA() {
        const e = pt(mr),
          t = pt(so);
        return n => e.runOutsideAngular(() => t.handleError(n))
      }
      let sA = (() => {
        class e {
          constructor() {
            this.subscription = new Ct.yU, this.initialized = !1, this.zone = pt(mr), this.pendingTasks =
              pt(Sa)
          }
          initialize() {
            if (this.initialized) return;
            this.initialized = !0;
            let n = null;
            !this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (
              n = this.pendingTasks.add()), this.zone.runOutsideAngular(() => {
              this.subscription.add(this.zone.onStable.subscribe(() => {
                mr.assertNotInAngularZone(), queueMicrotask(() => {
                  null !== n && !this.zone.hasPendingMacrotasks && !this.zone
                    .hasPendingMicrotasks && (this.pendingTasks.remove(n), n = null)
                })
              }))
            }), this.subscription.add(this.zone.onUnstable.subscribe(() => {
              mr.assertInAngularZone(), n ??= this.pendingTasks.add()
            }))
          }
          ngOnDestroy() {
            this.subscription.unsubscribe()
          }
          static #e = this.\u0275fac = function(r) {
            return new(r || e)
          };
          static #t = this.\u0275prov = Gt({
            token: e,
            factory: e.\u0275fac,
            providedIn: "root"
          })
        }
        return e
      })();
      const Du = new pe("", {
          providedIn: "root",
          factory: () => pt(Du, At.Optional | At.SkipSelf) || function oA() {
            return typeof $localize < "u" && $localize.locale || Ga
          }()
        }),
        aA = new pe("", {
          providedIn: "root",
          factory: () => "USD"
        }),
        gh = new pe("");
      let hD = (() => {
          class e {
            constructor(n) {
              this._injector = n, this._modules = [], this._destroyListeners = [], this._destroyed = !1
            }
            bootstrapModuleFactory(n, r) {
              const i = function Zw(e = "zone.js", t) {
                return "noop" === e ? new pm : "zone.js" === e ? new mr(t) : e
              }(r?.ngZone, function fD(e) {
                return {
                  enableLongStackTrace: !1,
                  shouldCoalesceEventChangeDetection: e?.eventCoalescing ?? !1,
                  shouldCoalesceRunChangeDetection: e?.runCoalescing ?? !1
                }
              }({
                eventCoalescing: r?.ngZoneEventCoalescing,
                runCoalescing: r?.ngZoneRunCoalescing
              }));
              return i.run(() => {
                const s = function W0(e, t, n) {
                    return new mf(e, t, n)
                  }(n.moduleType, this.injector, function dD(e) {
                    return [{
                      provide: mr,
                      useFactory: e
                    }, {
                      provide: hi,
                      multi: !0,
                      useFactory: () => {
                        const t = pt(nA, {
                          optional: !0
                        });
                        return () => t.initialize()
                      }
                    }, {
                      provide: hi,
                      multi: !0,
                      useFactory: () => {
                        const t = pt(sA);
                        return () => {
                          t.initialize()
                        }
                      }
                    }, {
                      provide: yp,
                      useFactory: rA
                    }]
                  }(() => i)),
                  o = s.injector.get(so, null);
                return i.runOutsideAngular(() => {
                    const l = i.onError.subscribe({
                      next: h => {
                        o.handleError(h)
                      }
                    });
                    s.onDestroy(() => {
                      vu(this._modules, s), l.unsubscribe()
                    })
                  }),
                  function lD(e, t, n) {
                    try {
                      const r = n();
                      return dh(r) ? r.catch(i => {
                        throw t.runOutsideAngular(() => e.handleError(i)), i
                      }) : r
                    } catch (r) {
                      throw t.runOutsideAngular(() => e.handleError(r)), r
                    }
                  }(o, i, () => {
                    const l = s.injector.get(fh);
                    return l.runInitializers(), l.donePromise.then(() => (function ov(e) {
                      "string" == typeof e && (sv = e.toLowerCase().replace(/_/g, "-"))
                    }(s.injector.get(Du, Ga) || Ga), this._moduleDoBootstrap(s), s))
                  })
              })
            }
            bootstrapModule(n, r = []) {
              const i = cD({}, r);
              return function tA(e, t, n) {
                const r = new yf(n);
                return Promise.resolve(r)
              }(0, 0, n).then(s => this.bootstrapModuleFactory(s, i))
            }
            _moduleDoBootstrap(n) {
              const r = n.injector.get(bo);
              if (n._bootstrapComponents.length > 0) n._bootstrapComponents.forEach(i => r.bootstrap(i));
              else {
                if (!n.instance.ngDoBootstrap) throw new Ke(-403, !1);
                n.instance.ngDoBootstrap(r)
              }
              this._modules.push(n)
            }
            onDestroy(n) {
              this._destroyListeners.push(n)
            }
            get injector() {
              return this._injector
            }
            destroy() {
              if (this._destroyed) throw new Ke(404, !1);
              this._modules.slice().forEach(r => r.destroy()), this._destroyListeners.forEach(r => r());
              const n = this._injector.get(gh, null);
              n && (n.forEach(r => r()), n.clear()), this._destroyed = !0
            }
            get destroyed() {
              return this._destroyed
            }
            static #e = this.\u0275fac = function(r) {
              return new(r || e)(en(Hi))
            };
            static #t = this.\u0275prov = Gt({
              token: e,
              factory: e.\u0275fac,
              providedIn: "platform"
            })
          }
          return e
        })(),
        wo = null;
      const pD = new pe("");

      function gD(e, t, n = []) {
        const r = `Platform: ${t}`,
          i = new pe(r);
        return (s = []) => {
          let o = mh();
          if (!o || o.injector.get(pD, !1)) {
            const l = [...n, ...s, {
              provide: i,
              useValue: !0
            }];
            e ? e(l) : function cA(e) {
              if (wo && !wo.get(pD, !1)) throw new Ke(400, !1);
              (function aD() {
                ! function Yn(e) {
                  Ht = e
                }(() => {
                  throw new Ke(600, !1)
                })
              })(), wo = e;
              const t = e.get(hD);
              (function yD(e) {
                e.get(Up, null)?.forEach(n => n())
              })(e)
            }(function mD(e = [], t) {
              return Hi.create({
                name: t,
                providers: [{
                  provide: eo,
                  useValue: "platform"
                }, {
                  provide: gh,
                  useValue: new Set([() => wo = null])
                }, ...e]
              })
            }(l, r))
          }
          return function uA(e) {
            const t = mh();
            if (!t) throw new Ke(401, !1);
            return t
          }()
        }
      }

      function mh() {
        return wo?.get(hD) ?? null
      }

      function fA() {}
      let _D = (() => {
        class e {
          static #e = this.__NG_ELEMENT_ID__ = hA
        }
        return e
      })();

      function hA(e) {
        return function pA(e, t, n) {
          if (En(e) && !n) {
            const r = ji(e.index, t);
            return new Cl(r, r)
          }
          return 47 & e.type ? new Cl(t[ft], t) : null
        }(Cn(), Te(), !(16 & ~e))
      }
      class bD {
        constructor() {}
        supports(t) {
          return Xc(t)
        }
        create(t) {
          return new _A(t)
        }
      }
      const vA = (e, t) => t;
      class _A {
        constructor(t) {
          this.length = 0, this._linkedRecords = null, this._unlinkedRecords = null, this._previousItHead =
            null, this._itHead = null, this._itTail = null, this._additionsHead = null, this._additionsTail =
            null, this._movesHead = null, this._movesTail = null, this._removalsHead = null, this
            ._removalsTail = null, this._identityChangesHead = null, this._identityChangesTail = null, this
            ._trackByFn = t || vA
        }
        forEachItem(t) {
          let n;
          for (n = this._itHead; null !== n; n = n._next) t(n)
        }
        forEachOperation(t) {
          let n = this._itHead,
            r = this._removalsHead,
            i = 0,
            s = null;
          for (; n || r;) {
            const o = !r || n && n.currentIndex < SD(r, i, s) ? n : r,
              l = SD(o, i, s),
              h = o.currentIndex;
            if (o === r) i--, r = r._nextRemoved;
            else if (n = n._next, null == o.previousIndex) i++;
            else {
              s || (s = []);
              const E = l - i,
                O = h - i;
              if (E != O) {
                for (let Q = 0; Q < E; Q++) {
                  const ne = Q < s.length ? s[Q] : s[Q] = 0,
                    ce = ne + Q;
                  O <= ce && ce < E && (s[Q] = ne + 1)
                }
                s[o.previousIndex] = O - E
              }
            }
            l !== h && t(o, l, h)
          }
        }
        forEachPreviousItem(t) {
          let n;
          for (n = this._previousItHead; null !== n; n = n._nextPrevious) t(n)
        }
        forEachAddedItem(t) {
          let n;
          for (n = this._additionsHead; null !== n; n = n._nextAdded) t(n)
        }
        forEachMovedItem(t) {
          let n;
          for (n = this._movesHead; null !== n; n = n._nextMoved) t(n)
        }
        forEachRemovedItem(t) {
          let n;
          for (n = this._removalsHead; null !== n; n = n._nextRemoved) t(n)
        }
        forEachIdentityChange(t) {
          let n;
          for (n = this._identityChangesHead; null !== n; n = n._nextIdentityChange) t(n)
        }
        diff(t) {
          if (null == t && (t = []), !Xc(t)) throw new Ke(900, !1);
          return this.check(t) ? this : null
        }
        onDestroy() {}
        check(t) {
          this._reset();
          let i, s, o, n = this._itHead,
            r = !1;
          if (Array.isArray(t)) {
            this.length = t.length;
            for (let l = 0; l < this.length; l++) s = t[l], o = this._trackByFn(l, s), null !== n && Object.is(n
              .trackById, o) ? (r && (n = this._verifyReinsertion(n, s, o, l)), Object.is(n.item, s) || this
              ._addIdentityChange(n, s)) : (n = this._mismatch(n, s, o, l), r = !0), n = n._next
          } else i = 0,
            function q0(e, t) {
              if (Array.isArray(e))
                for (let n = 0; n < e.length; n++) t(e[n]);
              else {
                const n = e[Symbol.iterator]();
                let r;
                for (; !(r = n.next()).done;) t(r.value)
              }
            }(t, l => {
              o = this._trackByFn(i, l), null !== n && Object.is(n.trackById, o) ? (r && (n = this
                ._verifyReinsertion(n, l, o, i)), Object.is(n.item, l) || this._addIdentityChange(n, l)) : (
                n = this._mismatch(n, l, o, i), r = !0), n = n._next, i++
            }), this.length = i;
          return this._truncate(n), this.collection = t, this.isDirty
        }
        get isDirty() {
          return null !== this._additionsHead || null !== this._movesHead || null !== this._removalsHead ||
            null !== this._identityChangesHead
        }
        _reset() {
          if (this.isDirty) {
            let t;
            for (t = this._previousItHead = this._itHead; null !== t; t = t._next) t._nextPrevious = t._next;
            for (t = this._additionsHead; null !== t; t = t._nextAdded) t.previousIndex = t.currentIndex;
            for (this._additionsHead = this._additionsTail = null, t = this._movesHead; null !== t; t = t
              ._nextMoved) t.previousIndex = t.currentIndex;
            this._movesHead = this._movesTail = null, this._removalsHead = this._removalsTail = null, this
              ._identityChangesHead = this._identityChangesTail = null
          }
        }
        _mismatch(t, n, r, i) {
          let s;
          return null === t ? s = this._itTail : (s = t._prev, this._remove(t)), null !== (t = null === this
            ._unlinkedRecords ? null : this._unlinkedRecords.get(r, null)) ? (Object.is(t.item, n) || this
            ._addIdentityChange(t, n), this._reinsertAfter(t, s, i)) : null !== (t = null === this
            ._linkedRecords ? null : this._linkedRecords.get(r, i)) ? (Object.is(t.item, n) || this
            ._addIdentityChange(t, n), this._moveAfter(t, s, i)) : t = this._addAfter(new DA(n, r), s, i), t
        }
        _verifyReinsertion(t, n, r, i) {
          let s = null === this._unlinkedRecords ? null : this._unlinkedRecords.get(r, null);
          return null !== s ? t = this._reinsertAfter(s, t._prev, i) : t.currentIndex != i && (t.currentIndex =
            i, this._addToMoves(t, i)), t
        }
        _truncate(t) {
          for (; null !== t;) {
            const n = t._next;
            this._addToRemovals(this._unlink(t)), t = n
          }
          null !== this._unlinkedRecords && this._unlinkedRecords.clear(), null !== this._additionsTail && (this
            ._additionsTail._nextAdded = null), null !== this._movesTail && (this._movesTail._nextMoved =
            null), null !== this._itTail && (this._itTail._next = null), null !== this._removalsTail && (this
            ._removalsTail._nextRemoved = null), null !== this._identityChangesTail && (this
            ._identityChangesTail._nextIdentityChange = null)
        }
        _reinsertAfter(t, n, r) {
          null !== this._unlinkedRecords && this._unlinkedRecords.remove(t);
          const i = t._prevRemoved,
            s = t._nextRemoved;
          return null === i ? this._removalsHead = s : i._nextRemoved = s, null === s ? this._removalsTail = i :
            s._prevRemoved = i, this._insertAfter(t, n, r), this._addToMoves(t, r), t
        }
        _moveAfter(t, n, r) {
          return this._unlink(t), this._insertAfter(t, n, r), this._addToMoves(t, r), t
        }
        _addAfter(t, n, r) {
          return this._insertAfter(t, n, r), this._additionsTail = null === this._additionsTail ? this
            ._additionsHead = t : this._additionsTail._nextAdded = t, t
        }
        _insertAfter(t, n, r) {
          const i = null === n ? this._itHead : n._next;
          return t._next = i, t._prev = n, null === i ? this._itTail = t : i._prev = t, null === n ? this
            ._itHead = t : n._next = t, null === this._linkedRecords && (this._linkedRecords = new wD), this
            ._linkedRecords.put(t), t.currentIndex = r, t
        }
        _remove(t) {
          return this._addToRemovals(this._unlink(t))
        }
        _unlink(t) {
          null !== this._linkedRecords && this._linkedRecords.remove(t);
          const n = t._prev,
            r = t._next;
          return null === n ? this._itHead = r : n._next = r, null === r ? this._itTail = n : r._prev = n, t
        }
        _addToMoves(t, n) {
          return t.previousIndex === n || (this._movesTail = null === this._movesTail ? this._movesHead = t :
            this._movesTail._nextMoved = t), t
        }
        _addToRemovals(t) {
          return null === this._unlinkedRecords && (this._unlinkedRecords = new wD), this._unlinkedRecords.put(
            t), t.currentIndex = null, t._nextRemoved = null, null === this._removalsTail ? (this
            ._removalsTail = this._removalsHead = t, t._prevRemoved = null) : (t._prevRemoved = this
            ._removalsTail, this._removalsTail = this._removalsTail._nextRemoved = t), t
        }
        _addIdentityChange(t, n) {
          return t.item = n, this._identityChangesTail = null === this._identityChangesTail ? this
            ._identityChangesHead = t : this._identityChangesTail._nextIdentityChange = t, t
        }
      }
      class DA {
        constructor(t, n) {
          this.item = t, this.trackById = n, this.currentIndex = null, this.previousIndex = null, this
            ._nextPrevious = null, this._prev = null, this._next = null, this._prevDup = null, this._nextDup =
            null, this._prevRemoved = null, this._nextRemoved = null, this._nextAdded = null, this._nextMoved =
            null, this._nextIdentityChange = null
        }
      }
      class EA {
        constructor() {
          this._head = null, this._tail = null
        }
        add(t) {
          null === this._head ? (this._head = this._tail = t, t._nextDup = null, t._prevDup = null) : (this
            ._tail._nextDup = t, t._prevDup = this._tail, t._nextDup = null, this._tail = t)
        }
        get(t, n) {
          let r;
          for (r = this._head; null !== r; r = r._nextDup)
            if ((null === n || n <= r.currentIndex) && Object.is(r.trackById, t)) return r;
          return null
        }
        remove(t) {
          const n = t._prevDup,
            r = t._nextDup;
          return null === n ? this._head = r : n._nextDup = r, null === r ? this._tail = n : r._prevDup = n,
            null === this._head
        }
      }
      class wD {
        constructor() {
          this.map = new Map
        }
        put(t) {
          const n = t.trackById;
          let r = this.map.get(n);
          r || (r = new EA, this.map.set(n, r)), r.add(t)
        }
        get(t, n) {
          const i = this.map.get(t);
          return i ? i.get(t, n) : null
        }
        remove(t) {
          const n = t.trackById;
          return this.map.get(n).remove(t) && this.map.delete(n), t
        }
        get isEmpty() {
          return 0 === this.map.size
        }
        clear() {
          this.map.clear()
        }
      }

      function SD(e, t, n) {
        const r = e.previousIndex;
        if (null === r) return r;
        let i = 0;
        return n && r < n.length && (i = n[r]), r + t + i
      }
      class ID {
        constructor() {}
        supports(t) {
          return t instanceof Map || _f(t)
        }
        create() {
          return new CA
        }
      }
      class CA {
        constructor() {
          this._records = new Map, this._mapHead = null, this._appendAfter = null, this._previousMapHead = null,
            this._changesHead = null, this._changesTail = null, this._additionsHead = null, this
            ._additionsTail = null, this._removalsHead = null, this._removalsTail = null
        }
        get isDirty() {
          return null !== this._additionsHead || null !== this._changesHead || null !== this._removalsHead
        }
        forEachItem(t) {
          let n;
          for (n = this._mapHead; null !== n; n = n._next) t(n)
        }
        forEachPreviousItem(t) {
          let n;
          for (n = this._previousMapHead; null !== n; n = n._nextPrevious) t(n)
        }
        forEachChangedItem(t) {
          let n;
          for (n = this._changesHead; null !== n; n = n._nextChanged) t(n)
        }
        forEachAddedItem(t) {
          let n;
          for (n = this._additionsHead; null !== n; n = n._nextAdded) t(n)
        }
        forEachRemovedItem(t) {
          let n;
          for (n = this._removalsHead; null !== n; n = n._nextRemoved) t(n)
        }
        diff(t) {
          if (t) {
            if (!(t instanceof Map || _f(t))) throw new Ke(900, !1)
          } else t = new Map;
          return this.check(t) ? this : null
        }
        onDestroy() {}
        check(t) {
          this._reset();
          let n = this._mapHead;
          if (this._appendAfter = null, this._forEach(t, (r, i) => {
              if (n && n.key === i) this._maybeAddToChanges(n, r), this._appendAfter = n, n = n._next;
              else {
                const s = this._getOrCreateRecordForKey(i, r);
                n = this._insertBeforeOrAppend(n, s)
              }
            }), n) {
            n._prev && (n._prev._next = null), this._removalsHead = n;
            for (let r = n; null !== r; r = r._nextRemoved) r === this._mapHead && (this._mapHead = null), this
              ._records.delete(r.key), r._nextRemoved = r._next, r.previousValue = r.currentValue, r
              .currentValue = null, r._prev = null, r._next = null
          }
          return this._changesTail && (this._changesTail._nextChanged = null), this._additionsTail && (this
            ._additionsTail._nextAdded = null), this.isDirty
        }
        _insertBeforeOrAppend(t, n) {
          if (t) {
            const r = t._prev;
            return n._next = t, n._prev = r, t._prev = n, r && (r._next = n), t === this._mapHead && (this
              ._mapHead = n), this._appendAfter = t, t
          }
          return this._appendAfter ? (this._appendAfter._next = n, n._prev = this._appendAfter) : this
            ._mapHead = n, this._appendAfter = n, null
        }
        _getOrCreateRecordForKey(t, n) {
          if (this._records.has(t)) {
            const i = this._records.get(t);
            this._maybeAddToChanges(i, n);
            const s = i._prev,
              o = i._next;
            return s && (s._next = o), o && (o._prev = s), i._next = null, i._prev = null, i
          }
          const r = new bA(t);
          return this._records.set(t, r), r.currentValue = n, this._addToAdditions(r), r
        }
        _reset() {
          if (this.isDirty) {
            let t;
            for (this._previousMapHead = this._mapHead, t = this._previousMapHead; null !== t; t = t._next) t
              ._nextPrevious = t._next;
            for (t = this._changesHead; null !== t; t = t._nextChanged) t.previousValue = t.currentValue;
            for (t = this._additionsHead; null != t; t = t._nextAdded) t.previousValue = t.currentValue;
            this._changesHead = this._changesTail = null, this._additionsHead = this._additionsTail = null, this
              ._removalsHead = null
          }
        }
        _maybeAddToChanges(t, n) {
          Object.is(n, t.currentValue) || (t.previousValue = t.currentValue, t.currentValue = n, this
            ._addToChanges(t))
        }
        _addToAdditions(t) {
          null === this._additionsHead ? this._additionsHead = this._additionsTail = t : (this._additionsTail
            ._nextAdded = t, this._additionsTail = t)
        }
        _addToChanges(t) {
          null === this._changesHead ? this._changesHead = this._changesTail = t : (this._changesTail
            ._nextChanged = t, this._changesTail = t)
        }
        _forEach(t, n) {
          t instanceof Map ? t.forEach(n) : Object.keys(t).forEach(r => n(t[r], r))
        }
      }
      class bA {
        constructor(t) {
          this.key = t, this.previousValue = null, this.currentValue = null, this._nextPrevious = null, this
            ._next = null, this._prev = null, this._nextAdded = null, this._nextRemoved = null, this
            ._nextChanged = null
        }
      }

      function MD() {
        return new Eh([new bD])
      }
      let Eh = (() => {
        class e {
          static #e = this.\u0275prov = Gt({
            token: e,
            providedIn: "root",
            factory: MD
          });
          constructor(n) {
            this.factories = n
          }
          static create(n, r) {
            if (null != r) {
              const i = r.factories.slice();
              n = n.concat(i)
            }
            return new e(n)
          }
          static extend(n) {
            return {
              provide: e,
              useFactory: r => e.create(n, r || MD()),
              deps: [
                [e, new ui, new er]
              ]
            }
          }
          find(n) {
            const r = this.factories.find(i => i.supports(n));
            if (null != r) return r;
            throw new Ke(901, !1)
          }
        }
        return e
      })();

      function TD() {
        return new Ch([new ID])
      }
      let Ch = (() => {
        class e {
          static #e = this.\u0275prov = Gt({
            token: e,
            providedIn: "root",
            factory: TD
          });
          constructor(n) {
            this.factories = n
          }
          static create(n, r) {
            if (r) {
              const i = r.factories.slice();
              n = n.concat(i)
            }
            return new e(n)
          }
          static extend(n) {
            return {
              provide: e,
              useFactory: r => e.create(n, r || TD()),
              deps: [
                [e, new ui, new er]
              ]
            }
          }
          find(n) {
            const r = this.factories.find(i => i.supports(n));
            if (r) return r;
            throw new Ke(901, !1)
          }
        }
        return e
      })();
      const IA = gD(null, "core", []);
      let MA = (() => {
        class e {
          constructor(n) {}
          static #e = this.\u0275fac = function(r) {
            return new(r || e)(en(bo))
          };
          static #t = this.\u0275mod = Xs({
            type: e
          });
          static #n = this.\u0275inj = si({})
        }
        return e
      })();

      function nO(e) {
        return "boolean" == typeof e ? e : null != e && "false" !== e
      }

      function rO(e, t = NaN) {
        return isNaN(parseFloat(e)) || isNaN(Number(e)) ? t : Number(e)
      }

      function sO(e, t) {
        $s("NgSignals");
        const n = function De(e) {
          const t = Object.create(et);
          t.computation = e;
          const n = () => {
            if (me(t), le(t), t.value === be) throw t.error;
            return t.value
          };
          return n[k] = t, n
        }(e);
        return t?.equal && (n[k].equal = t.equal), n
      }

      function oO(e) {
        const t = M(null);
        try {
          return e()
        } finally {
          M(t)
        }
      }
      const aO = new pe("", {
        providedIn: "root",
        factory: () => pt(lO)
      });
      let lO = (() => {
        class e {
          static #e = this.\u0275prov = Gt({
            token: e,
            providedIn: "root",
            factory: () => new cO
          })
        }
        return e
      })();
      class cO {
        constructor() {
          this.queuedEffectCount = 0, this.queues = new Map, this.pendingTasks = pt(Sa), this.taskId = null
        }
        scheduleEffect(t) {
          if (this.enqueue(t), null === this.taskId) {
            const n = this.taskId = this.pendingTasks.add();
            queueMicrotask(() => {
              this.flush(), this.pendingTasks.remove(n), this.taskId = null
            })
          }
        }
        enqueue(t) {
          const n = t.creationZone;
          this.queues.has(n) || this.queues.set(n, new Set);
          const r = this.queues.get(n);
          r.has(t) || (this.queuedEffectCount++, r.add(t))
        }
        flush() {
          for (; this.queuedEffectCount > 0;)
            for (const [t, n] of this.queues) null === t ? this.flushQueue(n) : t.run(() => this.flushQueue(n))
        }
        flushQueue(t) {
          for (const n of t) t.delete(n), this.queuedEffectCount--, n.run()
        }
      }
      class uO {
        constructor(t, n, r, i, s, o) {
          this.scheduler = t, this.effectFn = n, this.creationZone = r, this.injector = s, this.watcher =
            function ln(e, t, n) {
              const r = Object.create(Ut);
              n && (r.consumerAllowSignalWrites = !0), r.fn = e, r.schedule = t;
              const i = h => {
                r.cleanupFn = h
              };
              return r.ref = {
                notify: () => we(r),
                run: () => {
                  if (null === r.fn) return;
                  if (function $() {
                      return ae
                    }()) throw new Error(
                    "Schedulers cannot synchronously execute watches while scheduling.");
                  if (r.dirty = !1, r.hasRun && !vt(r)) return;
                  r.hasRun = !0;
                  const h = Ve(r);
                  try {
                    r.cleanupFn(), r.cleanupFn = ht, r.fn(i)
                  } finally {
                    Ze(r, h)
                  }
                },
                cleanup: () => r.cleanupFn(),
                destroy: () => function o(h) {
                  (function s(h) {
                    return null === h.fn && null === h.schedule
                  })(h) || (ue(h), h.cleanupFn(), h.fn = null, h.schedule = null, h.cleanupFn = ht)
                }(r),
                [k]: r
              }, r.ref
            }(l => this.runEffect(l), () => this.schedule(), o), this.unregisterOnDestroy = i?.onDestroy(() =>
              this.destroy())
        }
        runEffect(t) {
          try {
            this.effectFn(t)
          } catch (n) {
            this.injector.get(so, null, {
              optional: !0
            })?.handleError(n)
          }
        }
        run() {
          this.watcher.run()
        }
        schedule() {
          this.scheduler.scheduleEffect(this)
        }
        destroy() {
          this.watcher.destroy(), this.unregisterOnDestroy?.()
        }
      }

      function XD(e, t) {
        $s("NgSignals"), !t?.injector && no();
        const n = t?.injector ?? pt(Hi),
          r = !0 !== t?.manualCleanup ? n.get(fa) : null,
          i = new uO(n.get(aO), e, typeof Zone > "u" ? null : Zone.current, r, n, t?.allowSignalWrites ?? !1),
          s = n.get(_D, null, {
            optional: !0
          });
        return s && 8 & s._lView[m] ? (s._lView[ir] ??= []).push(i.watcher.notify) : i.watcher.notify(), i
      }

      function dO(e) {
        const t = Vt(e);
        if (!t) return null;
        const n = new Nl(t);
        return {
          get selector() {
            return n.selector
          },
          get type() {
            return n.componentType
          },
          get inputs() {
            return n.inputs
          },
          get outputs() {
            return n.outputs
          },
          get ngContentSelectors() {
            return n.ngContentSelectors
          },
          get isStandalone() {
            return t.standalone
          },
          get isSignal() {
            return t.signals
          }
        }
      }
    },
    9417: (nt, Se, x) => {
      x.d(Se, {
        BC: () => Nn,
        JD: () => Cr,
        MJ: () => sn,
        X1: () => Vi,
        YN: () => Sr,
        YS: () => br,
        cV: () => Qt,
        cb: () => Ke,
        cz: () => we,
        gE: () => Qe,
        j4: () => Ur,
        k0: () => vt,
        kq: () => V,
        me: () => me,
        qT: () => Fr,
        vO: () => Ct,
        vS: () => Ye
      });
      var g = x(4438),
        c = x(177),
        ee = x(6648),
        ae = x(7468),
        A = x(6354);
      let k = (() => {
          class I {
            constructor(_, F) {
              this._renderer = _, this._elementRef = F, this.onChange = Y => {}, this.onTouched = () => {}
            }
            setProperty(_, F) {
              this._renderer.setProperty(this._elementRef.nativeElement, _, F)
            }
            registerOnTouched(_) {
              this.onTouched = _
            }
            registerOnChange(_) {
              this.onChange = _
            }
            setDisabledState(_) {
              this.setProperty("disabled", _)
            }
            static #e = this.\u0275fac = function(F) {
              return new(F || I)(g.rXU(g.sFG), g.rXU(g.aKT))
            };
            static #t = this.\u0275dir = g.FsC({
              type: I
            })
          }
          return I
        })(),
        M = (() => {
          class I extends k {
            static #e = this.\u0275fac = (() => {
              let _;
              return function(Y) {
                return (_ || (_ = g.xGo(I)))(Y || I)
              }
            })();
            static #t = this.\u0275dir = g.FsC({
              type: I,
              features: [g.Vt3]
            })
          }
          return I
        })();
      const V = new g.nKC(""),
        U = {
          provide: V,
          useExisting: (0, g.Rfq)(() => me),
          multi: !0
        },
        Ne = new g.nKC("");
      let me = (() => {
        class I extends k {
          constructor(_, F, Y) {
            super(_, F), this._compositionMode = Y, this._composing = !1, null == this._compositionMode && (
              this._compositionMode = ! function le() {
                const I = (0, c.QT)() ? (0, c.QT)().getUserAgent() : "";
                return /android (\d+)/.test(I.toLowerCase())
              }())
          }
          writeValue(_) {
            this.setProperty("value", _ ?? "")
          }
          _handleInput(_) {
            (!this._compositionMode || this._compositionMode && !this._composing) && this.onChange(_)
          }
          _compositionStart() {
            this._composing = !0
          }
          _compositionEnd(_) {
            this._composing = !1, this._compositionMode && this.onChange(_)
          }
          static #e = this.\u0275fac = function(F) {
            return new(F || I)(g.rXU(g.sFG), g.rXU(g.aKT), g.rXU(Ne, 8))
          };
          static #t = this.\u0275dir = g.FsC({
            type: I,
            selectors: [
              ["input", "formControlName", "", 3, "type", "checkbox"],
              ["textarea", "formControlName", ""],
              ["input", "formControl", "", 3, "type", "checkbox"],
              ["textarea", "formControl", ""],
              ["input", "ngModel", "", 3, "type", "checkbox"],
              ["textarea", "ngModel", ""],
              ["", "ngDefaultControl", ""]
            ],
            hostBindings: function(F, Y) {
              1 & F && g.bIt("input", function(Rt) {
                return Y._handleInput(Rt.target.value)
              })("blur", function() {
                return Y.onTouched()
              })("compositionstart", function() {
                return Y._compositionStart()
              })("compositionend", function(Rt) {
                return Y._compositionEnd(Rt.target.value)
              })
            },
            features: [g.Jv_([U]), g.Vt3]
          })
        }
        return I
      })();

      function Ae(I) {
        return null == I || ("string" == typeof I || Array.isArray(I)) && 0 === I.length
      }

      function qe(I) {
        return null != I && "number" == typeof I.length
      }
      const we = new g.nKC(""),
        Ve = new g.nKC(""),
        Ze =
        /^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
      class vt {
        static min(T) {
          return function ue(I) {
            return T => {
              if (Ae(T.value) || Ae(I)) return null;
              const _ = parseFloat(T.value);
              return !isNaN(_) && _ < I ? {
                min: {
                  min: I,
                  actual: T.value
                }
              } : null
            }
          }(T)
        }
        static max(T) {
          return function Pe(I) {
            return T => {
              if (Ae(T.value) || Ae(I)) return null;
              const _ = parseFloat(T.value);
              return !isNaN(_) && _ > I ? {
                max: {
                  max: I,
                  actual: T.value
                }
              } : null
            }
          }(T)
        }
        static required(T) {
          return ie(T)
        }
        static requiredTrue(T) {
          return function se(I) {
            return !0 === I.value ? null : {
              required: !0
            }
          }(T)
        }
        static email(T) {
          return function Re(I) {
            return Ae(I.value) || Ze.test(I.value) ? null : {
              email: !0
            }
          }(T)
        }
        static minLength(T) {
          return function Be(I) {
            return T => Ae(T.value) || !qe(T.value) ? null : T.value.length < I ? {
              minlength: {
                requiredLength: I,
                actualLength: T.value.length
              }
            } : null
          }(T)
        }
        static maxLength(T) {
          return function De(I) {
            return T => qe(T.value) && T.value.length > I ? {
              maxlength: {
                requiredLength: I,
                actualLength: T.value.length
              }
            } : null
          }(T)
        }
        static pattern(T) {
          return function Z(I) {
            if (!I) return xe;
            let T, _;
            return "string" == typeof I ? (_ = "", "^" !== I.charAt(0) && (_ += "^"), _ += I, "$" !== I
              .charAt(I.length - 1) && (_ += "$"), T = new RegExp(_)) : (_ = I.toString(), T = I), F => {
              if (Ae(F.value)) return null;
              const Y = F.value;
              return T.test(Y) ? null : {
                pattern: {
                  requiredPattern: _,
                  actualValue: Y
                }
              }
            }
          }(T)
        }
        static nullValidator(T) {
          return null
        }
        static compose(T) {
          return he(T)
        }
        static composeAsync(T) {
          return ve(T)
        }
      }

      function ie(I) {
        return Ae(I.value) ? {
          required: !0
        } : null
      }

      function xe(I) {
        return null
      }

      function be(I) {
        return null != I
      }

      function et(I) {
        return (0, g.jNT)(I) ? (0, ee.H)(I) : I
      }

      function Et(I) {
        let T = {};
        return I.forEach(_ => {
          T = null != _ ? {
            ...T,
            ..._
          } : T
        }), 0 === Object.keys(T).length ? null : T
      }

      function Ht(I, T) {
        return T.map(_ => _(I))
      }

      function Yn(I) {
        return I.map(T => function Zt(I) {
          return !I.validate
        }(T) ? T : _ => T.validate(_))
      }

      function he(I) {
        if (!I) return null;
        const T = I.filter(be);
        return 0 == T.length ? null : function(_) {
          return Et(Ht(_, T))
        }
      }

      function ye(I) {
        return null != I ? he(Yn(I)) : null
      }

      function ve(I) {
        if (!I) return null;
        const T = I.filter(be);
        return 0 == T.length ? null : function(_) {
          const F = Ht(_, T).map(et);
          return (0, ae.p)(F).pipe((0, A.T)(Et))
        }
      }

      function Ce(I) {
        return null != I ? ve(Yn(I)) : null
      }

      function ke(I, T) {
        return null === I ? [T] : Array.isArray(I) ? [...I, T] : [I, T]
      }

      function Le(I) {
        return I._rawValidators
      }

      function rt(I) {
        return I._rawAsyncValidators
      }

      function Nt(I) {
        return I ? Array.isArray(I) ? I : [I] : []
      }

      function ln(I, T) {
        return Array.isArray(I) ? I.includes(T) : I === T
      }

      function ht(I, T) {
        const _ = Nt(T);
        return Nt(I).forEach(Y => {
          ln(_, Y) || _.push(Y)
        }), _
      }

      function Ut(I, T) {
        return Nt(T).filter(_ => !ln(I, _))
      }
      class nn {
        constructor() {
          this._rawValidators = [], this._rawAsyncValidators = [], this._onDestroyCallbacks = []
        }
        get value() {
          return this.control ? this.control.value : null
        }
        get valid() {
          return this.control ? this.control.valid : null
        }
        get invalid() {
          return this.control ? this.control.invalid : null
        }
        get pending() {
          return this.control ? this.control.pending : null
        }
        get disabled() {
          return this.control ? this.control.disabled : null
        }
        get enabled() {
          return this.control ? this.control.enabled : null
        }
        get errors() {
          return this.control ? this.control.errors : null
        }
        get pristine() {
          return this.control ? this.control.pristine : null
        }
        get dirty() {
          return this.control ? this.control.dirty : null
        }
        get touched() {
          return this.control ? this.control.touched : null
        }
        get status() {
          return this.control ? this.control.status : null
        }
        get untouched() {
          return this.control ? this.control.untouched : null
        }
        get statusChanges() {
          return this.control ? this.control.statusChanges : null
        }
        get valueChanges() {
          return this.control ? this.control.valueChanges : null
        }
        get path() {
          return null
        }
        _setValidators(T) {
          this._rawValidators = T || [], this._composedValidatorFn = ye(this._rawValidators)
        }
        _setAsyncValidators(T) {
          this._rawAsyncValidators = T || [], this._composedAsyncValidatorFn = Ce(this._rawAsyncValidators)
        }
        get validator() {
          return this._composedValidatorFn || null
        }
        get asyncValidator() {
          return this._composedAsyncValidatorFn || null
        }
        _registerOnDestroy(T) {
          this._onDestroyCallbacks.push(T)
        }
        _invokeOnDestroyCallbacks() {
          this._onDestroyCallbacks.forEach(T => T()), this._onDestroyCallbacks = []
        }
        reset(T = void 0) {
          this.control && this.control.reset(T)
        }
        hasError(T, _) {
          return !!this.control && this.control.hasError(T, _)
        }
        getError(T, _) {
          return this.control ? this.control.getError(T, _) : null
        }
      }
      class bt extends nn {
        get formDirective() {
          return null
        }
        get path() {
          return null
        }
      }
      class Ct extends nn {
        constructor() {
          super(...arguments), this._parent = null, this.name = null, this.valueAccessor = null
        }
      }
      class dn {
        constructor(T) {
          this._cd = T
        }
        get isTouched() {
          return !!this._cd?.control?.touched
        }
        get isUntouched() {
          return !!this._cd?.control?.untouched
        }
        get isPristine() {
          return !!this._cd?.control?.pristine
        }
        get isDirty() {
          return !!this._cd?.control?.dirty
        }
        get isValid() {
          return !!this._cd?.control?.valid
        }
        get isInvalid() {
          return !!this._cd?.control?.invalid
        }
        get isPending() {
          return !!this._cd?.control?.pending
        }
        get isSubmitted() {
          return !!this._cd?.submitted
        }
      }
      let Nn = (() => {
          class I extends dn {
            constructor(_) {
              super(_)
            }
            static #e = this.\u0275fac = function(F) {
              return new(F || I)(g.rXU(Ct, 2))
            };
            static #t = this.\u0275dir = g.FsC({
              type: I,
              selectors: [
                ["", "formControlName", ""],
                ["", "ngModel", ""],
                ["", "formControl", ""]
              ],
              hostVars: 14,
              hostBindings: function(F, Y) {
                2 & F && g.AVh("ng-untouched", Y.isUntouched)("ng-touched", Y.isTouched)("ng-pristine", Y
                  .isPristine)("ng-dirty", Y.isDirty)("ng-valid", Y.isValid)("ng-invalid", Y.isInvalid)(
                  "ng-pending", Y.isPending)
              },
              features: [g.Vt3]
            })
          }
          return I
        })(),
        Ke = (() => {
          class I extends dn {
            constructor(_) {
              super(_)
            }
            static #e = this.\u0275fac = function(F) {
              return new(F || I)(g.rXU(bt, 10))
            };
            static #t = this.\u0275dir = g.FsC({
              type: I,
              selectors: [
                ["", "formGroupName", ""],
                ["", "formArrayName", ""],
                ["", "ngModelGroup", ""],
                ["", "formGroup", ""],
                ["form", 3, "ngNoForm", ""],
                ["", "ngForm", ""]
              ],
              hostVars: 16,
              hostBindings: function(F, Y) {
                2 & F && g.AVh("ng-untouched", Y.isUntouched)("ng-touched", Y.isTouched)("ng-pristine", Y
                  .isPristine)("ng-dirty", Y.isDirty)("ng-valid", Y.isValid)("ng-invalid", Y.isInvalid)(
                  "ng-pending", Y.isPending)("ng-submitted", Y.isSubmitted)
              },
              features: [g.Vt3]
            })
          }
          return I
        })();
      const Pt = "VALID",
        _r = "INVALID",
        Jt = "PENDING",
        Kn = "DISABLED";

      function ri(I) {
        return (te(I) ? I.validators : I) || null
      }

      function qn(I, T) {
        return (te(T) ? T.asyncValidators : I) || null
      }

      function te(I) {
        return null != I && !Array.isArray(I) && "object" == typeof I
      }
      class Oe {
        constructor(T, _) {
          this._pendingDirty = !1, this._hasOwnPendingAsyncValidator = !1, this._pendingTouched = !1, this
            ._onCollectionChange = () => {}, this._parent = null, this.pristine = !0, this.touched = !1, this
            ._onDisabledChange = [], this._assignValidators(T), this._assignAsyncValidators(_)
        }
        get validator() {
          return this._composedValidatorFn
        }
        set validator(T) {
          this._rawValidators = this._composedValidatorFn = T
        }
        get asyncValidator() {
          return this._composedAsyncValidatorFn
        }
        set asyncValidator(T) {
          this._rawAsyncValidators = this._composedAsyncValidatorFn = T
        }
        get parent() {
          return this._parent
        }
        get valid() {
          return this.status === Pt
        }
        get invalid() {
          return this.status === _r
        }
        get pending() {
          return this.status == Jt
        }
        get disabled() {
          return this.status === Kn
        }
        get enabled() {
          return this.status !== Kn
        }
        get dirty() {
          return !this.pristine
        }
        get untouched() {
          return !this.touched
        }
        get updateOn() {
          return this._updateOn ? this._updateOn : this.parent ? this.parent.updateOn : "change"
        }
        setValidators(T) {
          this._assignValidators(T)
        }
        setAsyncValidators(T) {
          this._assignAsyncValidators(T)
        }
        addValidators(T) {
          this.setValidators(ht(T, this._rawValidators))
        }
        addAsyncValidators(T) {
          this.setAsyncValidators(ht(T, this._rawAsyncValidators))
        }
        removeValidators(T) {
          this.setValidators(Ut(T, this._rawValidators))
        }
        removeAsyncValidators(T) {
          this.setAsyncValidators(Ut(T, this._rawAsyncValidators))
        }
        hasValidator(T) {
          return ln(this._rawValidators, T)
        }
        hasAsyncValidator(T) {
          return ln(this._rawAsyncValidators, T)
        }
        clearValidators() {
          this.validator = null
        }
        clearAsyncValidators() {
          this.asyncValidator = null
        }
        markAsTouched(T = {}) {
          this.touched = !0, this._parent && !T.onlySelf && this._parent.markAsTouched(T)
        }
        markAllAsTouched() {
          this.markAsTouched({
            onlySelf: !0
          }), this._forEachChild(T => T.markAllAsTouched())
        }
        markAsUntouched(T = {}) {
          this.touched = !1, this._pendingTouched = !1, this._forEachChild(_ => {
            _.markAsUntouched({
              onlySelf: !0
            })
          }), this._parent && !T.onlySelf && this._parent._updateTouched(T)
        }
        markAsDirty(T = {}) {
          this.pristine = !1, this._parent && !T.onlySelf && this._parent.markAsDirty(T)
        }
        markAsPristine(T = {}) {
          this.pristine = !0, this._pendingDirty = !1, this._forEachChild(_ => {
            _.markAsPristine({
              onlySelf: !0
            })
          }), this._parent && !T.onlySelf && this._parent._updatePristine(T)
        }
        markAsPending(T = {}) {
          this.status = Jt, !1 !== T.emitEvent && this.statusChanges.emit(this.status), this._parent && !T
            .onlySelf && this._parent.markAsPending(T)
        }
        disable(T = {}) {
          const _ = this._parentMarkedDirty(T.onlySelf);
          this.status = Kn, this.errors = null, this._forEachChild(F => {
            F.disable({
              ...T,
              onlySelf: !0
            })
          }), this._updateValue(), !1 !== T.emitEvent && (this.valueChanges.emit(this.value), this
            .statusChanges.emit(this.status)), this._updateAncestors({
            ...T,
            skipPristineCheck: _
          }), this._onDisabledChange.forEach(F => F(!0))
        }
        enable(T = {}) {
          const _ = this._parentMarkedDirty(T.onlySelf);
          this.status = Pt, this._forEachChild(F => {
            F.enable({
              ...T,
              onlySelf: !0
            })
          }), this.updateValueAndValidity({
            onlySelf: !0,
            emitEvent: T.emitEvent
          }), this._updateAncestors({
            ...T,
            skipPristineCheck: _
          }), this._onDisabledChange.forEach(F => F(!1))
        }
        _updateAncestors(T) {
          this._parent && !T.onlySelf && (this._parent.updateValueAndValidity(T), T.skipPristineCheck || this
            ._parent._updatePristine(), this._parent._updateTouched())
        }
        setParent(T) {
          this._parent = T
        }
        getRawValue() {
          return this.value
        }
        updateValueAndValidity(T = {}) {
          this._setInitialStatus(), this._updateValue(), this.enabled && (this._cancelExistingSubscription(),
              this.errors = this._runValidator(), this.status = this._calculateStatus(), (this.status === Pt ||
                this.status === Jt) && this._runAsyncValidator(T.emitEvent)), !1 !== T.emitEvent && (this
              .valueChanges.emit(this.value), this.statusChanges.emit(this.status)), this._parent && !T
            .onlySelf && this._parent.updateValueAndValidity(T)
        }
        _updateTreeValidity(T = {
          emitEvent: !0
        }) {
          this._forEachChild(_ => _._updateTreeValidity(T)), this.updateValueAndValidity({
            onlySelf: !0,
            emitEvent: T.emitEvent
          })
        }
        _setInitialStatus() {
          this.status = this._allControlsDisabled() ? Kn : Pt
        }
        _runValidator() {
          return this.validator ? this.validator(this) : null
        }
        _runAsyncValidator(T) {
          if (this.asyncValidator) {
            this.status = Jt, this._hasOwnPendingAsyncValidator = !0;
            const _ = et(this.asyncValidator(this));
            this._asyncValidationSubscription = _.subscribe(F => {
              this._hasOwnPendingAsyncValidator = !1, this.setErrors(F, {
                emitEvent: T
              })
            })
          }
        }
        _cancelExistingSubscription() {
          this._asyncValidationSubscription && (this._asyncValidationSubscription.unsubscribe(), this
            ._hasOwnPendingAsyncValidator = !1)
        }
        setErrors(T, _ = {}) {
          this.errors = T, this._updateControlsErrors(!1 !== _.emitEvent)
        }
        get(T) {
          let _ = T;
          return null == _ || (Array.isArray(_) || (_ = _.split(".")), 0 === _.length) ? null : _.reduce((F,
            Y) => F && F._find(Y), this)
        }
        getError(T, _) {
          const F = _ ? this.get(_) : this;
          return F && F.errors ? F.errors[T] : null
        }
        hasError(T, _) {
          return !!this.getError(T, _)
        }
        get root() {
          let T = this;
          for (; T._parent;) T = T._parent;
          return T
        }
        _updateControlsErrors(T) {
          this.status = this._calculateStatus(), T && this.statusChanges.emit(this.status), this._parent && this
            ._parent._updateControlsErrors(T)
        }
        _initObservables() {
          this.valueChanges = new g.bkB, this.statusChanges = new g.bkB
        }
        _calculateStatus() {
          return this._allControlsDisabled() ? Kn : this.errors ? _r : this._hasOwnPendingAsyncValidator || this
            ._anyControlsHaveStatus(Jt) ? Jt : this._anyControlsHaveStatus(_r) ? _r : Pt
        }
        _anyControlsHaveStatus(T) {
          return this._anyControls(_ => _.status === T)
        }
        _anyControlsDirty() {
          return this._anyControls(T => T.dirty)
        }
        _anyControlsTouched() {
          return this._anyControls(T => T.touched)
        }
        _updatePristine(T = {}) {
          this.pristine = !this._anyControlsDirty(), this._parent && !T.onlySelf && this._parent
            ._updatePristine(T)
        }
        _updateTouched(T = {}) {
          this.touched = this._anyControlsTouched(), this._parent && !T.onlySelf && this._parent._updateTouched(
            T)
        }
        _registerOnCollectionChange(T) {
          this._onCollectionChange = T
        }
        _setUpdateStrategy(T) {
          te(T) && null != T.updateOn && (this._updateOn = T.updateOn)
        }
        _parentMarkedDirty(T) {
          return !T && !(!this._parent || !this._parent.dirty) && !this._parent._anyControlsDirty()
        }
        _find(T) {
          return null
        }
        _assignValidators(T) {
          this._rawValidators = Array.isArray(T) ? T.slice() : T, this._composedValidatorFn = function Di(I) {
            return Array.isArray(I) ? ye(I) : I || null
          }(this._rawValidators)
        }
        _assignAsyncValidators(T) {
          this._rawAsyncValidators = Array.isArray(T) ? T.slice() : T, this._composedAsyncValidatorFn =
            function re(I) {
              return Array.isArray(I) ? Ce(I) : I || null
            }(this._rawAsyncValidators)
        }
      }
      class Qe extends Oe {
        constructor(T, _, F) {
          super(ri(_), qn(F, _)), this.controls = T, this._initObservables(), this._setUpdateStrategy(_), this
            ._setUpControls(), this.updateValueAndValidity({
              onlySelf: !0,
              emitEvent: !!this.asyncValidator
            })
        }
        registerControl(T, _) {
          return this.controls[T] ? this.controls[T] : (this.controls[T] = _, _.setParent(this), _
            ._registerOnCollectionChange(this._onCollectionChange), _)
        }
        addControl(T, _, F = {}) {
          this.registerControl(T, _), this.updateValueAndValidity({
            emitEvent: F.emitEvent
          }), this._onCollectionChange()
        }
        removeControl(T, _ = {}) {
          this.controls[T] && this.controls[T]._registerOnCollectionChange(() => {}), delete this.controls[T],
            this.updateValueAndValidity({
              emitEvent: _.emitEvent
            }), this._onCollectionChange()
        }
        setControl(T, _, F = {}) {
          this.controls[T] && this.controls[T]._registerOnCollectionChange(() => {}), delete this.controls[T],
            _ && this.registerControl(T, _), this.updateValueAndValidity({
              emitEvent: F.emitEvent
            }), this._onCollectionChange()
        }
        contains(T) {
          return this.controls.hasOwnProperty(T) && this.controls[T].enabled
        }
        setValue(T, _ = {}) {
          (function J(I, T, _) {
            I._forEachChild((F, Y) => {
              if (void 0 === _[Y]) throw new g.wOt(1002, "")
            })
          })(this, 0, T), Object.keys(T).forEach(F => {
            (function H(I, T, _) {
              const F = I.controls;
              if (!(T ? Object.keys(F) : F).length) throw new g.wOt(1e3, "");
              if (!F[_]) throw new g.wOt(1001, "")
            })(this, !0, F), this.controls[F].setValue(T[F], {
              onlySelf: !0,
              emitEvent: _.emitEvent
            })
          }), this.updateValueAndValidity(_)
        }
        patchValue(T, _ = {}) {
          null != T && (Object.keys(T).forEach(F => {
            const Y = this.controls[F];
            Y && Y.patchValue(T[F], {
              onlySelf: !0,
              emitEvent: _.emitEvent
            })
          }), this.updateValueAndValidity(_))
        }
        reset(T = {}, _ = {}) {
          this._forEachChild((F, Y) => {
            F.reset(T ? T[Y] : null, {
              onlySelf: !0,
              emitEvent: _.emitEvent
            })
          }), this._updatePristine(_), this._updateTouched(_), this.updateValueAndValidity(_)
        }
        getRawValue() {
          return this._reduceChildren({}, (T, _, F) => (T[F] = _.getRawValue(), T))
        }
        _syncPendingControls() {
          let T = this._reduceChildren(!1, (_, F) => !!F._syncPendingControls() || _);
          return T && this.updateValueAndValidity({
            onlySelf: !0
          }), T
        }
        _forEachChild(T) {
          Object.keys(this.controls).forEach(_ => {
            const F = this.controls[_];
            F && T(F, _)
          })
        }
        _setUpControls() {
          this._forEachChild(T => {
            T.setParent(this), T._registerOnCollectionChange(this._onCollectionChange)
          })
        }
        _updateValue() {
          this.value = this._reduceValue()
        }
        _anyControls(T) {
          for (const [_, F] of Object.entries(this.controls))
            if (this.contains(_) && T(F)) return !0;
          return !1
        }
        _reduceValue() {
          return this._reduceChildren({}, (_, F, Y) => ((F.enabled || this.disabled) && (_[Y] = F.value), _))
        }
        _reduceChildren(T, _) {
          let F = T;
          return this._forEachChild((Y, ut) => {
            F = _(F, Y, ut)
          }), F
        }
        _allControlsDisabled() {
          for (const T of Object.keys(this.controls))
            if (this.controls[T].enabled) return !1;
          return Object.keys(this.controls).length > 0 || this.disabled
        }
        _find(T) {
          return this.controls.hasOwnProperty(T) ? this.controls[T] : null
        }
      }
      const yn = new g.nKC("CallSetDisabledState", {
          providedIn: "root",
          factory: () => lr
        }),
        lr = "always";

      function cr(I, T) {
        return [...T.path, I]
      }

      function qr(I, T, _ = lr) {
        Qr(I, T), T.valueAccessor.writeValue(I.value), (I.disabled || "always" === _) && T.valueAccessor
          .setDisabledState?.(I.disabled),
          function bs(I, T) {
            T.valueAccessor.registerOnChange(_ => {
              I._pendingValue = _, I._pendingChange = !0, I._pendingDirty = !0, "change" === I.updateOn && Gt(
                I, T)
            })
          }(I, T),
          function zi(I, T) {
            const _ = (F, Y) => {
              T.valueAccessor.writeValue(F), Y && T.viewToModelUpdate(F)
            };
            I.registerOnChange(_), T._registerOnDestroy(() => {
              I._unregisterOnChange(_)
            })
          }(I, T),
          function Vr(I, T) {
            T.valueAccessor.registerOnTouched(() => {
              I._pendingTouched = !0, "blur" === I.updateOn && I._pendingChange && Gt(I, T), "submit" !== I
                .updateOn && I.markAsTouched()
            })
          }(I, T),
          function Gi(I, T) {
            if (T.valueAccessor.setDisabledState) {
              const _ = F => {
                T.valueAccessor.setDisabledState(F)
              };
              I.registerOnDisabledChange(_), T._registerOnDestroy(() => {
                I._unregisterOnDisabledChange(_)
              })
            }
          }(I, T)
      }

      function fn(I, T, _ = !0) {
        const F = () => {};
        T.valueAccessor && (T.valueAccessor.registerOnChange(F), T.valueAccessor.registerOnTouched(F)), ii(I, T),
          I && (T._invokeOnDestroyCallbacks(), I._registerOnCollectionChange(() => {}))
      }

      function at(I, T) {
        I.forEach(_ => {
          _.registerOnValidatorChange && _.registerOnValidatorChange(T)
        })
      }

      function Qr(I, T) {
        const _ = Le(I);
        null !== T.validator ? I.setValidators(ke(_, T.validator)) : "function" == typeof _ && I.setValidators([
          _]);
        const F = rt(I);
        null !== T.asyncValidator ? I.setAsyncValidators(ke(F, T.asyncValidator)) : "function" == typeof F && I
          .setAsyncValidators([F]);
        const Y = () => I.updateValueAndValidity();
        at(T._rawValidators, Y), at(T._rawAsyncValidators, Y)
      }

      function ii(I, T) {
        let _ = !1;
        if (null !== I) {
          if (null !== T.validator) {
            const Y = Le(I);
            if (Array.isArray(Y) && Y.length > 0) {
              const ut = Y.filter(Rt => Rt !== T.validator);
              ut.length !== Y.length && (_ = !0, I.setValidators(ut))
            }
          }
          if (null !== T.asyncValidator) {
            const Y = rt(I);
            if (Array.isArray(Y) && Y.length > 0) {
              const ut = Y.filter(Rt => Rt !== T.asyncValidator);
              ut.length !== Y.length && (_ = !0, I.setAsyncValidators(ut))
            }
          }
        }
        const F = () => {};
        return at(T._rawValidators, F), at(T._rawAsyncValidators, F), _
      }

      function Gt(I, T) {
        I._pendingDirty && I.markAsDirty(), I.setValue(I._pendingValue, {
          emitModelToViewChange: !1
        }), T.viewToModelUpdate(I._pendingValue), I._pendingChange = !1
      }

      function si(I, T) {
        Qr(I, T)
      }

      function z(I, T) {
        if (!I.hasOwnProperty("model")) return !1;
        const _ = I.model;
        return !!_.isFirstChange() || !Object.is(T, _.currentValue)
      }

      function Ee(I, T) {
        I._syncPendingControls(), T.forEach(_ => {
          const F = _.control;
          "submit" === F.updateOn && F._pendingChange && (_.viewToModelUpdate(F._pendingValue), F
            ._pendingChange = !1)
        })
      }

      function pe(I, T) {
        if (!T) return null;
        let _, F, Y;
        return Array.isArray(T), T.forEach(ut => {
          ut.constructor === me ? _ = ut : function K(I) {
            return Object.getPrototypeOf(I.constructor) === M
          }(ut) ? F = ut : Y = ut
        }), Y || F || _ || null
      }
      const _t = {
          provide: bt,
          useExisting: (0, g.Rfq)(() => Qt)
        },
        it = Promise.resolve();
      let Qt = (() => {
        class I extends bt {
          constructor(_, F, Y) {
            super(), this.callSetDisabledState = Y, this.submitted = !1, this._directives = new Set, this
              .ngSubmit = new g.bkB, this.form = new Qe({}, ye(_), Ce(F))
          }
          ngAfterViewInit() {
            this._setUpdateStrategy()
          }
          get formDirective() {
            return this
          }
          get control() {
            return this.form
          }
          get path() {
            return []
          }
          get controls() {
            return this.form.controls
          }
          addControl(_) {
            it.then(() => {
              const F = this._findContainer(_.path);
              _.control = F.registerControl(_.name, _.control), qr(_.control, _, this
                .callSetDisabledState), _.control.updateValueAndValidity({
                emitEvent: !1
              }), this._directives.add(_)
            })
          }
          getControl(_) {
            return this.form.get(_.path)
          }
          removeControl(_) {
            it.then(() => {
              const F = this._findContainer(_.path);
              F && F.removeControl(_.name), this._directives.delete(_)
            })
          }
          addFormGroup(_) {
            it.then(() => {
              const F = this._findContainer(_.path),
                Y = new Qe({});
              si(Y, _), F.registerControl(_.name, Y), Y.updateValueAndValidity({
                emitEvent: !1
              })
            })
          }
          removeFormGroup(_) {
            it.then(() => {
              const F = this._findContainer(_.path);
              F && F.removeControl(_.name)
            })
          }
          getFormGroup(_) {
            return this.form.get(_.path)
          }
          updateModel(_, F) {
            it.then(() => {
              this.form.get(_.path).setValue(F)
            })
          }
          setValue(_) {
            this.control.setValue(_)
          }
          onSubmit(_) {
            return this.submitted = !0, Ee(this.form, this._directives), this.ngSubmit.emit(_), "dialog" ===
              _?.target?.method
          }
          onReset() {
            this.resetForm()
          }
          resetForm(_ = void 0) {
            this.form.reset(_), this.submitted = !1
          }
          _setUpdateStrategy() {
            this.options && null != this.options.updateOn && (this.form._updateOn = this.options.updateOn)
          }
          _findContainer(_) {
            return _.pop(), _.length ? this.form.get(_) : this.form
          }
          static #e = this.\u0275fac = function(F) {
            return new(F || I)(g.rXU(we, 10), g.rXU(Ve, 10), g.rXU(yn, 8))
          };
          static #t = this.\u0275dir = g.FsC({
            type: I,
            selectors: [
              ["form", 3, "ngNoForm", "", 3, "formGroup", ""],
              ["ng-form"],
              ["", "ngForm", ""]
            ],
            hostBindings: function(F, Y) {
              1 & F && g.bIt("submit", function(Rt) {
                return Y.onSubmit(Rt)
              })("reset", function() {
                return Y.onReset()
              })
            },
            inputs: {
              options: [g.Mj6.None, "ngFormOptions", "options"]
            },
            outputs: {
              ngSubmit: "ngSubmit"
            },
            exportAs: ["ngForm"],
            features: [g.Jv_([_t]), g.Vt3]
          })
        }
        return I
      })();

      function Xt(I, T) {
        const _ = I.indexOf(T);
        _ > -1 && I.splice(_, 1)
      }

      function Ft(I) {
        return "object" == typeof I && null !== I && 2 === Object.keys(I).length && "value" in I && "disabled" in
          I
      }
      const sn = class extends Oe {
          constructor(T = null, _, F) {
            super(ri(_), qn(F, _)), this.defaultValue = null, this._onChange = [], this._pendingChange = !1,
              this._applyFormState(T), this._setUpdateStrategy(_), this._initObservables(), this
              .updateValueAndValidity({
                onlySelf: !0,
                emitEvent: !!this.asyncValidator
              }), te(_) && (_.nonNullable || _.initialValueIsDefault) && (this.defaultValue = Ft(T) ? T.value :
                T)
          }
          setValue(T, _ = {}) {
            this.value = this._pendingValue = T, this._onChange.length && !1 !== _.emitModelToViewChange && this
              ._onChange.forEach(F => F(this.value, !1 !== _.emitViewToModelChange)), this
              .updateValueAndValidity(_)
          }
          patchValue(T, _ = {}) {
            this.setValue(T, _)
          }
          reset(T = this.defaultValue, _ = {}) {
            this._applyFormState(T), this.markAsPristine(_), this.markAsUntouched(_), this.setValue(this.value,
              _), this._pendingChange = !1
          }
          _updateValue() {}
          _anyControls(T) {
            return !1
          }
          _allControlsDisabled() {
            return this.disabled
          }
          registerOnChange(T) {
            this._onChange.push(T)
          }
          _unregisterOnChange(T) {
            Xt(this._onChange, T)
          }
          registerOnDisabledChange(T) {
            this._onDisabledChange.push(T)
          }
          _unregisterOnDisabledChange(T) {
            Xt(this._onDisabledChange, T)
          }
          _forEachChild(T) {}
          _syncPendingControls() {
            return !("submit" !== this.updateOn || (this._pendingDirty && this.markAsDirty(), this
              ._pendingTouched && this.markAsTouched(), !this._pendingChange) || (this.setValue(this
              ._pendingValue, {
                onlySelf: !0,
                emitModelToViewChange: !1
              }), 0))
          }
          _applyFormState(T) {
            Ft(T) ? (this.value = this._pendingValue = T.value, T.disabled ? this.disable({
              onlySelf: !0,
              emitEvent: !1
            }) : this.enable({
              onlySelf: !0,
              emitEvent: !1
            })) : this.value = this._pendingValue = T
          }
        },
        gn = {
          provide: Ct,
          useExisting: (0, g.Rfq)(() => Ye)
        },
        lt = Promise.resolve();
      let Ye = (() => {
          class I extends Ct {
            constructor(_, F, Y, ut, Rt, hr) {
              super(), this._changeDetectorRef = Rt, this.callSetDisabledState = hr, this.control = new sn,
                this._registered = !1, this.name = "", this.update = new g.bkB, this._parent = _, this
                ._setValidators(F), this._setAsyncValidators(Y), this.valueAccessor = pe(0, ut)
            }
            ngOnChanges(_) {
              if (this._checkForErrors(), !this._registered || "name" in _) {
                if (this._registered && (this._checkName(), this.formDirective)) {
                  const F = _.name.previousValue;
                  this.formDirective.removeControl({
                    name: F,
                    path: this._getPath(F)
                  })
                }
                this._setUpControl()
              }
              "isDisabled" in _ && this._updateDisabled(_), z(_, this.viewModel) && (this._updateValue(this
                .model), this.viewModel = this.model)
            }
            ngOnDestroy() {
              this.formDirective && this.formDirective.removeControl(this)
            }
            get path() {
              return this._getPath(this.name)
            }
            get formDirective() {
              return this._parent ? this._parent.formDirective : null
            }
            viewToModelUpdate(_) {
              this.viewModel = _, this.update.emit(_)
            }
            _setUpControl() {
              this._setUpdateStrategy(), this._isStandalone() ? this._setUpStandalone() : this.formDirective
                .addControl(this), this._registered = !0
            }
            _setUpdateStrategy() {
              this.options && null != this.options.updateOn && (this.control._updateOn = this.options
                .updateOn)
            }
            _isStandalone() {
              return !this._parent || !(!this.options || !this.options.standalone)
            }
            _setUpStandalone() {
              qr(this.control, this, this.callSetDisabledState), this.control.updateValueAndValidity({
                emitEvent: !1
              })
            }
            _checkForErrors() {
              this._isStandalone() || this._checkParentType(), this._checkName()
            }
            _checkParentType() {}
            _checkName() {
              this.options && this.options.name && (this.name = this.options.name), this._isStandalone()
            }
            _updateValue(_) {
              lt.then(() => {
                this.control.setValue(_, {
                  emitViewToModelChange: !1
                }), this._changeDetectorRef?.markForCheck()
              })
            }
            _updateDisabled(_) {
              const F = _.isDisabled.currentValue,
                Y = 0 !== F && (0, g.L39)(F);
              lt.then(() => {
                Y && !this.control.disabled ? this.control.disable() : !Y && this.control.disabled && this
                  .control.enable(), this._changeDetectorRef?.markForCheck()
              })
            }
            _getPath(_) {
              return this._parent ? cr(_, this._parent) : [_]
            }
            static #e = this.\u0275fac = function(F) {
              return new(F || I)(g.rXU(bt, 9), g.rXU(we, 10), g.rXU(Ve, 10), g.rXU(V, 10), g.rXU(g.gRc, 8), g
                .rXU(yn, 8))
            };
            static #t = this.\u0275dir = g.FsC({
              type: I,
              selectors: [
                ["", "ngModel", "", 3, "formControlName", "", 3, "formControl", ""]
              ],
              inputs: {
                name: "name",
                isDisabled: [g.Mj6.None, "disabled", "isDisabled"],
                model: [g.Mj6.None, "ngModel", "model"],
                options: [g.Mj6.None, "ngModelOptions", "options"]
              },
              outputs: {
                update: "ngModelChange"
              },
              exportAs: ["ngModel"],
              features: [g.Jv_([gn]), g.Vt3, g.OA$]
            })
          }
          return I
        })(),
        Fr = (() => {
          class I {
            static #e = this.\u0275fac = function(F) {
              return new(F || I)
            };
            static #t = this.\u0275dir = g.FsC({
              type: I,
              selectors: [
                ["form", 3, "ngNoForm", "", 3, "ngNativeValidate", ""]
              ],
              hostAttrs: ["novalidate", ""]
            })
          }
          return I
        })();
      const Vn = new g.nKC(""),
        rs = {
          provide: bt,
          useExisting: (0, g.Rfq)(() => Ur)
        };
      let Ur = (() => {
        class I extends bt {
          constructor(_, F, Y) {
            super(), this.callSetDisabledState = Y, this.submitted = !1, this._onCollectionChange = () =>
              this._updateDomValue(), this.directives = [], this.form = null, this.ngSubmit = new g.bkB,
              this._setValidators(_), this._setAsyncValidators(F)
          }
          ngOnChanges(_) {
            this._checkFormPresent(), _.hasOwnProperty("form") && (this._updateValidators(), this
              ._updateDomValue(), this._updateRegistrations(), this._oldForm = this.form)
          }
          ngOnDestroy() {
            this.form && (ii(this.form, this), this.form._onCollectionChange === this._onCollectionChange &&
              this.form._registerOnCollectionChange(() => {}))
          }
          get formDirective() {
            return this
          }
          get control() {
            return this.form
          }
          get path() {
            return []
          }
          addControl(_) {
            const F = this.form.get(_.path);
            return qr(F, _, this.callSetDisabledState), F.updateValueAndValidity({
              emitEvent: !1
            }), this.directives.push(_), F
          }
          getControl(_) {
            return this.form.get(_.path)
          }
          removeControl(_) {
            fn(_.control || null, _, !1),
              function je(I, T) {
                const _ = I.indexOf(T);
                _ > -1 && I.splice(_, 1)
              }(this.directives, _)
          }
          addFormGroup(_) {
            this._setUpFormContainer(_)
          }
          removeFormGroup(_) {
            this._cleanUpFormContainer(_)
          }
          getFormGroup(_) {
            return this.form.get(_.path)
          }
          addFormArray(_) {
            this._setUpFormContainer(_)
          }
          removeFormArray(_) {
            this._cleanUpFormContainer(_)
          }
          getFormArray(_) {
            return this.form.get(_.path)
          }
          updateModel(_, F) {
            this.form.get(_.path).setValue(F)
          }
          onSubmit(_) {
            return this.submitted = !0, Ee(this.form, this.directives), this.ngSubmit.emit(_), "dialog" ===
              _?.target?.method
          }
          onReset() {
            this.resetForm()
          }
          resetForm(_ = void 0) {
            this.form.reset(_), this.submitted = !1
          }
          _updateDomValue() {
            this.directives.forEach(_ => {
              const F = _.control,
                Y = this.form.get(_.path);
              F !== Y && (fn(F || null, _), (I => I instanceof sn)(Y) && (qr(Y, _, this
                .callSetDisabledState), _.control = Y))
            }), this.form._updateTreeValidity({
              emitEvent: !1
            })
          }
          _setUpFormContainer(_) {
            const F = this.form.get(_.path);
            si(F, _), F.updateValueAndValidity({
              emitEvent: !1
            })
          }
          _cleanUpFormContainer(_) {
            if (this.form) {
              const F = this.form.get(_.path);
              F && function oi(I, T) {
                return ii(I, T)
              }(F, _) && F.updateValueAndValidity({
                emitEvent: !1
              })
            }
          }
          _updateRegistrations() {
            this.form._registerOnCollectionChange(this._onCollectionChange), this._oldForm && this._oldForm
              ._registerOnCollectionChange(() => {})
          }
          _updateValidators() {
            Qr(this.form, this), this._oldForm && ii(this._oldForm, this)
          }
          _checkFormPresent() {}
          static #e = this.\u0275fac = function(F) {
            return new(F || I)(g.rXU(we, 10), g.rXU(Ve, 10), g.rXU(yn, 8))
          };
          static #t = this.\u0275dir = g.FsC({
            type: I,
            selectors: [
              ["", "formGroup", ""]
            ],
            hostBindings: function(F, Y) {
              1 & F && g.bIt("submit", function(Rt) {
                return Y.onSubmit(Rt)
              })("reset", function() {
                return Y.onReset()
              })
            },
            inputs: {
              form: [g.Mj6.None, "formGroup", "form"]
            },
            outputs: {
              ngSubmit: "ngSubmit"
            },
            exportAs: ["ngForm"],
            features: [g.Jv_([rs]), g.Vt3, g.OA$]
          })
        }
        return I
      })();
      const ss = {
        provide: Ct,
        useExisting: (0, g.Rfq)(() => Cr)
      };
      let Cr = (() => {
          class I extends Ct {
            set isDisabled(_) {}
            static #e = this._ngModelWarningSentOnce = !1;constructor(_, F, Y, ut, Rt) {
              super(), this._ngModelWarningConfig = Rt, this._added = !1, this.name = null, this.update = new g
                .bkB, this._ngModelWarningSent = !1, this._parent = _, this._setValidators(F), this
                ._setAsyncValidators(Y), this.valueAccessor = pe(0, ut)
            }
            ngOnChanges(_) {
              this._added || this._setUpControl(), z(_, this.viewModel) && (this.viewModel = this.model, this
                .formDirective.updateModel(this, this.model))
            }
            ngOnDestroy() {
              this.formDirective && this.formDirective.removeControl(this)
            }
            viewToModelUpdate(_) {
              this.viewModel = _, this.update.emit(_)
            }
            get path() {
              return cr(null == this.name ? this.name : this.name.toString(), this._parent)
            }
            get formDirective() {
              return this._parent ? this._parent.formDirective : null
            }
            _checkParentType() {}
            _setUpControl() {
              this._checkParentType(), this.control = this.formDirective.addControl(this), this._added = !0
            }
            static #t = this.\u0275fac = function(F) {
              return new(F || I)(g.rXU(bt, 13), g.rXU(we, 10), g.rXU(Ve, 10), g.rXU(V, 10), g.rXU(Vn, 8))
            };static #n = this.\u0275dir = g.FsC({
              type: I,
              selectors: [
                ["", "formControlName", ""]
              ],
              inputs: {
                name: [g.Mj6.None, "formControlName", "name"],
                isDisabled: [g.Mj6.None, "disabled", "isDisabled"],
                model: [g.Mj6.None, "ngModel", "model"]
              },
              outputs: {
                update: "ngModelChange"
              },
              features: [g.Jv_([ss]), g.Vt3, g.OA$]
            })
          }
          return I
        })(),
        er = (() => {
          class I {
            constructor() {
              this._validator = xe
            }
            ngOnChanges(_) {
              if (this.inputName in _) {
                const F = this.normalizeInput(_[this.inputName].currentValue);
                this._enabled = this.enabled(F), this._validator = this._enabled ? this.createValidator(F) :
                  xe, this._onChange && this._onChange()
              }
            }
            validate(_) {
              return this._validator(_)
            }
            registerOnValidatorChange(_) {
              this._onChange = _
            }
            enabled(_) {
              return null != _
            }
            static #e = this.\u0275fac = function(F) {
              return new(F || I)
            };
            static #t = this.\u0275dir = g.FsC({
              type: I,
              features: [g.OA$]
            })
          }
          return I
        })();
      const Zi = {
        provide: we,
        useExisting: (0, g.Rfq)(() => br),
        multi: !0
      };
      let br = (() => {
          class I extends er {
            constructor() {
              super(...arguments), this.inputName = "required", this.normalizeInput = g.L39, this
                .createValidator = _ => ie
            }
            enabled(_) {
              return _
            }
            static #e = this.\u0275fac = (() => {
              let _;
              return function(Y) {
                return (_ || (_ = g.xGo(I)))(Y || I)
              }
            })();
            static #t = this.\u0275dir = g.FsC({
              type: I,
              selectors: [
                ["", "required", "", "formControlName", "", 3, "type", "checkbox"],
                ["", "required", "", "formControl", "", 3, "type", "checkbox"],
                ["", "required", "", "ngModel", "", 3, "type", "checkbox"]
              ],
              hostVars: 1,
              hostBindings: function(F, Y) {
                2 & F && g.BMQ("required", Y._enabled ? "" : null)
              },
              inputs: {
                required: "required"
              },
              features: [g.Jv_([Zi]), g.Vt3]
            })
          }
          return I
        })(),
        nr = (() => {
          class I {
            static #e = this.\u0275fac = function(F) {
              return new(F || I)
            };
            static #t = this.\u0275mod = g.$C({
              type: I
            });
            static #n = this.\u0275inj = g.G2t({})
          }
          return I
        })(),
        Sr = (() => {
          class I {
            static withConfig(_) {
              return {
                ngModule: I,
                providers: [{
                  provide: yn,
                  useValue: _.callSetDisabledState ?? lr
                }]
              }
            }
            static #e = this.\u0275fac = function(F) {
              return new(F || I)
            };
            static #t = this.\u0275mod = g.$C({
              type: I
            });
            static #n = this.\u0275inj = g.G2t({
              imports: [nr]
            })
          }
          return I
        })(),
        Vi = (() => {
          class I {
            static withConfig(_) {
              return {
                ngModule: I,
                providers: [{
                  provide: Vn,
                  useValue: _.warnOnNgModelWithFormControl ?? "always"
                }, {
                  provide: yn,
                  useValue: _.callSetDisabledState ?? lr
                }]
              }
            }
            static #e = this.\u0275fac = function(F) {
              return new(F || I)
            };
            static #t = this.\u0275mod = g.$C({
              type: I
            });
            static #n = this.\u0275inj = g.G2t({
              imports: [nr]
            })
          }
          return I
        })()
    },
    345: (nt, Se, x) => {
      x.d(Se, {
        B7: () => Re,
        Bb: () => dn,
        hE: () => Nn,
        sG: () => Ut,
        up: () => ni
      });
      var g = x(4438),
        c = x(177);
      class ee extends c.VF {
        constructor() {
          super(...arguments), this.supportsDOMEvents = !0
        }
      }
      class ae extends ee {
        static makeCurrent() {
          (0, c.ZD)(new ae)
        }
        onAndCancel(te, H, J) {
          return te.addEventListener(H, J), () => {
            te.removeEventListener(H, J)
          }
        }
        dispatchEvent(te, H) {
          te.dispatchEvent(H)
        }
        remove(te) {
          te.parentNode && te.parentNode.removeChild(te)
        }
        createElement(te, H) {
          return (H = H || this.getDefaultDocument()).createElement(te)
        }
        createHtmlDocument() {
          return document.implementation.createHTMLDocument("fakeTitle")
        }
        getDefaultDocument() {
          return document
        }
        isElementNode(te) {
          return te.nodeType === Node.ELEMENT_NODE
        }
        isShadowRoot(te) {
          return te instanceof DocumentFragment
        }
        getGlobalEventTarget(te, H) {
          return "window" === H ? window : "document" === H ? te : "body" === H ? te.body : null
        }
        getBaseHref(te) {
          const H = function k() {
            return A = A || document.querySelector("base"), A ? A.getAttribute("href") : null
          }();
          return null == H ? null : function M(re) {
            return new URL(re, document.baseURI).pathname
          }(H)
        }
        resetBaseElement() {
          A = null
        }
        getUserAgent() {
          return window.navigator.userAgent
        }
        getCookie(te) {
          return (0, c._b)(document.cookie, te)
        }
      }
      let A = null,
        $ = (() => {
          class re {
            build() {
              return new XMLHttpRequest
            }
            static #e = this.\u0275fac = function(J) {
              return new(J || re)
            };
            static #t = this.\u0275prov = g.jDH({
              token: re,
              factory: re.\u0275fac
            })
          }
          return re
        })();
      const X = new g.nKC("");
      let U = (() => {
        class re {
          constructor(H, J) {
            this._zone = J, this._eventNameToPlugin = new Map, H.forEach(Oe => {
              Oe.manager = this
            }), this._plugins = H.slice().reverse()
          }
          addEventListener(H, J, Oe) {
            return this._findPluginFor(J).addEventListener(H, J, Oe)
          }
          getZone() {
            return this._zone
          }
          _findPluginFor(H) {
            let J = this._eventNameToPlugin.get(H);
            if (J) return J;
            if (J = this._plugins.find(Qe => Qe.supports(H)), !J) throw new g.wOt(5101, !1);
            return this._eventNameToPlugin.set(H, J), J
          }
          static #e = this.\u0275fac = function(J) {
            return new(J || re)(g.KVO(X), g.KVO(g.SKi))
          };
          static #t = this.\u0275prov = g.jDH({
            token: re,
            factory: re.\u0275fac
          })
        }
        return re
      })();
      class le {
        constructor(te) {
          this._doc = te
        }
      }
      const Ne = "ng-app-id";
      let me = (() => {
        class re {
          constructor(H, J, Oe, Qe = {}) {
            this.doc = H, this.appId = J, this.nonce = Oe, this.platformId = Qe, this.styleRef = new Map,
              this.hostNodes = new Set, this.styleNodesInDOM = this.collectServerRenderedStyles(), this
              .platformIsServer = (0, c.Vy)(Qe), this.resetHostNodes()
          }
          addStyles(H) {
            for (const J of H) 1 === this.changeUsageCount(J, 1) && this.onStyleAdded(J)
          }
          removeStyles(H) {
            for (const J of H) this.changeUsageCount(J, -1) <= 0 && this.onStyleRemoved(J)
          }
          ngOnDestroy() {
            const H = this.styleNodesInDOM;
            H && (H.forEach(J => J.remove()), H.clear());
            for (const J of this.getAllStyles()) this.onStyleRemoved(J);
            this.resetHostNodes()
          }
          addHost(H) {
            this.hostNodes.add(H);
            for (const J of this.getAllStyles()) this.addStyleToHost(H, J)
          }
          removeHost(H) {
            this.hostNodes.delete(H)
          }
          getAllStyles() {
            return this.styleRef.keys()
          }
          onStyleAdded(H) {
            for (const J of this.hostNodes) this.addStyleToHost(J, H)
          }
          onStyleRemoved(H) {
            const J = this.styleRef;
            J.get(H)?.elements?.forEach(Oe => Oe.remove()), J.delete(H)
          }
          collectServerRenderedStyles() {
            const H = this.doc.head?.querySelectorAll(`style[${Ne}="${this.appId}"]`);
            if (H?.length) {
              const J = new Map;
              return H.forEach(Oe => {
                null != Oe.textContent && J.set(Oe.textContent, Oe)
              }), J
            }
            return null
          }
          changeUsageCount(H, J) {
            const Oe = this.styleRef;
            if (Oe.has(H)) {
              const Qe = Oe.get(H);
              return Qe.usage += J, Qe.usage
            }
            return Oe.set(H, {
              usage: J,
              elements: []
            }), J
          }
          getStyleElement(H, J) {
            const Oe = this.styleNodesInDOM,
              Qe = Oe?.get(J);
            if (Qe?.parentNode === H) return Oe.delete(J), Qe.removeAttribute(Ne), Qe;
            {
              const ct = this.doc.createElement("style");
              return this.nonce && ct.setAttribute("nonce", this.nonce), ct.textContent = J, this
                .platformIsServer && ct.setAttribute(Ne, this.appId), H.appendChild(ct), ct
            }
          }
          addStyleToHost(H, J) {
            const Oe = this.getStyleElement(H, J),
              Qe = this.styleRef,
              ct = Qe.get(J)?.elements;
            ct ? ct.push(Oe) : Qe.set(J, {
              elements: [Oe],
              usage: 1
            })
          }
          resetHostNodes() {
            const H = this.hostNodes;
            H.clear(), H.add(this.doc.head)
          }
          static #e = this.\u0275fac = function(J) {
            return new(J || re)(g.KVO(c.qQ), g.KVO(g.sZ2), g.KVO(g.BIS, 8), g.KVO(g.Agw))
          };
          static #t = this.\u0275prov = g.jDH({
            token: re,
            factory: re.\u0275fac
          })
        }
        return re
      })();
      const Ae = {
          svg: "http://www.w3.org/2000/svg",
          xhtml: "http://www.w3.org/1999/xhtml",
          xlink: "http://www.w3.org/1999/xlink",
          xml: "http://www.w3.org/XML/1998/namespace",
          xmlns: "http://www.w3.org/2000/xmlns/",
          math: "http://www.w3.org/1998/MathML/"
        },
        qe = /%COMP%/g,
        ue = new g.nKC("", {
          providedIn: "root",
          factory: () => !0
        });

      function se(re, te) {
        return te.map(H => H.replace(qe, re))
      }
      let Re = (() => {
        class re {
          constructor(H, J, Oe, Qe, ct, qt, Wt, bn = null) {
            this.eventManager = H, this.sharedStylesHost = J, this.appId = Oe, this
              .removeStylesOnCompDestroy = Qe, this.doc = ct, this.platformId = qt, this.ngZone = Wt, this
              .nonce = bn, this.rendererByCompId = new Map, this.platformIsServer = (0, c.Vy)(qt), this
              .defaultRenderer = new Be(H, ct, Wt, this.platformIsServer)
          }
          createRenderer(H, J) {
            if (!H || !J) return this.defaultRenderer;
            this.platformIsServer && J.encapsulation === g.gXe.ShadowDom && (J = {
              ...J,
              encapsulation: g.gXe.Emulated
            });
            const Oe = this.getOrCreateRenderer(H, J);
            return Oe instanceof Et ? Oe.applyToHost(H) : Oe instanceof et && Oe.applyStyles(), Oe
          }
          getOrCreateRenderer(H, J) {
            const Oe = this.rendererByCompId;
            let Qe = Oe.get(J.id);
            if (!Qe) {
              const ct = this.doc,
                qt = this.ngZone,
                Wt = this.eventManager,
                bn = this.sharedStylesHost,
                Zn = this.removeStylesOnCompDestroy,
                yn = this.platformIsServer;
              switch (J.encapsulation) {
                case g.gXe.Emulated:
                  Qe = new Et(Wt, bn, J, this.appId, Zn, ct, qt, yn);
                  break;
                case g.gXe.ShadowDom:
                  return new be(Wt, bn, H, J, ct, qt, this.nonce, yn);
                default:
                  Qe = new et(Wt, bn, J, Zn, ct, qt, yn)
              }
              Oe.set(J.id, Qe)
            }
            return Qe
          }
          ngOnDestroy() {
            this.rendererByCompId.clear()
          }
          static #e = this.\u0275fac = function(J) {
            return new(J || re)(g.KVO(U), g.KVO(me), g.KVO(g.sZ2), g.KVO(ue), g.KVO(c.qQ), g.KVO(g.Agw), g
              .KVO(g.SKi), g.KVO(g.BIS))
          };
          static #t = this.\u0275prov = g.jDH({
            token: re,
            factory: re.\u0275fac
          })
        }
        return re
      })();
      class Be {
        constructor(te, H, J, Oe) {
          this.eventManager = te, this.doc = H, this.ngZone = J, this.platformIsServer = Oe, this.data = Object
            .create(null), this.throwOnSyntheticProps = !0, this.destroyNode = null
        }
        destroy() {}
        createElement(te, H) {
          return H ? this.doc.createElementNS(Ae[H] || H, te) : this.doc.createElement(te)
        }
        createComment(te) {
          return this.doc.createComment(te)
        }
        createText(te) {
          return this.doc.createTextNode(te)
        }
        appendChild(te, H) {
          (xe(te) ? te.content : te).appendChild(H)
        }
        insertBefore(te, H, J) {
          te && (xe(te) ? te.content : te).insertBefore(H, J)
        }
        removeChild(te, H) {
          te && te.removeChild(H)
        }
        selectRootElement(te, H) {
          let J = "string" == typeof te ? this.doc.querySelector(te) : te;
          if (!J) throw new g.wOt(-5104, !1);
          return H || (J.textContent = ""), J
        }
        parentNode(te) {
          return te.parentNode
        }
        nextSibling(te) {
          return te.nextSibling
        }
        setAttribute(te, H, J, Oe) {
          if (Oe) {
            H = Oe + ":" + H;
            const Qe = Ae[Oe];
            Qe ? te.setAttributeNS(Qe, H, J) : te.setAttribute(H, J)
          } else te.setAttribute(H, J)
        }
        removeAttribute(te, H, J) {
          if (J) {
            const Oe = Ae[J];
            Oe ? te.removeAttributeNS(Oe, H) : te.removeAttribute(`${J}:${H}`)
          } else te.removeAttribute(H)
        }
        addClass(te, H) {
          te.classList.add(H)
        }
        removeClass(te, H) {
          te.classList.remove(H)
        }
        setStyle(te, H, J, Oe) {
          Oe & (g.czy.DashCase | g.czy.Important) ? te.style.setProperty(H, J, Oe & g.czy.Important ?
            "important" : "") : te.style[H] = J
        }
        removeStyle(te, H, J) {
          J & g.czy.DashCase ? te.style.removeProperty(H) : te.style[H] = ""
        }
        setProperty(te, H, J) {
          null != te && (te[H] = J)
        }
        setValue(te, H) {
          te.nodeValue = H
        }
        listen(te, H, J) {
          if ("string" == typeof te && !(te = (0, c.QT)().getGlobalEventTarget(this.doc, te))) throw new Error(
            `Unsupported event target ${te} for event ${H}`);
          return this.eventManager.addEventListener(te, H, this.decoratePreventDefault(J))
        }
        decoratePreventDefault(te) {
          return H => {
            if ("__ngUnwrap__" === H) return te;
            !1 === (this.platformIsServer ? this.ngZone.runGuarded(() => te(H)) : te(H)) && H.preventDefault()
          }
        }
      }

      function xe(re) {
        return "TEMPLATE" === re.tagName && void 0 !== re.content
      }
      class be extends Be {
        constructor(te, H, J, Oe, Qe, ct, qt, Wt) {
          super(te, Qe, ct, Wt), this.sharedStylesHost = H, this.hostEl = J, this.shadowRoot = J.attachShadow({
            mode: "open"
          }), this.sharedStylesHost.addHost(this.shadowRoot);
          const bn = se(Oe.id, Oe.styles);
          for (const Zn of bn) {
            const yn = document.createElement("style");
            qt && yn.setAttribute("nonce", qt), yn.textContent = Zn, this.shadowRoot.appendChild(yn)
          }
        }
        nodeOrShadowRoot(te) {
          return te === this.hostEl ? this.shadowRoot : te
        }
        appendChild(te, H) {
          return super.appendChild(this.nodeOrShadowRoot(te), H)
        }
        insertBefore(te, H, J) {
          return super.insertBefore(this.nodeOrShadowRoot(te), H, J)
        }
        removeChild(te, H) {
          return super.removeChild(this.nodeOrShadowRoot(te), H)
        }
        parentNode(te) {
          return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(te)))
        }
        destroy() {
          this.sharedStylesHost.removeHost(this.shadowRoot)
        }
      }
      class et extends Be {
        constructor(te, H, J, Oe, Qe, ct, qt, Wt) {
          super(te, Qe, ct, qt), this.sharedStylesHost = H, this.removeStylesOnCompDestroy = Oe, this.styles =
            Wt ? se(Wt, J.styles) : J.styles
        }
        applyStyles() {
          this.sharedStylesHost.addStyles(this.styles)
        }
        destroy() {
          this.removeStylesOnCompDestroy && this.sharedStylesHost.removeStyles(this.styles)
        }
      }
      class Et extends et {
        constructor(te, H, J, Oe, Qe, ct, qt, Wt) {
          const bn = Oe + "-" + J.id;
          super(te, H, J, Qe, ct, qt, Wt, bn), this.contentAttr = function Pe(re) {
            return "_ngcontent-%COMP%".replace(qe, re)
          }(bn), this.hostAttr = function ie(re) {
            return "_nghost-%COMP%".replace(qe, re)
          }(bn)
        }
        applyToHost(te) {
          this.applyStyles(), this.setAttribute(te, this.hostAttr, "")
        }
        createElement(te, H) {
          const J = super.createElement(te, H);
          return super.setAttribute(J, this.contentAttr, ""), J
        }
      }
      let Ht = (() => {
        class re extends le {
          constructor(H) {
            super(H)
          }
          supports(H) {
            return !0
          }
          addEventListener(H, J, Oe) {
            return H.addEventListener(J, Oe, !1), () => this.removeEventListener(H, J, Oe)
          }
          removeEventListener(H, J, Oe) {
            return H.removeEventListener(J, Oe)
          }
          static #e = this.\u0275fac = function(J) {
            return new(J || re)(g.KVO(c.qQ))
          };
          static #t = this.\u0275prov = g.jDH({
            token: re,
            factory: re.\u0275fac
          })
        }
        return re
      })();
      const Zt = ["alt", "control", "meta", "shift"],
        Yn = {
          "\b": "Backspace",
          "\t": "Tab",
          "\x7f": "Delete",
          "\x1b": "Escape",
          Del: "Delete",
          Esc: "Escape",
          Left: "ArrowLeft",
          Right: "ArrowRight",
          Up: "ArrowUp",
          Down: "ArrowDown",
          Menu: "ContextMenu",
          Scroll: "ScrollLock",
          Win: "OS"
        },
        he = {
          alt: re => re.altKey,
          control: re => re.ctrlKey,
          meta: re => re.metaKey,
          shift: re => re.shiftKey
        };
      let ye = (() => {
        class re extends le {
          constructor(H) {
            super(H)
          }
          supports(H) {
            return null != re.parseEventName(H)
          }
          addEventListener(H, J, Oe) {
            const Qe = re.parseEventName(J),
              ct = re.eventCallback(Qe.fullKey, Oe, this.manager.getZone());
            return this.manager.getZone().runOutsideAngular(() => (0, c.QT)().onAndCancel(H, Qe
              .domEventName, ct))
          }
          static parseEventName(H) {
            const J = H.toLowerCase().split("."),
              Oe = J.shift();
            if (0 === J.length || "keydown" !== Oe && "keyup" !== Oe) return null;
            const Qe = re._normalizeKey(J.pop());
            let ct = "",
              qt = J.indexOf("code");
            if (qt > -1 && (J.splice(qt, 1), ct = "code."), Zt.forEach(bn => {
                const Zn = J.indexOf(bn);
                Zn > -1 && (J.splice(Zn, 1), ct += bn + ".")
              }), ct += Qe, 0 != J.length || 0 === Qe.length) return null;
            const Wt = {};
            return Wt.domEventName = Oe, Wt.fullKey = ct, Wt
          }
          static matchEventFullKeyCode(H, J) {
            let Oe = Yn[H.key] || H.key,
              Qe = "";
            return J.indexOf("code.") > -1 && (Oe = H.code, Qe = "code."), !(null == Oe || !Oe) && (Oe = Oe
              .toLowerCase(), " " === Oe ? Oe = "space" : "." === Oe && (Oe = "dot"), Zt.forEach(ct => {
                ct !== Oe && (0, he[ct])(H) && (Qe += ct + ".")
              }), Qe += Oe, Qe === J)
          }
          static eventCallback(H, J, Oe) {
            return Qe => {
              re.matchEventFullKeyCode(Qe, H) && Oe.runGuarded(() => J(Qe))
            }
          }
          static _normalizeKey(H) {
            return "esc" === H ? "escape" : H
          }
          static #e = this.\u0275fac = function(J) {
            return new(J || re)(g.KVO(c.qQ))
          };
          static #t = this.\u0275prov = g.jDH({
            token: re,
            factory: re.\u0275fac
          })
        }
        return re
      })();
      const Ut = (0, g.oH4)(g.fpN, "browser", [{
          provide: g.Agw,
          useValue: c.AJ
        }, {
          provide: g.PLl,
          useValue: function rt() {
            ae.makeCurrent()
          },
          multi: !0
        }, {
          provide: c.qQ,
          useFactory: function ln() {
            return (0, g.TL$)(document), document
          },
          deps: []
        }]),
        nn = new g.nKC(""),
        bt = [{
          provide: g.e01,
          useClass: class V {
            addToWindow(te) {
              g.JZv.getAngularTestability = (J, Oe = !0) => {
                  const Qe = te.findTestabilityInTree(J, Oe);
                  if (null == Qe) throw new g.wOt(5103, !1);
                  return Qe
                }, g.JZv.getAllAngularTestabilities = () => te.getAllTestabilities(), g.JZv
                .getAllAngularRootElements = () => te.getAllRootElements(), g.JZv.frameworkStabilizers || (g
                  .JZv.frameworkStabilizers = []), g.JZv.frameworkStabilizers.push(J => {
                  const Oe = g.JZv.getAllAngularTestabilities();
                  let Qe = Oe.length;
                  const ct = function() {
                    Qe--, 0 == Qe && J()
                  };
                  Oe.forEach(qt => {
                    qt.whenStable(ct)
                  })
                })
            }
            findTestabilityInTree(te, H, J) {
              return null == H ? null : te.getTestability(H) ?? (J ? (0, c.QT)().isShadowRoot(H) ? this
                .findTestabilityInTree(te, H.host, !0) : this.findTestabilityInTree(te, H.parentElement, !
                  0) : null)
            }
          },
          deps: []
        }, {
          provide: g.WHO,
          useClass: g.NYb,
          deps: [g.SKi, g.giA, g.e01]
        }, {
          provide: g.NYb,
          useClass: g.NYb,
          deps: [g.SKi, g.giA, g.e01]
        }],
        Ct = [{
            provide: g.H8p,
            useValue: "root"
          }, {
            provide: g.zcH,
            useFactory: function Nt() {
              return new g.zcH
            },
            deps: []
          }, {
            provide: X,
            useClass: Ht,
            multi: !0,
            deps: [c.qQ, g.SKi, g.Agw]
          }, {
            provide: X,
            useClass: ye,
            multi: !0,
            deps: [c.qQ]
          }, Re, me, U, {
            provide: g._9s,
            useExisting: Re
          }, {
            provide: c.N0,
            useClass: $,
            deps: []
          },
          []
        ];
      let dn = (() => {
          class re {
            constructor(H) {}
            static withServerTransition(H) {
              return {
                ngModule: re,
                providers: [{
                  provide: g.sZ2,
                  useValue: H.appId
                }]
              }
            }
            static #e = this.\u0275fac = function(J) {
              return new(J || re)(g.KVO(nn, 12))
            };
            static #t = this.\u0275mod = g.$C({
              type: re
            });
            static #n = this.\u0275inj = g.G2t({
              providers: [...Ct, ...bt],
              imports: [c.MD, g.Hbi]
            })
          }
          return re
        })(),
        Nn = (() => {
          class re {
            constructor(H) {
              this._doc = H
            }
            getTitle() {
              return this._doc.title
            }
            setTitle(H) {
              this._doc.title = H || ""
            }
            static #e = this.\u0275fac = function(J) {
              return new(J || re)(g.KVO(c.qQ))
            };
            static #t = this.\u0275prov = g.jDH({
              token: re,
              factory: re.\u0275fac,
              providedIn: "root"
            })
          }
          return re
        })(),
        ni = (() => {
          class re {
            static #e = this.\u0275fac = function(J) {
              return new(J || re)
            };
            static #t = this.\u0275prov = g.jDH({
              token: re,
              factory: function(J) {
                let Oe = null;
                return Oe = J ? new(J || re) : g.KVO(dt), Oe
              },
              providedIn: "root"
            })
          }
          return re
        })(),
        dt = (() => {
          class re extends ni {
            constructor(H) {
              super(), this._doc = H
            }
            sanitize(H, J) {
              if (null == J) return null;
              switch (H) {
                case g.WPN.NONE:
                  return J;
                case g.WPN.HTML:
                  return (0, g.ZF7)(J, "HTML") ? (0, g.rcV)(J) : (0, g.h9k)(this._doc, String(J)).toString();
                case g.WPN.STYLE:
                  return (0, g.ZF7)(J, "Style") ? (0, g.rcV)(J) : J;
                case g.WPN.SCRIPT:
                  if ((0, g.ZF7)(J, "Script")) return (0, g.rcV)(J);
                  throw new g.wOt(5200, !1);
                case g.WPN.URL:
                  return (0, g.ZF7)(J, "URL") ? (0, g.rcV)(J) : (0, g.$MX)(String(J));
                case g.WPN.RESOURCE_URL:
                  if ((0, g.ZF7)(J, "ResourceURL")) return (0, g.rcV)(J);
                  throw new g.wOt(5201, !1);
                default:
                  throw new g.wOt(5202, !1)
              }
            }
            bypassSecurityTrustHtml(H) {
              return (0, g.Kcf)(H)
            }
            bypassSecurityTrustStyle(H) {
              return (0, g.cWb)(H)
            }
            bypassSecurityTrustScript(H) {
              return (0, g.UyX)(H)
            }
            bypassSecurityTrustUrl(H) {
              return (0, g.osQ)(H)
            }
            bypassSecurityTrustResourceUrl(H) {
              return (0, g.e5t)(H)
            }
            static #e = this.\u0275fac = function(J) {
              return new(J || re)(g.KVO(c.qQ))
            };
            static #t = this.\u0275prov = g.jDH({
              token: re,
              factory: re.\u0275fac,
              providedIn: "root"
            })
          }
          return re
        })()
    },
    2183: (nt, Se, x) => {
      x.d(Se, {
        nX: () => Lr,
        wF: () => xr,
        Ix: () => ft,
        Wk: () => _n,
        wQ: () => Fn,
        iI: () => Ih,
        n3: () => di
      });
      var g = x(467),
        c = x(4438),
        ee = x(1985),
        ae = x(8071),
        k = x(6648),
        M = x(7673),
        V = x(4412),
        $ = x(3073),
        X = x(3669),
        U = x(6450),
        le = x(9326),
        Ne = x(8496),
        me = x(4360),
        Ae = x(5225);

      function qe(...u) {
        const y = (0, le.lI)(u),
          f = (0, le.ms)(u),
          {
            args: v,
            keys: w
          } = (0, $.D)(u);
        if (0 === v.length) return (0, k.H)([], y);
        const P = new ee.c(function we(u, y, f = X.D) {
          return v => {
            Ve(y, () => {
              const {
                length: w
              } = u, P = new Array(w);
              let G = w,
                ge = w;
              for (let oe = 0; oe < w; oe++) Ve(y, () => {
                const Xe = (0, k.H)(u[oe], y);
                let mt = !1;
                Xe.subscribe((0, me._)(v, Lt => {
                  P[oe] = Lt, mt || (mt = !0, ge--), ge || v.next(f(P.slice()))
                }, () => {
                  --G || v.complete()
                }))
              }, v)
            }, v)
          }
        }(v, y, w ? G => (0, Ne.e)(w, G) : X.D));
        return f ? P.pipe((0, U.I)(f)) : P
      }

      function Ve(u, y, f) {
        u ? (0, Ae.N)(f, u, y) : y()
      }
      const vt = (0, x(1853).L)(u => function() {
        u(this), this.name = "EmptyError", this.message = "no elements in sequence"
      });
      var ue = x(1397);

      function Pe(u = 1 / 0) {
        return (0, ue.Z)(X.D, u)
      }

      function se(...u) {
        return function ie() {
          return Pe(1)
        }()((0, k.H)(u, (0, le.lI)(u)))
      }
      var Re = x(8750);

      function Be(u) {
        return new ee.c(y => {
          (0, Re.Tg)(u()).subscribe(y)
        })
      }
      var De = x(1203),
        Z = x(8810);
      const xe = new ee.c(u => u.complete());
      var Et = x(8359),
        Ht = x(9974);

      function Zt() {
        return (0, Ht.N)((u, y) => {
          let f = null;
          u._refCount++;
          const v = (0, me._)(y, void 0, void 0, void 0, () => {
            if (!u || u._refCount <= 0 || 0 < --u._refCount) return void(f = null);
            const w = u._connection,
              P = f;
            f = null, w && (!P || w === P) && w.unsubscribe(), y.unsubscribe()
          });
          u.subscribe(v), v.closed || (f = u.connect())
        })
      }
      class Yn extends ee.c {
        constructor(y, f) {
          super(), this.source = y, this.subjectFactory = f, this._subject = null, this._refCount = 0, this
            ._connection = null, (0, Ht.S)(y) && (this.lift = y.lift)
        }
        _subscribe(y) {
          return this.getSubject().subscribe(y)
        }
        getSubject() {
          const y = this._subject;
          return (!y || y.isStopped) && (this._subject = this.subjectFactory()), this._subject
        }
        _teardown() {
          this._refCount = 0;
          const {
            _connection: y
          } = this;
          this._subject = this._connection = null, y?.unsubscribe()
        }
        connect() {
          let y = this._connection;
          if (!y) {
            y = this._connection = new Et.yU;
            const f = this.getSubject();
            y.add(this.source.subscribe((0, me._)(f, void 0, () => {
              this._teardown(), f.complete()
            }, v => {
              this._teardown(), f.error(v)
            }, () => this._teardown()))), y.closed && (this._connection = null, y = Et.yU.EMPTY)
          }
          return y
        }
        refCount() {
          return Zt()(this)
        }
      }
      var he = x(1413),
        ye = x(177),
        ve = x(6354),
        Ce = x(5558);

      function ke(u) {
        return u <= 0 ? () => xe : (0, Ht.N)((y, f) => {
          let v = 0;
          y.subscribe((0, me._)(f, w => {
            ++v <= u && (f.next(w), u <= v && f.complete())
          }))
        })
      }
      var rt = x(5964);

      function Nt(u) {
        return (0, Ht.N)((y, f) => {
          let v = !1;
          y.subscribe((0, me._)(f, w => {
            v = !0, f.next(w)
          }, () => {
            v || f.next(u), f.complete()
          }))
        })
      }

      function ln(u = ht) {
        return (0, Ht.N)((y, f) => {
          let v = !1;
          y.subscribe((0, me._)(f, w => {
            v = !0, f.next(w)
          }, () => v ? f.complete() : f.error(u())))
        })
      }

      function ht() {
        return new vt
      }

      function Ut(u, y) {
        const f = arguments.length >= 2;
        return v => v.pipe(u ? (0, rt.p)((w, P) => u(w, P, v)) : X.D, ke(1), f ? Nt(y) : ln(() => new vt))
      }
      var nn = x(274),
        bt = x(8141),
        Ct = x(9437);

      function rn(u) {
        return u <= 0 ? () => xe : (0, Ht.N)((y, f) => {
          let v = [];
          y.subscribe((0, me._)(f, w => {
            v.push(w), u < v.length && v.shift()
          }, () => {
            for (const w of v) f.next(w);
            f.complete()
          }, void 0, () => {
            v = null
          }))
        })
      }
      var zn = x(980),
        yr = x(5343),
        ti = x(345);
      const St = "primary",
        jn = Symbol("RouteTitle");
      class Tt {
        constructor(y) {
          this.params = y || {}
        }
        has(y) {
          return Object.prototype.hasOwnProperty.call(this.params, y)
        }
        get(y) {
          if (this.has(y)) {
            const f = this.params[y];
            return Array.isArray(f) ? f[0] : f
          }
          return null
        }
        getAll(y) {
          if (this.has(y)) {
            const f = this.params[y];
            return Array.isArray(f) ? f : [f]
          }
          return []
        }
        get keys() {
          return Object.keys(this.params)
        }
      }

      function It(u) {
        return new Tt(u)
      }

      function zr(u, y, f) {
        const v = f.path.split("/");
        if (v.length > u.length || "full" === f.pathMatch && (y.hasChildren() || v.length < u.length))
      return null;
        const w = {};
        for (let P = 0; P < v.length; P++) {
          const G = v[P],
            ge = u[P];
          if (G.startsWith(":")) w[G.substring(1)] = ge;
          else if (G !== ge.path) return null
        }
        return {
          consumed: u.slice(0, v.length),
          posParams: w
        }
      }

      function mn(u, y) {
        const f = u ? Pr(u) : void 0,
          v = y ? Pr(y) : void 0;
        if (!f || !v || f.length != v.length) return !1;
        let w;
        for (let P = 0; P < f.length; P++)
          if (w = f[P], !Mn(u[w], y[w])) return !1;
        return !0
      }

      function Pr(u) {
        return [...Object.keys(u), ...Object.getOwnPropertySymbols(u)]
      }

      function Mn(u, y) {
        if (Array.isArray(u) && Array.isArray(y)) {
          if (u.length !== y.length) return !1;
          const f = [...u].sort(),
            v = [...y].sort();
          return f.every((w, P) => v[P] === w)
        }
        return u === y
      }

      function ni(u) {
        return u.length > 0 ? u[u.length - 1] : null
      }

      function dt(u) {
        return function A(u) {
          return !!u && (u instanceof ee.c || (0, ae.T)(u.lift) && (0, ae.T)(u.subscribe))
        }(u) ? u : (0, c.jNT)(u) ? (0, k.H)(Promise.resolve(u)) : (0, M.of)(u)
      }
      const Kr = {
          exact: function Jt(u, y, f) {
            if (!Oe(u.segments, y.segments) || !qn(u.segments, y.segments, f) || u.numberOfChildren !== y
              .numberOfChildren) return !1;
            for (const v in y.children)
              if (!u.children[v] || !Jt(u.children[v], y.children[v], f)) return !1;
            return !0
          },
          subset: ri
        },
        zt = {
          exact: function _r(u, y) {
            return mn(u, y)
          },
          subset: function Kn(u, y) {
            return Object.keys(y).length <= Object.keys(u).length && Object.keys(y).every(f => Mn(u[f], y[f]))
          },
          ignored: () => !0
        };

      function Pt(u, y, f) {
        return Kr[f.paths](u.root, y.root, f.matrixParams) && zt[f.queryParams](u.queryParams, y.queryParams) && !
          ("exact" === f.fragment && u.fragment !== y.fragment)
      }

      function ri(u, y, f) {
        return Di(u, y, y.segments, f)
      }

      function Di(u, y, f, v) {
        if (u.segments.length > f.length) {
          const w = u.segments.slice(0, f.length);
          return !(!Oe(w, f) || y.hasChildren() || !qn(w, f, v))
        }
        if (u.segments.length === f.length) {
          if (!Oe(u.segments, f) || !qn(u.segments, f, v)) return !1;
          for (const w in y.children)
            if (!u.children[w] || !ri(u.children[w], y.children[w], v)) return !1;
          return !0
        } {
          const w = f.slice(0, u.segments.length),
            P = f.slice(u.segments.length);
          return !!(Oe(u.segments, w) && qn(u.segments, w, v) && u.children[St]) && Di(u.children[St], y, P, v)
        }
      }

      function qn(u, y, f) {
        return y.every((v, w) => zt[f](u[w].parameters, v.parameters))
      }
      class re {
        constructor(y = new te([], {}), f = {}, v = null) {
          this.root = y, this.queryParams = f, this.fragment = v
        }
        get queryParamMap() {
          return this._queryParamMap ??= It(this.queryParams), this._queryParamMap
        }
        toString() {
          return Wt.serialize(this)
        }
      }
      class te {
        constructor(y, f) {
          this.segments = y, this.children = f, this.parent = null, Object.values(f).forEach(v => v.parent =
            this)
        }
        hasChildren() {
          return this.numberOfChildren > 0
        }
        get numberOfChildren() {
          return Object.keys(this.children).length
        }
        toString() {
          return bn(this)
        }
      }
      class H {
        constructor(y, f) {
          this.path = y, this.parameters = f
        }
        get parameterMap() {
          return this._parameterMap ??= It(this.parameters), this._parameterMap
        }
        toString() {
          return Gi(this)
        }
      }

      function Oe(u, y) {
        return u.length === y.length && u.every((f, v) => f.path === y[v].path)
      }
      let ct = (() => {
        class u {
          static #e = this.\u0275fac = function(v) {
            return new(v || u)
          };
          static #t = this.\u0275prov = c.jDH({
            token: u,
            factory: () => new qt,
            providedIn: "root"
          })
        }
        return u
      })();
      class qt {
        parse(y) {
          const f = new ai(y);
          return new re(f.parseRootSegment(), f.parseQueryParams(), f.parseFragment())
        }
        serialize(y) {
          const f = `/${Zn(y.root,!0)}`,
            v = function ii(u) {
              const y = Object.entries(u).map(([f, v]) => Array.isArray(v) ? v.map(w => `${lr(f)}=${lr(w)}`)
                .join("&") : `${lr(f)}=${lr(v)}`).filter(f => f);
              return y.length ? `?${y.join("&")}` : ""
            }(y.queryParams);
          return `${f}${v}${"string"==typeof y.fragment?`#${function cr(u){return encodeURI(u)}(y.fragment)}`:""}`
        }
      }
      const Wt = new qt;

      function bn(u) {
        return u.segments.map(y => Gi(y)).join("/")
      }

      function Zn(u, y) {
        if (!u.hasChildren()) return bn(u);
        if (y) {
          const f = u.children[St] ? Zn(u.children[St], !1) : "",
            v = [];
          return Object.entries(u.children).forEach(([w, P]) => {
            w !== St && v.push(`${w}:${Zn(P,!1)}`)
          }), v.length > 0 ? `${f}(${v.join("//")})` : f
        } {
          const f = function Qe(u, y) {
            let f = [];
            return Object.entries(u.children).forEach(([v, w]) => {
              v === St && (f = f.concat(y(w, v)))
            }), Object.entries(u.children).forEach(([v, w]) => {
              v !== St && (f = f.concat(y(w, v)))
            }), f
          }(u, (v, w) => w === St ? [Zn(u.children[St], !1)] : [`${w}:${Zn(v,!1)}`]);
          return 1 === Object.keys(u.children).length && null != u.children[St] ? `${bn(u)}/${f[0]}` :
            `${bn(u)}/(${f.join("//")})`
        }
      }

      function yn(u) {
        return encodeURIComponent(u).replace(/%40/g, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(
          /%2C/gi, ",")
      }

      function lr(u) {
        return yn(u).replace(/%3B/gi, ";")
      }

      function qr(u) {
        return yn(u).replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/%26/gi, "&")
      }

      function fn(u) {
        return decodeURIComponent(u)
      }

      function at(u) {
        return fn(u.replace(/\+/g, "%20"))
      }

      function Gi(u) {
        return `${qr(u.path)}${function Qr(u){return Object.entries(u).map(([y,f])=>`;${qr(y)}=${qr(f)}`).join("")}(u.parameters)}`
      }
      const bs = /^[^\/()?;#]+/;

      function Vr(u) {
        const y = u.match(bs);
        return y ? y[0] : ""
      }
      const Gt = /^[^\/()?;=#]+/,
        si = /^[^=?&#]+/,
        Ni = /^[^&#]+/;
      class ai {
        constructor(y) {
          this.url = y, this.remaining = y
        }
        parseRootSegment() {
          return this.consumeOptional("/"), "" === this.remaining || this.peekStartsWith("?") || this
            .peekStartsWith("#") ? new te([], {}) : new te([], this.parseChildren())
        }
        parseQueryParams() {
          const y = {};
          if (this.consumeOptional("?"))
            do {
              this.parseQueryParam(y)
            } while (this.consumeOptional("&"));
          return y
        }
        parseFragment() {
          return this.consumeOptional("#") ? decodeURIComponent(this.remaining) : null
        }
        parseChildren() {
          if ("" === this.remaining) return {};
          this.consumeOptional("/");
          const y = [];
          for (this.peekStartsWith("(") || y.push(this.parseSegment()); this.peekStartsWith("/") && !this
            .peekStartsWith("//") && !this.peekStartsWith("/(");) this.capture("/"), y.push(this
        .parseSegment());
          let f = {};
          this.peekStartsWith("/(") && (this.capture("/"), f = this.parseParens(!0));
          let v = {};
          return this.peekStartsWith("(") && (v = this.parseParens(!1)), (y.length > 0 || Object.keys(f)
            .length > 0) && (v[St] = new te(y, f)), v
        }
        parseSegment() {
          const y = Vr(this.remaining);
          if ("" === y && this.peekStartsWith(";")) throw new c.wOt(4009, !1);
          return this.capture(y), new H(fn(y), this.parseMatrixParams())
        }
        parseMatrixParams() {
          const y = {};
          for (; this.consumeOptional(";");) this.parseParam(y);
          return y
        }
        parseParam(y) {
          const f = function zi(u) {
            const y = u.match(Gt);
            return y ? y[0] : ""
          }(this.remaining);
          if (!f) return;
          this.capture(f);
          let v = "";
          if (this.consumeOptional("=")) {
            const w = Vr(this.remaining);
            w && (v = w, this.capture(v))
          }
          y[fn(f)] = fn(v)
        }
        parseQueryParam(y) {
          const f = function oi(u) {
            const y = u.match(si);
            return y ? y[0] : ""
          }(this.remaining);
          if (!f) return;
          this.capture(f);
          let v = "";
          if (this.consumeOptional("=")) {
            const G = function Ei(u) {
              const y = u.match(Ni);
              return y ? y[0] : ""
            }(this.remaining);
            G && (v = G, this.capture(v))
          }
          const w = at(f),
            P = at(v);
          if (y.hasOwnProperty(w)) {
            let G = y[w];
            Array.isArray(G) || (G = [G], y[w] = G), G.push(P)
          } else y[w] = P
        }
        parseParens(y) {
          const f = {};
          for (this.capture("("); !this.consumeOptional(")") && this.remaining.length > 0;) {
            const v = Vr(this.remaining),
              w = this.remaining[v.length];
            if ("/" !== w && ")" !== w && ";" !== w) throw new c.wOt(4010, !1);
            let P;
            v.indexOf(":") > -1 ? (P = v.slice(0, v.indexOf(":")), this.capture(P), this.capture(":")) : y && (
              P = St);
            const G = this.parseChildren();
            f[P] = 1 === Object.keys(G).length ? G[St] : new te([], G), this.consumeOptional("//")
          }
          return f
        }
        peekStartsWith(y) {
          return this.remaining.startsWith(y)
        }
        consumeOptional(y) {
          return !!this.peekStartsWith(y) && (this.remaining = this.remaining.substring(y.length), !0)
        }
        capture(y) {
          if (!this.consumeOptional(y)) throw new c.wOt(4011, !1)
        }
      }

      function Xr(u) {
        return u.segments.length > 0 ? new te([], {
          [St]: u
        }) : u
      }

      function B(u) {
        const y = {};
        for (const [v, w] of Object.entries(u.children)) {
          const P = B(w);
          if (v === St && 0 === P.segments.length && P.hasChildren())
            for (const [G, ge] of Object.entries(P.children)) y[G] = ge;
          else(P.segments.length > 0 || P.hasChildren()) && (y[v] = P)
        }
        return function z(u) {
          if (1 === u.numberOfChildren && u.children[St]) {
            const y = u.children[St];
            return new te(u.segments.concat(y.segments), y.children)
          }
          return u
        }(new te(u.segments, y))
      }

      function K(u) {
        return u instanceof re
      }

      function pe(u) {
        let y;
        const w = Xr(function f(P) {
          const G = {};
          for (const oe of P.children) {
            const Xe = f(oe);
            G[oe.outlet] = Xe
          }
          const ge = new te(P.url, G);
          return P === u && (y = ge), ge
        }(u.root));
        return y ?? w
      }

      function je(u, y, f, v) {
        let w = u;
        for (; w.parent;) w = w.parent;
        if (0 === y.length) return it(w, w, w, f, v);
        const P = function Ft(u) {
          if ("string" == typeof u[0] && 1 === u.length && "/" === u[0]) return new Xt(!0, 0, u);
          let y = 0,
            f = !1;
          const v = u.reduce((w, P, G) => {
            if ("object" == typeof P && null != P) {
              if (P.outlets) {
                const ge = {};
                return Object.entries(P.outlets).forEach(([oe, Xe]) => {
                  ge[oe] = "string" == typeof Xe ? Xe.split("/") : Xe
                }), [...w, {
                  outlets: ge
                }]
              }
              if (P.segmentPath) return [...w, P.segmentPath]
            }
            return "string" != typeof P ? [...w, P] : 0 === G ? (P.split("/").forEach((ge, oe) => {
              0 == oe && "." === ge || (0 == oe && "" === ge ? f = !0 : ".." === ge ? y++ : "" !=
                ge && w.push(ge))
            }), w) : [...w, P]
          }, []);
          return new Xt(f, y, v)
        }(y);
        if (P.toRoot()) return it(w, w, new te([], {}), f, v);
        const G = function ur(u, y, f) {
            if (u.isAbsolute) return new sn(y, !0, 0);
            if (!f) return new sn(y, !1, NaN);
            if (null === f.parent) return new sn(f, !0, 0);
            const v = He(u.commands[0]) ? 0 : 1;
            return function Rn(u, y, f) {
              let v = u,
                w = y,
                P = f;
              for (; P > w;) {
                if (P -= w, v = v.parent, !v) throw new c.wOt(4005, !1);
                w = v.segments.length
              }
              return new sn(v, !1, w - P)
            }(f, f.segments.length - 1 + v, u.numberOfDoubleDots)
          }(P, w, u),
          ge = G.processChildren ? Dn(G.segmentGroup, G.index, P.commands) : kt(G.segmentGroup, G.index, P
            .commands);
        return it(w, G.segmentGroup, ge, f, v)
      }

      function He(u) {
        return "object" == typeof u && null != u && !u.outlets && !u.segmentPath
      }

      function _t(u) {
        return "object" == typeof u && null != u && u.outlets
      }

      function it(u, y, f, v, w) {
        let G, P = {};
        v && Object.entries(v).forEach(([oe, Xe]) => {
          P[oe] = Array.isArray(Xe) ? Xe.map(mt => `${mt}`) : `${Xe}`
        }), G = u === y ? f : Qt(u, y, f);
        const ge = Xr(B(G));
        return new re(ge, P, w)
      }

      function Qt(u, y, f) {
        const v = {};
        return Object.entries(u.children).forEach(([w, P]) => {
          v[w] = P === y ? f : Qt(P, y, f)
        }), new te(u.segments, v)
      }
      class Xt {
        constructor(y, f, v) {
          if (this.isAbsolute = y, this.numberOfDoubleDots = f, this.commands = v, y && v.length > 0 && He(v[
            0])) throw new c.wOt(4003, !1);
          const w = v.find(_t);
          if (w && w !== ni(v)) throw new c.wOt(4004, !1)
        }
        toRoot() {
          return this.isAbsolute && 1 === this.commands.length && "/" == this.commands[0]
        }
      }
      class sn {
        constructor(y, f, v) {
          this.segmentGroup = y, this.processChildren = f, this.index = v
        }
      }

      function kt(u, y, f) {
        if (u ??= new te([], {}), 0 === u.segments.length && u.hasChildren()) return Dn(u, y, f);
        const v = function Dr(u, y, f) {
            let v = 0,
              w = y;
            const P = {
              match: !1,
              pathIndex: 0,
              commandIndex: 0
            };
            for (; w < u.segments.length;) {
              if (v >= f.length) return P;
              const G = u.segments[w],
                ge = f[v];
              if (_t(ge)) break;
              const oe = `${ge}`,
                Xe = v < f.length - 1 ? f[v + 1] : null;
              if (w > 0 && void 0 === oe) break;
              if (oe && Xe && "object" == typeof Xe && void 0 === Xe.outlets) {
                if (!gn(oe, Xe, G)) return P;
                v += 2
              } else {
                if (!gn(oe, {}, G)) return P;
                v++
              }
              w++
            }
            return {
              match: !0,
              pathIndex: w,
              commandIndex: v
            }
          }(u, y, f),
          w = f.slice(v.commandIndex);
        if (v.match && v.pathIndex < u.segments.length) {
          const P = new te(u.segments.slice(0, v.pathIndex), {});
          return P.children[St] = new te(u.segments.slice(v.pathIndex), u.children), Dn(P, 0, w)
        }
        return v.match && 0 === w.length ? new te(u.segments, {}) : v.match && !u.hasChildren() ? wn(u, y, f) : v
          .match ? Dn(u, 0, w) : wn(u, y, f)
      }

      function Dn(u, y, f) {
        if (0 === f.length) return new te(u.segments, {});
        {
          const v = function jt(u) {
              return _t(u[0]) ? u[0].outlets : {
                [St]: u
              }
            }(f),
            w = {};
          if (Object.keys(v).some(P => P !== St) && u.children[St] && 1 === u.numberOfChildren && 0 === u
            .children[St].segments.length) {
            const P = Dn(u.children[St], y, f);
            return new te(u.segments, P.children)
          }
          return Object.entries(v).forEach(([P, G]) => {
            "string" == typeof G && (G = [G]), null !== G && (w[P] = kt(u.children[P], y, G))
          }), Object.entries(u.children).forEach(([P, G]) => {
            void 0 === v[P] && (w[P] = G)
          }), new te(u.segments, w)
        }
      }

      function wn(u, y, f) {
        const v = u.segments.slice(0, y);
        let w = 0;
        for (; w < f.length;) {
          const P = f[w];
          if (_t(P)) {
            const oe = Hn(P.outlets);
            return new te(v, oe)
          }
          if (0 === w && He(f[0])) {
            v.push(new H(u.segments[y].path, dr(f[0]))), w++;
            continue
          }
          const G = _t(P) ? P.outlets[St] : `${P}`,
            ge = w < f.length - 1 ? f[w + 1] : null;
          G && ge && He(ge) ? (v.push(new H(G, dr(ge))), w += 2) : (v.push(new H(G, {})), w++)
        }
        return new te(v, {})
      }

      function Hn(u) {
        const y = {};
        return Object.entries(u).forEach(([f, v]) => {
          "string" == typeof v && (v = [v]), null !== v && (y[f] = wn(new te([], {}), 0, v))
        }), y
      }

      function dr(u) {
        const y = {};
        return Object.entries(u).forEach(([f, v]) => y[f] = `${v}`), y
      }

      function gn(u, y, f) {
        return u == f.path && mn(y, f.parameters)
      }
      const lt = "imperative";
      var Ye = function(u) {
        return u[u.NavigationStart = 0] = "NavigationStart", u[u.NavigationEnd = 1] = "NavigationEnd", u[u
            .NavigationCancel = 2] = "NavigationCancel", u[u.NavigationError = 3] = "NavigationError", u[u
            .RoutesRecognized = 4] = "RoutesRecognized", u[u.ResolveStart = 5] = "ResolveStart", u[u
            .ResolveEnd = 6] = "ResolveEnd", u[u.GuardsCheckStart = 7] = "GuardsCheckStart", u[u
            .GuardsCheckEnd = 8] = "GuardsCheckEnd", u[u.RouteConfigLoadStart = 9] = "RouteConfigLoadStart", u[u
            .RouteConfigLoadEnd = 10] = "RouteConfigLoadEnd", u[u.ChildActivationStart = 11] =
          "ChildActivationStart", u[u.ChildActivationEnd = 12] = "ChildActivationEnd", u[u.ActivationStart =
          13] = "ActivationStart", u[u.ActivationEnd = 14] = "ActivationEnd", u[u.Scroll = 15] = "Scroll", u[u
            .NavigationSkipped = 16] = "NavigationSkipped", u
      }(Ye || {});
      class Fr {
        constructor(y, f) {
          this.id = y, this.url = f
        }
      }
      class Jn extends Fr {
        constructor(y, f, v = "imperative", w = null) {
          super(y, f), this.type = Ye.NavigationStart, this.navigationTrigger = v, this.restoredState = w
        }
        toString() {
          return `NavigationStart(id: ${this.id}, url: '${this.url}')`
        }
      }
      class xr extends Fr {
        constructor(y, f, v) {
          super(y, f), this.urlAfterRedirects = v, this.type = Ye.NavigationEnd
        }
        toString() {
          return `NavigationEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}')`
        }
      }
      var Er = function(u) {
          return u[u.Redirect = 0] = "Redirect", u[u.SupersededByNewNavigation = 1] = "SupersededByNewNavigation",
            u[u.NoDataFromResolver = 2] = "NoDataFromResolver", u[u.GuardRejected = 3] = "GuardRejected", u
        }(Er || {}),
        ws = function(u) {
          return u[u.IgnoredSameUrlNavigation = 0] = "IgnoredSameUrlNavigation", u[u
            .IgnoredByUrlHandlingStrategy = 1] = "IgnoredByUrlHandlingStrategy", u
        }(ws || {});
      class li extends Fr {
        constructor(y, f, v, w) {
          super(y, f), this.reason = v, this.code = w, this.type = Ye.NavigationCancel
        }
        toString() {
          return `NavigationCancel(id: ${this.id}, url: '${this.url}')`
        }
      }
      class At extends Fr {
        constructor(y, f, v, w) {
          super(y, f), this.reason = v, this.code = w, this.type = Ye.NavigationSkipped
        }
      }
      class Br extends Fr {
        constructor(y, f, v, w) {
          super(y, f), this.error = v, this.target = w, this.type = Ye.NavigationError
        }
        toString() {
          return `NavigationError(id: ${this.id}, url: '${this.url}', error: ${this.error})`
        }
      }
      class Ki extends Fr {
        constructor(y, f, v, w) {
          super(y, f), this.urlAfterRedirects = v, this.state = w, this.type = Ye.RoutesRecognized
        }
        toString() {
          return `RoutesRecognized(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
        }
      }
      class Vn extends Fr {
        constructor(y, f, v, w) {
          super(y, f), this.urlAfterRedirects = v, this.state = w, this.type = Ye.GuardsCheckStart
        }
        toString() {
          return `GuardsCheckStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
        }
      }
      class Ss extends Fr {
        constructor(y, f, v, w, P) {
          super(y, f), this.urlAfterRedirects = v, this.state = w, this.shouldActivate = P, this.type = Ye
            .GuardsCheckEnd
        }
        toString() {
          return `GuardsCheckEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state}, shouldActivate: ${this.shouldActivate})`
        }
      }
      class qi extends Fr {
        constructor(y, f, v, w) {
          super(y, f), this.urlAfterRedirects = v, this.state = w, this.type = Ye.ResolveStart
        }
        toString() {
          return `ResolveStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
        }
      }
      class rs extends Fr {
        constructor(y, f, v, w) {
          super(y, f), this.urlAfterRedirects = v, this.state = w, this.type = Ye.ResolveEnd
        }
        toString() {
          return `ResolveEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
        }
      }
      class Ur {
        constructor(y) {
          this.route = y, this.type = Ye.RouteConfigLoadStart
        }
        toString() {
          return `RouteConfigLoadStart(path: ${this.route.path})`
        }
      }
      class Qi {
        constructor(y) {
          this.route = y, this.type = Ye.RouteConfigLoadEnd
        }
        toString() {
          return `RouteConfigLoadEnd(path: ${this.route.path})`
        }
      }
      class Ci {
        constructor(y) {
          this.snapshot = y, this.type = Ye.ChildActivationStart
        }
        toString() {
          return `ChildActivationStart(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
        }
      }
      class is {
        constructor(y) {
          this.snapshot = y, this.type = Ye.ChildActivationEnd
        }
        toString() {
          return `ChildActivationEnd(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
        }
      }
      class Xi {
        constructor(y) {
          this.snapshot = y, this.type = Ye.ActivationStart
        }
        toString() {
          return `ActivationStart(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
        }
      }
      class Is {
        constructor(y) {
          this.snapshot = y, this.type = Ye.ActivationEnd
        }
        toString() {
          return `ActivationEnd(path: '${this.snapshot.routeConfig&&this.snapshot.routeConfig.path||""}')`
        }
      }
      class ss {
        constructor(y, f, v) {
          this.routerEvent = y, this.position = f, this.anchor = v, this.type = Ye.Scroll
        }
        toString() {
          return `Scroll(anchor: '${this.anchor}', position: '${this.position?`${this.position[0]}, ${this.position[1]}`:null}')`
        }
      }
      class Cr {}
      class Yi {
        constructor(y) {
          this.url = y
        }
      }
      class zs {
        constructor() {
          this.outlet = null, this.route = null, this.injector = null, this.children = new en, this.attachRef =
            null
        }
      }
      let en = (() => {
        class u {
          constructor() {
            this.contexts = new Map
          }
          onChildOutletCreated(f, v) {
            const w = this.getOrCreateContext(f);
            w.outlet = v, this.contexts.set(f, w)
          }
          onChildOutletDestroyed(f) {
            const v = this.getContext(f);
            v && (v.outlet = null, v.attachRef = null)
          }
          onOutletDeactivated() {
            const f = this.contexts;
            return this.contexts = new Map, f
          }
          onOutletReAttached(f) {
            this.contexts = f
          }
          getOrCreateContext(f) {
            let v = this.getContext(f);
            return v || (v = new zs, this.contexts.set(f, v)), v
          }
          getContext(f) {
            return this.contexts.get(f) || null
          }
          static #e = this.\u0275fac = function(v) {
            return new(v || u)
          };
          static #t = this.\u0275prov = c.jDH({
            token: u,
            factory: u.\u0275fac,
            providedIn: "root"
          })
        }
        return u
      })();
      class ci {
        constructor(y) {
          this._root = y
        }
        get root() {
          return this._root.value
        }
        parent(y) {
          const f = this.pathFromRoot(y);
          return f.length > 1 ? f[f.length - 2] : null
        }
        children(y) {
          const f = pt(y, this._root);
          return f ? f.children.map(v => v.value) : []
        }
        firstChild(y) {
          const f = pt(y, this._root);
          return f && f.children.length > 0 ? f.children[0].value : null
        }
        siblings(y) {
          const f = jr(y, this._root);
          return f.length < 2 ? [] : f[f.length - 2].children.map(w => w.value).filter(w => w !== y)
        }
        pathFromRoot(y) {
          return jr(y, this._root).map(f => f.value)
        }
      }

      function pt(u, y) {
        if (u === y.value) return y;
        for (const f of y.children) {
          const v = pt(u, f);
          if (v) return v
        }
        return null
      }

      function jr(u, y) {
        if (u === y.value) return [y];
        for (const f of y.children) {
          const v = jr(u, f);
          if (v.length) return v.unshift(y), v
        }
        return []
      }
      class fr {
        constructor(y, f) {
          this.value = y, this.children = f
        }
        toString() {
          return `TreeNode(${this.value})`
        }
      }

      function Hr(u) {
        const y = {};
        return u && u.children.forEach(f => y[f.value.outlet] = f), y
      }
      class Ri extends ci {
        constructor(y, f) {
          super(y), this.snapshot = f, Pi(this, y)
        }
        toString() {
          return this.snapshot.toString()
        }
      }

      function Ms(u) {
        const y = function Ts(u) {
            const P = new bi([], {}, {}, "", {}, St, u, null, {});
            return new ui("", new fr(P, []))
          }(u),
          f = new V.t([new H("", {})]),
          v = new V.t({}),
          w = new V.t({}),
          P = new V.t({}),
          G = new V.t(""),
          ge = new Lr(f, v, P, G, w, St, u, y.root);
        return ge.snapshot = y.root, new Ri(new fr(ge, []), y)
      }
      class Lr {
        constructor(y, f, v, w, P, G, ge, oe) {
          this.urlSubject = y, this.paramsSubject = f, this.queryParamsSubject = v, this.fragmentSubject = w,
            this.dataSubject = P, this.outlet = G, this.component = ge, this._futureSnapshot = oe, this.title =
            this.dataSubject?.pipe((0, ve.T)(Xe => Xe[jn])) ?? (0, M.of)(void 0), this.url = y, this.params = f,
            this.queryParams = v, this.fragment = w, this.data = P
        }
        get routeConfig() {
          return this._futureSnapshot.routeConfig
        }
        get root() {
          return this._routerState.root
        }
        get parent() {
          return this._routerState.parent(this)
        }
        get firstChild() {
          return this._routerState.firstChild(this)
        }
        get children() {
          return this._routerState.children(this)
        }
        get pathFromRoot() {
          return this._routerState.pathFromRoot(this)
        }
        get paramMap() {
          return this._paramMap ??= this.params.pipe((0, ve.T)(y => It(y))), this._paramMap
        }
        get queryParamMap() {
          return this._queryParamMap ??= this.queryParams.pipe((0, ve.T)(y => It(y))), this._queryParamMap
        }
        toString() {
          return this.snapshot ? this.snapshot.toString() : `Future(${this._futureSnapshot})`
        }
      }

      function er(u, y, f = "emptyOnly") {
        let v;
        const {
          routeConfig: w
        } = u;
        return v = null === y || "always" !== f && "" !== w?.path && (y.component || y.routeConfig
          ?.loadComponent) ? {
            params: {
              ...u.params
            },
            data: {
              ...u.data
            },
            resolve: {
              ...u.data,
              ...u._resolvedData ?? {}
            }
          } : {
            params: {
              ...y.params,
              ...u.params
            },
            data: {
              ...y.data,
              ...u.data
            },
            resolve: {
              ...u.data,
              ...y.data,
              ...w?.data,
              ...u._resolvedData
            }
          }, w && br(w) && (v.resolve[jn] = w.title), v
      }
      class bi {
        get title() {
          return this.data?.[jn]
        }
        constructor(y, f, v, w, P, G, ge, oe, Xe) {
          this.url = y, this.params = f, this.queryParams = v, this.fragment = w, this.data = P, this.outlet =
            G, this.component = ge, this.routeConfig = oe, this._resolve = Xe
        }
        get root() {
          return this._routerState.root
        }
        get parent() {
          return this._routerState.parent(this)
        }
        get firstChild() {
          return this._routerState.firstChild(this)
        }
        get children() {
          return this._routerState.children(this)
        }
        get pathFromRoot() {
          return this._routerState.pathFromRoot(this)
        }
        get paramMap() {
          return this._paramMap ??= It(this.params), this._paramMap
        }
        get queryParamMap() {
          return this._queryParamMap ??= It(this.queryParams), this._queryParamMap
        }
        toString() {
          return `Route(url:'${this.url.map(v=>v.toString()).join("/")}', path:'${this.routeConfig?this.routeConfig.path:""}')`
        }
      }
      class ui extends ci {
        constructor(y, f) {
          super(f), this.url = y, Pi(this, f)
        }
        toString() {
          return Zr(this._root)
        }
      }

      function Pi(u, y) {
        y.value._routerState = u, y.children.forEach(f => Pi(u, f))
      }

      function Zr(u) {
        const y = u.children.length > 0 ? ` { ${u.children.map(Zr).join(", ")} } ` : "";
        return `${u.value}${y}`
      }

      function Zi(u) {
        if (u.snapshot) {
          const y = u.snapshot,
            f = u._futureSnapshot;
          u.snapshot = f, mn(y.queryParams, f.queryParams) || u.queryParamsSubject.next(f.queryParams), y
            .fragment !== f.fragment && u.fragmentSubject.next(f.fragment), mn(y.params, f.params) || u
            .paramsSubject.next(f.params),
            function vr(u, y) {
              if (u.length !== y.length) return !1;
              for (let f = 0; f < u.length; ++f)
                if (!mn(u[f], y[f])) return !1;
              return !0
            }(y.url, f.url) || u.urlSubject.next(f.url), mn(y.data, f.data) || u.dataSubject.next(f.data)
        } else u.snapshot = u._futureSnapshot, u.dataSubject.next(u._futureSnapshot.data)
      }

      function Bn(u, y) {
        const f = mn(u.params, y.params) && function J(u, y) {
          return Oe(u, y) && u.every((f, v) => mn(f.parameters, y[v].parameters))
        }(u.url, y.url);
        return f && !(!u.parent != !y.parent) && (!u.parent || Bn(u.parent, y.parent))
      }

      function br(u) {
        return "string" == typeof u.title || null === u.title
      }
      let di = (() => {
        class u {
          constructor() {
            this.activated = null, this._activatedRoute = null, this.name = St, this.activateEvents = new c
              .bkB, this.deactivateEvents = new c.bkB, this.attachEvents = new c.bkB, this.detachEvents =
              new c.bkB, this.parentContexts = (0, c.WQX)(en), this.location = (0, c.WQX)(c.c1b), this
              .changeDetector = (0, c.WQX)(c.gRc), this.environmentInjector = (0, c.WQX)(c.uvJ), this
              .inputBinder = (0, c.WQX)(kr, {
                optional: !0
              }), this.supportsBindingToComponentInputs = !0
          }
          get activatedComponentRef() {
            return this.activated
          }
          ngOnChanges(f) {
            if (f.name) {
              const {
                firstChange: v,
                previousValue: w
              } = f.name;
              if (v) return;
              this.isTrackedInParentContexts(w) && (this.deactivate(), this.parentContexts
                .onChildOutletDestroyed(w)), this.initializeOutletWithName()
            }
          }
          ngOnDestroy() {
            this.isTrackedInParentContexts(this.name) && this.parentContexts.onChildOutletDestroyed(this
              .name), this.inputBinder?.unsubscribeFromRouteData(this)
          }
          isTrackedInParentContexts(f) {
            return this.parentContexts.getContext(f)?.outlet === this
          }
          ngOnInit() {
            this.initializeOutletWithName()
          }
          initializeOutletWithName() {
            if (this.parentContexts.onChildOutletCreated(this.name, this), this.activated) return;
            const f = this.parentContexts.getContext(this.name);
            f?.route && (f.attachRef ? this.attach(f.attachRef, f.route) : this.activateWith(f.route, f
              .injector))
          }
          get isActivated() {
            return !!this.activated
          }
          get component() {
            if (!this.activated) throw new c.wOt(4012, !1);
            return this.activated.instance
          }
          get activatedRoute() {
            if (!this.activated) throw new c.wOt(4012, !1);
            return this._activatedRoute
          }
          get activatedRouteData() {
            return this._activatedRoute ? this._activatedRoute.snapshot.data : {}
          }
          detach() {
            if (!this.activated) throw new c.wOt(4012, !1);
            this.location.detach();
            const f = this.activated;
            return this.activated = null, this._activatedRoute = null, this.detachEvents.emit(f.instance), f
          }
          attach(f, v) {
            this.activated = f, this._activatedRoute = v, this.location.insert(f.hostView), this.inputBinder
              ?.bindActivatedRouteToOutletComponent(this), this.attachEvents.emit(f.instance)
          }
          deactivate() {
            if (this.activated) {
              const f = this.component;
              this.activated.destroy(), this.activated = null, this._activatedRoute = null, this
                .deactivateEvents.emit(f)
            }
          }
          activateWith(f, v) {
            if (this.isActivated) throw new c.wOt(4013, !1);
            this._activatedRoute = f;
            const w = this.location,
              G = f.snapshot.component,
              ge = this.parentContexts.getOrCreateContext(this.name).children,
              oe = new fi(f, ge, w.injector);
            this.activated = w.createComponent(G, {
              index: w.length,
              injector: oe,
              environmentInjector: v ?? this.environmentInjector
            }), this.changeDetector.markForCheck(), this.inputBinder?.bindActivatedRouteToOutletComponent(
              this), this.activateEvents.emit(this.activated.instance)
          }
          static #e = this.\u0275fac = function(v) {
            return new(v || u)
          };
          static #t = this.\u0275dir = c.FsC({
            type: u,
            selectors: [
              ["router-outlet"]
            ],
            inputs: {
              name: "name"
            },
            outputs: {
              activateEvents: "activate",
              deactivateEvents: "deactivate",
              attachEvents: "attach",
              detachEvents: "detach"
            },
            exportAs: ["outlet"],
            standalone: !0,
            features: [c.OA$]
          })
        }
        return u
      })();
      class fi {
        __ngOutletInjector(y) {
          return new fi(this.route, this.childContexts, y)
        }
        constructor(y, f, v) {
          this.route = y, this.childContexts = f, this.parent = v
        }
        get(y, f) {
          return y === Lr ? this.route : y === en ? this.childContexts : this.parent.get(y, f)
        }
      }
      const kr = new c.nKC("");
      let os = (() => {
        class u {
          constructor() {
            this.outletDataSubscriptions = new Map
          }
          bindActivatedRouteToOutletComponent(f) {
            this.unsubscribeFromRouteData(f), this.subscribeToRouteData(f)
          }
          unsubscribeFromRouteData(f) {
            this.outletDataSubscriptions.get(f)?.unsubscribe(), this.outletDataSubscriptions.delete(f)
          }
          subscribeToRouteData(f) {
            const {
              activatedRoute: v
            } = f, w = qe([v.queryParams, v.params, v.data]).pipe((0, Ce.n)(([P, G, ge], oe) => (ge = {
              ...P,
              ...G,
              ...ge
            }, 0 === oe ? (0, M.of)(ge) : Promise.resolve(ge)))).subscribe(P => {
              if (!f.isActivated || !f.activatedComponentRef || f.activatedRoute !== v || null === v
                .component) return void this.unsubscribeFromRouteData(f);
              const G = (0, c.HJs)(v.component);
              if (G)
                for (const {
                    templateName: ge
                  }
                  of G.inputs) f.activatedComponentRef.setInput(ge, P[ge]);
              else this.unsubscribeFromRouteData(f)
            });
            this.outletDataSubscriptions.set(f, w)
          }
          static #e = this.\u0275fac = function(v) {
            return new(v || u)
          };
          static #t = this.\u0275prov = c.jDH({
            token: u,
            factory: u.\u0275fac
          })
        }
        return u
      })();

      function xi(u, y, f) {
        if (f && u.shouldReuseRoute(y.value, f.value.snapshot)) {
          const v = f.value;
          v._futureSnapshot = y.value;
          const w = function As(u, y, f) {
            return y.children.map(v => {
              for (const w of f.children)
                if (u.shouldReuseRoute(v.value, w.value.snapshot)) return xi(u, v, w);
              return xi(u, v)
            })
          }(u, y, f);
          return new fr(v, w)
        } {
          if (u.shouldAttach(y.value)) {
            const P = u.retrieve(y.value);
            if (null !== P) {
              const G = P.route;
              return G.value._futureSnapshot = y.value, G.children = y.children.map(ge => xi(u, ge)), G
            }
          }
          const v = function tr(u) {
              return new Lr(new V.t(u.url), new V.t(u.params), new V.t(u.queryParams), new V.t(u.fragment), new V
                .t(u.data), u.outlet, u.component, u)
            }(y.value),
            w = y.children.map(P => xi(u, P));
          return new fr(v, w)
        }
      }
      const Li = "ngNavigationCancelingError";

      function wr(u, y) {
        const {
          redirectTo: f,
          navigationBehaviorOptions: v
        } = K(y) ? {
          redirectTo: y,
          navigationBehaviorOptions: void 0
        } : y, w = Ks(!1, Er.Redirect);
        return w.url = f, w.navigationBehaviorOptions = v, w
      }

      function Ks(u, y) {
        const f = new Error(`NavigationCancelingError: ${u||""}`);
        return f[Li] = !0, f.cancellationCode = y, f
      }

      function nr(u) {
        return !!u && u[Li]
      }
      let $t = (() => {
        class u {
          static #e = this.\u0275fac = function(v) {
            return new(v || u)
          };
          static #t = this.\u0275cmp = c.VBU({
            type: u,
            selectors: [
              ["ng-component"]
            ],
            standalone: !0,
            features: [c.aNF],
            decls: 1,
            vars: 0,
            template: function(v, w) {
              1 & v && c.nrm(0, "router-outlet")
            },
            dependencies: [di],
            encapsulation: 2
          })
        }
        return u
      })();

      function I(u) {
        const y = u.children && u.children.map(I),
          f = y ? {
            ...u,
            children: y
          } : {
            ...u
          };
        return !f.component && !f.loadComponent && (y || f.loadChildren) && f.outlet && f.outlet !== St && (f
          .component = $t), f
      }

      function T(u) {
        return u.outlet || St
      }

      function F(u) {
        if (!u) return null;
        if (u.routeConfig?._injector) return u.routeConfig._injector;
        for (let y = u.parent; y; y = y.parent) {
          const f = y.routeConfig;
          if (f?._loadedInjector) return f._loadedInjector;
          if (f?._injector) return f._injector
        }
        return null
      }
      class Rt {
        constructor(y, f, v, w, P) {
          this.routeReuseStrategy = y, this.futureState = f, this.currState = v, this.forwardEvent = w, this
            .inputBindingEnabled = P
        }
        activate(y) {
          const f = this.futureState._root,
            v = this.currState ? this.currState._root : null;
          this.deactivateChildRoutes(f, v, y), Zi(this.futureState.root), this.activateChildRoutes(f, v, y)
        }
        deactivateChildRoutes(y, f, v) {
          const w = Hr(f);
          y.children.forEach(P => {
            const G = P.value.outlet;
            this.deactivateRoutes(P, w[G], v), delete w[G]
          }), Object.values(w).forEach(P => {
            this.deactivateRouteAndItsChildren(P, v)
          })
        }
        deactivateRoutes(y, f, v) {
          const w = y.value,
            P = f ? f.value : null;
          if (w === P)
            if (w.component) {
              const G = v.getContext(w.outlet);
              G && this.deactivateChildRoutes(y, f, G.children)
            } else this.deactivateChildRoutes(y, f, v);
          else P && this.deactivateRouteAndItsChildren(f, v)
        }
        deactivateRouteAndItsChildren(y, f) {
          y.value.component && this.routeReuseStrategy.shouldDetach(y.value.snapshot) ? this
            .detachAndStoreRouteSubtree(y, f) : this.deactivateRouteAndOutlet(y, f)
        }
        detachAndStoreRouteSubtree(y, f) {
          const v = f.getContext(y.value.outlet),
            w = v && y.value.component ? v.children : f,
            P = Hr(y);
          for (const G of Object.values(P)) this.deactivateRouteAndItsChildren(G, w);
          if (v && v.outlet) {
            const G = v.outlet.detach(),
              ge = v.children.onOutletDeactivated();
            this.routeReuseStrategy.store(y.value.snapshot, {
              componentRef: G,
              route: y,
              contexts: ge
            })
          }
        }
        deactivateRouteAndOutlet(y, f) {
          const v = f.getContext(y.value.outlet),
            w = v && y.value.component ? v.children : f,
            P = Hr(y);
          for (const G of Object.values(P)) this.deactivateRouteAndItsChildren(G, w);
          v && (v.outlet && (v.outlet.deactivate(), v.children.onOutletDeactivated()), v.attachRef = null, v
            .route = null)
        }
        activateChildRoutes(y, f, v) {
          const w = Hr(f);
          y.children.forEach(P => {
            this.activateRoutes(P, w[P.value.outlet], v), this.forwardEvent(new Is(P.value.snapshot))
          }), y.children.length && this.forwardEvent(new is(y.value.snapshot))
        }
        activateRoutes(y, f, v) {
          const w = y.value,
            P = f ? f.value : null;
          if (Zi(w), w === P)
            if (w.component) {
              const G = v.getOrCreateContext(w.outlet);
              this.activateChildRoutes(y, f, G.children)
            } else this.activateChildRoutes(y, f, v);
          else if (w.component) {
            const G = v.getOrCreateContext(w.outlet);
            if (this.routeReuseStrategy.shouldAttach(w.snapshot)) {
              const ge = this.routeReuseStrategy.retrieve(w.snapshot);
              this.routeReuseStrategy.store(w.snapshot, null), G.children.onOutletReAttached(ge.contexts), G
                .attachRef = ge.componentRef, G.route = ge.route.value, G.outlet && G.outlet.attach(ge
                  .componentRef, ge.route.value), Zi(ge.route.value), this.activateChildRoutes(y, null, G
                  .children)
            } else {
              const ge = F(w.snapshot);
              G.attachRef = null, G.route = w, G.injector = ge, G.outlet && G.outlet.activateWith(w, G
                .injector), this.activateChildRoutes(y, null, G.children)
            }
          } else this.activateChildRoutes(y, null, v)
        }
      }
      class hr {
        constructor(y) {
          this.path = y, this.route = this.path[this.path.length - 1]
        }
      }
      class gi {
        constructor(y, f) {
          this.component = y, this.route = f
        }
      }

      function Qn(u, y, f) {
        const v = u._root;
        return $n(v, y ? y._root : null, f, [v.value])
      }

      function Bi(u, y) {
        const f = Symbol(),
          v = y.get(u, f);
        return v === f ? "function" != typeof u || (0, c.LfX)(u) ? y.get(u) : u : v
      }

      function $n(u, y, f, v, w = {
        canDeactivateChecks: [],
        canActivateChecks: []
      }) {
        const P = Hr(y);
        return u.children.forEach(G => {
          (function Ji(u, y, f, v, w = {
            canDeactivateChecks: [],
            canActivateChecks: []
          }) {
            const P = u.value,
              G = y ? y.value : null,
              ge = f ? f.getContext(u.value.outlet) : null;
            if (G && P.routeConfig === G.routeConfig) {
              const oe = function hn(u, y, f) {
                if ("function" == typeof f) return f(u, y);
                switch (f) {
                  case "pathParamsChange":
                    return !Oe(u.url, y.url);
                  case "pathParamsOrQueryParamsChange":
                    return !Oe(u.url, y.url) || !mn(u.queryParams, y.queryParams);
                  case "always":
                    return !0;
                  case "paramsOrQueryParamsChange":
                    return !Bn(u, y) || !mn(u.queryParams, y.queryParams);
                  default:
                    return !Bn(u, y)
                }
              }(G, P, P.routeConfig.runGuardsAndResolvers);
              oe ? w.canActivateChecks.push(new hr(v)) : (P.data = G.data, P._resolvedData = G
                  ._resolvedData), $n(u, y, P.component ? ge ? ge.children : null : f, v, w), oe && ge && ge
                .outlet && ge.outlet.isActivated && w.canDeactivateChecks.push(new gi(ge.outlet.component,
                  G))
            } else G && Rs(y, ge, w), w.canActivateChecks.push(new hr(v)), $n(u, null, P.component ? ge ? ge
              .children : null : f, v, w)
          })(G, P[G.value.outlet], f, v.concat([G.value]), w), delete P[G.value.outlet]
        }), Object.entries(P).forEach(([G, ge]) => Rs(ge, f.getContext(G), w)), w
      }

      function Rs(u, y, f) {
        const v = Hr(u),
          w = u.value;
        Object.entries(v).forEach(([P, G]) => {
          Rs(G, w.component ? y ? y.children.getContext(P) : null : y, f)
        }), f.canDeactivateChecks.push(new gi(w.component && y && y.outlet && y.outlet.isActivated ? y.outlet
          .component : null, w))
      }

      function es(u) {
        return "function" == typeof u
      }

      function Xs(u) {
        return u instanceof vt || "EmptyError" === u?.name
      }
      const as = Symbol("INITIAL_VALUE");

      function Ui() {
        return (0, Ce.n)(u => qe(u.map(y => y.pipe(ke(1), function Le(...u) {
          const y = (0, le.lI)(u);
          return (0, Ht.N)((f, v) => {
            (y ? se(u, f, y) : se(u, f)).subscribe(v)
          })
        }(as)))).pipe((0, ve.T)(y => {
          for (const f of y)
            if (!0 !== f) {
              if (f === as) return as;
              if (!1 === f || f instanceof re) return f
            } return !0
        }), (0, rt.p)(y => y !== as), ke(1)))
      }

      function Ao(u) {
        return (0, De.F)((0, bt.M)(y => {
          if (K(y)) throw wr(0, y)
        }), (0, ve.T)(y => !0 === y))
      }
      class ts {
        constructor(y) {
          this.segmentGroup = y || null
        }
      }
      class cs extends Error {
        constructor(y) {
          super(), this.urlTree = y
        }
      }

      function $r(u) {
        return (0, Z.$)(new ts(u))
      }
      class Oo {
        constructor(y, f) {
          this.urlSerializer = y, this.urlTree = f
        }
        lineralizeSegments(y, f) {
          let v = [],
            w = f.root;
          for (;;) {
            if (v = v.concat(w.segments), 0 === w.numberOfChildren) return (0, M.of)(v);
            if (w.numberOfChildren > 1 || !w.children[St]) return (0, Z.$)(new c.wOt(4e3, !1));
            w = w.children[St]
          }
        }
        applyRedirectCommands(y, f, v) {
          const w = this.applyRedirectCreateUrlTree(f, this.urlSerializer.parse(f), y, v);
          if (f.startsWith("/")) throw new cs(w);
          return w
        }
        applyRedirectCreateUrlTree(y, f, v, w) {
          const P = this.createSegmentGroup(y, f.root, v, w);
          return new re(P, this.createQueryParams(f.queryParams, this.urlTree.queryParams), f.fragment)
        }
        createQueryParams(y, f) {
          const v = {};
          return Object.entries(y).forEach(([w, P]) => {
            if ("string" == typeof P && P.startsWith(":")) {
              const ge = P.substring(1);
              v[w] = f[ge]
            } else v[w] = P
          }), v
        }
        createSegmentGroup(y, f, v, w) {
          const P = this.createSegments(y, f.segments, v, w);
          let G = {};
          return Object.entries(f.children).forEach(([ge, oe]) => {
            G[ge] = this.createSegmentGroup(y, oe, v, w)
          }), new te(P, G)
        }
        createSegments(y, f, v, w) {
          return f.map(P => P.path.startsWith(":") ? this.findPosParam(y, P, w) : this.findOrReturn(P, v))
        }
        findPosParam(y, f, v) {
          const w = v[f.path.substring(1)];
          if (!w) throw new c.wOt(4001, !1);
          return w
        }
        findOrReturn(y, f) {
          let v = 0;
          for (const w of f) {
            if (w.path === y.path) return f.splice(v), w;
            v++
          }
          return y
        }
      }
      const No = {
        matched: !1,
        consumedSegments: [],
        remainingSegments: [],
        parameters: {},
        positionalParamSegments: {}
      };

      function po(u, y, f, v, w) {
        const P = Js(u, y, f);
        return P.matched ? (v = function hi(u, y) {
          return u.providers && !u._injector && (u._injector = (0, c.Ol2)(u.providers, y,
            `Route: ${u.path}`)), u._injector ?? y
        }(y, v), function ta(u, y, f, v) {
          const w = y.canMatch;
          if (!w || 0 === w.length) return (0, M.of)(!0);
          const P = w.map(G => {
            const ge = Bi(G, u);
            return dt(function Qs(u) {
              return u && es(u.canMatch)
            }(ge) ? ge.canMatch(y, f) : (0, c.N4e)(u, () => ge(y, f)))
          });
          return (0, M.of)(P).pipe(Ui(), Ao())
        }(v, y, f).pipe((0, ve.T)(G => !0 === G ? P : {
          ...No
        }))) : (0, M.of)(P)
      }

      function Js(u, y, f) {
        if ("**" === y.path) return function na(u) {
          return {
            matched: !0,
            parameters: u.length > 0 ? ni(u).parameters : {},
            consumedSegments: u,
            remainingSegments: [],
            positionalParamSegments: {}
          }
        }(f);
        if ("" === y.path) return "full" === y.pathMatch && (u.hasChildren() || f.length > 0) ? {
          ...No
        } : {
          matched: !0,
          consumedSegments: [],
          remainingSegments: f,
          parameters: {},
          positionalParamSegments: {}
        };
        const w = (y.matcher || zr)(f, u, y);
        if (!w) return {
          ...No
        };
        const P = {};
        Object.entries(w.posParams ?? {}).forEach(([ge, oe]) => {
          P[ge] = oe.path
        });
        const G = w.consumed.length > 0 ? {
          ...P,
          ...w.consumed[w.consumed.length - 1].parameters
        } : P;
        return {
          matched: !0,
          consumedSegments: w.consumed,
          remainingSegments: f.slice(w.consumed.length),
          parameters: G,
          positionalParamSegments: w.posParams ?? {}
        }
      }

      function wi(u, y, f, v) {
        return f.length > 0 && function to(u, y, f) {
          return f.some(v => us(u, y, v) && T(v) !== St)
        }(u, f, v) ? {
          segmentGroup: new te(y, eo(v, new te(f, u.children))),
          slicedSegments: []
        } : 0 === f.length && function Po(u, y, f) {
          return f.some(v => us(u, y, v))
        }(u, f, v) ? {
          segmentGroup: new te(u.segments, Ro(u, f, v, u.children)),
          slicedSegments: f
        } : {
          segmentGroup: new te(u.segments, u.children),
          slicedSegments: f
        }
      }

      function Ro(u, y, f, v) {
        const w = {};
        for (const P of f)
          if (us(u, y, P) && !v[T(P)]) {
            const G = new te([], {});
            w[T(P)] = G
          } return {
          ...v,
          ...w
        }
      }

      function eo(u, y) {
        const f = {};
        f[St] = y;
        for (const v of u)
          if ("" === v.path && T(v) !== St) {
            const w = new te([], {});
            f[T(v)] = w
          } return f
      }

      function us(u, y, f) {
        return (!(u.hasChildren() || y.length > 0) || "full" !== f.pathMatch) && "" === f.path
      }
      class ds {}
      class ia {
        constructor(y, f, v, w, P, G, ge) {
          this.injector = y, this.configLoader = f, this.rootComponentType = v, this.config = w, this.urlTree =
            P, this.paramsInheritanceStrategy = G, this.urlSerializer = ge, this.applyRedirects = new Oo(this
              .urlSerializer, this.urlTree), this.absoluteRedirectCount = 0, this.allowRedirects = !0
        }
        noMatchError(y) {
          return new c.wOt(4002, `'${y.segmentGroup}'`)
        }
        recognize() {
          const y = wi(this.urlTree.root, [], [], this.config).segmentGroup;
          return this.match(y).pipe((0, ve.T)(f => {
            const v = new bi([], Object.freeze({}), Object.freeze({
                ...this.urlTree.queryParams
              }), this.urlTree.fragment, {}, St, this.rootComponentType, null, {}),
              w = new fr(v, f),
              P = new ui("", w),
              G = function Ee(u, y, f = null, v = null) {
                return je(pe(u), y, f, v)
              }(v, [], this.urlTree.queryParams, this.urlTree.fragment);
            return G.queryParams = this.urlTree.queryParams, P.url = this.urlSerializer.serialize(G), this
              .inheritParamsAndData(P._root, null), {
                state: P,
                tree: G
              }
          }))
        }
        match(y) {
          return this.processSegmentGroup(this.injector, this.config, y, St).pipe((0, Ct.W)(v => {
            if (v instanceof cs) return this.urlTree = v.urlTree, this.match(v.urlTree.root);
            throw v instanceof ts ? this.noMatchError(v) : v
          }))
        }
        inheritParamsAndData(y, f) {
          const v = y.value,
            w = er(v, f, this.paramsInheritanceStrategy);
          v.params = Object.freeze(w.params), v.data = Object.freeze(w.data), y.children.forEach(P => this
            .inheritParamsAndData(P, v))
        }
        processSegmentGroup(y, f, v, w) {
          return 0 === v.segments.length && v.hasChildren() ? this.processChildren(y, f, v) : this
            .processSegment(y, f, v, v.segments, w, !0).pipe((0, ve.T)(P => P instanceof fr ? [P] : []))
        }
        processChildren(y, f, v) {
          const w = [];
          for (const P of Object.keys(v.children)) "primary" === P ? w.unshift(P) : w.push(P);
          return (0, k.H)(w).pipe((0, nn.H)(P => {
            const G = v.children[P],
              ge = function _(u, y) {
                const f = u.filter(v => T(v) === y);
                return f.push(...u.filter(v => T(v) !== y)), f
              }(f, P);
            return this.processSegmentGroup(y, ge, G, P)
          }), function Un(u, y) {
            return (0, Ht.N)(function dn(u, y, f, v, w) {
              return (P, G) => {
                let ge = f,
                  oe = y,
                  Xe = 0;
                P.subscribe((0, me._)(G, mt => {
                  const Lt = Xe++;
                  oe = ge ? u(oe, mt, Lt) : (ge = !0, mt), v && G.next(oe)
                }, w && (() => {
                  ge && G.next(oe), G.complete()
                })))
              }
            }(u, y, arguments.length >= 2, !0))
          }((P, G) => (P.push(...G), P)), Nt(null), function Nn(u, y) {
            const f = arguments.length >= 2;
            return v => v.pipe(u ? (0, rt.p)((w, P) => u(w, P, v)) : X.D, rn(1), f ? Nt(y) : ln(() =>
              new vt))
          }(), (0, ue.Z)(P => {
            if (null === P) return $r(v);
            const G = xo(P);
            return function Fo(u) {
              u.sort((y, f) => y.value.outlet === St ? -1 : f.value.outlet === St ? 1 : y.value.outlet
                .localeCompare(f.value.outlet))
            }(G), (0, M.of)(G)
          }))
        }
        processSegment(y, f, v, w, P, G) {
          return (0, k.H)(f).pipe((0, nn.H)(ge => this.processSegmentAgainstRoute(ge._injector ?? y, f, ge, v,
            w, P, G).pipe((0, Ct.W)(oe => {
            if (oe instanceof ts) return (0, M.of)(null);
            throw oe
          }))), Ut(ge => !!ge), (0, Ct.W)(ge => {
            if (Xs(ge)) return function Wr(u, y, f) {
              return 0 === y.length && !u.children[f]
            }(v, w, P) ? (0, M.of)(new ds) : $r(v);
            throw ge
          }))
        }
        processSegmentAgainstRoute(y, f, v, w, P, G, ge) {
          return function xs(u, y, f, v) {
              return !!(T(u) === v || v !== St && us(y, f, u)) && Js(y, u, f).matched
            }(v, w, P, G) ? void 0 === v.redirectTo ? this.matchSegmentAgainstRoute(y, w, v, P, G) : this
            .allowRedirects && ge ? this.expandSegmentAgainstRouteUsingRedirect(y, w, f, v, P, G) : $r(w) : $r(
              w)
        }
        expandSegmentAgainstRouteUsingRedirect(y, f, v, w, P, G) {
          const {
            matched: ge,
            consumedSegments: oe,
            positionalParamSegments: Xe,
            remainingSegments: mt
          } = Js(f, w, P);
          if (!ge) return $r(f);
          w.redirectTo.startsWith("/") && (this.absoluteRedirectCount++, this.absoluteRedirectCount > 31 && (
            this.allowRedirects = !1));
          const Lt = this.applyRedirects.applyRedirectCommands(oe, w.redirectTo, Xe);
          return this.applyRedirects.lineralizeSegments(w, Lt).pipe((0, ue.Z)(Gn => this.processSegment(y, v, f,
            Gn.concat(mt), G, !1)))
        }
        matchSegmentAgainstRoute(y, f, v, w, P) {
          const G = po(f, v, w, y);
          return "**" === v.path && (f.children = {}), G.pipe((0, Ce.n)(ge => ge.matched ? this.getChildConfig(
            y = v._injector ?? y, v, w).pipe((0, Ce.n)(({
            routes: oe
          }) => {
            const Xe = v._loadedInjector ?? y,
              {
                consumedSegments: mt,
                remainingSegments: Lt,
                parameters: Gn
              } = ge,
              yo = new bi(mt, Gn, Object.freeze({
                ...this.urlTree.queryParams
              }), this.urlTree.fragment, function Xa(u) {
                return u.data || {}
              }(v), T(v), v.component ?? v._loadedComponent ?? null, v, function Lo(u) {
                return u.resolve || {}
              }(v)),
              {
                segmentGroup: Uo,
                slicedSegments: oa
              } = wi(f, mt, Lt, oe);
            if (0 === oa.length && Uo.hasChildren()) return this.processChildren(Xe, oe, Uo).pipe((0,
              ve.T)(ys => null === ys ? null : new fr(yo, ys)));
            if (0 === oe.length && 0 === oa.length) return (0, M.of)(new fr(yo, []));
            const pn = T(v) === P;
            return this.processSegment(Xe, oe, Uo, oa, pn ? St : P, !0).pipe((0, ve.T)(ys => new fr(
              yo, ys instanceof fr ? [ys] : [])))
          })) : $r(f)))
        }
        getChildConfig(y, f, v) {
          return f.children ? (0, M.of)({
            routes: f.children,
            injector: y
          }) : f.loadChildren ? void 0 !== f._loadedRoutes ? (0, M.of)({
            routes: f._loadedRoutes,
            injector: f._loadedInjector
          }) : function ls(u, y, f, v) {
            const w = y.canLoad;
            if (void 0 === w || 0 === w.length) return (0, M.of)(!0);
            const P = w.map(G => {
              const ge = Bi(G, u);
              return dt(function Io(u) {
                return u && es(u.canLoad)
              }(ge) ? ge.canLoad(y, f) : (0, c.N4e)(u, () => ge(y, f)))
            });
            return (0, M.of)(P).pipe(Ui(), Ao())
          }(y, f, v).pipe((0, ue.Z)(w => w ? this.configLoader.loadChildren(y, f).pipe((0, bt.M)(P => {
            f._loadedRoutes = P.routes, f._loadedInjector = P.injector
          })) : function Yl(u) {
            return (0, Z.$)(Ks(!1, Er.GuardRejected))
          }())) : (0, M.of)({
            routes: [],
            injector: y
          })
        }
      }

      function fs(u) {
        const y = u.value.routeConfig;
        return y && "" === y.path
      }

      function xo(u) {
        const y = [],
          f = new Set;
        for (const v of u) {
          if (!fs(v)) {
            y.push(v);
            continue
          }
          const w = y.find(P => v.value.routeConfig === P.value.routeConfig);
          void 0 !== w ? (w.children.push(...v.children), f.add(w)) : y.push(v)
        }
        for (const v of f) {
          const w = xo(v.children);
          y.push(new fr(v.value, w))
        }
        return y.filter(v => !f.has(v))
      }

      function no(u) {
        const y = u.children.map(f => no(f)).flat();
        return [u, ...y]
      }

      function S(u) {
        return (0, Ce.n)(y => {
          const f = u(y);
          return f ? (0, k.H)(f).pipe((0, ve.T)(() => y)) : (0, M.of)(y)
        })
      }
      let W = (() => {
          class u {
            buildTitle(f) {
              let v, w = f.root;
              for (; void 0 !== w;) v = this.getResolvedTitleForRoute(w) ?? v, w = w.children.find(P => P
                .outlet === St);
              return v
            }
            getResolvedTitleForRoute(f) {
              return f.data[jn]
            }
            static #e = this.\u0275fac = function(v) {
              return new(v || u)
            };
            static #t = this.\u0275prov = c.jDH({
              token: u,
              factory: () => (0, c.WQX)(_e),
              providedIn: "root"
            })
          }
          return u
        })(),
        _e = (() => {
          class u extends W {
            constructor(f) {
              super(), this.title = f
            }
            updateTitle(f) {
              const v = this.buildTitle(f);
              void 0 !== v && this.title.setTitle(v)
            }
            static #e = this.\u0275fac = function(v) {
              return new(v || u)(c.KVO(ti.hE))
            };
            static #t = this.\u0275prov = c.jDH({
              token: u,
              factory: u.\u0275fac,
              providedIn: "root"
            })
          }
          return u
        })();
      const Me = new c.nKC("", {
          providedIn: "root",
          factory: () => ({})
        }),
        Je = new c.nKC("");
      let cn = (() => {
        class u {
          constructor() {
            this.componentLoaders = new WeakMap, this.childrenLoaders = new WeakMap, this.compiler = (0, c
              .WQX)(c.Ql9)
          }
          loadComponent(f) {
            if (this.componentLoaders.get(f)) return this.componentLoaders.get(f);
            if (f._loadedComponent) return (0, M.of)(f._loadedComponent);
            this.onLoadStartListener && this.onLoadStartListener(f);
            const v = dt(f.loadComponent()).pipe((0, ve.T)(xt), (0, bt.M)(P => {
                this.onLoadEndListener && this.onLoadEndListener(f), f._loadedComponent = P
              }), (0, zn.j)(() => {
                this.componentLoaders.delete(f)
              })),
              w = new Yn(v, () => new he.B).pipe(Zt());
            return this.componentLoaders.set(f, w), w
          }
          loadChildren(f, v) {
            if (this.childrenLoaders.get(v)) return this.childrenLoaders.get(v);
            if (v._loadedRoutes) return (0, M.of)({
              routes: v._loadedRoutes,
              injector: v._loadedInjector
            });
            this.onLoadStartListener && this.onLoadStartListener(v);
            const P = function on(u, y, f, v) {
                return dt(u.loadChildren()).pipe((0, ve.T)(xt), (0, ue.Z)(w => w instanceof c.Co$ || Array
                  .isArray(w) ? (0, M.of)(w) : (0, k.H)(y.compileModuleAsync(w))), (0, ve.T)(w => {
                  v && v(u);
                  let P, G, ge = !1;
                  return Array.isArray(w) ? (G = w, !0) : (P = w.create(f).injector, G = P.get(Je,
                [], {
                    optional: !0,
                    self: !0
                  }).flat()), {
                    routes: G.map(I),
                    injector: P
                  }
                }))
              }(v, this.compiler, f, this.onLoadEndListener).pipe((0, zn.j)(() => {
                this.childrenLoaders.delete(v)
              })),
              G = new Yn(P, () => new he.B).pipe(Zt());
            return this.childrenLoaders.set(v, G), G
          }
          static #e = this.\u0275fac = function(v) {
            return new(v || u)
          };
          static #t = this.\u0275prov = c.jDH({
            token: u,
            factory: u.\u0275fac,
            providedIn: "root"
          })
        }
        return u
      })();

      function xt(u) {
        return function un(u) {
          return u && "object" == typeof u && "default" in u
        }(u) ? u.default : u
      }
      let vn = (() => {
          class u {
            static #e = this.\u0275fac = function(v) {
              return new(v || u)
            };
            static #t = this.\u0275prov = c.jDH({
              token: u,
              factory: () => (0, c.WQX)(tn),
              providedIn: "root"
            })
          }
          return u
        })(),
        tn = (() => {
          class u {
            shouldProcessUrl(f) {
              return !0
            }
            extract(f) {
              return f
            }
            merge(f, v) {
              return f
            }
            static #e = this.\u0275fac = function(v) {
              return new(v || u)
            };
            static #t = this.\u0275prov = c.jDH({
              token: u,
              factory: u.\u0275fac,
              providedIn: "root"
            })
          }
          return u
        })();
      const C = new c.nKC(""),
        d = new c.nKC("");

      function a(u, y, f) {
        const v = u.get(d),
          w = u.get(ye.qQ);
        return u.get(c.SKi).runOutsideAngular(() => {
          if (!w.startViewTransition || v.skipNextTransition) return v.skipNextTransition = !1, new Promise(
            Xe => setTimeout(Xe));
          let P;
          const G = new Promise(Xe => {
              P = Xe
            }),
            ge = w.startViewTransition(() => (P(), function m(u) {
              return new Promise(y => {
                (0, c.mal)(y, {
                  injector: u
                })
              })
            }(u))),
            {
              onViewTransitionCreated: oe
            } = v;
          return oe && (0, c.N4e)(u, () => oe({
            transition: ge,
            from: y,
            to: f
          })), G
        })
      }
      let b = (() => {
        class u {
          get hasRequestedNavigation() {
            return 0 !== this.navigationId
          }
          constructor() {
            this.currentNavigation = null, this.currentTransition = null, this.lastSuccessfulNavigation =
              null, this.events = new he.B, this.transitionAbortSubject = new he.B, this.configLoader = (0,
                c.WQX)(cn), this.environmentInjector = (0, c.WQX)(c.uvJ), this.urlSerializer = (0, c.WQX)(
                ct), this.rootContexts = (0, c.WQX)(en), this.location = (0, c.WQX)(ye.aZ), this
              .inputBindingEnabled = null !== (0, c.WQX)(kr, {
                optional: !0
              }), this.titleStrategy = (0, c.WQX)(W), this.options = (0, c.WQX)(Me, {
                optional: !0
              }) || {}, this.paramsInheritanceStrategy = this.options.paramsInheritanceStrategy ||
              "emptyOnly", this.urlHandlingStrategy = (0, c.WQX)(vn), this.createViewTransition = (0, c.WQX)
              (C, {
                optional: !0
              }), this.navigationId = 0, this.afterPreactivation = () => (0, M.of)(void 0), this
              .rootComponentType = null, this.configLoader.onLoadEndListener = w => this.events.next(new Qi(
                w)), this.configLoader.onLoadStartListener = w => this.events.next(new Ur(w))
          }
          complete() {
            this.transitions?.complete()
          }
          handleNavigationRequest(f) {
            const v = ++this.navigationId;
            this.transitions?.next({
              ...this.transitions.value,
              ...f,
              id: v
            })
          }
          setupNavigations(f, v, w) {
            return this.transitions = new V.t({
              id: 0,
              currentUrlTree: v,
              currentRawUrl: v,
              extractedUrl: this.urlHandlingStrategy.extract(v),
              urlAfterRedirects: this.urlHandlingStrategy.extract(v),
              rawUrl: v,
              extras: {},
              resolve: null,
              reject: null,
              promise: Promise.resolve(!0),
              source: lt,
              restoredState: null,
              currentSnapshot: w.snapshot,
              targetSnapshot: null,
              currentRouterState: w,
              targetRouterState: null,
              guards: {
                canActivateChecks: [],
                canDeactivateChecks: []
              },
              guardsResult: null
            }), this.transitions.pipe((0, rt.p)(P => 0 !== P.id), (0, ve.T)(P => ({
              ...P,
              extractedUrl: this.urlHandlingStrategy.extract(P.rawUrl)
            })), (0, Ce.n)(P => {
              let G = !1,
                ge = !1;
              return (0, M.of)(P).pipe((0, Ce.n)(oe => {
                  if (this.navigationId > P.id) return this.cancelNavigationTransition(P, "", Er
                    .SupersededByNewNavigation), xe;
                  this.currentTransition = P, this.currentNavigation = {
                    id: oe.id,
                    initialUrl: oe.rawUrl,
                    extractedUrl: oe.extractedUrl,
                    trigger: oe.source,
                    extras: oe.extras,
                    previousNavigation: this.lastSuccessfulNavigation ? {
                      ...this.lastSuccessfulNavigation,
                      previousNavigation: null
                    } : null
                  };
                  const Xe = !f.navigated || this.isUpdatingInternalState() || this
                    .isUpdatedBrowserUrl();
                  if (!Xe && "reload" !== (oe.extras.onSameUrlNavigation ?? f
                    .onSameUrlNavigation)) {
                    const Lt = "";
                    return this.events.next(new At(oe.id, this.urlSerializer.serialize(oe.rawUrl),
                      Lt, ws.IgnoredSameUrlNavigation)), oe.resolve(null), xe
                  }
                  if (this.urlHandlingStrategy.shouldProcessUrl(oe.rawUrl)) return (0, M.of)(oe)
                    .pipe((0, Ce.n)(Lt => {
                      const Gn = this.transitions?.getValue();
                      return this.events.next(new Jn(Lt.id, this.urlSerializer.serialize(Lt
                          .extractedUrl), Lt.source, Lt.restoredState)), Gn !== this
                        .transitions?.getValue() ? xe : Promise.resolve(Lt)
                    }), function hs(u, y, f, v, w, P) {
                      return (0, ue.Z)(G => function go(u, y, f, v, w, P, G = "emptyOnly") {
                        return new ia(u, y, f, v, w, G, P).recognize()
                      }(u, y, f, v, G.extractedUrl, w, P).pipe((0, ve.T)(({
                        state: ge,
                        tree: oe
                      }) => ({
                        ...G,
                        targetSnapshot: ge,
                        urlAfterRedirects: oe
                      }))))
                    }(this.environmentInjector, this.configLoader, this.rootComponentType, f
                      .config, this.urlSerializer, this.paramsInheritanceStrategy), (0, bt.M)(
                      Lt => {
                        P.targetSnapshot = Lt.targetSnapshot, P.urlAfterRedirects = Lt
                          .urlAfterRedirects, this.currentNavigation = {
                            ...this.currentNavigation,
                            finalUrl: Lt.urlAfterRedirects
                          };
                        const Gn = new Ki(Lt.id, this.urlSerializer.serialize(Lt
                          .extractedUrl), this.urlSerializer.serialize(Lt
                          .urlAfterRedirects), Lt.targetSnapshot);
                        this.events.next(Gn)
                      }));
                  if (Xe && this.urlHandlingStrategy.shouldProcessUrl(oe.currentRawUrl)) {
                    const {
                      id: Lt,
                      extractedUrl: Gn,
                      source: yo,
                      restoredState: Uo,
                      extras: oa
                    } = oe, pn = new Jn(Lt, this.urlSerializer.serialize(Gn), yo, Uo);
                    this.events.next(pn);
                    const ys = Ms(this.rootComponentType).snapshot;
                    return this.currentTransition = P = {
                      ...oe,
                      targetSnapshot: ys,
                      urlAfterRedirects: Gn,
                      extras: {
                        ...oa,
                        skipLocationChange: !1,
                        replaceUrl: !1
                      }
                    }, this.currentNavigation.finalUrl = Gn, (0, M.of)(P)
                  } {
                    const Lt = "";
                    return this.events.next(new At(oe.id, this.urlSerializer.serialize(oe
                        .extractedUrl), Lt, ws.IgnoredByUrlHandlingStrategy)), oe.resolve(null),
                      xe
                  }
                }), (0, bt.M)(oe => {
                  const Xe = new Vn(oe.id, this.urlSerializer.serialize(oe.extractedUrl), this
                    .urlSerializer.serialize(oe.urlAfterRedirects), oe.targetSnapshot);
                  this.events.next(Xe)
                }), (0, ve.T)(oe => (this.currentTransition = P = {
                  ...oe,
                  guards: Qn(oe.targetSnapshot, oe.currentSnapshot, this.rootContexts)
                }, P)), function fo(u, y) {
                  return (0, ue.Z)(f => {
                    const {
                      targetSnapshot: v,
                      currentSnapshot: w,
                      guards: {
                        canActivateChecks: P,
                        canDeactivateChecks: G
                      }
                    } = f;
                    return 0 === G.length && 0 === P.length ? (0, M.of)({
                      ...f,
                      guardsResult: !0
                    }) : function Vt(u, y, f, v) {
                      return (0, k.H)(u).pipe((0, ue.Z)(w => function Ys(u, y, f, v, w) {
                        const P = y && y.routeConfig ? y.routeConfig.canDeactivate :
                          null;
                        if (!P || 0 === P.length) return (0, M.of)(!0);
                        const G = P.map(ge => {
                          const oe = F(y) ?? w,
                            Xe = Bi(ge, oe);
                          return dt(function Fs(u) {
                            return u && es(u.canDeactivate)
                          }(Xe) ? Xe.canDeactivate(u, y, f, v) : (0, c.N4e)(oe,
                            () => Xe(u, y, f, v))).pipe(Ut())
                        });
                        return (0, M.of)(G).pipe(Ui())
                      }(w.component, w.route, f, y, v)), Ut(w => !0 !== w, !0))
                    }(G, v, w, u).pipe((0, ue.Z)(ge => ge && function ea(u) {
                      return "boolean" == typeof u
                    }(ge) ? function Sn(u, y, f, v) {
                      return (0, k.H)(y).pipe((0, nn.H)(w => se(function Ir(u, y) {
                        return null !== u && y && y(new Ci(u)), (0, M.of)(!0)
                      }(w.route.parent, v), function Pn(u, y) {
                        return null !== u && y && y(new Xi(u)), (0, M.of)(!0)
                      }(w.route, v), function To(u, y, f) {
                        const v = y[y.length - 1],
                          P = y.slice(0, y.length - 1).reverse().map(G =>
                            function uo(u) {
                              const y = u.routeConfig ? u.routeConfig
                                .canActivateChild : null;
                              return y && 0 !== y.length ? {
                                node: u,
                                guards: y
                              } : null
                            }(G)).filter(G => null !== G).map(G => Be(() => {
                            const ge = G.guards.map(oe => {
                              const Xe = F(G.node) ?? f,
                                mt = Bi(oe, Xe);
                              return dt(function Mo(u) {
                                return u && es(u.canActivateChild)
                              }(mt) ? mt.canActivateChild(v, u) : (0,
                                c.N4e)(Xe, () => mt(v, u))).pipe(Ut())
                            });
                            return (0, M.of)(ge).pipe(Ui())
                          }));
                        return (0, M.of)(P).pipe(Ui())
                      }(u, w.path, f), function rr(u, y, f) {
                        const v = y.routeConfig ? y.routeConfig.canActivate :
                        null;
                        if (!v || 0 === v.length) return (0, M.of)(!0);
                        const w = v.map(P => Be(() => {
                          const G = F(y) ?? f,
                            ge = Bi(P, G);
                          return dt(function Ps(u) {
                            return u && es(u.canActivate)
                          }(ge) ? ge.canActivate(y, u) : (0, c.N4e)(G,
                          () => ge(y, u))).pipe(Ut())
                        }));
                        return (0, M.of)(w).pipe(Ui())
                      }(u, w.route, f))), Ut(w => !0 !== w, !0))
                    }(v, P, u, y) : (0, M.of)(ge)), (0, ve.T)(ge => ({
                      ...f,
                      guardsResult: ge
                    })))
                  })
                }(this.environmentInjector, oe => this.events.next(oe)), (0, bt.M)(oe => {
                  if (P.guardsResult = oe.guardsResult, K(oe.guardsResult)) throw wr(0, oe
                    .guardsResult);
                  const Xe = new Ss(oe.id, this.urlSerializer.serialize(oe.extractedUrl), this
                    .urlSerializer.serialize(oe.urlAfterRedirects), oe.targetSnapshot, !!oe
                    .guardsResult);
                  this.events.next(Xe)
                }), (0, rt.p)(oe => !!oe.guardsResult || (this.cancelNavigationTransition(oe, "", Er
                  .GuardRejected), !1)), S(oe => {
                  if (oe.guards.canActivateChecks.length) return (0, M.of)(oe).pipe((0, bt.M)(
                    Xe => {
                      const mt = new qi(Xe.id, this.urlSerializer.serialize(Xe
                        .extractedUrl), this.urlSerializer.serialize(Xe
                        .urlAfterRedirects), Xe.targetSnapshot);
                      this.events.next(mt)
                    }), (0, Ce.n)(Xe => {
                    let mt = !1;
                    return (0, M.of)(Xe).pipe(function mo(u, y) {
                      return (0, ue.Z)(f => {
                        const {
                          targetSnapshot: v,
                          guards: {
                            canActivateChecks: w
                          }
                        } = f;
                        if (!w.length) return (0, M.of)(f);
                        const P = new Set(w.map(oe => oe.route)),
                          G = new Set;
                        for (const oe of P)
                          if (!G.has(oe))
                            for (const Xe of no(oe)) G.add(Xe);
                        let ge = 0;
                        return (0, k.H)(G).pipe((0, nn.H)(oe => P.has(oe) ?
                          function p(u, y, f, v) {
                            const w = u.routeConfig,
                              P = u._resolve;
                            return void 0 !== w?.title && !br(w) && (P[jn] = w
                                .title),
                              function N(u, y, f, v) {
                                const w = Pr(u);
                                if (0 === w.length) return (0, M.of)({});
                                const P = {};
                                return (0, k.H)(w).pipe((0, ue.Z)(G =>
                                  function D(u, y, f, v) {
                                    const w = F(y) ?? v,
                                      P = Bi(u, w);
                                    return dt(P.resolve ? P.resolve(y,
                                      f) : (0, c.N4e)(w, () => P(y, f)))
                                  }(u[G], y, f, v).pipe(Ut(), (0, bt.M)(
                                    ge => {
                                      P[G] = ge
                                    }))), rn(1), function Ke(u) {
                                  return (0, ve.T)(() => u)
                                }(P), (0, Ct.W)(G => Xs(G) ? xe : (0, Z.$)
                                  (G)))
                              }(P, u, y, v).pipe((0, ve.T)(G => (u
                                ._resolvedData = G, u.data = er(u, u
                                  .parent, f).resolve, null)))
                          }(oe, v, u, y) : (oe.data = er(oe, oe.parent, u)
                            .resolve, (0, M.of)(void 0))), (0, bt.M)(() =>
                          ge++), rn(1), (0, ue.Z)(oe => ge === G.size ? (0, M
                          .of)(f) : xe))
                      })
                    }(this.paramsInheritanceStrategy, this.environmentInjector), (0,
                      bt.M)({
                      next: () => mt = !0,
                      complete: () => {
                        mt || this.cancelNavigationTransition(Xe, "", Er
                          .NoDataFromResolver)
                      }
                    }))
                  }), (0, bt.M)(Xe => {
                    const mt = new rs(Xe.id, this.urlSerializer.serialize(Xe
                      .extractedUrl), this.urlSerializer.serialize(Xe
                      .urlAfterRedirects), Xe.targetSnapshot);
                    this.events.next(mt)
                  }))
                }), S(oe => {
                  const Xe = mt => {
                    const Lt = [];
                    mt.routeConfig?.loadComponent && !mt.routeConfig._loadedComponent && Lt
                      .push(this.configLoader.loadComponent(mt.routeConfig).pipe((0, bt.M)(
                      Gn => {
                        mt.component = Gn
                      }), (0, ve.T)(() => {})));
                    for (const Gn of mt.children) Lt.push(...Xe(Gn));
                    return Lt
                  };
                  return qe(Xe(oe.targetSnapshot.root)).pipe(Nt(null), ke(1))
                }), S(() => this.afterPreactivation()), (0, Ce.n)(() => {
                  const {
                    currentSnapshot: oe,
                    targetSnapshot: Xe
                  } = P, mt = this.createViewTransition?.(this.environmentInjector, oe.root, Xe
                    .root);
                  return mt ? (0, k.H)(mt).pipe((0, ve.T)(() => P)) : (0, M.of)(P)
                }), (0, ve.T)(oe => {
                  const Xe = function Fi(u, y, f) {
                    const v = xi(u, y._root, f ? f._root : void 0);
                    return new Ri(v, y)
                  }(f.routeReuseStrategy, oe.targetSnapshot, oe.currentRouterState);
                  return this.currentTransition = P = {
                    ...oe,
                    targetRouterState: Xe
                  }, this.currentNavigation.targetRouterState = Xe, P
                }), (0, bt.M)(() => {
                  this.events.next(new Cr)
                }), ((u, y, f, v) => (0, ve.T)(w => (new Rt(y, w.targetRouterState, w
                  .currentRouterState, f, v).activate(u), w)))(this.rootContexts, f
                  .routeReuseStrategy, oe => this.events.next(oe), this.inputBindingEnabled), ke(1),
                (0, bt.M)({
                  next: oe => {
                    G = !0, this.lastSuccessfulNavigation = this.currentNavigation, this.events
                      .next(new xr(oe.id, this.urlSerializer.serialize(oe.extractedUrl), this
                        .urlSerializer.serialize(oe.urlAfterRedirects))), this.titleStrategy
                      ?.updateTitle(oe.targetRouterState.snapshot), oe.resolve(!0)
                  },
                  complete: () => {
                    G = !0
                  }
                }),
                function _i(u) {
                  return (0, Ht.N)((y, f) => {
                    (0, Re.Tg)(u).subscribe((0, me._)(f, () => f.complete(), yr.l)), !f
                      .closed && y.subscribe(f)
                  })
                }(this.transitionAbortSubject.pipe((0, bt.M)(oe => {
                  throw oe
                }))), (0, zn.j)(() => {
                  !G && !ge && this.cancelNavigationTransition(P, "", Er
                    .SupersededByNewNavigation), this.currentTransition?.id === P.id && (this
                    .currentNavigation = null, this.currentTransition = null)
                }), (0, Ct.W)(oe => {
                  if (ge = !0, nr(oe)) this.events.next(new li(P.id, this.urlSerializer.serialize(
                      P.extractedUrl), oe.message, oe.cancellationCode)),
                    function co(u) {
                      return nr(u) && K(u.url)
                    }(oe) ? this.events.next(new Yi(oe.url)) : P.resolve(!1);
                  else {
                    this.events.next(new Br(P.id, this.urlSerializer.serialize(P.extractedUrl),
                      oe, P.targetSnapshot ?? void 0));
                    try {
                      P.resolve(f.errorHandler(oe))
                    } catch (Xe) {
                      this.options.resolveNavigationPromiseOnError ? P.resolve(!1) : P.reject(Xe)
                    }
                  }
                  return xe
                }))
            }))
          }
          cancelNavigationTransition(f, v, w) {
            const P = new li(f.id, this.urlSerializer.serialize(f.extractedUrl), v, w);
            this.events.next(P), f.resolve(!1)
          }
          isUpdatingInternalState() {
            return this.currentTransition?.extractedUrl.toString() !== this.currentTransition
              ?.currentUrlTree.toString()
          }
          isUpdatedBrowserUrl() {
            return this.urlHandlingStrategy.extract(this.urlSerializer.parse(this.location.path(!0)))
              .toString() !== this.currentTransition?.extractedUrl.toString() && !this.currentTransition
              ?.extras.skipLocationChange
          }
          static #e = this.\u0275fac = function(v) {
            return new(v || u)
          };
          static #t = this.\u0275prov = c.jDH({
            token: u,
            factory: u.\u0275fac,
            providedIn: "root"
          })
        }
        return u
      })();

      function R(u) {
        return u !== lt
      }
      let j = (() => {
        class u {
          static #e = this.\u0275fac = function(v) {
            return new(v || u)
          };
          static #t = this.\u0275prov = c.jDH({
            token: u,
            factory: () => (0, c.WQX)(de),
            providedIn: "root"
          })
        }
        return u
      })();
      class q {
        shouldDetach(y) {
          return !1
        }
        store(y, f) {}
        shouldAttach(y) {
          return !1
        }
        retrieve(y) {
          return null
        }
        shouldReuseRoute(y, f) {
          return y.routeConfig === f.routeConfig
        }
      }
      let de = (() => {
          class u extends q {
            static #e = this.\u0275fac = (() => {
              let f;
              return function(w) {
                return (f || (f = c.xGo(u)))(w || u)
              }
            })();
            static #t = this.\u0275prov = c.jDH({
              token: u,
              factory: u.\u0275fac,
              providedIn: "root"
            })
          }
          return u
        })(),
        fe = (() => {
          class u {
            static #e = this.\u0275fac = function(v) {
              return new(v || u)
            };
            static #t = this.\u0275prov = c.jDH({
              token: u,
              factory: () => (0, c.WQX)($e),
              providedIn: "root"
            })
          }
          return u
        })(),
        $e = (() => {
          class u extends fe {
            constructor() {
              super(...arguments), this.location = (0, c.WQX)(ye.aZ), this.urlSerializer = (0, c.WQX)(ct),
                this.options = (0, c.WQX)(Me, {
                  optional: !0
                }) || {}, this.canceledNavigationResolution = this.options.canceledNavigationResolution ||
                "replace", this.urlHandlingStrategy = (0, c.WQX)(vn), this.urlUpdateStrategy = this.options
                .urlUpdateStrategy || "deferred", this.currentUrlTree = new re, this.rawUrlTree = this
                .currentUrlTree, this.currentPageId = 0, this.lastSuccessfulId = -1, this.routerState = Ms(
                  null), this.stateMemento = this.createStateMemento()
            }
            getCurrentUrlTree() {
              return this.currentUrlTree
            }
            getRawUrlTree() {
              return this.rawUrlTree
            }
            restoredState() {
              return this.location.getState()
            }
            get browserPageId() {
              return "computed" !== this.canceledNavigationResolution ? this.currentPageId : this
                .restoredState()?.\u0275routerPageId ?? this.currentPageId
            }
            getRouterState() {
              return this.routerState
            }
            createStateMemento() {
              return {
                rawUrlTree: this.rawUrlTree,
                currentUrlTree: this.currentUrlTree,
                routerState: this.routerState
              }
            }
            registerNonRouterCurrentEntryChangeListener(f) {
              return this.location.subscribe(v => {
                "popstate" === v.type && f(v.url, v.state)
              })
            }
            handleRouterEvent(f, v) {
              if (f instanceof Jn) this.stateMemento = this.createStateMemento();
              else if (f instanceof At) this.rawUrlTree = v.initialUrl;
              else if (f instanceof Ki) {
                if ("eager" === this.urlUpdateStrategy && !v.extras.skipLocationChange) {
                  const w = this.urlHandlingStrategy.merge(v.finalUrl, v.initialUrl);
                  this.setBrowserUrl(w, v)
                }
              } else f instanceof Cr ? (this.currentUrlTree = v.finalUrl, this.rawUrlTree = this
                  .urlHandlingStrategy.merge(v.finalUrl, v.initialUrl), this.routerState = v
                  .targetRouterState, "deferred" === this.urlUpdateStrategy && (v.extras.skipLocationChange ||
                    this.setBrowserUrl(this.rawUrlTree, v))) : f instanceof li && (f.code === Er
                  .GuardRejected || f.code === Er.NoDataFromResolver) ? this.restoreHistory(v) :
                f instanceof Br ? this.restoreHistory(v, !0) : f instanceof xr && (this.lastSuccessfulId = f
                  .id, this.currentPageId = this.browserPageId)
            }
            setBrowserUrl(f, v) {
              const w = this.urlSerializer.serialize(f);
              if (this.location.isCurrentPathEqualTo(w) || v.extras.replaceUrl) {
                const G = {
                  ...v.extras.state,
                  ...this.generateNgRouterState(v.id, this.browserPageId)
                };
                this.location.replaceState(w, "", G)
              } else {
                const P = {
                  ...v.extras.state,
                  ...this.generateNgRouterState(v.id, this.browserPageId + 1)
                };
                this.location.go(w, "", P)
              }
            }
            restoreHistory(f, v = !1) {
              if ("computed" === this.canceledNavigationResolution) {
                const P = this.currentPageId - this.browserPageId;
                0 !== P ? this.location.historyGo(P) : this.currentUrlTree === f.finalUrl && 0 === P && (this
                  .resetState(f), this.resetUrlToCurrentUrlTree())
              } else "replace" === this.canceledNavigationResolution && (v && this.resetState(f), this
                .resetUrlToCurrentUrlTree())
            }
            resetState(f) {
              this.routerState = this.stateMemento.routerState, this.currentUrlTree = this.stateMemento
                .currentUrlTree, this.rawUrlTree = this.urlHandlingStrategy.merge(this.currentUrlTree, f
                  .finalUrl ?? this.rawUrlTree)
            }
            resetUrlToCurrentUrlTree() {
              this.location.replaceState(this.urlSerializer.serialize(this.rawUrlTree), "", this
                .generateNgRouterState(this.lastSuccessfulId, this.currentPageId))
            }
            generateNgRouterState(f, v) {
              return "computed" === this.canceledNavigationResolution ? {
                navigationId: f,
                \u0275routerPageId: v
              } : {
                navigationId: f
              }
            }
            static #e = this.\u0275fac = (() => {
              let f;
              return function(w) {
                return (f || (f = c.xGo(u)))(w || u)
              }
            })();
            static #t = this.\u0275prov = c.jDH({
              token: u,
              factory: u.\u0275fac,
              providedIn: "root"
            })
          }
          return u
        })();
      var Ge = function(u) {
        return u[u.COMPLETE = 0] = "COMPLETE", u[u.FAILED = 1] = "FAILED", u[u.REDIRECTING = 2] = "REDIRECTING",
          u
      }(Ge || {});

      function We(u, y) {
        u.events.pipe((0, rt.p)(f => f instanceof xr || f instanceof li || f instanceof Br || f instanceof At), (
          0, ve.T)(f => f instanceof xr || f instanceof At ? Ge.COMPLETE : f instanceof li && (f.code === Er
          .Redirect || f.code === Er.SupersededByNewNavigation) ? Ge.REDIRECTING : Ge.FAILED), (0, rt.p)(f =>
          f !== Ge.REDIRECTING), ke(1)).subscribe(() => {
          y()
        })
      }

      function Mt(u) {
        throw u
      }
      const gt = {
          paths: "exact",
          fragment: "ignored",
          matrixParams: "ignored",
          queryParams: "exact"
        },
        Dt = {
          paths: "subset",
          fragment: "ignored",
          matrixParams: "ignored",
          queryParams: "subset"
        };
      let ft = (() => {
          class u {
            get currentUrlTree() {
              return this.stateManager.getCurrentUrlTree()
            }
            get rawUrlTree() {
              return this.stateManager.getRawUrlTree()
            }
            get events() {
              return this._events
            }
            get routerState() {
              return this.stateManager.getRouterState()
            }
            constructor() {
              this.disposed = !1, this.isNgZoneEnabled = !1, this.console = (0, c.WQX)(c.H3F), this
                .stateManager = (0, c.WQX)(fe), this.options = (0, c.WQX)(Me, {
                  optional: !0
                }) || {}, this.pendingTasks = (0, c.WQX)(c.TgB), this.urlUpdateStrategy = this.options
                .urlUpdateStrategy || "deferred", this.navigationTransitions = (0, c.WQX)(b), this
                .urlSerializer = (0, c.WQX)(ct), this.location = (0, c.WQX)(ye.aZ), this.urlHandlingStrategy =
                (0, c.WQX)(vn), this._events = new he.B, this.errorHandler = this.options.errorHandler || Mt,
                this.navigated = !1, this.routeReuseStrategy = (0, c.WQX)(j), this.onSameUrlNavigation = this
                .options.onSameUrlNavigation || "ignore", this.config = (0, c.WQX)(Je, {
                  optional: !0
                })?.flat() ?? [], this.componentInputBindingEnabled = !!(0, c.WQX)(kr, {
                  optional: !0
                }), this.eventsSubscription = new Et.yU, this.isNgZoneEnabled = (0, c.WQX)(c.SKi) instanceof c
                .SKi && c.SKi.isInAngularZone(), this.resetConfig(this.config), this.navigationTransitions
                .setupNavigations(this, this.currentUrlTree, this.routerState).subscribe({
                  error: f => {
                    this.console.warn(f)
                  }
                }), this.subscribeToNavigationEvents()
            }
            subscribeToNavigationEvents() {
              const f = this.navigationTransitions.events.subscribe(v => {
                try {
                  const w = this.navigationTransitions.currentTransition,
                    P = this.navigationTransitions.currentNavigation;
                  if (null !== w && null !== P)
                    if (this.stateManager.handleRouterEvent(v, P), v instanceof li && v.code !== Er
                      .Redirect && v.code !== Er.SupersededByNewNavigation) this.navigated = !0;
                    else if (v instanceof xr) this.navigated = !0;
                  else if (v instanceof Yi) {
                    const G = this.urlHandlingStrategy.merge(v.url, w.currentRawUrl),
                      ge = {
                        info: w.extras.info,
                        skipLocationChange: w.extras.skipLocationChange,
                        replaceUrl: "eager" === this.urlUpdateStrategy || R(w.source)
                      };
                    this.scheduleNavigation(G, lt, null, ge, {
                      resolve: w.resolve,
                      reject: w.reject,
                      promise: w.promise
                    })
                  }(function An(u) {
                    return !(u instanceof Cr || u instanceof Yi)
                  })(v) && this._events.next(v)
                } catch (w) {
                  this.navigationTransitions.transitionAbortSubject.next(w)
                }
              });
              this.eventsSubscription.add(f)
            }
            resetRootComponentType(f) {
              this.routerState.root.component = f, this.navigationTransitions.rootComponentType = f
            }
            initialNavigation() {
              this.setUpLocationChangeListener(), this.navigationTransitions.hasRequestedNavigation || this
                .navigateToSyncWithBrowser(this.location.path(!0), lt, this.stateManager.restoredState())
            }
            setUpLocationChangeListener() {
              this.nonRouterCurrentEntryChangeSubscription ??= this.stateManager
                .registerNonRouterCurrentEntryChangeListener((f, v) => {
                  setTimeout(() => {
                    this.navigateToSyncWithBrowser(f, "popstate", v)
                  }, 0)
                })
            }
            navigateToSyncWithBrowser(f, v, w) {
              const P = {
                  replaceUrl: !0
                },
                G = w?.navigationId ? w : null;
              if (w) {
                const oe = {
                  ...w
                };
                delete oe.navigationId, delete oe.\u0275routerPageId, 0 !== Object.keys(oe).length && (P
                  .state = oe)
              }
              const ge = this.parseUrl(f);
              this.scheduleNavigation(ge, v, G, P)
            }
            get url() {
              return this.serializeUrl(this.currentUrlTree)
            }
            getCurrentNavigation() {
              return this.navigationTransitions.currentNavigation
            }
            get lastSuccessfulNavigation() {
              return this.navigationTransitions.lastSuccessfulNavigation
            }
            resetConfig(f) {
              this.config = f.map(I), this.navigated = !1
            }
            ngOnDestroy() {
              this.dispose()
            }
            dispose() {
              this.navigationTransitions.complete(), this.nonRouterCurrentEntryChangeSubscription && (this
                  .nonRouterCurrentEntryChangeSubscription.unsubscribe(), this
                  .nonRouterCurrentEntryChangeSubscription = void 0), this.disposed = !0, this
                .eventsSubscription.unsubscribe()
            }
            createUrlTree(f, v = {}) {
              const {
                relativeTo: w,
                queryParams: P,
                fragment: G,
                queryParamsHandling: ge,
                preserveFragment: oe
              } = v, Xe = oe ? this.currentUrlTree.fragment : G;
              let Lt, mt = null;
              switch (ge) {
                case "merge":
                  mt = {
                    ...this.currentUrlTree.queryParams,
                    ...P
                  };
                  break;
                case "preserve":
                  mt = this.currentUrlTree.queryParams;
                  break;
                default:
                  mt = P || null
              }
              null !== mt && (mt = this.removeEmptyProps(mt));
              try {
                Lt = pe(w ? w.snapshot : this.routerState.snapshot.root)
              } catch {
                ("string" != typeof f[0] || !f[0].startsWith("/")) && (f = []), Lt = this.currentUrlTree.root
              }
              return je(Lt, f, mt, Xe ?? null)
            }
            navigateByUrl(f, v = {
              skipLocationChange: !1
            }) {
              const w = K(f) ? f : this.parseUrl(f),
                P = this.urlHandlingStrategy.merge(w, this.rawUrlTree);
              return this.scheduleNavigation(P, lt, null, v)
            }
            navigate(f, v = {
              skipLocationChange: !1
            }) {
              return function Tn(u) {
                for (let y = 0; y < u.length; y++)
                  if (null == u[y]) throw new c.wOt(4008, !1)
              }(f), this.navigateByUrl(this.createUrlTree(f, v), v)
            }
            serializeUrl(f) {
              return this.urlSerializer.serialize(f)
            }
            parseUrl(f) {
              try {
                return this.urlSerializer.parse(f)
              } catch {
                return this.urlSerializer.parse("/")
              }
            }
            isActive(f, v) {
              let w;
              if (w = !0 === v ? {
                  ...gt
                } : !1 === v ? {
                  ...Dt
                } : v, K(f)) return Pt(this.currentUrlTree, f, w);
              const P = this.parseUrl(f);
              return Pt(this.currentUrlTree, P, w)
            }
            removeEmptyProps(f) {
              return Object.entries(f).reduce((v, [w, P]) => (null != P && (v[w] = P), v), {})
            }
            scheduleNavigation(f, v, w, P, G) {
              if (this.disposed) return Promise.resolve(!1);
              let ge, oe, Xe;
              G ? (ge = G.resolve, oe = G.reject, Xe = G.promise) : Xe = new Promise((Lt, Gn) => {
                ge = Lt, oe = Gn
              });
              const mt = this.pendingTasks.add();
              return We(this, () => {
                queueMicrotask(() => this.pendingTasks.remove(mt))
              }), this.navigationTransitions.handleNavigationRequest({
                source: v,
                restoredState: w,
                currentUrlTree: this.currentUrlTree,
                currentRawUrl: this.currentUrlTree,
                rawUrl: f,
                extras: P,
                resolve: ge,
                reject: oe,
                promise: Xe,
                currentSnapshot: this.routerState.snapshot,
                currentRouterState: this.routerState
              }), Xe.catch(Lt => Promise.reject(Lt))
            }
            static #e = this.\u0275fac = function(v) {
              return new(v || u)
            };
            static #t = this.\u0275prov = c.jDH({
              token: u,
              factory: u.\u0275fac,
              providedIn: "root"
            })
          }
          return u
        })(),
        _n = (() => {
          class u {
            constructor(f, v, w, P, G, ge) {
              this.router = f, this.route = v, this.tabIndexAttribute = w, this.renderer = P, this.el = G,
                this.locationStrategy = ge, this.href = null, this.commands = null, this.onChanges = new he.B,
                this.preserveFragment = !1, this.skipLocationChange = !1, this.replaceUrl = !1;
              const oe = G.nativeElement.tagName?.toLowerCase();
              this.isAnchorElement = "a" === oe || "area" === oe, this.isAnchorElement ? this.subscription = f
                .events.subscribe(Xe => {
                  Xe instanceof xr && this.updateHref()
                }) : this.setTabIndexIfNotOnNativeEl("0")
            }
            setTabIndexIfNotOnNativeEl(f) {
              null != this.tabIndexAttribute || this.isAnchorElement || this.applyAttributeValue("tabindex",
                f)
            }
            ngOnChanges(f) {
              this.isAnchorElement && this.updateHref(), this.onChanges.next(this)
            }
            set routerLink(f) {
              null != f ? (this.commands = Array.isArray(f) ? f : [f], this.setTabIndexIfNotOnNativeEl("0")) :
                (this.commands = null, this.setTabIndexIfNotOnNativeEl(null))
            }
            onClick(f, v, w, P, G) {
              const ge = this.urlTree;
              return !!(null === ge || this.isAnchorElement && (0 !== f || v || w || P || G || "string" ==
                typeof this.target && "_self" != this.target)) || (this.router.navigateByUrl(ge, {
                skipLocationChange: this.skipLocationChange,
                replaceUrl: this.replaceUrl,
                state: this.state,
                info: this.info
              }), !this.isAnchorElement)
            }
            ngOnDestroy() {
              this.subscription?.unsubscribe()
            }
            updateHref() {
              const f = this.urlTree;
              this.href = null !== f && this.locationStrategy ? this.locationStrategy?.prepareExternalUrl(this
                .router.serializeUrl(f)) : null;
              const v = null === this.href ? null : (0, c.n$t)(this.href, this.el.nativeElement.tagName
                .toLowerCase(), "href");
              this.applyAttributeValue("href", v)
            }
            applyAttributeValue(f, v) {
              const w = this.renderer,
                P = this.el.nativeElement;
              null !== v ? w.setAttribute(P, f, v) : w.removeAttribute(P, f)
            }
            get urlTree() {
              return null === this.commands ? null : this.router.createUrlTree(this.commands, {
                relativeTo: void 0 !== this.relativeTo ? this.relativeTo : this.route,
                queryParams: this.queryParams,
                fragment: this.fragment,
                queryParamsHandling: this.queryParamsHandling,
                preserveFragment: this.preserveFragment
              })
            }
            static #e = this.\u0275fac = function(v) {
              return new(v || u)(c.rXU(ft), c.rXU(Lr), c.kS0("tabindex"), c.rXU(c.sFG), c.rXU(c.aKT), c.rXU(ye
                .hb))
            };
            static #t = this.\u0275dir = c.FsC({
              type: u,
              selectors: [
                ["", "routerLink", ""]
              ],
              hostVars: 1,
              hostBindings: function(v, w) {
                1 & v && c.bIt("click", function(G) {
                  return w.onClick(G.button, G.ctrlKey, G.shiftKey, G.altKey, G.metaKey)
                }), 2 & v && c.BMQ("target", w.target)
              },
              inputs: {
                target: "target",
                queryParams: "queryParams",
                fragment: "fragment",
                queryParamsHandling: "queryParamsHandling",
                state: "state",
                info: "info",
                relativeTo: "relativeTo",
                preserveFragment: [c.Mj6.HasDecoratorInputTransform, "preserveFragment", "preserveFragment",
                  c.L39
                ],
                skipLocationChange: [c.Mj6.HasDecoratorInputTransform, "skipLocationChange",
                  "skipLocationChange", c.L39
                ],
                replaceUrl: [c.Mj6.HasDecoratorInputTransform, "replaceUrl", "replaceUrl", c.L39],
                routerLink: "routerLink"
              },
              standalone: !0,
              features: [c.GFd, c.OA$]
            })
          }
          return u
        })(),
        Fn = (() => {
          class u {
            get isActive() {
              return this._isActive
            }
            constructor(f, v, w, P, G) {
              this.router = f, this.element = v, this.renderer = w, this.cdr = P, this.link = G, this
                .classes = [], this._isActive = !1, this.routerLinkActiveOptions = {
                  exact: !1
                }, this.isActiveChange = new c.bkB, this.routerEventsSubscription = f.events.subscribe(ge => {
                  ge instanceof xr && this.update()
                })
            }
            ngAfterContentInit() {
              (0, M.of)(this.links.changes, (0, M.of)(null)).pipe(Pe()).subscribe(f => {
                this.update(), this.subscribeToEachLinkOnChanges()
              })
            }
            subscribeToEachLinkOnChanges() {
              this.linkInputChangesSubscription?.unsubscribe();
              const f = [...this.links.toArray(), this.link].filter(v => !!v).map(v => v.onChanges);
              this.linkInputChangesSubscription = (0, k.H)(f).pipe(Pe()).subscribe(v => {
                this._isActive !== this.isLinkActive(this.router)(v) && this.update()
              })
            }
            set routerLinkActive(f) {
              const v = Array.isArray(f) ? f : f.split(" ");
              this.classes = v.filter(w => !!w)
            }
            ngOnChanges(f) {
              this.update()
            }
            ngOnDestroy() {
              this.routerEventsSubscription.unsubscribe(), this.linkInputChangesSubscription?.unsubscribe()
            }
            update() {
              !this.links || !this.router.navigated || queueMicrotask(() => {
                const f = this.hasActiveLinks();
                this.classes.forEach(v => {
                    f ? this.renderer.addClass(this.element.nativeElement, v) : this.renderer
                      .removeClass(this.element.nativeElement, v)
                  }), f && void 0 !== this.ariaCurrentWhenActive ? this.renderer.setAttribute(this.element
                    .nativeElement, "aria-current", this.ariaCurrentWhenActive.toString()) : this.renderer
                  .removeAttribute(this.element.nativeElement, "aria-current"), this._isActive !== f && (
                    this._isActive = f, this.cdr.markForCheck(), this.isActiveChange.emit(f))
              })
            }
            isLinkActive(f) {
              const v = function ps(u) {
                  return !!u.paths
                }(this.routerLinkActiveOptions) ? this.routerLinkActiveOptions : this.routerLinkActiveOptions
                .exact || !1;
              return w => {
                const P = w.urlTree;
                return !!P && f.isActive(P, v)
              }
            }
            hasActiveLinks() {
              const f = this.isLinkActive(this.router);
              return this.link && f(this.link) || this.links.some(f)
            }
            static #e = this.\u0275fac = function(v) {
              return new(v || u)(c.rXU(ft), c.rXU(c.aKT), c.rXU(c.sFG), c.rXU(c.gRc), c.rXU(_n, 8))
            };
            static #t = this.\u0275dir = c.FsC({
              type: u,
              selectors: [
                ["", "routerLinkActive", ""]
              ],
              contentQueries: function(v, w, P) {
                if (1 & v && c.wni(P, _n, 5), 2 & v) {
                  let G;
                  c.mGM(G = c.lsd()) && (w.links = G)
                }
              },
              inputs: {
                routerLinkActiveOptions: "routerLinkActiveOptions",
                ariaCurrentWhenActive: "ariaCurrentWhenActive",
                routerLinkActive: "routerLinkActive"
              },
              outputs: {
                isActiveChange: "isActiveChange"
              },
              exportAs: ["routerLinkActive"],
              standalone: !0,
              features: [c.OA$]
            })
          }
          return u
        })();
      class Xn {}
      let yt = (() => {
        class u {
          constructor(f, v, w, P, G) {
            this.router = f, this.injector = w, this.preloadingStrategy = P, this.loader = G
          }
          setUpPreloading() {
            this.subscription = this.router.events.pipe((0, rt.p)(f => f instanceof xr), (0, nn.H)(() =>
              this.preload())).subscribe(() => {})
          }
          preload() {
            return this.processRoutes(this.injector, this.router.config)
          }
          ngOnDestroy() {
            this.subscription && this.subscription.unsubscribe()
          }
          processRoutes(f, v) {
            const w = [];
            for (const P of v) {
              P.providers && !P._injector && (P._injector = (0, c.Ol2)(P.providers, f, `Route: ${P.path}`));
              const G = P._injector ?? f,
                ge = P._loadedInjector ?? G;
              (P.loadChildren && !P._loadedRoutes && void 0 === P.canLoad || P.loadComponent && !P
                ._loadedComponent) && w.push(this.preloadConfig(G, P)), (P.children || P._loadedRoutes) && w
                .push(this.processRoutes(ge, P.children ?? P._loadedRoutes))
            }
            return (0, k.H)(w).pipe(Pe())
          }
          preloadConfig(f, v) {
            return this.preloadingStrategy.preload(v, () => {
              let w;
              w = v.loadChildren && void 0 === v.canLoad ? this.loader.loadChildren(f, v) : (0, M.of)(
                null);
              const P = w.pipe((0, ue.Z)(G => null === G ? (0, M.of)(void 0) : (v._loadedRoutes = G
                .routes, v._loadedInjector = G.injector, this.processRoutes(G.injector ?? f, G
                  .routes))));
              if (v.loadComponent && !v._loadedComponent) {
                const G = this.loader.loadComponent(v);
                return (0, k.H)([P, G]).pipe(Pe())
              }
              return P
            })
          }
          static #e = this.\u0275fac = function(v) {
            return new(v || u)(c.KVO(ft), c.KVO(c.Ql9), c.KVO(c.uvJ), c.KVO(Xn), c.KVO(cn))
          };
          static #t = this.\u0275prov = c.jDH({
            token: u,
            factory: u.\u0275fac,
            providedIn: "root"
          })
        }
        return u
      })();
      const Si = new c.nKC("");
      let gs = (() => {
        class u {
          constructor(f, v, w, P, G = {}) {
            this.urlSerializer = f, this.transitions = v, this.viewportScroller = w, this.zone = P, this
              .options = G, this.lastId = 0, this.lastSource = "imperative", this.restoredId = 0, this
              .store = {}, this.environmentInjector = (0, c.WQX)(c.uvJ), G.scrollPositionRestoration ||=
              "disabled", G.anchorScrolling ||= "disabled"
          }
          init() {
            "disabled" !== this.options.scrollPositionRestoration && this.viewportScroller
              .setHistoryScrollRestoration("manual"), this.routerEventsSubscription = this
              .createScrollEvents(), this.scrollEventsSubscription = this.consumeScrollEvents()
          }
          createScrollEvents() {
            return this.transitions.events.subscribe(f => {
              f instanceof Jn ? (this.store[this.lastId] = this.viewportScroller.getScrollPosition(),
                  this.lastSource = f.navigationTrigger, this.restoredId = f.restoredState ? f
                  .restoredState.navigationId : 0) : f instanceof xr ? (this.lastId = f.id, this
                  .scheduleScrollEvent(f, this.urlSerializer.parse(f.urlAfterRedirects).fragment)) :
                f instanceof At && f.code === ws.IgnoredSameUrlNavigation && (this.lastSource = void 0,
                  this.restoredId = 0, this.scheduleScrollEvent(f, this.urlSerializer.parse(f.url)
                    .fragment))
            })
          }
          consumeScrollEvents() {
            return this.transitions.events.subscribe(f => {
              f instanceof ss && (f.position ? "top" === this.options.scrollPositionRestoration ? this
                .viewportScroller.scrollToPosition([0, 0]) : "enabled" === this.options
                .scrollPositionRestoration && this.viewportScroller.scrollToPosition(f.position) : f
                .anchor && "enabled" === this.options.anchorScrolling ? this.viewportScroller
                .scrollToAnchor(f.anchor) : "disabled" !== this.options.scrollPositionRestoration &&
                this.viewportScroller.scrollToPosition([0, 0]))
            })
          }
          scheduleScrollEvent(f, v) {
            var w = this;
            this.zone.runOutsideAngular((0, g.A)(function*() {
              yield new Promise(P => {
                setTimeout(() => {
                  P()
                }), (0, c.mal)(() => {
                  P()
                }, {
                  injector: w.environmentInjector
                })
              }), w.zone.run(() => {
                w.transitions.events.next(new ss(f, "popstate" === w.lastSource ? w.store[w
                  .restoredId] : null, v))
              })
            }))
          }
          ngOnDestroy() {
            this.routerEventsSubscription?.unsubscribe(), this.scrollEventsSubscription?.unsubscribe()
          }
          static #e = this.\u0275fac = function(v) {
            c.QTQ()
          };
          static #t = this.\u0275prov = c.jDH({
            token: u,
            factory: u.\u0275fac
          })
        }
        return u
      })();

      function pr(u, y) {
        return {
          \u0275kind: u,
          \u0275providers: y
        }
      }

      function Kt() {
        const u = (0, c.WQX)(c.zZn);
        return y => {
          const f = u.get(c.o8S);
          if (y !== f.components[0]) return;
          const v = u.get(ft),
            w = u.get(En);
          1 === u.get(Tr) && v.initialNavigation(), u.get(ko, null, c.$GK.Optional)?.setUpPreloading(), u.get(
            Si, null, c.$GK.Optional)?.init(), v.resetRootComponentType(f.componentTypes[0]), w.closed || (w
            .next(), w.complete(), w.unsubscribe())
        }
      }
      const En = new c.nKC("", {
          factory: () => new he.B
        }),
        Tr = new c.nKC("", {
          providedIn: "root",
          factory: () => 1
        }),
        ko = new c.nKC("");

      function Vo(u) {
        return pr(0, [{
          provide: ko,
          useExisting: yt
        }, {
          provide: Xn,
          useExisting: u
        }])
      }

      function sa(u) {
        return pr(9, [{
          provide: C,
          useValue: a
        }, {
          provide: d,
          useValue: {
            skipNextTransition: !!u?.skipInitialTransition,
            ...u
          }
        }])
      }
      const Tu = new c.nKC("ROUTER_FORROOT_GUARD"),
        Sh = [ye.aZ, {
          provide: ct,
          useClass: qt
        }, ft, en, {
          provide: Lr,
          useFactory: function ms(u) {
            return u.routerState.root
          },
          deps: [ft]
        }, cn, []];
      let Ih = (() => {
        class u {
          constructor(f) {}
          static forRoot(f, v) {
            return {
              ngModule: u,
              providers: [Sh, [], {
                  provide: Je,
                  multi: !0,
                  useValue: f
                }, {
                  provide: Tu,
                  useFactory: Oh,
                  deps: [
                    [ft, new c.Xx1, new c.kdw]
                  ]
                }, {
                  provide: Me,
                  useValue: v || {}
                }, v?.useHash ? {
                  provide: ye.hb,
                  useClass: ye.fw
                } : {
                  provide: ye.hb,
                  useClass: ye.Sm
                }, {
                  provide: Si,
                  useFactory: () => {
                    const u = (0, c.WQX)(ye.Xr),
                      y = (0, c.WQX)(c.SKi),
                      f = (0, c.WQX)(Me),
                      v = (0, c.WQX)(b),
                      w = (0, c.WQX)(ct);
                    return f.scrollOffset && u.setOffset(f.scrollOffset), new gs(w, v, u, y, f)
                  }
                }, v?.preloadingStrategy ? Vo(v.preloadingStrategy).\u0275providers : [], v
                ?.initialNavigation ? Nh(v) : [], v?.bindToComponentInputs ? pr(8, [os, {
                  provide: kr,
                  useExisting: os
                }]).\u0275providers : [], v?.enableViewTransitions ? sa().\u0275providers : [],
                [{
                  provide: Au,
                  useFactory: Kt
                }, {
                  provide: c.iLQ,
                  multi: !0,
                  useExisting: Au
                }]
              ]
            }
          }
          static forChild(f) {
            return {
              ngModule: u,
              providers: [{
                provide: Je,
                multi: !0,
                useValue: f
              }]
            }
          }
          static #e = this.\u0275fac = function(v) {
            return new(v || u)(c.KVO(Tu, 8))
          };
          static #t = this.\u0275mod = c.$C({
            type: u
          });
          static #n = this.\u0275inj = c.G2t({})
        }
        return u
      })();

      function Oh(u) {
        return "guarded"
      }

      function Nh(u) {
        return ["disabled" === u.initialNavigation ? pr(3, [{
          provide: c.hnV,
          multi: !0,
          useFactory: () => {
            const y = (0, c.WQX)(ft);
            return () => {
              y.setUpLocationChangeListener()
            }
          }
        }, {
          provide: Tr,
          useValue: 2
        }]).\u0275providers : [], "enabledBlocking" === u.initialNavigation ? pr(2, [{
          provide: Tr,
          useValue: 0
        }, {
          provide: c.hnV,
          multi: !0,
          deps: [c.zZn],
          useFactory: y => {
            const f = y.get(ye.hj, Promise.resolve());
            return () => f.then(() => new Promise(v => {
              const w = y.get(ft),
                P = y.get(En);
              We(w, () => {
                  v(!0)
                }), y.get(b).afterPreactivation = () => (v(!0), P.closed ? (0, M.of)(void 0) : P),
                w.initialNavigation()
            }))
          }
        }]).\u0275providers : []]
      }
      const Au = new c.nKC("")
    },
    5779: (nt, Se, x) => {
      x.d(Se, {
        E: () => X,
        Ei: () => we,
        Gg: () => Ve,
        Rn: () => V,
        Y9: () => Ae,
        Yj: () => Ze,
        bg: () => U,
        r1: () => me,
        si: () => le,
        tl: () => $,
        wi: () => qe
      });
      var g = x(4438),
        c = x(1413),
        ee = x(4420);
      const ae = ["*"];
      let V = (() => class ue {
          static STARTS_WITH = "startsWith";
          static CONTAINS = "contains";
          static NOT_CONTAINS = "notContains";
          static ENDS_WITH = "endsWith";
          static EQUALS = "equals";
          static NOT_EQUALS = "notEquals";
          static IN = "in";
          static LESS_THAN = "lt";
          static LESS_THAN_OR_EQUAL_TO = "lte";
          static GREATER_THAN = "gt";
          static GREATER_THAN_OR_EQUAL_TO = "gte";
          static BETWEEN = "between";
          static IS = "is";
          static IS_NOT = "isNot";
          static BEFORE = "before";
          static AFTER = "after";
          static DATE_IS = "dateIs";
          static DATE_IS_NOT = "dateIsNot";
          static DATE_BEFORE = "dateBefore";
          static DATE_AFTER = "dateAfter"
        })(),
        $ = (() => class ue {
          static AND = "and";
          static OR = "or"
        })(),
        X = (() => {
          class ue {
            filter(ie, se, Re, Be, De) {
              let Z = [];
              if (ie)
                for (let xe of ie)
                  for (let be of se) {
                    let et = ee.BF.resolveFieldData(xe, be);
                    if (this.filters[Be](et, Re, De)) {
                      Z.push(xe);
                      break
                    }
                  }
              return Z
            }
            filters = {
              startsWith: (ie, se, Re) => {
                if (null == se || "" === se.trim()) return !0;
                if (null == ie) return !1;
                let Be = ee.BF.removeAccents(se.toString()).toLocaleLowerCase(Re);
                return ee.BF.removeAccents(ie.toString()).toLocaleLowerCase(Re).slice(0, Be.length) === Be
              },
              contains: (ie, se, Re) => {
                if (null == se || "string" == typeof se && "" === se.trim()) return !0;
                if (null == ie) return !1;
                let Be = ee.BF.removeAccents(se.toString()).toLocaleLowerCase(Re);
                return -1 !== ee.BF.removeAccents(ie.toString()).toLocaleLowerCase(Re).indexOf(Be)
              },
              notContains: (ie, se, Re) => {
                if (null == se || "string" == typeof se && "" === se.trim()) return !0;
                if (null == ie) return !1;
                let Be = ee.BF.removeAccents(se.toString()).toLocaleLowerCase(Re);
                return -1 === ee.BF.removeAccents(ie.toString()).toLocaleLowerCase(Re).indexOf(Be)
              },
              endsWith: (ie, se, Re) => {
                if (null == se || "" === se.trim()) return !0;
                if (null == ie) return !1;
                let Be = ee.BF.removeAccents(se.toString()).toLocaleLowerCase(Re),
                  De = ee.BF.removeAccents(ie.toString()).toLocaleLowerCase(Re);
                return -1 !== De.indexOf(Be, De.length - Be.length)
              },
              equals: (ie, se, Re) => null == se || "string" == typeof se && "" === se.trim() || null != ie &&
                (ie.getTime && se.getTime ? ie.getTime() === se.getTime() : ie == se || ee.BF.removeAccents(ie
                    .toString()).toLocaleLowerCase(Re) == ee.BF.removeAccents(se.toString())
                  .toLocaleLowerCase(Re)),
              notEquals: (ie, se, Re) => !(null == se || "string" == typeof se && "" === se.trim() || null !=
                ie && (ie.getTime && se.getTime ? ie.getTime() === se.getTime() : ie == se || ee.BF
                  .removeAccents(ie.toString()).toLocaleLowerCase(Re) == ee.BF.removeAccents(se.toString())
                  .toLocaleLowerCase(Re))),
              in: (ie, se) => {
                if (null == se || 0 === se.length) return !0;
                for (let Re = 0; Re < se.length; Re++)
                  if (ee.BF.equals(ie, se[Re])) return !0;
                return !1
              },
              between: (ie, se) => null == se || null == se[0] || null == se[1] || null != ie && (ie.getTime ?
                se[0].getTime() <= ie.getTime() && ie.getTime() <= se[1].getTime() : se[0] <= ie && ie <=
                se[1]),
              lt: (ie, se, Re) => null == se || null != ie && (ie.getTime && se.getTime ? ie.getTime() < se
                .getTime() : ie < se),
              lte: (ie, se, Re) => null == se || null != ie && (ie.getTime && se.getTime ? ie.getTime() <= se
                .getTime() : ie <= se),
              gt: (ie, se, Re) => null == se || null != ie && (ie.getTime && se.getTime ? ie.getTime() > se
                .getTime() : ie > se),
              gte: (ie, se, Re) => null == se || null != ie && (ie.getTime && se.getTime ? ie.getTime() >= se
                .getTime() : ie >= se),
              is: (ie, se, Re) => this.filters.equals(ie, se, Re),
              isNot: (ie, se, Re) => this.filters.notEquals(ie, se, Re),
              before: (ie, se, Re) => this.filters.lt(ie, se, Re),
              after: (ie, se, Re) => this.filters.gt(ie, se, Re),
              dateIs: (ie, se) => null == se || null != ie && ie.toDateString() === se.toDateString(),
              dateIsNot: (ie, se) => null == se || null != ie && ie.toDateString() !== se.toDateString(),
              dateBefore: (ie, se) => null == se || null != ie && ie.getTime() < se.getTime(),
              dateAfter: (ie, se) => {
                if (null == se) return !0;
                if (null == ie) return !1;
                const Re = new Date(ie);
                return Re.setHours(0, 0, 0, 0), Re.getTime() > se.getTime()
              }
            };
            register(ie, se) {
              this.filters[ie] = se
            }
            static \u0275fac = function(se) {
              return new(se || ue)
            };
            static \u0275prov = g.jDH({
              token: ue,
              factory: ue.\u0275fac,
              providedIn: "root"
            })
          }
          return ue
        })(),
        U = (() => {
          class ue {
            messageSource = new c.B;
            clearSource = new c.B;
            messageObserver = this.messageSource.asObservable();
            clearObserver = this.clearSource.asObservable();
            add(ie) {
              ie && this.messageSource.next(ie)
            }
            addAll(ie) {
              ie && ie.length && this.messageSource.next(ie)
            }
            clear(ie) {
              this.clearSource.next(ie || null)
            }
            static \u0275fac = function(se) {
              return new(se || ue)
            };
            static \u0275prov = g.jDH({
              token: ue,
              factory: ue.\u0275fac
            })
          }
          return ue
        })(),
        le = (() => {
          class ue {
            clickSource = new c.B;
            clickObservable = this.clickSource.asObservable();
            add(ie) {
              ie && this.clickSource.next(ie)
            }
            static \u0275fac = function(se) {
              return new(se || ue)
            };
            static \u0275prov = g.jDH({
              token: ue,
              factory: ue.\u0275fac,
              providedIn: "root"
            })
          }
          return ue
        })(),
        me = (() => {
          class ue {
            ripple = !1;
            inputStyle = (0, g.vPA)("outlined");
            overlayOptions = {};
            csp = (0, g.vPA)({
              nonce: void 0
            });
            filterMatchModeOptions = {
              text: [V.STARTS_WITH, V.CONTAINS, V.NOT_CONTAINS, V.ENDS_WITH, V.EQUALS, V.NOT_EQUALS],
              numeric: [V.EQUALS, V.NOT_EQUALS, V.LESS_THAN, V.LESS_THAN_OR_EQUAL_TO, V.GREATER_THAN, V
                .GREATER_THAN_OR_EQUAL_TO
              ],
              date: [V.DATE_IS, V.DATE_IS_NOT, V.DATE_BEFORE, V.DATE_AFTER]
            };
            translation = {
              startsWith: "Starts with",
              contains: "Contains",
              notContains: "Not contains",
              endsWith: "Ends with",
              equals: "Equals",
              notEquals: "Not equals",
              noFilter: "No Filter",
              lt: "Less than",
              lte: "Less than or equal to",
              gt: "Greater than",
              gte: "Greater than or equal to",
              is: "Is",
              isNot: "Is not",
              before: "Before",
              after: "After",
              dateIs: "Date is",
              dateIsNot: "Date is not",
              dateBefore: "Date is before",
              dateAfter: "Date is after",
              clear: "Clear",
              apply: "Apply",
              matchAll: "Match All",
              matchAny: "Match Any",
              addRule: "Add Rule",
              removeRule: "Remove Rule",
              accept: "Yes",
              reject: "No",
              choose: "Choose",
              upload: "Upload",
              cancel: "Cancel",
              pending: "Pending",
              fileSizeTypes: ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
              dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
              dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
              dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
              monthNames: ["January", "February", "March", "April", "May", "June", "July", "August",
                "September", "October", "November", "December"
              ],
              monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                "Dec"
              ],
              chooseYear: "Choose Year",
              chooseMonth: "Choose Month",
              chooseDate: "Choose Date",
              prevDecade: "Previous Decade",
              nextDecade: "Next Decade",
              prevYear: "Previous Year",
              nextYear: "Next Year",
              prevMonth: "Previous Month",
              nextMonth: "Next Month",
              prevHour: "Previous Hour",
              nextHour: "Next Hour",
              prevMinute: "Previous Minute",
              nextMinute: "Next Minute",
              prevSecond: "Previous Second",
              nextSecond: "Next Second",
              am: "am",
              pm: "pm",
              dateFormat: "mm/dd/yy",
              firstDayOfWeek: 0,
              today: "Today",
              weekHeader: "Wk",
              weak: "Weak",
              medium: "Medium",
              strong: "Strong",
              passwordPrompt: "Enter a password",
              emptyMessage: "No results found",
              searchMessage: "{0} results are available",
              selectionMessage: "{0} items selected",
              emptySelectionMessage: "No selected item",
              emptySearchMessage: "No results found",
              emptyFilterMessage: "No results found",
              aria: {
                trueLabel: "True",
                falseLabel: "False",
                nullLabel: "Not Selected",
                star: "1 star",
                stars: "{star} stars",
                selectAll: "All items selected",
                unselectAll: "All items unselected",
                close: "Close",
                previous: "Previous",
                next: "Next",
                navigation: "Navigation",
                scrollTop: "Scroll Top",
                moveTop: "Move Top",
                moveUp: "Move Up",
                moveDown: "Move Down",
                moveBottom: "Move Bottom",
                moveToTarget: "Move to Target",
                moveToSource: "Move to Source",
                moveAllToTarget: "Move All to Target",
                moveAllToSource: "Move All to Source",
                pageLabel: "{page}",
                firstPageLabel: "First Page",
                lastPageLabel: "Last Page",
                nextPageLabel: "Next Page",
                prevPageLabel: "Previous Page",
                rowsPerPageLabel: "Rows per page",
                previousPageLabel: "Previous Page",
                jumpToPageDropdownLabel: "Jump to Page Dropdown",
                jumpToPageInputLabel: "Jump to Page Input",
                selectRow: "Row Selected",
                unselectRow: "Row Unselected",
                expandRow: "Row Expanded",
                collapseRow: "Row Collapsed",
                showFilterMenu: "Show Filter Menu",
                hideFilterMenu: "Hide Filter Menu",
                filterOperator: "Filter Operator",
                filterConstraint: "Filter Constraint",
                editRow: "Row Edit",
                saveEdit: "Save Edit",
                cancelEdit: "Cancel Edit",
                listView: "List View",
                gridView: "Grid View",
                slide: "Slide",
                slideNumber: "{slideNumber}",
                zoomImage: "Zoom Image",
                zoomIn: "Zoom In",
                zoomOut: "Zoom Out",
                rotateRight: "Rotate Right",
                rotateLeft: "Rotate Left",
                listLabel: "Option List",
                selectColor: "Select a color",
                removeLabel: "Remove",
                browseFiles: "Browse Files",
                maximizeLabel: "Maximize"
              }
            };
            zIndex = {
              modal: 1100,
              overlay: 1e3,
              menu: 1e3,
              tooltip: 1100
            };
            translationSource = new c.B;
            translationObserver = this.translationSource.asObservable();
            getTranslation(ie) {
              return this.translation[ie]
            }
            setTranslation(ie) {
              this.translation = {
                ...this.translation,
                ...ie
              }, this.translationSource.next(this.translation)
            }
            static \u0275fac = function(se) {
              return new(se || ue)
            };
            static \u0275prov = g.jDH({
              token: ue,
              factory: ue.\u0275fac,
              providedIn: "root"
            })
          }
          return ue
        })(),
        Ae = (() => {
          class ue {
            static \u0275fac = function(se) {
              return new(se || ue)
            };
            static \u0275cmp = g.VBU({
              type: ue,
              selectors: [
                ["p-header"]
              ],
              standalone: !0,
              features: [g.aNF],
              ngContentSelectors: ae,
              decls: 1,
              vars: 0,
              template: function(se, Re) {
                1 & se && (g.NAR(), g.SdG(0))
              },
              encapsulation: 2
            })
          }
          return ue
        })(),
        qe = (() => {
          class ue {
            static \u0275fac = function(se) {
              return new(se || ue)
            };
            static \u0275cmp = g.VBU({
              type: ue,
              selectors: [
                ["p-footer"]
              ],
              standalone: !0,
              features: [g.aNF],
              ngContentSelectors: ae,
              decls: 1,
              vars: 0,
              template: function(se, Re) {
                1 & se && (g.NAR(), g.SdG(0))
              },
              encapsulation: 2
            })
          }
          return ue
        })(),
        we = (() => {
          class ue {
            template;
            type;
            name;
            constructor(ie) {
              this.template = ie
            }
            getType() {
              return this.name
            }
            static \u0275fac = function(se) {
              return new(se || ue)(g.rXU(g.C4Q))
            };
            static \u0275dir = g.FsC({
              type: ue,
              selectors: [
                ["", "pTemplate", ""]
              ],
              inputs: {
                type: "type",
                name: [g.Mj6.None, "pTemplate", "name"]
              },
              standalone: !0
            })
          }
          return ue
        })(),
        Ve = (() => {
          class ue {
            static \u0275fac = function(se) {
              return new(se || ue)
            };
            static \u0275mod = g.$C({
              type: ue
            });
            static \u0275inj = g.G2t({})
          }
          return ue
        })(),
        Ze = (() => class ue {
          static STARTS_WITH = "startsWith";
          static CONTAINS = "contains";
          static NOT_CONTAINS = "notContains";
          static ENDS_WITH = "endsWith";
          static EQUALS = "equals";
          static NOT_EQUALS = "notEquals";
          static NO_FILTER = "noFilter";
          static LT = "lt";
          static LTE = "lte";
          static GT = "gt";
          static GTE = "gte";
          static IS = "is";
          static IS_NOT = "isNot";
          static BEFORE = "before";
          static AFTER = "after";
          static CLEAR = "clear";
          static APPLY = "apply";
          static MATCH_ALL = "matchAll";
          static MATCH_ANY = "matchAny";
          static ADD_RULE = "addRule";
          static REMOVE_RULE = "removeRule";
          static ACCEPT = "accept";
          static REJECT = "reject";
          static CHOOSE = "choose";
          static UPLOAD = "upload";
          static CANCEL = "cancel";
          static PENDING = "pending";
          static FILE_SIZE_TYPES = "fileSizeTypes";
          static DAY_NAMES = "dayNames";
          static DAY_NAMES_SHORT = "dayNamesShort";
          static DAY_NAMES_MIN = "dayNamesMin";
          static MONTH_NAMES = "monthNames";
          static MONTH_NAMES_SHORT = "monthNamesShort";
          static FIRST_DAY_OF_WEEK = "firstDayOfWeek";
          static TODAY = "today";
          static WEEK_HEADER = "weekHeader";
          static WEAK = "weak";
          static MEDIUM = "medium";
          static STRONG = "strong";
          static PASSWORD_PROMPT = "passwordPrompt";
          static EMPTY_MESSAGE = "emptyMessage";
          static EMPTY_FILTER_MESSAGE = "emptyFilterMessage";
          static SHOW_FILTER_MENU = "showFilterMenu";
          static HIDE_FILTER_MENU = "hideFilterMenu";
          static SELECTION_MESSAGE = "selectionMessage";
          static ARIA = "aria";
          static SELECT_COLOR = "selectColor";
          static BROWSE_FILES = "browseFiles"
        })()
    },
    1880: (nt, Se, x) => {
      x.d(Se, {
        q: () => ae,
        u: () => A
      });
      var g = x(177),
        c = x(4438),
        ee = x(1455);
      let ae = (() => {
          class k {
            autofocus = !1;
            focused = !1;
            platformId = (0, c.WQX)(c.Agw);
            document = (0, c.WQX)(g.qQ);
            host = (0, c.WQX)(c.aKT);
            ngAfterContentChecked() {
              !1 === this.autofocus ? this.host.nativeElement.removeAttribute("autofocus") : this.host
                .nativeElement.setAttribute("autofocus", !0), this.focused || this.autoFocus()
            }
            ngAfterViewChecked() {
              this.focused || this.autoFocus()
            }
            autoFocus() {
              (0, g.UE)(this.platformId) && this.autofocus && setTimeout(() => {
                const V = ee.D.getFocusableElements(this.host?.nativeElement);
                0 === V.length && this.host.nativeElement.focus(), V.length > 0 && V[0].focus(), this
                  .focused = !0
              })
            }
            static \u0275fac = function($) {
              return new($ || k)
            };
            static \u0275dir = c.FsC({
              type: k,
              selectors: [
                ["", "pAutoFocus", ""]
              ],
              hostAttrs: [1, "p-element"],
              inputs: {
                autofocus: [c.Mj6.HasDecoratorInputTransform, "autofocus", "autofocus", c.L39]
              },
              standalone: !0,
              features: [c.GFd]
            })
          }
          return k
        })(),
        A = (() => {
          class k {
            static \u0275fac = function($) {
              return new($ || k)
            };
            static \u0275mod = c.$C({
              type: k
            });
            static \u0275inj = c.G2t({})
          }
          return k
        })()
    },
    461: (nt, Se, x) => {
      x.d(Se, {
        h: () => ae
      });
      var g = x(4438),
        c = x(4420);
      const ee = ["*"];
      let ae = (() => {
        class A {
          label;
          spin = !1;
          styleClass;
          role;
          ariaLabel;
          ariaHidden;
          ngOnInit() {
            this.getAttributes()
          }
          getAttributes() {
            const M = c.BF.isEmpty(this.label);
            this.role = M ? void 0 : "img", this.ariaLabel = M ? void 0 : this.label, this.ariaHidden = M
          }
          getClassNames() {
            return `p-icon ${this.styleClass?this.styleClass+" ":""}${this.spin?"p-icon-spin":""}`
          }
          static \u0275fac = function(V) {
            return new(V || A)
          };
          static \u0275cmp = g.VBU({
            type: A,
            selectors: [
              ["ng-component"]
            ],
            hostAttrs: [1, "p-element", "p-icon-wrapper"],
            inputs: {
              label: "label",
              spin: [g.Mj6.HasDecoratorInputTransform, "spin", "spin", g.L39],
              styleClass: "styleClass"
            },
            standalone: !0,
            features: [g.GFd, g.aNF],
            ngContentSelectors: ee,
            decls: 1,
            vars: 0,
            template: function(V, $) {
              1 & V && (g.NAR(), g.SdG(0))
            },
            encapsulation: 2,
            changeDetection: 0
          })
        }
        return A
      })()
    },
    1141: (nt, Se, x) => {
      x.d(Se, {
        $n: () => Be,
        _f: () => Re,
        tm: () => De
      });
      var g = x(177),
        c = x(4438),
        ee = x(5779),
        ae = x(1880),
        A = x(1455),
        k = x(8757),
        M = x(563),
        V = x(4420);
      const $ = ["*"],
        X = Z => ({
          class: Z
        });

      function U(Z, xe) {
        1 & Z && c.eu8(0)
      }

      function le(Z, xe) {
        if (1 & Z && c.nrm(0, "span", 8), 2 & Z) {
          const be = c.XpG(3);
          c.Y8G("ngClass", be.iconClass()), c.BMQ("aria-hidden", !0)("data-pc-section", "loadingicon")
        }
      }

      function Ne(Z, xe) {
        if (1 & Z && c.nrm(0, "SpinnerIcon", 9), 2 & Z) {
          const be = c.XpG(3);
          c.Y8G("styleClass", be.spinnerIconClass())("spin", !0), c.BMQ("aria-hidden", !0)("data-pc-section",
            "loadingicon")
        }
      }

      function me(Z, xe) {
        if (1 & Z && (c.qex(0), c.DNE(1, le, 1, 3, "span", 6)(2, Ne, 1, 4, "SpinnerIcon", 7), c.bVm()), 2 & Z) {
          const be = c.XpG(2);
          c.R7$(), c.Y8G("ngIf", be.loadingIcon), c.R7$(), c.Y8G("ngIf", !be.loadingIcon)
        }
      }

      function Ae(Z, xe) {}

      function qe(Z, xe) {
        if (1 & Z && c.DNE(0, Ae, 0, 0, "ng-template", 10), 2 & Z) {
          const be = c.XpG(2);
          c.Y8G("ngIf", be.loadingIconTemplate)
        }
      }

      function we(Z, xe) {
        if (1 & Z && (c.qex(0), c.DNE(1, me, 3, 2, "ng-container", 2)(2, qe, 1, 1, null, 5), c.bVm()), 2 & Z) {
          const be = c.XpG();
          c.R7$(), c.Y8G("ngIf", !be.loadingIconTemplate), c.R7$(), c.Y8G("ngTemplateOutlet", be
            .loadingIconTemplate)("ngTemplateOutletContext", c.eq3(3, X, be.iconClass()))
        }
      }

      function Ve(Z, xe) {
        if (1 & Z && c.nrm(0, "span", 8), 2 & Z) {
          const be = c.XpG(2);
          c.Y8G("ngClass", be.iconClass()), c.BMQ("data-pc-section", "icon")
        }
      }

      function Ze(Z, xe) {}

      function vt(Z, xe) {
        if (1 & Z && c.DNE(0, Ze, 0, 0, "ng-template", 10), 2 & Z) {
          const be = c.XpG(2);
          c.Y8G("ngIf", !be.icon && be.iconTemplate)
        }
      }

      function ue(Z, xe) {
        if (1 & Z && (c.qex(0), c.DNE(1, Ve, 1, 2, "span", 6)(2, vt, 1, 1, null, 5), c.bVm()), 2 & Z) {
          const be = c.XpG();
          c.R7$(), c.Y8G("ngIf", be.icon && !be.iconTemplate), c.R7$(), c.Y8G("ngTemplateOutlet", be.iconTemplate)
            ("ngTemplateOutletContext", c.eq3(3, X, be.iconClass()))
        }
      }

      function Pe(Z, xe) {
        if (1 & Z && (c.j41(0, "span", 11), c.EFF(1), c.k0s()), 2 & Z) {
          const be = c.XpG();
          c.BMQ("aria-hidden", be.icon && !be.label)("data-pc-section", "label"), c.R7$(), c.JRh(be.label)
        }
      }

      function ie(Z, xe) {
        if (1 & Z && (c.j41(0, "span", 8), c.EFF(1), c.k0s()), 2 & Z) {
          const be = c.XpG();
          c.HbH(be.badgeClass), c.Y8G("ngClass", be.badgeStyleClass()), c.BMQ("data-pc-section", "badge"), c
          .R7$(), c.JRh(be.badge)
        }
      }
      const se = {
        button: "p-button",
        component: "p-component",
        iconOnly: "p-button-icon-only",
        disabled: "p-disabled",
        loading: "p-button-loading",
        labelOnly: "p-button-loading-label-only"
      };
      let Re = (() => {
          class Z {
            el;
            document;
            iconPos = "left";
            loadingIcon;
            get label() {
              return this._label
            }
            set label(be) {
              this._label = be, this.initialized && (this.updateLabel(), this.updateIcon(), this
                .setStyleClass())
            }
            get icon() {
              return this._icon
            }
            set icon(be) {
              this._icon = be, this.initialized && (this.updateIcon(), this.setStyleClass())
            }
            get loading() {
              return this._loading
            }
            set loading(be) {
              this._loading = be, this.initialized && (this.updateIcon(), this.setStyleClass())
            }
            severity;
            raised = !1;
            rounded = !1;
            text = !1;
            outlined = !1;
            size = null;
            plain = !1;
            _label;
            _icon;
            _loading = !1;
            initialized;
            get htmlElement() {
              return this.el.nativeElement
            }
            _internalClasses = Object.values(se);
            constructor(be, et) {
              this.el = be, this.document = et
            }
            ngAfterViewInit() {
              A.D.addMultipleClasses(this.htmlElement, this.getStyleClass().join(" ")), this.createIcon(),
                this.createLabel(), this.initialized = !0
            }
            getStyleClass() {
              const be = [se.button, se.component];
              return this.icon && !this.label && V.BF.isEmpty(this.htmlElement.textContent) && be.push(se
                  .iconOnly), this.loading && (be.push(se.disabled, se.loading), !this.icon && this.label &&
                  be.push(se.labelOnly), this.icon && !this.label && !V.BF.isEmpty(this.htmlElement
                    .textContent) && be.push(se.iconOnly)), this.text && be.push("p-button-text"), this
                .severity && be.push(`p-button-${this.severity}`), this.plain && be.push("p-button-plain"),
                this.raised && be.push("p-button-raised"), this.size && be.push(`p-button-${this.size}`), this
                .outlined && be.push("p-button-outlined"), this.rounded && be.push("p-button-rounded"),
                "small" === this.size && be.push("p-button-sm"), "large" === this.size && be.push(
                  "p-button-lg"), be
            }
            setStyleClass() {
              const be = this.getStyleClass();
              this.htmlElement.classList.remove(...this._internalClasses), this.htmlElement.classList.add(...
                be)
            }
            createLabel() {
              if (!A.D.findSingle(this.htmlElement, ".p-button-label") && this.label) {
                let et = this.document.createElement("span");
                this.icon && !this.label && et.setAttribute("aria-hidden", "true"), et.className =
                  "p-button-label", et.appendChild(this.document.createTextNode(this.label)), this.htmlElement
                  .appendChild(et)
              }
            }
            createIcon() {
              if (!A.D.findSingle(this.htmlElement, ".p-button-icon") && (this.icon || this.loading)) {
                let et = this.document.createElement("span");
                et.className = "p-button-icon", et.setAttribute("aria-hidden", "true");
                let Et = this.label ? "p-button-icon-" + this.iconPos : null;
                Et && A.D.addClass(et, Et);
                let Ht = this.getIconClass();
                Ht && A.D.addMultipleClasses(et, Ht), this.htmlElement.insertBefore(et, this.htmlElement
                  .firstChild)
              }
            }
            updateLabel() {
              let be = A.D.findSingle(this.htmlElement, ".p-button-label");
              this.label ? be ? be.textContent = this.label : this.createLabel() : be && this.htmlElement
                .removeChild(be)
            }
            updateIcon() {
              let be = A.D.findSingle(this.htmlElement, ".p-button-icon"),
                et = A.D.findSingle(this.htmlElement, ".p-button-label");
              be ? be.className = this.iconPos ? "p-button-icon " + (et ? "p-button-icon-" + this.iconPos :
                "") + " " + this.getIconClass() : "p-button-icon " + this.getIconClass() : this.createIcon()
            }
            getIconClass() {
              return this.loading ? "p-button-loading-icon pi-spin " + (this.loadingIcon ?? "pi pi-spinner") :
                this.icon || "p-hidden"
            }
            ngOnDestroy() {
              this.initialized = !1
            }
            static \u0275fac = function(et) {
              return new(et || Z)(c.rXU(c.aKT), c.rXU(g.qQ))
            };
            static \u0275dir = c.FsC({
              type: Z,
              selectors: [
                ["", "pButton", ""]
              ],
              hostAttrs: [1, "p-element"],
              inputs: {
                iconPos: "iconPos",
                loadingIcon: "loadingIcon",
                label: "label",
                icon: "icon",
                loading: "loading",
                severity: "severity",
                raised: [c.Mj6.HasDecoratorInputTransform, "raised", "raised", c.L39],
                rounded: [c.Mj6.HasDecoratorInputTransform, "rounded", "rounded", c.L39],
                text: [c.Mj6.HasDecoratorInputTransform, "text", "text", c.L39],
                outlined: [c.Mj6.HasDecoratorInputTransform, "outlined", "outlined", c.L39],
                size: "size",
                plain: [c.Mj6.HasDecoratorInputTransform, "plain", "plain", c.L39]
              },
              standalone: !0,
              features: [c.GFd]
            })
          }
          return Z
        })(),
        Be = (() => {
          class Z {
            el;
            type = "button";
            iconPos = "left";
            icon;
            badge;
            label;
            disabled;
            loading = !1;
            loadingIcon;
            raised = !1;
            rounded = !1;
            text = !1;
            plain = !1;
            severity;
            outlined = !1;
            link = !1;
            tabindex;
            size;
            style;
            styleClass;
            badgeClass;
            ariaLabel;
            autofocus;
            onClick = new c.bkB;
            onFocus = new c.bkB;
            onBlur = new c.bkB;
            contentTemplate;
            loadingIconTemplate;
            iconTemplate;
            templates;
            constructor(be) {
              this.el = be
            }
            spinnerIconClass() {
              return Object.entries(this.iconClass()).filter(([, be]) => !!be).reduce((be, [et]) => be +
                ` ${et}`, "p-button-loading-icon")
            }
            iconClass() {
              const be = {
                "p-button-icon": !0,
                "p-button-icon-left": "left" === this.iconPos && this.label,
                "p-button-icon-right": "right" === this.iconPos && this.label,
                "p-button-icon-top": "top" === this.iconPos && this.label,
                "p-button-icon-bottom": "bottom" === this.iconPos && this.label
              };
              return this.loading ? be[`p-button-loading-icon pi-spin ${this.loadingIcon??""}`] = !0 : this
                .icon && (be[this.icon] = !0), be
            }
            get buttonClass() {
              return {
                "p-button p-component": !0,
                "p-button-icon-only": (this.icon || this.iconTemplate || this.loadingIcon || this
                  .loadingIconTemplate) && !this.label,
                "p-button-vertical": ("top" === this.iconPos || "bottom" === this.iconPos) && this.label,
                "p-button-loading": this.loading,
                "p-button-loading-label-only": this.loading && !this.icon && this.label && !this
                  .loadingIcon && "left" === this.iconPos,
                "p-button-link": this.link,
                [`p-button-${this.severity}`]: this.severity,
                "p-button-raised": this.raised,
                "p-button-rounded": this.rounded,
                "p-button-text": this.text,
                "p-button-outlined": this.outlined,
                "p-button-sm": "small" === this.size,
                "p-button-lg": "large" === this.size,
                "p-button-plain": this.plain,
                [`${this.styleClass}`]: this.styleClass
              }
            }
            ngAfterContentInit() {
              this.templates?.forEach(be => {
                switch (be.getType()) {
                  case "content":
                  default:
                    this.contentTemplate = be.template;
                    break;
                  case "icon":
                    this.iconTemplate = be.template;
                    break;
                  case "loadingicon":
                    this.loadingIconTemplate = be.template
                }
              })
            }
            badgeStyleClass() {
              return {
                "p-badge p-component": !0,
                "p-badge-no-gutter": this.badge && 1 === String(this.badge).length
              }
            }
            focus() {
              this.el.nativeElement.firstChild.focus()
            }
            static \u0275fac = function(et) {
              return new(et || Z)(c.rXU(c.aKT))
            };
            static \u0275cmp = c.VBU({
              type: Z,
              selectors: [
                ["p-button"]
              ],
              contentQueries: function(et, Et, Ht) {
                if (1 & et && c.wni(Ht, ee.Ei, 4), 2 & et) {
                  let Zt;
                  c.mGM(Zt = c.lsd()) && (Et.templates = Zt)
                }
              },
              hostAttrs: [1, "p-element"],
              hostVars: 2,
              hostBindings: function(et, Et) {
                2 & et && c.AVh("p-disabled", Et.disabled)
              },
              inputs: {
                type: "type",
                iconPos: "iconPos",
                icon: "icon",
                badge: "badge",
                label: "label",
                disabled: [c.Mj6.HasDecoratorInputTransform, "disabled", "disabled", c.L39],
                loading: [c.Mj6.HasDecoratorInputTransform, "loading", "loading", c.L39],
                loadingIcon: "loadingIcon",
                raised: [c.Mj6.HasDecoratorInputTransform, "raised", "raised", c.L39],
                rounded: [c.Mj6.HasDecoratorInputTransform, "rounded", "rounded", c.L39],
                text: [c.Mj6.HasDecoratorInputTransform, "text", "text", c.L39],
                plain: [c.Mj6.HasDecoratorInputTransform, "plain", "plain", c.L39],
                severity: "severity",
                outlined: [c.Mj6.HasDecoratorInputTransform, "outlined", "outlined", c.L39],
                link: [c.Mj6.HasDecoratorInputTransform, "link", "link", c.L39],
                tabindex: [c.Mj6.HasDecoratorInputTransform, "tabindex", "tabindex", c.Udg],
                size: "size",
                style: "style",
                styleClass: "styleClass",
                badgeClass: "badgeClass",
                ariaLabel: "ariaLabel",
                autofocus: [c.Mj6.HasDecoratorInputTransform, "autofocus", "autofocus", c.L39]
              },
              outputs: {
                onClick: "onClick",
                onFocus: "onFocus",
                onBlur: "onBlur"
              },
              standalone: !0,
              features: [c.GFd, c.aNF],
              ngContentSelectors: $,
              decls: 7,
              vars: 14,
              consts: [
                ["pRipple", "", "pAutoFocus", "", 3, "click", "focus", "blur", "ngStyle", "disabled",
                  "ngClass", "autofocus"
                ],
                [4, "ngTemplateOutlet"],
                [4, "ngIf"],
                ["class", "p-button-label", 4, "ngIf"],
                [3, "ngClass", "class", 4, "ngIf"],
                [4, "ngTemplateOutlet", "ngTemplateOutletContext"],
                [3, "ngClass", 4, "ngIf"],
                [3, "styleClass", "spin", 4, "ngIf"],
                [3, "ngClass"],
                [3, "styleClass", "spin"],
                [3, "ngIf"],
                [1, "p-button-label"]
              ],
              template: function(et, Et) {
                1 & et && (c.NAR(), c.j41(0, "button", 0), c.bIt("click", function(Zt) {
                  return Et.onClick.emit(Zt)
                })("focus", function(Zt) {
                  return Et.onFocus.emit(Zt)
                })("blur", function(Zt) {
                  return Et.onBlur.emit(Zt)
                }), c.SdG(1), c.DNE(2, U, 1, 0, "ng-container", 1)(3, we, 3, 5, "ng-container", 2)(4,
                  ue, 3, 5, "ng-container", 2)(5, Pe, 2, 3, "span", 3)(6, ie, 2, 5, "span", 4), c
                .k0s()), 2 & et && (c.Y8G("ngStyle", Et.style)("disabled", Et.disabled || Et.loading)(
                    "ngClass", Et.buttonClass)("autofocus", Et.autofocus), c.BMQ("type", Et.type)(
                    "aria-label", Et.ariaLabel)("data-pc-name", "button")("data-pc-section", "root")(
                    "tabindex", Et.tabindex), c.R7$(2), c.Y8G("ngTemplateOutlet", Et.contentTemplate), c
                  .R7$(), c.Y8G("ngIf", Et.loading), c.R7$(), c.Y8G("ngIf", !Et.loading), c.R7$(), c
                  .Y8G("ngIf", !Et.contentTemplate && Et.label), c.R7$(), c.Y8G("ngIf", !Et
                    .contentTemplate && Et.badge))
              },
              dependencies: [g.bT, g.T3, g.B3, g.YU, M.n, ae.q, k.N],
              encapsulation: 2,
              changeDetection: 0
            })
          }
          return Z
        })(),
        De = (() => {
          class Z {
            static \u0275fac = function(et) {
              return new(et || Z)
            };
            static \u0275mod = c.$C({
              type: Z
            });
            static \u0275inj = c.G2t({
              imports: [Be, ee.Gg]
            })
          }
          return Z
        })()
    },
    1455: (nt, Se, x) => {
      x.d(Se, {
        D: () => g,
        b: () => c
      });
      let g = (() => {
        class ee {
          static zindex = 1e3;
          static calculatedScrollbarWidth = null;
          static calculatedScrollbarHeight = null;
          static browser;
          static addClass(A, k) {
            A && k && (A.classList ? A.classList.add(k) : A.className += " " + k)
          }
          static addMultipleClasses(A, k) {
            if (A && k)
              if (A.classList) {
                let M = k.trim().split(" ");
                for (let V = 0; V < M.length; V++) A.classList.add(M[V])
              } else {
                let M = k.split(" ");
                for (let V = 0; V < M.length; V++) A.className += " " + M[V]
              }
          }
          static removeClass(A, k) {
            A && k && (A.classList ? A.classList.remove(k) : A.className = A.className.replace(new RegExp(
              "(^|\\b)" + k.split(" ").join("|") + "(\\b|$)", "gi"), " "))
          }
          static removeMultipleClasses(A, k) {
            A && k && [k].flat().filter(Boolean).forEach(M => M.split(" ").forEach(V => this.removeClass(A,
              V)))
          }
          static hasClass(A, k) {
            return !(!A || !k) && (A.classList ? A.classList.contains(k) : new RegExp("(^| )" + k + "( |$)",
              "gi").test(A.className))
          }
          static siblings(A) {
            return Array.prototype.filter.call(A.parentNode.children, function(k) {
              return k !== A
            })
          }
          static find(A, k) {
            return Array.from(A.querySelectorAll(k))
          }
          static findSingle(A, k) {
            return this.isElement(A) ? A.querySelector(k) : null
          }
          static index(A) {
            let k = A.parentNode.childNodes,
              M = 0;
            for (var V = 0; V < k.length; V++) {
              if (k[V] == A) return M;
              1 == k[V].nodeType && M++
            }
            return -1
          }
          static indexWithinGroup(A, k) {
            let M = A.parentNode ? A.parentNode.childNodes : [],
              V = 0;
            for (var $ = 0; $ < M.length; $++) {
              if (M[$] == A) return V;
              M[$].attributes && M[$].attributes[k] && 1 == M[$].nodeType && V++
            }
            return -1
          }
          static appendOverlay(A, k, M = "self") {
            "self" !== M && A && k && this.appendChild(A, k)
          }
          static alignOverlay(A, k, M = "self", V = !0) {
            A && k && (V && (A.style.minWidth = `${ee.getOuterWidth(k)}px`), "self" === M ? this
              .relativePosition(A, k) : this.absolutePosition(A, k))
          }
          static relativePosition(A, k, M = !0) {
            const V = ue => {
                if (ue) return "relative" === getComputedStyle(ue).getPropertyValue("position") ? ue : V(ue
                  .parentElement)
              },
              $ = A.offsetParent ? {
                width: A.offsetWidth,
                height: A.offsetHeight
              } : this.getHiddenElementDimensions(A),
              X = k.offsetHeight ?? k.getBoundingClientRect().height,
              U = k.getBoundingClientRect(),
              le = this.getWindowScrollTop(),
              Ne = this.getWindowScrollLeft(),
              me = this.getViewport(),
              qe = V(A)?.getBoundingClientRect() || {
                top: -1 * le,
                left: -1 * Ne
              };
            let we, Ve;
            U.top + X + $.height > me.height ? (we = U.top - qe.top - $.height, A.style.transformOrigin =
              "bottom", U.top + we < 0 && (we = -1 * U.top)) : (we = X + U.top - qe.top, A.style
              .transformOrigin = "top");
            const Ze = U.left + $.width - me.width;
            Ve = $.width > me.width ? -1 * (U.left - qe.left) : Ze > 0 ? U.left - qe.left - Ze : U.left - qe
              .left, A.style.top = we + "px", A.style.left = Ve + "px", M && (A.style.marginTop =
                "bottom" === origin ? "calc(var(--p-anchor-gutter) * -1)" : "calc(var(--p-anchor-gutter))")
          }
          static absolutePosition(A, k, M = !0) {
            const V = A.offsetParent ? {
                width: A.offsetWidth,
                height: A.offsetHeight
              } : this.getHiddenElementDimensions(A),
              $ = V.height,
              X = V.width,
              U = k.offsetHeight ?? k.getBoundingClientRect().height,
              le = k.offsetWidth ?? k.getBoundingClientRect().width,
              Ne = k.getBoundingClientRect(),
              me = this.getWindowScrollTop(),
              Ae = this.getWindowScrollLeft(),
              qe = this.getViewport();
            let we, Ve;
            Ne.top + U + $ > qe.height ? (we = Ne.top + me - $, A.style.transformOrigin = "bottom", we <
                0 && (we = me)) : (we = U + Ne.top + me, A.style.transformOrigin = "top"), Ve = Ne.left +
              X > qe.width ? Math.max(0, Ne.left + Ae + le - X) : Ne.left + Ae, A.style.top = we + "px", A
              .style.left = Ve + "px", M && (A.style.marginTop = "bottom" === origin ?
                "calc(var(--p-anchor-gutter) * -1)" : "calc(var(--p-anchor-gutter))")
          }
          static getParents(A, k = []) {
            return null === A.parentNode ? k : this.getParents(A.parentNode, k.concat([A.parentNode]))
          }
          static getScrollableParents(A) {
            let k = [];
            if (A) {
              let M = this.getParents(A);
              const V = /(auto|scroll)/,
                $ = X => {
                  let U = window.getComputedStyle(X, null);
                  return V.test(U.getPropertyValue("overflow")) || V.test(U.getPropertyValue(
                    "overflowX")) || V.test(U.getPropertyValue("overflowY"))
                };
              for (let X of M) {
                let U = 1 === X.nodeType && X.dataset.scrollselectors;
                if (U) {
                  let le = U.split(",");
                  for (let Ne of le) {
                    let me = this.findSingle(X, Ne);
                    me && $(me) && k.push(me)
                  }
                }
                9 !== X.nodeType && $(X) && k.push(X)
              }
            }
            return k
          }
          static getHiddenElementOuterHeight(A) {
            A.style.visibility = "hidden", A.style.display = "block";
            let k = A.offsetHeight;
            return A.style.display = "none", A.style.visibility = "visible", k
          }
          static getHiddenElementOuterWidth(A) {
            A.style.visibility = "hidden", A.style.display = "block";
            let k = A.offsetWidth;
            return A.style.display = "none", A.style.visibility = "visible", k
          }
          static getHiddenElementDimensions(A) {
            let k = {};
            return A.style.visibility = "hidden", A.style.display = "block", k.width = A.offsetWidth, k
              .height = A.offsetHeight, A.style.display = "none", A.style.visibility = "visible", k
          }
          static scrollInView(A, k) {
            let M = getComputedStyle(A).getPropertyValue("borderTopWidth"),
              V = M ? parseFloat(M) : 0,
              $ = getComputedStyle(A).getPropertyValue("paddingTop"),
              X = $ ? parseFloat($) : 0,
              U = A.getBoundingClientRect(),
              Ne = k.getBoundingClientRect().top + document.body.scrollTop - (U.top + document.body
                .scrollTop) - V - X,
              me = A.scrollTop,
              Ae = A.clientHeight,
              qe = this.getOuterHeight(k);
            Ne < 0 ? A.scrollTop = me + Ne : Ne + qe > Ae && (A.scrollTop = me + Ne - Ae + qe)
          }
          static fadeIn(A, k) {
            A.style.opacity = 0;
            let M = +new Date,
              V = 0,
              $ = function() {
                V = +A.style.opacity.replace(",", ".") + ((new Date).getTime() - M) / k, A.style.opacity =
                  V, M = +new Date, +V < 1 && (window.requestAnimationFrame && requestAnimationFrame($) ||
                    setTimeout($, 16))
              };
            $()
          }
          static fadeOut(A, k) {
            var M = 1,
              X = 50 / k;
            let U = setInterval(() => {
              (M -= X) <= 0 && (M = 0, clearInterval(U)), A.style.opacity = M
            }, 50)
          }
          static getWindowScrollTop() {
            let A = document.documentElement;
            return (window.pageYOffset || A.scrollTop) - (A.clientTop || 0)
          }
          static getWindowScrollLeft() {
            let A = document.documentElement;
            return (window.pageXOffset || A.scrollLeft) - (A.clientLeft || 0)
          }
          static matches(A, k) {
            var M = Element.prototype;
            return (M.matches || M.webkitMatchesSelector || M.mozMatchesSelector || M.msMatchesSelector ||
              function($) {
                return -1 !== [].indexOf.call(document.querySelectorAll($), this)
              }).call(A, k)
          }
          static getOuterWidth(A, k) {
            let M = A.offsetWidth;
            if (k) {
              let V = getComputedStyle(A);
              M += parseFloat(V.marginLeft) + parseFloat(V.marginRight)
            }
            return M
          }
          static getHorizontalPadding(A) {
            let k = getComputedStyle(A);
            return parseFloat(k.paddingLeft) + parseFloat(k.paddingRight)
          }
          static getHorizontalMargin(A) {
            let k = getComputedStyle(A);
            return parseFloat(k.marginLeft) + parseFloat(k.marginRight)
          }
          static innerWidth(A) {
            let k = A.offsetWidth,
              M = getComputedStyle(A);
            return k += parseFloat(M.paddingLeft) + parseFloat(M.paddingRight), k
          }
          static width(A) {
            let k = A.offsetWidth,
              M = getComputedStyle(A);
            return k -= parseFloat(M.paddingLeft) + parseFloat(M.paddingRight), k
          }
          static getInnerHeight(A) {
            let k = A.offsetHeight,
              M = getComputedStyle(A);
            return k += parseFloat(M.paddingTop) + parseFloat(M.paddingBottom), k
          }
          static getOuterHeight(A, k) {
            let M = A.offsetHeight;
            if (k) {
              let V = getComputedStyle(A);
              M += parseFloat(V.marginTop) + parseFloat(V.marginBottom)
            }
            return M
          }
          static getHeight(A) {
            let k = A.offsetHeight,
              M = getComputedStyle(A);
            return k -= parseFloat(M.paddingTop) + parseFloat(M.paddingBottom) + parseFloat(M
              .borderTopWidth) + parseFloat(M.borderBottomWidth), k
          }
          static getWidth(A) {
            let k = A.offsetWidth,
              M = getComputedStyle(A);
            return k -= parseFloat(M.paddingLeft) + parseFloat(M.paddingRight) + parseFloat(M
              .borderLeftWidth) + parseFloat(M.borderRightWidth), k
          }
          static getViewport() {
            let A = window,
              k = document,
              M = k.documentElement,
              V = k.getElementsByTagName("body")[0];
            return {
              width: A.innerWidth || M.clientWidth || V.clientWidth,
              height: A.innerHeight || M.clientHeight || V.clientHeight
            }
          }
          static getOffset(A) {
            var k = A.getBoundingClientRect();
            return {
              top: k.top + (window.pageYOffset || document.documentElement.scrollTop || document.body
                .scrollTop || 0),
              left: k.left + (window.pageXOffset || document.documentElement.scrollLeft || document.body
                .scrollLeft || 0)
            }
          }
          static replaceElementWith(A, k) {
            let M = A.parentNode;
            if (!M) throw "Can't replace element";
            return M.replaceChild(k, A)
          }
          static getUserAgent() {
            if (navigator && this.isClient()) return navigator.userAgent
          }
          static isIE() {
            var A = window.navigator.userAgent;
            return A.indexOf("MSIE ") > 0 || (A.indexOf("Trident/") > 0 ? (A.indexOf("rv:"), !0) : A
              .indexOf("Edge/") > 0)
          }
          static isIOS() {
            return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream
          }
          static isAndroid() {
            return /(android)/i.test(navigator.userAgent)
          }
          static isTouchDevice() {
            return "ontouchstart" in window || navigator.maxTouchPoints > 0
          }
          static appendChild(A, k) {
            if (this.isElement(k)) k.appendChild(A);
            else {
              if (!(k && k.el && k.el.nativeElement)) throw "Cannot append " + k + " to " + A;
              k.el.nativeElement.appendChild(A)
            }
          }
          static removeChild(A, k) {
            if (this.isElement(k)) k.removeChild(A);
            else {
              if (!k.el || !k.el.nativeElement) throw "Cannot remove " + A + " from " + k;
              k.el.nativeElement.removeChild(A)
            }
          }
          static removeElement(A) {
            "remove" in Element.prototype ? A.remove() : A.parentNode.removeChild(A)
          }
          static isElement(A) {
            return "object" == typeof HTMLElement ? A instanceof HTMLElement : A && "object" == typeof A &&
              null !== A && 1 === A.nodeType && "string" == typeof A.nodeName
          }
          static calculateScrollbarWidth(A) {
            if (A) {
              let k = getComputedStyle(A);
              return A.offsetWidth - A.clientWidth - parseFloat(k.borderLeftWidth) - parseFloat(k
                .borderRightWidth)
            } {
              if (null !== this.calculatedScrollbarWidth) return this.calculatedScrollbarWidth;
              let k = document.createElement("div");
              k.className = "p-scrollbar-measure", document.body.appendChild(k);
              let M = k.offsetWidth - k.clientWidth;
              return document.body.removeChild(k), this.calculatedScrollbarWidth = M, M
            }
          }
          static calculateScrollbarHeight() {
            if (null !== this.calculatedScrollbarHeight) return this.calculatedScrollbarHeight;
            let A = document.createElement("div");
            A.className = "p-scrollbar-measure", document.body.appendChild(A);
            let k = A.offsetHeight - A.clientHeight;
            return document.body.removeChild(A), this.calculatedScrollbarWidth = k, k
          }
          static invokeElementMethod(A, k, M) {
            A[k].apply(A, M)
          }
          static clearSelection() {
            if (window.getSelection) window.getSelection().empty ? window.getSelection().empty() : window
              .getSelection().removeAllRanges && window.getSelection().rangeCount > 0 && window
              .getSelection().getRangeAt(0).getClientRects().length > 0 && window.getSelection()
              .removeAllRanges();
            else if (document.selection && document.selection.empty) try {
              document.selection.empty()
            } catch {}
          }
          static getBrowser() {
            if (!this.browser) {
              let A = this.resolveUserAgent();
              this.browser = {}, A.browser && (this.browser[A.browser] = !0, this.browser.version = A
                .version), this.browser.chrome ? this.browser.webkit = !0 : this.browser.webkit && (this
                .browser.safari = !0)
            }
            return this.browser
          }
          static resolveUserAgent() {
            let A = navigator.userAgent.toLowerCase(),
              k = /(chrome)[ \/]([\w.]+)/.exec(A) || /(webkit)[ \/]([\w.]+)/.exec(A) ||
              /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(A) || /(msie) ([\w.]+)/.exec(A) || A.indexOf(
                "compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(A) || [];
            return {
              browser: k[1] || "",
              version: k[2] || "0"
            }
          }
          static isInteger(A) {
            return Number.isInteger ? Number.isInteger(A) : "number" == typeof A && isFinite(A) && Math
              .floor(A) === A
          }
          static isHidden(A) {
            return !A || null === A.offsetParent
          }
          static isVisible(A) {
            return A && null != A.offsetParent
          }
          static isExist(A) {
            return null !== A && typeof A < "u" && A.nodeName && A.parentNode
          }
          static focus(A, k) {
            A && document.activeElement !== A && A.focus(k)
          }
          static getFocusableSelectorString(A = "") {
            return `button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A},\n        [href][clientHeight][clientWidth]:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A},\n        input:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A},\n        select:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A},\n        textarea:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A},\n        [tabIndex]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A},\n        [contenteditable]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A},\n        .p-inputtext:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A},\n        .p-button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${A}`
          }
          static getFocusableElements(A, k = "") {
            let M = this.find(A, this.getFocusableSelectorString(k)),
              V = [];
            for (let $ of M) {
              const X = getComputedStyle($);
              this.isVisible($) && "none" != X.display && "hidden" != X.visibility && V.push($)
            }
            return V
          }
          static getFocusableElement(A, k = "") {
            let M = this.findSingle(A, this.getFocusableSelectorString(k));
            if (M) {
              const V = getComputedStyle(M);
              if (this.isVisible(M) && "none" != V.display && "hidden" != V.visibility) return M
            }
            return null
          }
          static getFirstFocusableElement(A, k = "") {
            const M = this.getFocusableElements(A, k);
            return M.length > 0 ? M[0] : null
          }
          static getLastFocusableElement(A, k) {
            const M = this.getFocusableElements(A, k);
            return M.length > 0 ? M[M.length - 1] : null
          }
          static getNextFocusableElement(A, k = !1) {
            const M = ee.getFocusableElements(A);
            let V = 0;
            if (M && M.length > 0) {
              const $ = M.indexOf(M[0].ownerDocument.activeElement);
              k ? V = -1 == $ || 0 === $ ? M.length - 1 : $ - 1 : -1 != $ && $ !== M.length - 1 && (V = $ +
                1)
            }
            return M[V]
          }
          static generateZIndex() {
            return this.zindex = this.zindex || 999, ++this.zindex
          }
          static getSelection() {
            return window.getSelection ? window.getSelection().toString() : document.getSelection ? document
              .getSelection().toString() : document.selection ? document.selection.createRange().text : null
          }
          static getTargetElement(A, k) {
            if (!A) return null;
            switch (A) {
              case "document":
                return document;
              case "window":
                return window;
              case "@next":
                return k?.nextElementSibling;
              case "@prev":
                return k?.previousElementSibling;
              case "@parent":
                return k?.parentElement;
              case "@grandparent":
                return k?.parentElement.parentElement;
              default:
                const M = typeof A;
                if ("string" === M) return document.querySelector(A);
                if ("object" === M && A.hasOwnProperty("nativeElement")) return this.isExist(A
                  .nativeElement) ? A.nativeElement : void 0;
                const $ = (X = A) && X.constructor && X.call && X.apply ? A() : A;
                return $ && 9 === $.nodeType || this.isExist($) ? $ : null
            }
            var X
          }
          static isClient() {
            return !!(typeof window < "u" && window.document && window.document.createElement)
          }
          static getAttribute(A, k) {
            if (A) {
              const M = A.getAttribute(k);
              return isNaN(M) ? "true" === M || "false" === M ? "true" === M : M : +M
            }
          }
          static calculateBodyScrollbarWidth() {
            return window.innerWidth - document.documentElement.offsetWidth
          }
          static blockBodyScroll(A = "p-overflow-hidden") {
            document.body.style.setProperty("--scrollbar-width", this.calculateBodyScrollbarWidth() + "px"),
              this.addClass(document.body, A)
          }
          static unblockBodyScroll(A = "p-overflow-hidden") {
            document.body.style.removeProperty("--scrollbar-width"), this.removeClass(document.body, A)
          }
          static createElement(A, k = {}, ...M) {
            if (A) {
              const V = document.createElement(A);
              return this.setAttributes(V, k), V.append(...M), V
            }
          }
          static setAttribute(A, k = "", M) {
            this.isElement(A) && null != M && A.setAttribute(k, M)
          }
          static setAttributes(A, k = {}) {
            if (this.isElement(A)) {
              const M = (V, $) => {
                const X = A?.$attrs?.[V] ? [A?.$attrs?.[V]] : [];
                return [$].flat().reduce((U, le) => {
                  if (null != le) {
                    const Ne = typeof le;
                    if ("string" === Ne || "number" === Ne) U.push(le);
                    else if ("object" === Ne) {
                      const me = Array.isArray(le) ? M(V, le) : Object.entries(le).map(([Ae, qe]) =>
                        "style" !== V || !qe && 0 !== qe ? qe ? Ae : void 0 :
                        `${Ae.replace(/([a-z])([A-Z])/g,"$1-$2").toLowerCase()}:${qe}`);
                      U = me.length ? U.concat(me.filter(Ae => !!Ae)) : U
                    }
                  }
                  return U
                }, X)
              };
              Object.entries(k).forEach(([V, $]) => {
                if (null != $) {
                  const X = V.match(/^on(.+)/);
                  X ? A.addEventListener(X[1].toLowerCase(), $) : "pBind" === V ? this.setAttributes(A,
                    $) : ($ = "class" === V ? [...new Set(M("class", $))].join(" ").trim() :
                    "style" === V ? M("style", $).join(";").trim() : $, (A.$attrs = A.$attrs || {}) &&
                    (A.$attrs[V] = $), A.setAttribute(V, $))
                }
              })
            }
          }
          static isFocusableElement(A, k = "") {
            return !!this.isElement(A) && A.matches(
              `button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${k},\n                [href][clientHeight][clientWidth]:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${k},\n                input:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${k},\n                select:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${k},\n                textarea:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${k},\n                [tabIndex]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${k},\n                [contenteditable]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${k}`
              )
          }
        }
        return ee
      })();
      class c {
        element;
        listener;
        scrollableParents;
        constructor(ae, A = (() => {})) {
          this.element = ae, this.listener = A
        }
        bindScrollListener() {
          this.scrollableParents = g.getScrollableParents(this.element);
          for (let ae = 0; ae < this.scrollableParents.length; ae++) this.scrollableParents[ae]
            .addEventListener("scroll", this.listener)
        }
        unbindScrollListener() {
          if (this.scrollableParents)
            for (let ae = 0; ae < this.scrollableParents.length; ae++) this.scrollableParents[ae]
              .removeEventListener("scroll", this.listener)
        }
        destroy() {
          this.unbindScrollListener(), this.element = null, this.listener = null, this.scrollableParents = null
        }
      }
    },
    8757: (nt, Se, x) => {
      x.d(Se, {
        N: () => ae
      });
      var g = x(4438),
        c = x(461),
        ee = x(4420);
      let ae = (() => {
        class A extends c.h {
          pathId;
          ngOnInit() {
            this.pathId = "url(#" + (0, ee._Y)() + ")"
          }
          static \u0275fac = (() => {
            let M;
            return function($) {
              return (M || (M = g.xGo(A)))($ || A)
            }
          })();
          static \u0275cmp = g.VBU({
            type: A,
            selectors: [
              ["SpinnerIcon"]
            ],
            standalone: !0,
            features: [g.Vt3, g.aNF],
            decls: 6,
            vars: 7,
            consts: [
              ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns",
                "http://www.w3.org/2000/svg"
              ],
              ["d",
                "M6.99701 14C5.85441 13.999 4.72939 13.7186 3.72012 13.1832C2.71084 12.6478 1.84795 11.8737 1.20673 10.9284C0.565504 9.98305 0.165424 8.89526 0.041387 7.75989C-0.0826496 6.62453 0.073125 5.47607 0.495122 4.4147C0.917119 3.35333 1.59252 2.4113 2.46241 1.67077C3.33229 0.930247 4.37024 0.413729 5.4857 0.166275C6.60117 -0.0811796 7.76026 -0.0520535 8.86188 0.251112C9.9635 0.554278 10.9742 1.12227 11.8057 1.90555C11.915 2.01493 11.9764 2.16319 11.9764 2.31778C11.9764 2.47236 11.915 2.62062 11.8057 2.73C11.7521 2.78503 11.688 2.82877 11.6171 2.85864C11.5463 2.8885 11.4702 2.90389 11.3933 2.90389C11.3165 2.90389 11.2404 2.8885 11.1695 2.85864C11.0987 2.82877 11.0346 2.78503 10.9809 2.73C9.9998 1.81273 8.73246 1.26138 7.39226 1.16876C6.05206 1.07615 4.72086 1.44794 3.62279 2.22152C2.52471 2.99511 1.72683 4.12325 1.36345 5.41602C1.00008 6.70879 1.09342 8.08723 1.62775 9.31926C2.16209 10.5513 3.10478 11.5617 4.29713 12.1803C5.48947 12.7989 6.85865 12.988 8.17414 12.7157C9.48963 12.4435 10.6711 11.7264 11.5196 10.6854C12.3681 9.64432 12.8319 8.34282 12.8328 7C12.8328 6.84529 12.8943 6.69692 13.0038 6.58752C13.1132 6.47812 13.2616 6.41667 13.4164 6.41667C13.5712 6.41667 13.7196 6.47812 13.8291 6.58752C13.9385 6.69692 14 6.84529 14 7C14 8.85651 13.2622 10.637 11.9489 11.9497C10.6356 13.2625 8.85432 14 6.99701 14Z",
                "fill", "currentColor"
              ],
              [3, "id"],
              ["width", "14", "height", "14", "fill", "white"]
            ],
            template: function(V, $) {
              1 & V && (g.qSk(), g.j41(0, "svg", 0)(1, "g"), g.nrm(2, "path", 1), g.k0s(), g.j41(3,
                "defs")(4, "clipPath", 2), g.nrm(5, "rect", 3), g.k0s()()()), 2 & V && (g.HbH($
                .getClassNames()), g.BMQ("aria-label", $.ariaLabel)("aria-hidden", $.ariaHidden)(
                "role", $.role), g.R7$(), g.BMQ("clip-path", $.pathId), g.R7$(3), g.Y8G("id", $
                .pathId))
            },
            encapsulation: 2
          })
        }
        return A
      })()
    },
    1512: (nt, Se, x) => {
      x.d(Se, {
        A: () => ee
      });
      var g = x(4438),
        c = x(461);
      let ee = (() => {
        class ae extends c.h {
          static \u0275fac = (() => {
            let k;
            return function(V) {
              return (k || (k = g.xGo(ae)))(V || ae)
            }
          })();
          static \u0275cmp = g.VBU({
            type: ae,
            selectors: [
              ["TimesIcon"]
            ],
            standalone: !0,
            features: [g.Vt3, g.aNF],
            decls: 2,
            vars: 5,
            consts: [
              ["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns",
                "http://www.w3.org/2000/svg"
              ],
              ["d",
                "M8.01186 7.00933L12.27 2.75116C12.341 2.68501 12.398 2.60524 12.4375 2.51661C12.4769 2.42798 12.4982 2.3323 12.4999 2.23529C12.5016 2.13827 12.4838 2.0419 12.4474 1.95194C12.4111 1.86197 12.357 1.78024 12.2884 1.71163C12.2198 1.64302 12.138 1.58893 12.0481 1.55259C11.9581 1.51625 11.8617 1.4984 11.7647 1.50011C11.6677 1.50182 11.572 1.52306 11.4834 1.56255C11.3948 1.60204 11.315 1.65898 11.2488 1.72997L6.99067 5.98814L2.7325 1.72997C2.59553 1.60234 2.41437 1.53286 2.22718 1.53616C2.03999 1.53946 1.8614 1.61529 1.72901 1.74767C1.59663 1.88006 1.5208 2.05865 1.5175 2.24584C1.5142 2.43303 1.58368 2.61419 1.71131 2.75116L5.96948 7.00933L1.71131 11.2675C1.576 11.403 1.5 11.5866 1.5 11.7781C1.5 11.9696 1.576 12.1532 1.71131 12.2887C1.84679 12.424 2.03043 12.5 2.2219 12.5C2.41338 12.5 2.59702 12.424 2.7325 12.2887L6.99067 8.03052L11.2488 12.2887C11.3843 12.424 11.568 12.5 11.7594 12.5C11.9509 12.5 12.1346 12.424 12.27 12.2887C12.4053 12.1532 12.4813 11.9696 12.4813 11.7781C12.4813 11.5866 12.4053 11.403 12.27 11.2675L8.01186 7.00933Z",
                "fill", "currentColor"
              ]
            ],
            template: function(M, V) {
              1 & M && (g.qSk(), g.j41(0, "svg", 0), g.nrm(1, "path", 1), g.k0s()), 2 & M && (g.HbH(V
                .getClassNames()), g.BMQ("aria-label", V.ariaLabel)("aria-hidden", V.ariaHidden)(
                "role", V.role))
            },
            encapsulation: 2
          })
        }
        return ae
      })()
    },
    2242: (nt, Se, x) => {
      x.d(Se, {
        S: () => A,
        u: () => k
      });
      var g = x(4438),
        c = x(177),
        ee = x(9417),
        ae = x(5779);
      let A = (() => {
          class M {
            el;
            ngModel;
            cd;
            config;
            variant = "outlined";
            filled;
            constructor($, X, U, le) {
              this.el = $, this.ngModel = X, this.cd = U, this.config = le
            }
            ngAfterViewInit() {
              this.updateFilledState(), this.cd.detectChanges()
            }
            ngDoCheck() {
              this.updateFilledState()
            }
            onInput() {
              this.updateFilledState()
            }
            updateFilledState() {
              this.filled = this.el.nativeElement.value && this.el.nativeElement.value.length || this
                .ngModel && this.ngModel.model
            }
            static \u0275fac = function(X) {
              return new(X || M)(g.rXU(g.aKT), g.rXU(ee.vS, 8), g.rXU(g.gRc), g.rXU(ae.r1))
            };
            static \u0275dir = g.FsC({
              type: M,
              selectors: [
                ["", "pInputText", ""]
              ],
              hostAttrs: [1, "p-inputtext", "p-component", "p-element"],
              hostVars: 4,
              hostBindings: function(X, U) {
                1 & X && g.bIt("input", function(Ne) {
                  return U.onInput(Ne)
                }), 2 & X && g.AVh("p-filled", U.filled)("p-variant-filled", "filled" === U.variant ||
                  "filled" === U.config.inputStyle())
              },
              inputs: {
                variant: "variant"
              }
            })
          }
          return M
        })(),
        k = (() => {
          class M {
            static \u0275fac = function(X) {
              return new(X || M)
            };
            static \u0275mod = g.$C({
              type: M
            });
            static \u0275inj = g.G2t({
              imports: [c.MD]
            })
          }
          return M
        })()
    },
    494: (nt, Se, x) => {
      x.d(Se, {
        Ko: () => me,
        a: () => Ne
      });
      var g = x(177),
        c = x(4438),
        ee = x(9417),
        ae = x(1880),
        A = x(5779);
      const k = ["input"],
        M = (Ae, qe, we, Ve) => ({
          "p-radiobutton p-component": !0,
          "p-radiobutton-checked": Ae,
          "p-radiobutton-disabled": qe,
          "p-radiobutton-focused": we,
          "p-variant-filled": Ve
        }),
        V = (Ae, qe, we) => ({
          "p-radiobutton-box": !0,
          "p-highlight": Ae,
          "p-disabled": qe,
          "p-focus": we
        }),
        $ = (Ae, qe, we) => ({
          "p-radiobutton-label": !0,
          "p-radiobutton-label-active": Ae,
          "p-disabled": qe,
          "p-radiobutton-label-focus": we
        });

      function X(Ae, qe) {
        if (1 & Ae) {
          const we = c.RV6();
          c.j41(0, "label", 7), c.bIt("click", function(Ze) {
            c.eBV(we);
            const vt = c.XpG();
            return c.Njj(vt.select(Ze))
          }), c.EFF(1), c.k0s()
        }
        if (2 & Ae) {
          const we = c.XpG(),
            Ve = c.sdS(3);
          c.HbH(we.labelStyleClass), c.Y8G("ngClass", c.sMw(6, $, Ve.checked, we.disabled, we.focused)), c.BMQ(
            "for", we.inputId)("data-pc-section", "label"), c.R7$(), c.JRh(we.label)
        }
      }
      const U = {
        provide: ee.kq,
        useExisting: (0, c.Rfq)(() => Ne),
        multi: !0
      };
      let le = (() => {
          class Ae {
            accessors = [];
            add(we, Ve) {
              this.accessors.push([we, Ve])
            }
            remove(we) {
              this.accessors = this.accessors.filter(Ve => Ve[1] !== we)
            }
            select(we) {
              this.accessors.forEach(Ve => {
                this.isSameGroup(Ve, we) && Ve[1] !== we && Ve[1].writeValue(we.value)
              })
            }
            isSameGroup(we, Ve) {
              return !!we[0].control && we[0].control.root === Ve.control.control.root && we[1].name === Ve
                .name
            }
            static \u0275fac = function(Ve) {
              return new(Ve || Ae)
            };
            static \u0275prov = c.jDH({
              token: Ae,
              factory: Ae.\u0275fac,
              providedIn: "root"
            })
          }
          return Ae
        })(),
        Ne = (() => {
          class Ae {
            cd;
            injector;
            registry;
            config;
            value;
            formControlName;
            name;
            disabled;
            label;
            variant = "outlined";
            tabindex;
            inputId;
            ariaLabelledBy;
            ariaLabel;
            style;
            styleClass;
            labelStyleClass;
            autofocus;
            onClick = new c.bkB;
            onFocus = new c.bkB;
            onBlur = new c.bkB;
            inputViewChild;
            onModelChange = () => {};
            onModelTouched = () => {};
            checked;
            focused;
            control;
            constructor(we, Ve, Ze, vt) {
              this.cd = we, this.injector = Ve, this.registry = Ze, this.config = vt
            }
            ngOnInit() {
              this.control = this.injector.get(ee.vO), this.checkName(), this.registry.add(this.control, this)
            }
            handleClick(we, Ve, Ze) {
              we.preventDefault(), !this.disabled && (this.select(we), Ze && Ve.focus())
            }
            select(we) {
              this.disabled || (this.inputViewChild.nativeElement.checked = !0, this.checked = !0, this
                .onModelChange(this.value), this.registry.select(this), this.onClick.emit({
                  originalEvent: we,
                  value: this.value
                }))
            }
            writeValue(we) {
              this.checked = we == this.value, this.inputViewChild && this.inputViewChild.nativeElement && (
                this.inputViewChild.nativeElement.checked = this.checked), this.cd.markForCheck()
            }
            registerOnChange(we) {
              this.onModelChange = we
            }
            registerOnTouched(we) {
              this.onModelTouched = we
            }
            setDisabledState(we) {
              this.disabled = we, this.cd.markForCheck()
            }
            onInputFocus(we) {
              this.focused = !0, this.onFocus.emit(we)
            }
            onInputBlur(we) {
              this.focused = !1, this.onModelTouched(), this.onBlur.emit(we)
            }
            focus() {
              this.inputViewChild.nativeElement.focus()
            }
            ngOnDestroy() {
              this.registry.remove(this)
            }
            checkName() {
              this.name && this.formControlName && this.name !== this.formControlName && this
              .throwNameError(), !this.name && this.formControlName && (this.name = this.formControlName)
            }
            throwNameError() {
              throw new Error(
                '\n          If you define both a name and a formControlName attribute on your radio button, their values\n          must match. Ex: <p-radioButton formControlName="food" name="food"></p-radioButton>\n        '
                )
            }
            static \u0275fac = function(Ve) {
              return new(Ve || Ae)(c.rXU(c.gRc), c.rXU(c.zZn), c.rXU(le), c.rXU(A.r1))
            };
            static \u0275cmp = c.VBU({
              type: Ae,
              selectors: [
                ["p-radioButton"]
              ],
              viewQuery: function(Ve, Ze) {
                if (1 & Ve && c.GBs(k, 5), 2 & Ve) {
                  let vt;
                  c.mGM(vt = c.lsd()) && (Ze.inputViewChild = vt.first)
                }
              },
              hostAttrs: [1, "p-element"],
              inputs: {
                value: "value",
                formControlName: "formControlName",
                name: "name",
                disabled: [c.Mj6.HasDecoratorInputTransform, "disabled", "disabled", c.L39],
                label: "label",
                variant: "variant",
                tabindex: [c.Mj6.HasDecoratorInputTransform, "tabindex", "tabindex", c.Udg],
                inputId: "inputId",
                ariaLabelledBy: "ariaLabelledBy",
                ariaLabel: "ariaLabel",
                style: "style",
                styleClass: "styleClass",
                labelStyleClass: "labelStyleClass",
                autofocus: [c.Mj6.HasDecoratorInputTransform, "autofocus", "autofocus", c.L39]
              },
              outputs: {
                onClick: "onClick",
                onFocus: "onFocus",
                onBlur: "onBlur"
              },
              features: [c.Jv_([U]), c.GFd],
              decls: 7,
              vars: 31,
              consts: [
                ["input", ""],
                [3, "click", "ngStyle", "ngClass"],
                [1, "p-hidden-accessible"],
                ["type", "radio", "pAutoFocus", "", 3, "focus", "blur", "checked", "disabled", "value",
                  "autofocus"
                ],
                [3, "ngClass"],
                [1, "p-radiobutton-icon"],
                [3, "class", "ngClass", "click", 4, "ngIf"],
                [3, "click", "ngClass"]
              ],
              template: function(Ve, Ze) {
                if (1 & Ve) {
                  const vt = c.RV6();
                  c.j41(0, "div", 1), c.bIt("click", function(Pe) {
                    c.eBV(vt);
                    const ie = c.sdS(3);
                    return c.Njj(Ze.handleClick(Pe, ie, !0))
                  }), c.j41(1, "div", 2)(2, "input", 3, 0), c.bIt("focus", function(Pe) {
                    return c.eBV(vt), c.Njj(Ze.onInputFocus(Pe))
                  })("blur", function(Pe) {
                    return c.eBV(vt), c.Njj(Ze.onInputBlur(Pe))
                  }), c.k0s()(), c.j41(4, "div", 4), c.nrm(5, "span", 5), c.k0s()(), c.DNE(6, X, 2, 10,
                    "label", 6)
                }
                2 & Ve && (c.HbH(Ze.styleClass), c.Y8G("ngStyle", Ze.style)("ngClass", c.ziG(22, M, Ze
                    .checked, Ze.disabled, Ze.focused, "filled" === Ze.variant || "filled" === Ze
                    .config.inputStyle())), c.BMQ("data-pc-name", "radiobutton")("data-pc-section",
                    "root"), c.R7$(), c.BMQ("data-pc-section", "hiddenInputWrapper"), c.R7$(), c.Y8G(
                    "checked", Ze.checked)("disabled", Ze.disabled)("value", Ze.value)("autofocus", Ze
                    .autofocus), c.BMQ("id", Ze.inputId)("name", Ze.name)("aria-labelledby", Ze
                    .ariaLabelledBy)("aria-label", Ze.ariaLabel)("tabindex", Ze.tabindex)(
                    "aria-checked", Ze.checked)("data-pc-section", "hiddenInput"), c.R7$(2), c.Y8G(
                    "ngClass", c.sMw(27, V, Ze.checked, Ze.disabled, Ze.focused)), c.BMQ(
                    "data-pc-section", "input"), c.R7$(), c.BMQ("data-pc-section", "icon"), c.R7$(), c
                  .Y8G("ngIf", Ze.label))
              },
              dependencies: [g.YU, g.bT, g.B3, ae.q],
              encapsulation: 2,
              changeDetection: 0
            })
          }
          return Ae
        })(),
        me = (() => {
          class Ae {
            static \u0275fac = function(Ve) {
              return new(Ve || Ae)
            };
            static \u0275mod = c.$C({
              type: Ae
            });
            static \u0275inj = c.G2t({
              imports: [g.MD, ae.u]
            })
          }
          return Ae
        })()
    },
    563: (nt, Se, x) => {
      x.d(Se, {
        Z: () => k,
        n: () => A
      });
      var g = x(177),
        c = x(4438),
        ee = x(1455),
        ae = x(5779);
      let A = (() => {
          class M {
            document;
            platformId;
            renderer;
            el;
            zone;
            config;
            constructor($, X, U, le, Ne, me) {
              this.document = $, this.platformId = X, this.renderer = U, this.el = le, this.zone = Ne, this
                .config = me
            }
            animationListener;
            mouseDownListener;
            timeout;
            ngAfterViewInit() {
              (0, g.UE)(this.platformId) && this.config && this.config.ripple && this.zone.runOutsideAngular(
              () => {
                this.create(), this.mouseDownListener = this.renderer.listen(this.el.nativeElement,
                  "mousedown", this.onMouseDown.bind(this))
              })
            }
            onMouseDown($) {
              let X = this.getInk();
              if (!X || "none" === this.document.defaultView?.getComputedStyle(X, null).display) return;
              if (ee.D.removeClass(X, "p-ink-active"), !ee.D.getHeight(X) && !ee.D.getWidth(X)) {
                let me = Math.max(ee.D.getOuterWidth(this.el.nativeElement), ee.D.getOuterHeight(this.el
                  .nativeElement));
                X.style.height = me + "px", X.style.width = me + "px"
              }
              let U = ee.D.getOffset(this.el.nativeElement),
                le = $.pageX - U.left + this.document.body.scrollTop - ee.D.getWidth(X) / 2,
                Ne = $.pageY - U.top + this.document.body.scrollLeft - ee.D.getHeight(X) / 2;
              this.renderer.setStyle(X, "top", Ne + "px"), this.renderer.setStyle(X, "left", le + "px"), ee.D
                .addClass(X, "p-ink-active"), this.timeout = setTimeout(() => {
                  let me = this.getInk();
                  me && ee.D.removeClass(me, "p-ink-active")
                }, 401)
            }
            getInk() {
              const $ = this.el.nativeElement.children;
              for (let X = 0; X < $.length; X++)
                if ("string" == typeof $[X].className && -1 !== $[X].className.indexOf("p-ink")) return $[X];
              return null
            }
            resetInk() {
              let $ = this.getInk();
              $ && ee.D.removeClass($, "p-ink-active")
            }
            onAnimationEnd($) {
              this.timeout && clearTimeout(this.timeout), ee.D.removeClass($.currentTarget, "p-ink-active")
            }
            create() {
              let $ = this.renderer.createElement("span");
              this.renderer.addClass($, "p-ink"), this.renderer.appendChild(this.el.nativeElement, $), this
                .renderer.setAttribute($, "aria-hidden", "true"), this.renderer.setAttribute($, "role",
                  "presentation"), this.animationListener || (this.animationListener = this.renderer.listen($,
                  "animationend", this.onAnimationEnd.bind(this)))
            }
            remove() {
              let $ = this.getInk();
              $ && (this.mouseDownListener && this.mouseDownListener(), this.animationListener && this
                .animationListener(), this.mouseDownListener = null, this.animationListener = null, ee.D
                .removeElement($))
            }
            ngOnDestroy() {
              this.config && this.config.ripple && this.remove()
            }
            static \u0275fac = function(X) {
              return new(X || M)(c.rXU(g.qQ), c.rXU(c.Agw), c.rXU(c.sFG), c.rXU(c.aKT), c.rXU(c.SKi), c.rXU(ae
                .r1, 8))
            };
            static \u0275dir = c.FsC({
              type: M,
              selectors: [
                ["", "pRipple", ""]
              ],
              hostAttrs: [1, "p-ripple", "p-element"],
              standalone: !0
            })
          }
          return M
        })(),
        k = (() => {
          class M {
            static \u0275fac = function(X) {
              return new(X || M)
            };
            static \u0275mod = c.$C({
              type: M
            });
            static \u0275inj = c.G2t({})
          }
          return M
        })()
    },
    4420: (nt, Se, x) => {
      x.d(Se, {
        BF: () => g,
        Q$: () => A,
        _Y: () => ee
      });
      class g {
        static isArray(M, V = !0) {
          return Array.isArray(M) && (V || 0 !== M.length)
        }
        static isObject(M, V = !0) {
          return "object" == typeof M && !Array.isArray(M) && null != M && (V || 0 !== Object.keys(M).length)
        }
        static equals(M, V, $) {
          return $ ? this.resolveFieldData(M, $) === this.resolveFieldData(V, $) : this.equalsByValue(M, V)
        }
        static equalsByValue(M, V) {
          if (M === V) return !0;
          if (M && V && "object" == typeof M && "object" == typeof V) {
            var U, le, Ne, $ = Array.isArray(M),
              X = Array.isArray(V);
            if ($ && X) {
              if ((le = M.length) != V.length) return !1;
              for (U = le; 0 != U--;)
                if (!this.equalsByValue(M[U], V[U])) return !1;
              return !0
            }
            if ($ != X) return !1;
            var me = this.isDate(M),
              Ae = this.isDate(V);
            if (me != Ae) return !1;
            if (me && Ae) return M.getTime() == V.getTime();
            var qe = M instanceof RegExp,
              we = V instanceof RegExp;
            if (qe != we) return !1;
            if (qe && we) return M.toString() == V.toString();
            var Ve = Object.keys(M);
            if ((le = Ve.length) !== Object.keys(V).length) return !1;
            for (U = le; 0 != U--;)
              if (!Object.prototype.hasOwnProperty.call(V, Ve[U])) return !1;
            for (U = le; 0 != U--;)
              if (!this.equalsByValue(M[Ne = Ve[U]], V[Ne])) return !1;
            return !0
          }
          return M != M && V != V
        }
        static resolveFieldData(M, V) {
          if (M && V) {
            if (this.isFunction(V)) return V(M);
            if (-1 == V.indexOf(".")) return M[V];
            {
              let $ = V.split("."),
                X = M;
              for (let U = 0, le = $.length; U < le; ++U) {
                if (null == X) return null;
                X = X[$[U]]
              }
              return X
            }
          }
          return null
        }
        static isFunction(M) {
          return !!(M && M.constructor && M.call && M.apply)
        }
        static reorderArray(M, V, $) {
          M && V !== $ && ($ >= M.length && ($ %= M.length, V %= M.length), M.splice($, 0, M.splice(V, 1)[0]))
        }
        static insertIntoOrderedArray(M, V, $, X) {
          if ($.length > 0) {
            let U = !1;
            for (let le = 0; le < $.length; le++)
              if (this.findIndexInList($[le], X) > V) {
                $.splice(le, 0, M), U = !0;
                break
              } U || $.push(M)
          } else $.push(M)
        }
        static findIndexInList(M, V) {
          let $ = -1;
          if (V)
            for (let X = 0; X < V.length; X++)
              if (V[X] == M) {
                $ = X;
                break
              } return $
        }
        static contains(M, V) {
          if (null != M && V && V.length)
            for (let $ of V)
              if (this.equals(M, $)) return !0;
          return !1
        }
        static removeAccents(M) {
          return M && (M = M.normalize("NFKD").replace(new RegExp("\\p{Diacritic}", "gu"), "")), M
        }
        static isDate(M) {
          return "[object Date]" === Object.prototype.toString.call(M)
        }
        static isEmpty(M) {
          return null == M || "" === M || Array.isArray(M) && 0 === M.length || !this.isDate(M) && "object" ==
            typeof M && 0 === Object.keys(M).length
        }
        static isNotEmpty(M) {
          return !this.isEmpty(M)
        }
        static compare(M, V, $, X = 1) {
          let U = -1;
          const le = this.isEmpty(M),
            Ne = this.isEmpty(V);
          return U = le && Ne ? 0 : le ? X : Ne ? -X : "string" == typeof M && "string" == typeof V ? M
            .localeCompare(V, $, {
              numeric: !0
            }) : M < V ? -1 : M > V ? 1 : 0, U
        }
        static sort(M, V, $ = 1, X, U = 1) {
          const le = g.compare(M, V, X, $);
          let Ne = $;
          return (g.isEmpty(M) || g.isEmpty(V)) && (Ne = 1 === U ? $ : U), Ne * le
        }
        static merge(M, V) {
          if (null != M || null != V) return null != M && "object" != typeof M || null != V && "object" !=
            typeof V ? null != M && "string" != typeof M || null != V && "string" != typeof V ? V || M : [M ||
              "", V || ""
            ].join(" ") : {
              ...M || {},
              ...V || {}
            }
        }
        static isPrintableCharacter(M = "") {
          return this.isNotEmpty(M) && 1 === M.length && M.match(/\S| /)
        }
        static getItemValue(M, ...V) {
          return this.isFunction(M) ? M(...V) : M
        }
        static findLastIndex(M, V) {
          let $ = -1;
          if (this.isNotEmpty(M)) try {
            $ = M.findLastIndex(V)
          } catch {
            $ = M.lastIndexOf([...M].reverse().find(V))
          }
          return $
        }
        static findLast(M, V) {
          let $;
          if (this.isNotEmpty(M)) try {
            $ = M.findLast(V)
          } catch {
            $ = [...M].reverse().find(V)
          }
          return $
        }
        static deepEquals(M, V) {
          if (M === V) return !0;
          if (M && V && "object" == typeof M && "object" == typeof V) {
            var U, le, Ne, $ = Array.isArray(M),
              X = Array.isArray(V);
            if ($ && X) {
              if ((le = M.length) != V.length) return !1;
              for (U = le; 0 != U--;)
                if (!this.deepEquals(M[U], V[U])) return !1;
              return !0
            }
            if ($ != X) return !1;
            var me = M instanceof Date,
              Ae = V instanceof Date;
            if (me != Ae) return !1;
            if (me && Ae) return M.getTime() == V.getTime();
            var qe = M instanceof RegExp,
              we = V instanceof RegExp;
            if (qe != we) return !1;
            if (qe && we) return M.toString() == V.toString();
            var Ve = Object.keys(M);
            if ((le = Ve.length) !== Object.keys(V).length) return !1;
            for (U = le; 0 != U--;)
              if (!Object.prototype.hasOwnProperty.call(V, Ve[U])) return !1;
            for (U = le; 0 != U--;)
              if (!this.deepEquals(M[Ne = Ve[U]], V[Ne])) return !1;
            return !0
          }
          return M != M && V != V
        }
      }
      var c = 0;

      function ee(k = "pn_id_") {
        return `${k}${++c}`
      }
      var A = function ae() {
        let k = [];
        const X = U => U && parseInt(U.style.zIndex, 10) || 0;
        return {
          get: X,
          set: (U, le, Ne) => {
            le && (le.style.zIndex = String(((U, le) => {
              let Ne = k.length > 0 ? k[k.length - 1] : {
                  key: U,
                  value: le
                },
                me = Ne.value + (Ne.key === U ? 0 : le) + 2;
              return k.push({
                key: U,
                value: me
              }), me
            })(U, Ne)))
          },
          clear: U => {
            U && ((U => {
              k = k.filter(le => le.value !== U)
            })(X(U)), U.style.zIndex = "")
          },
          getCurrent: () => k.length > 0 ? k[k.length - 1].value : 0
        }
      }()
    },
    467: (nt, Se, x) => {
      function g(ee, ae, A, k, M, V, $) {
        try {
          var X = ee[V]($),
            U = X.value
        } catch (le) {
          return void A(le)
        }
        X.done ? ae(U) : Promise.resolve(U).then(k, M)
      }

      function c(ee) {
        return function() {
          var ae = this,
            A = arguments;
          return new Promise(function(k, M) {
            var V = ee.apply(ae, A);

            function $(U) {
              g(V, k, M, $, X, "next", U)
            }

            function X(U) {
              g(V, k, M, $, X, "throw", U)
            }
            $(void 0)
          })
        }
      }
      x.d(Se, {
        A: () => c
      })
    },
    1635: (nt, Se, x) => {
      function le(he, ye, ve, Ce) {
        return new(ve || (ve = Promise))(function(Le, rt) {
          function Nt(Ut) {
            try {
              ht(Ce.next(Ut))
            } catch (nn) {
              rt(nn)
            }
          }

          function ln(Ut) {
            try {
              ht(Ce.throw(Ut))
            } catch (nn) {
              rt(nn)
            }
          }

          function ht(Ut) {
            Ut.done ? Le(Ut.value) : function ke(Le) {
              return Le instanceof ve ? Le : new ve(function(rt) {
                rt(Le)
              })
            }(Ut.value).then(Nt, ln)
          }
          ht((Ce = Ce.apply(he, ye || [])).next())
        })
      }

      function ue(he) {
        return this instanceof ue ? (this.v = he, this) : new ue(he)
      }

      function Pe(he, ye, ve) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var ke, Ce = ve.apply(he, ye || []),
          Le = [];
        return ke = {}, Nt("next"), Nt("throw"), Nt("return", function rt(Ct) {
          return function(dn) {
            return Promise.resolve(dn).then(Ct, nn)
          }
        }), ke[Symbol.asyncIterator] = function() {
          return this
        }, ke;

        function Nt(Ct, dn) {
          Ce[Ct] && (ke[Ct] = function(Un) {
            return new Promise(function(rn, Nn) {
              Le.push([Ct, Un, rn, Nn]) > 1 || ln(Ct, Un)
            })
          }, dn && (ke[Ct] = dn(ke[Ct])))
        }

        function ln(Ct, dn) {
          try {
            ! function ht(Ct) {
              Ct.value instanceof ue ? Promise.resolve(Ct.value.v).then(Ut, nn) : bt(Le[0][2], Ct)
            }(Ce[Ct](dn))
          } catch (Un) {
            bt(Le[0][3], Un)
          }
        }

        function Ut(Ct) {
          ln("next", Ct)
        }

        function nn(Ct) {
          ln("throw", Ct)
        }

        function bt(Ct, dn) {
          Ct(dn), Le.shift(), Le.length && ln(Le[0][0], Le[0][1])
        }
      }

      function se(he) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var ve, ye = he[Symbol.asyncIterator];
        return ye ? ye.call(he) : (he = function qe(he) {
          var ye = "function" == typeof Symbol && Symbol.iterator,
            ve = ye && he[ye],
            Ce = 0;
          if (ve) return ve.call(he);
          if (he && "number" == typeof he.length) return {
            next: function() {
              return he && Ce >= he.length && (he = void 0), {
                value: he && he[Ce++],
                done: !he
              }
            }
          };
          throw new TypeError(ye ? "Object is not iterable." : "Symbol.iterator is not defined.")
        }(he), ve = {}, Ce("next"), Ce("throw"), Ce("return"), ve[Symbol.asyncIterator] = function() {
          return this
        }, ve);

        function Ce(Le) {
          ve[Le] = he[Le] && function(rt) {
            return new Promise(function(Nt, ln) {
              ! function ke(Le, rt, Nt, ln) {
                Promise.resolve(ln).then(function(ht) {
                  Le({
                    value: ht,
                    done: Nt
                  })
                }, rt)
              }(Nt, ln, (rt = he[Le](rt)).done, rt.value)
            })
          }
        }
      }
      x.d(Se, {
        AQ: () => Pe,
        N3: () => ue,
        sH: () => le,
        xN: () => se
      }), "function" == typeof SuppressedError && SuppressedError
    }
  },
  nt => {
    nt(nt.s = 541)
  }
]);