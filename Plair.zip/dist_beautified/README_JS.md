# PlairGrid frontend — de-minified, not decompiled

This is the Angular frontend bundled into the exe (`dist/` next to the Flask
backend). Important distinction from the Python side: this is a **production
webpack/Terser build with no source maps shipped**, so what follows is
de-minification (pretty-printing) only — it restores readable formatting,
not the original TypeScript source, file structure, or variable/class names.
A true decompile back to the original `.ts`/`.html`/`.scss` source files is
only possible when a `.js.map` file is present; none were bundled here.

## What's in this folder

- `main.84b28546dbfa79a0.js` — the app's own Angular code: `AppComponent`,
  a 404 page, routing setup, and (based on the config literal at the top)
  reads `apiBaseUrl` from `location.origin` in production — i.e. the
  frontend expects the Flask backend on the same origin/port it's served
  from.
- `191.2d25523357b77b27.js` — a lazy-loaded Angular feature module,
  internally named `MachinesModule` (still a webpack-numbered chunk, but
  the module class name itself survived minification) — almost certainly
  the UI for the "Rapid-C+ machines" the Flask backend discovers via mDNS.
- `polyfills.065e215a8a6c65a4.js` — standard Angular/zone.js polyfills,
  not app code.
- `runtime.1d1f648c49442e8e.js` — the webpack chunk-loading runtime, not
  app code.
- `scripts.30829d5c1d7be051.js` — this is **ApexCharts**, a third-party
  charting library bundled as a vendor script, not PlairGrid's own code
  (visible from its UMD wrapper: `... .ApexCharts=Y() ...`).
- `styles.5aa9722d01a4ecbd.css` — the compiled/bundled stylesheet,
  pretty-printed (still generated CSS, e.g. from SCSS + PrimeNG/PrimeFlex
  utility classes — not the original `.scss` sources).

## What you can and can't get back from this

You can read control flow, template structure (Angular's compiled
`template: function(...)` bodies are functionally equivalent to the
original HTML templates, just verbose), API calls, and constants like the
`_plair._tcp.local.` service name or API paths. You cannot recover:
component/property names beyond what a minifier happened to leave alone
(mostly public Angular framework hooks like `ngOnInit`, decorators'
metadata keys), the original file/folder layout, comments, or the
`.scss`/`.html` template source files — none of that survives a
source-map-free minified build.

## How this was produced

Ran the pure-Python port of `js-beautify` (from
github.com/beautify-web/js-beautify, `python/jsbeautifier`) against each
bundled `.js`/`.css` file — a formatter, not a deobfuscator: it re-adds
whitespace/indentation from the AST it parses, but performs no renaming
or webpack-module splitting.
