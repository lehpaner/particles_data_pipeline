! function(fe, Y) {
  "object" == typeof exports && typeof module < "u" ? module.exports = Y() : "function" == typeof define && define.amd ?
    define(Y) : (fe = typeof globalThis < "u" ? globalThis : fe || self).ApexCharts = Y()
}(this, function() {
  "use strict";

  function fe(w, e) {
    var t = Object.keys(w);
    if (Object.getOwnPropertySymbols) {
      var i = Object.getOwnPropertySymbols(w);
      e && (i = i.filter(function(a) {
        return Object.getOwnPropertyDescriptor(w, a).enumerable
      })), t.push.apply(t, i)
    }
    return t
  }

  function Y(w) {
    for (var e = 1; e < arguments.length; e++) {
      var t = null != arguments[e] ? arguments[e] : {};
      e % 2 ? fe(Object(t), !0).forEach(function(i) {
        ne(w, i, t[i])
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(w, Object.getOwnPropertyDescriptors(t)) : fe(
        Object(t)).forEach(function(i) {
        Object.defineProperty(w, i, Object.getOwnPropertyDescriptor(t, i))
      })
    }
    return w
  }

  function $(w) {
    return ($ = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
      return typeof e
    } : function(e) {
      return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" :
        typeof e
    })(w)
  }

  function F(w, e) {
    if (!(w instanceof e)) throw new TypeError("Cannot call a class as a function")
  }

  function Ne(w, e) {
    for (var t = 0; t < e.length; t++) {
      var i = e[t];
      i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object
        .defineProperty(w, i.key, i)
    }
  }

  function R(w, e, t) {
    return e && Ne(w.prototype, e), t && Ne(w, t), w
  }

  function ne(w, e, t) {
    return e in w ? Object.defineProperty(w, e, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : w[e] = t, w
  }

  function xe(w, e) {
    if ("function" != typeof e && null !== e) throw new TypeError(
      "Super expression must either be null or a function");
    w.prototype = Object.create(e && e.prototype, {
      constructor: {
        value: w,
        writable: !0,
        configurable: !0
      }
    }), e && Ie(w, e)
  }

  function Ce(w) {
    return (Ce = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
      return e.__proto__ || Object.getPrototypeOf(e)
    })(w)
  }

  function Ie(w, e) {
    return (Ie = Object.setPrototypeOf || function(t, i) {
      return t.__proto__ = i, t
    })(w, e)
  }

  function We(w) {
    if (void 0 === w) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return w
  }

  function be(w) {
    var e = function() {
      if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham) return !1;
      if ("function" == typeof Proxy) return !0;
      try {
        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
      } catch {
        return !1
      }
    }();
    return function() {
      var t, i = Ce(w);
      if (e) {
        var a = Ce(this).constructor;
        t = Reflect.construct(i, arguments, a)
      } else t = i.apply(this, arguments);
      return function(s, r) {
        if (r && ("object" == typeof r || "function" == typeof r)) return r;
        if (void 0 !== r) throw new TypeError("Derived constructors may only return object or undefined");
        return We(s)
      }(this, t)
    }
  }

  function Be(w, e) {
    return function(t) {
      if (Array.isArray(t)) return t
    }(w) || function(t, i) {
      var a = null == t ? null : typeof Symbol < "u" && t[Symbol.iterator] || t["@@iterator"];
      if (null != a) {
        var s, r, n = [],
          o = !0,
          l = !1;
        try {
          for (a = a.call(t); !(o = (s = a.next()).done) && (n.push(s.value), !i || n.length !== i); o = !0);
        } catch (c) {
          l = !0, r = c
        } finally {
          try {
            o || null == a.return || a.return()
          } finally {
            if (l) throw r
          }
        }
        return n
      }
    }(w, e) || Ge(w, e) || function() {
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        )
    }()
  }

  function J(w) {
    return function(e) {
      if (Array.isArray(e)) return Te(e)
    }(w) || function(e) {
      if (typeof Symbol < "u" && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
    }(w) || Ge(w) || function() {
      throw new TypeError(
        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        )
    }()
  }

  function Ge(w, e) {
    if (w) {
      if ("string" == typeof w) return Te(w, e);
      var t = Object.prototype.toString.call(w).slice(8, -1);
      return "Object" === t && w.constructor && (t = w.constructor.name), "Map" === t || "Set" === t ? Array.from(w) :
        "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? Te(w, e) : void 0
    }
  }

  function Te(w, e) {
    (null == e || e > w.length) && (e = w.length);
    for (var t = 0, i = new Array(e); t < e; t++) i[t] = w[t];
    return i
  }
  var P = function() {
      function w() {
        F(this, w)
      }
      return R(w, [{
        key: "shadeRGBColor",
        value: function(e, t) {
          var i = t.split(","),
            a = e < 0 ? 0 : 255,
            s = e < 0 ? -1 * e : e,
            r = parseInt(i[0].slice(4), 10),
            n = parseInt(i[1], 10),
            o = parseInt(i[2], 10);
          return "rgb(" + (Math.round((a - r) * s) + r) + "," + (Math.round((a - n) * s) + n) + "," + (Math
            .round((a - o) * s) + o) + ")"
        }
      }, {
        key: "shadeHexColor",
        value: function(e, t) {
          var i = parseInt(t.slice(1), 16),
            a = e < 0 ? 0 : 255,
            s = e < 0 ? -1 * e : e,
            r = i >> 16,
            n = i >> 8 & 255,
            o = 255 & i;
          return "#" + (16777216 + 65536 * (Math.round((a - r) * s) + r) + 256 * (Math.round((a - n) * s) +
            n) + (Math.round((a - o) * s) + o)).toString(16).slice(1)
        }
      }, {
        key: "shadeColor",
        value: function(e, t) {
          return w.isColorHex(t) ? this.shadeHexColor(e, t) : this.shadeRGBColor(e, t)
        }
      }], [{
        key: "bind",
        value: function(e, t) {
          return function() {
            return e.apply(t, arguments)
          }
        }
      }, {
        key: "isObject",
        value: function(e) {
          return e && "object" === $(e) && !Array.isArray(e) && null != e
        }
      }, {
        key: "is",
        value: function(e, t) {
          return Object.prototype.toString.call(t) === "[object " + e + "]"
        }
      }, {
        key: "listToArray",
        value: function(e) {
          var t, i = [];
          for (t = 0; t < e.length; t++) i[t] = e[t];
          return i
        }
      }, {
        key: "extend",
        value: function(e, t) {
          var i = this;
          "function" != typeof Object.assign && (Object.assign = function(s) {
            if (null == s) throw new TypeError("Cannot convert undefined or null to object");
            for (var r = Object(s), n = 1; n < arguments.length; n++) {
              var o = arguments[n];
              if (null != o)
                for (var l in o) o.hasOwnProperty(l) && (r[l] = o[l])
            }
            return r
          });
          var a = Object.assign({}, e);
          return this.isObject(e) && this.isObject(t) && Object.keys(t).forEach(function(s) {
            i.isObject(t[s]) && s in e ? a[s] = i.extend(e[s], t[s]) : Object.assign(a, ne({}, s, t[s]))
          }), a
        }
      }, {
        key: "extendArray",
        value: function(e, t) {
          var i = [];
          return e.map(function(a) {
            i.push(w.extend(t, a))
          }), i
        }
      }, {
        key: "monthMod",
        value: function(e) {
          return e % 12
        }
      }, {
        key: "clone",
        value: function(e) {
          if (w.is("Array", e)) {
            for (var t = [], i = 0; i < e.length; i++) t[i] = this.clone(e[i]);
            return t
          }
          if (w.is("Null", e)) return null;
          if (w.is("Date", e)) return e;
          if ("object" === $(e)) {
            var a = {};
            for (var s in e) e.hasOwnProperty(s) && (a[s] = this.clone(e[s]));
            return a
          }
          return e
        }
      }, {
        key: "log10",
        value: function(e) {
          return Math.log(e) / Math.LN10
        }
      }, {
        key: "roundToBase10",
        value: function(e) {
          return Math.pow(10, Math.floor(Math.log10(e)))
        }
      }, {
        key: "roundToBase",
        value: function(e, t) {
          return Math.pow(t, Math.floor(Math.log(e) / Math.log(t)))
        }
      }, {
        key: "parseNumber",
        value: function(e) {
          return null === e ? e : parseFloat(e)
        }
      }, {
        key: "stripNumber",
        value: function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2;
          return Number.isInteger(e) ? e : parseFloat(e.toPrecision(t))
        }
      }, {
        key: "randomId",
        value: function() {
          return (Math.random() + 1).toString(36).substring(4)
        }
      }, {
        key: "noExponents",
        value: function(e) {
          var t = String(e).split(/[eE]/);
          if (1 === t.length) return t[0];
          var i = "",
            a = e < 0 ? "-" : "",
            s = t[0].replace(".", ""),
            r = Number(t[1]) + 1;
          if (r < 0) {
            for (i = a + "0."; r++;) i += "0";
            return i + s.replace(/^-/, "")
          }
          for (r -= s.length; r--;) i += "0";
          return s + i
        }
      }, {
        key: "getDimensions",
        value: function(e) {
          var t = getComputedStyle(e, null),
            i = e.clientHeight,
            a = e.clientWidth;
          return i -= parseFloat(t.paddingTop) + parseFloat(t.paddingBottom), [a -= parseFloat(t
            .paddingLeft) + parseFloat(t.paddingRight), i
          ]
        }
      }, {
        key: "getBoundingClientRect",
        value: function(e) {
          var t = e.getBoundingClientRect();
          return {
            top: t.top,
            right: t.right,
            bottom: t.bottom,
            left: t.left,
            width: e.clientWidth,
            height: e.clientHeight,
            x: t.left,
            y: t.top
          }
        }
      }, {
        key: "getLargestStringFromArr",
        value: function(e) {
          return e.reduce(function(t, i) {
            return Array.isArray(i) && (i = i.reduce(function(a, s) {
              return a.length > s.length ? a : s
            })), t.length > i.length ? t : i
          }, 0)
        }
      }, {
        key: "hexToRgba",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "#999999",
            t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : .6;
          "#" !== e.substring(0, 1) && (e = "#999999");
          var i = e.replace("#", "");
          i = i.match(new RegExp("(.{" + i.length / 3 + "})", "g"));
          for (var a = 0; a < i.length; a++) i[a] = parseInt(1 === i[a].length ? i[a] + i[a] : i[a], 16);
          return void 0 !== t && i.push(t), "rgba(" + i.join(",") + ")"
        }
      }, {
        key: "getOpacityFromRGBA",
        value: function(e) {
          return parseFloat(e.replace(/^.*,(.+)\)/, "$1"))
        }
      }, {
        key: "rgb2hex",
        value: function(e) {
          return (e = e.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i)) &&
            4 === e.length ? "#" + ("0" + parseInt(e[1], 10).toString(16)).slice(-2) + ("0" + parseInt(e[2],
              10).toString(16)).slice(-2) + ("0" + parseInt(e[3], 10).toString(16)).slice(-2) : ""
        }
      }, {
        key: "isColorHex",
        value: function(e) {
          return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)|(^#[0-9A-F]{8}$)/i.test(e)
        }
      }, {
        key: "getPolygonPos",
        value: function(e, t) {
          for (var i = [], a = 2 * Math.PI / t, s = 0; s < t; s++) {
            var r = {};
            r.x = e * Math.sin(s * a), r.y = -e * Math.cos(s * a), i.push(r)
          }
          return i
        }
      }, {
        key: "polarToCartesian",
        value: function(e, t, i, a) {
          var s = (a - 90) * Math.PI / 180;
          return {
            x: e + i * Math.cos(s),
            y: t + i * Math.sin(s)
          }
        }
      }, {
        key: "escapeString",
        value: function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "x";
          return e.toString().slice().replace(/[` ~!@#$%^&*()|+\=?;:'",.<>{}[\]\\/]/gi, t)
        }
      }, {
        key: "negToZero",
        value: function(e) {
          return e < 0 ? 0 : e
        }
      }, {
        key: "moveIndexInArray",
        value: function(e, t, i) {
          if (i >= e.length)
            for (var a = i - e.length + 1; a--;) e.push(void 0);
          return e.splice(i, 0, e.splice(t, 1)[0]), e
        }
      }, {
        key: "extractNumber",
        value: function(e) {
          return parseFloat(e.replace(/[^\d.]*/g, ""))
        }
      }, {
        key: "findAncestor",
        value: function(e, t) {
          for (;
            (e = e.parentElement) && !e.classList.contains(t););
          return e
        }
      }, {
        key: "setELstyles",
        value: function(e, t) {
          for (var i in t) t.hasOwnProperty(i) && (e.style.key = t[i])
        }
      }, {
        key: "isNumber",
        value: function(e) {
          return !isNaN(e) && parseFloat(Number(e)) === e && !isNaN(parseInt(e, 10))
        }
      }, {
        key: "isFloat",
        value: function(e) {
          return Number(e) === e && e % 1 != 0
        }
      }, {
        key: "isSafari",
        value: function() {
          return /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
        }
      }, {
        key: "isFirefox",
        value: function() {
          return navigator.userAgent.toLowerCase().indexOf("firefox") > -1
        }
      }, {
        key: "isIE11",
        value: function() {
          if (-1 !== window.navigator.userAgent.indexOf("MSIE") || window.navigator.appVersion.indexOf(
              "Trident/") > -1) return !0
        }
      }, {
        key: "isIE",
        value: function() {
          var e = window.navigator.userAgent,
            t = e.indexOf("MSIE ");
          if (t > 0) return parseInt(e.substring(t + 5, e.indexOf(".", t)), 10);
          if (e.indexOf("Trident/") > 0) {
            var i = e.indexOf("rv:");
            return parseInt(e.substring(i + 3, e.indexOf(".", i)), 10)
          }
          var a = e.indexOf("Edge/");
          return a > 0 && parseInt(e.substring(a + 5, e.indexOf(".", a)), 10)
        }
      }, {
        key: "getGCD",
        value: function(e, t) {
          var a = Math.pow(10, (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 7) - Math
            .floor(Math.log10(Math.max(e, t))));
          for (e = Math.round(Math.abs(e) * a), t = Math.round(Math.abs(t) * a); t;) {
            var s = t;
            t = e % t, e = s
          }
          return e / a
        }
      }, {
        key: "getPrimeFactors",
        value: function(e) {
          for (var t = [], i = 2; e >= 2;) e % i == 0 ? (t.push(i), e /= i) : i++;
          return t
        }
      }, {
        key: "mod",
        value: function(e, t) {
          var a = Math.pow(10, (arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 7) - Math
            .floor(Math.log10(Math.max(e, t))));
          return (e = Math.round(Math.abs(e) * a)) % (t = Math.round(Math.abs(t) * a)) / a
        }
      }]), w
    }(),
    ge = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.setEasingFunctions()
      }
      return R(w, [{
        key: "setEasingFunctions",
        value: function() {
          var e;
          if (!this.w.globals.easing) {
            switch (this.w.config.chart.animations.easing) {
              case "linear":
                e = "-";
                break;
              case "easein":
                e = "<";
                break;
              case "easeout":
                e = ">";
                break;
              case "easeinout":
              default:
                e = "<>";
                break;
              case "swing":
                e = function(t) {
                  var i = 1.70158;
                  return (t -= 1) * t * ((i + 1) * t + i) + 1
                };
                break;
              case "bounce":
                e = function(t) {
                  return t < 1 / 2.75 ? 7.5625 * t * t : t < 2 / 2.75 ? 7.5625 * (t -= 1.5 / 2.75) * t +
                    .75 : t < 2.5 / 2.75 ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 /
                      2.75) * t + .984375
                };
                break;
              case "elastic":
                e = function(t) {
                  return t === !!t ? t : Math.pow(2, -10 * t) * Math.sin((t - .075) * (2 * Math.PI) / .3) +
                    1
                }
            }
            this.w.globals.easing = e
          }
        }
      }, {
        key: "animateLine",
        value: function(e, t, i, a) {
          e.attr(t).animate(a).attr(i)
        }
      }, {
        key: "animateMarker",
        value: function(e, t, i, a, s, r) {
          t || (t = 0), e.attr({
            r: t,
            width: t,
            height: t
          }).animate(a, s).attr({
            r: i,
            width: i.width,
            height: i.height
          }).afterAll(function() {
            r()
          })
        }
      }, {
        key: "animateCircle",
        value: function(e, t, i, a, s) {
          e.attr({
            r: t.r,
            cx: t.cx,
            cy: t.cy
          }).animate(a, s).attr({
            r: i.r,
            cx: i.cx,
            cy: i.cy
          })
        }
      }, {
        key: "animateRect",
        value: function(e, t, i, a, s) {
          e.attr(t).animate(a).attr(i).afterAll(function() {
            return s()
          })
        }
      }, {
        key: "animatePathsGradually",
        value: function(e) {
          var c = this.w,
            d = 0;
          c.config.chart.animations.animateGradually.enabled && (d = c.config.chart.animations
              .animateGradually.delay), c.config.chart.animations.dynamicAnimation.enabled && c.globals
            .dataChanged && "bar" !== c.config.chart.type && (d = 0), this.morphSVG(e.el, e.realIndex, e.j,
              "line" !== c.config.chart.type || c.globals.comboCharts ? e.fill : "stroke", e.pathFrom, e
              .pathTo, e.speed, e.delay * d)
        }
      }, {
        key: "showDelayedElements",
        value: function() {
          this.w.globals.delayedElements.forEach(function(e) {
            var t = e.el;
            t.classList.remove("apexcharts-element-hidden"), t.classList.add(
              "apexcharts-hidden-element-shown")
          })
        }
      }, {
        key: "animationCompleted",
        value: function(e) {
          var t = this.w;
          t.globals.animationEnded || (t.globals.animationEnded = !0, this.showDelayedElements(),
            "function" == typeof t.config.chart.events.animationEnd && t.config.chart.events.animationEnd(
              this.ctx, {
                el: e,
                w: t
              }))
        }
      }, {
        key: "morphSVG",
        value: function(e, t, i, a, s, r, n, o) {
          var l = this,
            c = this.w;
          s || (s = e.attr("pathFrom")), r || (r = e.attr("pathTo"));
          var d = function(g) {
            return "radar" === c.config.chart.type && (n = 1), "M 0 ".concat(c.globals.gridHeight)
          };
          (!s || s.indexOf("undefined") > -1 || s.indexOf("NaN") > -1) && (s = d()), (!r || r.indexOf(
            "undefined") > -1 || r.indexOf("NaN") > -1) && (r = d()), c.globals.shouldAnimate || (n = 1), e
            .plot(s).animate(1, c.globals.easing, o).plot(s).animate(n, c.globals.easing, o).plot(r).afterAll(
              function() {
                P.isNumber(i) ? i === c.globals.series[c.globals.maxValsInArrayIndex].length - 2 && c.globals
                  .shouldAnimate && l.animationCompleted(e) : "none" !== a && c.globals.shouldAnimate && (!c
                    .globals.comboCharts && t === c.globals.series.length - 1 || c.globals.comboCharts) && l
                  .animationCompleted(e), l.showDelayedElements()
              })
        }
      }]), w
    }(),
    K = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "getDefaultFilter",
        value: function(e, t) {
          var i = this.w;
          e.unfilter(!0), (new window.SVG.Filter).size("120%", "180%", "-5%", "-40%"), "none" !== i.config
            .states.normal.filter ? this.applyFilter(e, t, i.config.states.normal.filter.type, i.config.states
              .normal.filter.value) : i.config.chart.dropShadow.enabled && this.dropShadow(e, i.config.chart
              .dropShadow, t)
        }
      }, {
        key: "addNormalFilter",
        value: function(e, t) {
          var i = this.w;
          i.config.chart.dropShadow.enabled && !e.node.classList.contains("apexcharts-marker") && this
            .dropShadow(e, i.config.chart.dropShadow, t)
        }
      }, {
        key: "addLightenFilter",
        value: function(e, t, i) {
          var a = this,
            s = this.w,
            r = i.intensity;
          e.unfilter(!0), new window.SVG.Filter, e.filter(function(n) {
            var o = s.config.chart.dropShadow;
            (o.enabled ? a.addShadow(n, t, o) : n).componentTransfer({
              rgb: {
                type: "linear",
                slope: 1.5,
                intercept: r
              }
            })
          }), e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e
            .filterer.node)
        }
      }, {
        key: "addDarkenFilter",
        value: function(e, t, i) {
          var a = this,
            s = this.w,
            r = i.intensity;
          e.unfilter(!0), new window.SVG.Filter, e.filter(function(n) {
            var o = s.config.chart.dropShadow;
            (o.enabled ? a.addShadow(n, t, o) : n).componentTransfer({
              rgb: {
                type: "linear",
                slope: r
              }
            })
          }), e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e
            .filterer.node)
        }
      }, {
        key: "applyFilter",
        value: function(e, t, i) {
          var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : .5;
          switch (i) {
            case "none":
              this.addNormalFilter(e, t);
              break;
            case "lighten":
              this.addLightenFilter(e, t, {
                intensity: a
              });
              break;
            case "darken":
              this.addDarkenFilter(e, t, {
                intensity: a
              })
          }
        }
      }, {
        key: "addShadow",
        value: function(e, t, i) {
          var a, s = this.w,
            r = i.blur,
            n = i.top,
            o = i.left,
            l = i.color,
            c = i.opacity;
          if ((null === (a = s.config.chart.dropShadow.enabledOnSeries) || void 0 === a ? void 0 : a.length) >
            0 && -1 === s.config.chart.dropShadow.enabledOnSeries.indexOf(t)) return e;
          var d = e.flood(Array.isArray(l) ? l[t] : l, c).composite(e.sourceAlpha, "in").offset(o, n)
            .gaussianBlur(r).merge(e.source);
          return e.blend(e.source, d)
        }
      }, {
        key: "dropShadow",
        value: function(e, t) {
          var i, a, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            r = t.top,
            n = t.left,
            o = t.blur,
            l = t.color,
            c = t.opacity,
            d = t.noUserSpaceOnUse,
            g = this.w;
          return e.unfilter(!0), P.isIE() && "radialBar" === g.config.chart.type || (null === (i = g.config
            .chart.dropShadow.enabledOnSeries) || void 0 === i ? void 0 : i.length) > 0 && -1 === (null ===
            (a = g.config.chart.dropShadow.enabledOnSeries) || void 0 === a ? void 0 : a.indexOf(s)) || (l =
            Array.isArray(l) ? l[s] : l, e.filter(function(p) {
              var f;
              f = P.isSafari() || P.isFirefox() || P.isIE() ? p.flood(l, c).composite(p.sourceAlpha, "in")
                .offset(n, r).gaussianBlur(o) : p.flood(l, c).composite(p.sourceAlpha, "in").offset(n, r)
                .gaussianBlur(o).merge(p.source), p.blend(p.source, f)
            }), d || e.filterer.node.setAttribute("filterUnits", "userSpaceOnUse"), this._scaleFilterSize(e
              .filterer.node)), e
        }
      }, {
        key: "setSelectionFilter",
        value: function(e, t, i) {
          var a = this.w;
          if (void 0 !== a.globals.selectedDataPoints[t] && a.globals.selectedDataPoints[t].indexOf(i) > -1) {
            e.node.setAttribute("selected", !0);
            var s = a.config.states.active.filter;
            "none" !== s && this.applyFilter(e, t, s.type, s.value)
          }
        }
      }, {
        key: "_scaleFilterSize",
        value: function(e) {
          ! function(t) {
            for (var i in t) t.hasOwnProperty(i) && e.setAttribute(i, t[i])
          }({
            width: "200%",
            height: "200%",
            x: "-50%",
            y: "-50%"
          })
        }
      }]), w
    }(),
    X = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "roundPathCorners",
        value: function(e, t) {
          function i(S, C, L) {
            var M = C.x - S.x,
              z = C.y - S.y,
              I = Math.sqrt(M * M + z * z);
            return a(S, C, Math.min(1, L / I))
          }

          function a(S, C, L) {
            return {
              x: S.x + (C.x - S.x) * L,
              y: S.y + (C.y - S.y) * L
            }
          }

          function s(S, C) {
            S.length > 2 && (S[S.length - 2] = C.x, S[S.length - 1] = C.y)
          }

          function r(S) {
            return {
              x: parseFloat(S[S.length - 2]),
              y: parseFloat(S[S.length - 1])
            }
          }
          e.indexOf("NaN") > -1 && (e = "");
          var n = e.split(/[,\s]/).reduce(function(S, C) {
              var L = C.match("([a-zA-Z])(.+)");
              return L ? (S.push(L[1]), S.push(L[2])) : S.push(C), S
            }, []).reduce(function(S, C) {
              return parseFloat(C) == C && S.length ? S[S.length - 1].push(C) : S.push([C]), S
            }, []),
            o = [];
          if (n.length > 1) {
            var l = r(n[0]),
              c = null;
            "Z" == n[n.length - 1][0] && n[0].length > 2 && (n[n.length - 1] = c = ["L", l.x, l.y]), o.push(n[
              0]);
            for (var d = 1; d < n.length; d++) {
              var g = o[o.length - 1],
                p = n[d],
                f = p == c ? n[1] : n[d + 1];
              if (f && g && g.length > 2 && "L" == p[0] && f.length > 2 && "L" == f[0]) {
                var x, m, v = r(g),
                  y = r(p),
                  h = r(f);
                x = i(y, v, t), m = i(y, h, t), s(p, x), p.origPoint = y, o.push(p);
                var u = a(x, y, .5),
                  b = a(y, m, .5),
                  k = ["C", u.x, u.y, b.x, b.y, m.x, m.y];
                k.origPoint = y, o.push(k)
              } else o.push(p)
            }
            if (c) {
              var A = r(o[o.length - 1]);
              o.push(["Z"]), s(o[0], A)
            }
          } else o = n;
          return o.reduce(function(S, C) {
            return S + C.join(" ") + " "
          }, "")
        }
      }, {
        key: "drawLine",
        value: function(e, t, i, a) {
          var s = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : "#a8a8a8",
            r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 0,
            n = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
            o = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : "butt";
          return this.w.globals.dom.Paper.line().attr({
            x1: e,
            y1: t,
            x2: i,
            y2: a,
            stroke: s,
            "stroke-dasharray": r,
            "stroke-width": n,
            "stroke-linecap": o
          })
        }
      }, {
        key: "drawRect",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
            t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
            i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
            s = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
            r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "#fefefe",
            n = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 1,
            o = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
            l = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : null,
            c = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
            d = this.w.globals.dom.Paper.rect();
          return d.attr({
            x: e,
            y: t,
            width: i > 0 ? i : 0,
            height: a > 0 ? a : 0,
            rx: s,
            ry: s,
            opacity: n,
            "stroke-width": null !== o ? o : 0,
            stroke: null !== l ? l : "none",
            "stroke-dasharray": c
          }), d.node.setAttribute("fill", r), d
        }
      }, {
        key: "drawPolygon",
        value: function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "#e1e1e1",
            i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1,
            a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "none";
          return this.w.globals.dom.Paper.polygon(e).attr({
            fill: a,
            stroke: t,
            "stroke-width": i
          })
        }
      }, {
        key: "drawCircle",
        value: function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          e < 0 && (e = 0);
          var i = this.w.globals.dom.Paper.circle(2 * e);
          return null !== t && i.attr(t), i
        }
      }, {
        key: "drawPath",
        value: function(e) {
          var t = e.d,
            i = void 0 === t ? "" : t,
            a = e.stroke,
            s = void 0 === a ? "#a8a8a8" : a,
            r = e.strokeWidth,
            n = void 0 === r ? 1 : r,
            o = e.fill,
            l = e.fillOpacity,
            c = void 0 === l ? 1 : l,
            d = e.strokeOpacity,
            g = void 0 === d ? 1 : d,
            p = e.classes,
            f = e.strokeLinecap,
            x = void 0 === f ? null : f,
            m = e.strokeDashArray,
            v = void 0 === m ? 0 : m,
            y = this.w;
          return null === x && (x = y.config.stroke.lineCap), (i.indexOf("undefined") > -1 || i.indexOf(
            "NaN") > -1) && (i = "M 0 ".concat(y.globals.gridHeight)), y.globals.dom.Paper.path(i).attr({
            fill: o,
            "fill-opacity": c,
            stroke: s,
            "stroke-opacity": g,
            "stroke-linecap": x,
            "stroke-width": n,
            "stroke-dasharray": v,
            class: p
          })
        }
      }, {
        key: "group",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
            t = this.w.globals.dom.Paper.group();
          return null !== e && t.attr(e), t
        }
      }, {
        key: "move",
        value: function(e, t) {
          return ["M", e, t].join(" ")
        }
      }, {
        key: "line",
        value: function(e, t) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
            a = null;
          return null === i ? a = [" L", e, t].join(" ") : "H" === i ? a = [" H", e].join(" ") : "V" === i &&
            (a = [" V", t].join(" ")), a
        }
      }, {
        key: "curve",
        value: function(e, t, i, a, s, r) {
          return ["C", e, t, i, a, s, r].join(" ")
        }
      }, {
        key: "quadraticCurve",
        value: function(e, t, i, a) {
          return ["Q", e, t, i, a].join(" ")
        }
      }, {
        key: "arc",
        value: function(e, t, i, a, s, r, n) {
          var o = "A";
          return arguments.length > 7 && void 0 !== arguments[7] && arguments[7] && (o = "a"), [o, e, t, i, a,
            s, r, n
          ].join(" ")
        }
      }, {
        key: "renderPaths",
        value: function(e) {
          var t, i = e.j,
            a = e.realIndex,
            s = e.pathFrom,
            r = e.pathTo,
            n = e.stroke,
            o = e.strokeWidth,
            l = e.strokeLinecap,
            c = e.fill,
            d = e.animationDelay,
            g = e.initialSpeed,
            p = e.dataChangeSpeed,
            f = e.className,
            x = e.shouldClipToGrid,
            m = void 0 === x || x,
            v = e.bindEventsOnPaths,
            y = void 0 === v || v,
            h = e.drawShadow,
            u = void 0 === h || h,
            b = this.w,
            k = new K(this.ctx),
            A = new ge(this.ctx),
            S = this.w.config.chart.animations.enabled,
            C = S && this.w.config.chart.animations.dynamicAnimation.enabled,
            L = !!(S && !b.globals.resized || C && b.globals.dataChanged && b.globals.shouldAnimate);
          L ? t = s : (t = r, b.globals.animationEnded = !0);
          var z, M = b.config.stroke.dashArray;
          z = Array.isArray(M) ? M[a] : b.config.stroke.dashArray;
          var I = this.drawPath({
            d: t,
            stroke: n,
            strokeWidth: o,
            fill: c,
            fillOpacity: 1,
            classes: f,
            strokeLinecap: l,
            strokeDashArray: z
          });
          I.attr("index", a), m && I.attr({
              "clip-path": "url(#gridRectMask".concat(b.globals.cuid, ")")
            }), "none" !== b.config.states.normal.filter.type ? k.getDefaultFilter(I, a) : b.config.chart
            .dropShadow.enabled && u && k.dropShadow(I, b.config.chart.dropShadow, a), y && (I.node
              .addEventListener("mouseenter", this.pathMouseEnter.bind(this, I)), I.node.addEventListener(
                "mouseleave", this.pathMouseLeave.bind(this, I)), I.node.addEventListener("mousedown", this
                .pathMouseDown.bind(this, I))), I.attr({
              pathTo: r,
              pathFrom: s
            });
          var E = {
            el: I,
            j: i,
            realIndex: a,
            pathFrom: s,
            pathTo: r,
            fill: c,
            strokeWidth: o,
            delay: d
          };
          return !S || b.globals.resized || b.globals.dataChanged ? !b.globals.resized && b.globals
            .dataChanged || A.showDelayedElements() : A.animatePathsGradually(Y(Y({}, E), {}, {
              speed: g
            })), b.globals.dataChanged && C && L && A.animatePathsGradually(Y(Y({}, E), {}, {
              speed: p
            })), I
        }
      }, {
        key: "drawPattern",
        value: function(e, t, i) {
          var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "#a8a8a8",
            s = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0;
          return this.w.globals.dom.Paper.pattern(t, i, function(r) {
            "horizontalLines" === e ? r.line(0, 0, i, 0).stroke({
              color: a,
              width: s + 1
            }) : "verticalLines" === e ? r.line(0, 0, 0, t).stroke({
              color: a,
              width: s + 1
            }) : "slantedLines" === e ? r.line(0, 0, t, i).stroke({
              color: a,
              width: s
            }) : "squares" === e ? r.rect(t, i).fill("none").stroke({
              color: a,
              width: s
            }) : "circles" === e && r.circle(t).fill("none").stroke({
              color: a,
              width: s
            })
          })
        }
      }, {
        key: "drawGradient",
        value: function(e, t, i, a, s) {
          var r, n = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
            o = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : null,
            l = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : null,
            c = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
            d = this.w;
          t.length < 9 && 0 === t.indexOf("#") && (t = P.hexToRgba(t, a)), i.length < 9 && 0 === i.indexOf(
            "#") && (i = P.hexToRgba(i, s));
          var g = 0,
            p = 1,
            f = 1,
            x = null;
          null !== o && (g = void 0 !== o[0] ? o[0] / 100 : 0, p = void 0 !== o[1] ? o[1] / 100 : 1, f =
            void 0 !== o[2] ? o[2] / 100 : 1, x = void 0 !== o[3] ? o[3] / 100 : null);
          var m = !("donut" !== d.config.chart.type && "pie" !== d.config.chart.type && "polarArea" !== d
            .config.chart.type && "bubble" !== d.config.chart.type);
          return r = d.globals.dom.Paper.gradient(m ? "radial" : "linear", null === l || 0 === l.length ?
              function(h) {
                h.at(g, t, a), h.at(p, i, s), h.at(f, i, s), null !== x && h.at(x, t, a)
              } : function(h) {
                (Array.isArray(l[c]) ? l[c] : l).forEach(function(u) {
                  h.at(u.offset / 100, u.color, u.opacity)
                })
              }), m ? r.attr("bubble" !== d.config.chart.type ? {
              gradientUnits: "userSpaceOnUse",
              cx: d.globals.gridWidth / 2,
              cy: d.globals.gridHeight / 2,
              r: n
            } : {
              cx: .5,
              cy: .5,
              r: .8,
              fx: .2,
              fy: .2
            }) : "vertical" === e ? r.from(0, 0).to(0, 1) : "diagonal" === e ? r.from(0, 0).to(1, 1) :
            "horizontal" === e ? r.from(0, 1).to(1, 1) : "diagonal2" === e && r.from(1, 0).to(0, 1), r
        }
      }, {
        key: "getTextBasedOnMaxWidth",
        value: function(e) {
          var t = e.text,
            i = e.maxWidth,
            r = this.getTextRects(t, e.fontSize, e.fontFamily),
            o = Math.floor(i / (r.width / t.length));
          return i < r.width ? t.slice(0, o - 3) + "..." : t
        }
      }, {
        key: "drawText",
        value: function(e) {
          var t = this,
            i = e.x,
            a = e.y,
            s = e.text,
            r = e.textAnchor,
            n = e.fontSize,
            o = e.fontFamily,
            l = e.fontWeight,
            c = e.foreColor,
            d = e.opacity,
            g = e.maxWidth,
            p = e.cssClass,
            f = void 0 === p ? "" : p,
            x = e.isPlainText,
            m = void 0 === x || x,
            v = e.dominantBaseline,
            y = void 0 === v ? "auto" : v,
            h = this.w;
          void 0 === s && (s = "");
          var u = s;
          r || (r = "start"), c && c.length || (c = h.config.chart.foreColor), l = l || "regular";
          var b, k = {
            maxWidth: g,
            fontSize: n = n || "11px",
            fontFamily: o = o || h.config.chart.fontFamily
          };
          return Array.isArray(s) ? b = h.globals.dom.Paper.text(function(A) {
            for (var S = 0; S < s.length; S++) u = s[S], g && (u = t.getTextBasedOnMaxWidth(Y({
              text: s[S]
            }, k))), 0 === S ? A.tspan(u) : A.tspan(u).newLine()
          }) : (g && (u = this.getTextBasedOnMaxWidth(Y({
            text: s
          }, k))), b = m ? h.globals.dom.Paper.plain(s) : h.globals.dom.Paper.text(function(A) {
            return A.tspan(u)
          })), b.attr({
            x: i,
            y: a,
            "text-anchor": r,
            "dominant-baseline": y,
            "font-size": n,
            "font-family": o,
            "font-weight": l,
            fill: c,
            class: "apexcharts-text " + f
          }), b.node.style.fontFamily = o, b.node.style.opacity = d, b
        }
      }, {
        key: "createGroupWithAttributes",
        value: function(e, t, i, a) {
          var s = this.group();
          return i.forEach(function(r) {
            return s.add(r)
          }), s.attr({
            class: a.class ? a.class : "",
            cy: t,
            cx: e
          }), s
        }
      }, {
        key: "drawPlus",
        value: function(e, t, i, a) {
          var s = i / 2,
            r = this.drawLine(e, t - s, e, t + s, a.pointStrokeColor, a.pointStrokeDashArray, a
              .pointStrokeWidth, a.pointStrokeLineCap),
            n = this.drawLine(e - s, t, e + s, t, a.pointStrokeColor, a.pointStrokeDashArray, a
              .pointStrokeWidth, a.pointStrokeLineCap);
          return this.createGroupWithAttributes(e, t, [r, n], a)
        }
      }, {
        key: "drawX",
        value: function(e, t, i, a) {
          var s = i / 2,
            r = this.drawLine(e - s, t - s, e + s, t + s, a.pointStrokeColor, a.pointStrokeDashArray, a
              .pointStrokeWidth, a.pointStrokeLineCap),
            n = this.drawLine(e - s, t + s, e + s, t - s, a.pointStrokeColor, a.pointStrokeDashArray, a
              .pointStrokeWidth, a.pointStrokeLineCap);
          return this.createGroupWithAttributes(e, t, [r, n], a)
        }
      }, {
        key: "drawMarker",
        value: function(e, t, i) {
          e = e || 0;
          var a = i.pSize || 0,
            s = null;
          if ("X" === i?.shape || "x" === i?.shape) s = this.drawX(e, t, a, i);
          else if ("plus" === i?.shape || "+" === i?.shape) s = this.drawPlus(e, t, a, i);
          else if ("square" === i.shape || "rect" === i.shape) {
            var r = void 0 === i.pRadius ? a / 2 : i.pRadius;
            null !== t && a || (a = 0, r = 0);
            var n = 1.2 * a + r,
              o = this.drawRect(n, n, n, n, r);
            o.attr({
              x: e - n / 2,
              y: t - n / 2,
              cx: e,
              cy: t,
              class: i.class ? i.class : "",
              fill: i.pointFillColor,
              "fill-opacity": i.pointFillOpacity ? i.pointFillOpacity : 1,
              stroke: i.pointStrokeColor,
              "stroke-width": i.pointStrokeWidth ? i.pointStrokeWidth : 0,
              "stroke-opacity": i.pointStrokeOpacity ? i.pointStrokeOpacity : 1
            }), s = o
          } else "circle" !== i.shape && i.shape || (P.isNumber(t) || (a = 0, t = 0), s = this.drawCircle(a, {
            cx: e,
            cy: t,
            class: i.class ? i.class : "",
            stroke: i.pointStrokeColor,
            fill: i.pointFillColor,
            "fill-opacity": i.pointFillOpacity ? i.pointFillOpacity : 1,
            "stroke-width": i.pointStrokeWidth ? i.pointStrokeWidth : 0,
            "stroke-opacity": i.pointStrokeOpacity ? i.pointStrokeOpacity : 1
          }));
          return s
        }
      }, {
        key: "pathMouseEnter",
        value: function(e, t) {
          var i = this.w,
            a = new K(this.ctx),
            s = parseInt(e.node.getAttribute("index"), 10),
            r = parseInt(e.node.getAttribute("j"), 10);
          if ("function" == typeof i.config.chart.events.dataPointMouseEnter && i.config.chart.events
            .dataPointMouseEnter(t, this.ctx, {
              seriesIndex: s,
              dataPointIndex: r,
              w: i
            }), this.ctx.events.fireEvent("dataPointMouseEnter", [t, this.ctx, {
              seriesIndex: s,
              dataPointIndex: r,
              w: i
            }]), ("none" === i.config.states.active.filter.type || "true" !== e.node.getAttribute(
            "selected")) && "none" !== i.config.states.hover.filter.type && !i.globals.isTouchDevice) {
            var n = i.config.states.hover.filter;
            a.applyFilter(e, s, n.type, n.value)
          }
        }
      }, {
        key: "pathMouseLeave",
        value: function(e, t) {
          var i = this.w,
            a = new K(this.ctx),
            s = parseInt(e.node.getAttribute("index"), 10),
            r = parseInt(e.node.getAttribute("j"), 10);
          "function" == typeof i.config.chart.events.dataPointMouseLeave && i.config.chart.events
            .dataPointMouseLeave(t, this.ctx, {
              seriesIndex: s,
              dataPointIndex: r,
              w: i
            }), this.ctx.events.fireEvent("dataPointMouseLeave", [t, this.ctx, {
              seriesIndex: s,
              dataPointIndex: r,
              w: i
            }]), "none" !== i.config.states.active.filter.type && "true" === e.node.getAttribute(
            "selected") || "none" !== i.config.states.hover.filter.type && a.getDefaultFilter(e, s)
        }
      }, {
        key: "pathMouseDown",
        value: function(e, t) {
          var i = this.w,
            a = new K(this.ctx),
            s = parseInt(e.node.getAttribute("index"), 10),
            r = parseInt(e.node.getAttribute("j"), 10),
            n = "false";
          if ("true" === e.node.getAttribute("selected")) {
            if (e.node.setAttribute("selected", "false"), i.globals.selectedDataPoints[s].indexOf(r) > -1) {
              var o = i.globals.selectedDataPoints[s].indexOf(r);
              i.globals.selectedDataPoints[s].splice(o, 1)
            }
          } else {
            if (!i.config.states.active.allowMultipleDataPointsSelection && i.globals.selectedDataPoints
              .length > 0) {
              i.globals.selectedDataPoints = [];
              var l = i.globals.dom.Paper.select(".apexcharts-series path").members,
                c = i.globals.dom.Paper.select(".apexcharts-series circle, .apexcharts-series rect").members,
                d = function(f) {
                  Array.prototype.forEach.call(f, function(x) {
                    x.node.setAttribute("selected", "false"), a.getDefaultFilter(x, s)
                  })
                };
              d(l), d(c)
            }
            e.node.setAttribute("selected", "true"), n = "true", void 0 === i.globals.selectedDataPoints[s] &&
              (i.globals.selectedDataPoints[s] = []), i.globals.selectedDataPoints[s].push(r)
          }
          if ("true" === n) {
            var g = i.config.states.active.filter;
            if ("none" !== g) a.applyFilter(e, s, g.type, g.value);
            else if ("none" !== i.config.states.hover.filter && !i.globals.isTouchDevice) {
              var p = i.config.states.hover.filter;
              a.applyFilter(e, s, p.type, p.value)
            }
          } else "none" !== i.config.states.active.filter.type && ("none" === i.config.states.hover.filter
            .type || i.globals.isTouchDevice ? a.getDefaultFilter(e, s) : a.applyFilter(e, s, (p = i.config
              .states.hover.filter).type, p.value));
          "function" == typeof i.config.chart.events.dataPointSelection && i.config.chart.events
            .dataPointSelection(t, this.ctx, {
              selectedDataPoints: i.globals.selectedDataPoints,
              seriesIndex: s,
              dataPointIndex: r,
              w: i
            }), t && this.ctx.events.fireEvent("dataPointSelection", [t, this.ctx, {
              selectedDataPoints: i.globals.selectedDataPoints,
              seriesIndex: s,
              dataPointIndex: r,
              w: i
            }])
        }
      }, {
        key: "rotateAroundCenter",
        value: function(e) {
          var t = {};
          return e && "function" == typeof e.getBBox && (t = e.getBBox()), {
            x: t.x + t.width / 2,
            y: t.y + t.height / 2
          }
        }
      }, {
        key: "getTextRects",
        value: function(e, t, i, a) {
          var s = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
            r = this.w,
            n = this.drawText({
              x: -200,
              y: -200,
              text: e,
              textAnchor: "start",
              fontSize: t,
              fontFamily: i,
              foreColor: "#fff",
              opacity: 0
            });
          a && n.attr("transform", a), r.globals.dom.Paper.add(n);
          var o = n.bbox();
          return s || (o = n.node.getBoundingClientRect()), n.remove(), {
            width: o.width,
            height: o.height
          }
        }
      }, {
        key: "placeTextWithEllipsis",
        value: function(e, t, i) {
          if ("function" == typeof e.getComputedTextLength && (e.textContent = t, t.length > 0 && e
              .getComputedTextLength() >= i / 1.1)) {
            for (var a = t.length - 3; a > 0; a -= 3)
              if (e.getSubStringLength(0, a) <= i / 1.1) return void(e.textContent = t.substring(0, a) +
                "...");
            e.textContent = "."
          }
        }
      }], [{
        key: "setAttrs",
        value: function(e, t) {
          for (var i in t) t.hasOwnProperty(i) && e.setAttribute(i, t[i])
        }
      }]), w
    }(),
    q = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "getStackedSeriesTotals",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
            t = this.w,
            i = [];
          if (0 === t.globals.series.length) return i;
          for (var a = 0; a < t.globals.series[t.globals.maxValsInArrayIndex].length; a++) {
            for (var s = 0, r = 0; r < t.globals.series.length; r++) void 0 !== t.globals.series[r][a] && -
              1 === e.indexOf(r) && (s += t.globals.series[r][a]);
            i.push(s)
          }
          return i
        }
      }, {
        key: "getSeriesTotalByIndex",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
          return null === e ? this.w.config.series.reduce(function(t, i) {
            return t + i
          }, 0) : this.w.globals.series[e].reduce(function(t, i) {
            return t + i
          }, 0)
        }
      }, {
        key: "getStackedSeriesTotalsByGroups",
        value: function() {
          var e = this,
            t = this.w,
            i = [];
          return t.globals.seriesGroups.forEach(function(a) {
            var s = [];
            t.config.series.forEach(function(n, o) {
              a.indexOf(t.globals.seriesNames[o]) > -1 && s.push(o)
            });
            var r = t.globals.series.map(function(n, o) {
              return -1 === s.indexOf(o) ? o : -1
            }).filter(function(n) {
              return -1 !== n
            });
            i.push(e.getStackedSeriesTotals(r))
          }), i
        }
      }, {
        key: "setSeriesYAxisMappings",
        value: function() {
          var e = this.w.globals,
            t = this.w.config,
            i = [],
            a = [],
            s = [],
            r = e.series.length > t.yaxis.length || t.yaxis.some(function(d) {
              return Array.isArray(d.seriesName)
            });
          t.series.forEach(function(d, g) {
            s.push(g), a.push(null)
          }), t.yaxis.forEach(function(d, g) {
            i[g] = []
          });
          var n = [];
          t.yaxis.forEach(function(d, g) {
            var p = !1;
            if (d.seriesName) {
              var f = [];
              Array.isArray(d.seriesName) ? f = d.seriesName : f.push(d.seriesName), f.forEach(function(
              x) {
                t.series.forEach(function(m, v) {
                  if (m.name === x) {
                    var y = v;
                    g === v || r ? !r || s.indexOf(v) > -1 ? i[g].push([g, v]) : console.warn(
                        "Series '" + m.name +
                        "' referenced more than once in what looks like the new style. That is, when using either seriesName: [], or when there are more series than yaxes."
                        ) : (i[v].push([v, g]), y = g), p = !0, -1 !== (y = s.indexOf(y)) && s
                      .splice(y, 1)
                  }
                })
              })
            }
            p || n.push(g)
          }), i = i.map(function(d, g) {
            var p = [];
            return d.forEach(function(f) {
              a[f[1]] = f[0], p.push(f[1])
            }), p
          });
          for (var o = t.yaxis.length - 1, l = 0; l < n.length && (i[o = n[l]] = [], s); l++) {
            var c = s[0];
            s.shift(), i[o].push(c), a[c] = o
          }
          s.forEach(function(d) {
            i[o].push(d), a[d] = o
          }), e.seriesYAxisMap = i.map(function(d) {
            return d
          }), e.seriesYAxisReverseMap = a.map(function(d) {
            return d
          }), e.seriesYAxisMap.forEach(function(d, g) {
            d.forEach(function(p) {
              t.series[p] && void 0 === t.series[p].group && (t.series[p].group = "apexcharts-axis-"
                .concat(g.toString()))
            })
          })
        }
      }, {
        key: "isSeriesNull",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
          return 0 === (null === e ? this.w.config.series.filter(function(t) {
            return null !== t
          }) : this.w.config.series[e].data.filter(function(t) {
            return null !== t
          })).length
        }
      }, {
        key: "seriesHaveSameValues",
        value: function(e) {
          return this.w.globals.series[e].every(function(t, i, a) {
            return t === a[0]
          })
        }
      }, {
        key: "getCategoryLabels",
        value: function(e) {
          var t = this.w,
            i = e.slice();
          return t.config.xaxis.convertedCatToNumeric && (i = e.map(function(a, s) {
            return t.config.xaxis.labels.formatter(a - t.globals.minX + 1)
          })), i
        }
      }, {
        key: "getLargestSeries",
        value: function() {
          var e = this.w;
          e.globals.maxValsInArrayIndex = e.globals.series.map(function(t) {
            return t.length
          }).indexOf(Math.max.apply(Math, e.globals.series.map(function(t) {
            return t.length
          })))
        }
      }, {
        key: "getLargestMarkerSize",
        value: function() {
          var e = this.w,
            t = 0;
          return e.globals.markers.size.forEach(function(i) {
              t = Math.max(t, i)
            }), e.config.markers.discrete && e.config.markers.discrete.length && e.config.markers.discrete
            .forEach(function(i) {
              t = Math.max(t, i.size)
            }), t > 0 && (t += e.config.markers.hover.sizeOffset + 1), e.globals.markers.largestSize = t, t
        }
      }, {
        key: "getSeriesTotals",
        value: function() {
          var e = this.w;
          e.globals.seriesTotals = e.globals.series.map(function(t, i) {
            var a = 0;
            if (Array.isArray(t))
              for (var s = 0; s < t.length; s++) a += t[s];
            else a += t;
            return a
          })
        }
      }, {
        key: "getSeriesTotalsXRange",
        value: function(e, t) {
          var i = this.w;
          return i.globals.series.map(function(a, s) {
            for (var r = 0, n = 0; n < a.length; n++) i.globals.seriesX[s][n] > e && i.globals.seriesX[s][
              n
            ] < t && (r += a[n]);
            return r
          })
        }
      }, {
        key: "getPercentSeries",
        value: function() {
          var e = this.w;
          e.globals.seriesPercent = e.globals.series.map(function(t, i) {
            var a = [];
            if (Array.isArray(t))
              for (var s = 0; s < t.length; s++) {
                var r = e.globals.stackedSeriesTotals[s],
                  n = 0;
                r && (n = 100 * t[s] / r), a.push(n)
              } else {
                var o = 100 * t / e.globals.seriesTotals.reduce(function(l, c) {
                  return l + c
                }, 0);
                a.push(o)
              }
            return a
          })
        }
      }, {
        key: "getCalculatedRatios",
        value: function() {
          var e, t, i, a = this,
            s = this.w,
            r = s.globals,
            n = [],
            o = 0,
            l = [],
            c = .1,
            d = 0;
          if (r.yRange = [], r.isMultipleYAxis)
            for (var g = 0; g < r.minYArr.length; g++) r.yRange.push(Math.abs(r.minYArr[g] - r.maxYArr[g])), l
              .push(0);
          else r.yRange.push(Math.abs(r.minY - r.maxY));
          r.xRange = Math.abs(r.maxX - r.minX), r.zRange = Math.abs(r.maxZ - r.minZ);
          for (var p = 0; p < r.yRange.length; p++) n.push(r.yRange[p] / r.gridHeight);
          if (t = r.xRange / r.gridWidth, e = r.yRange / r.gridWidth, i = r.xRange / r.gridHeight, (o = r
              .zRange / r.gridHeight * 16) || (o = 1), r.minY !== Number.MIN_VALUE && 0 !== Math.abs(r
            .minY) && (r.hasNegs = !0), s.globals.seriesYAxisReverseMap.length > 0) {
            var f = function(m, v) {
              var y = s.config.yaxis[s.globals.seriesYAxisReverseMap[v]],
                h = m < 0 ? -1 : 1;
              return m = Math.abs(m), y.logarithmic && (m = a.getBaseLog(y.logBase, m)), -h * m / n[v]
            };
            if (r.isMultipleYAxis) {
              l = [];
              for (var x = 0; x < n.length; x++) l.push(f(r.minYArr[x], x))
            } else(l = []).push(f(r.minY, 0)), r.minY !== Number.MIN_VALUE && 0 !== Math.abs(r.minY) && (c = -
              r.minY / e, d = r.minX / t)
          } else(l = []).push(0), c = 0, d = 0;
          return {
            yRatio: n,
            invertedYRatio: e,
            zRatio: o,
            xRatio: t,
            invertedXRatio: i,
            baseLineInvertedY: c,
            baseLineY: l,
            baseLineX: d
          }
        }
      }, {
        key: "getLogSeries",
        value: function(e) {
          var t = this,
            i = this.w;
          return i.globals.seriesLog = e.map(function(a, s) {
            var r = i.globals.seriesYAxisReverseMap[s];
            return i.config.yaxis[r] && i.config.yaxis[r].logarithmic ? a.map(function(n) {
              return null === n ? null : t.getLogVal(i.config.yaxis[r].logBase, n, s)
            }) : a
          }), i.globals.invalidLogScale ? e : i.globals.seriesLog
        }
      }, {
        key: "getBaseLog",
        value: function(e, t) {
          return Math.log(t) / Math.log(e)
        }
      }, {
        key: "getLogVal",
        value: function(e, t, i) {
          if (t <= 0) return 0;
          var a = this.w,
            s = 0 === a.globals.minYArr[i] ? -1 : this.getBaseLog(e, a.globals.minYArr[i]),
            r = (0 === a.globals.maxYArr[i] ? 0 : this.getBaseLog(e, a.globals.maxYArr[i])) - s;
          return t < 1 ? t / r : (this.getBaseLog(e, t) - s) / r
        }
      }, {
        key: "getLogYRatios",
        value: function(e) {
          var t = this,
            i = this.w,
            a = this.w.globals;
          return a.yLogRatio = e.slice(), a.logYRange = a.yRange.map(function(s, r) {
            var n = i.globals.seriesYAxisReverseMap[r];
            if (i.config.yaxis[n] && t.w.config.yaxis[n].logarithmic) {
              var o, l = -Number.MAX_VALUE,
                c = Number.MIN_VALUE;
              return a.seriesLog.forEach(function(d, g) {
                  d.forEach(function(p) {
                    i.config.yaxis[g] && i.config.yaxis[g].logarithmic && (l = Math.max(p, l), c =
                      Math.min(p, c))
                  })
                }), o = Math.pow(a.yRange[r], Math.abs(c - l) / a.yRange[r]), a.yLogRatio[r] = o / a
                .gridHeight, o
            }
          }), a.invalidLogScale ? e.slice() : a.yLogRatio
        }
      }, {
        key: "drawSeriesByGroup",
        value: function(e, t, i, a) {
          var s = this.w,
            r = [];
          return e.series.length > 0 && t.forEach(function(n) {
            var o = [],
              l = [];
            e.i.forEach(function(c, d) {
              s.config.series[c].group === n && (o.push(e.series[d]), l.push(c))
            }), o.length > 0 && r.push(a.draw(o, i, l))
          }), r
        }
      }], [{
        key: "checkComboSeries",
        value: function(e, t) {
          var i = !1,
            a = 0,
            s = 0;
          return void 0 === t && (t = "line"), e.length && void 0 !== e[0].type && e.forEach(function(r) {
            "bar" !== r.type && "column" !== r.type && "candlestick" !== r.type && "boxPlot" !== r.type ||
              a++, void 0 !== r.type && r.type !== t && s++
          }), s > 0 && (i = !0), {
            comboBarCount: a,
            comboCharts: i
          }
        }
      }, {
        key: "extendArrayProps",
        value: function(e, t, i) {
          var a, s, r, n, o, l;
          return null !== (a = t) && void 0 !== a && a.yaxis && (t = e.extendYAxis(t, i)), null !== (s = t) &&
            void 0 !== s && s.annotations && (t.annotations.yaxis && (t = e.extendYAxisAnnotations(t)),
              null !== (r = t) && void 0 !== r && null !== (n = r.annotations) && void 0 !== n && n.xaxis && (
                t = e.extendXAxisAnnotations(t)), null !== (o = t) && void 0 !== o && null !== (l = o
                .annotations) && void 0 !== l && l.points && (t = e.extendPointAnnotations(t))), t
        }
      }]), w
    }(),
    Le = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.annoCtx = e
      }
      return R(w, [{
        key: "setOrientations",
        value: function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
          if ("vertical" === e.label.orientation) {
            var s = this.w.globals.dom.baseEl.querySelector(
              ".apexcharts-xaxis-annotations .apexcharts-xaxis-annotation-label[rel='".concat(null !== t ?
                t : 0, "']"));
            if (null !== s) {
              var r = s.getBoundingClientRect();
              s.setAttribute("x", parseFloat(s.getAttribute("x")) - r.height + 4), s.setAttribute("y",
                "top" === e.label.position ? parseFloat(s.getAttribute("y")) + r.width : parseFloat(s
                  .getAttribute("y")) - r.width);
              var n = this.annoCtx.graphics.rotateAroundCenter(s),
                l = n.y;
              s.setAttribute("transform", "rotate(-90 ".concat(n.x, " ").concat(l, ")"))
            }
          }
        }
      }, {
        key: "addBackgroundToAnno",
        value: function(e, t) {
          var i = this.w;
          if (!e || void 0 === t.label.text || void 0 !== t.label.text && !String(t.label.text).trim())
          return null;
          var a = i.globals.dom.baseEl.querySelector(".apexcharts-grid").getBoundingClientRect(),
            s = e.getBoundingClientRect(),
            r = t.label.style.padding.left,
            n = t.label.style.padding.right,
            o = t.label.style.padding.top,
            l = t.label.style.padding.bottom;
          "vertical" === t.label.orientation && (o = t.label.style.padding.left, l = t.label.style.padding
            .right, r = t.label.style.padding.top, n = t.label.style.padding.bottom);
          var g = this.annoCtx.graphics.drawRect(s.left - a.left - r - i.globals.barPadForNumericAxis, s.top -
            a.top - o, s.width + r + n, s.height + o + l, t.label.borderRadius, t.label.style.background, 1,
            t.label.borderWidth, t.label.borderColor, 0);
          return t.id && g.node.classList.add(t.id), g
        }
      }, {
        key: "annotationsBackground",
        value: function() {
          var e = this,
            t = this.w,
            i = function(a, s, r) {
              var n = t.globals.dom.baseEl.querySelector(".apexcharts-".concat(r, "-annotations .apexcharts-")
                .concat(r, "-annotation-label[rel='").concat(s, "']"));
              if (n) {
                var o = n.parentNode,
                  l = e.addBackgroundToAnno(n, a);
                l && (o.insertBefore(l.node, n), a.label.mouseEnter && l.node.addEventListener("mouseenter", a
                  .label.mouseEnter.bind(e, a)), a.label.mouseLeave && l.node.addEventListener(
                  "mouseleave", a.label.mouseLeave.bind(e, a)), a.label.click && l.node.addEventListener(
                  "click", a.label.click.bind(e, a)))
              }
            };
          t.config.annotations.xaxis.map(function(a, s) {
            i(a, s, "xaxis")
          }), t.config.annotations.yaxis.map(function(a, s) {
            i(a, s, "yaxis")
          }), t.config.annotations.points.map(function(a, s) {
            i(a, s, "point")
          })
        }
      }, {
        key: "getY1Y2",
        value: function(e, t) {
          var i, a = "y1" === e ? t.y : t.y2,
            s = !1,
            r = this.w;
          if (this.annoCtx.invertAxis) {
            var n = r.globals.labels;
            r.config.xaxis.convertedCatToNumeric && (n = r.globals.categoryLabels);
            var o = n.indexOf(a),
              l = r.globals.dom.baseEl.querySelector(".apexcharts-yaxis-texts-g text:nth-child(" + (o + 1) +
                ")");
            i = l ? parseFloat(l.getAttribute("y")) : (r.globals.gridHeight / n.length - 1) * (o + 1) - r
              .globals.barHeight, void 0 !== t.seriesIndex && r.globals.barHeight && (i = i - r.globals
                .barHeight / 2 * (r.globals.series.length - 1) + r.globals.barHeight * t.seriesIndex)
          } else {
            var c, d = r.globals.seriesYAxisMap[t.yAxisIndex][0];
            (c = r.config.yaxis[t.yAxisIndex].logarithmic ? (a = new q(this.annoCtx.ctx).getLogVal(r.config
              .yaxis[t.yAxisIndex].logBase, a, d)) / r.globals.yLogRatio[d] : (a - r.globals.minYArr[d]) / (
              r.globals.yRange[d] / r.globals.gridHeight)) > r.globals.gridHeight ? (c = r.globals.gridHeight,
                s = !0) : c < 0 && (c = 0, s = !0), i = r.globals.gridHeight - c, !t.marker || null != t.y ||
              (i = 0), r.config.yaxis[t.yAxisIndex] && r.config.yaxis[t.yAxisIndex].reversed && (i = c)
          }
          return "string" == typeof a && a.indexOf("px") > -1 && (i = parseFloat(a)), {
            yP: i,
            clipped: s
          }
        }
      }, {
        key: "getX1X2",
        value: function(e, t) {
          var i, a = "x1" === e ? t.x : t.x2,
            s = this.w,
            o = this.annoCtx.invertAxis ? s.globals.yRange[0] : s.globals.xRange,
            l = !1;
          return i = this.annoCtx.inversedReversedAxis ? ((this.annoCtx.invertAxis ? s.globals.maxY : s
              .globals.maxX) - a) / (o / s.globals.gridWidth) : (a - (this.annoCtx.invertAxis ? s.globals
              .minY : s.globals.minX)) / (o / s.globals.gridWidth), "category" !== s.config.xaxis.type && !s
            .config.xaxis.convertedCatToNumeric || this.annoCtx.invertAxis || s.globals.dataFormatXNumeric ||
            s.config.chart.sparkline.enabled || (i = this.getStringX(a)), "string" == typeof a && a.indexOf(
              "px") > -1 && (i = parseFloat(a)), null == a && t.marker && (i = s.globals.gridWidth),
            void 0 !== t.seriesIndex && s.globals.barWidth && !this.annoCtx.invertAxis && (i = i - s.globals
              .barWidth / 2 * (s.globals.series.length - 1) + s.globals.barWidth * t.seriesIndex), i > s
            .globals.gridWidth ? (i = s.globals.gridWidth, l = !0) : i < 0 && (i = 0, l = !0), {
              x: i,
              clipped: l
            }
        }
      }, {
        key: "getStringX",
        value: function(e) {
          var t = this.w,
            i = e;
          t.config.xaxis.convertedCatToNumeric && t.globals.categoryLabels.length && (e = t.globals
            .categoryLabels.indexOf(e) + 1);
          var a = t.globals.labels.indexOf(e),
            s = t.globals.dom.baseEl.querySelector(".apexcharts-xaxis-texts-g text:nth-child(" + (a + 1) +
              ")");
          return s && (i = parseFloat(s.getAttribute("x"))), i
        }
      }]), w
    }(),
    ot = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.annoCtx = e, this.invertAxis = this.annoCtx.invertAxis, this.helpers = new Le(
          this.annoCtx)
      }
      return R(w, [{
        key: "addXaxisAnnotation",
        value: function(e, t, i) {
          var a, s = this.w,
            r = this.helpers.getX1X2("x1", e),
            n = r.x,
            o = r.clipped,
            l = !0,
            c = e.label.text,
            d = e.strokeDashArray;
          if (P.isNumber(n)) {
            if (null == e.x2) {
              if (!o) {
                var g = this.annoCtx.graphics.drawLine(n + e.offsetX, 0 + e.offsetY, n + e.offsetX, s.globals
                  .gridHeight + e.offsetY, e.borderColor, d, e.borderWidth);
                t.appendChild(g.node), e.id && g.node.classList.add(e.id)
              }
            } else {
              var p = this.helpers.getX1X2("x2", e);
              if (a = p.x, l = p.clipped, !o || !l) {
                if (a < n) {
                  var f = n;
                  n = a, a = f
                }
                var x = this.annoCtx.graphics.drawRect(n + e.offsetX, 0 + e.offsetY, a - n, s.globals
                  .gridHeight + e.offsetY, 0, e.fillColor, e.opacity, 1, e.borderColor, d);
                x.node.classList.add("apexcharts-annotation-rect"), x.attr("clip-path", "url(#gridRectMask"
                  .concat(s.globals.cuid, ")")), t.appendChild(x.node), e.id && x.node.classList.add(e.id)
              }
            }
            if (!o || !l) {
              var m = this.annoCtx.graphics.getTextRects(c, parseFloat(e.label.style.fontSize)),
                y = this.annoCtx.graphics.drawText({
                  x: n + e.label.offsetX,
                  y: ("top" === e.label.position ? 4 : "center" === e.label.position ? s.globals
                    .gridHeight / 2 + ("vertical" === e.label.orientation ? m.width / 2 : 0) : s.globals
                    .gridHeight) + e.label.offsetY - ("vertical" === e.label.orientation ? "top" === e
                    .label.position ? m.width / 2 - 12 : -m.width / 2 : 0),
                  text: c,
                  textAnchor: e.label.textAnchor,
                  fontSize: e.label.style.fontSize,
                  fontFamily: e.label.style.fontFamily,
                  fontWeight: e.label.style.fontWeight,
                  foreColor: e.label.style.color,
                  cssClass: "apexcharts-xaxis-annotation-label ".concat(e.label.style.cssClass, " ").concat(
                    e.id ? e.id : "")
                });
              y.attr({
                rel: i
              }), t.appendChild(y.node), this.annoCtx.helpers.setOrientations(e, i)
            }
          }
        }
      }, {
        key: "drawXAxisAnnotations",
        value: function() {
          var e = this,
            t = this.w,
            i = this.annoCtx.graphics.group({
              class: "apexcharts-xaxis-annotations"
            });
          return t.config.annotations.xaxis.map(function(a, s) {
            e.addXaxisAnnotation(a, i.node, s)
          }), i
        }
      }]), w
    }(),
    Q = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.months31 = [1, 3, 5, 7, 8, 10, 12], this.months30 = [2, 4, 6, 9,
          11
        ], this.daysCntOfYear = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
      }
      return R(w, [{
        key: "isValidDate",
        value: function(e) {
          return "number" != typeof e && !isNaN(this.parseDate(e))
        }
      }, {
        key: "getTimeStamp",
        value: function(e) {
          return Date.parse(e) ? this.w.config.xaxis.labels.datetimeUTC ? new Date(new Date(e).toISOString()
            .substr(0, 25)).getTime() : new Date(e).getTime() : e
        }
      }, {
        key: "getDate",
        value: function(e) {
          return this.w.config.xaxis.labels.datetimeUTC ? new Date(new Date(e).toUTCString()) : new Date(e)
        }
      }, {
        key: "parseDate",
        value: function(e) {
          var t = Date.parse(e);
          if (!isNaN(t)) return this.getTimeStamp(e);
          var i = Date.parse(e.replace(/-/g, "/").replace(/[a-z]+/gi, " "));
          return this.getTimeStamp(i)
        }
      }, {
        key: "parseDateWithTimezone",
        value: function(e) {
          return Date.parse(e.replace(/-/g, "/").replace(/[a-z]+/gi, " "))
        }
      }, {
        key: "formatDate",
        value: function(e, t) {
          var i = this.w.globals.locale,
            a = this.w.config.xaxis.labels.datetimeUTC,
            s = ["\0"].concat(J(i.months)),
            r = ["\x01"].concat(J(i.shortMonths)),
            n = ["\x02"].concat(J(i.days)),
            o = ["\x03"].concat(J(i.shortDays));

          function l(S, C) {
            var L = S + "";
            for (C = C || 2; L.length < C;) L = "0" + L;
            return L
          }
          var c = a ? e.getUTCFullYear() : e.getFullYear();
          t = (t = (t = t.replace(/(^|[^\\])yyyy+/g, "$1" + c)).replace(/(^|[^\\])yy/g, "$1" + c.toString()
            .substr(2, 2))).replace(/(^|[^\\])y/g, "$1" + c);
          var d = (a ? e.getUTCMonth() : e.getMonth()) + 1;
          t = (t = (t = (t = t.replace(/(^|[^\\])MMMM+/g, "$1" + s[0])).replace(/(^|[^\\])MMM/g, "$1" + r[0]))
            .replace(/(^|[^\\])MM/g, "$1" + l(d))).replace(/(^|[^\\])M/g, "$1" + d);
          var g = a ? e.getUTCDate() : e.getDate();
          t = (t = (t = (t = t.replace(/(^|[^\\])dddd+/g, "$1" + n[0])).replace(/(^|[^\\])ddd/g, "$1" + o[0]))
            .replace(/(^|[^\\])dd/g, "$1" + l(g))).replace(/(^|[^\\])d/g, "$1" + g);
          var p = a ? e.getUTCHours() : e.getHours(),
            f = p > 12 ? p - 12 : 0 === p ? 12 : p;
          t = (t = (t = (t = t.replace(/(^|[^\\])HH+/g, "$1" + l(p))).replace(/(^|[^\\])H/g, "$1" + p))
            .replace(/(^|[^\\])hh+/g, "$1" + l(f))).replace(/(^|[^\\])h/g, "$1" + f);
          var x = a ? e.getUTCMinutes() : e.getMinutes();
          t = (t = t.replace(/(^|[^\\])mm+/g, "$1" + l(x))).replace(/(^|[^\\])m/g, "$1" + x);
          var m = a ? e.getUTCSeconds() : e.getSeconds();
          t = (t = t.replace(/(^|[^\\])ss+/g, "$1" + l(m))).replace(/(^|[^\\])s/g, "$1" + m);
          var v = a ? e.getUTCMilliseconds() : e.getMilliseconds();
          t = t.replace(/(^|[^\\])fff+/g, "$1" + l(v, 3)), v = Math.round(v / 10), t = t.replace(
            /(^|[^\\])ff/g, "$1" + l(v)), v = Math.round(v / 10);
          var y = p < 12 ? "AM" : "PM";
          t = (t = (t = t.replace(/(^|[^\\])f/g, "$1" + v)).replace(/(^|[^\\])TT+/g, "$1" + y)).replace(
            /(^|[^\\])T/g, "$1" + y.charAt(0));
          var h = y.toLowerCase();
          t = (t = t.replace(/(^|[^\\])tt+/g, "$1" + h)).replace(/(^|[^\\])t/g, "$1" + h.charAt(0));
          var u = -e.getTimezoneOffset(),
            b = a || !u ? "Z" : u > 0 ? "+" : "-";
          if (!a) {
            var k = (u = Math.abs(u)) % 60;
            b += l(Math.floor(u / 60)) + ":" + l(k)
          }
          t = t.replace(/(^|[^\\])K/g, "$1" + b);
          var A = (a ? e.getUTCDay() : e.getDay()) + 1;
          return (t = (t = (t = (t = t.replace(new RegExp(n[0], "g"), n[A])).replace(new RegExp(o[0], "g"), o[
            A])).replace(new RegExp(s[0], "g"), s[d])).replace(new RegExp(r[0], "g"), r[d])).replace(
            /\\(.)/g, "$1")
        }
      }, {
        key: "getTimeUnitsfromTimestamp",
        value: function(e, t, i) {
          var a = this.w;
          void 0 !== a.config.xaxis.min && (e = a.config.xaxis.min), void 0 !== a.config.xaxis.max && (t = a
            .config.xaxis.max);
          var s = this.getDate(e),
            r = this.getDate(t),
            n = this.formatDate(s, "yyyy MM dd HH mm ss fff").split(" "),
            o = this.formatDate(r, "yyyy MM dd HH mm ss fff").split(" ");
          return {
            minMillisecond: parseInt(n[6], 10),
            maxMillisecond: parseInt(o[6], 10),
            minSecond: parseInt(n[5], 10),
            maxSecond: parseInt(o[5], 10),
            minMinute: parseInt(n[4], 10),
            maxMinute: parseInt(o[4], 10),
            minHour: parseInt(n[3], 10),
            maxHour: parseInt(o[3], 10),
            minDate: parseInt(n[2], 10),
            maxDate: parseInt(o[2], 10),
            minMonth: parseInt(n[1], 10) - 1,
            maxMonth: parseInt(o[1], 10) - 1,
            minYear: parseInt(n[0], 10),
            maxYear: parseInt(o[0], 10)
          }
        }
      }, {
        key: "isLeapYear",
        value: function(e) {
          return e % 4 == 0 && e % 100 != 0 || e % 400 == 0
        }
      }, {
        key: "calculcateLastDaysOfMonth",
        value: function(e, t, i) {
          return this.determineDaysOfMonths(e, t) - i
        }
      }, {
        key: "determineDaysOfYear",
        value: function(e) {
          var t = 365;
          return this.isLeapYear(e) && (t = 366), t
        }
      }, {
        key: "determineRemainingDaysOfYear",
        value: function(e, t, i) {
          var a = this.daysCntOfYear[t] + i;
          return t > 1 && this.isLeapYear() && a++, a
        }
      }, {
        key: "determineDaysOfMonths",
        value: function(e, t) {
          var i = 30;
          switch (e = P.monthMod(e), !0) {
            case this.months30.indexOf(e) > -1:
              2 === e && (i = this.isLeapYear(t) ? 29 : 28);
              break;
            case this.months31.indexOf(e) > -1:
            default:
              i = 31
          }
          return i
        }
      }]), w
    }(),
    me = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.tooltipKeyFormat = "dd MMM"
      }
      return R(w, [{
        key: "xLabelFormat",
        value: function(e, t, i, a) {
          var s = this.w;
          if ("datetime" === s.config.xaxis.type && void 0 === s.config.xaxis.labels.formatter && void 0 === s
            .config.tooltip.x.formatter) {
            var r = new Q(this.ctx);
            return r.formatDate(r.getDate(t), s.config.tooltip.x.format)
          }
          return e(t, i, a)
        }
      }, {
        key: "defaultGeneralFormatter",
        value: function(e) {
          return Array.isArray(e) ? e.map(function(t) {
            return t
          }) : e
        }
      }, {
        key: "defaultYFormatter",
        value: function(e, t, i) {
          var a = this.w;
          if (P.isNumber(e))
            if (0 !== a.globals.yValueDecimal) e = e.toFixed(void 0 !== t.decimalsInFloat ? t
              .decimalsInFloat : a.globals.yValueDecimal);
            else {
              var s = e.toFixed(0);
              e = e == s ? s : e.toFixed(1)
            } return e
        }
      }, {
        key: "setLabelFormatters",
        value: function() {
          var e = this,
            t = this.w;
          return t.globals.xaxisTooltipFormatter = function(i) {
              return e.defaultGeneralFormatter(i)
            }, t.globals.ttKeyFormatter = function(i) {
              return e.defaultGeneralFormatter(i)
            }, t.globals.ttZFormatter = function(i) {
              return i
            }, t.globals.legendFormatter = function(i) {
              return e.defaultGeneralFormatter(i)
            }, t.globals.xLabelFormatter = void 0 !== t.config.xaxis.labels.formatter ? t.config.xaxis.labels
            .formatter : function(i) {
              if (P.isNumber(i)) {
                if (!t.config.xaxis.convertedCatToNumeric && "numeric" === t.config.xaxis.type) {
                  if (P.isNumber(t.config.xaxis.decimalsInFloat)) return i.toFixed(t.config.xaxis
                    .decimalsInFloat);
                  var a = t.globals.maxX - t.globals.minX;
                  return i.toFixed(a > 0 && a < 100 ? 1 : 0)
                }
                return i.toFixed(t.globals.isBarHorizontal && t.globals.maxY - t.globals.minYArr < 4 ? 1 : 0)
              }
              return i
            }, t.globals.ttKeyFormatter = "function" == typeof t.config.tooltip.x.formatter ? t.config.tooltip
            .x.formatter : t.globals.xLabelFormatter, "function" == typeof t.config.xaxis.tooltip.formatter &&
            (t.globals.xaxisTooltipFormatter = t.config.xaxis.tooltip.formatter), (Array.isArray(t.config
              .tooltip.y) || void 0 !== t.config.tooltip.y.formatter) && (t.globals.ttVal = t.config.tooltip
              .y), void 0 !== t.config.tooltip.z.formatter && (t.globals.ttZFormatter = t.config.tooltip.z
              .formatter), void 0 !== t.config.legend.formatter && (t.globals.legendFormatter = t.config
              .legend.formatter), t.config.yaxis.forEach(function(i, a) {
              t.globals.yLabelFormatters[a] = void 0 !== i.labels.formatter ? i.labels.formatter : function(
                s) {
                return t.globals.xyCharts ? Array.isArray(s) ? s.map(function(r) {
                  return e.defaultYFormatter(r, i, a)
                }) : e.defaultYFormatter(s, i, a) : s
              }
            }), t.globals
        }
      }, {
        key: "heatmapLabelFormatters",
        value: function() {
          var e = this.w;
          if ("heatmap" === e.config.chart.type) {
            e.globals.yAxisScale[0].result = e.globals.seriesNames.slice();
            var t = e.globals.seriesNames.reduce(function(i, a) {
              return i.length > a.length ? i : a
            }, 0);
            e.globals.yAxisScale[0].niceMax = t, e.globals.yAxisScale[0].niceMin = t
          }
        }
      }]), w
    }(),
    ce = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "getLabel",
        value: function(e, t, i, a) {
          var m, v, s = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : [],
            r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : "12px",
            n = !(arguments.length > 6 && void 0 !== arguments[6]) || arguments[6],
            o = this.w,
            l = void 0 === e[a] ? "" : e[a],
            c = l,
            d = o.globals.xLabelFormatter,
            g = o.config.xaxis.labels.formatter,
            p = !1,
            f = new me(this.ctx);
          n && (c = f.xLabelFormat(d, l, l, {
              i: a,
              dateFormatter: new Q(this.ctx).formatDate,
              w: o
            }), void 0 !== g && (c = g(l, e[a], {
              i: a,
              dateFormatter: new Q(this.ctx).formatDate,
              w: o
            }))), t.length > 0 ? (m = t[a].unit, v = null, t.forEach(function(b) {
              "month" === b.unit ? v = "year" : "day" === b.unit ? v = "month" : "hour" === b.unit ? v =
                "day" : "minute" === b.unit && (v = "hour")
            }), p = v === m, i = t[a].position, c = t[a].value) : "datetime" === o.config.xaxis.type &&
            void 0 === g && (c = ""), void 0 === c && (c = ""), c = Array.isArray(c) ? c : c.toString();
          var h, y = new X(this.ctx);
          h = o.globals.rotateXLabels && n ? y.getTextRects(c, parseInt(r, 10), null, "rotate(".concat(o
            .config.xaxis.labels.rotate, " 0 0)"), !1) : y.getTextRects(c, parseInt(r, 10));
          var u = !o.config.xaxis.labels.showDuplicates && this.ctx.timeScale;
          return !Array.isArray(c) && ("NaN" === String(c) || s.indexOf(c) >= 0 && u) && (c = ""), {
            x: i,
            text: c,
            textRect: h,
            isBold: p
          }
        }
      }, {
        key: "checkLabelBasedOnTickamount",
        value: function(e, t, i) {
          var a = this.w,
            s = a.config.xaxis.tickAmount;
          return "dataPoints" === s && (s = Math.round(a.globals.gridWidth / 120)), s > i || e % Math.round(
            i / (s + 1)) == 0 || (t.text = ""), t
        }
      }, {
        key: "checkForOverflowingLabels",
        value: function(e, t, i, a, s) {
          var r = this.w;
          if (0 === e && r.globals.skipFirstTimelinelabel && (t.text = ""), e === i - 1 && r.globals
            .skipLastTimelinelabel && (t.text = ""), r.config.xaxis.labels.hideOverlappingLabels && a.length >
            0) {
            var n = s[s.length - 1];
            t.x < n.textRect.width / (r.globals.rotateXLabels ? Math.abs(r.config.xaxis.labels.rotate) / 12 :
              1.01) + n.x && (t.text = "")
          }
          return t
        }
      }, {
        key: "checkForReversedLabels",
        value: function(e, t) {
          var i = this.w;
          return i.config.yaxis[e] && i.config.yaxis[e].reversed && t.reverse(), t
        }
      }, {
        key: "yAxisAllSeriesCollapsed",
        value: function(e) {
          var t = this.w.globals;
          return !t.seriesYAxisMap[e].some(function(i) {
            return -1 === t.collapsedSeriesIndices.indexOf(i)
          })
        }
      }, {
        key: "translateYAxisIndex",
        value: function(e) {
          var t = this.w,
            i = t.globals,
            a = t.config.yaxis;
          return i.series.length > a.length || a.some(function(s) {
            return Array.isArray(s.seriesName)
          }) ? e : i.seriesYAxisReverseMap[e]
        }
      }, {
        key: "isYAxisHidden",
        value: function(e) {
          var t = this.w,
            i = t.config.yaxis[e];
          if (!i.show || this.yAxisAllSeriesCollapsed(e)) return !0;
          if (!i.showForNullSeries) {
            var a = t.globals.seriesYAxisMap[e],
              s = new q(this.ctx);
            return a.every(function(r) {
              return s.isSeriesNull(r)
            })
          }
          return !1
        }
      }, {
        key: "getYAxisForeColor",
        value: function(e, t) {
          var i = this.w;
          return Array.isArray(e) && i.globals.yAxisScale[t] && this.ctx.theme.pushExtraColors(e, i.globals
            .yAxisScale[t].result.length, !1), e
        }
      }, {
        key: "drawYAxisTicks",
        value: function(e, t, i, a, s, r, n) {
          var o = this.w,
            l = new X(this.ctx),
            c = o.globals.translateY + o.config.yaxis[s].labels.offsetY;
          if (o.globals.isBarHorizontal ? c = 0 : "heatmap" === o.config.chart.type && (c += r / 2), a.show &&
            t > 0) {
            !0 === o.config.yaxis[s].opposite && (e += a.width);
            for (var d = t; d >= 0; d--) {
              var g = l.drawLine(e + i.offsetX - a.width + a.offsetX, c + a.offsetY, e + i.offsetX + a
                .offsetX, c + a.offsetY, a.color);
              n.add(g), c += r
            }
          }
        }
      }]), w
    }(),
    lt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.annoCtx = e, this.helpers = new Le(this.annoCtx), this.axesUtils = new ce(this
          .annoCtx)
      }
      return R(w, [{
        key: "addYaxisAnnotation",
        value: function(e, t, i) {
          var a, s = this.w,
            r = e.strokeDashArray,
            n = this.helpers.getY1Y2("y1", e),
            o = n.yP,
            l = n.clipped,
            d = !1,
            g = e.label.text;
          if (null == e.y2) {
            if (!l) {
              d = !0;
              var p = this.annoCtx.graphics.drawLine(0 + e.offsetX, o + e.offsetY, this
                ._getYAxisAnnotationWidth(e), o + e.offsetY, e.borderColor, r, e.borderWidth);
              t.appendChild(p.node), e.id && p.node.classList.add(e.id)
            }
          } else {
            if ((a = (n = this.helpers.getY1Y2("y2", e)).yP) > o) {
              var f = o;
              o = a, a = f
            }
            if (!l || !n.clipped) {
              d = !0;
              var x = this.annoCtx.graphics.drawRect(0 + e.offsetX, a + e.offsetY, this
                ._getYAxisAnnotationWidth(e), o - a, 0, e.fillColor, e.opacity, 1, e.borderColor, r);
              x.node.classList.add("apexcharts-annotation-rect"), x.attr("clip-path", "url(#gridRectMask"
                .concat(s.globals.cuid, ")")), t.appendChild(x.node), e.id && x.node.classList.add(e.id)
            }
          }
          if (d) {
            var v = this.annoCtx.graphics.drawText({
              x: ("right" === e.label.position ? s.globals.gridWidth : "center" === e.label.position ? s
                .globals.gridWidth / 2 : 0) + e.label.offsetX,
              y: (a ?? o) + e.label.offsetY - 3,
              text: g,
              textAnchor: e.label.textAnchor,
              fontSize: e.label.style.fontSize,
              fontFamily: e.label.style.fontFamily,
              fontWeight: e.label.style.fontWeight,
              foreColor: e.label.style.color,
              cssClass: "apexcharts-yaxis-annotation-label ".concat(e.label.style.cssClass, " ").concat(e
                .id ? e.id : "")
            });
            v.attr({
              rel: i
            }), t.appendChild(v.node)
          }
        }
      }, {
        key: "_getYAxisAnnotationWidth",
        value: function(e) {
          var t = this.w;
          return (e.width.indexOf("%") > -1 ? t.globals.gridWidth * parseInt(e.width, 10) / 100 : parseInt(e
            .width, 10)) + e.offsetX
        }
      }, {
        key: "drawYAxisAnnotations",
        value: function() {
          var e = this,
            t = this.w,
            i = this.annoCtx.graphics.group({
              class: "apexcharts-yaxis-annotations"
            });
          return t.config.annotations.yaxis.forEach(function(a, s) {
            a.yAxisIndex = e.axesUtils.translateYAxisIndex(a.yAxisIndex), e.axesUtils.isYAxisHidden(a
              .yAxisIndex) && e.axesUtils.yAxisAllSeriesCollapsed(a.yAxisIndex) || e.addYaxisAnnotation(
              a, i.node, s)
          }), i
        }
      }]), w
    }(),
    ht = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.annoCtx = e, this.helpers = new Le(this.annoCtx)
      }
      return R(w, [{
        key: "addPointAnnotation",
        value: function(e, t, i) {
          if (!(this.w.globals.collapsedSeriesIndices.indexOf(e.seriesIndex) > -1)) {
            var a = this.helpers.getX1X2("x1", e),
              s = a.x,
              r = a.clipped,
              n = (a = this.helpers.getY1Y2("y1", e)).yP,
              o = a.clipped;
            if (P.isNumber(s) && !o && !r) {
              var l = {
                  pSize: e.marker.size,
                  pointStrokeWidth: e.marker.strokeWidth,
                  pointFillColor: e.marker.fillColor,
                  pointStrokeColor: e.marker.strokeColor,
                  shape: e.marker.shape,
                  pRadius: e.marker.radius,
                  class: "apexcharts-point-annotation-marker ".concat(e.marker.cssClass, " ").concat(e.id ? e
                    .id : "")
                },
                c = this.annoCtx.graphics.drawMarker(s + e.marker.offsetX, n + e.marker.offsetY, l);
              t.appendChild(c.node);
              var d = e.label.text ? e.label.text : "",
                g = this.annoCtx.graphics.drawText({
                  x: s + e.label.offsetX,
                  y: n + e.label.offsetY - e.marker.size - parseFloat(e.label.style.fontSize) / 1.6,
                  text: d,
                  textAnchor: e.label.textAnchor,
                  fontSize: e.label.style.fontSize,
                  fontFamily: e.label.style.fontFamily,
                  fontWeight: e.label.style.fontWeight,
                  foreColor: e.label.style.color,
                  cssClass: "apexcharts-point-annotation-label ".concat(e.label.style.cssClass, " ").concat(
                    e.id ? e.id : "")
                });
              if (g.attr({
                  rel: i
                }), t.appendChild(g.node), e.customSVG.SVG) {
                var p = this.annoCtx.graphics.group({
                  class: "apexcharts-point-annotations-custom-svg " + e.customSVG.cssClass
                });
                p.attr({
                  transform: "translate(".concat(s + e.customSVG.offsetX, ", ").concat(n + e.customSVG
                    .offsetY, ")")
                }), p.node.innerHTML = e.customSVG.SVG, t.appendChild(p.node)
              }
              if (e.image.path) {
                var f = e.image.width ? e.image.width : 20,
                  x = e.image.height ? e.image.height : 20;
                c = this.annoCtx.addImage({
                  x: s + e.image.offsetX - f / 2,
                  y: n + e.image.offsetY - x / 2,
                  width: f,
                  height: x,
                  path: e.image.path,
                  appendTo: ".apexcharts-point-annotations"
                })
              }
              e.mouseEnter && c.node.addEventListener("mouseenter", e.mouseEnter.bind(this, e)), e
                .mouseLeave && c.node.addEventListener("mouseleave", e.mouseLeave.bind(this, e)), e.click && c
                .node.addEventListener("click", e.click.bind(this, e))
            }
          }
        }
      }, {
        key: "drawPointAnnotations",
        value: function() {
          var e = this,
            t = this.w,
            i = this.annoCtx.graphics.group({
              class: "apexcharts-point-annotations"
            });
          return t.config.annotations.points.map(function(a, s) {
            e.addPointAnnotation(a, i.node, s)
          }), i
        }
      }]), w
    }(),
    Ve = {
      name: "en",
      options: {
        months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
          "November", "December"
        ],
        shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        toolbar: {
          exportToSVG: "Download SVG",
          exportToPNG: "Download PNG",
          exportToCSV: "Download CSV",
          menu: "Menu",
          selection: "Selection",
          selectionZoom: "Selection Zoom",
          zoomIn: "Zoom In",
          zoomOut: "Zoom Out",
          pan: "Panning",
          reset: "Reset Zoom"
        }
      }
    },
    de = function() {
      function w() {
        F(this, w), this.yAxis = {
          show: !0,
          showAlways: !1,
          showForNullSeries: !0,
          seriesName: void 0,
          opposite: !1,
          reversed: !1,
          logarithmic: !1,
          logBase: 10,
          tickAmount: void 0,
          stepSize: void 0,
          forceNiceScale: !1,
          max: void 0,
          min: void 0,
          floating: !1,
          decimalsInFloat: void 0,
          labels: {
            show: !0,
            minWidth: 0,
            maxWidth: 160,
            offsetX: 0,
            offsetY: 0,
            align: void 0,
            rotate: 0,
            padding: 20,
            style: {
              colors: [],
              fontSize: "11px",
              fontWeight: 400,
              fontFamily: void 0,
              cssClass: ""
            },
            formatter: void 0
          },
          axisBorder: {
            show: !1,
            color: "#e0e0e0",
            width: 1,
            offsetX: 0,
            offsetY: 0
          },
          axisTicks: {
            show: !1,
            color: "#e0e0e0",
            width: 6,
            offsetX: 0,
            offsetY: 0
          },
          title: {
            text: void 0,
            rotate: -90,
            offsetY: 0,
            offsetX: 0,
            style: {
              color: void 0,
              fontSize: "11px",
              fontWeight: 900,
              fontFamily: void 0,
              cssClass: ""
            }
          },
          tooltip: {
            enabled: !1,
            offsetX: 0
          },
          crosshairs: {
            show: !0,
            position: "front",
            stroke: {
              color: "#b6b6b6",
              width: 1,
              dashArray: 0
            }
          }
        }, this.pointAnnotation = {
          id: void 0,
          x: 0,
          y: null,
          yAxisIndex: 0,
          seriesIndex: void 0,
          mouseEnter: void 0,
          mouseLeave: void 0,
          click: void 0,
          marker: {
            size: 4,
            fillColor: "#fff",
            strokeWidth: 2,
            strokeColor: "#333",
            shape: "circle",
            offsetX: 0,
            offsetY: 0,
            radius: 2,
            cssClass: ""
          },
          label: {
            borderColor: "#c2c2c2",
            borderWidth: 1,
            borderRadius: 2,
            text: void 0,
            textAnchor: "middle",
            offsetX: 0,
            offsetY: 0,
            mouseEnter: void 0,
            mouseLeave: void 0,
            click: void 0,
            style: {
              background: "#fff",
              color: void 0,
              fontSize: "11px",
              fontFamily: void 0,
              fontWeight: 400,
              cssClass: "",
              padding: {
                left: 5,
                right: 5,
                top: 2,
                bottom: 2
              }
            }
          },
          customSVG: {
            SVG: void 0,
            cssClass: void 0,
            offsetX: 0,
            offsetY: 0
          },
          image: {
            path: void 0,
            width: 20,
            height: 20,
            offsetX: 0,
            offsetY: 0
          }
        }, this.yAxisAnnotation = {
          id: void 0,
          y: 0,
          y2: null,
          strokeDashArray: 1,
          fillColor: "#c2c2c2",
          borderColor: "#c2c2c2",
          borderWidth: 1,
          opacity: .3,
          offsetX: 0,
          offsetY: 0,
          width: "100%",
          yAxisIndex: 0,
          label: {
            borderColor: "#c2c2c2",
            borderWidth: 1,
            borderRadius: 2,
            text: void 0,
            textAnchor: "end",
            position: "right",
            offsetX: 0,
            offsetY: -3,
            mouseEnter: void 0,
            mouseLeave: void 0,
            click: void 0,
            style: {
              background: "#fff",
              color: void 0,
              fontSize: "11px",
              fontFamily: void 0,
              fontWeight: 400,
              cssClass: "",
              padding: {
                left: 5,
                right: 5,
                top: 2,
                bottom: 2
              }
            }
          }
        }, this.xAxisAnnotation = {
          id: void 0,
          x: 0,
          x2: null,
          strokeDashArray: 1,
          fillColor: "#c2c2c2",
          borderColor: "#c2c2c2",
          borderWidth: 1,
          opacity: .3,
          offsetX: 0,
          offsetY: 0,
          label: {
            borderColor: "#c2c2c2",
            borderWidth: 1,
            borderRadius: 2,
            text: void 0,
            textAnchor: "middle",
            orientation: "vertical",
            position: "top",
            offsetX: 0,
            offsetY: 0,
            mouseEnter: void 0,
            mouseLeave: void 0,
            click: void 0,
            style: {
              background: "#fff",
              color: void 0,
              fontSize: "11px",
              fontFamily: void 0,
              fontWeight: 400,
              cssClass: "",
              padding: {
                left: 5,
                right: 5,
                top: 2,
                bottom: 2
              }
            }
          }
        }, this.text = {
          x: 0,
          y: 0,
          text: "",
          textAnchor: "start",
          foreColor: void 0,
          fontSize: "13px",
          fontFamily: void 0,
          fontWeight: 400,
          appendTo: ".apexcharts-annotations",
          backgroundColor: "transparent",
          borderColor: "#c2c2c2",
          borderRadius: 0,
          borderWidth: 0,
          paddingLeft: 4,
          paddingRight: 4,
          paddingTop: 2,
          paddingBottom: 2
        }
      }
      return R(w, [{
        key: "init",
        value: function() {
          return {
            annotations: {
              yaxis: [this.yAxisAnnotation],
              xaxis: [this.xAxisAnnotation],
              points: [this.pointAnnotation],
              texts: [],
              images: [],
              shapes: []
            },
            chart: {
              animations: {
                enabled: !0,
                easing: "easeinout",
                speed: 800,
                animateGradually: {
                  delay: 150,
                  enabled: !0
                },
                dynamicAnimation: {
                  enabled: !0,
                  speed: 350
                }
              },
              background: "transparent",
              locales: [Ve],
              defaultLocale: "en",
              dropShadow: {
                enabled: !1,
                enabledOnSeries: void 0,
                top: 2,
                left: 2,
                blur: 4,
                color: "#000",
                opacity: .35
              },
              events: {
                animationEnd: void 0,
                beforeMount: void 0,
                mounted: void 0,
                updated: void 0,
                click: void 0,
                mouseMove: void 0,
                mouseLeave: void 0,
                xAxisLabelClick: void 0,
                legendClick: void 0,
                markerClick: void 0,
                selection: void 0,
                dataPointSelection: void 0,
                dataPointMouseEnter: void 0,
                dataPointMouseLeave: void 0,
                beforeZoom: void 0,
                beforeResetZoom: void 0,
                zoomed: void 0,
                scrolled: void 0,
                brushScrolled: void 0
              },
              foreColor: "#373d3f",
              fontFamily: "Helvetica, Arial, sans-serif",
              height: "auto",
              parentHeightOffset: 15,
              redrawOnParentResize: !0,
              redrawOnWindowResize: !0,
              id: void 0,
              group: void 0,
              nonce: void 0,
              offsetX: 0,
              offsetY: 0,
              selection: {
                enabled: !1,
                type: "x",
                fill: {
                  color: "#24292e",
                  opacity: .1
                },
                stroke: {
                  width: 1,
                  color: "#24292e",
                  opacity: .4,
                  dashArray: 3
                },
                xaxis: {
                  min: void 0,
                  max: void 0
                },
                yaxis: {
                  min: void 0,
                  max: void 0
                }
              },
              sparkline: {
                enabled: !1
              },
              brush: {
                enabled: !1,
                autoScaleYaxis: !0,
                target: void 0,
                targets: void 0
              },
              stacked: !1,
              stackOnlyBar: !0,
              stackType: "normal",
              toolbar: {
                show: !0,
                offsetX: 0,
                offsetY: 0,
                tools: {
                  download: !0,
                  selection: !0,
                  zoom: !0,
                  zoomin: !0,
                  zoomout: !0,
                  pan: !0,
                  reset: !0,
                  customIcons: []
                },
                export: {
                  csv: {
                    filename: void 0,
                    columnDelimiter: ",",
                    headerCategory: "category",
                    headerValue: "value",
                    dateFormatter: function(e) {
                      return new Date(e).toDateString()
                    }
                  },
                  png: {
                    filename: void 0
                  },
                  svg: {
                    filename: void 0
                  }
                },
                autoSelected: "zoom"
              },
              type: "line",
              width: "100%",
              zoom: {
                enabled: !0,
                type: "x",
                autoScaleYaxis: !1,
                zoomedArea: {
                  fill: {
                    color: "#90CAF9",
                    opacity: .4
                  },
                  stroke: {
                    color: "#0D47A1",
                    opacity: .4,
                    width: 1
                  }
                }
              }
            },
            plotOptions: {
              line: {
                isSlopeChart: !1
              },
              area: {
                fillTo: "origin"
              },
              bar: {
                horizontal: !1,
                columnWidth: "70%",
                barHeight: "70%",
                distributed: !1,
                borderRadius: 0,
                borderRadiusApplication: "around",
                borderRadiusWhenStacked: "last",
                rangeBarOverlap: !0,
                rangeBarGroupRows: !1,
                hideZeroBarsWhenGrouped: !1,
                isDumbbell: !1,
                dumbbellColors: void 0,
                isFunnel: !1,
                isFunnel3d: !0,
                colors: {
                  ranges: [],
                  backgroundBarColors: [],
                  backgroundBarOpacity: 1,
                  backgroundBarRadius: 0
                },
                dataLabels: {
                  position: "top",
                  maxItems: 100,
                  hideOverflowingLabels: !0,
                  orientation: "horizontal",
                  total: {
                    enabled: !1,
                    formatter: void 0,
                    offsetX: 0,
                    offsetY: 0,
                    style: {
                      color: "#373d3f",
                      fontSize: "12px",
                      fontFamily: void 0,
                      fontWeight: 600
                    }
                  }
                }
              },
              bubble: {
                zScaling: !0,
                minBubbleRadius: void 0,
                maxBubbleRadius: void 0
              },
              candlestick: {
                colors: {
                  upward: "#00B746",
                  downward: "#EF403C"
                },
                wick: {
                  useFillColor: !0
                }
              },
              boxPlot: {
                colors: {
                  upper: "#00E396",
                  lower: "#008FFB"
                }
              },
              heatmap: {
                radius: 2,
                enableShades: !0,
                shadeIntensity: .5,
                reverseNegativeShade: !1,
                distributed: !1,
                useFillColorAsStroke: !1,
                colorScale: {
                  inverse: !1,
                  ranges: [],
                  min: void 0,
                  max: void 0
                }
              },
              treemap: {
                enableShades: !0,
                shadeIntensity: .5,
                distributed: !1,
                reverseNegativeShade: !1,
                useFillColorAsStroke: !1,
                borderRadius: 4,
                dataLabels: {
                  format: "scale"
                },
                colorScale: {
                  inverse: !1,
                  ranges: [],
                  min: void 0,
                  max: void 0
                }
              },
              radialBar: {
                inverseOrder: !1,
                startAngle: 0,
                endAngle: 360,
                offsetX: 0,
                offsetY: 0,
                hollow: {
                  margin: 5,
                  size: "50%",
                  background: "transparent",
                  image: void 0,
                  imageWidth: 150,
                  imageHeight: 150,
                  imageOffsetX: 0,
                  imageOffsetY: 0,
                  imageClipped: !0,
                  position: "front",
                  dropShadow: {
                    enabled: !1,
                    top: 0,
                    left: 0,
                    blur: 3,
                    color: "#000",
                    opacity: .5
                  }
                },
                track: {
                  show: !0,
                  startAngle: void 0,
                  endAngle: void 0,
                  background: "#f2f2f2",
                  strokeWidth: "97%",
                  opacity: 1,
                  margin: 5,
                  dropShadow: {
                    enabled: !1,
                    top: 0,
                    left: 0,
                    blur: 3,
                    color: "#000",
                    opacity: .5
                  }
                },
                dataLabels: {
                  show: !0,
                  name: {
                    show: !0,
                    fontSize: "16px",
                    fontFamily: void 0,
                    fontWeight: 600,
                    color: void 0,
                    offsetY: 0,
                    formatter: function(e) {
                      return e
                    }
                  },
                  value: {
                    show: !0,
                    fontSize: "14px",
                    fontFamily: void 0,
                    fontWeight: 400,
                    color: void 0,
                    offsetY: 16,
                    formatter: function(e) {
                      return e + "%"
                    }
                  },
                  total: {
                    show: !1,
                    label: "Total",
                    fontSize: "16px",
                    fontWeight: 600,
                    fontFamily: void 0,
                    color: void 0,
                    formatter: function(e) {
                      return e.globals.seriesTotals.reduce(function(t, i) {
                        return t + i
                      }, 0) / e.globals.series.length + "%"
                    }
                  }
                },
                barLabels: {
                  enabled: !1,
                  margin: 5,
                  useSeriesColors: !0,
                  fontFamily: void 0,
                  fontWeight: 600,
                  fontSize: "16px",
                  formatter: function(e) {
                    return e
                  },
                  onClick: void 0
                }
              },
              pie: {
                customScale: 1,
                offsetX: 0,
                offsetY: 0,
                startAngle: 0,
                endAngle: 360,
                expandOnClick: !0,
                dataLabels: {
                  offset: 0,
                  minAngleToShowLabel: 10
                },
                donut: {
                  size: "65%",
                  background: "transparent",
                  labels: {
                    show: !1,
                    name: {
                      show: !0,
                      fontSize: "16px",
                      fontFamily: void 0,
                      fontWeight: 600,
                      color: void 0,
                      offsetY: -10,
                      formatter: function(e) {
                        return e
                      }
                    },
                    value: {
                      show: !0,
                      fontSize: "20px",
                      fontFamily: void 0,
                      fontWeight: 400,
                      color: void 0,
                      offsetY: 10,
                      formatter: function(e) {
                        return e
                      }
                    },
                    total: {
                      show: !1,
                      showAlways: !1,
                      label: "Total",
                      fontSize: "16px",
                      fontWeight: 400,
                      fontFamily: void 0,
                      color: void 0,
                      formatter: function(e) {
                        return e.globals.seriesTotals.reduce(function(t, i) {
                          return t + i
                        }, 0)
                      }
                    }
                  }
                }
              },
              polarArea: {
                rings: {
                  strokeWidth: 1,
                  strokeColor: "#e8e8e8"
                },
                spokes: {
                  strokeWidth: 1,
                  connectorColors: "#e8e8e8"
                }
              },
              radar: {
                size: void 0,
                offsetX: 0,
                offsetY: 0,
                polygons: {
                  strokeWidth: 1,
                  strokeColors: "#e8e8e8",
                  connectorColors: "#e8e8e8",
                  fill: {
                    colors: void 0
                  }
                }
              }
            },
            colors: void 0,
            dataLabels: {
              enabled: !0,
              enabledOnSeries: void 0,
              formatter: function(e) {
                return null !== e ? e : ""
              },
              textAnchor: "middle",
              distributed: !1,
              offsetX: 0,
              offsetY: 0,
              style: {
                fontSize: "12px",
                fontFamily: void 0,
                fontWeight: 600,
                colors: void 0
              },
              background: {
                enabled: !0,
                foreColor: "#fff",
                borderRadius: 2,
                padding: 4,
                opacity: .9,
                borderWidth: 1,
                borderColor: "#fff",
                dropShadow: {
                  enabled: !1,
                  top: 1,
                  left: 1,
                  blur: 1,
                  color: "#000",
                  opacity: .45
                }
              },
              dropShadow: {
                enabled: !1,
                top: 1,
                left: 1,
                blur: 1,
                color: "#000",
                opacity: .45
              }
            },
            fill: {
              type: "solid",
              colors: void 0,
              opacity: .85,
              gradient: {
                shade: "dark",
                type: "horizontal",
                shadeIntensity: .5,
                gradientToColors: void 0,
                inverseColors: !0,
                opacityFrom: 1,
                opacityTo: 1,
                stops: [0, 50, 100],
                colorStops: []
              },
              image: {
                src: [],
                width: void 0,
                height: void 0
              },
              pattern: {
                style: "squares",
                width: 6,
                height: 6,
                strokeWidth: 2
              }
            },
            forecastDataPoints: {
              count: 0,
              fillOpacity: .5,
              strokeWidth: void 0,
              dashArray: 4
            },
            grid: {
              show: !0,
              borderColor: "#e0e0e0",
              strokeDashArray: 0,
              position: "back",
              xaxis: {
                lines: {
                  show: !1
                }
              },
              yaxis: {
                lines: {
                  show: !0
                }
              },
              row: {
                colors: void 0,
                opacity: .5
              },
              column: {
                colors: void 0,
                opacity: .5
              },
              padding: {
                top: 0,
                right: 10,
                bottom: 0,
                left: 12
              }
            },
            labels: [],
            legend: {
              show: !0,
              showForSingleSeries: !1,
              showForNullSeries: !0,
              showForZeroSeries: !0,
              floating: !1,
              position: "bottom",
              horizontalAlign: "center",
              inverseOrder: !1,
              fontSize: "12px",
              fontFamily: void 0,
              fontWeight: 400,
              width: void 0,
              height: void 0,
              formatter: void 0,
              tooltipHoverFormatter: void 0,
              offsetX: -20,
              offsetY: 4,
              customLegendItems: [],
              labels: {
                colors: void 0,
                useSeriesColors: !1
              },
              markers: {
                width: 12,
                height: 12,
                strokeWidth: 0,
                fillColors: void 0,
                strokeColor: "#fff",
                radius: 12,
                customHTML: void 0,
                offsetX: 0,
                offsetY: 0,
                onClick: void 0
              },
              itemMargin: {
                horizontal: 5,
                vertical: 2
              },
              onItemClick: {
                toggleDataSeries: !0
              },
              onItemHover: {
                highlightDataSeries: !0
              }
            },
            markers: {
              discrete: [],
              size: 0,
              colors: void 0,
              strokeColors: "#fff",
              strokeWidth: 2,
              strokeOpacity: .9,
              strokeDashArray: 0,
              fillOpacity: 1,
              shape: "circle",
              width: 8,
              height: 8,
              radius: 2,
              offsetX: 0,
              offsetY: 0,
              onClick: void 0,
              onDblClick: void 0,
              showNullDataPoints: !0,
              hover: {
                size: void 0,
                sizeOffset: 3
              }
            },
            noData: {
              text: void 0,
              align: "center",
              verticalAlign: "middle",
              offsetX: 0,
              offsetY: 0,
              style: {
                color: void 0,
                fontSize: "14px",
                fontFamily: void 0
              }
            },
            responsive: [],
            series: void 0,
            states: {
              normal: {
                filter: {
                  type: "none",
                  value: 0
                }
              },
              hover: {
                filter: {
                  type: "lighten",
                  value: .1
                }
              },
              active: {
                allowMultipleDataPointsSelection: !1,
                filter: {
                  type: "darken",
                  value: .5
                }
              }
            },
            title: {
              text: void 0,
              align: "left",
              margin: 5,
              offsetX: 0,
              offsetY: 0,
              floating: !1,
              style: {
                fontSize: "14px",
                fontWeight: 900,
                fontFamily: void 0,
                color: void 0
              }
            },
            subtitle: {
              text: void 0,
              align: "left",
              margin: 5,
              offsetX: 0,
              offsetY: 30,
              floating: !1,
              style: {
                fontSize: "12px",
                fontWeight: 400,
                fontFamily: void 0,
                color: void 0
              }
            },
            stroke: {
              show: !0,
              curve: "smooth",
              lineCap: "butt",
              width: 2,
              colors: void 0,
              dashArray: 0,
              fill: {
                type: "solid",
                colors: void 0,
                opacity: .85,
                gradient: {
                  shade: "dark",
                  type: "horizontal",
                  shadeIntensity: .5,
                  gradientToColors: void 0,
                  inverseColors: !0,
                  opacityFrom: 1,
                  opacityTo: 1,
                  stops: [0, 50, 100],
                  colorStops: []
                }
              }
            },
            tooltip: {
              enabled: !0,
              enabledOnSeries: void 0,
              shared: !0,
              hideEmptySeries: !1,
              followCursor: !1,
              intersect: !1,
              inverseOrder: !1,
              custom: void 0,
              fillSeriesColor: !1,
              theme: "light",
              cssClass: "",
              style: {
                fontSize: "12px",
                fontFamily: void 0
              },
              onDatasetHover: {
                highlightDataSeries: !1
              },
              x: {
                show: !0,
                format: "dd MMM",
                formatter: void 0
              },
              y: {
                formatter: void 0,
                title: {
                  formatter: function(e) {
                    return e ? e + ": " : ""
                  }
                }
              },
              z: {
                formatter: void 0,
                title: "Size: "
              },
              marker: {
                show: !0,
                fillColors: void 0
              },
              items: {
                display: "flex"
              },
              fixed: {
                enabled: !1,
                position: "topRight",
                offsetX: 0,
                offsetY: 0
              }
            },
            xaxis: {
              type: "category",
              categories: [],
              convertedCatToNumeric: !1,
              offsetX: 0,
              offsetY: 0,
              overwriteCategories: void 0,
              labels: {
                show: !0,
                rotate: -45,
                rotateAlways: !1,
                hideOverlappingLabels: !0,
                trim: !1,
                minHeight: void 0,
                maxHeight: 120,
                showDuplicates: !0,
                style: {
                  colors: [],
                  fontSize: "12px",
                  fontWeight: 400,
                  fontFamily: void 0,
                  cssClass: ""
                },
                offsetX: 0,
                offsetY: 0,
                format: void 0,
                formatter: void 0,
                datetimeUTC: !0,
                datetimeFormatter: {
                  year: "yyyy",
                  month: "MMM 'yy",
                  day: "dd MMM",
                  hour: "HH:mm",
                  minute: "HH:mm:ss",
                  second: "HH:mm:ss"
                }
              },
              group: {
                groups: [],
                style: {
                  colors: [],
                  fontSize: "12px",
                  fontWeight: 400,
                  fontFamily: void 0,
                  cssClass: ""
                }
              },
              axisBorder: {
                show: !0,
                color: "#e0e0e0",
                width: "100%",
                height: 1,
                offsetX: 0,
                offsetY: 0
              },
              axisTicks: {
                show: !0,
                color: "#e0e0e0",
                height: 6,
                offsetX: 0,
                offsetY: 0
              },
              stepSize: void 0,
              tickAmount: void 0,
              tickPlacement: "on",
              min: void 0,
              max: void 0,
              range: void 0,
              floating: !1,
              decimalsInFloat: void 0,
              position: "bottom",
              title: {
                text: void 0,
                offsetX: 0,
                offsetY: 0,
                style: {
                  color: void 0,
                  fontSize: "12px",
                  fontWeight: 900,
                  fontFamily: void 0,
                  cssClass: ""
                }
              },
              crosshairs: {
                show: !0,
                width: 1,
                position: "back",
                opacity: .9,
                stroke: {
                  color: "#b6b6b6",
                  width: 1,
                  dashArray: 3
                },
                fill: {
                  type: "solid",
                  color: "#B1B9C4",
                  gradient: {
                    colorFrom: "#D8E3F0",
                    colorTo: "#BED1E6",
                    stops: [0, 100],
                    opacityFrom: .4,
                    opacityTo: .5
                  }
                },
                dropShadow: {
                  enabled: !1,
                  left: 0,
                  top: 0,
                  blur: 1,
                  opacity: .4
                }
              },
              tooltip: {
                enabled: !0,
                offsetY: 0,
                formatter: void 0,
                style: {
                  fontSize: "12px",
                  fontFamily: void 0
                }
              }
            },
            yaxis: this.yAxis,
            theme: {
              mode: "light",
              palette: "palette1",
              monochrome: {
                enabled: !1,
                color: "#008FFB",
                shadeTo: "light",
                shadeIntensity: .65
              }
            }
          }
        }
      }]), w
    }(),
    ct = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.graphics = new X(this.ctx), this.w.globals.isBarHorizontal && (
            this.invertAxis = !0), this.helpers = new Le(this), this.xAxisAnnotations = new ot(this), this
          .yAxisAnnotations = new lt(this), this.pointsAnnotations = new ht(this), this.w.globals.isBarHorizontal &&
          this.w.config.yaxis[0].reversed && (this.inversedReversedAxis = !0), this.xDivision = this.w.globals
          .gridWidth / this.w.globals.dataPoints
      }
      return R(w, [{
        key: "drawAxesAnnotations",
        value: function() {
          var e = this.w;
          if (e.globals.axisCharts) {
            for (var t = this.yAxisAnnotations.drawYAxisAnnotations(), i = this.xAxisAnnotations
                .drawXAxisAnnotations(), a = this.pointsAnnotations.drawPointAnnotations(), s = e.config.chart
                .animations.enabled, r = [t, i, a], n = [i.node, t.node, a.node], o = 0; o < 3; o++) e.globals
              .dom.elGraphical.add(r[o]), !s || e.globals.resized || e.globals.dataChanged || "scatter" !== e
              .config.chart.type && "bubble" !== e.config.chart.type && e.globals.dataPoints > 1 && n[o]
              .classList.add("apexcharts-element-hidden"), e.globals.delayedElements.push({
                el: n[o],
                index: 0
              });
            this.helpers.annotationsBackground()
          }
        }
      }, {
        key: "drawImageAnnos",
        value: function() {
          var e = this;
          this.w.config.annotations.images.map(function(t, i) {
            e.addImage(t, i)
          })
        }
      }, {
        key: "drawTextAnnos",
        value: function() {
          var e = this;
          this.w.config.annotations.texts.map(function(t, i) {
            e.addText(t, i)
          })
        }
      }, {
        key: "addXaxisAnnotation",
        value: function(e, t, i) {
          this.xAxisAnnotations.addXaxisAnnotation(e, t, i)
        }
      }, {
        key: "addYaxisAnnotation",
        value: function(e, t, i) {
          this.yAxisAnnotations.addYaxisAnnotation(e, t, i)
        }
      }, {
        key: "addPointAnnotation",
        value: function(e, t, i) {
          this.pointsAnnotations.addPointAnnotation(e, t, i)
        }
      }, {
        key: "addText",
        value: function(e, t) {
          var s = e.text,
            g = e.backgroundColor,
            p = e.borderWidth,
            f = e.strokeDashArray,
            x = e.borderRadius,
            m = e.borderColor,
            v = e.appendTo,
            y = void 0 === v ? ".apexcharts-svg" : v,
            h = e.paddingLeft,
            u = void 0 === h ? 4 : h,
            b = e.paddingRight,
            k = void 0 === b ? 4 : b,
            A = e.paddingBottom,
            S = void 0 === A ? 2 : A,
            C = e.paddingTop,
            L = void 0 === C ? 2 : C,
            M = this.w,
            z = this.graphics.drawText({
              x: e.x,
              y: e.y,
              text: s,
              textAnchor: e.textAnchor || "start",
              fontSize: e.fontSize || "12px",
              fontWeight: e.fontWeight || "regular",
              fontFamily: e.fontFamily || M.config.chart.fontFamily,
              foreColor: e.foreColor || M.config.chart.foreColor,
              cssClass: e.cssClass
            }),
            I = M.globals.dom.baseEl.querySelector(y);
          I && I.appendChild(z.node);
          var T = z.bbox();
          if (s) {
            var E = this.graphics.drawRect(T.x - u, T.y - L, T.width + u + k, T.height + S + L, x, g ||
              "transparent", 1, p, m, f);
            I.insertBefore(E.node, z.node)
          }
        }
      }, {
        key: "addImage",
        value: function(e, t) {
          var i = this.w,
            s = e.x,
            r = void 0 === s ? 0 : s,
            n = e.y,
            o = void 0 === n ? 0 : n,
            l = e.width,
            c = void 0 === l ? 20 : l,
            d = e.height,
            g = void 0 === d ? 20 : d,
            p = e.appendTo,
            f = void 0 === p ? ".apexcharts-svg" : p,
            x = i.globals.dom.Paper.image(e.path);
          x.size(c, g).move(r, o);
          var m = i.globals.dom.baseEl.querySelector(f);
          return m && m.appendChild(x.node), x
        }
      }, {
        key: "addXaxisAnnotationExternal",
        value: function(e, t, i) {
          return this.addAnnotationExternal({
            params: e,
            pushToMemory: t,
            context: i,
            type: "xaxis",
            contextMethod: i.addXaxisAnnotation
          }), i
        }
      }, {
        key: "addYaxisAnnotationExternal",
        value: function(e, t, i) {
          return this.addAnnotationExternal({
            params: e,
            pushToMemory: t,
            context: i,
            type: "yaxis",
            contextMethod: i.addYaxisAnnotation
          }), i
        }
      }, {
        key: "addPointAnnotationExternal",
        value: function(e, t, i) {
          return void 0 === this.invertAxis && (this.invertAxis = i.w.globals.isBarHorizontal), this
            .addAnnotationExternal({
              params: e,
              pushToMemory: t,
              context: i,
              type: "point",
              contextMethod: i.addPointAnnotation
            }), i
        }
      }, {
        key: "addAnnotationExternal",
        value: function(e) {
          var t = e.params,
            i = e.pushToMemory,
            a = e.context,
            s = e.type,
            r = e.contextMethod,
            n = a,
            o = n.w,
            l = o.globals.dom.baseEl.querySelector(".apexcharts-".concat(s, "-annotations")),
            c = l.childNodes.length + 1,
            d = new de,
            g = Object.assign({}, "xaxis" === s ? d.xAxisAnnotation : "yaxis" === s ? d.yAxisAnnotation : d
              .pointAnnotation),
            p = P.extend(g, t);
          switch (s) {
            case "xaxis":
              this.addXaxisAnnotation(p, l, c);
              break;
            case "yaxis":
              this.addYaxisAnnotation(p, l, c);
              break;
            case "point":
              this.addPointAnnotation(p, l, c)
          }
          var f = o.globals.dom.baseEl.querySelector(".apexcharts-".concat(s, "-annotations .apexcharts-")
              .concat(s, "-annotation-label[rel='").concat(c, "']")),
            x = this.helpers.addBackgroundToAnno(f, p);
          return x && l.insertBefore(x.node, f), i && o.globals.memory.methodsToExec.push({
            context: n,
            id: p.id ? p.id : P.randomId(),
            method: r,
            label: "addAnnotation",
            params: t
          }), a
        }
      }, {
        key: "clearAnnotations",
        value: function(e) {
          var t = e.w,
            i = t.globals.dom.baseEl.querySelectorAll(
              ".apexcharts-yaxis-annotations, .apexcharts-xaxis-annotations, .apexcharts-point-annotations");
          t.globals.memory.methodsToExec.map(function(a, s) {
            "addText" !== a.label && "addAnnotation" !== a.label || t.globals.memory.methodsToExec.splice(
              s, 1)
          }), i = P.listToArray(i), Array.prototype.forEach.call(i, function(a) {
            for (; a.firstChild;) a.removeChild(a.firstChild)
          })
        }
      }, {
        key: "removeAnnotation",
        value: function(e, t) {
          var i = e.w,
            a = i.globals.dom.baseEl.querySelectorAll(".".concat(t));
          a && (i.globals.memory.methodsToExec.map(function(s, r) {
            s.id === t && i.globals.memory.methodsToExec.splice(r, 1)
          }), Array.prototype.forEach.call(a, function(s) {
            s.parentElement.removeChild(s)
          }))
        }
      }]), w
    }(),
    ze = function(w) {
      var e, t = w.isTimeline,
        i = w.ctx,
        a = w.seriesIndex,
        s = w.dataPointIndex,
        r = w.y1,
        n = w.y2,
        o = w.w,
        l = o.globals.seriesRangeStart[a][s],
        c = o.globals.seriesRangeEnd[a][s],
        d = o.globals.labels[s],
        g = o.config.series[a].name ? o.config.series[a].name : "",
        p = o.globals.ttKeyFormatter,
        f = o.config.tooltip.y.title.formatter,
        x = {
          w: o,
          seriesIndex: a,
          dataPointIndex: s,
          start: l,
          end: c
        };
      "function" == typeof f && (g = f(g, x)), null !== (e = o.config.series[a].data[s]) && void 0 !== e && e.x && (
        d = o.config.series[a].data[s].x), t || "datetime" === o.config.xaxis.type && (d = new me(i).xLabelFormat(o
        .globals.ttKeyFormatter, d, d, {
          i: void 0,
          dateFormatter: new Q(i).formatDate,
          w: o
        })), "function" == typeof p && (d = p(d, x)), Number.isFinite(r) && Number.isFinite(n) && (l = r, c = n);
      var m = "",
        v = "",
        y = o.globals.colors[a];
      if (void 0 === o.config.tooltip.x.formatter)
        if ("datetime" === o.config.xaxis.type) {
          var h = new Q(i);
          m = h.formatDate(h.getDate(l), o.config.tooltip.x.format), v = h.formatDate(h.getDate(c), o.config.tooltip.x
            .format)
        } else m = l, v = c;
      else m = o.config.tooltip.x.formatter(l), v = o.config.tooltip.x.formatter(c);
      return {
        start: l,
        end: c,
        startVal: m,
        endVal: v,
        ylabel: d,
        color: y,
        seriesName: g
      }
    },
    Xe = function(w) {
      var e = w.color,
        t = w.seriesName,
        i = w.ylabel,
        a = w.start,
        s = w.end,
        r = w.seriesIndex,
        n = w.dataPointIndex,
        o = w.ctx.tooltip.tooltipLabels.getFormatters(r);
      a = o.yLbFormatter(a), s = o.yLbFormatter(s);
      var l = o.yLbFormatter(w.w.globals.series[r][n]),
        c = '<span class="value start-value">\n  '.concat(a,
          '\n  </span> <span class="separator">-</span> <span class="value end-value">\n  ').concat(s, "\n  </span>");
      return '<div class="apexcharts-tooltip-rangebar"><div> <span class="series-name" style="color: ' + e + '">' + (
        t || "") + '</span></div><div> <span class="category">' + i + ": </span> " + (w.w.globals.comboCharts ?
        "rangeArea" === w.w.config.series[r].type || "rangeBar" === w.w.config.series[r].type ? c : "<span>".concat(
          l, "</span>") : c) + " </div></div>"
    },
    ve = function() {
      function w(e) {
        F(this, w), this.opts = e
      }
      return R(w, [{
        key: "hideYAxis",
        value: function() {
          this.opts.yaxis[0].show = !1, this.opts.yaxis[0].title.text = "", this.opts.yaxis[0].axisBorder
            .show = !1, this.opts.yaxis[0].axisTicks.show = !1, this.opts.yaxis[0].floating = !0
        }
      }, {
        key: "line",
        value: function() {
          return {
            chart: {
              animations: {
                easing: "swing"
              }
            },
            dataLabels: {
              enabled: !1
            },
            stroke: {
              width: 5,
              curve: "straight"
            },
            markers: {
              size: 0,
              hover: {
                sizeOffset: 6
              }
            },
            xaxis: {
              crosshairs: {
                width: 1
              }
            }
          }
        }
      }, {
        key: "sparkline",
        value: function(e) {
          return this.hideYAxis(), P.extend(e, {
            grid: {
              show: !1,
              padding: {
                left: 0,
                right: 0,
                top: 0,
                bottom: 0
              }
            },
            legend: {
              show: !1
            },
            xaxis: {
              labels: {
                show: !1
              },
              tooltip: {
                enabled: !1
              },
              axisBorder: {
                show: !1
              },
              axisTicks: {
                show: !1
              }
            },
            chart: {
              toolbar: {
                show: !1
              },
              zoom: {
                enabled: !1
              }
            },
            dataLabels: {
              enabled: !1
            }
          })
        }
      }, {
        key: "slope",
        value: function() {
          return this.hideYAxis(), {
            chart: {
              toolbar: {
                show: !1
              },
              zoom: {
                enabled: !1
              }
            },
            dataLabels: {
              enabled: !0,
              formatter: function(e, t) {
                return null !== e ? t.w.config.series[t.seriesIndex].name + ": " + e : ""
              },
              background: {
                enabled: !1
              },
              offsetX: -5
            },
            grid: {
              xaxis: {
                lines: {
                  show: !0
                }
              },
              yaxis: {
                lines: {
                  show: !1
                }
              }
            },
            xaxis: {
              position: "top",
              labels: {
                style: {
                  fontSize: 14,
                  fontWeight: 900
                }
              },
              tooltip: {
                enabled: !1
              },
              crosshairs: {
                show: !1
              }
            },
            markers: {
              size: 8,
              hover: {
                sizeOffset: 1
              }
            },
            legend: {
              show: !1
            },
            tooltip: {
              shared: !1,
              intersect: !0,
              followCursor: !0
            },
            stroke: {
              width: 5,
              curve: "straight"
            }
          }
        }
      }, {
        key: "bar",
        value: function() {
          return {
            chart: {
              stacked: !1,
              animations: {
                easing: "swing"
              }
            },
            plotOptions: {
              bar: {
                dataLabels: {
                  position: "center"
                }
              }
            },
            dataLabels: {
              style: {
                colors: ["#fff"]
              },
              background: {
                enabled: !1
              }
            },
            stroke: {
              width: 0,
              lineCap: "round"
            },
            fill: {
              opacity: .85
            },
            legend: {
              markers: {
                shape: "square",
                radius: 2,
                size: 8
              }
            },
            tooltip: {
              shared: !1,
              intersect: !0
            },
            xaxis: {
              tooltip: {
                enabled: !1
              },
              tickPlacement: "between",
              crosshairs: {
                width: "barWidth",
                position: "back",
                fill: {
                  type: "gradient"
                },
                dropShadow: {
                  enabled: !1
                },
                stroke: {
                  width: 0
                }
              }
            }
          }
        }
      }, {
        key: "funnel",
        value: function() {
          return this.hideYAxis(), Y(Y({}, this.bar()), {}, {
            chart: {
              animations: {
                easing: "linear",
                speed: 800,
                animateGradually: {
                  enabled: !1
                }
              }
            },
            plotOptions: {
              bar: {
                horizontal: !0,
                borderRadiusApplication: "around",
                borderRadius: 0,
                dataLabels: {
                  position: "center"
                }
              }
            },
            grid: {
              show: !1,
              padding: {
                left: 0,
                right: 0
              }
            },
            xaxis: {
              labels: {
                show: !1
              },
              tooltip: {
                enabled: !1
              },
              axisBorder: {
                show: !1
              },
              axisTicks: {
                show: !1
              }
            }
          })
        }
      }, {
        key: "candlestick",
        value: function() {
          var e = this;
          return {
            stroke: {
              width: 1,
              colors: ["#333"]
            },
            fill: {
              opacity: 1
            },
            dataLabels: {
              enabled: !1
            },
            tooltip: {
              shared: !0,
              custom: function(t) {
                return e._getBoxTooltip(t.w, t.seriesIndex, t.dataPointIndex, ["Open", "High", "", "Low",
                  "Close"
                ], "candlestick")
              }
            },
            states: {
              active: {
                filter: {
                  type: "none"
                }
              }
            },
            xaxis: {
              crosshairs: {
                width: 1
              }
            }
          }
        }
      }, {
        key: "boxPlot",
        value: function() {
          var e = this;
          return {
            chart: {
              animations: {
                dynamicAnimation: {
                  enabled: !1
                }
              }
            },
            stroke: {
              width: 1,
              colors: ["#24292e"]
            },
            dataLabels: {
              enabled: !1
            },
            tooltip: {
              shared: !0,
              custom: function(t) {
                return e._getBoxTooltip(t.w, t.seriesIndex, t.dataPointIndex, ["Minimum", "Q1", "Median",
                  "Q3", "Maximum"
                ], "boxPlot")
              }
            },
            markers: {
              size: 5,
              strokeWidth: 1,
              strokeColors: "#111"
            },
            xaxis: {
              crosshairs: {
                width: 1
              }
            }
          }
        }
      }, {
        key: "rangeBar",
        value: function() {
          return {
            chart: {
              animations: {
                animateGradually: !1
              }
            },
            stroke: {
              width: 0,
              lineCap: "square"
            },
            plotOptions: {
              bar: {
                borderRadius: 0,
                dataLabels: {
                  position: "center"
                }
              }
            },
            dataLabels: {
              enabled: !1,
              formatter: function(e, t) {
                var i = t.seriesIndex,
                  a = t.dataPointIndex,
                  s = t.w,
                  r = function() {
                    return s.globals.seriesRangeEnd[i][a] - s.globals.seriesRangeStart[i][a]
                  };
                return s.globals.comboCharts ? "rangeBar" === s.config.series[i].type || "rangeArea" === s
                  .config.series[i].type ? r() : e : r()
              },
              background: {
                enabled: !1
              },
              style: {
                colors: ["#fff"]
              }
            },
            markers: {
              size: 10
            },
            tooltip: {
              shared: !1,
              followCursor: !0,
              custom: function(e) {
                return e.w.config.plotOptions && e.w.config.plotOptions.bar && e.w.config.plotOptions.bar
                  .horizontal ? (a = (i = ze(Y(Y({}, t = e), {}, {
                    isTimeline: !0
                  }))).color, s = i.seriesName, r = i.ylabel, n = i.startVal, o = i.endVal, Xe(Y(Y({},
                  t), {}, {
                    color: a,
                    seriesName: s,
                    ylabel: r,
                    start: n,
                    end: o
                  }))) : function(t) {
                    var i = ze(t),
                      a = i.color,
                      s = i.seriesName,
                      r = i.ylabel,
                      n = i.start,
                      o = i.end;
                    return Xe(Y(Y({}, t), {}, {
                      color: a,
                      seriesName: s,
                      ylabel: r,
                      start: n,
                      end: o
                    }))
                  }(e);
                var t, i, a, s, r, n, o
              }
            },
            xaxis: {
              tickPlacement: "between",
              tooltip: {
                enabled: !1
              },
              crosshairs: {
                stroke: {
                  width: 0
                }
              }
            }
          }
        }
      }, {
        key: "dumbbell",
        value: function(e) {
          var t, i;
          return null !== (t = e.plotOptions.bar) && void 0 !== t && t.barHeight || (e.plotOptions.bar
            .barHeight = 2), null !== (i = e.plotOptions.bar) && void 0 !== i && i.columnWidth || (e
            .plotOptions.bar.columnWidth = 2), e
        }
      }, {
        key: "area",
        value: function() {
          return {
            stroke: {
              width: 4,
              fill: {
                type: "solid",
                gradient: {
                  inverseColors: !1,
                  shade: "light",
                  type: "vertical",
                  opacityFrom: .65,
                  opacityTo: .5,
                  stops: [0, 100, 100]
                }
              }
            },
            fill: {
              type: "gradient",
              gradient: {
                inverseColors: !1,
                shade: "light",
                type: "vertical",
                opacityFrom: .65,
                opacityTo: .5,
                stops: [0, 100, 100]
              }
            },
            markers: {
              size: 0,
              hover: {
                sizeOffset: 6
              }
            },
            tooltip: {
              followCursor: !1
            }
          }
        }
      }, {
        key: "rangeArea",
        value: function() {
          return {
            stroke: {
              curve: "straight",
              width: 0
            },
            fill: {
              type: "solid",
              opacity: .6
            },
            markers: {
              size: 0
            },
            states: {
              hover: {
                filter: {
                  type: "none"
                }
              },
              active: {
                filter: {
                  type: "none"
                }
              }
            },
            tooltip: {
              intersect: !1,
              shared: !0,
              followCursor: !0,
              custom: function(e) {
                return a = (i = ze(t = e)).color, s = i.seriesName, r = i.ylabel, n = i.start, o = i.end,
                  Xe(Y(Y({}, t), {}, {
                    color: a,
                    seriesName: s,
                    ylabel: r,
                    start: n,
                    end: o
                  }));
                var t, i, a, s, r, n, o
              }
            }
          }
        }
      }, {
        key: "brush",
        value: function(e) {
          return P.extend(e, {
            chart: {
              toolbar: {
                autoSelected: "selection",
                show: !1
              },
              zoom: {
                enabled: !1
              }
            },
            dataLabels: {
              enabled: !1
            },
            stroke: {
              width: 1
            },
            tooltip: {
              enabled: !1
            },
            xaxis: {
              tooltip: {
                enabled: !1
              }
            }
          })
        }
      }, {
        key: "stacked100",
        value: function(e) {
          e.dataLabels = e.dataLabels || {}, e.dataLabels.formatter = e.dataLabels.formatter || void 0;
          var t = e.dataLabels.formatter;
          return e.yaxis.forEach(function(i, a) {
            e.yaxis[a].min = 0, e.yaxis[a].max = 100
          }), "bar" === e.chart.type && (e.dataLabels.formatter = t || function(i) {
            return "number" == typeof i && i ? i.toFixed(0) + "%" : i
          }), e
        }
      }, {
        key: "stackedBars",
        value: function() {
          var e = this.bar();
          return Y(Y({}, e), {}, {
            plotOptions: Y(Y({}, e.plotOptions), {}, {
              bar: Y(Y({}, e.plotOptions.bar), {}, {
                borderRadiusApplication: "end",
                borderRadiusWhenStacked: "last"
              })
            })
          })
        }
      }, {
        key: "convertCatToNumeric",
        value: function(e) {
          return e.xaxis.convertedCatToNumeric = !0, e
        }
      }, {
        key: "convertCatToNumericXaxis",
        value: function(e, t, i) {
          e.xaxis.type = "numeric", e.xaxis.labels = e.xaxis.labels || {}, e.xaxis.labels.formatter = e.xaxis
            .labels.formatter || function(r) {
              return P.isNumber(r) ? Math.floor(r) : r
            };
          var a = e.xaxis.labels.formatter,
            s = e.xaxis.categories && e.xaxis.categories.length ? e.xaxis.categories : e.labels;
          return i && i.length && (s = i.map(function(r) {
              return Array.isArray(r) ? r : String(r)
            })), s && s.length && (e.xaxis.labels.formatter = function(r) {
              return P.isNumber(r) ? a(s[Math.floor(r) - 1]) : a(r)
            }), e.xaxis.categories = [], e.labels = [], e.xaxis.tickAmount = e.xaxis.tickAmount ||
            "dataPoints", e
        }
      }, {
        key: "bubble",
        value: function() {
          return {
            dataLabels: {
              style: {
                colors: ["#fff"]
              }
            },
            tooltip: {
              shared: !1,
              intersect: !0
            },
            xaxis: {
              crosshairs: {
                width: 0
              }
            },
            fill: {
              type: "solid",
              gradient: {
                shade: "light",
                inverse: !0,
                shadeIntensity: .55,
                opacityFrom: .4,
                opacityTo: .8
              }
            }
          }
        }
      }, {
        key: "scatter",
        value: function() {
          return {
            dataLabels: {
              enabled: !1
            },
            tooltip: {
              shared: !1,
              intersect: !0
            },
            markers: {
              size: 6,
              strokeWidth: 1,
              hover: {
                sizeOffset: 2
              }
            }
          }
        }
      }, {
        key: "heatmap",
        value: function() {
          return {
            chart: {
              stacked: !1
            },
            fill: {
              opacity: 1
            },
            dataLabels: {
              style: {
                colors: ["#fff"]
              }
            },
            stroke: {
              colors: ["#fff"]
            },
            tooltip: {
              followCursor: !0,
              marker: {
                show: !1
              },
              x: {
                show: !1
              }
            },
            legend: {
              position: "top",
              markers: {
                shape: "square",
                size: 10,
                offsetY: 2
              }
            },
            grid: {
              padding: {
                right: 20
              }
            }
          }
        }
      }, {
        key: "treemap",
        value: function() {
          return {
            chart: {
              zoom: {
                enabled: !1
              }
            },
            dataLabels: {
              style: {
                fontSize: 14,
                fontWeight: 600,
                colors: ["#fff"]
              }
            },
            stroke: {
              show: !0,
              width: 2,
              colors: ["#fff"]
            },
            legend: {
              show: !1
            },
            fill: {
              gradient: {
                stops: [0, 100]
              }
            },
            tooltip: {
              followCursor: !0,
              x: {
                show: !1
              }
            },
            grid: {
              padding: {
                left: 0,
                right: 0
              }
            },
            xaxis: {
              crosshairs: {
                show: !1
              },
              tooltip: {
                enabled: !1
              }
            }
          }
        }
      }, {
        key: "pie",
        value: function() {
          return {
            chart: {
              toolbar: {
                show: !1
              }
            },
            plotOptions: {
              pie: {
                donut: {
                  labels: {
                    show: !1
                  }
                }
              }
            },
            dataLabels: {
              formatter: function(e) {
                return e.toFixed(1) + "%"
              },
              style: {
                colors: ["#fff"]
              },
              background: {
                enabled: !1
              },
              dropShadow: {
                enabled: !0
              }
            },
            stroke: {
              colors: ["#fff"]
            },
            fill: {
              opacity: 1,
              gradient: {
                shade: "light",
                stops: [0, 100]
              }
            },
            tooltip: {
              theme: "dark",
              fillSeriesColor: !0
            },
            legend: {
              position: "right"
            }
          }
        }
      }, {
        key: "donut",
        value: function() {
          return {
            chart: {
              toolbar: {
                show: !1
              }
            },
            dataLabels: {
              formatter: function(e) {
                return e.toFixed(1) + "%"
              },
              style: {
                colors: ["#fff"]
              },
              background: {
                enabled: !1
              },
              dropShadow: {
                enabled: !0
              }
            },
            stroke: {
              colors: ["#fff"]
            },
            fill: {
              opacity: 1,
              gradient: {
                shade: "light",
                shadeIntensity: .35,
                stops: [80, 100],
                opacityFrom: 1,
                opacityTo: 1
              }
            },
            tooltip: {
              theme: "dark",
              fillSeriesColor: !0
            },
            legend: {
              position: "right"
            }
          }
        }
      }, {
        key: "polarArea",
        value: function() {
          return {
            chart: {
              toolbar: {
                show: !1
              }
            },
            dataLabels: {
              formatter: function(e) {
                return e.toFixed(1) + "%"
              },
              enabled: !1
            },
            stroke: {
              show: !0,
              width: 2
            },
            fill: {
              opacity: .7
            },
            tooltip: {
              theme: "dark",
              fillSeriesColor: !0
            },
            legend: {
              position: "right"
            }
          }
        }
      }, {
        key: "radar",
        value: function() {
          return this.opts.yaxis[0].labels.offsetY = this.opts.yaxis[0].labels.offsetY ? this.opts.yaxis[0]
            .labels.offsetY : 6, {
              dataLabels: {
                enabled: !1,
                style: {
                  fontSize: "11px"
                }
              },
              stroke: {
                width: 2
              },
              markers: {
                size: 3,
                strokeWidth: 1,
                strokeOpacity: 1
              },
              fill: {
                opacity: .2
              },
              tooltip: {
                shared: !1,
                intersect: !0,
                followCursor: !0
              },
              grid: {
                show: !1
              },
              xaxis: {
                labels: {
                  formatter: function(e) {
                    return e
                  },
                  style: {
                    colors: ["#a8a8a8"],
                    fontSize: "11px"
                  }
                },
                tooltip: {
                  enabled: !1
                },
                crosshairs: {
                  show: !1
                }
              }
            }
        }
      }, {
        key: "radialBar",
        value: function() {
          return {
            chart: {
              animations: {
                dynamicAnimation: {
                  enabled: !0,
                  speed: 800
                }
              },
              toolbar: {
                show: !1
              }
            },
            fill: {
              gradient: {
                shade: "dark",
                shadeIntensity: .4,
                inverseColors: !1,
                type: "diagonal2",
                opacityFrom: 1,
                opacityTo: 1,
                stops: [70, 98, 100]
              }
            },
            legend: {
              show: !1,
              position: "right"
            },
            tooltip: {
              enabled: !1,
              fillSeriesColor: !0
            }
          }
        }
      }, {
        key: "_getBoxTooltip",
        value: function(e, t, i, a, s) {
          var r = e.globals.seriesCandleO[t][i],
            n = e.globals.seriesCandleH[t][i],
            o = e.globals.seriesCandleM[t][i],
            l = e.globals.seriesCandleL[t][i],
            c = e.globals.seriesCandleC[t][i];
          return e.config.series[t].type && e.config.series[t].type !== s ?
            '<div class="apexcharts-custom-tooltip">\n          '.concat(e.config.series[t].name ? e.config
              .series[t].name : "series-" + (t + 1), ": <strong>").concat(e.globals.series[t][i],
              "</strong>\n        </div>") : '<div class="apexcharts-tooltip-box apexcharts-tooltip-'.concat(e
              .config.chart.type, '">') + "<div>".concat(a[0], ': <span class="value">') + r +
            "</span></div>" + "<div>".concat(a[1], ': <span class="value">') + n + "</span></div>" + (o ?
              "<div>".concat(a[2], ': <span class="value">') + o + "</span></div>" : "") + "<div>".concat(a[
              3], ': <span class="value">') + l + "</span></div>" + "<div>".concat(a[4],
              ': <span class="value">') + c + "</span></div></div>"
        }
      }]), w
    }(),
    ye = function() {
      function w(e) {
        F(this, w), this.opts = e
      }
      return R(w, [{
        key: "init",
        value: function(e) {
          var t = e.responsiveOverride,
            i = this.opts,
            a = new de,
            s = new ve(i);
          this.chartType = i.chart.type, i = this.extendYAxis(i), i = this.extendAnnotations(i);
          var r = a.init(),
            n = {};
          if (i && "object" === $(i)) {
            var o, l, c, d, g, p, f, x, m, v, y = {};
            y = -1 !== ["line", "area", "bar", "candlestick", "boxPlot", "rangeBar", "rangeArea", "bubble",
                "scatter", "heatmap", "treemap", "pie", "polarArea", "donut", "radar", "radialBar"
              ].indexOf(i.chart.type) ? s[i.chart.type]() : s.line(), null !== (o = i.plotOptions) &&
              void 0 !== o && null !== (l = o.bar) && void 0 !== l && l.isFunnel && (y = s.funnel()), i.chart
              .stacked && "bar" === i.chart.type && (y = s.stackedBars()), null !== (c = i.chart.brush) &&
              void 0 !== c && c.enabled && (y = s.brush(y)), null !== (d = i.plotOptions) && void 0 !== d &&
              null !== (g = d.line) && void 0 !== g && g.isSlopeChart && (y = s.slope()), i.chart.stacked &&
              "100%" === i.chart.stackType && (i = s.stacked100(i)), null !== (p = i.plotOptions) &&
              void 0 !== p && null !== (f = p.bar) && void 0 !== f && f.isDumbbell && (i = s.dumbbell(i)),
              this.checkForDarkTheme(window.Apex), this.checkForDarkTheme(i), i.xaxis = i.xaxis || window.Apex
              .xaxis || {}, t || (i.xaxis.convertedCatToNumeric = !1), (null !== (x = (i = this
                  .checkForCatToNumericXAxis(this.chartType, y, i)).chart.sparkline) && void 0 !== x && x
                .enabled || null !== (m = window.Apex.chart) && void 0 !== m && null !== (v = m.sparkline) &&
                void 0 !== v && v.enabled) && (y = s.sparkline(y)), n = P.extend(r, y)
          }
          var h = P.extend(n, window.Apex);
          return r = P.extend(h, i), this.handleUserInputErrors(r)
        }
      }, {
        key: "checkForCatToNumericXAxis",
        value: function(e, t, i) {
          var a, s, r = new ve(i);
          return ("bar" === e || "boxPlot" === e) && (null === (a = i.plotOptions) || void 0 === a || null ===
              (s = a.bar) || void 0 === s ? void 0 : s.horizontal) || "pie" === e || "polarArea" === e ||
            "donut" === e || "radar" === e || "radialBar" === e || "heatmap" === e || !("datetime" !== i.xaxis
              .type && "numeric" !== i.xaxis.type) || "between" === (i.xaxis.tickPlacement ? i.xaxis
              .tickPlacement : t.xaxis && t.xaxis.tickPlacement) || (i = r.convertCatToNumeric(i)), i
        }
      }, {
        key: "extendYAxis",
        value: function(e, t) {
          var i = new de;
          (void 0 === e.yaxis || !e.yaxis || Array.isArray(e.yaxis) && 0 === e.yaxis.length) && (e
          .yaxis = {}), e.yaxis.constructor !== Array && window.Apex.yaxis && window.Apex.yaxis
            .constructor !== Array && (e.yaxis = P.extend(e.yaxis, window.Apex.yaxis)), e.yaxis = e.yaxis
            .constructor !== Array ? [P.extend(i.yAxis, e.yaxis)] : P.extendArray(e.yaxis, i.yAxis);
          var a = !1;
          e.yaxis.forEach(function(r) {
            r.logarithmic && (a = !0)
          });
          var s = e.series;
          return t && !s && (s = t.config.series), a && s.length !== e.yaxis.length && s.length && (e.yaxis =
            s.map(function(r, n) {
              if (r.name || (s[n].name = "series-".concat(n + 1)), e.yaxis[n]) return e.yaxis[n]
                .seriesName = s[n].name, e.yaxis[n];
              var o = P.extend(i.yAxis, e.yaxis[0]);
              return o.show = !1, o
            })), a && s.length > 1 && s.length !== e.yaxis.length && console.warn(
            "A multi-series logarithmic chart should have equal number of series and y-axes"), e
        }
      }, {
        key: "extendAnnotations",
        value: function(e) {
          return void 0 === e.annotations && (e.annotations = {}, e.annotations.yaxis = [], e.annotations
              .xaxis = [], e.annotations.points = []), e = this.extendYAxisAnnotations(e), e = this
            .extendXAxisAnnotations(e), this.extendPointAnnotations(e)
        }
      }, {
        key: "extendYAxisAnnotations",
        value: function(e) {
          var t = new de;
          return e.annotations.yaxis = P.extendArray(void 0 !== e.annotations.yaxis ? e.annotations.yaxis :
          [], t.yAxisAnnotation), e
        }
      }, {
        key: "extendXAxisAnnotations",
        value: function(e) {
          var t = new de;
          return e.annotations.xaxis = P.extendArray(void 0 !== e.annotations.xaxis ? e.annotations.xaxis :
          [], t.xAxisAnnotation), e
        }
      }, {
        key: "extendPointAnnotations",
        value: function(e) {
          var t = new de;
          return e.annotations.points = P.extendArray(void 0 !== e.annotations.points ? e.annotations.points :
            [], t.pointAnnotation), e
        }
      }, {
        key: "checkForDarkTheme",
        value: function(e) {
          e.theme && "dark" === e.theme.mode && (e.tooltip || (e.tooltip = {}), "light" !== e.tooltip.theme &&
            (e.tooltip.theme = "dark"), e.chart.foreColor || (e.chart.foreColor = "#f6f7f8"), e.chart
            .background || (e.chart.background = "#424242"), e.theme.palette || (e.theme.palette =
              "palette4"))
        }
      }, {
        key: "handleUserInputErrors",
        value: function(e) {
          var t = e;
          if (t.tooltip.shared && t.tooltip.intersect) throw new Error(
            "tooltip.shared cannot be enabled when tooltip.intersect is true. Turn off any other option by setting it to false."
            );
          if ("bar" === t.chart.type && t.plotOptions.bar.horizontal) {
            if (t.yaxis.length > 1) throw new Error(
              "Multiple Y Axis for bars are not supported. Switch to column chart by setting plotOptions.bar.horizontal=false"
              );
            t.yaxis[0].reversed && (t.yaxis[0].opposite = !0), t.xaxis.tooltip.enabled = !1, t.yaxis[0]
              .tooltip.enabled = !1, t.chart.zoom.enabled = !1
          }
          return "bar" !== t.chart.type && "rangeBar" !== t.chart.type || t.tooltip.shared && "barWidth" === t
            .xaxis.crosshairs.width && t.series.length > 1 && (t.xaxis.crosshairs.width = "tickWidth"),
            "candlestick" !== t.chart.type && "boxPlot" !== t.chart.type || t.yaxis[0].reversed && (console
              .warn("Reversed y-axis in ".concat(t.chart.type, " chart is not supported.")), t.yaxis[0]
              .reversed = !1), t
        }
      }]), w
    }(),
    je = function() {
      function w() {
        F(this, w)
      }
      return R(w, [{
        key: "initGlobalVars",
        value: function(e) {
          e.series = [], e.seriesCandleO = [], e.seriesCandleH = [], e.seriesCandleM = [], e
            .seriesCandleL = [], e.seriesCandleC = [], e.seriesRangeStart = [], e.seriesRangeEnd = [], e
            .seriesRange = [], e.seriesPercent = [], e.seriesGoals = [], e.seriesX = [], e.seriesZ = [], e
            .seriesNames = [], e.seriesTotals = [], e.seriesLog = [], e.seriesColors = [], e
            .stackedSeriesTotals = [], e.seriesXvalues = [], e.seriesYvalues = [], e.labels = [], e
            .hasXaxisGroups = !1, e.groups = [], e.barGroups = [], e.lineGroups = [], e.areaGroups = [], e
            .hasSeriesGroups = !1, e.seriesGroups = [], e.categoryLabels = [], e.timescaleLabels = [], e
            .noLabelsProvided = !1, e.resizeTimer = null, e.selectionResizeTimer = null, e
            .delayedElements = [], e.pointsArray = [], e.dataLabelsRects = [], e.isXNumeric = !1, e
            .skipLastTimelinelabel = !1, e.skipFirstTimelinelabel = !1, e.isDataXYZ = !1, e.isMultiLineX = !1,
            e.isMultipleYAxis = !1, e.maxY = -Number.MAX_VALUE, e.minY = Number.MIN_VALUE, e.minYArr = [], e
            .maxYArr = [], e.maxX = -Number.MAX_VALUE, e.minX = Number.MAX_VALUE, e.initialMaxX = -Number
            .MAX_VALUE, e.initialMinX = Number.MAX_VALUE, e.maxDate = 0, e.minDate = Number.MAX_VALUE, e
            .minZ = Number.MAX_VALUE, e.maxZ = -Number.MAX_VALUE, e.minXDiff = Number.MAX_VALUE, e
            .yAxisScale = [], e.xAxisScale = null, e.xAxisTicksPositions = [], e.yLabelsCoords = [], e
            .yTitleCoords = [], e.barPadForNumericAxis = 0, e.padHorizontal = 0, e.xRange = 0, e.yRange = [],
            e.zRange = 0, e.dataPoints = 0, e.xTickAmount = 0, e.multiAxisTickAmount = 0
        }
      }, {
        key: "globalVars",
        value: function(e) {
          return {
            chartID: null,
            cuid: null,
            events: {
              beforeMount: [],
              mounted: [],
              updated: [],
              clicked: [],
              selection: [],
              dataPointSelection: [],
              zoomed: [],
              scrolled: []
            },
            colors: [],
            clientX: null,
            clientY: null,
            fill: {
              colors: []
            },
            stroke: {
              colors: []
            },
            dataLabels: {
              style: {
                colors: []
              }
            },
            radarPolygons: {
              fill: {
                colors: []
              }
            },
            markers: {
              colors: [],
              size: e.markers.size,
              largestSize: 0
            },
            animationEnded: !1,
            isTouchDevice: "ontouchstart" in window || navigator.msMaxTouchPoints,
            isDirty: !1,
            isExecCalled: !1,
            initialConfig: null,
            initialSeries: [],
            lastXAxis: [],
            lastYAxis: [],
            columnSeries: null,
            labels: [],
            timescaleLabels: [],
            noLabelsProvided: !1,
            allSeriesCollapsed: !1,
            collapsedSeries: [],
            collapsedSeriesIndices: [],
            ancillaryCollapsedSeries: [],
            ancillaryCollapsedSeriesIndices: [],
            risingSeries: [],
            dataFormatXNumeric: !1,
            capturedSeriesIndex: -1,
            capturedDataPointIndex: -1,
            selectedDataPoints: [],
            goldenPadding: 35,
            invalidLogScale: !1,
            ignoreYAxisIndexes: [],
            maxValsInArrayIndex: 0,
            radialSize: 0,
            selection: void 0,
            zoomEnabled: "zoom" === e.chart.toolbar.autoSelected && e.chart.toolbar.tools.zoom && e.chart.zoom
              .enabled,
            panEnabled: "pan" === e.chart.toolbar.autoSelected && e.chart.toolbar.tools.pan,
            selectionEnabled: "selection" === e.chart.toolbar.autoSelected && e.chart.toolbar.tools.selection,
            yaxis: null,
            mousedown: !1,
            lastClientPosition: {},
            visibleXRange: void 0,
            yValueDecimal: 0,
            total: 0,
            SVGNS: "http://www.w3.org/2000/svg",
            svgWidth: 0,
            svgHeight: 0,
            noData: !1,
            locale: {},
            dom: {},
            memory: {
              methodsToExec: []
            },
            shouldAnimate: !0,
            skipLastTimelinelabel: !1,
            skipFirstTimelinelabel: !1,
            delayedElements: [],
            axisCharts: !0,
            isDataXYZ: !1,
            isSlopeChart: e.plotOptions.line.isSlopeChart,
            resized: !1,
            resizeTimer: null,
            comboCharts: !1,
            dataChanged: !1,
            previousPaths: [],
            allSeriesHasEqualX: !0,
            pointsArray: [],
            dataLabelsRects: [],
            lastDrawnDataLabelsIndexes: [],
            hasNullValues: !1,
            easing: null,
            zoomed: !1,
            gridWidth: 0,
            gridHeight: 0,
            rotateXLabels: !1,
            defaultLabels: !1,
            xLabelFormatter: void 0,
            yLabelFormatters: [],
            xaxisTooltipFormatter: void 0,
            ttKeyFormatter: void 0,
            ttVal: void 0,
            ttZFormatter: void 0,
            LINE_HEIGHT_RATIO: 1.618,
            xAxisLabelsHeight: 0,
            xAxisGroupLabelsHeight: 0,
            xAxisLabelsWidth: 0,
            yAxisLabelsWidth: 0,
            scaleX: 1,
            scaleY: 1,
            translateX: 0,
            translateY: 0,
            translateYAxisX: [],
            yAxisWidths: [],
            translateXAxisY: 0,
            translateXAxisX: 0,
            tooltip: null,
            niceScaleAllowedMagMsd: [
              [1, 1, 2, 5, 5, 5, 10, 10, 10, 10, 10],
              [1, 1, 2, 5, 5, 5, 10, 10, 10, 10, 10]
            ],
            niceScaleDefaultTicks: [1, 2, 4, 4, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 12, 12, 12, 12, 12,
              12, 12, 12, 12, 24
            ],
            seriesYAxisMap: [],
            seriesYAxisReverseMap: []
          }
        }
      }, {
        key: "init",
        value: function(e) {
          var t = this.globalVars(e);
          return this.initGlobalVars(t), t.initialConfig = P.extend({}, e), t.initialSeries = P.clone(e
            .series), t.lastXAxis = P.clone(t.initialConfig.xaxis), t.lastYAxis = P.clone(t.initialConfig
            .yaxis), t
        }
      }]), w
    }(),
    dt = function() {
      function w(e) {
        F(this, w), this.opts = e
      }
      return R(w, [{
        key: "init",
        value: function() {
          var e = new ye(this.opts).init({
            responsiveOverride: !1
          });
          return {
            config: e,
            globals: (new je).init(e)
          }
        }
      }]), w
    }(),
    re = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.opts = null, this.seriesIndex = 0
      }
      return R(w, [{
        key: "clippedImgArea",
        value: function(e) {
          var t = this.w,
            i = t.config,
            a = parseInt(t.globals.gridWidth, 10),
            s = parseInt(t.globals.gridHeight, 10),
            r = a > s ? a : s,
            n = e.image,
            o = 0,
            l = 0;
          void 0 === e.width && void 0 === e.height ? void 0 !== i.fill.image.width && void 0 !== i.fill.image
            .height ? (o = i.fill.image.width + 1, l = i.fill.image.height) : (o = r + 1, l = r) : (o = e
              .width, l = e.height);
          var c = document.createElementNS(t.globals.SVGNS, "pattern");
          X.setAttrs(c, {
            id: e.patternID,
            patternUnits: e.patternUnits ? e.patternUnits : "userSpaceOnUse",
            width: o + "px",
            height: l + "px"
          });
          var d = document.createElementNS(t.globals.SVGNS, "image");
          c.appendChild(d), d.setAttributeNS(window.SVG.xlink, "href", n), X.setAttrs(d, {
            x: 0,
            y: 0,
            preserveAspectRatio: "none",
            width: o + "px",
            height: l + "px"
          }), d.style.opacity = e.opacity, t.globals.dom.elDefs.node.appendChild(c)
        }
      }, {
        key: "getSeriesIndex",
        value: function(e) {
          var t = this.w,
            i = t.config.chart.type;
          return this.seriesIndex = ("bar" === i || "rangeBar" === i) && t.config.plotOptions.bar
            .distributed || "heatmap" === i || "treemap" === i ? e.seriesNumber : e.seriesNumber % t.globals
            .series.length, this.seriesIndex
        }
      }, {
        key: "fillPath",
        value: function(e) {
          var t = this.w;
          this.opts = e;
          var i, a, s, r = this.w.config;
          this.seriesIndex = this.getSeriesIndex(e);
          var n = this.getFillColors()[this.seriesIndex];
          void 0 !== t.globals.seriesColors[this.seriesIndex] && (n = t.globals.seriesColors[this
            .seriesIndex]), "function" == typeof n && (n = n({
            seriesIndex: this.seriesIndex,
            dataPointIndex: e.dataPointIndex,
            value: e.value,
            w: t
          }));
          var o = e.fillType ? e.fillType : this.getFillType(this.seriesIndex),
            l = Array.isArray(r.fill.opacity) ? r.fill.opacity[this.seriesIndex] : r.fill.opacity;
          e.color && (n = e.color), n || (n = "#fff", console.warn("undefined color - ApexCharts"));
          var c = n;
          if (-1 === n.indexOf("rgb") ? n.length < 9 && (c = P.hexToRgba(n, l)) : n.indexOf("rgba") > -1 && (
              l = P.getOpacityFromRGBA(n)), e.opacity && (l = e.opacity), "pattern" === o && (a = this
              .handlePatternFill({
                fillConfig: e.fillConfig,
                patternFill: a,
                fillColor: n,
                fillOpacity: l,
                defaultColor: c
              })), "gradient" === o && (s = this.handleGradientFill({
              fillConfig: e.fillConfig,
              fillColor: n,
              fillOpacity: l,
              i: this.seriesIndex
            })), "image" === o) {
            var d = r.fill.image.src,
              g = e.patternID ? e.patternID : "";
            this.clippedImgArea({
              opacity: l,
              image: Array.isArray(d) ? e.seriesNumber < d.length ? d[e.seriesNumber] : d[0] : d,
              width: e.width ? e.width : void 0,
              height: e.height ? e.height : void 0,
              patternUnits: e.patternUnits,
              patternID: "pattern".concat(t.globals.cuid).concat(e.seriesNumber + 1).concat(g)
            }), i = "url(#pattern".concat(t.globals.cuid).concat(e.seriesNumber + 1).concat(g, ")")
          } else i = "gradient" === o ? s : "pattern" === o ? a : c;
          return e.solid && (i = c), i
        }
      }, {
        key: "getFillType",
        value: function(e) {
          var t = this.w;
          return Array.isArray(t.config.fill.type) ? t.config.fill.type[e] : t.config.fill.type
        }
      }, {
        key: "getFillColors",
        value: function() {
          var e = this.w,
            t = e.config,
            i = this.opts,
            a = [];
          return e.globals.comboCharts ? "line" === e.config.series[this.seriesIndex].type ? Array.isArray(e
              .globals.stroke.colors) ? a = e.globals.stroke.colors : a.push(e.globals.stroke.colors) : Array
            .isArray(e.globals.fill.colors) ? a = e.globals.fill.colors : a.push(e.globals.fill.colors) :
            "line" === t.chart.type ? Array.isArray(e.globals.stroke.colors) ? a = e.globals.stroke.colors : a
            .push(e.globals.stroke.colors) : Array.isArray(e.globals.fill.colors) ? a = e.globals.fill
            .colors : a.push(e.globals.fill.colors), void 0 !== i.fillColors && (a = [], Array.isArray(i
              .fillColors) ? a = i.fillColors.slice() : a.push(i.fillColors)), a
        }
      }, {
        key: "handlePatternFill",
        value: function(e) {
          var t = e.fillConfig,
            a = e.fillColor,
            s = e.fillOpacity,
            r = e.defaultColor,
            n = this.w.config.fill;
          t && (n = t);
          var o = this.opts,
            l = new X(this.ctx),
            c = Array.isArray(n.pattern.strokeWidth) ? n.pattern.strokeWidth[this.seriesIndex] : n.pattern
            .strokeWidth,
            d = a;
          return Array.isArray(n.pattern.style) ? void 0 !== n.pattern.style[o.seriesNumber] ? l.drawPattern(n
            .pattern.style[o.seriesNumber], n.pattern.width, n.pattern.height, d, c, s) : r : l.drawPattern(
            n.pattern.style, n.pattern.width, n.pattern.height, d, c, s)
        }
      }, {
        key: "handleGradientFill",
        value: function(e) {
          var t = e.fillColor,
            i = e.fillOpacity,
            a = e.fillConfig,
            s = e.i,
            r = this.w.config.fill;
          a && (r = Y(Y({}, r), a));
          var n, o = this.opts,
            l = new X(this.ctx),
            c = new P,
            d = r.gradient.type,
            g = t,
            p = void 0 === r.gradient.opacityFrom ? i : Array.isArray(r.gradient.opacityFrom) ? r.gradient
            .opacityFrom[s] : r.gradient.opacityFrom;
          g.indexOf("rgba") > -1 && (p = P.getOpacityFromRGBA(g));
          var f = void 0 === r.gradient.opacityTo ? i : Array.isArray(r.gradient.opacityTo) ? r.gradient
            .opacityTo[s] : r.gradient.opacityTo;
          if (void 0 === r.gradient.gradientToColors || 0 === r.gradient.gradientToColors.length) n = c
            .shadeColor("dark" === r.gradient.shade ? -1 * parseFloat(r.gradient.shadeIntensity) : parseFloat(
              r.gradient.shadeIntensity), t.indexOf("rgb") > -1 ? P.rgb2hex(t) : t);
          else if (r.gradient.gradientToColors[o.seriesNumber]) {
            var x = r.gradient.gradientToColors[o.seriesNumber];
            n = x, x.indexOf("rgba") > -1 && (f = P.getOpacityFromRGBA(x))
          } else n = t;
          if (r.gradient.gradientFrom && (g = r.gradient.gradientFrom), r.gradient.gradientTo && (n = r
              .gradient.gradientTo), r.gradient.inverseColors) {
            var m = g;
            g = n, n = m
          }
          return g.indexOf("rgb") > -1 && (g = P.rgb2hex(g)), n.indexOf("rgb") > -1 && (n = P.rgb2hex(n)), l
            .drawGradient(d, g, n, p, f, o.size, r.gradient.stops, r.gradient.colorStops, s)
        }
      }]), w
    }(),
    we = function() {
      function w(e, t) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "setGlobalMarkerSize",
        value: function() {
          var e = this.w;
          if (e.globals.markers.size = Array.isArray(e.config.markers.size) ? e.config.markers.size : [e
              .config.markers.size
            ], e.globals.markers.size.length > 0) {
            if (e.globals.markers.size.length < e.globals.series.length + 1)
              for (var t = 0; t <= e.globals.series.length; t++) void 0 === e.globals.markers.size[t] && e
                .globals.markers.size.push(e.globals.markers.size[0])
          } else e.globals.markers.size = e.config.series.map(function(i) {
            return e.config.markers.size
          })
        }
      }, {
        key: "plotChartMarkers",
        value: function(e, t, i, a) {
          var s, r = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
            n = this.w,
            o = t,
            l = e,
            c = null,
            d = new X(this.ctx),
            g = n.config.markers.discrete && n.config.markers.discrete.length;
          if ((n.globals.markers.size[t] > 0 || r || g) && (c = d.group({
              class: r || g ? "" : "apexcharts-series-markers"
            })).attr("clip-path", "url(#gridRectMarkerMask".concat(n.globals.cuid, ")")), Array.isArray(l.x))
            for (var p = 0; p < l.x.length; p++) {
              var f = i;
              1 === i && 0 === p && (f = 0), 1 === i && 1 === p && (f = 1);
              var x = "apexcharts-marker";
              if ("line" !== n.config.chart.type && "area" !== n.config.chart.type || n.globals.comboCharts ||
                n.config.tooltip.intersect || (x += " no-pointer-events"), (Array.isArray(n.config.markers
                  .size) ? n.globals.markers.size[t] > 0 : n.config.markers.size > 0) || r || g) {
                P.isNumber(l.y[p]) ? x += " w".concat(P.randomId()) : x = "apexcharts-nullpoint";
                var m = this.getMarkerConfig({
                  cssClass: x,
                  seriesIndex: t,
                  dataPointIndex: f
                });
                n.config.series[o].data[f] && (n.config.series[o].data[f].fillColor && (m.pointFillColor = n
                    .config.series[o].data[f].fillColor), n.config.series[o].data[f].strokeColor && (m
                    .pointStrokeColor = n.config.series[o].data[f].strokeColor)), a && (m.pSize = a), (l.x[
                    p] < -n.globals.markers.largestSize || l.x[p] > n.globals.gridWidth + n.globals.markers
                    .largestSize || l.y[p] < -n.globals.markers.largestSize || l.y[p] > n.globals.gridHeight +
                    n.globals.markers.largestSize) && (m.pSize = 0), (s = d.drawMarker(l.x[p], l.y[p], m))
                  .attr("rel", f), s.attr("j", f), s.attr("index", t), s.node.setAttribute(
                    "default-marker-size", m.pSize), new K(this.ctx).setSelectionFilter(s, t, f), this
                  .addEvents(s), c && c.add(s)
              } else void 0 === n.globals.pointsArray[t] && (n.globals.pointsArray[t] = []), n.globals
                .pointsArray[t].push([l.x[p], l.y[p]])
            }
          return c
        }
      }, {
        key: "getMarkerConfig",
        value: function(e) {
          var t = e.cssClass,
            i = e.seriesIndex,
            a = e.dataPointIndex,
            s = void 0 === a ? null : a,
            r = e.finishRadius,
            n = void 0 === r ? null : r,
            o = this.w,
            l = this.getMarkerStyle(i),
            c = o.globals.markers.size[i],
            d = o.config.markers;
          return null !== s && d.discrete.length && d.discrete.map(function(g) {
            g.seriesIndex === i && g.dataPointIndex === s && (l.pointStrokeColor = g.strokeColor, l
              .pointFillColor = g.fillColor, c = g.size, l.pointShape = g.shape)
          }), {
            pSize: null === n ? c : n,
            pRadius: d.radius,
            width: Array.isArray(d.width) ? d.width[i] : d.width,
            height: Array.isArray(d.height) ? d.height[i] : d.height,
            pointStrokeWidth: Array.isArray(d.strokeWidth) ? d.strokeWidth[i] : d.strokeWidth,
            pointStrokeColor: l.pointStrokeColor,
            pointFillColor: l.pointFillColor,
            shape: l.pointShape || (Array.isArray(d.shape) ? d.shape[i] : d.shape),
            class: t,
            pointStrokeOpacity: Array.isArray(d.strokeOpacity) ? d.strokeOpacity[i] : d.strokeOpacity,
            pointStrokeDashArray: Array.isArray(d.strokeDashArray) ? d.strokeDashArray[i] : d
              .strokeDashArray,
            pointFillOpacity: Array.isArray(d.fillOpacity) ? d.fillOpacity[i] : d.fillOpacity,
            seriesIndex: i
          }
        }
      }, {
        key: "addEvents",
        value: function(e) {
          var t = this.w,
            i = new X(this.ctx);
          e.node.addEventListener("mouseenter", i.pathMouseEnter.bind(this.ctx, e)), e.node.addEventListener(
              "mouseleave", i.pathMouseLeave.bind(this.ctx, e)), e.node.addEventListener("mousedown", i
              .pathMouseDown.bind(this.ctx, e)), e.node.addEventListener("click", t.config.markers.onClick), e
            .node.addEventListener("dblclick", t.config.markers.onDblClick), e.node.addEventListener(
              "touchstart", i.pathMouseDown.bind(this.ctx, e), {
                passive: !0
              })
        }
      }, {
        key: "getMarkerStyle",
        value: function(e) {
          var t = this.w,
            i = t.globals.markers.colors,
            a = t.config.markers.strokeColor || t.config.markers.strokeColors;
          return {
            pointStrokeColor: Array.isArray(a) ? a[e] : a,
            pointFillColor: Array.isArray(i) ? i[e] : i
          }
        }
      }]), w
    }(),
    _e = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.initialAnim = this.w.config.chart.animations.enabled, this
          .dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled
      }
      return R(w, [{
        key: "draw",
        value: function(e, t, i) {
          var a = this.w,
            s = new X(this.ctx),
            r = i.realIndex,
            n = i.pointsPos,
            o = i.zRatio,
            l = i.elParent,
            c = s.group({
              class: "apexcharts-series-markers apexcharts-series-".concat(a.config.chart.type)
            });
          if (c.attr("clip-path", "url(#gridRectMarkerMask".concat(a.globals.cuid, ")")), Array.isArray(n.x))
            for (var d = 0; d < n.x.length; d++) {
              var g = t + 1,
                p = !0;
              0 === t && 0 === d && (g = 0), 0 === t && 1 === d && (g = 1);
              var f = 0,
                x = a.globals.markers.size[r];
              if (o !== 1 / 0) {
                var m = a.config.plotOptions.bubble;
                x = a.globals.seriesZ[r][g], m.zScaling && (x /= o), m.minBubbleRadius && x < m
                  .minBubbleRadius && (x = m.minBubbleRadius), m.maxBubbleRadius && x > m.maxBubbleRadius && (
                    x = m.maxBubbleRadius)
              }
              a.config.chart.animations.enabled || (f = x);
              var y = n.y[d];
              if (f = f || 0, null !== y && void 0 !== a.globals.series[r][g] || (p = !1), p) {
                var h = this.drawPoint(n.x[d], y, f, x, r, g, t);
                c.add(h)
              }
              l.add(c)
            }
        }
      }, {
        key: "drawPoint",
        value: function(e, t, i, a, s, r, n) {
          var o = this.w,
            l = s,
            c = new ge(this.ctx),
            d = new K(this.ctx),
            g = new re(this.ctx),
            p = new we(this.ctx),
            f = new X(this.ctx),
            x = p.getMarkerConfig({
              cssClass: "apexcharts-marker",
              seriesIndex: l,
              dataPointIndex: r,
              finishRadius: "bubble" === o.config.chart.type || o.globals.comboCharts && o.config.series[
                s] && "bubble" === o.config.series[s].type ? a : null
            });
          a = x.pSize;
          var m, v = g.fillPath({
            seriesNumber: s,
            dataPointIndex: r,
            color: x.pointFillColor,
            patternUnits: "objectBoundingBox",
            value: o.globals.series[s][n]
          });
          if ("circle" === x.shape ? m = f.drawCircle(i) : "square" !== x.shape && "rect" !== x.shape || (m =
              f.drawRect(0, 0, x.width - x.pointStrokeWidth / 2, x.height - x.pointStrokeWidth / 2, x.pRadius)
              ), o.config.series[l].data[r] && o.config.series[l].data[r].fillColor && (v = o.config.series[l]
              .data[r].fillColor), m.attr({
              x: e - x.width / 2 - x.pointStrokeWidth / 2,
              y: t - x.height / 2 - x.pointStrokeWidth / 2,
              cx: e,
              cy: t,
              fill: v,
              "fill-opacity": x.pointFillOpacity,
              stroke: x.pointStrokeColor,
              r: a,
              "stroke-width": x.pointStrokeWidth,
              "stroke-dasharray": x.pointStrokeDashArray,
              "stroke-opacity": x.pointStrokeOpacity
            }), o.config.chart.dropShadow.enabled && d.dropShadow(m, o.config.chart.dropShadow, s), !this
            .initialAnim || o.globals.dataChanged || o.globals.resized ? o.globals.animationEnded = !0 : c
            .animateMarker(m, 0, "circle" === x.shape ? a : {
              width: x.width,
              height: x.height
            }, o.config.chart.animations.speed, o.globals.easing, function() {
              window.setTimeout(function() {
                c.animationCompleted(m)
              }, 100)
            }), o.globals.dataChanged && "circle" === x.shape)
            if (this.dynamicAnim) {
              var u, b, k, A, S = o.config.chart.animations.dynamicAnimation.speed;
              null != (A = o.globals.previousPaths[s] && o.globals.previousPaths[s][n]) && (u = A.x, b = A.y,
                k = void 0 !== A.r ? A.r : a);
              for (var C = 0; C < o.globals.collapsedSeries.length; C++) o.globals.collapsedSeries[C]
                .index === s && (S = 1, a = 0);
              0 === e && 0 === t && (a = 0), c.animateCircle(m, {
                cx: u,
                cy: b,
                r: k
              }, {
                cx: e,
                cy: t,
                r: a
              }, S, o.globals.easing)
            } else m.attr({
              r: a
            });
          return m.attr({
            rel: r,
            j: r,
            index: s,
            "default-marker-size": a
          }), d.setSelectionFilter(m, s, r), p.addEvents(m), m.node.classList.add("apexcharts-marker"), m
        }
      }, {
        key: "centerTextInBubble",
        value: function(e) {
          return {
            y: e += parseInt(this.w.config.dataLabels.style.fontSize, 10) / 4
          }
        }
      }]), w
    }(),
    ue = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "dataLabelsCorrection",
        value: function(e, t, i, a, s, r, n) {
          var o = this.w,
            l = !1,
            c = new X(this.ctx).getTextRects(i, n),
            d = c.width,
            g = c.height;
          if (t < 0 && (t = 0), t > o.globals.gridHeight + g && (t = o.globals.gridHeight + g / 2), void 0 ===
            o.globals.dataLabelsRects[a] && (o.globals.dataLabelsRects[a] = []), o.globals.dataLabelsRects[a]
            .push({
              x: e,
              y: t,
              width: d,
              height: g
            }), void 0 !== o.globals.dataLabelsRects[a][o.globals.dataLabelsRects[a].length - 2]) {
            var x = o.globals.dataLabelsRects[a][void 0 !== o.globals.lastDrawnDataLabelsIndexes[a] ? o
              .globals.lastDrawnDataLabelsIndexes[a][o.globals.lastDrawnDataLabelsIndexes[a].length - 1] : 0
            ];
            (e > x.x + x.width || t > x.y + x.height || t + g < x.y || e + d < x.x) && (l = !0)
          }
          return (0 === s || r) && (l = !0), {
            x: e,
            y: t,
            textRects: c,
            drawnextLabel: l
          }
        }
      }, {
        key: "drawDataLabel",
        value: function(e) {
          var t = this,
            i = e.type,
            a = e.pos,
            s = e.i,
            r = e.j,
            n = e.isRangeStart,
            o = e.strokeWidth,
            l = void 0 === o ? 2 : o,
            c = this.w,
            d = new X(this.ctx),
            g = c.config.dataLabels,
            p = 0,
            f = 0,
            x = r,
            m = null;
          if (-1 !== c.globals.collapsedSeriesIndices.indexOf(s) || !g.enabled || !Array.isArray(a.x))
          return m;
          m = d.group({
            class: "apexcharts-data-labels"
          });
          for (var v = 0; v < a.x.length; v++)
            if (p = a.x[v] + g.offsetX, f = a.y[v] + g.offsetY + l, !isNaN(p)) {
              1 === r && 0 === v && (x = 0), 1 === r && 1 === v && (x = 1);
              var y = c.globals.series[s][x];
              "rangeArea" === i && (y = n ? c.globals.seriesRangeStart[s][x] : c.globals.seriesRangeEnd[s][
              x]);
              var h = "",
                u = function(k) {
                  return c.config.dataLabels.formatter(k, {
                    ctx: t.ctx,
                    seriesIndex: s,
                    dataPointIndex: x,
                    w: c
                  })
                };
              "bubble" === c.config.chart.type ? (h = u(y = c.globals.seriesZ[s][x]), f = a.y[v], f = new _e(
                this.ctx).centerTextInBubble(f, s, x).y) : void 0 !== y && (h = u(y));
              var b = c.config.dataLabels.textAnchor;
              c.globals.isSlopeChart && (b = 0 === x ? "end" : x === c.config.series[s].data.length - 1 ?
                "start" : "middle"), this.plotDataLabelsText({
                x: p,
                y: f,
                text: h,
                i: s,
                j: x,
                parent: m,
                offsetCorrection: !0,
                dataLabelsConfig: c.config.dataLabels,
                textAnchor: b
              })
            } return m
        }
      }, {
        key: "plotDataLabelsText",
        value: function(e) {
          var t = this.w,
            i = new X(this.ctx),
            a = e.x,
            s = e.y,
            r = e.i,
            n = e.j,
            o = e.text,
            l = e.textAnchor,
            c = e.fontSize,
            d = e.parent,
            g = e.dataLabelsConfig,
            p = e.color,
            f = e.alwaysDrawDataLabel,
            x = e.offsetCorrection;
          if (!(Array.isArray(t.config.dataLabels.enabledOnSeries) && t.config.dataLabels.enabledOnSeries
              .indexOf(r) < 0)) {
            var m = {
              x: a,
              y: s,
              drawnextLabel: !0,
              textRects: null
            };
            x && (m = this.dataLabelsCorrection(a, s, o, r, n, f, parseInt(g.style.fontSize, 10))), t.globals
              .zoomed || (a = m.x, s = m.y), m.textRects && (a < -20 - m.textRects.width || a > t.globals
                .gridWidth + m.textRects.width + 30) && (o = "");
            var v = t.globals.dataLabels.style.colors[r];
            (("bar" === t.config.chart.type || "rangeBar" === t.config.chart.type) && t.config.plotOptions.bar
              .distributed || t.config.dataLabels.distributed) && (v = t.globals.dataLabels.style.colors[n]),
            "function" == typeof v && (v = v({
              series: t.globals.series,
              seriesIndex: r,
              dataPointIndex: n,
              w: t
            })), p && (v = p);
            var y = g.offsetX,
              h = g.offsetY;
            if ("bar" !== t.config.chart.type && "rangeBar" !== t.config.chart.type || (y = 0, h = 0), t
              .globals.isSlopeChart && (0 !== n && (y = -2 * g.offsetX + 5), 0 !== n && n !== t.config.series[
                r].data.length - 1 && (y = 0)), m.drawnextLabel) {
              var u = i.drawText({
                width: 100,
                height: parseInt(g.style.fontSize, 10),
                x: a + y,
                y: s + h,
                foreColor: v,
                textAnchor: l || g.textAnchor,
                text: o,
                fontSize: c || g.style.fontSize,
                fontFamily: g.style.fontFamily,
                fontWeight: g.style.fontWeight || "normal"
              });
              if (u.attr({
                  class: "apexcharts-datalabel",
                  cx: a,
                  cy: s
                }), g.dropShadow.enabled) {
                var b = g.dropShadow;
                new K(this.ctx).dropShadow(u, b)
              }
              d.add(u), void 0 === t.globals.lastDrawnDataLabelsIndexes[r] && (t.globals
                .lastDrawnDataLabelsIndexes[r] = []), t.globals.lastDrawnDataLabelsIndexes[r].push(n)
            }
          }
        }
      }, {
        key: "addBackgroundToDataLabel",
        value: function(e, t) {
          var i = this.w,
            a = i.config.dataLabels.background,
            s = a.padding,
            r = a.padding / 2,
            n = t.width,
            o = t.height,
            l = new X(this.ctx).drawRect(t.x - s, t.y - r / 2, n + 2 * s, o + r, a.borderRadius,
              "transparent" === i.config.chart.background ? "#fff" : i.config.chart.background, a.opacity, a
              .borderWidth, a.borderColor);
          return a.dropShadow.enabled && new K(this.ctx).dropShadow(l, a.dropShadow), l
        }
      }, {
        key: "dataLabelsBackground",
        value: function() {
          var e = this.w;
          if ("bubble" !== e.config.chart.type)
            for (var t = e.globals.dom.baseEl.querySelectorAll(".apexcharts-datalabels text"), i = 0; i < t
              .length; i++) {
              var a = t[i],
                s = a.getBBox(),
                r = null;
              if (s.width && s.height && (r = this.addBackgroundToDataLabel(a, s)), r) {
                a.parentNode.insertBefore(r.node, a);
                var n = a.getAttribute("fill");
                !e.config.chart.animations.enabled || e.globals.resized || e.globals.dataChanged ? r.attr({
                  fill: n
                }) : r.animate().attr({
                  fill: n
                }), a.setAttribute("fill", e.config.dataLabels.background.foreColor)
              }
            }
        }
      }, {
        key: "bringForward",
        value: function() {
          for (var e = this.w, t = e.globals.dom.baseEl.querySelectorAll(".apexcharts-datalabels"), i = e
              .globals.dom.baseEl.querySelector(".apexcharts-plot-series:last-child"), a = 0; a < t
            .length; a++) i && i.insertBefore(t[a], i.nextSibling)
        }
      }]), w
    }(),
    se = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.legendInactiveClass = "legend-mouseover-inactive"
      }
      return R(w, [{
        key: "getAllSeriesEls",
        value: function() {
          return this.w.globals.dom.baseEl.getElementsByClassName("apexcharts-series")
        }
      }, {
        key: "getSeriesByName",
        value: function(e) {
          return this.w.globals.dom.baseEl.querySelector(".apexcharts-inner .apexcharts-series[seriesName='"
            .concat(P.escapeString(e), "']"))
        }
      }, {
        key: "isSeriesHidden",
        value: function(e) {
          var t = this.getSeriesByName(e),
            i = parseInt(t.getAttribute("data:realIndex"), 10);
          return {
            isHidden: t.classList.contains("apexcharts-series-collapsed"),
            realIndex: i
          }
        }
      }, {
        key: "addCollapsedClassToSeries",
        value: function(e, t) {
          var i = this.w;

          function a(s) {
            for (var r = 0; r < s.length; r++) s[r].index === t && e.node.classList.add(
              "apexcharts-series-collapsed")
          }
          a(i.globals.collapsedSeries), a(i.globals.ancillaryCollapsedSeries)
        }
      }, {
        key: "toggleSeries",
        value: function(e) {
          var t = this.isSeriesHidden(e);
          return this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, t.isHidden), t.isHidden
        }
      }, {
        key: "showSeries",
        value: function(e) {
          var t = this.isSeriesHidden(e);
          t.isHidden && this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, !0)
        }
      }, {
        key: "hideSeries",
        value: function(e) {
          var t = this.isSeriesHidden(e);
          t.isHidden || this.ctx.legend.legendHelpers.toggleDataSeries(t.realIndex, !1)
        }
      }, {
        key: "resetSeries",
        value: function() {
          var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
            i = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
            a = this.w,
            s = P.clone(a.globals.initialSeries);
          a.globals.previousPaths = [], i ? (a.globals.collapsedSeries = [], a.globals
              .ancillaryCollapsedSeries = [], a.globals.collapsedSeriesIndices = [], a.globals
              .ancillaryCollapsedSeriesIndices = []) : s = this.emptyCollapsedSeries(s), a.config.series = s,
            e && (t && (a.globals.zoomed = !1, this.ctx.updateHelpers.revertDefaultAxisMinMax()), this.ctx
              .updateHelpers._updateSeries(s, a.config.chart.animations.dynamicAnimation.enabled))
        }
      }, {
        key: "emptyCollapsedSeries",
        value: function(e) {
          for (var t = this.w, i = 0; i < e.length; i++) t.globals.collapsedSeriesIndices.indexOf(i) > -1 && (
            e[i].data = []);
          return e
        }
      }, {
        key: "toggleSeriesOnHover",
        value: function(e, t) {
          var i = this.w;
          t || (t = e.target);
          var a = i.globals.dom.baseEl.querySelectorAll(
            ".apexcharts-series, .apexcharts-datalabels, .apexcharts-yaxis");
          if ("mousemove" === e.type) {
            var s = parseInt(t.getAttribute("rel"), 10) - 1,
              r = null,
              n = null,
              o = null;
            i.globals.axisCharts || "radialBar" === i.config.chart.type ? i.globals.axisCharts ? (r = i
              .globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(s, "']")),
              n = i.globals.dom.baseEl.querySelector(".apexcharts-datalabels[data\\:realIndex='".concat(s,
                "']")), o = i.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(i.globals
                .seriesYAxisReverseMap[s], "']"))) : r = i.globals.dom.baseEl.querySelector(
              ".apexcharts-series[rel='".concat(s + 1, "']")) : r = i.globals.dom.baseEl.querySelector(
              ".apexcharts-series[rel='".concat(s + 1, "'] path"));
            for (var c = 0; c < a.length; c++) a[c].classList.add(this.legendInactiveClass);
            null !== r && (i.globals.axisCharts || r.parentNode.classList.remove(this.legendInactiveClass), r
              .classList.remove(this.legendInactiveClass), null !== n && n.classList.remove(this
                .legendInactiveClass), null !== o && o.classList.remove(this.legendInactiveClass))
          } else if ("mouseout" === e.type)
            for (var d = 0; d < a.length; d++) a[d].classList.remove(this.legendInactiveClass)
        }
      }, {
        key: "highlightRangeInSeries",
        value: function(e, t) {
          var i = this,
            a = this.w,
            s = a.globals.dom.baseEl.getElementsByClassName("apexcharts-heatmap-rect"),
            r = function(o) {
              for (var l = 0; l < s.length; l++) s[l].classList[o](i.legendInactiveClass)
            };
          if ("mousemove" === e.type) {
            var n = parseInt(t.getAttribute("rel"), 10) - 1;
            r("add"),
              function(o) {
                for (var l = 0; l < s.length; l++) {
                  var c = parseInt(s[l].getAttribute("val"), 10);
                  c >= o.from && c <= o.to && s[l].classList.remove(i.legendInactiveClass)
                }
              }(a.config.plotOptions.heatmap.colorScale.ranges[n])
          } else "mouseout" === e.type && r("remove")
        }
      }, {
        key: "getActiveConfigSeriesIndex",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "asc",
            t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
            i = this.w,
            a = 0;
          if (i.config.series.length > 1)
            for (var s = i.config.series.map(function(n, o) {
                return n.data && n.data.length > 0 && -1 === i.globals.collapsedSeriesIndices.indexOf(
                  o) && (!i.globals.comboCharts || 0 === t.length || t.length && t.indexOf(i.config
                    .series[o].type) > -1) ? o : -1
              }), r = "asc" === e ? 0 : s.length - 1;
              "asc" === e ? r < s.length : r >= 0;
              "asc" === e ? r++ : r--)
              if (-1 !== s[r]) {
                a = s[r];
                break
              } return a
        }
      }, {
        key: "getBarSeriesIndices",
        value: function() {
          return this.w.globals.comboCharts ? this.w.config.series.map(function(e, t) {
            return "bar" === e.type || "column" === e.type ? t : -1
          }).filter(function(e) {
            return -1 !== e
          }) : this.w.config.series.map(function(e, t) {
            return t
          })
        }
      }, {
        key: "getPreviousPaths",
        value: function() {
          var e = this.w;

          function t(r, n, o) {
            for (var l = r[n].childNodes, c = {
                type: o,
                paths: [],
                realIndex: r[n].getAttribute("data:realIndex")
              }, d = 0; d < l.length; d++)
              if (l[d].hasAttribute("pathTo")) {
                var g = l[d].getAttribute("pathTo");
                c.paths.push({
                  d: g
                })
              } e.globals.previousPaths.push(c)
          }
          e.globals.previousPaths = [], ["line", "area", "bar", "rangebar", "rangeArea", "candlestick",
            "radar"
          ].forEach(function(r) {
            for (var o = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(r,
                "-series .apexcharts-series")), l = 0; l < o.length; l++) t(o, l, r)
          }), this.handlePrevBubbleScatterPaths("bubble"), this.handlePrevBubbleScatterPaths("scatter");
          var i = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e.config.chart.type,
            " .apexcharts-series"));
          if (i.length > 0)
            for (var a = function(r) {
                for (var n = e.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e.config.chart
                      .type, " .apexcharts-series[data\\:realIndex='").concat(r, "'] rect")), o = [], l =
                    function(d) {
                      var g = function(f) {
                          return n[d].getAttribute(f)
                        },
                        p = {
                          x: parseFloat(g("x")),
                          y: parseFloat(g("y")),
                          width: parseFloat(g("width")),
                          height: parseFloat(g("height"))
                        };
                      o.push({
                        rect: p,
                        color: n[d].getAttribute("color")
                      })
                    }, c = 0; c < n.length; c++) l(c);
                e.globals.previousPaths.push(o)
              }, s = 0; s < i.length; s++) a(s);
          e.globals.axisCharts || (e.globals.previousPaths = e.globals.series)
        }
      }, {
        key: "handlePrevBubbleScatterPaths",
        value: function(e) {
          var t = this.w,
            i = t.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e, "-series .apexcharts-series"));
          if (i.length > 0)
            for (var a = 0; a < i.length; a++) {
              for (var s = t.globals.dom.baseEl.querySelectorAll(".apexcharts-".concat(e,
                  "-series .apexcharts-series[data\\:realIndex='").concat(a, "'] circle")), r = [], n = 0; n <
                s.length; n++) r.push({
                x: s[n].getAttribute("cx"),
                y: s[n].getAttribute("cy"),
                r: s[n].getAttribute("r")
              });
              t.globals.previousPaths.push(r)
            }
        }
      }, {
        key: "clearPreviousPaths",
        value: function() {
          var e = this.w;
          e.globals.previousPaths = [], e.globals.allSeriesCollapsed = !1
        }
      }, {
        key: "handleNoData",
        value: function() {
          var e = this.w,
            t = e.config.noData,
            i = new X(this.ctx),
            a = e.globals.svgWidth / 2,
            s = e.globals.svgHeight / 2,
            r = "middle";
          if (e.globals.noData = !0, e.globals.animationEnded = !0, "left" === t.align ? (a = 10, r =
            "start") : "right" === t.align && (a = e.globals.svgWidth - 10, r = "end"), "top" === t
            .verticalAlign ? s = 50 : "bottom" === t.verticalAlign && (s = e.globals.svgHeight - 50), a += t
            .offsetX, s = s + parseInt(t.style.fontSize, 10) + 2 + t.offsetY, void 0 !== t.text && "" !== t
            .text) {
            var n = i.drawText({
              x: a,
              y: s,
              text: t.text,
              textAnchor: r,
              fontSize: t.style.fontSize,
              fontFamily: t.style.fontFamily,
              foreColor: t.style.color,
              opacity: 1,
              class: "apexcharts-text-nodata"
            });
            e.globals.dom.Paper.add(n)
          }
        }
      }, {
        key: "setNullSeriesToZeroValues",
        value: function(e) {
          for (var t = this.w, i = 0; i < e.length; i++)
            if (0 === e[i].length)
              for (var a = 0; a < e[t.globals.maxValsInArrayIndex].length; a++) e[i].push(0);
          return e
        }
      }, {
        key: "hasAllSeriesEqualX",
        value: function() {
          for (var e = !0, t = this.w, i = this.filteredSeriesX(), a = 0; a < i.length - 1; a++)
            if (i[a][0] !== i[a + 1][0]) {
              e = !1;
              break
            } return t.globals.allSeriesHasEqualX = e, e
        }
      }, {
        key: "filteredSeriesX",
        value: function() {
          return this.w.globals.seriesX.map(function(t) {
            return t.length > 0 ? t : []
          })
        }
      }]), w
    }(),
    Ue = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.twoDSeries = [], this.threeDSeries = [], this.twoDSeriesX = [],
          this.seriesGoals = [], this.coreUtils = new q(this.ctx)
      }
      return R(w, [{
        key: "isMultiFormat",
        value: function() {
          return this.isFormatXY() || this.isFormat2DArray()
        }
      }, {
        key: "isFormatXY",
        value: function() {
          var e = this.w.config.series.slice(),
            t = new se(this.ctx);
          if (this.activeSeriesIndex = t.getActiveConfigSeriesIndex(), void 0 !== e[this.activeSeriesIndex]
            .data && e[this.activeSeriesIndex].data.length > 0 && null !== e[this.activeSeriesIndex].data[
            0] && void 0 !== e[this.activeSeriesIndex].data[0].x && null !== e[this.activeSeriesIndex].data[0]
            ) return !0
        }
      }, {
        key: "isFormat2DArray",
        value: function() {
          var e = this.w.config.series.slice(),
            t = new se(this.ctx);
          if (this.activeSeriesIndex = t.getActiveConfigSeriesIndex(), void 0 !== e[this.activeSeriesIndex]
            .data && e[this.activeSeriesIndex].data.length > 0 && null != e[this.activeSeriesIndex].data[0] &&
            e[this.activeSeriesIndex].data[0].constructor === Array) return !0
        }
      }, {
        key: "handleFormat2DArray",
        value: function(e, t) {
          for (var i = this.w.config, a = this.w.globals, s = "boxPlot" === i.chart.type || "boxPlot" === i
              .series[t].type, r = 0; r < e[t].data.length; r++)
            if (void 0 !== e[t].data[r][1] && (Array.isArray(e[t].data[r][1]) && 4 === e[t].data[r][1]
                .length && !s ? this.twoDSeries.push(P.parseNumber(e[t].data[r][1][3])) : this.twoDSeries
                .push(P.parseNumber(e[t].data[r].length >= 5 ? e[t].data[r][4] : e[t].data[r][1])), a
                .dataFormatXNumeric = !0), "datetime" === i.xaxis.type) {
              var n = new Date(e[t].data[r][0]);
              n = new Date(n).getTime(), this.twoDSeriesX.push(n)
            } else this.twoDSeriesX.push(e[t].data[r][0]);
          for (var o = 0; o < e[t].data.length; o++) void 0 !== e[t].data[o][2] && (this.threeDSeries.push(e[
            t].data[o][2]), a.isDataXYZ = !0)
        }
      }, {
        key: "handleFormatXY",
        value: function(e, t) {
          var i = this.w.config,
            a = this.w.globals,
            s = new Q(this.ctx),
            r = t;
          a.collapsedSeriesIndices.indexOf(t) > -1 && (r = this.activeSeriesIndex);
          for (var n = 0; n < e[t].data.length; n++) void 0 !== e[t].data[n].y && (Array.isArray(e[t].data[n]
                .y) ? this.twoDSeries.push(P.parseNumber(e[t].data[n].y[e[t].data[n].y.length - 1])) : this
              .twoDSeries.push(P.parseNumber(e[t].data[n].y))), void 0 !== e[t].data[n].goals && Array
            .isArray(e[t].data[n].goals) ? (void 0 === this.seriesGoals[t] && (this.seriesGoals[t] = []), this
              .seriesGoals[t].push(e[t].data[n].goals)) : (void 0 === this.seriesGoals[t] && (this
              .seriesGoals[t] = []), this.seriesGoals[t].push(null));
          for (var o = 0; o < e[r].data.length; o++) {
            var l = "string" == typeof e[r].data[o].x,
              c = Array.isArray(e[r].data[o].x),
              d = !c && !!s.isValidDate(e[r].data[o].x);
            l || d ? l || i.xaxis.convertedCatToNumeric ? "datetime" !== i.xaxis.type || a.isBarHorizontal &&
              a.isRangeData ? (this.fallbackToCategory = !0, this.twoDSeriesX.push(e[r].data[o].x), isNaN(e[r]
                  .data[o].x) || "category" === this.w.config.xaxis.type || "string" == typeof e[r].data[o]
                .x || (a.isXNumeric = !0)) : this.twoDSeriesX.push(s.parseDate(e[r].data[o].x)) :
              "datetime" === i.xaxis.type ? this.twoDSeriesX.push(s.parseDate(e[r].data[o].x.toString())) : (a
                .dataFormatXNumeric = !0, a.isXNumeric = !0, this.twoDSeriesX.push(parseFloat(e[r].data[o].x))
                ) : c ? (this.fallbackToCategory = !0, this.twoDSeriesX.push(e[r].data[o].x)) : (a
                .isXNumeric = !0, a.dataFormatXNumeric = !0, this.twoDSeriesX.push(e[r].data[o].x))
          }
          if (e[t].data[0] && void 0 !== e[t].data[0].z) {
            for (var p = 0; p < e[t].data.length; p++) this.threeDSeries.push(e[t].data[p].z);
            a.isDataXYZ = !0
          }
        }
      }, {
        key: "handleRangeData",
        value: function(e, t) {
          var i = this.w.globals,
            a = {};
          return this.isFormat2DArray() ? a = this.handleRangeDataFormat("array", e, t) : this.isFormatXY() &&
            (a = this.handleRangeDataFormat("xy", e, t)), i.seriesRangeStart.push(void 0 === a.start ? [] : a
              .start), i.seriesRangeEnd.push(void 0 === a.end ? [] : a.end), i.seriesRange.push(a
              .rangeUniques), i.seriesRange.forEach(function(s, r) {
              s && s.forEach(function(n, o) {
                n.y.forEach(function(l, c) {
                  for (var d = 0; d < n.y.length; d++) c !== d && l.y1 <= n.y[d].y2 && n.y[d].y1 <=
                    l.y2 && (n.overlaps.indexOf(l.rangeName) < 0 && n.overlaps.push(l.rangeName), n
                      .overlaps.indexOf(n.y[d].rangeName) < 0 && n.overlaps.push(n.y[d].rangeName))
                })
              })
            }), a
        }
      }, {
        key: "handleCandleStickBoxData",
        value: function(e, t) {
          var i = this.w.globals,
            a = {};
          return this.isFormat2DArray() ? a = this.handleCandleStickBoxDataFormat("array", e, t) : this
            .isFormatXY() && (a = this.handleCandleStickBoxDataFormat("xy", e, t)), i.seriesCandleO[t] = a.o,
            i.seriesCandleH[t] = a.h, i.seriesCandleM[t] = a.m, i.seriesCandleL[t] = a.l, i.seriesCandleC[t] =
            a.c, a
        }
      }, {
        key: "handleRangeDataFormat",
        value: function(e, t, i) {
          var a = [],
            s = [],
            r = t[i].data.filter(function(c, d, g) {
              return d === g.findIndex(function(p) {
                return p.x === c.x
              })
            }).map(function(c, d) {
              return {
                x: c.x,
                overlaps: [],
                y: []
              }
            });
          if ("array" === e)
            for (var n = 0; n < t[i].data.length; n++) Array.isArray(t[i].data[n]) ? (a.push(t[i].data[n][1][
              0]), s.push(t[i].data[n][1][1])) : (a.push(t[i].data[n]), s.push(t[i].data[n]));
          else if ("xy" === e)
            for (var o = function(c) {
                var d = Array.isArray(t[i].data[c].y),
                  g = P.randomId(),
                  p = t[i].data[c].x,
                  f = {
                    y1: d ? t[i].data[c].y[0] : t[i].data[c].y,
                    y2: d ? t[i].data[c].y[1] : t[i].data[c].y,
                    rangeName: g
                  };
                t[i].data[c].rangeName = g;
                var x = r.findIndex(function(m) {
                  return m.x === p
                });
                r[x].y.push(f), a.push(f.y1), s.push(f.y2)
              }, l = 0; l < t[i].data.length; l++) o(l);
          return {
            start: a,
            end: s,
            rangeUniques: r
          }
        }
      }, {
        key: "handleCandleStickBoxDataFormat",
        value: function(e, t, i) {
          var a = this.w,
            s = "boxPlot" === a.config.chart.type || "boxPlot" === a.config.series[i].type,
            r = [],
            n = [],
            o = [],
            l = [],
            c = [];
          if ("array" === e)
            if (s && 6 === t[i].data[0].length || !s && 5 === t[i].data[0].length)
              for (var d = 0; d < t[i].data.length; d++) r.push(t[i].data[d][1]), n.push(t[i].data[d][2]), s ?
                (o.push(t[i].data[d][3]), l.push(t[i].data[d][4]), c.push(t[i].data[d][5])) : (l.push(t[i]
                  .data[d][3]), c.push(t[i].data[d][4]));
            else
              for (var g = 0; g < t[i].data.length; g++) Array.isArray(t[i].data[g][1]) && (r.push(t[i].data[
                g][1][0]), n.push(t[i].data[g][1][1]), s ? (o.push(t[i].data[g][1][2]), l.push(t[i].data[
                g][1][3]), c.push(t[i].data[g][1][4])) : (l.push(t[i].data[g][1][2]), c.push(t[i].data[g][
                1
              ][3])));
          else if ("xy" === e)
            for (var p = 0; p < t[i].data.length; p++) Array.isArray(t[i].data[p].y) && (r.push(t[i].data[p]
              .y[0]), n.push(t[i].data[p].y[1]), s ? (o.push(t[i].data[p].y[2]), l.push(t[i].data[p].y[
              3]), c.push(t[i].data[p].y[4])) : (l.push(t[i].data[p].y[2]), c.push(t[i].data[p].y[3])));
          return {
            o: r,
            h: n,
            m: o,
            l,
            c
          }
        }
      }, {
        key: "parseDataAxisCharts",
        value: function(e) {
          var t = this,
            a = this.w.config,
            s = this.w.globals,
            r = new Q(arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.ctx),
            n = a.labels.length > 0 ? a.labels.slice() : a.xaxis.categories.slice();
          s.isRangeBar = "rangeBar" === a.chart.type && s.isBarHorizontal, s.hasXaxisGroups = "category" === a
            .xaxis.type && a.xaxis.group.groups.length > 0, s.hasXaxisGroups && (s.groups = a.xaxis.group
              .groups), e.forEach(function(p, f) {
              s.seriesNames.push(void 0 !== p.name ? p.name : "series-" + parseInt(f + 1, 10))
            }), this.coreUtils.setSeriesYAxisMappings();
          var o = [],
            l = J(new Set(a.series.map(function(p) {
              return p.group
            })));
          a.series.forEach(function(p, f) {
            var x = l.indexOf(p.group);
            o[x] || (o[x] = []), o[x].push(s.seriesNames[f])
          }), s.seriesGroups = o;
          for (var c = function() {
              for (var p = 0; p < n.length; p++)
                if ("string" == typeof n[p]) {
                  if (!r.isValidDate(n[p])) throw new Error(
                    "You have provided invalid Date format. Please provide a valid JavaScript Date");
                  t.twoDSeriesX.push(r.parseDate(n[p]))
                } else t.twoDSeriesX.push(n[p])
            }, d = 0; d < e.length; d++) {
            if (this.twoDSeries = [], this.twoDSeriesX = [], this.threeDSeries = [], void 0 === e[d].data)
              return void console.error(
                "It is a possibility that you may have not included 'data' property in series.");
            if ("rangeBar" !== a.chart.type && "rangeArea" !== a.chart.type && "rangeBar" !== e[d].type &&
              "rangeArea" !== e[d].type || (s.isRangeData = !0, "rangeBar" !== a.chart.type && "rangeArea" !==
                a.chart.type || this.handleRangeData(e, d)), this.isMultiFormat()) this.isFormat2DArray() ?
              this.handleFormat2DArray(e, d) : this.isFormatXY() && this.handleFormatXY(e, d),
              "candlestick" !== a.chart.type && "candlestick" !== e[d].type && "boxPlot" !== a.chart.type &&
              "boxPlot" !== e[d].type || this.handleCandleStickBoxData(e, d), s.series.push(this.twoDSeries),
              s.labels.push(this.twoDSeriesX), s.seriesX.push(this.twoDSeriesX), s.seriesGoals = this
              .seriesGoals, d !== this.activeSeriesIndex || this.fallbackToCategory || (s.isXNumeric = !0);
            else {
              "datetime" === a.xaxis.type ? (s.isXNumeric = !0, c(), s.seriesX.push(this.twoDSeriesX)) :
                "numeric" === a.xaxis.type && (s.isXNumeric = !0, n.length > 0 && (this.twoDSeriesX = n, s
                  .seriesX.push(this.twoDSeriesX))), s.labels.push(this.twoDSeriesX);
              var g = e[d].data.map(function(p) {
                return P.parseNumber(p)
              });
              s.series.push(g)
            }
            s.seriesZ.push(this.threeDSeries), s.seriesColors.push(void 0 !== e[d].color ? e[d].color :
              void 0)
          }
          return this.w
        }
      }, {
        key: "parseDataNonAxisCharts",
        value: function(e) {
          var t = this.w.globals,
            i = this.w.config;
          t.series = e.slice(), t.seriesNames = i.labels.slice();
          for (var a = 0; a < t.series.length; a++) void 0 === t.seriesNames[a] && t.seriesNames.push(
            "series-" + (a + 1));
          return this.w
        }
      }, {
        key: "handleExternalLabelsData",
        value: function(e) {
          var t = this.w.config,
            i = this.w.globals;
          t.xaxis.categories.length > 0 ? i.labels = t.xaxis.categories : t.labels.length > 0 ? i.labels = t
            .labels.slice() : this.fallbackToCategory ? (i.labels = i.labels[0], i.seriesRange.length && (i
                .seriesRange.map(function(a) {
                  a.forEach(function(s) {
                    i.labels.indexOf(s.x) < 0 && s.x && i.labels.push(s.x)
                  })
                }), i.labels = Array.from(new Set(i.labels.map(JSON.stringify)), JSON.parse)), t.xaxis
              .convertedCatToNumeric && (new ve(t).convertCatToNumericXaxis(t, this.ctx, i.seriesX[0]), this
                ._generateExternalLabels(e))) : this._generateExternalLabels(e)
        }
      }, {
        key: "_generateExternalLabels",
        value: function(e) {
          var t = this.w.globals,
            i = this.w.config,
            a = [];
          if (t.axisCharts) {
            if (t.series.length > 0)
              if (this.isFormatXY())
                for (var s = i.series.map(function(d, g) {
                    return d.data.filter(function(p, f, x) {
                      return x.findIndex(function(m) {
                        return m.x === p.x
                      }) === f
                    })
                  }), r = s.reduce(function(d, g, p, f) {
                    return f[d].length > g.length ? d : p
                  }, 0), n = 0; n < s[r].length; n++) a.push(n + 1);
              else
                for (var o = 0; o < t.series[t.maxValsInArrayIndex].length; o++) a.push(o + 1);
            t.seriesX = [];
            for (var l = 0; l < e.length; l++) t.seriesX.push(a);
            this.w.globals.isBarHorizontal || (t.isXNumeric = !0)
          }
          if (0 === a.length) {
            a = t.axisCharts ? [] : t.series.map(function(d, g) {
              return g + 1
            });
            for (var c = 0; c < e.length; c++) t.seriesX.push(a)
          }
          t.labels = a, i.xaxis.convertedCatToNumeric && (t.categoryLabels = a.map(function(d) {
            return i.xaxis.labels.formatter(d)
          })), t.noLabelsProvided = !0
        }
      }, {
        key: "parseData",
        value: function(e) {
          var t = this.w,
            i = t.config,
            a = t.globals;
          if (this.excludeCollapsedSeriesInYAxis(), this.fallbackToCategory = !1, this.ctx.core
          .resetGlobals(), this.ctx.core.isMultipleY(), a.axisCharts ? (this.parseDataAxisCharts(e), this
              .coreUtils.getLargestSeries()) : this.parseDataNonAxisCharts(e), i.chart.stacked) {
            var s = new se(this.ctx);
            a.series = s.setNullSeriesToZeroValues(a.series)
          }
          this.coreUtils.getSeriesTotals(), a.axisCharts && (a.stackedSeriesTotals = this.coreUtils
              .getStackedSeriesTotals(), a.stackedSeriesTotalsByGroups = this.coreUtils
              .getStackedSeriesTotalsByGroups()), this.coreUtils.getPercentSeries(), a.dataFormatXNumeric || a
            .isXNumeric && ("numeric" !== i.xaxis.type || 0 !== i.labels.length || 0 !== i.xaxis.categories
              .length) || this.handleExternalLabelsData(e);
          for (var r = this.coreUtils.getCategoryLabels(a.labels), n = 0; n < r.length; n++)
            if (Array.isArray(r[n])) {
              a.isMultiLineX = !0;
              break
            }
        }
      }, {
        key: "excludeCollapsedSeriesInYAxis",
        value: function() {
          var e = this.w,
            t = [];
          e.globals.seriesYAxisMap.forEach(function(i, a) {
            var s = 0;
            i.forEach(function(r) {
              -1 !== e.globals.collapsedSeriesIndices.indexOf(r) && s++
            }), s > 0 && s == i.length && t.push(a)
          }), e.globals.ignoreYAxisIndexes = t.map(function(i) {
            return i
          })
        }
      }]), w
    }(),
    Pe = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "scaleSvgNode",
        value: function(e, t) {
          var i = parseFloat(e.getAttributeNS(null, "width")),
            a = parseFloat(e.getAttributeNS(null, "height"));
          e.setAttributeNS(null, "width", i * t), e.setAttributeNS(null, "height", a * t), e.setAttributeNS(
            null, "viewBox", "0 0 " + i + " " + a)
        }
      }, {
        key: "fixSvgStringForIe11",
        value: function(e) {
          if (!P.isIE11()) return e.replace(/&nbsp;/g, "&#160;");
          var t = 0,
            i = e.replace(/xmlns="http:\/\/www.w3.org\/2000\/svg"/g, function(a) {
              return 2 == ++t ?
                'xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev"' : a
            });
          return (i = i.replace(/xmlns:NS\d+=""/g, "")).replace(/NS\d+:(\w+:\w+=")/g, "$1")
        }
      }, {
        key: "getSvgString",
        value: function(e) {
          null == e && (e = 1);
          var t = this.w.globals.dom.Paper.svg();
          if (1 !== e) {
            var i = this.w.globals.dom.Paper.node.cloneNode(!0);
            this.scaleSvgNode(i, e), t = (new XMLSerializer).serializeToString(i)
          }
          return this.fixSvgStringForIe11(t)
        }
      }, {
        key: "cleanup",
        value: function() {
          var e = this.w,
            t = e.globals.dom.baseEl.getElementsByClassName("apexcharts-xcrosshairs"),
            i = e.globals.dom.baseEl.getElementsByClassName("apexcharts-ycrosshairs"),
            a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-zoom-rect, .apexcharts-selection-rect");
          Array.prototype.forEach.call(a, function(s) {
            s.setAttribute("width", 0)
          }), t && t[0] && (t[0].setAttribute("x", -500), t[0].setAttribute("x1", -500), t[0].setAttribute(
            "x2", -500)), i && i[0] && (i[0].setAttribute("y", -100), i[0].setAttribute("y1", -100), i[0]
            .setAttribute("y2", -100))
        }
      }, {
        key: "svgUrl",
        value: function() {
          this.cleanup();
          var e = this.getSvgString(),
            t = new Blob([e], {
              type: "image/svg+xml;charset=utf-8"
            });
          return URL.createObjectURL(t)
        }
      }, {
        key: "dataURI",
        value: function(e) {
          var t = this;
          return new Promise(function(i) {
            var a = t.w,
              s = e ? e.scale || e.width / a.globals.svgWidth : 1;
            t.cleanup();
            var r = document.createElement("canvas");
            r.width = a.globals.svgWidth * s, r.height = parseInt(a.globals.dom.elWrap.style.height, 10) *
              s;
            var n = "transparent" === a.config.chart.background ? "#fff" : a.config.chart.background,
              o = r.getContext("2d");
            o.fillStyle = n, o.fillRect(0, 0, r.width * s, r.height * s);
            var l = t.getSvgString(s);
            if (window.canvg && P.isIE11()) {
              var c = window.canvg.Canvg.fromString(o, l, {
                ignoreClear: !0,
                ignoreDimensions: !0
              });
              c.start();
              var d = r.msToBlob();
              c.stop(), i({
                blob: d
              })
            } else {
              var g = "data:image/svg+xml," + encodeURIComponent(l),
                p = new Image;
              p.crossOrigin = "anonymous", p.onload = function() {
                if (o.drawImage(p, 0, 0), r.msToBlob) {
                  var f = r.msToBlob();
                  i({
                    blob: f
                  })
                } else {
                  var x = r.toDataURL("image/png");
                  i({
                    imgURI: x
                  })
                }
              }, p.src = g
            }
          })
        }
      }, {
        key: "exportToSVG",
        value: function() {
          this.triggerDownload(this.svgUrl(), this.w.config.chart.toolbar.export.svg.filename, ".svg")
        }
      }, {
        key: "exportToPng",
        value: function() {
          var e = this;
          this.dataURI().then(function(t) {
            var i = t.imgURI,
              a = t.blob;
            a ? navigator.msSaveOrOpenBlob(a, e.w.globals.chartID + ".png") : e.triggerDownload(i, e.w
              .config.chart.toolbar.export.png.filename, ".png")
          })
        }
      }, {
        key: "exportToCSV",
        value: function(e) {
          var t = this,
            i = e.series,
            a = e.fileName,
            s = e.columnDelimiter,
            r = void 0 === s ? "," : s,
            n = e.lineDelimiter,
            o = void 0 === n ? "\n" : n,
            l = this.w;
          i || (i = l.config.series);
          var c, d, g = [],
            p = [],
            f = "",
            x = l.globals.series.map(function(k, A) {
              return -1 === l.globals.collapsedSeriesIndices.indexOf(A) ? k : []
            }),
            m = function(k) {
              return "datetime" === l.config.xaxis.type && String(k).length >= 10
            },
            v = Math.max.apply(Math, J(i.map(function(k) {
              return k.data ? k.data.length : 0
            }))),
            y = new Ue(this.ctx),
            h = new ce(this.ctx),
            u = function(k) {
              var A = "";
              if (l.globals.axisCharts) {
                if ("category" === l.config.xaxis.type || l.config.xaxis.convertedCatToNumeric)
                  if (l.globals.isBarHorizontal) {
                    var S = l.globals.yLabelFormatters[0],
                      C = new se(t.ctx).getActiveConfigSeriesIndex();
                    A = S(l.globals.labels[k], {
                      seriesIndex: C,
                      dataPointIndex: k,
                      w: l
                    })
                  } else A = h.getLabel(l.globals.labels, l.globals.timescaleLabels, 0, k).text;
                "datetime" === l.config.xaxis.type && (l.config.xaxis.categories.length ? A = l.config.xaxis
                  .categories[k] : l.config.labels.length && (A = l.config.labels[k]))
              } else A = l.config.labels[k];
              return null === A ? "nullvalue" : (Array.isArray(A) && (A = A.join(" ")), P.isNumber(A) ? A : A
                .split(r).join(""))
            };
          g.push(l.config.chart.toolbar.export.csv.headerCategory), "boxPlot" === l.config.chart.type ? (g
              .push("minimum"), g.push("q1"), g.push("median"), g.push("q3"), g.push("maximum")) :
            "candlestick" === l.config.chart.type ? (g.push("open"), g.push("high"), g.push("low"), g.push(
              "close")) : "rangeBar" === l.config.chart.type ? (g.push("minimum"), g.push("maximum")) : i.map(
              function(k, A) {
                var S = (k.name ? k.name : "series-".concat(A)) + "";
                l.globals.axisCharts && g.push(S.split(r).join("") ? S.split(r).join("") : "series-".concat(
                  A))
              }), l.globals.axisCharts || (g.push(l.config.chart.toolbar.export.csv.headerValue), p.push(g
              .join(r))), l.globals.allSeriesHasEqualX || !l.globals.axisCharts || l.config.xaxis.categories
            .length || l.config.labels.length ? i.map(function(k, A) {
              l.globals.axisCharts ? function(k, A) {
                if (g.length && 0 === A && p.push(g.join(r)), k.data) {
                  k.data = k.data.length && k.data || J(Array(v)).map(function() {
                    return ""
                  });
                  for (var S = 0; S < k.data.length; S++) {
                    g = [];
                    var C = u(S);
                    if ("nullvalue" !== C) {
                      if (C || (y.isFormatXY() ? C = i[A].data[S].x : y.isFormat2DArray() && (C = i[A]
                          .data[S] ? i[A].data[S][0] : "")), 0 === A) {
                        g.push(m(C) ? l.config.chart.toolbar.export.csv.dateFormatter(C) : P.isNumber(C) ?
                          C : C.split(r).join(""));
                        for (var L = 0; L < l.globals.series.length; L++) {
                          var M;
                          y.isFormatXY() ? g.push(null === (M = i[L].data[S]) || void 0 === M ? void 0 : M
                            .y) : g.push(x[L][S])
                        }
                      }("candlestick" === l.config.chart.type || k.type && "candlestick" === k.type) && (g
                        .pop(), g.push(l.globals.seriesCandleO[A][S]), g.push(l.globals.seriesCandleH[A][
                          S]), g.push(l.globals.seriesCandleL[A][S]), g.push(l.globals.seriesCandleC[A][
                          S])), ("boxPlot" === l.config.chart.type || k.type && "boxPlot" === k.type) && (
                        g.pop(), g.push(l.globals.seriesCandleO[A][S]), g.push(l.globals.seriesCandleH[A][
                          S
                        ]), g.push(l.globals.seriesCandleM[A][S]), g.push(l.globals.seriesCandleL[A][S]),
                        g.push(l.globals.seriesCandleC[A][S])), "rangeBar" === l.config.chart.type && (g
                        .pop(), g.push(l.globals.seriesRangeStart[A][S]), g.push(l.globals
                          .seriesRangeEnd[A][S])), g.length && p.push(g.join(r))
                    }
                  }
                }
              }(k, A) : ((g = []).push(l.globals.labels[A].split(r).join("")), g.push(x[A]), p.push(g
                .join(r)))
            }) : (c = new Set, d = {}, i.forEach(function(k, A) {
              k?.data.forEach(function(S) {
                var C, L;
                if (y.isFormatXY()) C = S.x, L = S.y;
                else {
                  if (!y.isFormat2DArray()) return;
                  C = S[0], L = S[1]
                }
                d[C] || (d[C] = Array(i.length).fill("")), d[C][A] = L, c.add(C)
              })
            }), g.length && p.push(g.join(r)), Array.from(c).sort().forEach(function(k) {
              p.push([m(k) && "datetime" === l.config.xaxis.type ? l.config.chart.toolbar.export.csv
                .dateFormatter(k) : P.isNumber(k) ? k : k.split(r).join(""), d[k].join(r)
              ])
            })), f += p.join(o), this.triggerDownload("data:text/csv; charset=utf-8," + encodeURIComponent(
              "\ufeff" + f), a || l.config.chart.toolbar.export.csv.filename, ".csv")
        }
      }, {
        key: "triggerDownload",
        value: function(e, t, i) {
          var a = document.createElement("a");
          a.href = e, a.download = (t || this.w.globals.chartID) + i, document.body.appendChild(a), a.click(),
            document.body.removeChild(a)
        }
      }]), w
    }(),
    ke = function() {
      function w(e, t) {
        F(this, w), this.ctx = e, this.elgrid = t, this.w = e.w;
        var i = this.w;
        this.axesUtils = new ce(e), this.xaxisLabels = i.globals.labels.slice(), i.globals.timescaleLabels.length >
          0 && !i.globals.isBarHorizontal && (this.xaxisLabels = i.globals.timescaleLabels.slice()), i.config.xaxis
          .overwriteCategories && (this.xaxisLabels = i.config.xaxis.overwriteCategories), this.drawnLabels = [], this
          .drawnLabelsRects = [], this.offY = "top" === i.config.xaxis.position ? 0 : i.globals.gridHeight, this
          .offY = this.offY + i.config.xaxis.axisBorder.offsetY, this.isCategoryBarHorizontal = "bar" === i.config
          .chart.type && i.config.plotOptions.bar.horizontal, this.xaxisFontSize = i.config.xaxis.labels.style
          .fontSize, this.xaxisFontFamily = i.config.xaxis.labels.style.fontFamily, this.xaxisForeColors = i.config
          .xaxis.labels.style.colors, this.xaxisBorderWidth = i.config.xaxis.axisBorder.width, this
          .isCategoryBarHorizontal && (this.xaxisBorderWidth = i.config.yaxis[0].axisBorder.width.toString()), this
          .xaxisBorderWidth = this.xaxisBorderWidth.indexOf("%") > -1 ? i.globals.gridWidth * parseInt(this
            .xaxisBorderWidth, 10) / 100 : parseInt(this.xaxisBorderWidth, 10), this.xaxisBorderHeight = i.config
          .xaxis.axisBorder.height, this.yaxis = i.config.yaxis[0]
      }
      return R(w, [{
        key: "drawXaxis",
        value: function() {
          var e = this.w,
            t = new X(this.ctx),
            i = t.group({
              class: "apexcharts-xaxis",
              transform: "translate(".concat(e.config.xaxis.offsetX, ", ").concat(e.config.xaxis.offsetY,
                ")")
            }),
            a = t.group({
              class: "apexcharts-xaxis-texts-g",
              transform: "translate(".concat(e.globals.translateXAxisX, ", ").concat(e.globals
                .translateXAxisY, ")")
            });
          i.add(a);
          for (var s = [], r = 0; r < this.xaxisLabels.length; r++) s.push(this.xaxisLabels[r]);
          if (this.drawXAxisLabelAndGroup(!0, t, a, s, e.globals.isXNumeric, function(f, x) {
              return x
            }), e.globals.hasXaxisGroups) {
            var n = e.globals.groups;
            s = [];
            for (var o = 0; o < n.length; o++) s.push(n[o].title);
            var l = {};
            e.config.xaxis.group.style && (l.xaxisFontSize = e.config.xaxis.group.style.fontSize, l
              .xaxisFontFamily = e.config.xaxis.group.style.fontFamily, l.xaxisForeColors = e.config.xaxis
              .group.style.colors, l.fontWeight = e.config.xaxis.group.style.fontWeight, l.cssClass = e
              .config.xaxis.group.style.cssClass), this.drawXAxisLabelAndGroup(!1, t, a, s, !1, function(f,
              x) {
              return n[f].cols * x
            }, l)
          }
          if (void 0 !== e.config.xaxis.title.text) {
            var c = t.group({
                class: "apexcharts-xaxis-title"
              }),
              d = t.drawText({
                x: e.globals.gridWidth / 2 + e.config.xaxis.title.offsetX,
                y: this.offY + parseFloat(this.xaxisFontSize) + ("bottom" === e.config.xaxis.position ? e
                    .globals.xAxisLabelsHeight : -e.globals.xAxisLabelsHeight - 10) + e.config.xaxis.title
                  .offsetY,
                text: e.config.xaxis.title.text,
                textAnchor: "middle",
                fontSize: e.config.xaxis.title.style.fontSize,
                fontFamily: e.config.xaxis.title.style.fontFamily,
                fontWeight: e.config.xaxis.title.style.fontWeight,
                foreColor: e.config.xaxis.title.style.color,
                cssClass: "apexcharts-xaxis-title-text " + e.config.xaxis.title.style.cssClass
              });
            c.add(d), i.add(c)
          }
          if (e.config.xaxis.axisBorder.show) {
            var g = e.globals.barPadForNumericAxis,
              p = t.drawLine(e.globals.padHorizontal + e.config.xaxis.axisBorder.offsetX - g, this.offY, this
                .xaxisBorderWidth + g, this.offY, e.config.xaxis.axisBorder.color, 0, this.xaxisBorderHeight);
            this.elgrid && this.elgrid.elGridBorders && e.config.grid.show ? this.elgrid.elGridBorders.add(
              p) : i.add(p)
          }
          return i
        }
      }, {
        key: "drawXAxisLabelAndGroup",
        value: function(e, t, i, a, s, r) {
          var n, o = this,
            l = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : {},
            c = [],
            d = [],
            g = this.w,
            p = l.xaxisFontSize || this.xaxisFontSize,
            f = l.xaxisFontFamily || this.xaxisFontFamily,
            x = l.xaxisForeColors || this.xaxisForeColors,
            m = l.fontWeight || g.config.xaxis.labels.style.fontWeight,
            v = l.cssClass || g.config.xaxis.labels.style.cssClass,
            y = g.globals.padHorizontal,
            h = a.length,
            u = "category" === g.config.xaxis.type ? g.globals.dataPoints : h;
          0 === u && h > u && (u = h), s ? (n = g.globals.gridWidth / Math.min(u > 1 ? u - 1 : u, h - 1), y =
              y + r(0, n) / 2 + g.config.xaxis.labels.offsetX) : y = y + r(0, n = g.globals.gridWidth / u) + g
            .config.xaxis.labels.offsetX;
          for (var k = function(S) {
              var C = y - r(S, n) / 2 + g.config.xaxis.labels.offsetX;
              0 === S && 1 === h && n / 2 === y && 1 === u && (C = g.globals.gridWidth / 2);
              var L = o.axesUtils.getLabel(a, g.globals.timescaleLabels, C, S, c, p, e),
                M = 28;
              if (g.globals.rotateXLabels && e && (M = 22), g.config.xaxis.title.text && "top" === g.config
                .xaxis.position && (M += parseFloat(g.config.xaxis.title.style.fontSize) + 2), e || (M = M +
                  parseFloat(p) + (g.globals.xAxisLabelsHeight - g.globals.xAxisGroupLabelsHeight) + (g
                    .globals.rotateXLabels ? 10 : 0)), L = void 0 !== g.config.xaxis.tickAmount &&
                "dataPoints" !== g.config.xaxis.tickAmount && "datetime" !== g.config.xaxis.type ? o
                .axesUtils.checkLabelBasedOnTickamount(S, L, h) : o.axesUtils.checkForOverflowingLabels(S,
                  L, h, c, d), g.config.xaxis.labels.show) {
                var z = t.drawText({
                  x: L.x,
                  y: o.offY + g.config.xaxis.labels.offsetY + M - ("top" === g.config.xaxis.position ? g
                    .globals.xAxisHeight + g.config.xaxis.axisTicks.height - 2 : 0),
                  text: L.text,
                  textAnchor: "middle",
                  fontWeight: L.isBold ? 600 : m,
                  fontSize: p,
                  fontFamily: f,
                  foreColor: Array.isArray(x) ? e && g.config.xaxis.convertedCatToNumeric ? x[g.globals
                    .minX + S - 1] : x[S] : x,
                  isPlainText: !1,
                  cssClass: (e ? "apexcharts-xaxis-label " : "apexcharts-xaxis-group-label ") + v
                });
                if (i.add(z), z.on("click", function(T) {
                    if ("function" == typeof g.config.chart.events.xAxisLabelClick) {
                      var E = Object.assign({}, g, {
                        labelIndex: S
                      });
                      g.config.chart.events.xAxisLabelClick(T, o.ctx, E)
                    }
                  }), e) {
                  var I = document.createElementNS(g.globals.SVGNS, "title");
                  I.textContent = Array.isArray(L.text) ? L.text.join(" ") : L.text, z.node.appendChild(I),
                    "" !== L.text && (c.push(L.text), d.push(L))
                }
              }
              S < h - 1 && (y += r(S + 1, n))
            }, A = 0; A <= h - 1; A++) k(A)
        }
      }, {
        key: "drawXaxisInversed",
        value: function(e) {
          var t, i, a = this,
            s = this.w,
            r = new X(this.ctx),
            n = s.config.yaxis[0].opposite ? s.globals.translateYAxisX[e] : 0,
            o = r.group({
              class: "apexcharts-yaxis apexcharts-xaxis-inversed",
              rel: e
            }),
            l = r.group({
              class: "apexcharts-yaxis-texts-g apexcharts-xaxis-inversed-texts-g",
              transform: "translate(" + n + ", 0)"
            });
          o.add(l);
          var c = [];
          if (s.config.yaxis[e].show)
            for (var d = 0; d < this.xaxisLabels.length; d++) c.push(this.xaxisLabels[d]);
          i = -(t = s.globals.gridHeight / c.length) / 2.2;
          var g = s.globals.yLabelFormatters[0],
            p = s.config.yaxis[0].labels;
          if (p.show)
            for (var f = function(b) {
                var k = void 0 === c[b] ? "" : c[b];
                k = g(k, {
                  seriesIndex: e,
                  dataPointIndex: b,
                  w: s
                });
                var A = a.axesUtils.getYAxisForeColor(p.style.colors, e),
                  S = 0;
                Array.isArray(k) && (S = k.length / 2 * parseInt(p.style.fontSize, 10));
                var C = p.offsetX - 15,
                  L = "end";
                a.yaxis.opposite && (L = "start"), "left" === s.config.yaxis[0].labels.align ? (C = p
                  .offsetX, L = "start") : "center" === s.config.yaxis[0].labels.align ? (C = p.offsetX,
                  L = "middle") : "right" === s.config.yaxis[0].labels.align && (L = "end");
                var M = r.drawText({
                  x: C,
                  y: i + t + p.offsetY - S,
                  text: k,
                  textAnchor: L,
                  foreColor: Array.isArray(A) ? A[b] : A,
                  fontSize: p.style.fontSize,
                  fontFamily: p.style.fontFamily,
                  fontWeight: p.style.fontWeight,
                  isPlainText: !1,
                  cssClass: "apexcharts-yaxis-label " + p.style.cssClass,
                  maxWidth: p.maxWidth
                });
                l.add(M), M.on("click", function(T) {
                  if ("function" == typeof s.config.chart.events.xAxisLabelClick) {
                    var E = Object.assign({}, s, {
                      labelIndex: b
                    });
                    s.config.chart.events.xAxisLabelClick(T, a.ctx, E)
                  }
                });
                var z = document.createElementNS(s.globals.SVGNS, "title");
                if (z.textContent = Array.isArray(k) ? k.join(" ") : k, M.node.appendChild(z), 0 !== s
                  .config.yaxis[e].labels.rotate) {
                  var I = r.rotateAroundCenter(M.node);
                  M.node.setAttribute("transform", "rotate(".concat(s.config.yaxis[e].labels.rotate, " 0 ")
                    .concat(I.y, ")"))
                }
                i += t
              }, x = 0; x <= c.length - 1; x++) f(x);
          if (void 0 !== s.config.yaxis[0].title.text) {
            var m = r.group({
                class: "apexcharts-yaxis-title apexcharts-xaxis-title-inversed",
                transform: "translate(" + n + ", 0)"
              }),
              v = r.drawText({
                x: s.config.yaxis[0].title.offsetX,
                y: s.globals.gridHeight / 2 + s.config.yaxis[0].title.offsetY,
                text: s.config.yaxis[0].title.text,
                textAnchor: "middle",
                foreColor: s.config.yaxis[0].title.style.color,
                fontSize: s.config.yaxis[0].title.style.fontSize,
                fontWeight: s.config.yaxis[0].title.style.fontWeight,
                fontFamily: s.config.yaxis[0].title.style.fontFamily,
                cssClass: "apexcharts-yaxis-title-text " + s.config.yaxis[0].title.style.cssClass
              });
            m.add(v), o.add(m)
          }
          var y = 0;
          this.isCategoryBarHorizontal && s.config.yaxis[0].opposite && (y = s.globals.gridWidth);
          var h = s.config.xaxis.axisBorder;
          if (h.show) {
            var u = r.drawLine(s.globals.padHorizontal + h.offsetX + y, 1 + h.offsetY, s.globals
              .padHorizontal + h.offsetX + y, s.globals.gridHeight + h.offsetY, h.color, 0);
            this.elgrid && this.elgrid.elGridBorders && s.config.grid.show ? this.elgrid.elGridBorders.add(
              u) : o.add(u)
          }
          return s.config.yaxis[0].axisTicks.show && this.axesUtils.drawYAxisTicks(y, c.length, s.config
            .yaxis[0].axisBorder, s.config.yaxis[0].axisTicks, 0, t, o), o
        }
      }, {
        key: "drawXaxisTicks",
        value: function(e, t, i) {
          var a = this.w,
            s = e;
          if (!(e < 0 || e - 2 > a.globals.gridWidth)) {
            var r = this.offY + a.config.xaxis.axisTicks.offsetY;
            if (t = t + r + a.config.xaxis.axisTicks.height, "top" === a.config.xaxis.position && (t = r - a
                .config.xaxis.axisTicks.height), a.config.xaxis.axisTicks.show) {
              var n = new X(this.ctx).drawLine(e + a.config.xaxis.axisTicks.offsetX, r + a.config.xaxis
                .offsetY, s + a.config.xaxis.axisTicks.offsetX, t + a.config.xaxis.offsetY, a.config.xaxis
                .axisTicks.color);
              i.add(n), n.node.classList.add("apexcharts-xaxis-tick")
            }
          }
        }
      }, {
        key: "getXAxisTicksPositions",
        value: function() {
          var e = this.w,
            t = [],
            i = this.xaxisLabels.length,
            a = e.globals.padHorizontal;
          if (e.globals.timescaleLabels.length > 0)
            for (var s = 0; s < i; s++) t.push(a = this.xaxisLabels[s].position);
          else
            for (var r = i, n = 0; n < r; n++) {
              var o = r;
              e.globals.isXNumeric && "bar" !== e.config.chart.type && (o -= 1), t.push(a += e.globals
                .gridWidth / o)
            }
          return t
        }
      }, {
        key: "xAxisLabelCorrections",
        value: function() {
          var e = this.w,
            t = new X(this.ctx),
            i = e.globals.dom.baseEl.querySelector(".apexcharts-xaxis-texts-g"),
            a = e.globals.dom.baseEl.querySelectorAll(
              ".apexcharts-xaxis-texts-g text:not(.apexcharts-xaxis-group-label)"),
            s = e.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis-inversed text"),
            r = e.globals.dom.baseEl.querySelectorAll(".apexcharts-xaxis-inversed-texts-g text tspan");
          if (e.globals.rotateXLabels || e.config.xaxis.labels.rotateAlways)
            for (var n = 0; n < a.length; n++) {
              var o = t.rotateAroundCenter(a[n]);
              o.y = o.y - 1, o.x = o.x + 1, a[n].setAttribute("transform", "rotate(".concat(e.config.xaxis
                  .labels.rotate, " ").concat(o.x, " ").concat(o.y, ")")), a[n].setAttribute("text-anchor",
                  "end"), i.setAttribute("transform", "translate(0, ".concat(-10, ")")), e.config.xaxis.labels
                .trim && Array.prototype.forEach.call(a[n].childNodes, function(p) {
                  t.placeTextWithEllipsis(p, p.textContent, e.globals.xAxisLabelsHeight - ("bottom" === e
                    .config.legend.position ? 20 : 10))
                })
            } else ! function() {
              for (var p = e.globals.gridWidth / (e.globals.labels.length + 1), f = 0; f < a.length; f++) e
                .config.xaxis.labels.trim && "datetime" !== e.config.xaxis.type && Array.prototype.forEach
                .call(a[f].childNodes, function(m) {
                  t.placeTextWithEllipsis(m, m.textContent, p)
                })
            }();
          if (s.length > 0) {
            var c = s[s.length - 1].getBBox(),
              d = s[0].getBBox();
            c.x < -20 && s[s.length - 1].parentNode.removeChild(s[s.length - 1]), d.x + d.width > e.globals
              .gridWidth && !e.globals.isBarHorizontal && s[0].parentNode.removeChild(s[0]);
            for (var g = 0; g < r.length; g++) t.placeTextWithEllipsis(r[g], r[g].textContent, e.config.yaxis[
              0].labels.maxWidth - (e.config.yaxis[0].title.text ? 2 * parseFloat(e.config.yaxis[0].title
              .style.fontSize) : 0) - 15)
          }
        }
      }]), w
    }(),
    qe = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w;
        var t = this.w;
        this.xaxisLabels = t.globals.labels.slice(), this.axesUtils = new ce(e), this.isRangeBar = t.globals
          .seriesRange.length && t.globals.isBarHorizontal, t.globals.timescaleLabels.length > 0 && (this
            .xaxisLabels = t.globals.timescaleLabels.slice())
      }
      return R(w, [{
        key: "drawGridArea",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
            t = this.w,
            i = new X(this.ctx);
          null === e && (e = i.group({
            class: "apexcharts-grid"
          }));
          var a = i.drawLine(t.globals.padHorizontal, 1, t.globals.padHorizontal, t.globals.gridHeight,
              "transparent"),
            s = i.drawLine(t.globals.padHorizontal, t.globals.gridHeight, t.globals.gridWidth, t.globals
              .gridHeight, "transparent");
          return e.add(s), e.add(a), e
        }
      }, {
        key: "drawGrid",
        value: function() {
          var e = null;
          return this.w.globals.axisCharts && (e = this.renderGrid(), this.drawGridArea(e.el)), e
        }
      }, {
        key: "createGridMask",
        value: function() {
          var e = this.w,
            t = e.globals,
            i = new X(this.ctx),
            a = Array.isArray(e.config.stroke.width) ? 0 : e.config.stroke.width;
          if (Array.isArray(e.config.stroke.width)) {
            var s = 0;
            e.config.stroke.width.forEach(function(d) {
              s = Math.max(s, d)
            }), a = s
          }
          t.dom.elGridRectMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elGridRectMask
            .setAttribute("id", "gridRectMask".concat(t.cuid)), t.dom.elGridRectMarkerMask = document
            .createElementNS(t.SVGNS, "clipPath"), t.dom.elGridRectMarkerMask.setAttribute("id",
              "gridRectMarkerMask".concat(t.cuid)), t.dom.elForecastMask = document.createElementNS(t.SVGNS,
              "clipPath"), t.dom.elForecastMask.setAttribute("id", "forecastMask".concat(t.cuid)), t.dom
            .elNonForecastMask = document.createElementNS(t.SVGNS, "clipPath"), t.dom.elNonForecastMask
            .setAttribute("id", "nonForecastMask".concat(t.cuid));
          var r = e.config.chart.type,
            n = 0,
            o = 0;
          ("bar" === r || "rangeBar" === r || "candlestick" === r || "boxPlot" === r || e.globals
            .comboBarCount > 0) && e.globals.isXNumeric && !e.globals.isBarHorizontal && (o = e.config.grid
            .padding.right, t.barPadForNumericAxis > (n = e.config.grid.padding.left) && (n = t
              .barPadForNumericAxis, o = t.barPadForNumericAxis)), t.dom.elGridRect = i.drawRect(-a / 2 -
            n - 2, -a / 2 - 2, t.gridWidth + a + o + n + 4, t.gridHeight + a + 4, 0, "#fff");
          var l = e.globals.markers.largestSize + 1;
          t.dom.elGridRectMarker = i.drawRect(2 * -l, 2 * -l, t.gridWidth + 4 * l, t.gridHeight + 4 * l, 0,
              "#fff"), t.dom.elGridRectMask.appendChild(t.dom.elGridRect.node), t.dom.elGridRectMarkerMask
            .appendChild(t.dom.elGridRectMarker.node);
          var c = t.dom.baseEl.querySelector("defs");
          c.appendChild(t.dom.elGridRectMask), c.appendChild(t.dom.elForecastMask), c.appendChild(t.dom
            .elNonForecastMask), c.appendChild(t.dom.elGridRectMarkerMask)
        }
      }, {
        key: "_drawGridLines",
        value: function(e) {
          var t = e.i,
            i = e.x1,
            n = e.xCount,
            l = this.w;
          if (!(0 === t && l.globals.skipFirstTimelinelabel || t === n - 1 && l.globals
              .skipLastTimelinelabel && !l.config.xaxis.labels.formatter || "radar" === l.config.chart.type
              )) {
            l.config.grid.xaxis.lines.show && this._drawGridLine({
              i: t,
              x1: i,
              y1: e.y1,
              x2: e.x2,
              y2: e.y2,
              xCount: n,
              parent: e.parent
            });
            var c = 0;
            if (l.globals.hasXaxisGroups && "between" === l.config.xaxis.tickPlacement) {
              var d = l.globals.groups;
              if (d) {
                for (var g = 0, p = 0; g < t && p < d.length; p++) g += d[p].cols;
                g === t && (c = .6 * l.globals.xAxisLabelsHeight)
              }
            }
            new ke(this.ctx).drawXaxisTicks(i, c, l.globals.dom.elGraphical)
          }
        }
      }, {
        key: "_drawGridLine",
        value: function(e) {
          var t = e.i,
            i = e.x1,
            a = e.y1,
            s = e.x2,
            r = e.y2,
            n = e.xCount,
            o = e.parent,
            l = this.w,
            c = !1,
            d = o.node.classList.contains("apexcharts-gridlines-horizontal"),
            g = l.config.grid.strokeDashArray,
            p = l.globals.barPadForNumericAxis;
          (0 === a && 0 === r || 0 === i && 0 === s) && (c = !0), a === l.globals.gridHeight && r === l
            .globals.gridHeight && (c = !0), !l.globals.isBarHorizontal || 0 !== t && t !== n - 1 || (c = !0);
          var f = new X(this).drawLine(i - (d ? p : 0), a, s + (d ? p : 0), r, l.config.grid.borderColor, g);
          f.node.classList.add("apexcharts-gridline"), c && l.config.grid.show ? this.elGridBorders.add(f) : o
            .add(f)
        }
      }, {
        key: "_drawGridBandRect",
        value: function(e) {
          var t = e.c,
            i = e.x1,
            a = e.y1,
            s = e.x2,
            r = e.y2,
            n = e.type,
            o = this.w,
            l = new X(this.ctx),
            c = o.globals.barPadForNumericAxis;
          if ("column" !== n || "datetime" !== o.config.xaxis.type) {
            var g = l.drawRect(i - ("row" === n ? c : 0), a, s + ("row" === n ? 2 * c : 0), r, 0, o.config
              .grid[n].colors[t], o.config.grid[n].opacity);
            this.elg.add(g), g.attr("clip-path", "url(#gridRectMask".concat(o.globals.cuid, ")")), g.node
              .classList.add("apexcharts-grid-".concat(n))
          }
        }
      }, {
        key: "_drawXYLines",
        value: function(e) {
          var t = this,
            i = e.xCount,
            a = e.tickAmount,
            s = this.w;
          if (s.config.grid.xaxis.lines.show || s.config.xaxis.axisTicks.show) {
            var r, n = s.globals.padHorizontal,
              o = s.globals.gridHeight;
            s.globals.timescaleLabels.length ? function(f) {
              for (var x = f.xC, v = f.y1, h = f.y2, u = 0; u < x; u++) t._drawGridLines({
                i: u,
                x1: t.xaxisLabels[u].position,
                y1: v,
                x2: t.xaxisLabels[u].position,
                y2: h,
                xCount: i,
                parent: t.elgridLinesV
              })
            }({
              xC: i,
              x1: n,
              y1: 0,
              x2: r,
              y2: o
            }) : (s.globals.isXNumeric && (i = s.globals.xAxisScale.result.length), function(f) {
              for (var x = f.xC, m = f.x1, v = f.y1, y = f.x2, h = f.y2, u = 0; u < x + (s.globals
                  .isXNumeric ? 0 : 1); u++) 0 === u && 1 === x && 1 === s.globals.dataPoints && (y = m =
                s.globals.gridWidth / 2), t._drawGridLines({
                i: u,
                x1: m,
                y1: v,
                x2: y,
                y2: h,
                xCount: i,
                parent: t.elgridLinesV
              }), y = m += s.globals.gridWidth / (s.globals.isXNumeric ? x - 1 : x)
            }({
              xC: i,
              x1: n,
              y1: 0,
              x2: r,
              y2: o
            }))
          }
          if (s.config.grid.yaxis.lines.show) {
            var l = 0,
              c = 0,
              d = s.globals.gridWidth,
              g = a + 1;
            this.isRangeBar && (g = s.globals.labels.length);
            for (var p = 0; p < g + (this.isRangeBar ? 1 : 0); p++) this._drawGridLine({
              i: p,
              xCount: g + (this.isRangeBar ? 1 : 0),
              x1: 0,
              y1: l,
              x2: d,
              y2: c,
              parent: this.elgridLinesH
            }), c = l += s.globals.gridHeight / (this.isRangeBar ? g : a)
          }
        }
      }, {
        key: "_drawInvertedXYLines",
        value: function(e) {
          var t = e.xCount,
            i = this.w;
          if (i.config.grid.xaxis.lines.show || i.config.xaxis.axisTicks.show)
            for (var a, s = i.globals.padHorizontal, r = i.globals.gridHeight, n = 0; n < t + 1; n++) i.config
              .grid.xaxis.lines.show && this._drawGridLine({
                i: n,
                xCount: t + 1,
                x1: s,
                y1: 0,
                x2: a,
                y2: r,
                parent: this.elgridLinesV
              }), new ke(this.ctx).drawXaxisTicks(s, 0, i.globals.dom.elGraphical), a = s += i.globals
              .gridWidth / t;
          if (i.config.grid.yaxis.lines.show)
            for (var o = 0, l = 0, c = i.globals.gridWidth, d = 0; d < i.globals.dataPoints + 1; d++) this
              ._drawGridLine({
                i: d,
                xCount: i.globals.dataPoints + 1,
                x1: 0,
                y1: o,
                x2: c,
                y2: l,
                parent: this.elgridLinesH
              }), l = o += i.globals.gridHeight / i.globals.dataPoints
        }
      }, {
        key: "renderGrid",
        value: function() {
          var e = this.w,
            t = e.globals,
            i = new X(this.ctx);
          this.elg = i.group({
            class: "apexcharts-grid"
          }), this.elgridLinesH = i.group({
            class: "apexcharts-gridlines-horizontal"
          }), this.elgridLinesV = i.group({
            class: "apexcharts-gridlines-vertical"
          }), this.elGridBorders = i.group({
            class: "apexcharts-grid-borders"
          }), this.elg.add(this.elgridLinesH), this.elg.add(this.elgridLinesV), e.config.grid.show || (this
            .elgridLinesV.hide(), this.elgridLinesH.hide(), this.elGridBorders.hide());
          for (var a = 0; a < t.seriesYAxisMap.length && -1 !== t.ignoreYAxisIndexes.indexOf(a);) a++;
          a === t.seriesYAxisMap.length && (a = 0);
          var s, n, o, l, r = t.yAxisScale[a].result.length - 1;
          return !t.isBarHorizontal || this.isRangeBar ? (s = this.xaxisLabels.length, this.isRangeBar && (r =
              t.labels.length, e.config.xaxis.tickAmount && e.config.xaxis.labels.formatter && (s = e.config
                .xaxis.tickAmount), (null === (n = t.yAxisScale) || void 0 === n || null === (o = n[a]) ||
                void 0 === o || null === (l = o.result) || void 0 === l ? void 0 : l.length) > 0 &&
              "datetime" !== e.config.xaxis.type && (s = t.yAxisScale[a].result.length - 1)), this
            ._drawXYLines({
              xCount: s,
              tickAmount: r
            })) : this._drawInvertedXYLines({
            xCount: s = r,
            tickAmount: r = t.xTickAmount
          }), this.drawGridBands(s, r), {
            el: this.elg,
            elGridBorders: this.elGridBorders,
            xAxisTickWidth: t.gridWidth / s
          }
        }
      }, {
        key: "drawGridBands",
        value: function(e, t) {
          var i = this.w;
          if (void 0 !== i.config.grid.row.colors && i.config.grid.row.colors.length > 0)
            for (var a = 0, s = i.globals.gridHeight / t, r = i.globals.gridWidth, n = 0, o = 0; n < t; n++,
              o++) o >= i.config.grid.row.colors.length && (o = 0), this._drawGridBandRect({
              c: o,
              x1: 0,
              y1: a,
              x2: r,
              y2: s,
              type: "row"
            }), a += i.globals.gridHeight / t;
          if (void 0 !== i.config.grid.column.colors && i.config.grid.column.colors.length > 0)
            for (var l = i.globals.isBarHorizontal || "on" !== i.config.xaxis.tickPlacement || "category" !==
                i.config.xaxis.type && !i.config.xaxis.convertedCatToNumeric ? e : e - 1, c = i.globals
                .padHorizontal, d = i.globals.padHorizontal + i.globals.gridWidth / l, g = i.globals
                .gridHeight, p = 0, f = 0; p < e; p++, f++) f >= i.config.grid.column.colors.length && (f =
              0), this._drawGridBandRect({
                c: f,
                x1: c,
                y1: 0,
                x2: d,
                y2: g,
                type: "column"
              }), c += i.globals.gridWidth / l
        }
      }]), w
    }(),
    Ze = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "niceScale",
        value: function(e, t) {
          var i, a, s, r, n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
            o = 1e-11,
            l = this.w,
            c = l.globals;
          c.isBarHorizontal ? (i = l.config.xaxis, a = Math.max((c.svgWidth - 100) / 25, 2)) : (i = l.config
              .yaxis[n], a = Math.max((c.svgHeight - 100) / 15, 2)), s = null != i.min, r = void 0 !== i
            .max && null !== i.min;
          var d = null != i.stepSize,
            g = null != i.tickAmount,
            p = g ? i.tickAmount : i.forceNiceScale ? c.niceScaleDefaultTicks[Math.min(Math.round(a / 2), c
              .niceScaleDefaultTicks.length - 1)] : 10;
          if (c.isMultipleYAxis && !g && c.multiAxisTickAmount > 0 && (p = c.multiAxisTickAmount, g = !0), p =
            "dataPoints" === p ? c.dataPoints - 1 : Math.abs(Math.round(p)), (e === Number.MIN_VALUE && 0 ===
              t || !P.isNumber(e) && !P.isNumber(t) || e === Number.MIN_VALUE && t === -Number.MAX_VALUE) && (
              e = P.isNumber(i.min) ? i.min : 0, t = P.isNumber(i.max) ? i.max : e + p, c
              .allSeriesCollapsed = !1), e > t) {
            console.warn("axis.min cannot be greater than axis.max: swapping min and max");
            var f = t;
            t = e, e = f
          } else e === t && (e = 0 === e ? 0 : e - 1, t = 0 === t ? 2 : t + 1);
          var x = [];
          p < 1 && (p = 1);
          var m = p,
            v = Math.abs(t - e);
          i.forceNiceScale && (!s && e > 0 && e / v < .15 && (e = 0, s = !0), !r && t < 0 && -t / v < .15 && (
            t = 0, r = !0), v = Math.abs(t - e));
          var y = v / m,
            h = y,
            u = Math.floor(Math.log10(h)),
            b = Math.pow(10, u),
            k = Math.ceil(h / b);
          if (y = h = (k = c.niceScaleAllowedMagMsd[0 === c.yValueDecimal ? 0 : 1][k]) * b, c
            .isBarHorizontal && i.stepSize && "datetime" !== i.type ? (y = i.stepSize, d = !0) : d && (y = i
              .stepSize), d && i.forceNiceScale) {
            var A = Math.floor(Math.log10(y));
            y *= Math.pow(10, u - A)
          }
          if (s && r) {
            var S = v / m;
            if (g)
              if (d)
                if (0 != P.mod(v, y)) {
                  var C = P.getGCD(y, S);
                  y = S / C < 10 ? C : S
                } else 0 == P.mod(y, S) ? y = S : (S = y, g = !1);
            else y = S;
            else if (d) 0 == P.mod(v, y) ? S = y : y = S;
            else if (0 == P.mod(v, y)) S = y;
            else {
              S = v / (m = Math.ceil(v / y));
              var L = P.getGCD(v, y);
              v / L < a && (S = L), y = S
            }
            m = Math.round(v / y)
          } else {
            if (s || r) {
              if (r)
                if (g) e = t - y * m;
                else {
                  var M = e;
                  e = y * Math.floor(e / y), Math.abs(t - e) / P.getGCD(v, y) > a && (e = t - y * p, e += y *
                    Math.floor((M - e) / y))
                }
              else if (s)
                if (g) t = e + y * m;
                else {
                  var z = t;
                  t = y * Math.ceil(t / y), Math.abs(t - e) / P.getGCD(v, y) > a && (t = e + y * p, t += y *
                    Math.ceil((z - t) / y))
                }
            } else if (g) {
              var I = y / (t - e > t ? 1 : 2),
                T = I * Math.floor(e / I);
              Math.abs(T - e) <= I / 2 ? t = (e = T) + y * m : e = (t = I * Math.ceil(t / I)) - y * m
            } else e = y * Math.floor(e / y), t = y * Math.ceil(t / y);
            v = Math.abs(t - e), y = P.getGCD(v, y), m = Math.round(v / y)
          }
          if (g || s || r || (m = Math.ceil((v - o) / (y + o))) > 16 && P.getPrimeFactors(m).length < 2 &&
            m++, !g && i.forceNiceScale && 0 === c.yValueDecimal && m > v && (m = v, y = Math.round(v / m)),
            m > a && (!g && !d || i.forceNiceScale)) {
            var E = P.getPrimeFactors(m),
              H = E.length - 1,
              D = m;
            e: for (var O = 0; O < H; O++)
              for (var W = 0; W <= H - O; W++) {
                for (var N = Math.min(W + O, H), B = D, Z = 1, U = W; U <= N; U++) Z *= E[U];
                if ((B /= Z) < a) {
                  D = B;
                  break e
                }
              }
            y = D === m ? v : v / D, m = Math.round(v / y)
          }
          c.isMultipleYAxis && 0 == c.multiAxisTickAmount && c.ignoreYAxisIndexes.indexOf(n) < 0 && (c
            .multiAxisTickAmount = m);
          var _ = e - y,
            ae = y * o;
          do {
            x.push(P.stripNumber(_ += y, 7))
          } while (t - _ > ae);
          return {
            result: x,
            niceMin: x[0],
            niceMax: x[x.length - 1]
          }
        }
      }, {
        key: "linearScale",
        value: function(e, t) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 10,
            a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
            s = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : void 0,
            r = Math.abs(t - e);
          "dataPoints" === (i = this._adjustTicksForSmallRange(i, a, r)) && (i = this.w.globals.dataPoints -
            1), s || (s = r / i), i === Number.MAX_VALUE && (i = 5, s = 1);
          for (var n = [], o = e; i >= 0;) n.push(o), o += s, i -= 1;
          return {
            result: n,
            niceMin: n[0],
            niceMax: n[n.length - 1]
          }
        }
      }, {
        key: "logarithmicScaleNice",
        value: function(e, t, i) {
          t <= 0 && (t = Math.max(e, i)), e <= 0 && (e = Math.min(t, i));
          for (var a = [], s = Math.ceil(Math.log(t) / Math.log(i) + 1), r = Math.floor(Math.log(e) / Math
              .log(i)); r < s; r++) a.push(Math.pow(i, r));
          return {
            result: a,
            niceMin: a[0],
            niceMax: a[a.length - 1]
          }
        }
      }, {
        key: "logarithmicScale",
        value: function(e, t, i) {
          t <= 0 && (t = Math.max(e, i)), e <= 0 && (e = Math.min(t, i));
          for (var a = [], s = Math.log(t) / Math.log(i), r = Math.log(e) / Math.log(i), n = s - r, o = Math
              .round(n), l = n / o, c = 0, d = r; c < o; c++, d += l) a.push(Math.pow(i, d));
          return a.push(Math.pow(i, s)), {
            result: a,
            niceMin: e,
            niceMax: t
          }
        }
      }, {
        key: "_adjustTicksForSmallRange",
        value: function(e, t, i) {
          var a = e;
          if (void 0 !== t && this.w.config.yaxis[t].labels.formatter && void 0 === this.w.config.yaxis[t]
            .tickAmount) {
            var s = Number(this.w.config.yaxis[t].labels.formatter(1));
            P.isNumber(s) && 0 === this.w.globals.yValueDecimal && (a = Math.ceil(i))
          }
          return a < e ? a : e
        }
      }, {
        key: "setYScaleForIndex",
        value: function(e, t, i) {
          var a = this.w.globals,
            s = this.w.config,
            r = a.isBarHorizontal ? s.xaxis : s.yaxis[e];
          void 0 === a.yAxisScale[e] && (a.yAxisScale[e] = []);
          var n = Math.abs(i - t);
          r.logarithmic && n <= 5 && (a.invalidLogScale = !0), r.logarithmic && n > 5 ? (a
              .allSeriesCollapsed = !1, a.yAxisScale[e] = r.forceNiceScale ? this.logarithmicScaleNice(t, i, r
                .logBase) : this.logarithmicScale(t, i, r.logBase)) : i !== -Number.MAX_VALUE && P.isNumber(
            i) && t !== Number.MAX_VALUE && P.isNumber(t) ? (a.allSeriesCollapsed = !1, a.yAxisScale[e] = this
              .niceScale(t, i, e)) : a.yAxisScale[e] = this.niceScale(Number.MIN_VALUE, 0, e)
        }
      }, {
        key: "setXScale",
        value: function(e, t) {
          var i = this.w,
            a = i.globals,
            s = Math.abs(t - e);
          return a.xAxisScale = t !== -Number.MAX_VALUE && P.isNumber(t) ? this.linearScale(e, t, i.config
            .xaxis.tickAmount ? i.config.xaxis.tickAmount : s < 10 && s > 1 ? s + 1 : 10, 0, i.config.xaxis
            .stepSize) : this.linearScale(0, 10, 10), a.xAxisScale
        }
      }, {
        key: "setSeriesYAxisMappings",
        value: function() {
          var e = this.w.globals,
            t = this.w.config,
            i = [],
            a = [],
            s = [],
            r = e.series.length > t.yaxis.length || t.yaxis.some(function(d) {
              return Array.isArray(d.seriesName)
            });
          t.series.forEach(function(d, g) {
            s.push(g), a.push(null)
          }), t.yaxis.forEach(function(d, g) {
            i[g] = []
          });
          var n = [];
          t.yaxis.forEach(function(d, g) {
            var p = !1;
            if (d.seriesName) {
              var f = [];
              Array.isArray(d.seriesName) ? f = d.seriesName : f.push(d.seriesName), f.forEach(function(
              x) {
                t.series.forEach(function(m, v) {
                  if (m.name === x) {
                    var y = v;
                    g === v || r ? !r || s.indexOf(v) > -1 ? i[g].push([g, v]) : console.warn(
                        "Series '" + m.name +
                        "' referenced more than once in what looks like the new style. That is, when using either seriesName: [], or when there are more series than yaxes."
                        ) : (i[v].push([v, g]), y = g), p = !0, -1 !== (y = s.indexOf(y)) && s
                      .splice(y, 1)
                  }
                })
              })
            }
            p || n.push(g)
          }), i = i.map(function(d, g) {
            var p = [];
            return d.forEach(function(f) {
              a[f[1]] = f[0], p.push(f[1])
            }), p
          });
          for (var o = t.yaxis.length - 1, l = 0; l < n.length && (i[o = n[l]] = [], s); l++) {
            var c = s[0];
            s.shift(), i[o].push(c), a[c] = o
          }
          s.forEach(function(d) {
            i[o].push(d), a[d] = o
          }), e.seriesYAxisMap = i.map(function(d) {
            return d
          }), e.seriesYAxisReverseMap = a.map(function(d) {
            return d
          })
        }
      }, {
        key: "scaleMultipleYAxes",
        value: function() {
          var e = this,
            t = this.w.config,
            i = this.w.globals;
          this.setSeriesYAxisMappings();
          var a = i.seriesYAxisMap,
            s = i.minYArr,
            r = i.maxYArr;
          i.allSeriesCollapsed = !0, i.barGroups = [], a.forEach(function(n, o) {
            var l = [];
            n.forEach(function(c) {
              var d = t.series[c].group;
              l.indexOf(d) < 0 && l.push(d)
            }), n.length > 0 ? function() {
              var c, d, g = Number.MAX_VALUE,
                p = -Number.MAX_VALUE,
                f = g,
                x = p;
              if (t.chart.stacked) ! function() {
                var y = i.seriesX[n[0]],
                  h = [],
                  u = [],
                  b = [];
                l.forEach(function() {
                  h.push(y.map(function() {
                    return Number.MIN_VALUE
                  })), u.push(y.map(function() {
                    return Number.MIN_VALUE
                  })), b.push(y.map(function() {
                    return Number.MIN_VALUE
                  }))
                });
                for (var k = function(S) {
                    !c && t.series[n[S]].type && (c = t.series[n[S]].type);
                    var C = n[S];
                    d = t.series[C].group ? t.series[C].group : "axis-".concat(o), !(i
                      .collapsedSeriesIndices.indexOf(C) < 0 && i.ancillaryCollapsedSeriesIndices
                      .indexOf(C) < 0) || (i.allSeriesCollapsed = !1, l.forEach(function(L, M) {
                      if (t.series[C].group === L)
                        for (var z = 0; z < i.series[C].length; z++) {
                          var I = i.series[C][z];
                          I >= 0 ? u[M][z] += I : b[M][z] += I, h[M][z] += I, f = Math.min(f,
                            I), x = Math.max(x, I)
                        }
                    })), "bar" !== c && "column" !== c || i.barGroups.push(d)
                  }, A = 0; A < n.length; A++) k(A);
                c || (c = t.chart.type), "bar" === c || "column" === c ? l.forEach(function(S, C) {
                  g = Math.min(g, Math.min.apply(null, b[C])), p = Math.max(p, Math.max.apply(
                    null, u[C]))
                }) : (l.forEach(function(S, C) {
                  f = Math.min(f, Math.min.apply(null, h[C])), x = Math.max(x, Math.max.apply(
                    null, h[C]))
                }), g = f, p = x), g === Number.MIN_VALUE && p === Number.MIN_VALUE && (p = -Number
                  .MAX_VALUE)
              }();
              else
                for (var m = 0; m < n.length; m++) {
                  var v = n[m];
                  g = Math.min(g, s[v]), p = Math.max(p, r[v]), !(i.collapsedSeriesIndices.indexOf(v) <
                    0 && i.ancillaryCollapsedSeriesIndices.indexOf(v) < 0) || (i
                    .allSeriesCollapsed = !1)
                }
              void 0 !== t.yaxis[o].min && (g = "function" == typeof t.yaxis[o].min ? t.yaxis[o].min(
                g) : t.yaxis[o].min), void 0 !== t.yaxis[o].max && (p = "function" == typeof t.yaxis[
                o].max ? t.yaxis[o].max(p) : t.yaxis[o].max), i.barGroups = i.barGroups.filter(
                function(y, h, u) {
                  return u.indexOf(y) === h
                }), e.setYScaleForIndex(o, g, p), n.forEach(function(y) {
                s[y] = i.yAxisScale[o].niceMin, r[y] = i.yAxisScale[o].niceMax
              })
            }() : e.setYScaleForIndex(o, 0, -Number.MAX_VALUE)
          })
        }
      }]), w
    }(),
    Ee = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.scales = new Ze(e)
      }
      return R(w, [{
        key: "init",
        value: function() {
          this.setYRange(), this.setXRange(), this.setZRange()
        }
      }, {
        key: "getMinYMaxY",
        value: function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Number.MAX_VALUE,
            i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : -Number.MAX_VALUE,
            a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
            s = this.w.config,
            r = this.w.globals,
            n = -Number.MAX_VALUE,
            o = Number.MIN_VALUE;
          null === a && (a = e + 1);
          var l = 0,
            c = 0,
            d = void 0;
          if (r.seriesX.length >= a) {
            var g, p;
            l = 0, c = (d = J(new Set((g = []).concat.apply(g, J(r.seriesX.slice(e, a)))))).length - 1;
            var f = null === (p = r.brushSource) || void 0 === p ? void 0 : p.w.config.chart.brush;
            if (s.chart.zoom.enabled && s.chart.zoom.autoScaleYaxis || null != f && f.enabled && null != f &&
              f.autoScaleYaxis) {
              if (s.xaxis.min)
                for (l = 0; l < c && d[l] < s.xaxis.min; l++);
              if (s.xaxis.max)
                for (; c > l && d[c] > s.xaxis.max; c--);
            }
          }
          var x = r.series,
            m = x,
            v = x;
          "candlestick" === s.chart.type ? (m = r.seriesCandleL, v = r.seriesCandleH) : "boxPlot" === s.chart
            .type ? (m = r.seriesCandleO, v = r.seriesCandleC) : r.isRangeData && (m = r.seriesRangeStart, v =
              r.seriesRangeEnd);
          for (var y = e; y < a; y++) {
            r.dataPoints = Math.max(r.dataPoints, x[y].length);
            var h = s.series[y].type;
            r.categoryLabels.length && (r.dataPoints = r.categoryLabels.filter(function(k) {
              return void 0 !== k
            }).length), r.labels.length && "datetime" !== s.xaxis.type && 0 !== r.series.reduce(function(k,
              A) {
              return k + A.length
            }, 0) && (r.dataPoints = Math.max(r.dataPoints, r.labels.length)), d || (l = 0, c = r.series[y]
              .length);
            for (var u = l; u <= c && u < r.series[y].length; u++) {
              var b = x[y][u];
              if (null !== b && P.isNumber(b)) {
                switch (void 0 !== v[y][u] && (n = Math.max(n, v[y][u]), t = Math.min(t, v[y][u])), void 0 !==
                  m[y][u] && (t = Math.min(t, m[y][u]), i = Math.max(i, m[y][u])), h) {
                  case "candlestick":
                    void 0 !== r.seriesCandleC[y][u] && (n = Math.max(n, r.seriesCandleH[y][u]), t = Math.min(
                      t, r.seriesCandleL[y][u]));
                    break;
                  case "boxPlot":
                    void 0 !== r.seriesCandleC[y][u] && (n = Math.max(n, r.seriesCandleC[y][u]), t = Math.min(
                      t, r.seriesCandleO[y][u]))
                }
                h && "candlestick" !== h && "boxPlot" !== h && "rangeArea" !== h && "rangeBar" !== h && (n =
                    Math.max(n, r.series[y][u]), t = Math.min(t, r.series[y][u])), i = n, r.seriesGoals[y] &&
                  r.seriesGoals[y][u] && Array.isArray(r.seriesGoals[y][u]) && r.seriesGoals[y][u].forEach(
                    function(k) {
                      o !== Number.MIN_VALUE && (o = Math.min(o, k.value), t = o), n = Math.max(n, k.value),
                        i = n
                    }), P.isFloat(b) && (b = P.noExponents(b), r.yValueDecimal = Math.max(r.yValueDecimal, b
                    .toString().split(".")[1].length)), o > m[y][u] && m[y][u] < 0 && (o = m[y][u])
              } else r.hasNullValues = !0
            }
            "bar" !== h && "column" !== h || (o < 0 && n < 0 && (n = 0, i = Math.max(i, 0)), o === Number
              .MIN_VALUE && (o = 0, t = Math.min(t, 0)))
          }
          return "rangeBar" === s.chart.type && r.seriesRangeStart.length && r.isBarHorizontal && (o = t),
            "bar" === s.chart.type && (o < 0 && n < 0 && (n = 0), o === Number.MIN_VALUE && (o = 0)), {
              minY: o,
              maxY: n,
              lowestY: t,
              highestY: i
            }
        }
      }, {
        key: "setYRange",
        value: function() {
          var e = this.w.globals,
            t = this.w.config;
          e.maxY = -Number.MAX_VALUE, e.minY = Number.MIN_VALUE;
          var i, a = Number.MAX_VALUE;
          if (e.isMultipleYAxis) {
            a = Number.MAX_VALUE;
            for (var s = 0; s < e.series.length; s++) i = this.getMinYMaxY(s), e.minYArr[s] = i.lowestY, e
              .maxYArr[s] = i.highestY, a = Math.min(a, i.lowestY)
          }
          return i = this.getMinYMaxY(0, a, null, e.series.length), "bar" === t.chart.type ? (e.minY = i.minY,
              e.maxY = i.maxY) : (e.minY = i.lowestY, e.maxY = i.highestY), a = i.lowestY, t.chart.stacked &&
            this._setStackedMinMax(), "line" === t.chart.type || "area" === t.chart.type || "scatter" === t
            .chart.type || "candlestick" === t.chart.type || "boxPlot" === t.chart.type || "rangeBar" === t
            .chart.type && !e.isBarHorizontal ? e.minY === Number.MIN_VALUE && a !== -Number.MAX_VALUE &&
            a !== e.maxY && (e.minY = a) : e.minY = i.minY, t.yaxis.forEach(function(r, n) {
              void 0 !== r.max && ("number" == typeof r.max ? e.maxYArr[n] = r.max : "function" == typeof r
                .max && (e.maxYArr[n] = r.max(e.isMultipleYAxis ? e.maxYArr[n] : e.maxY)), e.maxY = e
                .maxYArr[n]), void 0 !== r.min && ("number" == typeof r.min ? e.minYArr[n] = r.min :
                "function" == typeof r.min && (e.minYArr[n] = r.min(e.isMultipleYAxis ? e.minYArr[n] ===
                  Number.MIN_VALUE ? 0 : e.minYArr[n] : e.minY)), e.minY = e.minYArr[n])
            }), e.isBarHorizontal && ["min", "max"].forEach(function(r) {
              void 0 !== t.xaxis[r] && "number" == typeof t.xaxis[r] && ("min" === r ? e.minY = t.xaxis[r] :
                e.maxY = t.xaxis[r])
            }), e.isMultipleYAxis ? (this.scales.scaleMultipleYAxes(), e.minY = a) : (this.scales
              .setYScaleForIndex(0, e.minY, e.maxY), e.minY = e.yAxisScale[0].niceMin, e.maxY = e.yAxisScale[
                0].niceMax, e.minYArr[0] = e.minY, e.maxYArr[0] = e.maxY), e.barGroups = [], e
          .lineGroups = [], e.areaGroups = [], t.series.forEach(function(r) {
              switch (r.type || t.chart.type) {
                case "bar":
                case "column":
                  e.barGroups.push(r.group);
                  break;
                case "line":
                  e.lineGroups.push(r.group);
                  break;
                case "area":
                  e.areaGroups.push(r.group)
              }
            }), e.barGroups = e.barGroups.filter(function(r, n, o) {
              return o.indexOf(r) === n
            }), e.lineGroups = e.lineGroups.filter(function(r, n, o) {
              return o.indexOf(r) === n
            }), e.areaGroups = e.areaGroups.filter(function(r, n, o) {
              return o.indexOf(r) === n
            }), {
              minY: e.minY,
              maxY: e.maxY,
              minYArr: e.minYArr,
              maxYArr: e.maxYArr,
              yAxisScale: e.yAxisScale
            }
        }
      }, {
        key: "setXRange",
        value: function() {
          var e = this.w.globals,
            t = this.w.config,
            i = "numeric" === t.xaxis.type || "datetime" === t.xaxis.type || "category" === t.xaxis.type && !e
            .noLabelsProvided || e.noLabelsProvided || e.isXNumeric;
          if (e.isXNumeric && function() {
              for (var n = 0; n < e.series.length; n++)
                if (e.labels[n])
                  for (var o = 0; o < e.labels[n].length; o++) null !== e.labels[n][o] && P.isNumber(e.labels[
                    n][o]) && (e.maxX = Math.max(e.maxX, e.labels[n][o]), e.initialMaxX = Math.max(e.maxX, e
                    .labels[n][o]), e.minX = Math.min(e.minX, e.labels[n][o]), e.initialMinX = Math.min(e
                    .minX, e.labels[n][o]))
            }(), e.noLabelsProvided && 0 === t.xaxis.categories.length && (e.maxX = e.labels[e.labels.length -
              1], e.initialMaxX = e.labels[e.labels.length - 1], e.minX = 1, e.initialMinX = 1), e
            .isXNumeric || e.noLabelsProvided || e.dataFormatXNumeric) {
            var a;
            if (void 0 === t.xaxis.tickAmount ? (a = Math.round(e.svgWidth / 150), "numeric" === t.xaxis
                .type && e.dataPoints < 30 && (a = e.dataPoints - 1), a > e.dataPoints && 0 !== e
                .dataPoints && (a = e.dataPoints - 1)) : "dataPoints" === t.xaxis.tickAmount ? (e.series
                .length > 1 && (a = e.series[e.maxValsInArrayIndex].length - 1), e.isXNumeric && (a = e.maxX -
                  e.minX - 1)) : a = t.xaxis.tickAmount, e.xTickAmount = a, void 0 !== t.xaxis.max &&
              "number" == typeof t.xaxis.max && (e.maxX = t.xaxis.max), void 0 !== t.xaxis.min && "number" ==
              typeof t.xaxis.min && (e.minX = t.xaxis.min), void 0 !== t.xaxis.range && (e.minX = e.maxX - t
                .xaxis.range), e.minX !== Number.MAX_VALUE && e.maxX !== -Number.MAX_VALUE)
              if (t.xaxis.convertedCatToNumeric && !e.dataFormatXNumeric) {
                for (var s = [], r = e.minX - 1; r < e.maxX; r++) s.push(r + 1);
                e.xAxisScale = {
                  result: s,
                  niceMin: s[0],
                  niceMax: s[s.length - 1]
                }
              } else e.xAxisScale = this.scales.setXScale(e.minX, e.maxX);
            else e.xAxisScale = this.scales.linearScale(0, a, a, 0, t.xaxis.stepSize), e.noLabelsProvided && e
              .labels.length > 0 && (e.xAxisScale = this.scales.linearScale(1, e.labels.length, a - 1, 0, t
                .xaxis.stepSize), e.seriesX = e.labels.slice());
            i && (e.labels = e.xAxisScale.result.slice())
          }
          return e.isBarHorizontal && e.labels.length && (e.xTickAmount = e.labels.length), this
            ._handleSingleDataPoint(), this._getMinXDiff(), {
              minX: e.minX,
              maxX: e.maxX
            }
        }
      }, {
        key: "setZRange",
        value: function() {
          var e = this.w.globals;
          if (e.isDataXYZ)
            for (var t = 0; t < e.series.length; t++)
              if (void 0 !== e.seriesZ[t])
                for (var i = 0; i < e.seriesZ[t].length; i++) null !== e.seriesZ[t][i] && P.isNumber(e
                  .seriesZ[t][i]) && (e.maxZ = Math.max(e.maxZ, e.seriesZ[t][i]), e.minZ = Math.min(e.minZ,
                  e.seriesZ[t][i]))
        }
      }, {
        key: "_handleSingleDataPoint",
        value: function() {
          var e = this.w.globals,
            t = this.w.config;
          if (e.minX === e.maxX) {
            var i = new Q(this.ctx);
            if ("datetime" === t.xaxis.type) {
              var a = i.getDate(e.minX);
              t.xaxis.labels.datetimeUTC ? a.setUTCDate(a.getUTCDate() - 2) : a.setDate(a.getDate() - 2), e
                .minX = new Date(a).getTime();
              var s = i.getDate(e.maxX);
              t.xaxis.labels.datetimeUTC ? s.setUTCDate(s.getUTCDate() + 2) : s.setDate(s.getDate() + 2), e
                .maxX = new Date(s).getTime()
            } else("numeric" === t.xaxis.type || "category" === t.xaxis.type && !e.noLabelsProvided) && (e
              .minX = e.minX - 2, e.initialMinX = e.minX, e.maxX = e.maxX + 2, e.initialMaxX = e.maxX)
          }
        }
      }, {
        key: "_getMinXDiff",
        value: function() {
          var e = this.w.globals;
          e.isXNumeric && e.seriesX.forEach(function(t, i) {
            1 === t.length && t.push(e.seriesX[e.maxValsInArrayIndex][e.seriesX[e.maxValsInArrayIndex]
              .length - 1
            ]);
            var a = t.slice();
            a.sort(function(s, r) {
              return s - r
            }), a.forEach(function(s, r) {
              if (r > 0) {
                var n = s - a[r - 1];
                n > 0 && (e.minXDiff = Math.min(n, e.minXDiff))
              }
            }), 1 !== e.dataPoints && e.minXDiff !== Number.MAX_VALUE || (e.minXDiff = .5)
          })
        }
      }, {
        key: "_setStackedMinMax",
        value: function() {
          var e = this,
            t = this.w.globals;
          if (t.series.length) {
            var i = t.seriesGroups;
            i.length || (i = [this.w.globals.seriesNames.map(function(r) {
              return r
            })]);
            var a = {},
              s = {};
            i.forEach(function(r) {
              a[r] = [], s[r] = [], e.w.config.series.map(function(n, o) {
                return r.indexOf(t.seriesNames[o]) > -1 ? o : null
              }).filter(function(n) {
                return null !== n
              }).forEach(function(n) {
                for (var o = 0; o < t.series[t.maxValsInArrayIndex].length; o++) {
                  var l, c, d, g;
                  void 0 === a[r][o] && (a[r][o] = 0, s[r][o] = 0), (e.w.config.chart.stacked && !t
                    .comboCharts || e.w.config.chart.stacked && t.comboCharts && (!e.w.config.chart
                      .stackOnlyBar || "bar" === (null === (l = e.w.config.series) || void 0 ===
                        l || null === (c = l[n]) || void 0 === c ? void 0 : c.type) || "column" ===
                      (null === (d = e.w.config.series) || void 0 === d || null === (g = d[n]) ||
                        void 0 === g ? void 0 : g.type))) && null !== t.series[n][o] && P.isNumber(t
                    .series[n][o]) && (t.series[n][o] > 0 ? a[r][o] += parseFloat(t.series[n][o]) +
                    1e-4 : s[r][o] += parseFloat(t.series[n][o]))
                }
              })
            }), Object.entries(a).forEach(function(r) {
              var n = Be(r, 1)[0];
              a[n].forEach(function(o, l) {
                t.maxY = Math.max(t.maxY, a[n][l]), t.minY = Math.min(t.minY, s[n][l])
              })
            })
          }
        }
      }]), w
    }(),
    Ye = function() {
      function w(e, t) {
        F(this, w), this.ctx = e, this.elgrid = t, this.w = e.w;
        var i = this.w;
        this.xaxisFontSize = i.config.xaxis.labels.style.fontSize, this.axisFontFamily = i.config.xaxis.labels.style
          .fontFamily, this.xaxisForeColors = i.config.xaxis.labels.style.colors, this.isCategoryBarHorizontal =
          "bar" === i.config.chart.type && i.config.plotOptions.bar.horizontal, this.xAxisoffX = 0, "bottom" === i
          .config.xaxis.position && (this.xAxisoffX = i.globals.gridHeight), this.drawnLabels = [], this.axesUtils =
          new ce(e)
      }
      return R(w, [{
        key: "drawYaxis",
        value: function(e) {
          var t = this,
            i = this.w,
            a = new X(this.ctx),
            s = i.config.yaxis[e].labels.style,
            r = s.fontSize,
            n = s.fontFamily,
            o = s.fontWeight,
            l = a.group({
              class: "apexcharts-yaxis",
              rel: e,
              transform: "translate(" + i.globals.translateYAxisX[e] + ", 0)"
            });
          if (this.axesUtils.isYAxisHidden(e)) return l;
          var c = a.group({
            class: "apexcharts-yaxis-texts-g"
          });
          l.add(c);
          var d = i.globals.yAxisScale[e].result.length - 1,
            g = i.globals.gridHeight / d,
            p = i.globals.yLabelFormatters[e],
            f = i.globals.yAxisScale[e].result.slice();
          f = this.axesUtils.checkForReversedLabels(e, f);
          var x = "";
          if (i.config.yaxis[e].labels.show) {
            var m = i.globals.translateY + i.config.yaxis[e].labels.offsetY;
            i.globals.isBarHorizontal ? m = 0 : "heatmap" === i.config.chart.type && (m -= g / 2), m +=
              parseInt(i.config.yaxis[e].labels.style.fontSize, 10) / 3;
            for (var v = function(C) {
                var L = f[C];
                L = p(L, C, i);
                var M = i.config.yaxis[e].labels.padding;
                i.config.yaxis[e].opposite && 0 !== i.config.yaxis.length && (M *= -1);
                var z = "end";
                i.config.yaxis[e].opposite && (z = "start"), "left" === i.config.yaxis[e].labels.align ? z =
                  "start" : "center" === i.config.yaxis[e].labels.align ? z = "middle" : "right" === i
                  .config.yaxis[e].labels.align && (z = "end");
                var I = t.axesUtils.getYAxisForeColor(s.colors, e),
                  T = a.drawText({
                    x: M,
                    y: m,
                    text: L,
                    textAnchor: z,
                    fontSize: r,
                    fontFamily: n,
                    fontWeight: o,
                    maxWidth: i.config.yaxis[e].labels.maxWidth,
                    foreColor: Array.isArray(I) ? I[C] : I,
                    isPlainText: !1,
                    cssClass: "apexcharts-yaxis-label " + s.cssClass
                  });
                C === d && (x = T), c.add(T);
                var E = document.createElementNS(i.globals.SVGNS, "title");
                if (E.textContent = Array.isArray(L) ? L.join(" ") : L, T.node.appendChild(E), 0 !== i
                  .config.yaxis[e].labels.rotate) {
                  var H = a.rotateAroundCenter(x.node),
                    D = a.rotateAroundCenter(T.node);
                  T.node.setAttribute("transform", "rotate(".concat(i.config.yaxis[e].labels.rotate, " ")
                    .concat(H.x, " ").concat(D.y, ")"))
                }
                m += g
              }, y = d; y >= 0; y--) v(y)
          }
          if (void 0 !== i.config.yaxis[e].title.text) {
            var h = a.group({
                class: "apexcharts-yaxis-title"
              }),
              u = 0;
            i.config.yaxis[e].opposite && (u = i.globals.translateYAxisX[e]);
            var b = a.drawText({
              x: u,
              y: i.globals.gridHeight / 2 + i.globals.translateY + i.config.yaxis[e].title.offsetY,
              text: i.config.yaxis[e].title.text,
              textAnchor: "end",
              foreColor: i.config.yaxis[e].title.style.color,
              fontSize: i.config.yaxis[e].title.style.fontSize,
              fontWeight: i.config.yaxis[e].title.style.fontWeight,
              fontFamily: i.config.yaxis[e].title.style.fontFamily,
              cssClass: "apexcharts-yaxis-title-text " + i.config.yaxis[e].title.style.cssClass
            });
            h.add(b), l.add(h)
          }
          var k = i.config.yaxis[e].axisBorder,
            A = 31 + k.offsetX;
          if (i.config.yaxis[e].opposite && (A = -31 - k.offsetX), k.show) {
            var S = a.drawLine(A, i.globals.translateY + k.offsetY - 2, A, i.globals.gridHeight + i.globals
              .translateY + k.offsetY + 2, k.color, 0, k.width);
            l.add(S)
          }
          return i.config.yaxis[e].axisTicks.show && this.axesUtils.drawYAxisTicks(A, d, k, i.config.yaxis[e]
            .axisTicks, e, g, l), l
        }
      }, {
        key: "drawYaxisInversed",
        value: function(e) {
          var t = this.w,
            i = new X(this.ctx),
            a = i.group({
              class: "apexcharts-xaxis apexcharts-yaxis-inversed"
            }),
            s = i.group({
              class: "apexcharts-xaxis-texts-g",
              transform: "translate(".concat(t.globals.translateXAxisX, ", ").concat(t.globals
                .translateXAxisY, ")")
            });
          a.add(s);
          var r = t.globals.yAxisScale[e].result.length - 1,
            n = t.globals.gridWidth / r + .1,
            o = n + t.config.xaxis.labels.offsetX,
            l = t.globals.xLabelFormatter,
            c = t.globals.yAxisScale[e].result.slice(),
            d = t.globals.timescaleLabels;
          d.length > 0 && (this.xaxisLabels = d.slice(), r = (c = d.slice()).length), c = this.axesUtils
            .checkForReversedLabels(e, c);
          var g = d.length;
          if (t.config.xaxis.labels.show)
            for (var p = g ? 0 : r; g ? p < g : p >= 0; g ? p++ : p--) {
              var f = c[p];
              f = l(f, p, t);
              var x = t.globals.gridWidth + t.globals.padHorizontal - (o - n + t.config.xaxis.labels.offsetX);
              if (d.length) {
                var m = this.axesUtils.getLabel(c, d, x, p, this.drawnLabels, this.xaxisFontSize);
                x = m.x, f = m.text, this.drawnLabels.push(m.text), 0 === p && t.globals
                  .skipFirstTimelinelabel && (f = ""), p === c.length - 1 && t.globals
                  .skipLastTimelinelabel && (f = "")
              }
              var v = i.drawText({
                x,
                y: this.xAxisoffX + t.config.xaxis.labels.offsetY + 30 - ("top" === t.config.xaxis
                  .position ? t.globals.xAxisHeight + t.config.xaxis.axisTicks.height - 2 : 0),
                text: f,
                textAnchor: "middle",
                foreColor: Array.isArray(this.xaxisForeColors) ? this.xaxisForeColors[e] : this
                  .xaxisForeColors,
                fontSize: this.xaxisFontSize,
                fontFamily: this.xaxisFontFamily,
                fontWeight: t.config.xaxis.labels.style.fontWeight,
                isPlainText: !1,
                cssClass: "apexcharts-xaxis-label " + t.config.xaxis.labels.style.cssClass
              });
              s.add(v), v.tspan(f);
              var y = document.createElementNS(t.globals.SVGNS, "title");
              y.textContent = f, v.node.appendChild(y), o += n
            }
          return this.inversedYAxisTitleText(a), this.inversedYAxisBorder(a), a
        }
      }, {
        key: "inversedYAxisBorder",
        value: function(e) {
          var t = this.w,
            i = new X(this.ctx),
            a = t.config.xaxis.axisBorder;
          if (a.show) {
            var s = 0;
            "bar" === t.config.chart.type && t.globals.isXNumeric && (s -= 15);
            var r = i.drawLine(t.globals.padHorizontal + s + a.offsetX, this.xAxisoffX, t.globals.gridWidth,
              this.xAxisoffX, a.color, 0, a.height);
            this.elgrid && this.elgrid.elGridBorders && t.config.grid.show ? this.elgrid.elGridBorders.add(
              r) : e.add(r)
          }
        }
      }, {
        key: "inversedYAxisTitleText",
        value: function(e) {
          var t = this.w,
            i = new X(this.ctx);
          if (void 0 !== t.config.xaxis.title.text) {
            var a = i.group({
                class: "apexcharts-xaxis-title apexcharts-yaxis-title-inversed"
              }),
              s = i.drawText({
                x: t.globals.gridWidth / 2 + t.config.xaxis.title.offsetX,
                y: this.xAxisoffX + parseFloat(this.xaxisFontSize) + parseFloat(t.config.xaxis.title.style
                  .fontSize) + t.config.xaxis.title.offsetY + 20,
                text: t.config.xaxis.title.text,
                textAnchor: "middle",
                fontSize: t.config.xaxis.title.style.fontSize,
                fontFamily: t.config.xaxis.title.style.fontFamily,
                fontWeight: t.config.xaxis.title.style.fontWeight,
                foreColor: t.config.xaxis.title.style.color,
                cssClass: "apexcharts-xaxis-title-text " + t.config.xaxis.title.style.cssClass
              });
            a.add(s), e.add(a)
          }
        }
      }, {
        key: "yAxisTitleRotate",
        value: function(e, t) {
          var i = this.w,
            a = new X(this.ctx),
            s = {
              width: 0,
              height: 0
            },
            r = {
              width: 0,
              height: 0
            },
            n = i.globals.dom.baseEl.querySelector(" .apexcharts-yaxis[rel='".concat(e,
              "'] .apexcharts-yaxis-texts-g"));
          null !== n && (s = n.getBoundingClientRect());
          var o = i.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(e,
            "'] .apexcharts-yaxis-title text"));
          if (null !== o && (r = o.getBoundingClientRect()), null !== o) {
            var l = this.xPaddingForYAxisTitle(e, s, r, t);
            o.setAttribute("x", l.xPos - (t ? 10 : 0))
          }
          if (null !== o) {
            var c = a.rotateAroundCenter(o);
            o.setAttribute("transform", "rotate(".concat(t ? -1 * i.config.yaxis[e].title.rotate : i.config
              .yaxis[e].title.rotate, " ").concat(c.x, " ").concat(c.y, ")"))
          }
        }
      }, {
        key: "xPaddingForYAxisTitle",
        value: function(e, t, i, a) {
          var s = this.w,
            r = 0,
            n = 0,
            o = 10;
          return void 0 === s.config.yaxis[e].title.text || e < 0 ? {
            xPos: n,
            padd: 0
          } : (a ? (n = t.width + s.config.yaxis[e].title.offsetX + i.width / 2 + o / 2, 0 === (r += 1) && (
            n -= o / 2)) : (n = -1 * t.width + s.config.yaxis[e].title.offsetX + o / 2 + i.width / 2, s
            .globals.isBarHorizontal && (n = -1 * t.width - s.config.yaxis[e].title.offsetX - (o = 25))
            ), {
            xPos: n,
            padd: o
          })
        }
      }, {
        key: "setYAxisXPosition",
        value: function(e, t) {
          var i = this.w,
            a = 0,
            s = 0,
            r = 18,
            n = 1;
          i.config.yaxis.length > 1 && (this.multipleYs = !0), i.config.yaxis.map(function(o, l) {
            var c = i.globals.ignoreYAxisIndexes.indexOf(l) > -1 || !o.show || o.floating || 0 === e[l]
              .width,
              d = e[l].width + t[l].width;
            o.opposite ? i.globals.isBarHorizontal ? i.globals.translateYAxisX[l] = (s = i.globals
              .gridWidth + i.globals.translateX - 1) - o.labels.offsetX : (s = i.globals.gridWidth + i
              .globals.translateX + n, c || (n = n + d + 20), i.globals.translateYAxisX[l] = s - o
              .labels.offsetX + 20) : (a = i.globals.translateX - r, c || (r = r + d + 20), i.globals
              .translateYAxisX[l] = a + o.labels.offsetX)
          })
        }
      }, {
        key: "setYAxisTextAlignments",
        value: function() {
          var e = this.w,
            t = e.globals.dom.baseEl.getElementsByClassName("apexcharts-yaxis");
          (t = P.listToArray(t)).forEach(function(i, a) {
            var s = e.config.yaxis[a];
            if (s && !s.floating && void 0 !== s.labels.align) {
              var r = e.globals.dom.baseEl.querySelector(".apexcharts-yaxis[rel='".concat(a,
                  "'] .apexcharts-yaxis-texts-g")),
                n = e.globals.dom.baseEl.querySelectorAll(".apexcharts-yaxis[rel='".concat(a,
                  "'] .apexcharts-yaxis-label"));
              n = P.listToArray(n);
              var o = r.getBoundingClientRect();
              "left" === s.labels.align ? (n.forEach(function(l, c) {
                  l.setAttribute("text-anchor", "start")
                }), s.opposite || r.setAttribute("transform", "translate(-".concat(o.width, ", 0)"))) :
                "center" === s.labels.align ? (n.forEach(function(l, c) {
                  l.setAttribute("text-anchor", "middle")
                }), r.setAttribute("transform", "translate(".concat(o.width / 2 * (s.opposite ? 1 : -1),
                  ", 0)"))) : "right" === s.labels.align && (n.forEach(function(l, c) {
                  l.setAttribute("text-anchor", "end")
                }), s.opposite && r.setAttribute("transform", "translate(".concat(o.width, ", 0)")))
            }
          })
        }
      }]), w
    }(),
    gt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.documentEvent = P.bind(this.documentEvent, this)
      }
      return R(w, [{
        key: "addEventListener",
        value: function(e, t) {
          var i = this.w;
          i.globals.events.hasOwnProperty(e) ? i.globals.events[e].push(t) : i.globals.events[e] = [t]
        }
      }, {
        key: "removeEventListener",
        value: function(e, t) {
          var i = this.w;
          if (i.globals.events.hasOwnProperty(e)) {
            var a = i.globals.events[e].indexOf(t); - 1 !== a && i.globals.events[e].splice(a, 1)
          }
        }
      }, {
        key: "fireEvent",
        value: function(e, t) {
          var i = this.w;
          if (i.globals.events.hasOwnProperty(e)) {
            t && t.length || (t = []);
            for (var a = i.globals.events[e], s = a.length, r = 0; r < s; r++) a[r].apply(null, t)
          }
        }
      }, {
        key: "setupEventHandlers",
        value: function() {
          var e = this,
            t = this.w,
            i = this.ctx,
            a = t.globals.dom.baseEl.querySelector(t.globals.chartClass);
          this.ctx.eventList.forEach(function(s) {
            a.addEventListener(s, function(r) {
              var n = Object.assign({}, t, {
                seriesIndex: t.globals.axisCharts ? t.globals.capturedSeriesIndex : 0,
                dataPointIndex: t.globals.capturedDataPointIndex
              });
              "mousemove" === r.type || "touchmove" === r.type ? "function" == typeof t.config.chart
                .events.mouseMove && t.config.chart.events.mouseMove(r, i, n) : "mouseleave" === r
                .type || "touchleave" === r.type ? "function" == typeof t.config.chart.events
                .mouseLeave && t.config.chart.events.mouseLeave(r, i, n) : ("mouseup" === r.type &&
                  1 === r.which || "touchend" === r.type) && ("function" == typeof t.config.chart
                  .events.click && t.config.chart.events.click(r, i, n), i.ctx.events.fireEvent(
                    "click", [r, i, n]))
            }, {
              capture: !1,
              passive: !0
            })
          }), this.ctx.eventList.forEach(function(s) {
            t.globals.dom.baseEl.addEventListener(s, e.documentEvent, {
              passive: !0
            })
          }), this.ctx.core.setupBrushHandler()
        }
      }, {
        key: "documentEvent",
        value: function(e) {
          var t = this.w,
            i = e.target.className;
          if ("click" === e.type) {
            var a = t.globals.dom.baseEl.querySelector(".apexcharts-menu");
            a && a.classList.contains("apexcharts-menu-open") && "apexcharts-menu-icon" !== i && a.classList
              .remove("apexcharts-menu-open")
          }
          t.globals.clientX = "touchmove" === e.type ? e.touches[0].clientX : e.clientX, t.globals.clientY =
            "touchmove" === e.type ? e.touches[0].clientY : e.clientY
        }
      }]), w
    }(),
    ut = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "setCurrentLocaleValues",
        value: function(e) {
          var t = this.w.config.chart.locales;
          window.Apex.chart && window.Apex.chart.locales && window.Apex.chart.locales.length > 0 && (t = this
            .w.config.chart.locales.concat(window.Apex.chart.locales));
          var i = t.filter(function(s) {
            return s.name === e
          })[0];
          if (!i) throw new Error(
            "Wrong locale name provided. Please make sure you set the correct locale name in options");
          var a = P.extend(Ve, i);
          this.w.globals.locale = a.options
        }
      }]), w
    }(),
    pt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "drawAxis",
        value: function(e, t) {
          var i, a, s = this,
            r = this.w.globals,
            n = this.w.config,
            o = new ke(this.ctx, t),
            l = new Ye(this.ctx, t);
          r.axisCharts && "radar" !== e && (r.isBarHorizontal ? (a = l.drawYaxisInversed(0), i = o
            .drawXaxisInversed(0), r.dom.elGraphical.add(i), r.dom.elGraphical.add(a)) : (i = o
          .drawXaxis(), r.dom.elGraphical.add(i), n.yaxis.map(function(c, d) {
            if (-1 === r.ignoreYAxisIndexes.indexOf(d) && (a = l.drawYaxis(d), r.dom.Paper.add(a),
                "back" === s.w.config.grid.position)) {
              var g = r.dom.Paper.children()[1];
              g.remove(), r.dom.Paper.add(g)
            }
          })))
        }
      }]), w
    }(),
    Fe = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "drawXCrosshairs",
        value: function() {
          var e = this.w,
            t = new X(this.ctx),
            i = new K(this.ctx),
            a = e.config.xaxis.crosshairs.fill.gradient,
            s = e.config.xaxis.crosshairs.dropShadow,
            g = s.enabled,
            p = s.left,
            f = s.top,
            x = s.blur,
            m = s.color,
            v = s.opacity,
            y = e.config.xaxis.crosshairs.fill.color;
          if (e.config.xaxis.crosshairs.show) {
            "gradient" === e.config.xaxis.crosshairs.fill.type && (y = t.drawGradient("vertical", a.colorFrom,
              a.colorTo, a.opacityFrom, a.opacityTo, null, a.stops, null));
            var h = t.drawRect();
            1 === e.config.xaxis.crosshairs.width && (h = t.drawLine());
            var u = e.globals.gridHeight;
            (!P.isNumber(u) || u < 0) && (u = 0);
            var b = e.config.xaxis.crosshairs.width;
            (!P.isNumber(b) || b < 0) && (b = 0), h.attr({
              class: "apexcharts-xcrosshairs",
              x: 0,
              y: 0,
              y2: u,
              width: b,
              height: u,
              fill: y,
              filter: "none",
              "fill-opacity": e.config.xaxis.crosshairs.opacity,
              stroke: e.config.xaxis.crosshairs.stroke.color,
              "stroke-width": e.config.xaxis.crosshairs.stroke.width,
              "stroke-dasharray": e.config.xaxis.crosshairs.stroke.dashArray
            }), g && (h = i.dropShadow(h, {
              left: p,
              top: f,
              blur: x,
              color: m,
              opacity: v
            })), e.globals.dom.elGraphical.add(h)
          }
        }
      }, {
        key: "drawYCrosshairs",
        value: function() {
          var e = this.w,
            t = new X(this.ctx),
            i = e.config.yaxis[0].crosshairs,
            a = e.globals.barPadForNumericAxis;
          if (e.config.yaxis[0].crosshairs.show) {
            var s = t.drawLine(-a, 0, e.globals.gridWidth + a, 0, i.stroke.color, i.stroke.dashArray, i.stroke
              .width);
            s.attr({
              class: "apexcharts-ycrosshairs"
            }), e.globals.dom.elGraphical.add(s)
          }
          var r = t.drawLine(-a, 0, e.globals.gridWidth + a, 0, i.stroke.color, 0, 0);
          r.attr({
            class: "apexcharts-ycrosshairs-hidden"
          }), e.globals.dom.elGraphical.add(r)
        }
      }]), w
    }(),
    ft = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "checkResponsiveConfig",
        value: function(e) {
          var t = this,
            i = this.w,
            a = i.config;
          if (0 !== a.responsive.length) {
            var s = a.responsive.slice();
            s.sort(function(l, c) {
              return l.breakpoint > c.breakpoint ? 1 : c.breakpoint > l.breakpoint ? -1 : 0
            }).reverse();
            var r = new ye({}),
              n = function() {
                var l = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                  d = window.innerWidth > 0 ? window.innerWidth : screen.width;
                if (d > s[0].breakpoint) {
                  var g = P.clone(i.globals.initialConfig);
                  g.series = P.clone(i.config.series);
                  var p = q.extendArrayProps(r, g, i);
                  l = P.extend(p, l), l = P.extend(i.config, l), t.overrideResponsiveOptions(l)
                } else
                  for (var f = 0; f < s.length; f++)
                    if (d < s[f].breakpoint) {
                      var x = q.extendArrayProps(r, s[f].options, i);
                      l = P.extend(x, l), l = P.extend(i.config, l), t.overrideResponsiveOptions(l)
                    }
              };
            if (e) {
              var o = q.extendArrayProps(r, e, i);
              o = P.extend(i.config, o), n(o = P.extend(o, e))
            } else n({})
          }
        }
      }, {
        key: "overrideResponsiveOptions",
        value: function(e) {
          var t = new ye(e).init({
            responsiveOverride: !0
          });
          this.w.config = t
        }
      }]), w
    }(),
    xt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.colors = [], this.w = e.w;
        var t = this.w;
        this.isColorFn = !1, this.isHeatmapDistributed = "treemap" === t.config.chart.type && t.config.plotOptions
          .treemap.distributed || "heatmap" === t.config.chart.type && t.config.plotOptions.heatmap.distributed, this
          .isBarDistributed = t.config.plotOptions.bar.distributed && ("bar" === t.config.chart.type || "rangeBar" ===
            t.config.chart.type)
      }
      return R(w, [{
        key: "init",
        value: function() {
          this.setDefaultColors()
        }
      }, {
        key: "setDefaultColors",
        value: function() {
          var e, t = this,
            i = this.w,
            a = new P;
          if (i.globals.dom.elWrap.classList.add("apexcharts-theme-".concat(i.config.theme.mode)), void 0 ===
            i.config.colors || 0 === (null === (e = i.config.colors) || void 0 === e ? void 0 : e.length) ? i
            .globals.colors = this.predefined() : (i.globals.colors = i.config.colors, Array.isArray(i.config
              .colors) && i.config.colors.length > 0 && "function" == typeof i.config.colors[0] && (i
              .globals.colors = i.config.series.map(function(f, x) {
                var m = i.config.colors[x];
                return m || (m = i.config.colors[0]), "function" == typeof m ? (t.isColorFn = !0, m({
                  value: i.globals.axisCharts ? i.globals.series[x][0] ? i.globals.series[x][0] :
                    0 : i.globals.series[x],
                  seriesIndex: x,
                  dataPointIndex: x,
                  w: i
                })) : m
              }))), i.globals.seriesColors.map(function(f, x) {
              f && (i.globals.colors[x] = f)
            }), i.config.theme.monochrome.enabled) {
            var s = [],
              r = i.globals.series.length;
            (this.isBarDistributed || this.isHeatmapDistributed) && (r = i.globals.series[0].length * i
              .globals.series.length);
            for (var n = i.config.theme.monochrome.color, o = 1 / (r / i.config.theme.monochrome
                .shadeIntensity), l = i.config.theme.monochrome.shadeTo, c = 0, d = 0; d < r; d++) {
              var g = void 0;
              "dark" === l ? (g = a.shadeColor(-1 * c, n), c += o) : (g = a.shadeColor(c, n), c += o), s.push(
                g)
            }
            i.globals.colors = s.slice()
          }
          var p = i.globals.colors.slice();
          this.pushExtraColors(i.globals.colors), ["fill", "stroke"].forEach(function(f) {
              i.globals[f].colors = void 0 === i.config[f].colors ? t.isColorFn ? i.config.colors : p : i
                .config[f].colors.slice(), t.pushExtraColors(i.globals[f].colors)
            }), i.globals.dataLabels.style.colors = void 0 === i.config.dataLabels.style.colors ? p : i.config
            .dataLabels.style.colors.slice(), this.pushExtraColors(i.globals.dataLabels.style.colors, 50), i
            .globals.radarPolygons.fill.colors = void 0 === i.config.plotOptions.radar.polygons.fill.colors ?
            ["dark" === i.config.theme.mode ? "#424242" : "none"] : i.config.plotOptions.radar.polygons.fill
            .colors.slice(), this.pushExtraColors(i.globals.radarPolygons.fill.colors, 20), i.globals.markers
            .colors = void 0 === i.config.markers.colors ? p : i.config.markers.colors.slice(), this
            .pushExtraColors(i.globals.markers.colors)
        }
      }, {
        key: "pushExtraColors",
        value: function(e, t) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
            a = this.w,
            s = t || a.globals.series.length;
          if (null === i && (i = this.isBarDistributed || this.isHeatmapDistributed || "heatmap" === a.config
              .chart.type && a.config.plotOptions.heatmap.colorScale.inverse), i && a.globals.series.length &&
            (s = a.globals.series[a.globals.maxValsInArrayIndex].length * a.globals.series.length), e.length <
            s)
            for (var r = s - e.length, n = 0; n < r; n++) e.push(e[n])
        }
      }, {
        key: "updateThemeOptions",
        value: function(e) {
          e.chart = e.chart || {}, e.tooltip = e.tooltip || {};
          var t = e.theme.mode || "light",
            i = e.theme.palette ? e.theme.palette : "dark" === t ? "palette4" : "palette1",
            a = e.chart.foreColor ? e.chart.foreColor : "dark" === t ? "#f6f7f8" : "#373d3f";
          return e.tooltip.theme = t, e.chart.foreColor = a, e.theme.palette = i, e
        }
      }, {
        key: "predefined",
        value: function() {
          switch (this.w.config.theme.palette) {
            case "palette1":
            default:
              this.colors = ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0"];
              break;
            case "palette2":
              this.colors = ["#3f51b5", "#03a9f4", "#4caf50", "#f9ce1d", "#FF9800"];
              break;
            case "palette3":
              this.colors = ["#33b2df", "#546E7A", "#d4526e", "#13d8aa", "#A5978B"];
              break;
            case "palette4":
              this.colors = ["#4ecdc4", "#c7f464", "#81D4FA", "#fd6a6a", "#546E7A"];
              break;
            case "palette5":
              this.colors = ["#2b908f", "#f9a3a4", "#90ee7e", "#fa4443", "#69d2e7"];
              break;
            case "palette6":
              this.colors = ["#449DD1", "#F86624", "#EA3546", "#662E9B", "#C5D86D"];
              break;
            case "palette7":
              this.colors = ["#D7263D", "#1B998B", "#2E294E", "#F46036", "#E2C044"];
              break;
            case "palette8":
              this.colors = ["#662E9B", "#F86624", "#F9C80E", "#EA3546", "#43BCCD"];
              break;
            case "palette9":
              this.colors = ["#5C4742", "#A5978B", "#8D5B4C", "#5A2A27", "#C4BBAF"];
              break;
            case "palette10":
              this.colors = ["#A300D6", "#7D02EB", "#5653FE", "#2983FF", "#00B1F2"]
          }
          return this.colors
        }
      }]), w
    }(),
    bt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "draw",
        value: function() {
          this.drawTitleSubtitle("title"), this.drawTitleSubtitle("subtitle")
        }
      }, {
        key: "drawTitleSubtitle",
        value: function(e) {
          var t = this.w,
            i = "title" === e ? t.config.title : t.config.subtitle,
            a = t.globals.svgWidth / 2,
            s = i.offsetY,
            r = "middle";
          if ("left" === i.align ? (a = 10, r = "start") : "right" === i.align && (a = t.globals.svgWidth -
              10, r = "end"), a += i.offsetX, s = s + parseInt(i.style.fontSize, 10) + i.margin / 2,
            void 0 !== i.text) {
            var n = new X(this.ctx).drawText({
              x: a,
              y: s,
              text: i.text,
              textAnchor: r,
              fontSize: i.style.fontSize,
              fontFamily: i.style.fontFamily,
              fontWeight: i.style.fontWeight,
              foreColor: i.style.color,
              opacity: 1
            });
            n.node.setAttribute("class", "apexcharts-".concat(e, "-text")), t.globals.dom.Paper.add(n)
          }
        }
      }]), w
    }(),
    mt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.dCtx = e
      }
      return R(w, [{
        key: "getTitleSubtitleCoords",
        value: function(e) {
          var t = this.w,
            i = 0,
            a = 0,
            s = "title" === e ? t.config.title.floating : t.config.subtitle.floating,
            r = t.globals.dom.baseEl.querySelector(".apexcharts-".concat(e, "-text"));
          if (null !== r && !s) {
            var n = r.getBoundingClientRect();
            i = n.width, a = t.globals.axisCharts ? n.height + 5 : n.height
          }
          return {
            width: i,
            height: a
          }
        }
      }, {
        key: "getLegendsRect",
        value: function() {
          var e = this.w,
            t = e.globals.dom.elLegendWrap;
          e.config.legend.height || "top" !== e.config.legend.position && "bottom" !== e.config.legend
            .position || (t.style.maxHeight = e.globals.svgHeight / 2 + "px");
          var i = Object.assign({}, P.getBoundingClientRect(t));
          return this.dCtx.lgRect = null !== t && !e.config.legend.floating && e.config.legend.show ? {
              x: i.x,
              y: i.y,
              height: i.height,
              width: 0 === i.height ? 0 : i.width
            } : {
              x: 0,
              y: 0,
              height: 0,
              width: 0
            }, "left" !== e.config.legend.position && "right" !== e.config.legend.position || 1.5 * this.dCtx
            .lgRect.width > e.globals.svgWidth && (this.dCtx.lgRect.width = e.globals.svgWidth / 1.5), this
            .dCtx.lgRect
        }
      }, {
        key: "getDatalabelsRect",
        value: function() {
          var e = this,
            t = this.w,
            i = [];
          t.config.series.forEach(function(o, l) {
            o.data.forEach(function(c, d) {
              a = t.config.dataLabels.formatter(t.globals.series[l][d], {
                ctx: e.dCtx.ctx,
                seriesIndex: l,
                dataPointIndex: d,
                w: t
              }), i.push(a)
            })
          });
          var a = P.getLargestStringFromArr(i),
            s = new X(this.dCtx.ctx),
            r = t.config.dataLabels.style,
            n = s.getTextRects(a, parseInt(r.fontSize), r.fontFamily);
          return {
            width: 1.05 * n.width,
            height: n.height
          }
        }
      }, {
        key: "getLargestStringFromMultiArr",
        value: function(e, t) {
          var i = e;
          if (this.w.globals.isMultiLineX) {
            var a = t.map(function(r, n) {
                return Array.isArray(r) ? r.length : 1
              }),
              s = Math.max.apply(Math, J(a));
            i = t[a.indexOf(s)]
          }
          return i
        }
      }]), w
    }(),
    vt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.dCtx = e
      }
      return R(w, [{
        key: "getxAxisLabelsCoords",
        value: function() {
          var e, t = this.w,
            i = t.globals.labels.slice();
          if (t.config.xaxis.convertedCatToNumeric && 0 === i.length && (i = t.globals.categoryLabels), t
            .globals.timescaleLabels.length > 0) {
            var a = this.getxAxisTimeScaleLabelsCoords();
            e = {
              width: a.width,
              height: a.height
            }, t.globals.rotateXLabels = !1
          } else {
            this.dCtx.lgWidthForSideLegends = "left" !== t.config.legend.position && "right" !== t.config
              .legend.position || t.config.legend.floating ? 0 : this.dCtx.lgRect.width;
            var s = t.globals.xLabelFormatter,
              r = P.getLargestStringFromArr(i),
              n = this.dCtx.dimHelpers.getLargestStringFromMultiArr(r, i);
            t.globals.isBarHorizontal && (n = r = t.globals.yAxisScale[0].result.reduce(function(f, x) {
              return f.length > x.length ? f : x
            }, 0));
            var o = new me(this.dCtx.ctx),
              l = r;
            r = o.xLabelFormat(s, r, l, {
              i: void 0,
              dateFormatter: new Q(this.dCtx.ctx).formatDate,
              w: t
            }), n = o.xLabelFormat(s, n, l, {
              i: void 0,
              dateFormatter: new Q(this.dCtx.ctx).formatDate,
              w: t
            }), (t.config.xaxis.convertedCatToNumeric && void 0 === r || "" === String(r).trim()) && (n =
              r = "1");
            var c = new X(this.dCtx.ctx),
              d = c.getTextRects(r, t.config.xaxis.labels.style.fontSize),
              g = d;
            if (r !== n && (g = c.getTextRects(n, t.config.xaxis.labels.style.fontSize)), (e = {
                width: d.width >= g.width ? d.width : g.width,
                height: d.height >= g.height ? d.height : g.height
              }).width * i.length > t.globals.svgWidth - this.dCtx.lgWidthForSideLegends - this.dCtx
              .yAxisWidth - this.dCtx.gridPad.left - this.dCtx.gridPad.right && 0 !== t.config.xaxis.labels
              .rotate || t.config.xaxis.labels.rotateAlways) {
              if (!t.globals.isBarHorizontal) {
                t.globals.rotateXLabels = !0;
                var p = function(f) {
                  return c.getTextRects(f, t.config.xaxis.labels.style.fontSize, t.config.xaxis.labels.style
                    .fontFamily, "rotate(".concat(t.config.xaxis.labels.rotate, " 0 0)"), !1)
                };
                d = p(r), r !== n && (g = p(n)), e.height = (d.height > g.height ? d.height : g.height) / 1.5,
                  e.width = d.width > g.width ? d.width : g.width
              }
            } else t.globals.rotateXLabels = !1
          }
          return t.config.xaxis.labels.show || (e = {
            width: 0,
            height: 0
          }), {
            width: e.width,
            height: e.height
          }
        }
      }, {
        key: "getxAxisGroupLabelsCoords",
        value: function() {
          var e, t = this.w;
          if (!t.globals.hasXaxisGroups) return {
            width: 0,
            height: 0
          };
          var i, a = (null === (e = t.config.xaxis.group.style) || void 0 === e ? void 0 : e.fontSize) || t
            .config.xaxis.labels.style.fontSize,
            s = t.globals.groups.map(function(d) {
              return d.title
            }),
            r = P.getLargestStringFromArr(s),
            n = this.dCtx.dimHelpers.getLargestStringFromMultiArr(r, s),
            o = new X(this.dCtx.ctx),
            l = o.getTextRects(r, a),
            c = l;
          return r !== n && (c = o.getTextRects(n, a)), i = {
            width: l.width >= c.width ? l.width : c.width,
            height: l.height >= c.height ? l.height : c.height
          }, t.config.xaxis.labels.show || (i = {
            width: 0,
            height: 0
          }), {
            width: i.width,
            height: i.height
          }
        }
      }, {
        key: "getxAxisTitleCoords",
        value: function() {
          var e = this.w,
            t = 0,
            i = 0;
          if (void 0 !== e.config.xaxis.title.text) {
            var a = new X(this.dCtx.ctx).getTextRects(e.config.xaxis.title.text, e.config.xaxis.title.style
              .fontSize);
            t = a.width, i = a.height
          }
          return {
            width: t,
            height: i
          }
        }
      }, {
        key: "getxAxisTimeScaleLabelsCoords",
        value: function() {
          var e, t = this.w;
          this.dCtx.timescaleLabels = t.globals.timescaleLabels.slice();
          var i = this.dCtx.timescaleLabels.map(function(s) {
              return s.value
            }),
            a = i.reduce(function(s, r) {
              return void 0 === s ? (console.error(
                  "You have possibly supplied invalid Date format. Please supply a valid JavaScript Date"
                  ), 0) : s.length > r.length ? s : r
            }, 0);
          return 1.05 * (e = new X(this.dCtx.ctx).getTextRects(a, t.config.xaxis.labels.style.fontSize))
            .width * i.length > t.globals.gridWidth && 0 !== t.config.xaxis.labels.rotate && (t.globals
              .overlappingXLabels = !0), e
        }
      }, {
        key: "additionalPaddingXLabels",
        value: function(e) {
          var t = this,
            i = this.w,
            a = i.globals,
            s = i.config,
            r = s.xaxis.type,
            n = e.width;
          a.skipLastTimelinelabel = !1, a.skipFirstTimelinelabel = !1;
          var o = i.config.yaxis[0].opposite && i.globals.isBarHorizontal;
          s.yaxis.forEach(function(c, d) {
            o ? (t.dCtx.gridPad.left < n && (t.dCtx.xPadLeft = n / 2 + 1), t.dCtx.xPadRight = n / 2 + 1) :
              function(c, d) {
                s.yaxis.length > 1 && -1 !== a.collapsedSeriesIndices.indexOf(d) || function(g) {
                  if (t.dCtx.timescaleLabels && t.dCtx.timescaleLabels.length) {
                    var x = t.dCtx.timescaleLabels[0].position - n / 1.75 + t.dCtx.yAxisWidthLeft;
                    t.dCtx.timescaleLabels[t.dCtx.timescaleLabels.length - 1].position + n / 1.75 - t
                      .dCtx.yAxisWidthRight > a.svgWidth - a.translateX - ("right" === i.config.legend
                        .position && t.dCtx.lgRect.width > 0 ? t.dCtx.lgRect.width : 0) && (a
                        .skipLastTimelinelabel = !0), x < -(g.show && !g.floating || "bar" !== s.chart
                        .type && "candlestick" !== s.chart.type && "rangeBar" !== s.chart.type &&
                        "boxPlot" !== s.chart.type ? 10 : n / 1.75) && (a.skipFirstTimelinelabel = !0)
                  } else "datetime" === r ? t.dCtx.gridPad.right < n && !a.rotateXLabels && (a
                      .skipLastTimelinelabel = !0) : "datetime" !== r && t.dCtx.gridPad.right < n / 2 -
                    t.dCtx.yAxisWidthRight && !a.rotateXLabels && !i.config.xaxis.labels.trim && (
                      "between" !== i.config.xaxis.tickPlacement || i.globals.isBarHorizontal) && (t
                      .dCtx.xPadRight = n / 2 + 1)
                }(c)
              }(c, d)
          })
        }
      }]), w
    }(),
    yt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.dCtx = e
      }
      return R(w, [{
        key: "getyAxisLabelsCoords",
        value: function() {
          var e = this,
            t = this.w,
            i = [],
            a = 10,
            s = new ce(this.dCtx.ctx);
          return t.config.yaxis.map(function(r, n) {
            var o = {
                seriesIndex: n,
                dataPointIndex: -1,
                w: t
              },
              l = t.globals.yAxisScale[n],
              c = 0;
            if (!s.isYAxisHidden(n) && r.labels.show && void 0 !== r.labels.minWidth && (c = r.labels
                .minWidth), !s.isYAxisHidden(n) && r.labels.show && l.result.length) {
              var d = t.globals.yLabelFormatters[n],
                p = l.result.reduce(function(u, b) {
                  var k, A;
                  return (null === (k = String(d(u, o))) || void 0 === k ? void 0 : k.length) > (
                    null === (A = String(d(b, o))) || void 0 === A ? void 0 : A.length) ? u : b
                }, l.niceMin === Number.MIN_VALUE ? 0 : l.niceMin),
                f = p = d(p, o);
              if (void 0 !== p && 0 !== p.length || (p = l.niceMax), t.globals.isBarHorizontal) {
                a = 0;
                var x = t.globals.labels.slice();
                p = P.getLargestStringFromArr(x), p = d(p, {
                  seriesIndex: n,
                  dataPointIndex: -1,
                  w: t
                }), f = e.dCtx.dimHelpers.getLargestStringFromMultiArr(p, x)
              }
              var m = new X(e.dCtx.ctx),
                v = "rotate(".concat(r.labels.rotate, " 0 0)"),
                y = m.getTextRects(p, r.labels.style.fontSize, r.labels.style.fontFamily, v, !1),
                h = y;
              p !== f && (h = m.getTextRects(f, r.labels.style.fontSize, r.labels.style.fontFamily, v, !
                1)), i.push({
                width: (c > h.width || c > y.width ? c : h.width > y.width ? h.width : y.width) + a,
                height: h.height > y.height ? h.height : y.height
              })
            } else i.push({
              width: 0,
              height: 0
            })
          }), i
        }
      }, {
        key: "getyAxisTitleCoords",
        value: function() {
          var e = this,
            i = [];
          return this.w.config.yaxis.map(function(a, s) {
            if (a.show && void 0 !== a.title.text) {
              var r = new X(e.dCtx.ctx),
                n = "rotate(".concat(a.title.rotate, " 0 0)"),
                o = r.getTextRects(a.title.text, a.title.style.fontSize, a.title.style.fontFamily, n, !1);
              i.push({
                width: o.width,
                height: o.height
              })
            } else i.push({
              width: 0,
              height: 0
            })
          }), i
        }
      }, {
        key: "getTotalYAxisWidth",
        value: function() {
          var e = this.w,
            t = 0,
            i = 0,
            a = 0,
            s = e.globals.yAxisScale.length > 1 ? 10 : 0,
            r = new ce(this.dCtx.ctx),
            n = function(o, l) {
              var c = e.config.yaxis[l].floating,
                d = 0;
              o.width > 0 && !c ? (d = o.width + s, e.globals.ignoreYAxisIndexes.indexOf(l) > -1 && (d = d - o
                  .width - s)) : d = c || r.isYAxisHidden(l) ? 0 : 5, e.config.yaxis[l].opposite ? a += d :
                i += d, t += d
            };
          return e.globals.yLabelsCoords.map(function(o, l) {
              n(o, l)
            }), e.globals.yTitleCoords.map(function(o, l) {
              n(o, l)
            }), e.globals.isBarHorizontal && !e.config.yaxis[0].floating && (t = e.globals.yLabelsCoords[0]
              .width + e.globals.yTitleCoords[0].width + 15), this.dCtx.yAxisWidthLeft = i, this.dCtx
            .yAxisWidthRight = a, t
        }
      }]), w
    }(),
    wt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.dCtx = e
      }
      return R(w, [{
        key: "gridPadForColumnsInNumericAxis",
        value: function(e) {
          var t = this.w,
            i = t.config,
            a = t.globals;
          if (a.noData || a.collapsedSeries.length + a.ancillaryCollapsedSeries.length === i.series.length)
            return 0;
          var s = function(g) {
              return "bar" === g || "rangeBar" === g || "candlestick" === g || "boxPlot" === g
            },
            r = i.chart.type,
            n = 0,
            o = s(r) ? i.series.length : 1;
          if (a.comboBarCount > 0 && (o = a.comboBarCount), a.collapsedSeries.forEach(function(g) {
              s(g.type) && (o -= 1)
            }), i.chart.stacked && (o = 1), (s(r) || a.comboBarCount > 0) && a.isXNumeric && !a
            .isBarHorizontal && o > 0) {
            var l, c, d = Math.abs(a.initialMaxX - a.initialMinX);
            d <= 3 && (d = a.dataPoints), l = d / e, a.minXDiff && a.minXDiff / l > 0 && (c = a.minXDiff / l),
              c > e / 2 && (c /= 2), (n = c * parseInt(i.plotOptions.bar.columnWidth, 10) / 100) < 1 && (n =
                1), a.barPadForNumericAxis = n
          }
          return n
        }
      }, {
        key: "gridPadFortitleSubtitle",
        value: function() {
          var e = this,
            t = this.w,
            i = t.globals,
            a = this.dCtx.isSparkline || !t.globals.axisCharts ? 0 : 10;
          ["title", "subtitle"].forEach(function(n) {
              a += void 0 !== t.config[n].text ? t.config[n].margin : e.dCtx.isSparkline || !t.globals
                .axisCharts ? 0 : 5
            }), !t.config.legend.show || "bottom" !== t.config.legend.position || t.config.legend.floating ||
            t.globals.axisCharts || (a += 10);
          var s = this.dCtx.dimHelpers.getTitleSubtitleCoords("title"),
            r = this.dCtx.dimHelpers.getTitleSubtitleCoords("subtitle");
          i.gridHeight = i.gridHeight - s.height - r.height - a, i.translateY = i.translateY + s.height + r
            .height + a
        }
      }, {
        key: "setGridXPosForDualYAxis",
        value: function(e, t) {
          var i = this.w,
            a = new ce(this.dCtx.ctx);
          i.config.yaxis.map(function(s, r) {
            -1 !== i.globals.ignoreYAxisIndexes.indexOf(r) || s.floating || a.isYAxisHidden(r) || (s
              .opposite && (i.globals.translateX = i.globals.translateX - (t[r].width + e[r].width) -
                parseInt(i.config.yaxis[r].labels.style.fontSize, 10) / 1.2 - 12), i.globals
              .translateX < 2 && (i.globals.translateX = 2))
          })
        }
      }]), w
    }(),
    Me = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.lgRect = {}, this.yAxisWidth = 0, this.yAxisWidthLeft = 0, this
          .yAxisWidthRight = 0, this.xAxisHeight = 0, this.isSparkline = this.w.config.chart.sparkline.enabled, this
          .dimHelpers = new mt(this), this.dimYAxis = new yt(this), this.dimXAxis = new vt(this), this.dimGrid =
          new wt(this), this.lgWidthForSideLegends = 0, this.gridPad = this.w.config.grid.padding, this.xPadRight = 0,
          this.xPadLeft = 0
      }
      return R(w, [{
        key: "plotCoords",
        value: function() {
          var e = this,
            t = this.w,
            i = t.globals;
          this.lgRect = this.dimHelpers.getLegendsRect(), this.datalabelsCoords = {
            width: 0,
            height: 0
          };
          var a = Array.isArray(t.config.stroke.width) ? Math.max.apply(Math, J(t.config.stroke.width)) : t
            .config.stroke.width;
          this.isSparkline && ((t.config.markers.discrete.length > 0 || t.config.markers.size > 0) && Object
              .entries(this.gridPad).forEach(function(r) {
                var n = Be(r, 2);
                e.gridPad[n[0]] = Math.max(n[1], e.w.globals.markers.largestSize / 1.5)
              }), this.gridPad.top = Math.max(a / 2, this.gridPad.top), this.gridPad.bottom = Math.max(a / 2,
                this.gridPad.bottom)), i.axisCharts ? this.setDimensionsForAxisCharts() : this
            .setDimensionsForNonAxisCharts(), this.dimGrid.gridPadFortitleSubtitle(), i.gridHeight = i
            .gridHeight - this.gridPad.top - this.gridPad.bottom, i.gridWidth = i.gridWidth - this.gridPad
            .left - this.gridPad.right - this.xPadRight - this.xPadLeft;
          var s = this.dimGrid.gridPadForColumnsInNumericAxis(i.gridWidth);
          i.gridWidth = i.gridWidth - 2 * s, i.translateX = i.translateX + this.gridPad.left + this.xPadLeft +
            (s > 0 ? s : 0), i.translateY = i.translateY + this.gridPad.top
        }
      }, {
        key: "setDimensionsForAxisCharts",
        value: function() {
          var e = this,
            t = this.w,
            i = t.globals,
            a = this.dimYAxis.getyAxisLabelsCoords(),
            s = this.dimYAxis.getyAxisTitleCoords();
          i.isSlopeChart && (this.datalabelsCoords = this.dimHelpers.getDatalabelsRect()), t.globals
            .yLabelsCoords = [], t.globals.yTitleCoords = [], t.config.yaxis.map(function(p, f) {
              t.globals.yLabelsCoords.push({
                width: a[f].width,
                index: f
              }), t.globals.yTitleCoords.push({
                width: s[f].width,
                index: f
              })
            }), this.yAxisWidth = this.dimYAxis.getTotalYAxisWidth();
          var r = this.dimXAxis.getxAxisLabelsCoords(),
            n = this.dimXAxis.getxAxisGroupLabelsCoords(),
            o = this.dimXAxis.getxAxisTitleCoords();
          this.conditionalChecksForAxisCoords(r, o, n), i.translateXAxisY = t.globals.rotateXLabels ? this
            .xAxisHeight / 8 : -4, i.translateXAxisX = t.globals.rotateXLabels && t.globals.isXNumeric && t
            .config.xaxis.labels.rotate <= -45 ? -this.xAxisWidth / 4 : 0, t.globals.isBarHorizontal && (i
              .rotateXLabels = !1, i.translateXAxisY = parseInt(t.config.xaxis.labels.style.fontSize, 10) /
              1.5 * -1), i.translateXAxisY = i.translateXAxisY + t.config.xaxis.labels.offsetY, i
            .translateXAxisX = i.translateXAxisX + t.config.xaxis.labels.offsetX;
          var l = this.yAxisWidth,
            c = this.xAxisHeight;
          i.xAxisLabelsHeight = this.xAxisHeight - o.height, i.xAxisGroupLabelsHeight = i.xAxisLabelsHeight -
            r.height, i.xAxisLabelsWidth = this.xAxisWidth, i.xAxisHeight = this.xAxisHeight;
          var d = 10;
          ("radar" === t.config.chart.type || this.isSparkline) && (l = 0, c = i.goldenPadding), this
            .isSparkline && (this.lgRect = {
              height: 0,
              width: 0
            }), (this.isSparkline || "treemap" === t.config.chart.type) && (l = 0, c = 0, d = 0), this
            .isSparkline || this.dimXAxis.additionalPaddingXLabels(r);
          var g = function() {
            i.translateX = l + e.datalabelsCoords.width, i.gridHeight = i.svgHeight - e.lgRect.height - c -
              (e.isSparkline || "treemap" === t.config.chart.type ? 0 : t.globals.rotateXLabels ? 10 : 15),
              i.gridWidth = i.svgWidth - l - 2 * e.datalabelsCoords.width
          };
          switch ("top" === t.config.xaxis.position && (d = i.xAxisHeight - t.config.xaxis.axisTicks.height -
              5), t.config.legend.position) {
            case "bottom":
              i.translateY = d, g();
              break;
            case "top":
              i.translateY = this.lgRect.height + d, g();
              break;
            case "left":
              i.translateY = d, i.translateX = this.lgRect.width + l + this.datalabelsCoords.width, i
                .gridHeight = i.svgHeight - c - 12, i.gridWidth = i.svgWidth - this.lgRect.width - l - 2 *
                this.datalabelsCoords.width;
              break;
            case "right":
              i.translateY = d, i.translateX = l + this.datalabelsCoords.width, i.gridHeight = i.svgHeight -
                c - 12, i.gridWidth = i.svgWidth - this.lgRect.width - l - 2 * this.datalabelsCoords.width -
                5;
              break;
            default:
              throw new Error("Legend position not supported")
          }
          this.dimGrid.setGridXPosForDualYAxis(s, a), new Ye(this.ctx).setYAxisXPosition(a, s)
        }
      }, {
        key: "setDimensionsForNonAxisCharts",
        value: function() {
          var e = this.w,
            t = e.globals,
            i = e.config,
            a = 0;
          e.config.legend.show && !e.config.legend.floating && (a = 20);
          var s = "pie" === i.chart.type || "polarArea" === i.chart.type || "donut" === i.chart.type ? "pie" :
            "radialBar",
            r = i.plotOptions[s].offsetY,
            n = i.plotOptions[s].offsetX;
          if (!i.legend.show || i.legend.floating) return t.gridHeight = t.svgHeight - i.grid.padding.left + i
            .grid.padding.right, t.gridWidth = Math.min(t.svgWidth, t.gridHeight), t.translateY = r, void(t
              .translateX = n + (t.svgWidth - t.gridWidth) / 2);
          switch (i.legend.position) {
            case "bottom":
              t.gridHeight = t.svgHeight - this.lgRect.height - t.goldenPadding, t.gridWidth = t.svgWidth, t
                .translateY = r - 10, t.translateX = n + (t.svgWidth - t.gridWidth) / 2;
              break;
            case "top":
              t.gridHeight = t.svgHeight - this.lgRect.height - t.goldenPadding, t.gridWidth = t.svgWidth, t
                .translateY = this.lgRect.height + r + 10, t.translateX = n + (t.svgWidth - t.gridWidth) / 2;
              break;
            case "left":
              t.gridWidth = t.svgWidth - this.lgRect.width - a, t.gridHeight = "auto" !== i.chart.height ? t
                .svgHeight : t.gridWidth, t.translateY = r, t.translateX = n + this.lgRect.width + a;
              break;
            case "right":
              t.gridWidth = t.svgWidth - this.lgRect.width - a - 5, t.gridHeight = "auto" !== i.chart.height ?
                t.svgHeight : t.gridWidth, t.translateY = r, t.translateX = n + 10;
              break;
            default:
              throw new Error("Legend position not supported")
          }
        }
      }, {
        key: "conditionalChecksForAxisCoords",
        value: function(e, t, i) {
          var a = this.w;
          this.xAxisHeight = (i.height + e.height + t.height) * (a.globals.isMultiLineX ? 1.2 : a.globals
              .LINE_HEIGHT_RATIO) + (a.globals.hasXaxisGroups ? 2 : 1) * (a.globals.rotateXLabels ? 22 : 10) +
            (a.globals.rotateXLabels && "bottom" === a.config.legend.position ? 10 : 0), this.xAxisWidth = e
            .width, this.xAxisHeight - t.height > a.config.xaxis.labels.maxHeight && (this.xAxisHeight = a
              .config.xaxis.labels.maxHeight), a.config.xaxis.labels.minHeight && this.xAxisHeight < a.config
            .xaxis.labels.minHeight && (this.xAxisHeight = a.config.xaxis.labels.minHeight), a.config.xaxis
            .floating && (this.xAxisHeight = 0);
          var c = 0,
            d = 0;
          a.config.yaxis.forEach(function(g) {
            c += g.labels.minWidth, d += g.labels.maxWidth
          }), this.yAxisWidth < c && (this.yAxisWidth = c), this.yAxisWidth > d && (this.yAxisWidth = d)
        }
      }]), w
    }(),
    kt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.lgCtx = e
      }
      return R(w, [{
        key: "getLegendStyles",
        value: function() {
          var e, t, i, a = document.createElement("style");
          a.setAttribute("type", "text/css");
          var s = (null === (e = this.lgCtx.ctx) || void 0 === e || null === (t = e.opts) || void 0 === t ||
            null === (i = t.chart) || void 0 === i ? void 0 : i.nonce) || this.w.config.chart.nonce;
          s && a.setAttribute("nonce", s);
          var r = document.createTextNode(
            "\n      .apexcharts-legend {\n        display: flex;\n        overflow: auto;\n        padding: 0 10px;\n      }\n      .apexcharts-legend.apx-legend-position-bottom, .apexcharts-legend.apx-legend-position-top {\n        flex-wrap: wrap\n      }\n      .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {\n        flex-direction: column;\n        bottom: 0;\n      }\n      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left, .apexcharts-legend.apx-legend-position-top.apexcharts-align-left, .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {\n        justify-content: flex-start;\n      }\n      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center, .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {\n        justify-content: center;\n      }\n      .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right, .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {\n        justify-content: flex-end;\n      }\n      .apexcharts-legend-series {\n        cursor: pointer;\n        line-height: normal;\n      }\n      .apexcharts-legend.apx-legend-position-bottom .apexcharts-legend-series, .apexcharts-legend.apx-legend-position-top .apexcharts-legend-series{\n        display: flex;\n        align-items: center;\n      }\n      .apexcharts-legend-text {\n        position: relative;\n        font-size: 14px;\n      }\n      .apexcharts-legend-text *, .apexcharts-legend-marker * {\n        pointer-events: none;\n      }\n      .apexcharts-legend-marker {\n        position: relative;\n        display: inline-block;\n        cursor: pointer;\n        margin-right: 3px;\n        border-style: solid;\n      }\n\n      .apexcharts-legend.apexcharts-align-right .apexcharts-legend-series, .apexcharts-legend.apexcharts-align-left .apexcharts-legend-series{\n        display: inline-block;\n      }\n      .apexcharts-legend-series.apexcharts-no-click {\n        cursor: auto;\n      }\n      .apexcharts-legend .apexcharts-hidden-zero-series, .apexcharts-legend .apexcharts-hidden-null-series {\n        display: none !important;\n      }\n      .apexcharts-inactive-legend {\n        opacity: 0.45;\n      }"
            );
          return a.appendChild(r), a
        }
      }, {
        key: "getLegendBBox",
        value: function() {
          var e = this.w.globals.dom.baseEl.querySelector(".apexcharts-legend").getBoundingClientRect();
          return {
            clwh: e.height,
            clww: e.width
          }
        }
      }, {
        key: "appendToForeignObject",
        value: function() {
          this.w.globals.dom.elLegendForeign.appendChild(this.getLegendStyles())
        }
      }, {
        key: "toggleDataSeries",
        value: function(e, t) {
          var i = this,
            a = this.w;
          if (a.globals.axisCharts || "radialBar" === a.config.chart.type) {
            a.globals.resized = !0;
            var s = null,
              r = null;
            a.globals.risingSeries = [], a.globals.axisCharts ? (s = a.globals.dom.baseEl.querySelector(
              ".apexcharts-series[data\\:realIndex='".concat(e, "']")), r = parseInt(s.getAttribute(
              "data:realIndex"), 10)) : (s = a.globals.dom.baseEl.querySelector(".apexcharts-series[rel='"
              .concat(e + 1, "']")), r = parseInt(s.getAttribute("rel"), 10) - 1), t ? [{
              cs: a.globals.collapsedSeries,
              csi: a.globals.collapsedSeriesIndices
            }, {
              cs: a.globals.ancillaryCollapsedSeries,
              csi: a.globals.ancillaryCollapsedSeriesIndices
            }].forEach(function(c) {
              i.riseCollapsedSeries(c.cs, c.csi, r)
            }) : this.hideSeries({
              seriesEl: s,
              realIndex: r
            })
          } else {
            var n = a.globals.dom.Paper.select(" .apexcharts-series[rel='".concat(e + 1, "'] path")),
              o = a.config.chart.type;
            if ("pie" === o || "polarArea" === o || "donut" === o) {
              var l = a.config.plotOptions.pie.donut.labels;
              new X(this.lgCtx.ctx).pathMouseDown(n.members[0], null), this.lgCtx.ctx.pie
                .printDataLabelsInner(n.members[0].node, l)
            }
            n.fire("click")
          }
        }
      }, {
        key: "hideSeries",
        value: function(e) {
          var t = e.seriesEl,
            i = e.realIndex,
            a = this.w,
            s = a.globals,
            r = P.clone(a.config.series);
          if (s.axisCharts) {
            var n = a.config.yaxis[s.seriesYAxisReverseMap[i]];
            if (n && n.show && n.showAlways) s.ancillaryCollapsedSeriesIndices.indexOf(i) < 0 && (s
              .ancillaryCollapsedSeries.push({
                index: i,
                data: r[i].data.slice(),
                type: t.parentNode.className.baseVal.split("-")[1]
              }), s.ancillaryCollapsedSeriesIndices.push(i));
            else if (s.collapsedSeriesIndices.indexOf(i) < 0) {
              s.collapsedSeries.push({
                index: i,
                data: r[i].data.slice(),
                type: t.parentNode.className.baseVal.split("-")[1]
              }), s.collapsedSeriesIndices.push(i);
              var o = s.risingSeries.indexOf(i);
              s.risingSeries.splice(o, 1)
            }
          } else s.collapsedSeries.push({
            index: i,
            data: r[i]
          }), s.collapsedSeriesIndices.push(i);
          for (var l = t.childNodes, c = 0; c < l.length; c++) l[c].classList.contains(
            "apexcharts-series-markers-wrap") && (l[c].classList.contains("apexcharts-hide") ? l[c]
            .classList.remove("apexcharts-hide") : l[c].classList.add("apexcharts-hide"));
          s.allSeriesCollapsed = s.collapsedSeries.length + s.ancillaryCollapsedSeries.length === a.config
            .series.length, r = this._getSeriesBasedOnCollapsedState(r), this.lgCtx.ctx.updateHelpers
            ._updateSeries(r, a.config.chart.animations.dynamicAnimation.enabled)
        }
      }, {
        key: "riseCollapsedSeries",
        value: function(e, t, i) {
          var a = this.w,
            s = P.clone(a.config.series);
          if (e.length > 0) {
            for (var r = 0; r < e.length; r++) e[r].index === i && (a.globals.axisCharts ? (s[i].data = e[r]
              .data.slice(), e.splice(r, 1), t.splice(r, 1), a.globals.risingSeries.push(i)) : (s[i] = e[
              r].data, e.splice(r, 1), t.splice(r, 1), a.globals.risingSeries.push(i)));
            s = this._getSeriesBasedOnCollapsedState(s), this.lgCtx.ctx.updateHelpers._updateSeries(s, a
              .config.chart.animations.dynamicAnimation.enabled)
          }
        }
      }, {
        key: "_getSeriesBasedOnCollapsedState",
        value: function(e) {
          var t = this.w,
            i = 0;
          return e.forEach(t.globals.axisCharts ? function(a, s) {
            t.globals.collapsedSeriesIndices.indexOf(s) < 0 && t.globals.ancillaryCollapsedSeriesIndices
              .indexOf(s) < 0 || (e[s].data = [], i++)
          } : function(a, s) {
            !t.globals.collapsedSeriesIndices.indexOf(s) < 0 && (e[s] = 0, i++)
          }), t.globals.allSeriesCollapsed = i === e.length, e
        }
      }]), w
    }(),
    $e = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.onLegendClick = this.onLegendClick.bind(this), this
          .onLegendHovered = this.onLegendHovered.bind(this), this.isBarsDistributed = "bar" === this.w.config.chart
          .type && this.w.config.plotOptions.bar.distributed && 1 === this.w.config.series.length, this
          .legendHelpers = new kt(this)
      }
      return R(w, [{
        key: "init",
        value: function() {
          var e = this.w,
            t = e.globals,
            i = e.config;
          if ((i.legend.showForSingleSeries && 1 === t.series.length || this.isBarsDistributed || t.series
              .length > 1 || !t.axisCharts) && i.legend.show) {
            for (; t.dom.elLegendWrap.firstChild;) t.dom.elLegendWrap.removeChild(t.dom.elLegendWrap
              .firstChild);
            this.drawLegends(), P.isIE11() ? document.getElementsByTagName("head")[0].appendChild(this
                .legendHelpers.getLegendStyles()) : this.legendHelpers.appendToForeignObject(), "bottom" === i
              .legend.position || "top" === i.legend.position ? this.legendAlignHorizontal() : "right" !== i
              .legend.position && "left" !== i.legend.position || this.legendAlignVertical()
          }
        }
      }, {
        key: "drawLegends",
        value: function() {
          var e = this,
            t = this.w,
            i = t.config.legend.fontFamily,
            a = t.globals.seriesNames,
            s = t.globals.colors.slice();
          if ("heatmap" === t.config.chart.type) {
            var r = t.config.plotOptions.heatmap.colorScale.ranges;
            a = r.map(function(I) {
              return I.name ? I.name : I.from + " - " + I.to
            }), s = r.map(function(I) {
              return I.color
            })
          } else this.isBarsDistributed && (a = t.globals.labels.slice());
          t.config.legend.customLegendItems.length && (a = t.config.legend.customLegendItems);
          for (var n = t.globals.legendFormatter, o = t.config.legend.inverseOrder, l = o ? a.length - 1 :
            0; o ? l >= 0 : l <= a.length - 1; o ? l-- : l++) {
            var c, d = n(a[l], {
                seriesIndex: l,
                w: t
              }),
              g = !1,
              p = !1;
            if (t.globals.collapsedSeries.length > 0)
              for (var f = 0; f < t.globals.collapsedSeries.length; f++) t.globals.collapsedSeries[f]
                .index === l && (g = !0);
            if (t.globals.ancillaryCollapsedSeriesIndices.length > 0)
              for (var x = 0; x < t.globals.ancillaryCollapsedSeriesIndices.length; x++) t.globals
                .ancillaryCollapsedSeriesIndices[x] === l && (p = !0);
            var m = document.createElement("span");
            m.classList.add("apexcharts-legend-marker");
            var v = t.config.legend.markers.offsetX,
              y = t.config.legend.markers.offsetY,
              h = t.config.legend.markers.height,
              u = t.config.legend.markers.width,
              b = t.config.legend.markers.strokeWidth,
              k = t.config.legend.markers.strokeColor,
              A = t.config.legend.markers.radius,
              S = m.style;
            S.background = s[l], S.color = s[l], S.setProperty("background", s[l], "important"), t.config
              .legend.markers.fillColors && t.config.legend.markers.fillColors[l] && (S.background = t.config
                .legend.markers.fillColors[l]), void 0 !== t.globals.seriesColors[l] && (S.background = t
                .globals.seriesColors[l], S.color = t.globals.seriesColors[l]), S.height = Array.isArray(h) ?
              parseFloat(h[l]) + "px" : parseFloat(h) + "px", S.width = Array.isArray(u) ? parseFloat(u[l]) +
              "px" : parseFloat(u) + "px", S.left = (Array.isArray(v) ? parseFloat(v[l]) : parseFloat(v)) +
              "px", S.top = (Array.isArray(y) ? parseFloat(y[l]) : parseFloat(y)) + "px", S.borderWidth =
              Array.isArray(b) ? b[l] : b, S.borderColor = Array.isArray(k) ? k[l] : k, S.borderRadius = Array
              .isArray(A) ? parseFloat(A[l]) + "px" : parseFloat(A) + "px", t.config.legend.markers
              .customHTML && (Array.isArray(t.config.legend.markers.customHTML) ? t.config.legend.markers
                .customHTML[l] && (m.innerHTML = t.config.legend.markers.customHTML[l]()) : m.innerHTML = t
                .config.legend.markers.customHTML()), X.setAttrs(m, {
                rel: l + 1,
                "data:collapsed": g || p
              }), (g || p) && m.classList.add("apexcharts-inactive-legend");
            var C = document.createElement("div"),
              L = document.createElement("span");
            L.classList.add("apexcharts-legend-text"), L.innerHTML = Array.isArray(d) ? d.join(" ") : d;
            var M = t.config.legend.labels.useSeriesColors ? t.globals.colors[l] : Array.isArray(t.config
                .legend.labels.colors) ? null === (c = t.config.legend.labels.colors) || void 0 === c ?
              void 0 : c[l] : t.config.legend.labels.colors;
            M || (M = t.config.chart.foreColor), L.style.color = M, L.style.fontSize = parseFloat(t.config
                .legend.fontSize) + "px", L.style.fontWeight = t.config.legend.fontWeight, L.style
              .fontFamily = i || t.config.chart.fontFamily, X.setAttrs(L, {
                rel: l + 1,
                i: l,
                "data:default-text": encodeURIComponent(d),
                "data:collapsed": g || p
              }), C.appendChild(m), C.appendChild(L);
            var z = new q(this.ctx);
            t.config.legend.showForZeroSeries || 0 === z.getSeriesTotalByIndex(l) && z.seriesHaveSameValues(
              l) && !z.isSeriesNull(l) && -1 === t.globals.collapsedSeriesIndices.indexOf(l) && -1 === t
              .globals.ancillaryCollapsedSeriesIndices.indexOf(l) && C.classList.add(
                "apexcharts-hidden-zero-series"), t.config.legend.showForNullSeries || z.isSeriesNull(l) && -
              1 === t.globals.collapsedSeriesIndices.indexOf(l) && -1 === t.globals
              .ancillaryCollapsedSeriesIndices.indexOf(l) && C.classList.add("apexcharts-hidden-null-series"),
              t.globals.dom.elLegendWrap.appendChild(C), t.globals.dom.elLegendWrap.classList.add(
                "apexcharts-align-".concat(t.config.legend.horizontalAlign)), t.globals.dom.elLegendWrap
              .classList.add("apx-legend-position-" + t.config.legend.position), C.classList.add(
                "apexcharts-legend-series"), C.style.margin = "".concat(t.config.legend.itemMargin.vertical,
                "px ").concat(t.config.legend.itemMargin.horizontal, "px"), t.globals.dom.elLegendWrap.style
              .width = t.config.legend.width ? t.config.legend.width + "px" : "", t.globals.dom.elLegendWrap
              .style.height = t.config.legend.height ? t.config.legend.height + "px" : "", X.setAttrs(C, {
                rel: l + 1,
                seriesName: P.escapeString(a[l]),
                "data:collapsed": g || p
              }), (g || p) && C.classList.add("apexcharts-inactive-legend"), t.config.legend.onItemClick
              .toggleDataSeries || C.classList.add("apexcharts-no-click")
          }
          t.globals.dom.elWrap.addEventListener("click", e.onLegendClick, !0), t.config.legend.onItemHover
            .highlightDataSeries && 0 === t.config.legend.customLegendItems.length && (t.globals.dom.elWrap
              .addEventListener("mousemove", e.onLegendHovered, !0), t.globals.dom.elWrap.addEventListener(
                "mouseout", e.onLegendHovered, !0))
        }
      }, {
        key: "setLegendWrapXY",
        value: function(e, t) {
          var i = this.w,
            a = i.globals.dom.elLegendWrap,
            s = a.getBoundingClientRect(),
            r = 0,
            n = 0;
          if ("bottom" === i.config.legend.position) n += i.globals.svgHeight - s.height / 2;
          else if ("top" === i.config.legend.position) {
            var o = new Me(this.ctx),
              l = o.dimHelpers.getTitleSubtitleCoords("title").height,
              c = o.dimHelpers.getTitleSubtitleCoords("subtitle").height;
            n = n + (l > 0 ? l - 10 : 0) + (c > 0 ? c - 10 : 0)
          }
          a.style.position = "absolute", n = n + t + i.config.legend.offsetY, a.style.left = (r = r + e + i
              .config.legend.offsetX) + "px", a.style.top = n + "px", "bottom" === i.config.legend.position ?
            (a.style.top = "auto", a.style.bottom = 5 - i.config.legend.offsetY + "px") : "right" === i.config
            .legend.position && (a.style.left = "auto", a.style.right = 25 + i.config.legend.offsetX + "px"),
            ["width", "height"].forEach(function(d) {
              a.style[d] && (a.style[d] = parseInt(i.config.legend[d], 10) + "px")
            })
        }
      }, {
        key: "legendAlignHorizontal",
        value: function() {
          var e = this.w;
          e.globals.dom.elLegendWrap.style.right = 0;
          var t = this.legendHelpers.getLegendBBox(),
            i = new Me(this.ctx),
            a = i.dimHelpers.getTitleSubtitleCoords("title"),
            s = i.dimHelpers.getTitleSubtitleCoords("subtitle"),
            r = 0;
          "bottom" === e.config.legend.position ? r = -t.clwh / 1.8 : "top" === e.config.legend.position && (
              r = a.height + s.height + e.config.title.margin + e.config.subtitle.margin - 10), this
            .setLegendWrapXY(20, r)
        }
      }, {
        key: "legendAlignVertical",
        value: function() {
          var e = this.w,
            t = this.legendHelpers.getLegendBBox(),
            i = 0;
          "left" === e.config.legend.position && (i = 20), "right" === e.config.legend.position && (i = e
            .globals.svgWidth - t.clww - 10), this.setLegendWrapXY(i, 20)
        }
      }, {
        key: "onLegendHovered",
        value: function(e) {
          var t = this.w,
            i = e.target.classList.contains("apexcharts-legend-series") || e.target.classList.contains(
              "apexcharts-legend-text") || e.target.classList.contains("apexcharts-legend-marker");
          if ("heatmap" === t.config.chart.type || this.isBarsDistributed) {
            if (i) {
              var a = parseInt(e.target.getAttribute("rel"), 10) - 1;
              this.ctx.events.fireEvent("legendHover", [this.ctx, a, this.w]), new se(this.ctx)
                .highlightRangeInSeries(e, e.target)
            }
          } else !e.target.classList.contains("apexcharts-inactive-legend") && i && new se(this.ctx)
            .toggleSeriesOnHover(e, e.target)
        }
      }, {
        key: "onLegendClick",
        value: function(e) {
          var t = this.w;
          if (!t.config.legend.customLegendItems.length && (e.target.classList.contains(
                "apexcharts-legend-series") || e.target.classList.contains("apexcharts-legend-text") || e
              .target.classList.contains("apexcharts-legend-marker"))) {
            var i = parseInt(e.target.getAttribute("rel"), 10) - 1,
              a = "true" === e.target.getAttribute("data:collapsed"),
              s = this.w.config.chart.events.legendClick;
            "function" == typeof s && s(this.ctx, i, this.w), this.ctx.events.fireEvent("legendClick", [this
              .ctx, i, this.w
            ]);
            var r = this.w.config.legend.markers.onClick;
            "function" == typeof r && e.target.classList.contains("apexcharts-legend-marker") && (r(this.ctx,
                i, this.w), this.ctx.events.fireEvent("legendMarkerClick", [this.ctx, i, this.w])),
              "treemap" !== t.config.chart.type && "heatmap" !== t.config.chart.type && !this
              .isBarsDistributed && t.config.legend.onItemClick.toggleDataSeries && this.legendHelpers
              .toggleDataSeries(i, a)
          }
        }
      }]), w
    }(),
    Je = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w;
        var t = this.w;
        this.ev = this.w.config.chart.events, this.selectedClass = "apexcharts-selected", this.localeValues = this.w
          .globals.locale.toolbar, this.minX = t.globals.minX, this.maxX = t.globals.maxX
      }
      return R(w, [{
        key: "createToolbar",
        value: function() {
          var e = this,
            t = this.w,
            i = function() {
              return document.createElement("div")
            },
            a = i();
          if (a.setAttribute("class", "apexcharts-toolbar"), a.style.top = t.config.chart.toolbar.offsetY +
            "px", a.style.right = 3 - t.config.chart.toolbar.offsetX + "px", t.globals.dom.elWrap.appendChild(
              a), this.elZoom = i(), this.elZoomIn = i(), this.elZoomOut = i(), this.elPan = i(), this
            .elSelection = i(), this.elZoomReset = i(), this.elMenuIcon = i(), this.elMenu = i(), this
            .elCustomIcons = [], this.t = t.config.chart.toolbar.tools, Array.isArray(this.t.customIcons))
            for (var s = 0; s < this.t.customIcons.length; s++) this.elCustomIcons.push(i());
          var r = [],
            n = function(d, g, p) {
              var f = d.toLowerCase();
              e.t[f] && t.config.chart.zoom.enabled && r.push({
                el: g,
                icon: "string" == typeof e.t[f] ? e.t[f] : p,
                title: e.localeValues[d],
                class: "apexcharts-".concat(f, "-icon")
              })
            };
          n("zoomIn", this.elZoomIn,
            '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">\n    <path d="M0 0h24v24H0z" fill="none"/>\n    <path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>\n</svg>\n'
            ), n("zoomOut", this.elZoomOut,
            '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">\n    <path d="M0 0h24v24H0z" fill="none"/>\n    <path d="M7 11v2h10v-2H7zm5-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>\n</svg>\n'
            );
          var o = function(d) {
            e.t[d] && t.config.chart[d].enabled && r.push({
              el: "zoom" === d ? e.elZoom : e.elSelection,
              icon: "string" == typeof e.t[d] ? e.t[d] : "zoom" === d ?
                '<svg xmlns="http://www.w3.org/2000/svg" fill="#000000" height="24" viewBox="0 0 24 24" width="24">\n    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>\n    <path d="M0 0h24v24H0V0z" fill="none"/>\n    <path d="M12 10h-2v2H9v-2H7V9h2V7h1v2h2v1z"/>\n</svg>' :
                '<svg fill="#6E8192" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">\n    <path d="M0 0h24v24H0z" fill="none"/>\n    <path d="M3 5h2V3c-1.1 0-2 .9-2 2zm0 8h2v-2H3v2zm4 8h2v-2H7v2zM3 9h2V7H3v2zm10-6h-2v2h2V3zm6 0v2h2c0-1.1-.9-2-2-2zM5 21v-2H3c0 1.1.9 2 2 2zm-2-4h2v-2H3v2zM9 3H7v2h2V3zm2 18h2v-2h-2v2zm8-8h2v-2h-2v2zm0 8c1.1 0 2-.9 2-2h-2v2zm0-12h2V7h-2v2zm0 8h2v-2h-2v2zm-4 4h2v-2h-2v2zm0-16h2V3h-2v2z"/>\n</svg>',
              title: e.localeValues["zoom" === d ? "selectionZoom" : "selection"],
              class: t.globals.isTouchDevice ? "apexcharts-element-hidden" : "apexcharts-".concat(d,
                "-icon")
            })
          };
          o("zoom"), o("selection"), this.t.pan && t.config.chart.zoom.enabled && r.push({
            el: this.elPan,
            icon: "string" == typeof this.t.pan ? this.t.pan :
              '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" height="24" viewBox="0 0 24 24" width="24">\n    <defs>\n        <path d="M0 0h24v24H0z" id="a"/>\n    </defs>\n    <clipPath id="b">\n        <use overflow="visible" xlink:href="#a"/>\n    </clipPath>\n    <path clip-path="url(#b)" d="M23 5.5V20c0 2.2-1.8 4-4 4h-7.3c-1.08 0-2.1-.43-2.85-1.19L1 14.83s1.26-1.23 1.3-1.25c.22-.19.49-.29.79-.29.22 0 .42.06.6.16.04.01 4.31 2.46 4.31 2.46V4c0-.83.67-1.5 1.5-1.5S11 3.17 11 4v7h1V1.5c0-.83.67-1.5 1.5-1.5S15 .67 15 1.5V11h1V2.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5V11h1V5.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5z"/>\n</svg>',
            title: this.localeValues.pan,
            class: t.globals.isTouchDevice ? "apexcharts-element-hidden" : "apexcharts-pan-icon"
          }), n("reset", this.elZoomReset,
            '<svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">\n    <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>\n    <path d="M0 0h24v24H0z" fill="none"/>\n</svg>'
            ), this.t.download && r.push({
            el: this.elMenuIcon,
            icon: "string" == typeof this.t.download ? this.t.download :
              '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" d="M0 0h24v24H0V0z"/><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/></svg>',
            title: this.localeValues.menu,
            class: "apexcharts-menu-icon"
          });
          for (var l = 0; l < this.elCustomIcons.length; l++) r.push({
            el: this.elCustomIcons[l],
            icon: this.t.customIcons[l].icon,
            title: this.t.customIcons[l].title,
            index: this.t.customIcons[l].index,
            class: "apexcharts-toolbar-custom-icon " + this.t.customIcons[l].class
          });
          r.forEach(function(d, g) {
            d.index && P.moveIndexInArray(r, g, d.index)
          });
          for (var c = 0; c < r.length; c++) X.setAttrs(r[c].el, {
            class: r[c].class,
            title: r[c].title
          }), r[c].el.innerHTML = r[c].icon, a.appendChild(r[c].el);
          this._createHamburgerMenu(a), t.globals.zoomEnabled ? this.elZoom.classList.add(this
            .selectedClass) : t.globals.panEnabled ? this.elPan.classList.add(this.selectedClass) : t.globals
            .selectionEnabled && this.elSelection.classList.add(this.selectedClass), this
            .addToolbarEventListeners()
        }
      }, {
        key: "_createHamburgerMenu",
        value: function(e) {
          this.elMenuItems = [], e.appendChild(this.elMenu), X.setAttrs(this.elMenu, {
            class: "apexcharts-menu"
          });
          for (var t = [{
              name: "exportSVG",
              title: this.localeValues.exportToSVG
            }, {
              name: "exportPNG",
              title: this.localeValues.exportToPNG
            }, {
              name: "exportCSV",
              title: this.localeValues.exportToCSV
            }], i = 0; i < t.length; i++) this.elMenuItems.push(document.createElement("div")), this
            .elMenuItems[i].innerHTML = t[i].title, X.setAttrs(this.elMenuItems[i], {
              class: "apexcharts-menu-item ".concat(t[i].name),
              title: t[i].title
            }), this.elMenu.appendChild(this.elMenuItems[i])
        }
      }, {
        key: "addToolbarEventListeners",
        value: function() {
          var e = this;
          this.elZoomReset.addEventListener("click", this.handleZoomReset.bind(this)), this.elSelection
            .addEventListener("click", this.toggleZoomSelection.bind(this, "selection")), this.elZoom
            .addEventListener("click", this.toggleZoomSelection.bind(this, "zoom")), this.elZoomIn
            .addEventListener("click", this.handleZoomIn.bind(this)), this.elZoomOut.addEventListener("click",
              this.handleZoomOut.bind(this)), this.elPan.addEventListener("click", this.togglePanning.bind(
              this)), this.elMenuIcon.addEventListener("click", this.toggleMenu.bind(this)), this.elMenuItems
            .forEach(function(i) {
              i.classList.contains("exportSVG") ? i.addEventListener("click", e.handleDownload.bind(e,
                "svg")) : i.classList.contains("exportPNG") ? i.addEventListener("click", e.handleDownload
                .bind(e, "png")) : i.classList.contains("exportCSV") && i.addEventListener("click", e
                .handleDownload.bind(e, "csv"))
            });
          for (var t = 0; t < this.t.customIcons.length; t++) this.elCustomIcons[t].addEventListener("click",
            this.t.customIcons[t].click.bind(this, this.ctx, this.ctx.w))
        }
      }, {
        key: "toggleZoomSelection",
        value: function(e) {
          this.ctx.getSyncedCharts().forEach(function(t) {
            t.ctx.toolbar.toggleOtherControls();
            var i = "selection" === e ? t.ctx.toolbar.elSelection : t.ctx.toolbar.elZoom,
              a = "selection" === e ? "selectionEnabled" : "zoomEnabled";
            t.w.globals[a] = !t.w.globals[a], i.classList.contains(t.ctx.toolbar.selectedClass) ? i
              .classList.remove(t.ctx.toolbar.selectedClass) : i.classList.add(t.ctx.toolbar
                .selectedClass)
          })
        }
      }, {
        key: "getToolbarIconsReference",
        value: function() {
          var e = this.w;
          this.elZoom || (this.elZoom = e.globals.dom.baseEl.querySelector(".apexcharts-zoom-icon")), this
            .elPan || (this.elPan = e.globals.dom.baseEl.querySelector(".apexcharts-pan-icon")), this
            .elSelection || (this.elSelection = e.globals.dom.baseEl.querySelector(
              ".apexcharts-selection-icon"))
        }
      }, {
        key: "enableZoomPanFromToolbar",
        value: function(e) {
          this.toggleOtherControls(), "pan" === e ? this.w.globals.panEnabled = !0 : this.w.globals
            .zoomEnabled = !0;
          var t = "pan" === e ? this.elPan : this.elZoom,
            i = "pan" === e ? this.elZoom : this.elPan;
          t && t.classList.add(this.selectedClass), i && i.classList.remove(this.selectedClass)
        }
      }, {
        key: "togglePanning",
        value: function() {
          this.ctx.getSyncedCharts().forEach(function(e) {
            e.ctx.toolbar.toggleOtherControls(), e.w.globals.panEnabled = !e.w.globals.panEnabled, e.ctx
              .toolbar.elPan.classList.contains(e.ctx.toolbar.selectedClass) ? e.ctx.toolbar.elPan
              .classList.remove(e.ctx.toolbar.selectedClass) : e.ctx.toolbar.elPan.classList.add(e.ctx
                .toolbar.selectedClass)
          })
        }
      }, {
        key: "toggleOtherControls",
        value: function() {
          var e = this,
            t = this.w;
          t.globals.panEnabled = !1, t.globals.zoomEnabled = !1, t.globals.selectionEnabled = !1, this
            .getToolbarIconsReference(), [this.elPan, this.elSelection, this.elZoom].forEach(function(i) {
              i && i.classList.remove(e.selectedClass)
            })
        }
      }, {
        key: "handleZoomIn",
        value: function() {
          var e = this.w;
          e.globals.isRangeBar && (this.minX = e.globals.minY, this.maxX = e.globals.maxY);
          var t = (this.minX + this.maxX) / 2,
            s = this._getNewMinXMaxX((this.minX + t) / 2, (this.maxX + t) / 2);
          e.globals.disableZoomIn || this.zoomUpdateOptions(s.minX, s.maxX)
        }
      }, {
        key: "handleZoomOut",
        value: function() {
          var e = this.w;
          if (e.globals.isRangeBar && (this.minX = e.globals.minY, this.maxX = e.globals.maxY), !(
              "datetime" === e.config.xaxis.type && new Date(this.minX).getUTCFullYear() < 1e3)) {
            var t = (this.minX + this.maxX) / 2,
              s = this._getNewMinXMaxX(this.minX - (t - this.minX), this.maxX - (t - this.maxX));
            e.globals.disableZoomOut || this.zoomUpdateOptions(s.minX, s.maxX)
          }
        }
      }, {
        key: "_getNewMinXMaxX",
        value: function(e, t) {
          var i = this.w.config.xaxis.convertedCatToNumeric;
          return {
            minX: i ? Math.floor(e) : e,
            maxX: i ? Math.floor(t) : t
          }
        }
      }, {
        key: "zoomUpdateOptions",
        value: function(e, t) {
          var i = this.w;
          if (void 0 !== e || void 0 !== t) {
            if (!(i.config.xaxis.convertedCatToNumeric && (e < 1 && (e = 1, t = i.globals.dataPoints), t - e <
                2))) {
              var a = {
                  min: e,
                  max: t
                },
                s = this.getBeforeZoomRange(a);
              s && (a = s.xaxis);
              var r = {
                  xaxis: a
                },
                n = P.clone(i.globals.initialConfig.yaxis);
              i.config.chart.group || (r.yaxis = n), this.w.globals.zoomed = !0, this.ctx.updateHelpers
                ._updateOptions(r, !1, this.w.config.chart.animations.dynamicAnimation.enabled), this
                .zoomCallback(a, n)
            }
          } else this.handleZoomReset()
        }
      }, {
        key: "zoomCallback",
        value: function(e, t) {
          "function" == typeof this.ev.zoomed && this.ev.zoomed(this.ctx, {
            xaxis: e,
            yaxis: t
          })
        }
      }, {
        key: "getBeforeZoomRange",
        value: function(e, t) {
          var i = null;
          return "function" == typeof this.ev.beforeZoom && (i = this.ev.beforeZoom(this, {
            xaxis: e,
            yaxis: t
          })), i
        }
      }, {
        key: "toggleMenu",
        value: function() {
          var e = this;
          window.setTimeout(function() {
            e.elMenu.classList.contains("apexcharts-menu-open") ? e.elMenu.classList.remove(
              "apexcharts-menu-open") : e.elMenu.classList.add("apexcharts-menu-open")
          }, 0)
        }
      }, {
        key: "handleDownload",
        value: function(e) {
          var t = this.w,
            i = new Pe(this.ctx);
          switch (e) {
            case "svg":
              i.exportToSVG(this.ctx);
              break;
            case "png":
              i.exportToPng(this.ctx);
              break;
            case "csv":
              i.exportToCSV({
                series: t.config.series,
                columnDelimiter: t.config.chart.toolbar.export.csv.columnDelimiter
              })
          }
        }
      }, {
        key: "handleZoomReset",
        value: function(e) {
          this.ctx.getSyncedCharts().forEach(function(t) {
            var i = t.w;
            if (i.globals.lastXAxis.min = i.globals.initialConfig.xaxis.min, i.globals.lastXAxis.max = i
              .globals.initialConfig.xaxis.max, t.updateHelpers.revertDefaultAxisMinMax(), "function" ==
              typeof i.config.chart.events.beforeResetZoom) {
              var a = i.config.chart.events.beforeResetZoom(t, i);
              a && t.updateHelpers.revertDefaultAxisMinMax(a)
            }
            "function" == typeof i.config.chart.events.zoomed && t.ctx.toolbar.zoomCallback({
              min: i.config.xaxis.min,
              max: i.config.xaxis.max
            }), i.globals.zoomed = !1;
            var s = t.ctx.series.emptyCollapsedSeries(P.clone(i.globals.initialSeries));
            t.updateHelpers._updateSeries(s, i.config.chart.animations.dynamicAnimation.enabled)
          })
        }
      }, {
        key: "destroy",
        value: function() {
          this.elZoom = null, this.elZoomIn = null, this.elZoomOut = null, this.elPan = null, this
            .elSelection = null, this.elZoomReset = null, this.elMenuIcon = null
        }
      }]), w
    }(),
    At = function(w) {
      xe(t, w);
      var e = be(t);

      function t(i) {
        var a;
        return F(this, t), (a = e.call(this, i)).ctx = i, a.w = i.w, a.dragged = !1, a.graphics = new X(a.ctx), a
          .eventList = ["mousedown", "mouseleave", "mousemove", "touchstart", "touchmove", "mouseup", "touchend"], a
          .clientX = 0, a.clientY = 0, a.startX = 0, a.endX = 0, a.dragX = 0, a.startY = 0, a.endY = 0, a.dragY = 0, a
          .moveDirection = "none", a
      }
      return R(t, [{
        key: "init",
        value: function(i) {
          var a = this,
            s = i.xyRatios,
            r = this.w,
            n = this;
          this.xyRatios = s, this.zoomRect = this.graphics.drawRect(0, 0, 0, 0), this.selectionRect = this
            .graphics.drawRect(0, 0, 0, 0), this.gridRect = r.globals.dom.baseEl.querySelector(
              ".apexcharts-grid"), this.zoomRect.node.classList.add("apexcharts-zoom-rect"), this
            .selectionRect.node.classList.add("apexcharts-selection-rect"), r.globals.dom.elGraphical.add(this
              .zoomRect), r.globals.dom.elGraphical.add(this.selectionRect), this.slDraggableRect = "x" === r
            .config.chart.selection.type ? this.selectionRect.draggable({
              minX: 0,
              minY: 0,
              maxX: r.globals.gridWidth,
              maxY: r.globals.gridHeight
            }).on("dragmove", this.selectionDragging.bind(this, "dragging")) : "y" === r.config.chart
            .selection.type ? this.selectionRect.draggable({
              minX: 0,
              maxX: r.globals.gridWidth
            }).on("dragmove", this.selectionDragging.bind(this, "dragging")) : this.selectionRect.draggable()
            .on("dragmove", this.selectionDragging.bind(this, "dragging")), this.preselectedSelection(), this
            .hoverArea = r.globals.dom.baseEl.querySelector("".concat(r.globals.chartClass,
              " .apexcharts-svg")), this.hoverArea.classList.add("apexcharts-zoomable"), this.eventList
            .forEach(function(o) {
              a.hoverArea.addEventListener(o, n.svgMouseEvents.bind(n, s), {
                capture: !1,
                passive: !0
              })
            })
        }
      }, {
        key: "destroy",
        value: function() {
          this.slDraggableRect && (this.slDraggableRect.draggable(!1), this.slDraggableRect.off(), this
            .selectionRect.off()), this.selectionRect = null, this.zoomRect = null, this.gridRect = null
        }
      }, {
        key: "svgMouseEvents",
        value: function(i, a) {
          var s = this.w,
            r = this,
            n = this.ctx.toolbar,
            o = s.globals.zoomEnabled ? s.config.chart.zoom.type : s.config.chart.selection.type,
            l = s.config.chart.toolbar.autoSelected;
          if (a.shiftKey ? (this.shiftWasPressed = !0, n.enableZoomPanFromToolbar("pan" === l ? "zoom" :
              "pan")) : this.shiftWasPressed && (n.enableZoomPanFromToolbar(l), this.shiftWasPressed = !1), a
            .target) {
            var c, d = a.target.classList;
            if (a.target.parentNode && null !== a.target.parentNode && (c = a.target.parentNode.classList), !(
                d.contains("apexcharts-selection-rect") || d.contains("apexcharts-legend-marker") || d
                .contains("apexcharts-legend-text") || c && c.contains("apexcharts-toolbar"))) {
              if (r.clientX = "touchmove" === a.type || "touchstart" === a.type ? a.touches[0].clientX :
                "touchend" === a.type ? a.changedTouches[0].clientX : a.clientX, r.clientY = "touchmove" === a
                .type || "touchstart" === a.type ? a.touches[0].clientY : "touchend" === a.type ? a
                .changedTouches[0].clientY : a.clientY, "mousedown" === a.type && 1 === a.which) {
                var g = r.gridRect.getBoundingClientRect();
                r.startX = r.clientX - g.left, r.startY = r.clientY - g.top, r.dragged = !1, r.w.globals
                  .mousedown = !0
              }
              if (("mousemove" === a.type && 1 === a.which || "touchmove" === a.type) && (r.dragged = !0, s
                  .globals.panEnabled ? (s.globals.selection = null, r.w.globals.mousedown && r.panDragging({
                    context: r,
                    zoomtype: o,
                    xyRatios: i
                  })) : (r.w.globals.mousedown && s.globals.zoomEnabled || r.w.globals.mousedown && s.globals
                    .selectionEnabled) && (r.selection = r.selectionDrawing({
                    context: r,
                    zoomtype: o
                  }))), "mouseup" === a.type || "touchend" === a.type || "mouseleave" === a.type) {
                var p = r.gridRect.getBoundingClientRect();
                r.w.globals.mousedown && (r.endX = r.clientX - p.left, r.endY = r.clientY - p.top, r.dragX =
                    Math.abs(r.endX - r.startX), r.dragY = Math.abs(r.endY - r.startY), (s.globals
                      .zoomEnabled || s.globals.selectionEnabled) && r.selectionDrawn({
                      context: r,
                      zoomtype: o
                    }), s.globals.panEnabled && s.config.xaxis.convertedCatToNumeric && r.delayedPanScrolled()
                    ), s.globals.zoomEnabled && r.hideSelectionRect(this.selectionRect), r.dragged = !1, r.w
                  .globals.mousedown = !1
              }
              this.makeSelectionRectDraggable()
            }
          }
        }
      }, {
        key: "makeSelectionRectDraggable",
        value: function() {
          var i = this.w;
          if (this.selectionRect) {
            var a = this.selectionRect.node.getBoundingClientRect();
            a.width > 0 && a.height > 0 && this.slDraggableRect.selectize({
              points: "l, r",
              pointSize: 8,
              pointType: "rect"
            }).resize({
              constraint: {
                minX: 0,
                minY: 0,
                maxX: i.globals.gridWidth,
                maxY: i.globals.gridHeight
              }
            }).on("resizing", this.selectionDragging.bind(this, "resizing"))
          }
        }
      }, {
        key: "preselectedSelection",
        value: function() {
          var i = this.w,
            a = this.xyRatios;
          if (!i.globals.zoomEnabled)
            if (null != i.globals.selection) this.drawSelectionRect(i.globals.selection);
            else if (void 0 !== i.config.chart.selection.xaxis.min && void 0 !== i.config.chart.selection
            .xaxis.max) {
            var s = (i.config.chart.selection.xaxis.min - i.globals.minX) / a.xRatio,
              r = i.globals.gridWidth - (i.globals.maxX - i.config.chart.selection.xaxis.max) / a.xRatio - s;
            i.globals.isRangeBar && (s = (i.config.chart.selection.xaxis.min - i.globals.yAxisScale[0]
                .niceMin) / a.invertedYRatio, r = (i.config.chart.selection.xaxis.max - i.config.chart
                .selection.xaxis.min) / a.invertedYRatio), this.drawSelectionRect({
                x: s,
                y: 0,
                width: r,
                height: i.globals.gridHeight,
                translateX: 0,
                translateY: 0,
                selectionEnabled: !0
              }), this.makeSelectionRectDraggable(), "function" == typeof i.config.chart.events.selection && i
              .config.chart.events.selection(this.ctx, {
                xaxis: {
                  min: i.config.chart.selection.xaxis.min,
                  max: i.config.chart.selection.xaxis.max
                },
                yaxis: {}
              })
          }
        }
      }, {
        key: "drawSelectionRect",
        value: function(i) {
          var a = i.x,
            s = i.y,
            r = i.width,
            n = i.height,
            o = i.translateX,
            c = i.translateY,
            g = this.w,
            p = this.zoomRect,
            f = this.selectionRect;
          if (this.dragged || null !== g.globals.selection) {
            var x = {
              transform: "translate(" + (void 0 === o ? 0 : o) + ", " + (void 0 === c ? 0 : c) + ")"
            };
            g.globals.zoomEnabled && this.dragged && (r < 0 && (r = 1), p.attr({
              x: a,
              y: s,
              width: r,
              height: n,
              fill: g.config.chart.zoom.zoomedArea.fill.color,
              "fill-opacity": g.config.chart.zoom.zoomedArea.fill.opacity,
              stroke: g.config.chart.zoom.zoomedArea.stroke.color,
              "stroke-width": g.config.chart.zoom.zoomedArea.stroke.width,
              "stroke-opacity": g.config.chart.zoom.zoomedArea.stroke.opacity
            }), X.setAttrs(p.node, x)), g.globals.selectionEnabled && (f.attr({
              x: a,
              y: s,
              width: r > 0 ? r : 0,
              height: n > 0 ? n : 0,
              fill: g.config.chart.selection.fill.color,
              "fill-opacity": g.config.chart.selection.fill.opacity,
              stroke: g.config.chart.selection.stroke.color,
              "stroke-width": g.config.chart.selection.stroke.width,
              "stroke-dasharray": g.config.chart.selection.stroke.dashArray,
              "stroke-opacity": g.config.chart.selection.stroke.opacity
            }), X.setAttrs(f.node, x))
          }
        }
      }, {
        key: "hideSelectionRect",
        value: function(i) {
          i && i.attr({
            x: 0,
            y: 0,
            width: 0,
            height: 0
          })
        }
      }, {
        key: "selectionDrawing",
        value: function(i) {
          var x, s = i.zoomtype,
            r = this.w,
            n = i.context,
            o = this.gridRect.getBoundingClientRect(),
            l = n.startX - 1,
            c = n.startY,
            d = !1,
            g = !1,
            p = n.clientX - o.left - l,
            f = n.clientY - o.top - c;
          return Math.abs(p + l) > r.globals.gridWidth ? p = r.globals.gridWidth - l : n.clientX - o.left <
            0 && (p = l), l > n.clientX - o.left && (d = !0, p = Math.abs(p)), c > n.clientY - o.top && (g = !
              0, f = Math.abs(f)), n.drawSelectionRect(x = "x" === s ? {
              x: d ? l - p : l,
              y: 0,
              width: p,
              height: r.globals.gridHeight
            } : "y" === s ? {
              x: 0,
              y: g ? c - f : c,
              width: r.globals.gridWidth,
              height: f
            } : {
              x: d ? l - p : l,
              y: g ? c - f : c,
              width: p,
              height: f
            }), n.selectionDragging("resizing"), x
        }
      }, {
        key: "selectionDragging",
        value: function(i, a) {
          var s = this,
            r = this.w,
            n = this.xyRatios,
            o = this.selectionRect,
            l = 0;
          "resizing" === i && (l = 30);
          var c = function(g) {
              return parseFloat(o.node.getAttribute(g))
            },
            d = {
              x: c("x"),
              y: c("y"),
              width: c("width"),
              height: c("height")
            };
          r.globals.selection = d, "function" == typeof r.config.chart.events.selection && r.globals
            .selectionEnabled && (clearTimeout(this.w.globals.selectionResizeTimer), this.w.globals
              .selectionResizeTimer = window.setTimeout(function() {
                var g, p, f, x, m = s.gridRect.getBoundingClientRect(),
                  v = o.node.getBoundingClientRect();
                r.globals.isRangeBar ? (g = r.globals.yAxisScale[0].niceMin + (v.left - m.left) * n
                  .invertedYRatio, p = r.globals.yAxisScale[0].niceMin + (v.right - m.left) * n
                  .invertedYRatio, f = 0, x = 1) : (g = r.globals.xAxisScale.niceMin + (v.left - m.left) *
                  n.xRatio, p = r.globals.xAxisScale.niceMin + (v.right - m.left) * n.xRatio, f = r
                  .globals.yAxisScale[0].niceMin + (m.bottom - v.bottom) * n.yRatio[0], x = r.globals
                  .yAxisScale[0].niceMax - (v.top - m.top) * n.yRatio[0]);
                var y = {
                  xaxis: {
                    min: g,
                    max: p
                  },
                  yaxis: {
                    min: f,
                    max: x
                  }
                };
                r.config.chart.events.selection(s.ctx, y), r.config.chart.brush.enabled && void 0 !== r
                  .config.chart.events.brushScrolled && r.config.chart.events.brushScrolled(s.ctx, y)
              }, l))
        }
      }, {
        key: "selectionDrawn",
        value: function(i) {
          var s = i.zoomtype,
            r = this.w,
            n = i.context,
            o = this.xyRatios,
            l = this.ctx.toolbar;
          if (n.startX > n.endX) {
            var c = n.startX;
            n.startX = n.endX, n.endX = c
          }
          if (n.startY > n.endY) {
            var d = n.startY;
            n.startY = n.endY, n.endY = d
          }
          var g = void 0,
            p = void 0;
          r.globals.isRangeBar ? (g = r.globals.yAxisScale[0].niceMin + n.startX * o.invertedYRatio, p = r
            .globals.yAxisScale[0].niceMin + n.endX * o.invertedYRatio) : (g = r.globals.xAxisScale
            .niceMin + n.startX * o.xRatio, p = r.globals.xAxisScale.niceMin + n.endX * o.xRatio);
          var f = [],
            x = [];
          if (r.config.yaxis.forEach(function(k, A) {
              if (r.globals.seriesYAxisMap[A].length > 0) {
                var S = r.globals.seriesYAxisMap[A][0];
                f.push(r.globals.yAxisScale[A].niceMax - o.yRatio[S] * n.startY), x.push(r.globals
                  .yAxisScale[A].niceMax - o.yRatio[S] * n.endY)
              }
            }), n.dragged && (n.dragX > 10 || n.dragY > 10) && g !== p)
            if (r.globals.zoomEnabled) {
              var m = P.clone(r.globals.initialConfig.yaxis),
                v = P.clone(r.globals.initialConfig.xaxis);
              if (r.globals.zoomed = !0, r.config.xaxis.convertedCatToNumeric && (g = Math.floor(g), p = Math
                  .floor(p), g < 1 && (g = 1, p = r.globals.dataPoints), p - g < 2 && (p = g + 1)), "xy" !==
                s && "x" !== s || (v = {
                  min: g,
                  max: p
                }), "xy" !== s && "y" !== s || m.forEach(function(k, A) {
                  m[A].min = x[A], m[A].max = f[A]
                }), l) {
                var y = l.getBeforeZoomRange(v, m);
                y && (v = y.xaxis ? y.xaxis : v, m = y.yaxis ? y.yaxis : m)
              }
              var h = {
                xaxis: v
              };
              r.config.chart.group || (h.yaxis = m), n.ctx.updateHelpers._updateOptions(h, !1, n.w.config
                  .chart.animations.dynamicAnimation.enabled), "function" == typeof r.config.chart.events
                .zoomed && l.zoomCallback(v, m)
            } else if (r.globals.selectionEnabled) {
            var u, b = null;
            u = {
                min: g,
                max: p
              }, "xy" !== s && "y" !== s || (b = P.clone(r.config.yaxis)).forEach(function(k, A) {
                b[A].min = x[A], b[A].max = f[A]
              }), r.globals.selection = n.selection, "function" == typeof r.config.chart.events.selection && r
              .config.chart.events.selection(n.ctx, {
                xaxis: u,
                yaxis: b
              })
          }
        }
      }, {
        key: "panDragging",
        value: function(i) {
          var s = this.w,
            r = i.context;
          if (void 0 !== s.globals.lastClientPosition.x) {
            var n = s.globals.lastClientPosition.x - r.clientX,
              o = s.globals.lastClientPosition.y - r.clientY;
            Math.abs(n) > Math.abs(o) && n > 0 ? this.moveDirection = "left" : Math.abs(n) > Math.abs(o) &&
              n < 0 ? this.moveDirection = "right" : Math.abs(o) > Math.abs(n) && o > 0 ? this.moveDirection =
              "up" : Math.abs(o) > Math.abs(n) && o < 0 && (this.moveDirection = "down")
          }
          s.globals.lastClientPosition = {
            x: r.clientX,
            y: r.clientY
          }, s.config.xaxis.convertedCatToNumeric || r.panScrolled(s.globals.isRangeBar ? s.globals.minY : s
            .globals.minX, s.globals.isRangeBar ? s.globals.maxY : s.globals.maxX)
        }
      }, {
        key: "delayedPanScrolled",
        value: function() {
          var i = this.w,
            a = i.globals.minX,
            s = i.globals.maxX,
            r = (i.globals.maxX - i.globals.minX) / 2;
          "left" === this.moveDirection ? (a = i.globals.minX + r, s = i.globals.maxX + r) : "right" === this
            .moveDirection && (a = i.globals.minX - r, s = i.globals.maxX - r), a = Math.floor(a), s = Math
            .floor(s), this.updateScrolledChart({
              xaxis: {
                min: a,
                max: s
              }
            }, a, s)
        }
      }, {
        key: "panScrolled",
        value: function(i, a) {
          var s = this.w,
            r = this.xyRatios,
            n = P.clone(s.globals.initialConfig.yaxis),
            o = r.xRatio,
            l = s.globals.minX,
            c = s.globals.maxX;
          s.globals.isRangeBar && (o = r.invertedYRatio, l = s.globals.minY, c = s.globals.maxY), "left" ===
            this.moveDirection ? (i = l + s.globals.gridWidth / 15 * o, a = c + s.globals.gridWidth / 15 *
            o) : "right" === this.moveDirection && (i = l - s.globals.gridWidth / 15 * o, a = c - s.globals
              .gridWidth / 15 * o), s.globals.isRangeBar || (i < s.globals.initialMinX || a > s.globals
              .initialMaxX) && (i = l, a = c);
          var d = {
            xaxis: {
              min: i,
              max: a
            }
          };
          s.config.chart.group || (d.yaxis = n), this.updateScrolledChart(d, i, a)
        }
      }, {
        key: "updateScrolledChart",
        value: function(i, a, s) {
          var r = this.w;
          this.ctx.updateHelpers._updateOptions(i, !1, !1), "function" == typeof r.config.chart.events
            .scrolled && r.config.chart.events.scrolled(this.ctx, {
              xaxis: {
                min: a,
                max: s
              }
            })
        }
      }]), t
    }(Je),
    Qe = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.ttCtx = e, this.ctx = e.ctx
      }
      return R(w, [{
        key: "getNearestValues",
        value: function(e) {
          var t = e.hoverArea,
            a = e.clientX,
            s = e.clientY,
            r = this.w,
            n = e.elGrid.getBoundingClientRect(),
            o = n.width,
            l = n.height,
            c = o / (r.globals.dataPoints - 1),
            d = l / r.globals.dataPoints,
            g = this.hasBars();
          !r.globals.comboCharts && !g || r.config.xaxis.convertedCatToNumeric || (c = o / r.globals
            .dataPoints);
          var p = a - n.left - r.globals.barPadForNumericAxis,
            f = s - n.top;
          p < 0 || f < 0 || p > o || f > l ? (t.classList.remove("hovering-zoom"), t.classList.remove(
            "hovering-pan")) : r.globals.zoomEnabled ? (t.classList.remove("hovering-pan"), t.classList.add(
            "hovering-zoom")) : r.globals.panEnabled && (t.classList.remove("hovering-zoom"), t.classList
            .add("hovering-pan"));
          var x = Math.round(p / c),
            m = Math.floor(f / d);
          g && !r.config.xaxis.convertedCatToNumeric && (x = Math.ceil(p / c), x -= 1);
          var v = null,
            y = null,
            h = r.globals.seriesXvalues.map(function(S) {
              return S.filter(function(C) {
                return P.isNumber(C)
              })
            }),
            u = r.globals.seriesYvalues.map(function(S) {
              return S.filter(function(C) {
                return P.isNumber(C)
              })
            });
          if (r.globals.isXNumeric) {
            var b = this.ttCtx.getElGrid().getBoundingClientRect(),
              k = p * (b.width / o);
            v = (y = this.closestInMultiArray(k, f * (b.height / l), h, u)).index, x = y.j, null !== v && (x =
              (y = this.closestInArray(k, h = r.globals.seriesXvalues[v])).index)
          }
          return r.globals.capturedSeriesIndex = null === v ? -1 : v, (!x || x < 1) && (x = 0), r.globals
            .capturedDataPointIndex = r.globals.isBarHorizontal ? m : x, {
              capturedSeries: v,
              j: r.globals.isBarHorizontal ? m : x,
              hoverX: p,
              hoverY: f
            }
        }
      }, {
        key: "closestInMultiArray",
        value: function(e, t, i, a) {
          var r = 0,
            n = null,
            o = -1;
          this.w.globals.series.length > 1 ? r = this.getFirstActiveXArray(i) : n = 0;
          var c = Math.abs(e - i[r][0]);
          if (i.forEach(function(p) {
              p.forEach(function(f, x) {
                var m = Math.abs(e - f);
                m <= c && (c = m, o = x)
              })
            }), -1 !== o) {
            var g = Math.abs(t - a[r][o]);
            n = r, a.forEach(function(p, f) {
              var x = Math.abs(t - p[o]);
              x <= g && (g = x, n = f)
            })
          }
          return {
            index: n,
            j: o
          }
        }
      }, {
        key: "getFirstActiveXArray",
        value: function(e) {
          for (var t = this.w, i = 0, a = e.map(function(r, n) {
              return r.length > 0 ? n : -1
            }), s = 0; s < a.length; s++)
            if (-1 !== a[s] && -1 === t.globals.collapsedSeriesIndices.indexOf(s) && -1 === t.globals
              .ancillaryCollapsedSeriesIndices.indexOf(s)) {
              i = a[s];
              break
            } return i
        }
      }, {
        key: "closestInArray",
        value: function(e, t) {
          for (var a = null, s = Math.abs(e - t[0]), r = 0; r < t.length; r++) {
            var n = Math.abs(e - t[r]);
            n < s && (s = n, a = r)
          }
          return {
            index: a
          }
        }
      }, {
        key: "isXoverlap",
        value: function(e) {
          var t = [],
            i = this.w.globals.seriesX.filter(function(s) {
              return void 0 !== s[0]
            });
          if (i.length > 0)
            for (var a = 0; a < i.length - 1; a++) void 0 !== i[a][e] && void 0 !== i[a + 1][e] && i[a][e] !==
              i[a + 1][e] && t.push("unEqual");
          return 0 === t.length
        }
      }, {
        key: "isInitialSeriesSameLen",
        value: function() {
          for (var e = !0, t = this.w.globals.initialSeries, i = 0; i < t.length - 1; i++)
            if (t[i].data.length !== t[i + 1].data.length) {
              e = !1;
              break
            } return e
        }
      }, {
        key: "getBarsHeight",
        value: function(e) {
          return J(e).reduce(function(t, i) {
            return t + i.getBBox().height
          }, 0)
        }
      }, {
        key: "getElMarkers",
        value: function(e) {
          return this.w.globals.dom.baseEl.querySelectorAll("number" == typeof e ?
            ".apexcharts-series[data\\:realIndex='".concat(e, "'] .apexcharts-series-markers-wrap > *") :
            ".apexcharts-series-markers-wrap > *")
        }
      }, {
        key: "getAllMarkers",
        value: function() {
          var e = this.w.globals.dom.baseEl.querySelectorAll(".apexcharts-series-markers-wrap");
          (e = J(e)).sort(function(i, a) {
            var s = Number(i.getAttribute("data:realIndex")),
              r = Number(a.getAttribute("data:realIndex"));
            return r < s ? 1 : r > s ? -1 : 0
          });
          var t = [];
          return e.forEach(function(i) {
            t.push(i.querySelector(".apexcharts-marker"))
          }), t
        }
      }, {
        key: "hasMarkers",
        value: function(e) {
          return this.getElMarkers(e).length > 0
        }
      }, {
        key: "getElBars",
        value: function() {
          return this.w.globals.dom.baseEl.querySelectorAll(
            ".apexcharts-bar-series,  .apexcharts-candlestick-series, .apexcharts-boxPlot-series, .apexcharts-rangebar-series"
            )
        }
      }, {
        key: "hasBars",
        value: function() {
          return this.getElBars().length > 0
        }
      }, {
        key: "getHoverMarkerSize",
        value: function(e) {
          var t = this.w,
            i = t.config.markers.hover.size;
          return void 0 === i && (i = t.globals.markers.size[e] + t.config.markers.hover.sizeOffset), i
        }
      }, {
        key: "toggleAllTooltipSeriesGroups",
        value: function(e) {
          var t = this.w,
            i = this.ttCtx;
          0 === i.allTooltipSeriesGroups.length && (i.allTooltipSeriesGroups = t.globals.dom.baseEl
            .querySelectorAll(".apexcharts-tooltip-series-group"));
          for (var a = i.allTooltipSeriesGroups, s = 0; s < a.length; s++) "enable" === e ? (a[s].classList
            .add("apexcharts-active"), a[s].style.display = t.config.tooltip.items.display) : (a[s]
            .classList.remove("apexcharts-active"), a[s].style.display = "none")
        }
      }]), w
    }(),
    St = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.ctx = e.ctx, this.ttCtx = e, this.tooltipUtil = new Qe(e)
      }
      return R(w, [{
        key: "drawSeriesTexts",
        value: function(e) {
          var t = e.shared,
            i = void 0 === t || t,
            a = e.ttItems,
            s = e.i,
            r = void 0 === s ? 0 : s,
            n = e.j,
            o = void 0 === n ? null : n,
            d = e.e,
            g = this.w;
          void 0 !== g.config.tooltip.custom ? this.handleCustomTooltip({
            i: r,
            j: o,
            y1: e.y1,
            y2: e.y2,
            w: g
          }) : this.toggleActiveInactiveSeries(i);
          var p = this.getValuesToPrint({
            i: r,
            j: o
          });
          this.printLabels({
            i: r,
            j: o,
            values: p,
            ttItems: a,
            shared: i,
            e: d
          });
          var f = this.ttCtx.getElTooltip();
          this.ttCtx.tooltipRect.ttWidth = f.getBoundingClientRect().width, this.ttCtx.tooltipRect.ttHeight =
            f.getBoundingClientRect().height
        }
      }, {
        key: "printLabels",
        value: function(e) {
          var t, i = this,
            a = e.i,
            s = e.j,
            r = e.values,
            n = e.ttItems,
            o = e.shared,
            l = e.e,
            c = this.w,
            d = [],
            g = function(b) {
              return c.globals.seriesGoals[b] && c.globals.seriesGoals[b][s] && Array.isArray(c.globals
                .seriesGoals[b][s])
            },
            p = r.xVal,
            f = r.zVal,
            x = r.xAxisTTVal,
            m = "",
            v = c.globals.colors[a];
          null !== s && c.config.plotOptions.bar.distributed && (v = c.globals.colors[s]);
          for (var y = function(b, k) {
              var A = i.getFormatters(a);
              m = i.getSeriesName({
                fn: A.yLbTitleFormatter,
                index: a,
                seriesIndex: a,
                j: s
              }), "treemap" === c.config.chart.type && (m = A.yLbTitleFormatter(String(c.config.series[a]
                .data[s].x), {
                series: c.globals.series,
                seriesIndex: a,
                dataPointIndex: s,
                w: c
              }));
              var S = c.config.tooltip.inverseOrder ? k : b;
              if (c.globals.axisCharts) {
                var C = function(z) {
                  var I, T, E, H;
                  return c.globals.isRangeData ? A.yLbFormatter(null === (I = c.globals
                    .seriesRangeStart) || void 0 === I || null === (T = I[z]) || void 0 === T ? void 0 :
                    T[s], {
                      series: c.globals.seriesRangeStart,
                      seriesIndex: z,
                      dataPointIndex: s,
                      w: c
                    }) + " - " + A.yLbFormatter(null === (E = c.globals.seriesRangeEnd) || void 0 ===
                    E || null === (H = E[z]) || void 0 === H ? void 0 : H[s], {
                      series: c.globals.seriesRangeEnd,
                      seriesIndex: z,
                      dataPointIndex: s,
                      w: c
                    }) : A.yLbFormatter(c.globals.series[z][s], {
                    series: c.globals.series,
                    seriesIndex: z,
                    dataPointIndex: s,
                    w: c
                  })
                };
                if (o) A = i.getFormatters(S), m = i.getSeriesName({
                  fn: A.yLbTitleFormatter,
                  index: S,
                  seriesIndex: a,
                  j: s
                }), v = c.globals.colors[S], t = C(S), g(S) && (d = c.globals.seriesGoals[S][s].map(
                  function(z) {
                    return {
                      attrs: z,
                      val: A.yLbFormatter(z.value, {
                        seriesIndex: S,
                        dataPointIndex: s,
                        w: c
                      })
                    }
                  }));
                else {
                  var L, M = null == l || null === (L = l.target) || void 0 === L ? void 0 : L.getAttribute(
                    "fill");
                  M && (v = -1 !== M.indexOf("url") ? document.querySelector(M.substr(4).slice(0, -1))
                    .childNodes[0].getAttribute("stroke") : M), t = C(a), g(a) && Array.isArray(c.globals
                    .seriesGoals[a][s]) && (d = c.globals.seriesGoals[a][s].map(function(z) {
                    return {
                      attrs: z,
                      val: A.yLbFormatter(z.value, {
                        seriesIndex: a,
                        dataPointIndex: s,
                        w: c
                      })
                    }
                  }))
                }
              }
              null === s && (t = A.yLbFormatter(c.globals.series[a], Y(Y({}, c), {}, {
                seriesIndex: a,
                dataPointIndex: a
              }))), i.DOMHandling({
                i: a,
                t: S,
                j: s,
                ttItems: n,
                values: {
                  val: t,
                  goalVals: d,
                  xVal: p,
                  xAxisTTVal: x,
                  zVal: f
                },
                seriesName: m,
                shared: o,
                pColor: v
              })
            }, h = 0, u = c.globals.series.length - 1; h < c.globals.series.length; h++, u--) y(h, u)
        }
      }, {
        key: "getFormatters",
        value: function(e) {
          var t, i = this.w,
            a = i.globals.yLabelFormatters[e];
          return void 0 !== i.globals.ttVal ? Array.isArray(i.globals.ttVal) ? (a = i.globals.ttVal[e] && i
              .globals.ttVal[e].formatter, t = i.globals.ttVal[e] && i.globals.ttVal[e].title && i.globals
              .ttVal[e].title.formatter) : (a = i.globals.ttVal.formatter, "function" == typeof i.globals
              .ttVal.title.formatter && (t = i.globals.ttVal.title.formatter)) : t = i.config.tooltip.y.title
            .formatter, "function" != typeof a && (a = i.globals.yLabelFormatters[0] ? i.globals
              .yLabelFormatters[0] : function(s) {
                return s
              }), "function" != typeof t && (t = function(s) {
              return s
            }), {
              yLbFormatter: a,
              yLbTitleFormatter: t
            }
        }
      }, {
        key: "getSeriesName",
        value: function(e) {
          var a = e.seriesIndex,
            s = e.j,
            r = this.w;
          return (0, e.fn)(String(r.globals.seriesNames[e.index]), {
            series: r.globals.series,
            seriesIndex: a,
            dataPointIndex: s,
            w: r
          })
        }
      }, {
        key: "DOMHandling",
        value: function(e) {
          var t = e.t,
            i = e.j,
            a = e.ttItems,
            s = e.values,
            r = e.seriesName,
            n = e.shared,
            o = e.pColor,
            l = this.w,
            c = this.ttCtx,
            d = s.val,
            g = s.goalVals,
            p = s.xVal,
            f = s.xAxisTTVal,
            x = s.zVal,
            m = null;
          m = a[t].children, l.config.tooltip.fillSeriesColor && (a[t].style.backgroundColor = o, m[0].style
              .display = "none"), c.showTooltipTitle && (null === c.tooltipTitle && (c.tooltipTitle = l
              .globals.dom.baseEl.querySelector(".apexcharts-tooltip-title")), c.tooltipTitle.innerHTML = p),
            c.isXAxisTooltipEnabled && (c.xaxisTooltipText.innerHTML = "" !== f ? f : p);
          var v = a[t].querySelector(".apexcharts-tooltip-text-y-label");
          v && (v.innerHTML = r || "");
          var y = a[t].querySelector(".apexcharts-tooltip-text-y-value");
          y && (y.innerHTML = void 0 !== d ? d : ""), m[0] && m[0].classList.contains(
            "apexcharts-tooltip-marker") && (l.config.tooltip.marker.fillColors && Array.isArray(l.config
              .tooltip.marker.fillColors) && (o = l.config.tooltip.marker.fillColors[t]), m[0].style
            .backgroundColor = o), l.config.tooltip.marker.show || (m[0].style.display = "none");
          var h = a[t].querySelector(".apexcharts-tooltip-text-goals-label"),
            u = a[t].querySelector(".apexcharts-tooltip-text-goals-value");
          if (g.length && l.globals.seriesGoals[t]) {
            var b = function() {
              var S = "<div >",
                C = "<div>";
              g.forEach(function(L, M) {
                S +=
                  ' <div style="display: flex"><span class="apexcharts-tooltip-marker" style="background-color: '
                  .concat(L.attrs.strokeColor, '; height: 3px; border-radius: 0; top: 5px;"></span> ')
                  .concat(L.attrs.name, "</div>"), C += "<div>".concat(L.val, "</div>")
              }), h.innerHTML = S + "</div>", u.innerHTML = C + "</div>"
            };
            n ? l.globals.seriesGoals[t][i] && Array.isArray(l.globals.seriesGoals[t][i]) ? b() : (h
              .innerHTML = "", u.innerHTML = "") : b()
          } else h.innerHTML = "", u.innerHTML = "";
          if (null !== x && (a[t].querySelector(".apexcharts-tooltip-text-z-label").innerHTML = l.config
              .tooltip.z.title, a[t].querySelector(".apexcharts-tooltip-text-z-value").innerHTML = void 0 !==
              x ? x : ""), n && m[0]) {
            if (l.config.tooltip.hideEmptySeries) {
              var k = a[t].querySelector(".apexcharts-tooltip-marker"),
                A = a[t].querySelector(".apexcharts-tooltip-text");
              0 == parseFloat(d) ? (k.style.display = "none", A.style.display = "none") : (k.style.display =
                "block", A.style.display = "block")
            }
            m[0].parentNode.style.display = null == d || l.globals.ancillaryCollapsedSeriesIndices.indexOf(
              t) > -1 || l.globals.collapsedSeriesIndices.indexOf(t) > -1 ? "none" : l.config.tooltip.items
              .display
          }
        }
      }, {
        key: "toggleActiveInactiveSeries",
        value: function(e) {
          var t = this.w;
          if (e) this.tooltipUtil.toggleAllTooltipSeriesGroups("enable");
          else {
            this.tooltipUtil.toggleAllTooltipSeriesGroups("disable");
            var i = t.globals.dom.baseEl.querySelector(".apexcharts-tooltip-series-group");
            i && (i.classList.add("apexcharts-active"), i.style.display = t.config.tooltip.items.display)
          }
        }
      }, {
        key: "getValuesToPrint",
        value: function(e) {
          var t = e.i,
            i = e.j,
            a = this.w,
            s = this.ctx.series.filteredSeriesX(),
            r = "",
            n = "",
            o = null,
            l = null,
            c = {
              series: a.globals.series,
              seriesIndex: t,
              dataPointIndex: i,
              w: a
            },
            d = a.globals.ttZFormatter;
          null === i ? l = a.globals.series[t] : a.globals.isXNumeric && "treemap" !== a.config.chart.type ? (
              r = s[t][i], 0 === s[t].length && (r = s[this.tooltipUtil.getFirstActiveXArray(s)][i])) : r =
            void 0 !== a.globals.labels[i] ? a.globals.labels[i] : "";
          var g = r;
          return r = a.globals.isXNumeric && "datetime" === a.config.xaxis.type ? new me(this.ctx)
            .xLabelFormat(a.globals.ttKeyFormatter, g, g, {
              i: void 0,
              dateFormatter: new Q(this.ctx).formatDate,
              w: this.w
            }) : a.globals.isBarHorizontal ? a.globals.yLabelFormatters[0](g, c) : a.globals.xLabelFormatter(
              g, c), void 0 !== a.config.tooltip.x.formatter && (r = a.globals.ttKeyFormatter(g, c)), a
            .globals.seriesZ.length > 0 && a.globals.seriesZ[t].length > 0 && (o = d(a.globals.seriesZ[t][i],
              a)), n = "function" == typeof a.config.xaxis.tooltip.formatter ? a.globals
            .xaxisTooltipFormatter(g, c) : r, {
              val: Array.isArray(l) ? l.join(" ") : l,
              xVal: Array.isArray(r) ? r.join(" ") : r,
              xAxisTTVal: Array.isArray(n) ? n.join(" ") : n,
              zVal: o
            }
        }
      }, {
        key: "handleCustomTooltip",
        value: function(e) {
          var t = e.i,
            i = e.j,
            a = e.y1,
            s = e.y2,
            r = e.w,
            n = this.ttCtx.getElTooltip(),
            o = r.config.tooltip.custom;
          Array.isArray(o) && o[t] && (o = o[t]), n.innerHTML = o({
            ctx: this.ctx,
            series: r.globals.series,
            seriesIndex: t,
            dataPointIndex: i,
            y1: a,
            y2: s,
            w: r
          })
        }
      }]), w
    }(),
    Ke = function() {
      function w(e) {
        F(this, w), this.ttCtx = e, this.ctx = e.ctx, this.w = e.w
      }
      return R(w, [{
        key: "moveXCrosshairs",
        value: function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
            i = this.ttCtx,
            a = this.w,
            s = i.getElXCrosshairs(),
            r = e - i.xcrosshairsWidth / 2,
            n = a.globals.labels.slice().length;
          if (null !== t && (r = a.globals.gridWidth / n * t), null === s || a.globals.isBarHorizontal || (s
              .setAttribute("x", r), s.setAttribute("x1", r), s.setAttribute("x2", r), s.setAttribute("y2", a
                .globals.gridHeight), s.classList.add("apexcharts-active")), r < 0 && (r = 0), r > a.globals
            .gridWidth && (r = a.globals.gridWidth), i.isXAxisTooltipEnabled) {
            var o = r;
            "tickWidth" !== a.config.xaxis.crosshairs.width && "barWidth" !== a.config.xaxis.crosshairs
              .width || (o = r + i.xcrosshairsWidth / 2), this.moveXAxisTooltip(o)
          }
        }
      }, {
        key: "moveYCrosshairs",
        value: function(e) {
          var t = this.ttCtx;
          null !== t.ycrosshairs && X.setAttrs(t.ycrosshairs, {
            y1: e,
            y2: e
          }), null !== t.ycrosshairsHidden && X.setAttrs(t.ycrosshairsHidden, {
            y1: e,
            y2: e
          })
        }
      }, {
        key: "moveXAxisTooltip",
        value: function(e) {
          var t = this.w,
            i = this.ttCtx;
          if (null !== i.xaxisTooltip && 0 !== i.xcrosshairsWidth) {
            i.xaxisTooltip.classList.add("apexcharts-active");
            var s, a = i.xaxisOffY + t.config.xaxis.tooltip.offsetY + t.globals.translateY + 1 + t.config
              .xaxis.offsetY;
            e -= i.xaxisTooltip.getBoundingClientRect().width / 2, isNaN(e) || (e += t.globals.translateX, s =
              new X(this.ctx).getTextRects(i.xaxisTooltipText.innerHTML), i.xaxisTooltipText.style
              .minWidth = s.width + "px", i.xaxisTooltip.style.left = e + "px", i.xaxisTooltip.style.top =
              a + "px")
          }
        }
      }, {
        key: "moveYAxisTooltip",
        value: function(e) {
          var t = this.w,
            i = this.ttCtx;
          null === i.yaxisTTEls && (i.yaxisTTEls = t.globals.dom.baseEl.querySelectorAll(
            ".apexcharts-yaxistooltip"));
          var a = parseInt(i.ycrosshairsHidden.getAttribute("y1"), 10),
            s = t.globals.translateY + a,
            r = i.yaxisTTEls[e].getBoundingClientRect().height,
            n = t.globals.translateYAxisX[e] - 2;
          t.config.yaxis[e].opposite && (n -= 26), s -= r / 2, -1 === t.globals.ignoreYAxisIndexes.indexOf(
            e) ? (i.yaxisTTEls[e].classList.add("apexcharts-active"), i.yaxisTTEls[e].style.top = s + "px", i
              .yaxisTTEls[e].style.left = n + t.config.yaxis[e].tooltip.offsetX + "px") : i.yaxisTTEls[e]
            .classList.remove("apexcharts-active")
        }
      }, {
        key: "moveTooltip",
        value: function(e, t) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
            a = this.w,
            s = this.ttCtx,
            r = s.getElTooltip(),
            n = s.tooltipRect,
            o = null !== i ? parseFloat(i) : 1,
            l = parseFloat(e) + o + 5,
            c = parseFloat(t) + o / 2;
          if (l > a.globals.gridWidth / 2 && (l = l - n.ttWidth - o - 10), l > a.globals.gridWidth - n
            .ttWidth - 10 && (l = a.globals.gridWidth - n.ttWidth), l < -20 && (l = -20), a.config.tooltip
            .followCursor) {
            var d = s.getElGrid().getBoundingClientRect();
            (l = s.e.clientX - d.left) > a.globals.gridWidth / 2 && (l -= s.tooltipRect.ttWidth), (c = s.e
              .clientY + a.globals.translateY - d.top) > a.globals.gridHeight / 2 && (c -= s.tooltipRect
              .ttHeight)
          } else a.globals.isBarHorizontal || n.ttHeight / 2 + c > a.globals.gridHeight && (c = a.globals
            .gridHeight - n.ttHeight + a.globals.translateY);
          isNaN(l) || (r.style.left = (l += a.globals.translateX) + "px", r.style.top = c + "px")
        }
      }, {
        key: "moveMarkers",
        value: function(e, t) {
          var i = this.w,
            a = this.ttCtx;
          if (i.globals.markers.size[e] > 0)
            for (var s = i.globals.dom.baseEl.querySelectorAll(" .apexcharts-series[data\\:realIndex='"
                .concat(e, "'] .apexcharts-marker")), r = 0; r < s.length; r++) parseInt(s[r].getAttribute(
              "rel"), 10) === t && (a.marker.resetPointsSize(), a.marker.enlargeCurrentPoint(t, s[r]));
          else a.marker.resetPointsSize(), this.moveDynamicPointOnHover(t, e)
        }
      }, {
        key: "moveDynamicPointOnHover",
        value: function(e, t) {
          var i, a, s = this.w,
            r = this.ttCtx,
            n = s.globals.pointsArray,
            o = r.tooltipUtil.getHoverMarkerSize(t),
            l = s.config.series[t].type;
          if (!l || "column" !== l && "candlestick" !== l && "boxPlot" !== l) {
            i = n[t][e][0], a = n[t][e][1] ? n[t][e][1] : 0;
            var c = s.globals.dom.baseEl.querySelector(".apexcharts-series[data\\:realIndex='".concat(t,
              "'] .apexcharts-series-markers circle"));
            c && a < s.globals.gridHeight && a > 0 && (c.setAttribute("r", o), c.setAttribute("cx", i), c
              .setAttribute("cy", a)), this.moveXCrosshairs(i), r.fixedTooltip || this.moveTooltip(i, a, o)
          }
        }
      }, {
        key: "moveDynamicPointsOnHover",
        value: function(e) {
          var t, i = this.ttCtx,
            a = i.w,
            s = 0,
            r = 0,
            n = a.globals.pointsArray;
          t = new se(this.ctx).getActiveConfigSeriesIndex("asc", ["line", "area", "scatter", "bubble"]);
          var o = i.tooltipUtil.getHoverMarkerSize(t);
          n[t] && (s = n[t][e][0], r = n[t][e][1]);
          var l = i.tooltipUtil.getAllMarkers();
          if (null !== l)
            for (var c = 0; c < a.globals.series.length; c++) {
              var d = n[c];
              if (a.globals.comboCharts && void 0 === d && l.splice(c, 0, null), d && d.length) {
                var g = n[c][e][1];
                l[c].setAttribute("cx", s), "rangeArea" !== a.config.chart.type || a.globals.comboCharts || (
                    g -= Math.abs(g - n[c][e + a.globals.series[c].length][1]) / 2), null !== g && !isNaN(
                  g) && g < a.globals.gridHeight + o && g + o > 0 ? (l[c] && l[c].setAttribute("r", o), l[
                    c] && l[c].setAttribute("cy", g)) : l[c] && l[c].setAttribute("r", 0)
              }
            }
          this.moveXCrosshairs(s), i.fixedTooltip || this.moveTooltip(s, r || a.globals.gridHeight, o)
        }
      }, {
        key: "moveStickyTooltipOverBars",
        value: function(e, t) {
          var i = this.w,
            a = this.ttCtx,
            s = i.globals.columnSeries ? i.globals.columnSeries.length : i.globals.series.length,
            r = s >= 2 && s % 2 == 0 ? Math.floor(s / 2) : Math.floor(s / 2) + 1;
          i.globals.isBarHorizontal && (r = new se(this.ctx).getActiveConfigSeriesIndex("desc") + 1);
          var n = i.globals.dom.baseEl.querySelector(".apexcharts-bar-series .apexcharts-series[rel='".concat(
              r, "'] path[j='").concat(e, "'], .apexcharts-candlestick-series .apexcharts-series[rel='")
            .concat(r, "'] path[j='").concat(e, "'], .apexcharts-boxPlot-series .apexcharts-series[rel='")
            .concat(r, "'] path[j='").concat(e, "'], .apexcharts-rangebar-series .apexcharts-series[rel='")
            .concat(r, "'] path[j='").concat(e, "']"));
          n || "number" != typeof t || (n = i.globals.dom.baseEl.querySelector(
            ".apexcharts-bar-series .apexcharts-series[data\\:realIndex='".concat(t, "'] path[j='")
            .concat(e,
              "'],\n        .apexcharts-candlestick-series .apexcharts-series[data\\:realIndex='").concat(
              t, "'] path[j='").concat(e,
              "'],\n        .apexcharts-boxPlot-series .apexcharts-series[data\\:realIndex='").concat(t,
              "'] path[j='").concat(e,
              "'],\n        .apexcharts-rangebar-series .apexcharts-series[data\\:realIndex='").concat(t,
              "'] path[j='").concat(e, "']")));
          var o = n ? parseFloat(n.getAttribute("cx")) : 0,
            l = n ? parseFloat(n.getAttribute("cy")) : 0,
            c = n ? parseFloat(n.getAttribute("barWidth")) : 0,
            d = a.getElGrid().getBoundingClientRect(),
            g = n && (n.classList.contains("apexcharts-candlestick-area") || n.classList.contains(
              "apexcharts-boxPlot-area"));
          i.globals.isXNumeric ? (n && !g && (o -= s % 2 != 0 ? c / 2 : 0), n && g && i.globals.comboCharts &&
              (o -= c / 2)) : i.globals.isBarHorizontal || (o = a.xAxisTicksPositions[e - 1] + a
              .dataPointsDividedWidth / 2, isNaN(o) && (o = a.xAxisTicksPositions[e] - a
                .dataPointsDividedWidth / 2)), i.globals.isBarHorizontal ? l -= a.tooltipRect.ttHeight : i
            .config.tooltip.followCursor ? l = a.e.clientY - d.top - a.tooltipRect.ttHeight / 2 : l + a
            .tooltipRect.ttHeight + 15 > i.globals.gridHeight && (l = i.globals.gridHeight), i.globals
            .isBarHorizontal || this.moveXCrosshairs(o), a.fixedTooltip || this.moveTooltip(o, l || i.globals
              .gridHeight)
        }
      }]), w
    }(),
    Ct = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.ttCtx = e, this.ctx = e.ctx, this.tooltipPosition = new Ke(e)
      }
      return R(w, [{
        key: "drawDynamicPoints",
        value: function() {
          var e = this.w,
            t = new X(this.ctx),
            i = new we(this.ctx),
            a = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series");
          a = J(a), e.config.chart.stacked && a.sort(function(d, g) {
            return parseFloat(d.getAttribute("data:realIndex")) - parseFloat(g.getAttribute(
              "data:realIndex"))
          });
          for (var s = 0; s < a.length; s++) {
            var r = a[s].querySelector(".apexcharts-series-markers-wrap");
            if (null !== r) {
              var n = void 0,
                o = "apexcharts-marker w".concat((Math.random() + 1).toString(36).substring(4));
              "line" !== e.config.chart.type && "area" !== e.config.chart.type || e.globals.comboCharts || e
                .config.tooltip.intersect || (o += " no-pointer-events");
              var l = i.getMarkerConfig({
                cssClass: o,
                seriesIndex: Number(r.getAttribute("data:realIndex"))
              });
              (n = t.drawMarker(0, 0, l)).node.setAttribute("default-marker-size", 0);
              var c = document.createElementNS(e.globals.SVGNS, "g");
              c.classList.add("apexcharts-series-markers"), c.appendChild(n.node), r.appendChild(c)
            }
          }
        }
      }, {
        key: "enlargeCurrentPoint",
        value: function(e, t) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : null,
            a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null,
            s = this.w;
          "bubble" !== s.config.chart.type && this.newPointSize(e, t);
          var r = t.getAttribute("cx"),
            n = t.getAttribute("cy");
          if (null !== i && null !== a && (r = i, n = a), this.tooltipPosition.moveXCrosshairs(r), !this
            .fixedTooltip) {
            if ("radar" === s.config.chart.type) {
              var o = this.ttCtx.getElGrid().getBoundingClientRect();
              r = this.ttCtx.e.clientX - o.left
            }
            this.tooltipPosition.moveTooltip(r, n, s.config.markers.hover.size)
          }
        }
      }, {
        key: "enlargePoints",
        value: function(e) {
          for (var t = this.w, i = this, a = this.ttCtx, s = e, r = t.globals.dom.baseEl.querySelectorAll(
                ".apexcharts-series:not(.apexcharts-series-collapsed) .apexcharts-marker"), n = t.config
              .markers.hover.size, o = 0; o < r.length; o++) {
            var l = r[o].getAttribute("rel"),
              c = r[o].getAttribute("index");
            if (void 0 === n && (n = t.globals.markers.size[c] + t.config.markers.hover.sizeOffset), s ===
              parseInt(l, 10)) {
              i.newPointSize(s, r[o]);
              var d = r[o].getAttribute("cx"),
                g = r[o].getAttribute("cy");
              i.tooltipPosition.moveXCrosshairs(d), a.fixedTooltip || i.tooltipPosition.moveTooltip(d, g, n)
            } else i.oldPointSize(r[o])
          }
        }
      }, {
        key: "newPointSize",
        value: function(e, t) {
          var i = this.w,
            a = i.config.markers.hover.size,
            s = 0 === e ? t.parentNode.firstChild : t.parentNode.lastChild;
          if ("0" !== s.getAttribute("default-marker-size")) {
            var r = parseInt(s.getAttribute("index"), 10);
            void 0 === a && (a = i.globals.markers.size[r] + i.config.markers.hover.sizeOffset), a < 0 && (a =
              0), s.setAttribute("r", a)
          }
        }
      }, {
        key: "oldPointSize",
        value: function(e) {
          var t = parseFloat(e.getAttribute("default-marker-size"));
          e.setAttribute("r", t)
        }
      }, {
        key: "resetPointsSize",
        value: function() {
          for (var e = this.w.globals.dom.baseEl.querySelectorAll(
              ".apexcharts-series:not(.apexcharts-series-collapsed) .apexcharts-marker"), t = 0; t < e
            .length; t++) {
            var i = parseFloat(e[t].getAttribute("default-marker-size"));
            P.isNumber(i) && i >= 0 ? e[t].setAttribute("r", i) : e[t].setAttribute("r", 0)
          }
        }
      }]), w
    }(),
    Lt = function() {
      function w(e) {
        F(this, w), this.w = e.w;
        var t = this.w;
        this.ttCtx = e, this.isVerticalGroupedRangeBar = !t.globals.isBarHorizontal && "rangeBar" === t.config.chart
          .type && t.config.plotOptions.bar.rangeBarGroupRows
      }
      return R(w, [{
        key: "getAttr",
        value: function(e, t) {
          return parseFloat(e.target.getAttribute(t))
        }
      }, {
        key: "handleHeatTreeTooltip",
        value: function(e) {
          var t = e.e,
            i = e.opt,
            a = e.x,
            s = e.y,
            n = this.ttCtx,
            o = this.w;
          if (t.target.classList.contains("apexcharts-".concat(e.type, "-rect"))) {
            var l = this.getAttr(t, "i"),
              c = this.getAttr(t, "j"),
              d = this.getAttr(t, "cx"),
              g = this.getAttr(t, "cy"),
              p = this.getAttr(t, "width"),
              f = this.getAttr(t, "height");
            if (n.tooltipLabels.drawSeriesTexts({
                ttItems: i.ttItems,
                i: l,
                j: c,
                shared: !1,
                e: t
              }), o.globals.capturedSeriesIndex = l, o.globals.capturedDataPointIndex = c, a = d + n
              .tooltipRect.ttWidth / 2 + p, s = g + n.tooltipRect.ttHeight / 2 - f / 2, n.tooltipPosition
              .moveXCrosshairs(d + p / 2), a > o.globals.gridWidth / 2 && (a = d - n.tooltipRect.ttWidth / 2 +
                p), n.w.config.tooltip.followCursor) {
              var x = o.globals.dom.elWrap.getBoundingClientRect();
              a = o.globals.clientX - x.left - (a > o.globals.gridWidth / 2 ? n.tooltipRect.ttWidth : 0), s =
                o.globals.clientY - x.top - (s > o.globals.gridHeight / 2 ? n.tooltipRect.ttHeight : 0)
            }
          }
          return {
            x: a,
            y: s
          }
        }
      }, {
        key: "handleMarkerTooltip",
        value: function(e) {
          var t, i, a = e.e,
            s = e.opt,
            r = e.x,
            n = e.y,
            o = this.w,
            l = this.ttCtx;
          if (a.target.classList.contains("apexcharts-marker")) {
            var c = parseInt(s.paths.getAttribute("cx"), 10),
              d = parseInt(s.paths.getAttribute("cy"), 10),
              g = parseFloat(s.paths.getAttribute("val"));
            if (i = parseInt(s.paths.getAttribute("rel"), 10), t = parseInt(s.paths.parentNode.parentNode
                .parentNode.getAttribute("rel"), 10) - 1, l.intersect) {
              var p = P.findAncestor(s.paths, "apexcharts-series");
              p && (t = parseInt(p.getAttribute("data:realIndex"), 10))
            }
            if (l.tooltipLabels.drawSeriesTexts({
                ttItems: s.ttItems,
                i: t,
                j: i,
                shared: !l.showOnIntersect && o.config.tooltip.shared,
                e: a
              }), "mouseup" === a.type && l.markerClick(a, t, i), o.globals.capturedSeriesIndex = t, o.globals
              .capturedDataPointIndex = i, r = c, n = d + o.globals.translateY - 1.4 * l.tooltipRect.ttHeight,
              l.w.config.tooltip.followCursor) {
              var f = l.getElGrid().getBoundingClientRect();
              n = l.e.clientY + o.globals.translateY - f.top
            }
            g < 0 && (n = d), l.marker.enlargeCurrentPoint(i, s.paths, r, n)
          }
          return {
            x: r,
            y: n
          }
        }
      }, {
        key: "handleBarTooltip",
        value: function(e) {
          var t, i, a = e.e,
            s = e.opt,
            r = this.w,
            n = this.ttCtx,
            o = n.getElTooltip(),
            l = 0,
            c = 0,
            d = 0,
            g = this.getBarTooltipXY({
              e: a,
              opt: s
            }),
            p = g.barHeight,
            f = g.j;
          r.globals.capturedSeriesIndex = t = g.i, r.globals.capturedDataPointIndex = f, r.globals
            .isBarHorizontal && n.tooltipUtil.hasBars() || !r.config.tooltip.shared ? (c = g.x, d = g.y, i =
              Array.isArray(r.config.stroke.width) ? r.config.stroke.width[t] : r.config.stroke.width, l = c
              ) : r.globals.comboCharts || r.config.tooltip.shared || (l /= 2), isNaN(d) && (d = r.globals
              .svgHeight - n.tooltipRect.ttHeight);
          var x = parseInt(s.paths.parentNode.getAttribute("data:realIndex"), 10),
            m = r.globals.isMultipleYAxis ? r.config.yaxis[x] && r.config.yaxis[x].reversed : r.config.yaxis[
              0].reversed;
          if (c + n.tooltipRect.ttWidth > r.globals.gridWidth && !m ? c -= n.tooltipRect.ttWidth : c < 0 && (
              c = 0), n.w.config.tooltip.followCursor) {
            var v = n.getElGrid().getBoundingClientRect();
            d = n.e.clientY - v.top
          }
          null === n.tooltip && (n.tooltip = r.globals.dom.baseEl.querySelector(".apexcharts-tooltip")), r
            .config.tooltip.shared || n.tooltipPosition.moveXCrosshairs(r.globals.comboBarCount > 0 ? l + i /
              2 : l), !n.fixedTooltip && (!r.config.tooltip.shared || r.globals.isBarHorizontal && n
              .tooltipUtil.hasBars()) && (m && (c -= n.tooltipRect.ttWidth) < 0 && (c = 0), !m || r.globals
              .isBarHorizontal && n.tooltipUtil.hasBars() || (d = d + p - 2 * (r.globals.series[t][f] < 0 ?
                p : 0)), d = d + r.globals.translateY - n.tooltipRect.ttHeight / 2, o.style.left = c + r
              .globals.translateX + "px", o.style.top = d + "px")
        }
      }, {
        key: "getBarTooltipXY",
        value: function(e) {
          var t = this,
            i = e.e,
            a = e.opt,
            s = this.w,
            r = null,
            n = this.ttCtx,
            o = 0,
            l = 0,
            c = 0,
            d = 0,
            g = 0,
            p = i.target.classList;
          if (p.contains("apexcharts-bar-area") || p.contains("apexcharts-candlestick-area") || p.contains(
              "apexcharts-boxPlot-area") || p.contains("apexcharts-rangebar-area")) {
            var f = i.target,
              x = f.getBoundingClientRect(),
              m = a.elGrid.getBoundingClientRect(),
              v = x.height;
            g = x.height;
            var y = x.width,
              h = parseInt(f.getAttribute("cx"), 10),
              u = parseInt(f.getAttribute("cy"), 10);
            d = parseFloat(f.getAttribute("barWidth"));
            var b = "touchmove" === i.type ? i.touches[0].clientX : i.clientX;
            r = parseInt(f.getAttribute("j"), 10), o = parseInt(f.parentNode.getAttribute("rel"), 10) - 1;
            var k = f.getAttribute("data-range-y1"),
              A = f.getAttribute("data-range-y2");
            s.globals.comboCharts && (o = parseInt(f.parentNode.getAttribute("data:realIndex"), 10));
            var S = function(L) {
                return s.globals.isXNumeric ? h - y / 2 : t.isVerticalGroupedRangeBar ? h + y / 2 : h - n
                  .dataPointsDividedWidth + y / 2
              },
              C = function() {
                return u - n.dataPointsDividedHeight + v / 2 - n.tooltipRect.ttHeight / 2
              };
            n.tooltipLabels.drawSeriesTexts({
                ttItems: a.ttItems,
                i: o,
                j: r,
                y1: k ? parseInt(k, 10) : null,
                y2: A ? parseInt(A, 10) : null,
                shared: !n.showOnIntersect && s.config.tooltip.shared,
                e: i
              }), s.config.tooltip.followCursor ? s.globals.isBarHorizontal ? (l = b - m.left + 15, c = C()) :
              (l = S(), c = i.clientY - m.top - n.tooltipRect.ttHeight / 2 - 15) : s.globals.isBarHorizontal ?
              ((l = h) < n.xyRatios.baseLineInvertedY && (l = h - n.tooltipRect.ttWidth), c = C()) : (l = S(),
                c = u)
          }
          return {
            x: l,
            y: c,
            barHeight: g,
            barWidth: d,
            i: o,
            j: r
          }
        }
      }]), w
    }(),
    Pt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.ttCtx = e
      }
      return R(w, [{
        key: "drawXaxisTooltip",
        value: function() {
          var e = this.w,
            t = this.ttCtx,
            i = "bottom" === e.config.xaxis.position;
          t.xaxisOffY = i ? e.globals.gridHeight + 1 : -e.globals.xAxisHeight - e.config.xaxis.axisTicks
            .height + 3;
          var a = i ? "apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom" :
            "apexcharts-xaxistooltip apexcharts-xaxistooltip-top",
            s = e.globals.dom.elWrap;
          t.isXAxisTooltipEnabled && null === e.globals.dom.baseEl.querySelector(
            ".apexcharts-xaxistooltip") && (t.xaxisTooltip = document.createElement("div"), t.xaxisTooltip
              .setAttribute("class", a + " apexcharts-theme-" + e.config.tooltip.theme), s.appendChild(t
                .xaxisTooltip), t.xaxisTooltipText = document.createElement("div"), t.xaxisTooltipText
              .classList.add("apexcharts-xaxistooltip-text"), t.xaxisTooltipText.style.fontFamily = e.config
              .xaxis.tooltip.style.fontFamily || e.config.chart.fontFamily, t.xaxisTooltipText.style
              .fontSize = e.config.xaxis.tooltip.style.fontSize, t.xaxisTooltip.appendChild(t
                .xaxisTooltipText))
        }
      }, {
        key: "drawYaxisTooltip",
        value: function() {
          for (var e = this.w, t = this.ttCtx, i = 0; i < e.config.yaxis.length; i++) {
            var a = e.config.yaxis[i].opposite || e.config.yaxis[i].crosshairs.opposite;
            t.yaxisOffX = a ? e.globals.gridWidth + 1 : 1;
            var s = "apexcharts-yaxistooltip apexcharts-yaxistooltip-".concat(i, a ?
                " apexcharts-yaxistooltip-right" : " apexcharts-yaxistooltip-left"),
              r = e.globals.dom.elWrap;
            null === e.globals.dom.baseEl.querySelector(".apexcharts-yaxistooltip apexcharts-yaxistooltip-"
              .concat(i)) && (t.yaxisTooltip = document.createElement("div"), t.yaxisTooltip.setAttribute(
                "class", s + " apexcharts-theme-" + e.config.tooltip.theme), r.appendChild(t.yaxisTooltip),
              0 === i && (t.yaxisTooltipText = []), t.yaxisTooltipText[i] = document.createElement("div"), t
              .yaxisTooltipText[i].classList.add("apexcharts-yaxistooltip-text"), t.yaxisTooltip
              .appendChild(t.yaxisTooltipText[i]))
          }
        }
      }, {
        key: "setXCrosshairWidth",
        value: function() {
          var e = this.w,
            t = this.ttCtx,
            i = t.getElXCrosshairs();
          if (t.xcrosshairsWidth = parseInt(e.config.xaxis.crosshairs.width, 10), e.globals.comboCharts) {
            var a = e.globals.dom.baseEl.querySelector(".apexcharts-bar-area");
            if (null !== a && "barWidth" === e.config.xaxis.crosshairs.width) {
              var s = parseFloat(a.getAttribute("barWidth"));
              t.xcrosshairsWidth = s
            } else "tickWidth" === e.config.xaxis.crosshairs.width && (t.xcrosshairsWidth = e.globals
              .gridWidth / e.globals.labels.length)
          } else if ("tickWidth" === e.config.xaxis.crosshairs.width) t.xcrosshairsWidth = e.globals
            .gridWidth / e.globals.labels.length;
          else if ("barWidth" === e.config.xaxis.crosshairs.width) {
            var o = e.globals.dom.baseEl.querySelector(".apexcharts-bar-area");
            if (null !== o) {
              var l = parseFloat(o.getAttribute("barWidth"));
              t.xcrosshairsWidth = l
            } else t.xcrosshairsWidth = 1
          }
          e.globals.isBarHorizontal && (t.xcrosshairsWidth = 0), null !== i && t.xcrosshairsWidth > 0 && i
            .setAttribute("width", t.xcrosshairsWidth)
        }
      }, {
        key: "handleYCrosshair",
        value: function() {
          var e = this.w,
            t = this.ttCtx;
          t.ycrosshairs = e.globals.dom.baseEl.querySelector(".apexcharts-ycrosshairs"), t.ycrosshairsHidden =
            e.globals.dom.baseEl.querySelector(".apexcharts-ycrosshairs-hidden")
        }
      }, {
        key: "drawYaxisTooltipText",
        value: function(e, t, i) {
          var a = this.ttCtx,
            s = this.w,
            r = s.globals,
            n = r.seriesYAxisMap[e];
          if (a.yaxisTooltips[e] && n.length > 0) {
            var o = r.yLabelFormatters[e],
              l = a.getElGrid().getBoundingClientRect(),
              c = n[0];
            i.yRatio.length > 1 && function(f) {
              throw new TypeError('"translationsIndex" is read-only')
            }();
            var d = (t - l.top) * i.yRatio[0],
              g = r.maxYArr[c] - r.minYArr[c],
              p = r.minYArr[c] + (g - d);
            s.config.yaxis[e].reversed && (p = r.maxYArr[c] - (g - d)), a.tooltipPosition.moveYCrosshairs(t -
              l.top), a.yaxisTooltipText[e].innerHTML = o(p), a.tooltipPosition.moveYAxisTooltip(e)
          }
        }
      }]), w
    }(),
    et = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w;
        var t = this.w;
        this.tConfig = t.config.tooltip, this.tooltipUtil = new Qe(this), this.tooltipLabels = new St(this), this
          .tooltipPosition = new Ke(this), this.marker = new Ct(this), this.intersect = new Lt(this), this
          .axesTooltip = new Pt(this), this.showOnIntersect = this.tConfig.intersect, this.showTooltipTitle = this
          .tConfig.x.show, this.fixedTooltip = this.tConfig.fixed.enabled, this.xaxisTooltip = null, this.yaxisTTEls =
          null, this.isBarShared = !t.globals.isBarHorizontal && this.tConfig.shared, this.lastHoverTime = Date.now()
      }
      return R(w, [{
        key: "getElTooltip",
        value: function(e) {
          return e || (e = this), e.w.globals.dom.baseEl ? e.w.globals.dom.baseEl.querySelector(
            ".apexcharts-tooltip") : null
        }
      }, {
        key: "getElXCrosshairs",
        value: function() {
          return this.w.globals.dom.baseEl.querySelector(".apexcharts-xcrosshairs")
        }
      }, {
        key: "getElGrid",
        value: function() {
          return this.w.globals.dom.baseEl.querySelector(".apexcharts-grid")
        }
      }, {
        key: "drawTooltip",
        value: function(e) {
          var t = this.w;
          this.xyRatios = e, this.isXAxisTooltipEnabled = t.config.xaxis.tooltip.enabled && t.globals
            .axisCharts, this.yaxisTooltips = t.config.yaxis.map(function(r, n) {
              return !!(r.show && r.tooltip.enabled && t.globals.axisCharts)
            }), this.allTooltipSeriesGroups = [], t.globals.axisCharts || (this.showTooltipTitle = !1);
          var i = document.createElement("div");
          if (i.classList.add("apexcharts-tooltip"), t.config.tooltip.cssClass && i.classList.add(t.config
              .tooltip.cssClass), i.classList.add("apexcharts-theme-".concat(this.tConfig.theme)), t.globals
            .dom.elWrap.appendChild(i), t.globals.axisCharts) {
            this.axesTooltip.drawXaxisTooltip(), this.axesTooltip.drawYaxisTooltip(), this.axesTooltip
              .setXCrosshairWidth(), this.axesTooltip.handleYCrosshair();
            var a = new ke(this.ctx);
            this.xAxisTicksPositions = a.getXAxisTicksPositions()
          }
          if (!t.globals.comboCharts && !this.tConfig.intersect && "rangeBar" !== t.config.chart.type || this
            .tConfig.shared || (this.showOnIntersect = !0), 0 !== t.config.markers.size && 0 !== t.globals
            .markers.largestSize || this.marker.drawDynamicPoints(this), t.globals.collapsedSeries.length !==
            t.globals.series.length) {
            this.dataPointsDividedHeight = t.globals.gridHeight / t.globals.dataPoints, this
              .dataPointsDividedWidth = t.globals.gridWidth / t.globals.dataPoints, this.showTooltipTitle && (
                this.tooltipTitle = document.createElement("div"), this.tooltipTitle.classList.add(
                  "apexcharts-tooltip-title"), this.tooltipTitle.style.fontFamily = this.tConfig.style
                .fontFamily || t.config.chart.fontFamily, this.tooltipTitle.style.fontSize = this.tConfig
                .style.fontSize, i.appendChild(this.tooltipTitle));
            var s = t.globals.series.length;
            (t.globals.xyCharts || t.globals.comboCharts) && this.tConfig.shared && (s = this
                .showOnIntersect ? 1 : t.globals.series.length), this.legendLabels = t.globals.dom.baseEl
              .querySelectorAll(".apexcharts-legend-text"), this.ttItems = this.createTTElements(s), this
              .addSVGEvents()
          }
        }
      }, {
        key: "createTTElements",
        value: function(e) {
          for (var t = this, i = this.w, a = [], s = this.getElTooltip(), r = function(o) {
              var l = document.createElement("div");
              l.classList.add("apexcharts-tooltip-series-group"), l.style.order = i.config.tooltip
                .inverseOrder ? e - o : o + 1, t.tConfig.shared && t.tConfig.enabledOnSeries && Array
                .isArray(t.tConfig.enabledOnSeries) && t.tConfig.enabledOnSeries.indexOf(o) < 0 && l
                .classList.add("apexcharts-tooltip-series-group-hidden");
              var c = document.createElement("span");
              c.classList.add("apexcharts-tooltip-marker"), c.style.backgroundColor = i.globals.colors[o], l
                .appendChild(c);
              var d = document.createElement("div");
              d.classList.add("apexcharts-tooltip-text"), d.style.fontFamily = t.tConfig.style.fontFamily ||
                i.config.chart.fontFamily, d.style.fontSize = t.tConfig.style.fontSize, ["y", "goals", "z"]
                .forEach(function(g) {
                  var p = document.createElement("div");
                  p.classList.add("apexcharts-tooltip-".concat(g, "-group"));
                  var f = document.createElement("span");
                  f.classList.add("apexcharts-tooltip-text-".concat(g, "-label")), p.appendChild(f);
                  var x = document.createElement("span");
                  x.classList.add("apexcharts-tooltip-text-".concat(g, "-value")), p.appendChild(x), d
                    .appendChild(p)
                }), l.appendChild(d), s.appendChild(l), a.push(l)
            }, n = 0; n < e; n++) r(n);
          return a
        }
      }, {
        key: "addSVGEvents",
        value: function() {
          var e = this.w,
            t = e.config.chart.type,
            i = this.getElTooltip(),
            a = !("bar" !== t && "candlestick" !== t && "boxPlot" !== t && "rangeBar" !== t),
            s = "area" === t || "line" === t || "scatter" === t || "bubble" === t || "radar" === t,
            r = e.globals.dom.Paper.node,
            n = this.getElGrid();
          n && (this.seriesBound = n.getBoundingClientRect());
          var o, l = [],
            c = [],
            d = {
              hoverArea: r,
              elGrid: n,
              tooltipEl: i,
              tooltipY: l,
              tooltipX: c,
              ttItems: this.ttItems
            };
          if (e.globals.axisCharts && (s ? o = e.globals.dom.baseEl.querySelectorAll(
                ".apexcharts-series[data\\:longestSeries='true'] .apexcharts-marker") : a ? o = e.globals.dom
              .baseEl.querySelectorAll(
                ".apexcharts-series .apexcharts-bar-area, .apexcharts-series .apexcharts-candlestick-area, .apexcharts-series .apexcharts-boxPlot-area, .apexcharts-series .apexcharts-rangebar-area"
                ) : "heatmap" !== t && "treemap" !== t || (o = e.globals.dom.baseEl.querySelectorAll(
                ".apexcharts-series .apexcharts-heatmap, .apexcharts-series .apexcharts-treemap")), o && o
              .length))
            for (var g = 0; g < o.length; g++) l.push(o[g].getAttribute("cy")), c.push(o[g].getAttribute(
              "cx"));
          if (e.globals.xyCharts && !this.showOnIntersect || e.globals.comboCharts && !this.showOnIntersect ||
            a && this.tooltipUtil.hasBars() && this.tConfig.shared) this.addPathsEventListeners([r], d);
          else if (a && !e.globals.comboCharts || s && this.showOnIntersect) this.addDatapointEventsListeners(
            d);
          else if (!e.globals.axisCharts || "heatmap" === t || "treemap" === t) {
            var p = e.globals.dom.baseEl.querySelectorAll(".apexcharts-series");
            this.addPathsEventListeners(p, d)
          }
          if (this.showOnIntersect) {
            var f = e.globals.dom.baseEl.querySelectorAll(
              ".apexcharts-line-series .apexcharts-marker, .apexcharts-area-series .apexcharts-marker");
            f.length > 0 && this.addPathsEventListeners(f, d), this.tooltipUtil.hasBars() && !this.tConfig
              .shared && this.addDatapointEventsListeners(d)
          }
        }
      }, {
        key: "drawFixedTooltipRect",
        value: function() {
          var e = this.w,
            t = this.getElTooltip(),
            i = t.getBoundingClientRect(),
            a = i.width + 10,
            s = i.height + 10,
            r = this.tConfig.fixed.offsetX,
            n = this.tConfig.fixed.offsetY,
            o = this.tConfig.fixed.position.toLowerCase();
          return o.indexOf("right") > -1 && (r = r + e.globals.svgWidth - a + 10), o.indexOf("bottom") > -1 &&
            (n = n + e.globals.svgHeight - s - 10), t.style.left = r + "px", t.style.top = n + "px", {
              x: r,
              y: n,
              ttWidth: a,
              ttHeight: s
            }
        }
      }, {
        key: "addDatapointEventsListeners",
        value: function(e) {
          var t = this.w.globals.dom.baseEl.querySelectorAll(
            ".apexcharts-series-markers .apexcharts-marker, .apexcharts-bar-area, .apexcharts-candlestick-area, .apexcharts-boxPlot-area, .apexcharts-rangebar-area"
            );
          this.addPathsEventListeners(t, e)
        }
      }, {
        key: "addPathsEventListeners",
        value: function(e, t) {
          for (var i = this, a = function(r) {
              var n = {
                paths: e[r],
                tooltipEl: t.tooltipEl,
                tooltipY: t.tooltipY,
                tooltipX: t.tooltipX,
                elGrid: t.elGrid,
                hoverArea: t.hoverArea,
                ttItems: t.ttItems
              };
              ["mousemove", "mouseup", "touchmove", "mouseout", "touchend"].map(function(o) {
                return e[r].addEventListener(o, i.onSeriesHover.bind(i, n), {
                  capture: !1,
                  passive: !0
                })
              })
            }, s = 0; s < e.length; s++) a(s)
        }
      }, {
        key: "onSeriesHover",
        value: function(e, t) {
          var i = this,
            a = Date.now() - this.lastHoverTime;
          a >= 100 ? this.seriesHover(e, t) : (clearTimeout(this.seriesHoverTimeout), this
            .seriesHoverTimeout = setTimeout(function() {
              i.seriesHover(e, t)
            }, 100 - a))
        }
      }, {
        key: "seriesHover",
        value: function(e, t) {
          var i = this;
          this.lastHoverTime = Date.now();
          var a = [],
            s = this.w;
          s.config.chart.group && (a = this.ctx.getGroupedCharts()), s.globals.axisCharts && (s.globals
            .minX === -1 / 0 && s.globals.maxX === 1 / 0 || 0 === s.globals.dataPoints) || (a.length ? a
            .forEach(function(r) {
              var n = i.getElTooltip(r);
              r.w.globals.minX === i.w.globals.minX && r.w.globals.maxX === i.w.globals.maxX && r.w
                .globals.tooltip.seriesHoverByContext({
                  chartCtx: r,
                  ttCtx: r.w.globals.tooltip,
                  opt: {
                    paths: e.paths,
                    tooltipEl: n,
                    tooltipY: e.tooltipY,
                    tooltipX: e.tooltipX,
                    elGrid: e.elGrid,
                    hoverArea: e.hoverArea,
                    ttItems: r.w.globals.tooltip.ttItems
                  },
                  e: t
                })
            }) : this.seriesHoverByContext({
              chartCtx: this.ctx,
              ttCtx: this.w.globals.tooltip,
              opt: e,
              e: t
            }))
        }
      }, {
        key: "seriesHoverByContext",
        value: function(e) {
          var t = e.chartCtx,
            i = e.ttCtx,
            a = e.opt,
            s = e.e,
            r = t.w,
            n = this.getElTooltip();
          n && (i.tooltipRect = {
              x: 0,
              y: 0,
              ttWidth: n.getBoundingClientRect().width,
              ttHeight: n.getBoundingClientRect().height
            }, i.e = s, i.tooltipUtil.hasBars() && !r.globals.comboCharts && !i.isBarShared && this.tConfig
            .onDatasetHover.highlightDataSeries && new se(t).toggleSeriesOnHover(s, s.target.parentNode), i
            .fixedTooltip && i.drawFixedTooltipRect(), r.globals.axisCharts ? i.axisChartsTooltips({
              e: s,
              opt: a,
              tooltipRect: i.tooltipRect
            }) : i.nonAxisChartsTooltips({
              e: s,
              opt: a,
              tooltipRect: i.tooltipRect
            }))
        }
      }, {
        key: "axisChartsTooltips",
        value: function(e) {
          var t, i, a = e.e,
            s = e.opt,
            r = this.w,
            n = s.elGrid.getBoundingClientRect(),
            o = "touchmove" === a.type ? a.touches[0].clientX : a.clientX,
            l = "touchmove" === a.type ? a.touches[0].clientY : a.clientY;
          if (this.clientY = l, this.clientX = o, r.globals.capturedSeriesIndex = -1, r.globals
            .capturedDataPointIndex = -1, l < n.top || l > n.top + n.height) this.handleMouseOut(s);
          else {
            if (Array.isArray(this.tConfig.enabledOnSeries) && !r.config.tooltip.shared) {
              var c = parseInt(s.paths.getAttribute("index"), 10);
              if (this.tConfig.enabledOnSeries.indexOf(c) < 0) return void this.handleMouseOut(s)
            }
            var d = this.getElTooltip(),
              g = this.getElXCrosshairs(),
              p = r.globals.xyCharts || "bar" === r.config.chart.type && !r.globals.isBarHorizontal && this
              .tooltipUtil.hasBars() && this.tConfig.shared || r.globals.comboCharts && this.tooltipUtil
              .hasBars();
            if ("mousemove" === a.type || "touchmove" === a.type || "mouseup" === a.type) {
              if (r.globals.collapsedSeries.length + r.globals.ancillaryCollapsedSeries.length === r.globals
                .series.length) return;
              null !== g && g.classList.add("apexcharts-active");
              var f = this.yaxisTooltips.filter(function(v) {
                return !0 === v
              });
              if (null !== this.ycrosshairs && f.length && this.ycrosshairs.classList.add(
                "apexcharts-active"), p && !this.showOnIntersect) this.handleStickyTooltip(a, o, l, s);
              else if ("heatmap" === r.config.chart.type || "treemap" === r.config.chart.type) {
                var x = this.intersect.handleHeatTreeTooltip({
                  e: a,
                  opt: s,
                  x: t,
                  y: i,
                  type: r.config.chart.type
                });
                i = x.y, d.style.left = (t = x.x) + "px", d.style.top = i + "px"
              } else this.tooltipUtil.hasBars() && this.intersect.handleBarTooltip({
                e: a,
                opt: s
              }), this.tooltipUtil.hasMarkers() && this.intersect.handleMarkerTooltip({
                e: a,
                opt: s,
                x: t,
                y: i
              });
              if (this.yaxisTooltips.length)
                for (var m = 0; m < r.config.yaxis.length; m++) this.axesTooltip.drawYaxisTooltipText(m, l,
                  this.xyRatios);
              s.tooltipEl.classList.add("apexcharts-active")
            } else "mouseout" !== a.type && "touchend" !== a.type || this.handleMouseOut(s)
          }
        }
      }, {
        key: "nonAxisChartsTooltips",
        value: function(e) {
          var t = e.e,
            i = e.opt,
            a = e.tooltipRect,
            s = this.w,
            r = i.paths.getAttribute("rel"),
            n = this.getElTooltip(),
            o = s.globals.dom.elWrap.getBoundingClientRect();
          if ("mousemove" === t.type || "touchmove" === t.type) {
            n.classList.add("apexcharts-active"), this.tooltipLabels.drawSeriesTexts({
              ttItems: i.ttItems,
              i: parseInt(r, 10) - 1,
              shared: !1
            });
            var c = s.globals.clientY - o.top - a.ttHeight - 10;
            if (n.style.left = s.globals.clientX - o.left - a.ttWidth / 2 + "px", n.style.top = c + "px", s
              .config.legend.tooltipHoverFormatter) {
              var d = r - 1,
                g = (0, s.config.legend.tooltipHoverFormatter)(this.legendLabels[d].getAttribute(
                  "data:default-text"), {
                  seriesIndex: d,
                  dataPointIndex: d,
                  w: s
                });
              this.legendLabels[d].innerHTML = g
            }
          } else "mouseout" !== t.type && "touchend" !== t.type || (n.classList.remove("apexcharts-active"), s
            .config.legend.tooltipHoverFormatter && this.legendLabels.forEach(function(p) {
              var f = p.getAttribute("data:default-text");
              p.innerHTML = decodeURIComponent(f)
            }))
        }
      }, {
        key: "handleStickyTooltip",
        value: function(e, t, i, a) {
          var s = this.w,
            r = this.tooltipUtil.getNearestValues({
              context: this,
              hoverArea: a.hoverArea,
              elGrid: a.elGrid,
              clientX: t,
              clientY: i
            }),
            n = r.j,
            o = r.capturedSeries;
          s.globals.collapsedSeriesIndices.includes(o) && (o = null);
          var l = a.elGrid.getBoundingClientRect();
          if (r.hoverX < 0 || r.hoverX > l.width) this.handleMouseOut(a);
          else if (null !== o) this.handleStickyCapturedSeries(e, o, a, n);
          else if (this.tooltipUtil.isXoverlap(n) || s.globals.isBarHorizontal) {
            var c = s.globals.series.findIndex(function(d, g) {
              return !s.globals.collapsedSeriesIndices.includes(g)
            });
            this.create(e, this, c, n, a.ttItems)
          }
        }
      }, {
        key: "handleStickyCapturedSeries",
        value: function(e, t, i, a) {
          var s = this.w;
          if (this.tConfig.shared || null !== s.globals.series[t][a]) {
            if (void 0 !== s.globals.series[t][a]) this.tConfig.shared && this.tooltipUtil.isXoverlap(a) &&
              this.tooltipUtil.isInitialSeriesSameLen() ? this.create(e, this, t, a, i.ttItems) : this.create(
                e, this, t, a, i.ttItems, !1);
            else if (this.tooltipUtil.isXoverlap(a)) {
              var r = s.globals.series.findIndex(function(n, o) {
                return !s.globals.collapsedSeriesIndices.includes(o)
              });
              this.create(e, this, r, a, i.ttItems)
            }
          } else this.handleMouseOut(i)
        }
      }, {
        key: "deactivateHoverFilter",
        value: function() {
          for (var e = this.w, t = new X(this.ctx), i = e.globals.dom.Paper.select(".apexcharts-bar-area"),
              a = 0; a < i.length; a++) t.pathMouseLeave(i[a])
        }
      }, {
        key: "handleMouseOut",
        value: function(e) {
          var t = this.w,
            i = this.getElXCrosshairs();
          if (e.tooltipEl.classList.remove("apexcharts-active"), this.deactivateHoverFilter(), "bubble" !== t
            .config.chart.type && this.marker.resetPointsSize(), null !== i && i.classList.remove(
              "apexcharts-active"), null !== this.ycrosshairs && this.ycrosshairs.classList.remove(
              "apexcharts-active"), this.isXAxisTooltipEnabled && this.xaxisTooltip.classList.remove(
              "apexcharts-active"), this.yaxisTooltips.length) {
            null === this.yaxisTTEls && (this.yaxisTTEls = t.globals.dom.baseEl.querySelectorAll(
              ".apexcharts-yaxistooltip"));
            for (var a = 0; a < this.yaxisTTEls.length; a++) this.yaxisTTEls[a].classList.remove(
              "apexcharts-active")
          }
          t.config.legend.tooltipHoverFormatter && this.legendLabels.forEach(function(s) {
            var r = s.getAttribute("data:default-text");
            s.innerHTML = decodeURIComponent(r)
          })
        }
      }, {
        key: "markerClick",
        value: function(e, t, i) {
          var a = this.w;
          "function" == typeof a.config.chart.events.markerClick && a.config.chart.events.markerClick(e, this
            .ctx, {
              seriesIndex: t,
              dataPointIndex: i,
              w: a
            }), this.ctx.events.fireEvent("markerClick", [e, this.ctx, {
            seriesIndex: t,
            dataPointIndex: i,
            w: a
          }])
        }
      }, {
        key: "create",
        value: function(e, t, i, a, s) {
          var r, n, o, l, c, d, g, p, f, x, m, v, y, h, u, b, k = arguments.length > 5 && void 0 !==
            arguments[5] ? arguments[5] : null,
            A = this.w,
            S = t;
          "mouseup" === e.type && this.markerClick(e, i, a), null === k && (k = this.tConfig.shared);
          var C = this.tooltipUtil.hasMarkers(i),
            L = this.tooltipUtil.getElBars();
          if (A.config.legend.tooltipHoverFormatter) {
            var M = A.config.legend.tooltipHoverFormatter,
              z = Array.from(this.legendLabels);
            z.forEach(function(Z) {
              var U = Z.getAttribute("data:default-text");
              Z.innerHTML = decodeURIComponent(U)
            });
            for (var I = 0; I < z.length; I++) {
              var T = z[I],
                E = parseInt(T.getAttribute("i"), 10),
                H = decodeURIComponent(T.getAttribute("data:default-text")),
                D = M(H, {
                  seriesIndex: k ? E : i,
                  dataPointIndex: a,
                  w: A
                });
              if (k) T.innerHTML = A.globals.collapsedSeriesIndices.indexOf(E) < 0 ? D : H;
              else if (T.innerHTML = E === i ? D : H, i === E) break
            }
          }
          var O = Y(Y({
            ttItems: s,
            i,
            j: a
          }, void 0 !== (null === (r = A.globals.seriesRange) || void 0 === r || null === (n = r[i]) ||
            void 0 === n || null === (o = n[a]) || void 0 === o || null === (l = o.y[0]) || void 0 ===
            l ? void 0 : l.y1) && {
            y1: null === (c = A.globals.seriesRange) || void 0 === c || null === (d = c[i]) ||
              void 0 === d || null === (g = d[a]) || void 0 === g || null === (p = g.y[0]) || void 0 ===
              p ? void 0 : p.y1
          }), void 0 !== (null === (f = A.globals.seriesRange) || void 0 === f || null === (x = f[i]) ||
            void 0 === x || null === (m = x[a]) || void 0 === m || null === (v = m.y[0]) || void 0 === v ?
            void 0 : v.y2) && {
            y2: null === (y = A.globals.seriesRange) || void 0 === y || null === (h = y[i]) || void 0 ===
              h || null === (u = h[a]) || void 0 === u || null === (b = u.y[0]) || void 0 === b ? void 0 :
              b.y2
          });
          if (k) {
            if (S.tooltipLabels.drawSeriesTexts(Y(Y({}, O), {}, {
                shared: !this.showOnIntersect && this.tConfig.shared
              })), C) A.globals.markers.largestSize > 0 ? S.marker.enlargePoints(a) : S.tooltipPosition
              .moveDynamicPointsOnHover(a);
            else if (this.tooltipUtil.hasBars() && (this.barSeriesHeight = this.tooltipUtil.getBarsHeight(L),
                this.barSeriesHeight > 0)) {
              var W = new X(this.ctx),
                N = A.globals.dom.Paper.select(".apexcharts-bar-area[j='".concat(a, "']"));
              this.deactivateHoverFilter(), this.tooltipPosition.moveStickyTooltipOverBars(a, i);
              for (var B = 0; B < N.length; B++) W.pathMouseEnter(N[B])
            }
          } else S.tooltipLabels.drawSeriesTexts(Y({
              shared: !1
            }, O)), this.tooltipUtil.hasBars() && S.tooltipPosition.moveStickyTooltipOverBars(a, i), C && S
            .tooltipPosition.moveMarkers(i, a)
        }
      }]), w
    }(),
    Mt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.barCtx = e, this.totalFormatter = this.w.config.plotOptions.bar.dataLabels
          .total.formatter, this.totalFormatter || (this.totalFormatter = this.w.config.dataLabels.formatter)
      }
      return R(w, [{
        key: "handleBarDataLabels",
        value: function(e) {
          var t, i, a = e.x,
            s = e.y,
            r = e.y1,
            n = e.y2,
            o = e.i,
            l = e.j,
            c = e.realIndex,
            d = e.columnGroupIndex,
            g = e.series,
            p = e.barHeight,
            f = e.barWidth,
            x = e.barXPosition,
            m = e.barYPosition,
            v = e.visibleSeries,
            y = e.renderedPath,
            h = this.w,
            u = new X(this.barCtx.ctx),
            b = Array.isArray(this.barCtx.strokeWidth) ? this.barCtx.strokeWidth[c] : this.barCtx.strokeWidth;
          h.globals.isXNumeric && !h.globals.isBarHorizontal ? (t = a + parseFloat(f * (v + 1)), i = s +
            parseFloat(p * (v + 1)) - b) : (t = a + parseFloat(f * v), i = s + parseFloat(p * v));
          var k, L, A = null,
            S = a,
            C = s,
            M = h.config.dataLabels,
            z = this.barCtx.barOptions.dataLabels,
            I = this.barCtx.barOptions.dataLabels.total;
          void 0 !== m && this.barCtx.isRangeBar && (i = m, C = m), void 0 !== x && this.barCtx
            .isVerticalGroupedRangeBar && (t = x, S = x);
          var T = M.offsetX,
            E = M.offsetY,
            H = {
              width: 0,
              height: 0
            };
          h.config.dataLabels.enabled && (H = u.getTextRects(h.globals.yLabelFormatters[0](this.barCtx.series[
            o][l]), parseFloat(M.style.fontSize)));
          var O = {
            x: a,
            y: s,
            i: o,
            j: l,
            realIndex: c,
            columnGroupIndex: d,
            renderedPath: y,
            bcx: t,
            bcy: i,
            barHeight: p,
            barWidth: f,
            textRects: H,
            strokeWidth: b,
            dataLabelsX: S,
            dataLabelsY: C,
            dataLabelsConfig: M,
            barDataLabelsConfig: z,
            barTotalDataLabelsConfig: I,
            offX: T,
            offY: E
          };
          return L = this.barCtx.isHorizontal ? this.calculateBarsDataLabelsPosition(O) : this
            .calculateColumnsDataLabelsPosition(O), y.attr({
              cy: L.bcy,
              cx: L.bcx,
              j: l,
              val: g[o][l],
              barHeight: p,
              barWidth: f
            }), k = this.drawCalculatedDataLabels({
              x: L.dataLabelsX,
              y: L.dataLabelsY,
              val: this.barCtx.isRangeBar ? [r, n] : g[o][l],
              i: c,
              j: l,
              barWidth: f,
              barHeight: p,
              textRects: H,
              dataLabelsConfig: M
            }), h.config.chart.stacked && I.enabled && (A = this.drawTotalDataLabels({
              x: L.totalDataLabelsX,
              y: L.totalDataLabelsY,
              barWidth: f,
              barHeight: p,
              realIndex: c,
              textAnchor: L.totalDataLabelsAnchor,
              val: this.getStackedTotalDataLabel({
                realIndex: c,
                j: l
              }),
              dataLabelsConfig: M,
              barTotalDataLabelsConfig: I
            })), {
              dataLabels: k,
              totalDataLabels: A
            }
        }
      }, {
        key: "getStackedTotalDataLabel",
        value: function(e) {
          var t = e.realIndex,
            i = e.j,
            a = this.w,
            s = this.barCtx.stackedSeriesTotals[i];
          return this.totalFormatter && (s = this.totalFormatter(s, Y(Y({}, a), {}, {
            seriesIndex: t,
            dataPointIndex: i,
            w: a
          }))), s
        }
      }, {
        key: "calculateColumnsDataLabelsPosition",
        value: function(e) {
          var t, i, a = this.w,
            s = e.i,
            r = e.j,
            n = e.realIndex,
            o = e.columnGroupIndex,
            l = e.y,
            c = e.bcx,
            d = e.barWidth,
            g = e.barHeight,
            p = e.textRects,
            f = e.dataLabelsX,
            x = e.dataLabelsY,
            m = e.dataLabelsConfig,
            v = e.barDataLabelsConfig,
            y = e.barTotalDataLabelsConfig,
            h = e.strokeWidth,
            u = e.offX,
            b = e.offY,
            k = c;
          g = Math.abs(g);
          var A = "vertical" === a.config.plotOptions.bar.dataLabels.orientation,
            S = this.barCtx.barHelpers.getZeroValueEncounters({
              i: s,
              j: r
            }).zeroEncounters;
          c = c - h / 2 + o * d, this.barCtx.isVerticalGroupedRangeBar ? f += d / 2 : (f = a.globals
            .isXNumeric ? c - d / 2 + u : c - a.globals.gridWidth / a.globals.dataPoints + d / 2 + u, S >
            0 && a.config.plotOptions.bar.hideZeroBarsWhenGrouped && (f -= d * S)), A && (f = f + p.height /
            2 - h / 2 - 2);
          var L = this.barCtx.series[s][r] < 0,
            M = l;
          switch (this.barCtx.isReversed && (M = l + (L ? g : -g), l -= g), v.position) {
            case "center":
              x = A ? L ? M - g / 2 + b : M + g / 2 - b : L ? M - g / 2 + p.height / 2 + b : M + g / 2 + p
                .height / 2 - b;
              break;
            case "bottom":
              x = A ? L ? M - g + b : M + g - b : L ? M - g + p.height + h + b : M + g - p.height / 2 + h - b;
              break;
            case "top":
              x = A ? L ? M + b : M - b : L ? M - p.height / 2 - b : M + p.height + b
          }
          if (this.barCtx.lastActiveBarSerieIndex === n && y.enabled) {
            var z = new X(this.barCtx.ctx).getTextRects(this.getStackedTotalDataLabel({
              realIndex: n,
              j: r
            }), m.fontSize);
            t = L ? M - z.height / 2 - b - y.offsetY + 18 : M + z.height + b + y.offsetY - 18, i = k + (a
              .globals.isXNumeric ? d * (a.globals.barGroups.length - 1) - d / 2 : -(d * a.globals.barGroups
                .length - d / 2 - 2 * h)) + y.offsetX
          }
          return a.config.chart.stacked || (x < 0 ? x = 0 + h : x + p.height / 3 > a.globals.gridHeight && (
            x = a.globals.gridHeight - h)), {
            bcx: c,
            bcy: l,
            dataLabelsX: f,
            dataLabelsY: x,
            totalDataLabelsX: i,
            totalDataLabelsY: t,
            totalDataLabelsAnchor: "middle"
          }
        }
      }, {
        key: "calculateBarsDataLabelsPosition",
        value: function(e) {
          var t = this.w,
            i = e.x,
            a = e.i,
            s = e.j,
            r = e.realIndex,
            n = e.columnGroupIndex,
            o = e.bcy,
            l = e.barHeight,
            c = e.barWidth,
            d = e.textRects,
            g = e.dataLabelsX,
            p = e.strokeWidth,
            f = e.dataLabelsConfig,
            x = e.barDataLabelsConfig,
            m = e.barTotalDataLabelsConfig,
            v = e.offX,
            y = e.offY,
            h = t.globals.gridHeight / t.globals.dataPoints;
          c = Math.abs(c);
          var u, b, k = (o += n * l) - (this.barCtx.isRangeBar ? 0 : h) + l / 2 + d.height / 2 + y - 3,
            A = "start",
            S = this.barCtx.series[a][s] < 0,
            C = i;
          switch (this.barCtx.isReversed && (C = i + (S ? -c : c), i = t.globals.gridWidth - c, A = S ?
              "start" : "end"), x.position) {
            case "center":
              g = S ? C + c / 2 - v : Math.max(d.width / 2, C - c / 2) + v;
              break;
            case "bottom":
              g = S ? C + c - p - Math.round(d.width / 2) - v : C - c + p + Math.round(d.width / 2) + v;
              break;
            case "top":
              g = S ? C - p + Math.round(d.width / 2) - v : C - p - Math.round(d.width / 2) + v
          }
          if (this.barCtx.lastActiveBarSerieIndex === r && m.enabled) {
            var L = new X(this.barCtx.ctx).getTextRects(this.getStackedTotalDataLabel({
              realIndex: r,
              j: s
            }), f.fontSize);
            S ? (u = C - p - v - m.offsetX, A = "end") : u = C + v + m.offsetX + (this.barCtx.isReversed ? -(
              c + p) : p), b = k - d.height / 2 + L.height / 2 + m.offsetY + p
          }
          return t.config.chart.stacked || (g < 0 ? g = g + d.width + p : g + d.width / 2 > t.globals
            .gridWidth && (g = t.globals.gridWidth - d.width - p)), {
            bcx: i,
            bcy: o,
            dataLabelsX: g,
            dataLabelsY: k,
            totalDataLabelsX: u,
            totalDataLabelsY: b,
            totalDataLabelsAnchor: A
          }
        }
      }, {
        key: "drawCalculatedDataLabels",
        value: function(e) {
          var t = e.x,
            i = e.y,
            a = e.val,
            s = e.i,
            r = e.j,
            n = e.textRects,
            o = e.barHeight,
            l = e.barWidth,
            c = e.dataLabelsConfig,
            d = this.w,
            g = "rotate(0)";
          "vertical" === d.config.plotOptions.bar.dataLabels.orientation && (g = "rotate(-90, ".concat(t,
            ", ").concat(i, ")"));
          var p = new ue(this.barCtx.ctx),
            f = new X(this.barCtx.ctx),
            x = c.formatter,
            m = null,
            v = d.globals.collapsedSeriesIndices.indexOf(s) > -1;
          if (c.enabled && !v) {
            m = f.group({
              class: "apexcharts-data-labels",
              transform: g
            });
            var y = "";
            void 0 !== a && (y = x(a, Y(Y({}, d), {}, {
              seriesIndex: s,
              dataPointIndex: r,
              w: d
            }))), !a && d.config.plotOptions.bar.hideZeroBarsWhenGrouped && (y = "");
            var h = d.globals.series[s][r] < 0,
              u = d.config.plotOptions.bar.dataLabels.position;
            "vertical" === d.config.plotOptions.bar.dataLabels.orientation && ("top" === u && (c.textAnchor =
                h ? "end" : "start"), "center" === u && (c.textAnchor = "middle"), "bottom" === u && (c
                .textAnchor = h ? "end" : "start")), this.barCtx.isRangeBar && this.barCtx.barOptions
              .dataLabels.hideOverflowingLabels && l < f.getTextRects(y, parseFloat(c.style.fontSize))
              .width && (y = ""), d.config.chart.stacked && this.barCtx.barOptions.dataLabels
              .hideOverflowingLabels && (this.barCtx.isHorizontal ? n.width / 1.6 > Math.abs(l) && (y = "") :
                n.height / 1.6 > Math.abs(o) && (y = ""));
            var b = Y({}, c);
            this.barCtx.isHorizontal && a < 0 && ("start" === c.textAnchor ? b.textAnchor = "end" : "end" ===
              c.textAnchor && (b.textAnchor = "start")), p.plotDataLabelsText({
              x: t,
              y: i,
              text: y,
              i: s,
              j: r,
              parent: m,
              dataLabelsConfig: b,
              alwaysDrawDataLabel: !0,
              offsetCorrection: !0
            })
          }
          return m
        }
      }, {
        key: "drawTotalDataLabels",
        value: function(e) {
          var t, i = e.x,
            a = e.y,
            s = e.val,
            r = e.barWidth,
            n = e.barHeight,
            o = e.realIndex,
            l = e.textAnchor,
            c = e.barTotalDataLabelsConfig,
            d = this.w,
            g = new X(this.barCtx.ctx);
          return c.enabled && void 0 !== i && void 0 !== a && this.barCtx.lastActiveBarSerieIndex === o && (
            t = g.drawText({
              x: i - (!d.globals.isBarHorizontal && d.globals.barGroups.length ? r * (d.globals.barGroups
                .length - 1) / 2 : 0),
              y: a - (d.globals.isBarHorizontal && d.globals.barGroups.length ? n * (d.globals.barGroups
                .length - 1) / 2 : 0),
              foreColor: c.style.color,
              text: s,
              textAnchor: l,
              fontFamily: c.style.fontFamily,
              fontSize: c.style.fontSize,
              fontWeight: c.style.fontWeight
            })), t
        }
      }]), w
    }(),
    It = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.barCtx = e
      }
      return R(w, [{
        key: "initVariables",
        value: function(e) {
          var t = this.w;
          this.barCtx.series = e, this.barCtx.totalItems = 0, this.barCtx.seriesLen = 0, this.barCtx
            .visibleI = -1, this.barCtx.visibleItems = 1;
          for (var i = 0; i < e.length; i++)
            if (e[i].length > 0 && (this.barCtx.seriesLen = this.barCtx.seriesLen + 1, this.barCtx
                .totalItems += e[i].length), t.globals.isXNumeric)
              for (var a = 0; a < e[i].length; a++) t.globals.seriesX[i][a] > t.globals.minX && t.globals
                .seriesX[i][a] < t.globals.maxX && this.barCtx.visibleItems++;
            else this.barCtx.visibleItems = t.globals.dataPoints;
          0 === this.barCtx.seriesLen && (this.barCtx.seriesLen = 1), this.barCtx.zeroSerieses = [], t.globals
            .comboCharts || this.checkZeroSeries({
              series: e
            })
        }
      }, {
        key: "initialPositions",
        value: function() {
          var e, t, i, a, s, r, n, o, l = this.w,
            c = l.globals.dataPoints;
          this.barCtx.isRangeBar && (c = l.globals.labels.length);
          var d = this.barCtx.seriesLen;
          if (l.config.plotOptions.bar.rangeBarGroupRows && (d = 1), this.barCtx.isHorizontal) s = (i = l
              .globals.gridHeight / c) / d, l.globals.isXNumeric && (s = (i = l.globals.gridHeight / this
              .barCtx.totalItems) / this.barCtx.seriesLen), s = s * parseInt(this.barCtx.barOptions.barHeight,
              10) / 100, -1 === String(this.barCtx.barOptions.barHeight).indexOf("%") && (s = parseInt(this
              .barCtx.barOptions.barHeight, 10)), o = this.barCtx.baseLineInvertedY + l.globals
            .padHorizontal + (this.barCtx.isReversed ? l.globals.gridWidth : 0) - (this.barCtx.isReversed ?
              2 * this.barCtx.baseLineInvertedY : 0), this.barCtx.isFunnel && (o = l.globals.gridWidth / 2),
            t = (i - s * this.barCtx.seriesLen) / 2;
          else {
            if (a = l.globals.gridWidth / this.barCtx.visibleItems, l.config.xaxis.convertedCatToNumeric && (
                a = l.globals.gridWidth / l.globals.dataPoints), r = a / d * parseInt(this.barCtx.barOptions
                .columnWidth, 10) / 100, l.globals.isXNumeric) {
              var g = this.barCtx.xRatio;
              l.globals.minXDiff && .5 !== l.globals.minXDiff && l.globals.minXDiff / g > 0 && (a = l.globals
                  .minXDiff / g), (r = a / d * parseInt(this.barCtx.barOptions.columnWidth, 10) / 100) < 1 &&
                (r = 1)
            } - 1 === String(this.barCtx.barOptions.columnWidth).indexOf("%") && (r = parseInt(this.barCtx
                .barOptions.columnWidth, 10)), n = l.globals.gridHeight - this.barCtx.baseLineY[this.barCtx
                .translationsIndex] - (this.barCtx.isReversed ? l.globals.gridHeight : 0) + (this.barCtx
                .isReversed ? 2 * this.barCtx.baseLineY[this.barCtx.translationsIndex] : 0), e = l.globals
              .padHorizontal + (a - r * this.barCtx.seriesLen) / 2
          }
          return l.globals.barHeight = s, l.globals.barWidth = r, {
            x: e,
            y: t,
            yDivision: i,
            xDivision: a,
            barHeight: s,
            barWidth: r,
            zeroH: n,
            zeroW: o
          }
        }
      }, {
        key: "initializeStackedPrevVars",
        value: function(e) {
          e.w.globals.seriesGroups.forEach(function(t) {
            e[t] || (e[t] = {}), e[t].prevY = [], e[t].prevX = [], e[t].prevYF = [], e[t].prevXF = [], e[
              t].prevYVal = [], e[t].prevXVal = []
          })
        }
      }, {
        key: "initializeStackedXYVars",
        value: function(e) {
          e.w.globals.seriesGroups.forEach(function(t) {
            e[t] || (e[t] = {}), e[t].xArrj = [], e[t].xArrjF = [], e[t].xArrjVal = [], e[t].yArrj = [],
              e[t].yArrjF = [], e[t].yArrjVal = []
          })
        }
      }, {
        key: "getPathFillColor",
        value: function(e, t, i, a) {
          var s, r, n, o, l = this.w,
            c = new re(this.barCtx.ctx),
            d = null,
            g = this.barCtx.barOptions.distributed ? i : t;
          return this.barCtx.barOptions.colors.ranges.length > 0 && this.barCtx.barOptions.colors.ranges.map(
            function(p) {
              e[t][i] >= p.from && e[t][i] <= p.to && (d = p.color)
            }), l.config.series[t].data[i] && l.config.series[t].data[i].fillColor && (d = l.config.series[
            t].data[i].fillColor), c.fillPath({
            seriesNumber: this.barCtx.barOptions.distributed ? g : a,
            dataPointIndex: i,
            color: d,
            value: e[t][i],
            fillConfig: null === (s = l.config.series[t].data[i]) || void 0 === s ? void 0 : s.fill,
            fillType: null !== (r = l.config.series[t].data[i]) && void 0 !== r && null !== (n = r
              .fill) && void 0 !== n && n.type ? null === (o = l.config.series[t].data[i]) || void 0 ===
              o ? void 0 : o.fill.type : Array.isArray(l.config.fill.type) ? l.config.fill.type[t] : l
              .config.fill.type
          })
        }
      }, {
        key: "getStrokeWidth",
        value: function(e, t, i) {
          var a = 0,
            s = this.w;
          return this.barCtx.isNullValue = null == this.barCtx.series[e][t], s.config.stroke.show && (this
            .barCtx.isNullValue || (a = Array.isArray(this.barCtx.strokeWidth) ? this.barCtx.strokeWidth[
              i] : this.barCtx.strokeWidth)), a
        }
      }, {
        key: "shouldApplyRadius",
        value: function(e) {
          var t = this.w,
            i = !1;
          return t.config.plotOptions.bar.borderRadius > 0 && (t.config.chart.stacked && "last" === t.config
            .plotOptions.bar.borderRadiusWhenStacked ? this.barCtx.lastActiveBarSerieIndex === e && (i = !
            0) : i = !0), i
        }
      }, {
        key: "barBackground",
        value: function(e) {
          var t = e.j,
            i = e.i,
            a = e.x1,
            s = e.x2,
            r = e.y1,
            n = e.y2,
            o = e.elSeries,
            l = this.w,
            c = new X(this.barCtx.ctx),
            d = new se(this.barCtx.ctx).getActiveConfigSeriesIndex();
          if (this.barCtx.barOptions.colors.backgroundBarColors.length > 0 && d === i) {
            t >= this.barCtx.barOptions.colors.backgroundBarColors.length && (t %= this.barCtx.barOptions
              .colors.backgroundBarColors.length);
            var p = c.drawRect(void 0 !== a ? a : 0, void 0 !== r ? r : 0, void 0 !== s ? s : l.globals
              .gridWidth, void 0 !== n ? n : l.globals.gridHeight, this.barCtx.barOptions.colors
              .backgroundBarRadius, this.barCtx.barOptions.colors.backgroundBarColors[t], this.barCtx
              .barOptions.colors.backgroundBarOpacity);
            o.add(p), p.node.classList.add("apexcharts-backgroundBar")
          }
        }
      }, {
        key: "getColumnPaths",
        value: function(e) {
          var t, i = e.barWidth,
            a = e.barXPosition,
            s = e.y1,
            r = e.y2,
            n = e.strokeWidth,
            o = e.seriesGroup,
            l = e.realIndex,
            c = e.i,
            d = e.j,
            g = e.w,
            p = new X(this.barCtx.ctx);
          (n = Array.isArray(n) ? n[l] : n) || (n = 0);
          var f = i,
            x = a;
          null !== (t = g.config.series[l].data[d]) && void 0 !== t && t.columnWidthOffset && (x = a - g
            .config.series[l].data[d].columnWidthOffset / 2, f = i + g.config.series[l].data[d]
            .columnWidthOffset);
          var m = n / 2,
            v = x + m,
            y = x + f - m;
          r += .001 + m;
          var h = p.move(v, s += .001 - m),
            u = p.move(v, s),
            b = p.line(y, s);
          if (g.globals.previousPaths.length > 0 && (u = this.barCtx.getPreviousPath(l, d, !1)), h = h + p
            .line(v, r) + p.line(y, r) + p.line(y, s) + ("around" === g.config.plotOptions.bar
              .borderRadiusApplication ? " Z" : " z"), u = u + p.line(v, s) + b + b + b + b + b + p.line(v,
            s) + ("around" === g.config.plotOptions.bar.borderRadiusApplication ? " Z" : " z"), this
            .shouldApplyRadius(l) && (h = p.roundPathCorners(h, g.config.plotOptions.bar.borderRadius)), g
            .config.chart.stacked) {
            var k = this.barCtx;
            (k = this.barCtx[o]).yArrj.push(r - m), k.yArrjF.push(Math.abs(s - r + n)), k.yArrjVal.push(this
              .barCtx.series[c][d])
          }
          return {
            pathTo: h,
            pathFrom: u
          }
        }
      }, {
        key: "getBarpaths",
        value: function(e) {
          var t, i = e.barYPosition,
            a = e.barHeight,
            s = e.x1,
            r = e.x2,
            n = e.strokeWidth,
            o = e.seriesGroup,
            l = e.realIndex,
            c = e.i,
            d = e.j,
            g = e.w,
            p = new X(this.barCtx.ctx);
          (n = Array.isArray(n) ? n[l] : n) || (n = 0);
          var f = i,
            x = a;
          null !== (t = g.config.series[l].data[d]) && void 0 !== t && t.barHeightOffset && (f = i - g.config
            .series[l].data[d].barHeightOffset / 2, x = a + g.config.series[l].data[d].barHeightOffset);
          var m = n / 2,
            v = f + m,
            y = f + x - m;
          r += .001 + m;
          var h = p.move(s += .001 - m, v),
            u = p.move(s, v);
          g.globals.previousPaths.length > 0 && (u = this.barCtx.getPreviousPath(l, d, !1));
          var b = p.line(s, y);
          if (h = h + p.line(r, v) + p.line(r, y) + b + ("around" === g.config.plotOptions.bar
              .borderRadiusApplication ? " Z" : " z"), u = u + p.line(s, v) + b + b + b + b + b + p.line(s,
            v) + ("around" === g.config.plotOptions.bar.borderRadiusApplication ? " Z" : " z"), this
            .shouldApplyRadius(l) && (h = p.roundPathCorners(h, g.config.plotOptions.bar.borderRadius)), g
            .config.chart.stacked) {
            var k = this.barCtx;
            (k = this.barCtx[o]).xArrj.push(r + m), k.xArrjF.push(Math.abs(s - r)), k.xArrjVal.push(this
              .barCtx.series[c][d])
          }
          return {
            pathTo: h,
            pathFrom: u
          }
        }
      }, {
        key: "checkZeroSeries",
        value: function(e) {
          for (var t = e.series, i = this.w, a = 0; a < t.length; a++) {
            for (var s = 0, r = 0; r < t[i.globals.maxValsInArrayIndex].length; r++) s += t[a][r];
            0 === s && this.barCtx.zeroSerieses.push(a)
          }
        }
      }, {
        key: "getXForValue",
        value: function(e, t) {
          var i = arguments.length > 2 && void 0 !== arguments[2] && !arguments[2] ? null : t;
          return null != e && (i = t + e / this.barCtx.invertedYRatio - 2 * (this.barCtx.isReversed ? e / this
            .barCtx.invertedYRatio : 0)), i
        }
      }, {
        key: "getYForValue",
        value: function(e, t, i) {
          var a = arguments.length > 3 && void 0 !== arguments[3] && !arguments[3] ? null : t;
          return null != e && (a = t - e / this.barCtx.yRatio[i] + 2 * (this.barCtx.isReversed ? e / this
            .barCtx.yRatio[i] : 0)), a
        }
      }, {
        key: "getGoalValues",
        value: function(e, t, i, a, s, r) {
          var n = this,
            o = this.w,
            l = [],
            c = function(p, f) {
              var x;
              l.push((ne(x = {}, e, "x" === e ? n.getXForValue(p, t, !1) : n.getYForValue(p, i, r, !1)), ne(x,
                "attrs", f), x))
            };
          if (o.globals.seriesGoals[a] && o.globals.seriesGoals[a][s] && Array.isArray(o.globals.seriesGoals[
              a][s]) && o.globals.seriesGoals[a][s].forEach(function(p) {
              c(p.value, p)
            }), this.barCtx.barOptions.isDumbbell && o.globals.seriesRange.length) {
            var d = this.barCtx.barOptions.dumbbellColors ? this.barCtx.barOptions.dumbbellColors : o.globals
              .colors,
              g = {
                strokeHeight: "x" === e ? 0 : o.globals.markers.size[a],
                strokeWidth: "x" === e ? o.globals.markers.size[a] : 0,
                strokeDashArray: 0,
                strokeLineCap: "round",
                strokeColor: Array.isArray(d[a]) ? d[a][0] : d[a]
              };
            c(o.globals.seriesRangeStart[a][s], g), c(o.globals.seriesRangeEnd[a][s], Y(Y({}, g), {}, {
              strokeColor: Array.isArray(d[a]) ? d[a][1] : d[a]
            }))
          }
          return l
        }
      }, {
        key: "drawGoalLine",
        value: function(e) {
          var t = e.barXPosition,
            i = e.barYPosition,
            a = e.goalX,
            s = e.goalY,
            r = e.barWidth,
            n = e.barHeight,
            o = new X(this.barCtx.ctx),
            l = o.group({
              className: "apexcharts-bar-goals-groups"
            });
          l.node.classList.add("apexcharts-element-hidden"), this.barCtx.w.globals.delayedElements.push({
            el: l.node
          }), l.attr("clip-path", "url(#gridRectMarkerMask".concat(this.barCtx.w.globals.cuid, ")"));
          var c = null;
          return this.barCtx.isHorizontal ? Array.isArray(a) && a.forEach(function(d) {
            if (d.x >= -1 && d.x <= o.w.globals.gridWidth + 1) {
              var g = void 0 !== d.attrs.strokeHeight ? d.attrs.strokeHeight : n / 2,
                p = i + g + n / 2;
              c = o.drawLine(d.x, p - 2 * g, d.x, p, d.attrs.strokeColor ? d.attrs.strokeColor : void 0, d
                .attrs.strokeDashArray, d.attrs.strokeWidth ? d.attrs.strokeWidth : 2, d.attrs
                .strokeLineCap), l.add(c)
            }
          }) : Array.isArray(s) && s.forEach(function(d) {
            if (d.y >= -1 && d.y <= o.w.globals.gridHeight + 1) {
              var g = void 0 !== d.attrs.strokeWidth ? d.attrs.strokeWidth : r / 2,
                p = t + g + r / 2;
              c = o.drawLine(p - 2 * g, d.y, p, d.y, d.attrs.strokeColor ? d.attrs.strokeColor : void 0, d
                .attrs.strokeDashArray, d.attrs.strokeHeight ? d.attrs.strokeHeight : 2, d.attrs
                .strokeLineCap), l.add(c)
            }
          }), l
        }
      }, {
        key: "drawBarShadow",
        value: function(e) {
          var t = e.prevPaths,
            i = e.currPaths,
            a = e.color,
            s = this.w,
            r = t.x,
            n = t.x1,
            l = i.x,
            c = i.x1,
            d = i.barYPosition,
            g = t.barYPosition + i.barHeight,
            p = new X(this.barCtx.ctx),
            f = new P,
            x = p.move(n, g) + p.line(r, g) + p.line(l, d) + p.line(c, d) + p.line(n, g) + ("around" === s
              .config.plotOptions.bar.borderRadiusApplication ? " Z" : " z");
          return p.drawPath({
            d: x,
            fill: f.shadeColor(.5, P.rgb2hex(a)),
            stroke: "none",
            strokeWidth: 0,
            fillOpacity: 1,
            classes: "apexcharts-bar-shadows"
          })
        }
      }, {
        key: "getZeroValueEncounters",
        value: function(e) {
          var t, i = e.i,
            a = e.j,
            s = this.w,
            r = 0,
            n = 0;
          return (s.config.plotOptions.bar.horizontal ? s.globals.series.map(function(o, l) {
            return l
          }) : (null === (t = s.globals.columnSeries) || void 0 === t ? void 0 : t.i.map(function(o) {
            return o
          })) || []).forEach(function(o) {
            var l = s.globals.seriesPercent[o][a];
            l && r++, o < i && 0 === l && n++
          }), {
            nonZeroColumns: r,
            zeroEncounters: n
          }
        }
      }, {
        key: "getGroupIndex",
        value: function(e) {
          var t = this.w,
            i = t.globals.seriesGroups.findIndex(function(r) {
              return r.indexOf(t.globals.seriesNames[e]) > -1
            }),
            a = this.barCtx.columnGroupIndices,
            s = a.indexOf(i);
          return s < 0 && (a.push(i), s = a.length - 1), {
            groupIndex: i,
            columnGroupIndex: s
          }
        }
      }]), w
    }(),
    pe = function() {
      function w(e, t) {
        F(this, w), this.ctx = e, this.w = e.w;
        var i = this.w;
        this.barOptions = i.config.plotOptions.bar, this.isHorizontal = this.barOptions.horizontal, this.strokeWidth =
          i.config.stroke.width, this.isNullValue = !1, this.isRangeBar = i.globals.seriesRange.length && this
          .isHorizontal, this.isVerticalGroupedRangeBar = !i.globals.isBarHorizontal && i.globals.seriesRange
          .length && i.config.plotOptions.bar.rangeBarGroupRows, this.isFunnel = this.barOptions.isFunnel, this
          .xyRatios = t, null !== this.xyRatios && (this.xRatio = t.xRatio, this.yRatio = t.yRatio, this
            .invertedXRatio = t.invertedXRatio, this.invertedYRatio = t.invertedYRatio, this.baseLineY = t.baseLineY,
            this.baseLineInvertedY = t.baseLineInvertedY), this.yaxisIndex = 0, this.translationsIndex = 0, this
          .seriesLen = 0, this.pathArr = [];
        var a = new se(this.ctx);
        this.lastActiveBarSerieIndex = a.getActiveConfigSeriesIndex("desc", ["bar", "column"]), this
          .columnGroupIndices = [];
        var s = a.getBarSeriesIndices(),
          r = new q(this.ctx);
        this.stackedSeriesTotals = r.getStackedSeriesTotals(this.w.config.series.map(function(n, o) {
          return -1 === s.indexOf(o) ? o : -1
        }).filter(function(n) {
          return -1 !== n
        })), this.barHelpers = new It(this)
      }
      return R(w, [{
        key: "draw",
        value: function(e, t) {
          var i = this.w,
            a = new X(this.ctx),
            s = new q(this.ctx, i);
          e = s.getLogSeries(e), this.series = e, this.yRatio = s.getLogYRatios(this.yRatio), this.barHelpers
            .initVariables(e);
          var r = a.group({
            class: "apexcharts-bar-series apexcharts-plot-series"
          });
          i.config.dataLabels.enabled && this.totalItems > this.barOptions.dataLabels.maxItems && console
            .warn(
              "WARNING: DataLabels are enabled but there are too many to display. This may cause performance issue when rendering - ApexCharts"
              );
          for (var n = 0, o = 0; n < e.length; n++, o++) {
            var l, c, d, g, p = void 0,
              f = void 0,
              x = [],
              m = [],
              v = i.globals.comboCharts ? t[n] : n,
              y = this.barHelpers.getGroupIndex(v).columnGroupIndex,
              h = a.group({
                class: "apexcharts-series",
                rel: n + 1,
                seriesName: P.escapeString(i.globals.seriesNames[v]),
                "data:realIndex": v
              });
            this.ctx.series.addCollapsedClassToSeries(h, v), e[n].length > 0 && (this.visibleI = this
              .visibleI + 1);
            var u = 0,
              b = 0;
            this.yRatio.length > 1 && (this.yaxisIndex = i.globals.seriesYAxisReverseMap[v], this
              .translationsIndex = v);
            var k = this.translationsIndex;
            this.isReversed = i.config.yaxis[this.yaxisIndex] && i.config.yaxis[this.yaxisIndex].reversed;
            var A = this.barHelpers.initialPositions();
            f = A.y, u = A.barHeight, c = A.yDivision, g = A.zeroW, p = A.x, b = A.barWidth, l = A.xDivision,
              d = A.zeroH, this.horizontal || m.push(p + b / 2);
            var S = a.group({
              class: "apexcharts-datalabels",
              "data:realIndex": v
            });
            i.globals.delayedElements.push({
              el: S.node
            }), S.node.classList.add("apexcharts-element-hidden");
            var C = a.group({
                class: "apexcharts-bar-goals-markers"
              }),
              L = a.group({
                class: "apexcharts-bar-shadows"
              });
            i.globals.delayedElements.push({
              el: L.node
            }), L.node.classList.add("apexcharts-element-hidden");
            for (var M = 0; M < e[n].length; M++) {
              var z = this.barHelpers.getStrokeWidth(n, M, v),
                I = null,
                T = {
                  indexes: {
                    i: n,
                    j: M,
                    realIndex: v,
                    translationsIndex: k,
                    bc: o
                  },
                  x: p,
                  y: f,
                  strokeWidth: z,
                  elSeries: h
                };
              this.isHorizontal ? (I = this.drawBarPaths(Y(Y({}, T), {}, {
                barHeight: u,
                zeroW: g,
                yDivision: c
              })), b = this.series[n][M] / this.invertedYRatio) : (I = this.drawColumnPaths(Y(Y({},
              T), {}, {
                xDivision: l,
                barWidth: b,
                zeroH: d
              })), u = this.series[n][M] / this.yRatio[k]);
              var E = this.barHelpers.getPathFillColor(e, n, M, v);
              if (this.isFunnel && this.barOptions.isFunnel3d && this.pathArr.length && M > 0) {
                var H = this.barHelpers.drawBarShadow({
                  color: "string" == typeof E && -1 === E?.indexOf("url") ? E : P.hexToRgba(i.globals
                    .colors[n]),
                  prevPaths: this.pathArr[this.pathArr.length - 1],
                  currPaths: I
                });
                H && L.add(H)
              }
              this.pathArr.push(I);
              var D = this.barHelpers.drawGoalLine({
                barXPosition: I.barXPosition,
                barYPosition: I.barYPosition,
                goalX: I.goalX,
                goalY: I.goalY,
                barHeight: u,
                barWidth: b
              });
              D && C.add(D), f = I.y, p = I.x, M > 0 && m.push(p + b / 2), x.push(f), this.renderSeries({
                realIndex: v,
                pathFill: E,
                j: M,
                i: n,
                columnGroupIndex: y,
                pathFrom: I.pathFrom,
                pathTo: I.pathTo,
                strokeWidth: z,
                elSeries: h,
                x: p,
                y: f,
                series: e,
                barHeight: I.barHeight ? I.barHeight : u,
                barWidth: I.barWidth ? I.barWidth : b,
                elDataLabelsWrap: S,
                elGoalsMarkers: C,
                elBarShadows: L,
                visibleSeries: this.visibleI,
                type: "bar"
              })
            }
            i.globals.seriesXvalues[v] = m, i.globals.seriesYvalues[v] = x, r.add(h)
          }
          return r
        }
      }, {
        key: "renderSeries",
        value: function(e) {
          var D, O, W, t = e.realIndex,
            i = e.pathFill,
            a = e.lineFill,
            s = e.j,
            r = e.i,
            n = e.columnGroupIndex,
            o = e.pathFrom,
            l = e.pathTo,
            c = e.strokeWidth,
            d = e.elSeries,
            g = e.x,
            p = e.y,
            f = e.y1,
            x = e.y2,
            m = e.series,
            v = e.barHeight,
            y = e.barWidth,
            h = e.barXPosition,
            u = e.barYPosition,
            b = e.elDataLabelsWrap,
            k = e.elGoalsMarkers,
            A = e.elBarShadows,
            S = e.visibleSeries,
            C = e.type,
            L = this.w,
            M = new X(this.ctx);
          if (!a) {
            var z = "function" == typeof L.globals.stroke.colors[t] ? (D = t, W = L.config.stroke.colors,
              Array.isArray(W) && W.length > 0 && ((O = W[D]) || (O = ""), "function" == typeof O) ? O({
                value: L.globals.series[D][s],
                dataPointIndex: s,
                w: L
              }) : O) : L.globals.stroke.colors[t];
            a = this.barOptions.distributed ? L.globals.stroke.colors[s] : z
          }
          L.config.series[r].data[s] && L.config.series[r].data[s].strokeColor && (a = L.config.series[r]
            .data[s].strokeColor), this.isNullValue && (i = "none");
          var T = M.renderPaths({
            i: r,
            j: s,
            realIndex: t,
            pathFrom: o,
            pathTo: l,
            stroke: a,
            strokeWidth: c,
            strokeLineCap: L.config.stroke.lineCap,
            fill: i,
            animationDelay: s / L.config.chart.animations.animateGradually.delay * (L.config.chart
              .animations.speed / L.globals.dataPoints) / 2.4,
            initialSpeed: L.config.chart.animations.speed,
            dataChangeSpeed: L.config.chart.animations.dynamicAnimation.speed,
            className: "apexcharts-".concat(C, "-area")
          });
          T.attr("clip-path", "url(#gridRectMask".concat(L.globals.cuid, ")"));
          var E = L.config.forecastDataPoints;
          E.count > 0 && s >= L.globals.dataPoints - E.count && (T.node.setAttribute("stroke-dasharray", E
            .dashArray), T.node.setAttribute("stroke-width", E.strokeWidth), T.node.setAttribute(
            "fill-opacity", E.fillOpacity)), void 0 !== f && void 0 !== x && (T.attr("data-range-y1", f), T
            .attr("data-range-y2", x)), new K(this.ctx).setSelectionFilter(T, t, s), d.add(T);
          var H = new Mt(this).handleBarDataLabels({
            x: g,
            y: p,
            y1: f,
            y2: x,
            i: r,
            j: s,
            series: m,
            realIndex: t,
            columnGroupIndex: n,
            barHeight: v,
            barWidth: y,
            barXPosition: h,
            barYPosition: u,
            renderedPath: T,
            visibleSeries: S
          });
          return null !== H.dataLabels && b.add(H.dataLabels), H.totalDataLabels && b.add(H.totalDataLabels),
            d.add(b), k && d.add(k), A && d.add(A), d
        }
      }, {
        key: "drawBarPaths",
        value: function(e) {
          var t, n, i = e.indexes,
            a = e.barHeight,
            s = e.strokeWidth,
            r = e.zeroW,
            o = e.y,
            l = e.yDivision,
            c = e.elSeries,
            d = this.w,
            g = i.i,
            p = i.j;
          if (d.globals.isXNumeric) t = (o = (d.globals.seriesX[g][p] - d.globals.minX) / this
            .invertedXRatio - a) + a * this.visibleI;
          else if (d.config.plotOptions.bar.hideZeroBarsWhenGrouped) {
            var f = 0,
              x = 0;
            d.globals.seriesPercent.forEach(function(v, y) {
              v[p] && f++, y < g && 0 === v[p] && x++
            }), f > 0 && (a = this.seriesLen * a / f), t = o + a * this.visibleI, t -= a * x
          } else t = o + a * this.visibleI;
          this.isFunnel && (r -= (this.barHelpers.getXForValue(this.series[g][p], r) - r) / 2), n = this
            .barHelpers.getXForValue(this.series[g][p], r);
          var m = this.barHelpers.getBarpaths({
            barYPosition: t,
            barHeight: a,
            x1: r,
            x2: n,
            strokeWidth: s,
            series: this.series,
            realIndex: i.realIndex,
            i: g,
            j: p,
            w: d
          });
          return d.globals.isXNumeric || (o += l), this.barHelpers.barBackground({
            j: p,
            i: g,
            y1: t - a * this.visibleI,
            y2: a * this.seriesLen,
            elSeries: c
          }), {
            pathTo: m.pathTo,
            pathFrom: m.pathFrom,
            x1: r,
            x: n,
            y: o,
            goalX: this.barHelpers.getGoalValues("x", r, null, g, p),
            barYPosition: t,
            barHeight: a
          }
        }
      }, {
        key: "drawColumnPaths",
        value: function(e) {
          var t, s, i = e.indexes,
            a = e.x,
            r = e.xDivision,
            n = e.barWidth,
            o = e.zeroH,
            l = e.strokeWidth,
            c = e.elSeries,
            d = this.w,
            g = i.realIndex,
            p = i.translationsIndex,
            f = i.i,
            x = i.j,
            m = i.bc;
          if (d.globals.isXNumeric) {
            var v = this.getBarXForNumericXAxis({
              x: a,
              j: x,
              realIndex: g,
              barWidth: n
            });
            a = v.x, t = v.barXPosition
          } else if (d.config.plotOptions.bar.hideZeroBarsWhenGrouped) {
            var y = this.barHelpers.getZeroValueEncounters({
                i: f,
                j: x
              }),
              h = y.nonZeroColumns;
            h > 0 && (n = this.seriesLen * n / h), t = a + n * this.visibleI, t -= n * y.zeroEncounters
          } else t = a + n * this.visibleI;
          s = this.barHelpers.getYForValue(this.series[f][x], o, p);
          var b = this.barHelpers.getColumnPaths({
            barXPosition: t,
            barWidth: n,
            y1: o,
            y2: s,
            strokeWidth: l,
            series: this.series,
            realIndex: g,
            i: f,
            j: x,
            w: d
          });
          return d.globals.isXNumeric || (a += r), this.barHelpers.barBackground({
            bc: m,
            j: x,
            i: f,
            x1: t - l / 2 - n * this.visibleI,
            x2: n * this.seriesLen + l / 2,
            elSeries: c
          }), {
            pathTo: b.pathTo,
            pathFrom: b.pathFrom,
            x: a,
            y: s,
            goalY: this.barHelpers.getGoalValues("y", null, o, f, x, p),
            barXPosition: t,
            barWidth: n
          }
        }
      }, {
        key: "getBarXForNumericXAxis",
        value: function(e) {
          var t = e.x,
            i = e.barWidth,
            a = e.realIndex,
            s = e.j,
            r = this.w,
            n = a;
          return r.globals.seriesX[a].length || (n = r.globals.maxValsInArrayIndex), r.globals.seriesX[n][
            s] && (t = (r.globals.seriesX[n][s] - r.globals.minX) / this.xRatio - i * this.seriesLen / 2), {
              barXPosition: t + i * this.visibleI,
              x: t
            }
        }
      }, {
        key: "getPreviousPath",
        value: function(e, t) {
          for (var i, a = this.w, s = 0; s < a.globals.previousPaths.length; s++) {
            var r = a.globals.previousPaths[s];
            r.paths && r.paths.length > 0 && parseInt(r.realIndex, 10) === parseInt(e, 10) && void 0 !== a
              .globals.previousPaths[s].paths[t] && (i = a.globals.previousPaths[s].paths[t].d)
          }
          return i
        }
      }]), w
    }(),
    tt = function(w) {
      xe(t, w);
      var e = be(t);

      function t() {
        return F(this, t), e.apply(this, arguments)
      }
      return R(t, [{
        key: "draw",
        value: function(i, a) {
          var s = this,
            r = this.w;
          this.graphics = new X(this.ctx), this.bar = new pe(this.ctx, this.xyRatios);
          var n = new q(this.ctx, r);
          i = n.getLogSeries(i), this.yRatio = n.getLogYRatios(this.yRatio), this.barHelpers.initVariables(i),
            "100%" === r.config.chart.stackType && (i = r.globals.comboCharts ? a.map(function(f) {
              return r.globals.seriesPercent[f]
            }) : r.globals.seriesPercent.slice()), this.series = i, this.barHelpers.initializeStackedPrevVars(
              this);
          for (var o = this.graphics.group({
              class: "apexcharts-bar-series apexcharts-plot-series"
            }), l = 0, c = 0, d = function(f, x) {
              var m = void 0,
                v = void 0,
                y = void 0,
                h = void 0,
                u = r.globals.comboCharts ? a[f] : f,
                b = s.barHelpers.getGroupIndex(u),
                k = b.groupIndex,
                A = b.columnGroupIndex;
              s.groupCtx = s[r.globals.seriesGroups[k]];
              var S = [],
                C = [],
                L = 0;
              s.yRatio.length > 1 && (s.yaxisIndex = r.globals.seriesYAxisReverseMap[u][0], L = u), s
                .isReversed = r.config.yaxis[s.yaxisIndex] && r.config.yaxis[s.yaxisIndex].reversed;
              var M = s.graphics.group({
                class: "apexcharts-series",
                seriesName: P.escapeString(r.globals.seriesNames[u]),
                rel: f + 1,
                "data:realIndex": u
              });
              s.ctx.series.addCollapsedClassToSeries(M, u);
              var z = s.graphics.group({
                  class: "apexcharts-datalabels",
                  "data:realIndex": u
                }),
                I = s.graphics.group({
                  class: "apexcharts-bar-goals-markers"
                }),
                T = 0,
                E = 0,
                H = s.initialPositions(l, c, m, v, y, h, L);
              c = H.y, v = H.yDivision, h = H.zeroW, l = H.x, E = H.barWidth, m = H.xDivision, y = H.zeroH,
                r.globals.barHeight = T = H.barHeight, r.globals.barWidth = E, s.barHelpers
                .initializeStackedXYVars(s), 1 === s.groupCtx.prevY.length && s.groupCtx.prevY[0].every(
                  function(U) {
                    return isNaN(U)
                  }) && (s.groupCtx.prevY[0] = s.groupCtx.prevY[0].map(function() {
                  return y
                }), s.groupCtx.prevYF[0] = s.groupCtx.prevYF[0].map(function() {
                  return 0
                }));
              for (var D = 0; D < r.globals.dataPoints; D++) {
                var O = s.barHelpers.getStrokeWidth(f, D, u),
                  W = {
                    indexes: {
                      i: f,
                      j: D,
                      realIndex: u,
                      translationsIndex: L,
                      bc: x
                    },
                    strokeWidth: O,
                    x: l,
                    y: c,
                    elSeries: M,
                    columnGroupIndex: A,
                    seriesGroup: r.globals.seriesGroups[k]
                  },
                  N = null;
                s.isHorizontal ? (N = s.drawStackedBarPaths(Y(Y({}, W), {}, {
                  zeroW: h,
                  barHeight: T,
                  yDivision: v
                })), E = s.series[f][D] / s.invertedYRatio) : (N = s.drawStackedColumnPaths(Y(Y({},
                  W), {}, {
                    xDivision: m,
                    barWidth: E,
                    zeroH: y
                  })), T = s.series[f][D] / s.yRatio[L]);
                var B = s.barHelpers.drawGoalLine({
                  barXPosition: N.barXPosition,
                  barYPosition: N.barYPosition,
                  goalX: N.goalX,
                  goalY: N.goalY,
                  barHeight: T,
                  barWidth: E
                });
                B && I.add(B), c = N.y, S.push(l = N.x), C.push(c);
                var Z = s.barHelpers.getPathFillColor(i, f, D, u);
                M = s.renderSeries({
                  realIndex: u,
                  pathFill: Z,
                  j: D,
                  i: f,
                  columnGroupIndex: A,
                  pathFrom: N.pathFrom,
                  pathTo: N.pathTo,
                  strokeWidth: O,
                  elSeries: M,
                  x: l,
                  y: c,
                  series: i,
                  barHeight: T,
                  barWidth: E,
                  elDataLabelsWrap: z,
                  elGoalsMarkers: I,
                  type: "bar",
                  visibleSeries: 0
                })
              }
              r.globals.seriesXvalues[u] = S, r.globals.seriesYvalues[u] = C, s.groupCtx.prevY.push(s
                .groupCtx.yArrj), s.groupCtx.prevYF.push(s.groupCtx.yArrjF), s.groupCtx.prevYVal.push(s
                .groupCtx.yArrjVal), s.groupCtx.prevX.push(s.groupCtx.xArrj), s.groupCtx.prevXF.push(s
                .groupCtx.xArrjF), s.groupCtx.prevXVal.push(s.groupCtx.xArrjVal), o.add(M)
            }, g = 0, p = 0; g < i.length; g++, p++) d(g, p);
          return o
        }
      }, {
        key: "initialPositions",
        value: function(i, a, s, r, n, o, l) {
          var c, d, g = this.w;
          if (this.isHorizontal) {
            r = g.globals.gridHeight / g.globals.dataPoints;
            var p = g.config.plotOptions.bar.barHeight;
            c = -1 === String(p).indexOf("%") ? parseInt(p, 10) : r * parseInt(p, 10) / 100, o = g.globals
              .padHorizontal + (this.isReversed ? g.globals.gridWidth - this.baseLineInvertedY : this
                .baseLineInvertedY), a = (r - c) / 2
          } else {
            d = s = g.globals.gridWidth / g.globals.dataPoints;
            var f = g.config.plotOptions.bar.columnWidth;
            g.globals.isXNumeric && g.globals.dataPoints > 1 ? d = (s = g.globals.minXDiff / this.xRatio) *
              parseInt(this.barOptions.columnWidth, 10) / 100 : -1 === String(f).indexOf("%") ? d = parseInt(
                f, 10) : d *= parseInt(f, 10) / 100, n = g.globals.gridHeight - this.baseLineY[l] - (this
                .isReversed ? g.globals.gridHeight : 0), i = g.globals.padHorizontal + (s - d) / 2
          }
          var x = g.globals.barGroups.length || 1;
          return {
            x: i,
            y: a,
            yDivision: r,
            xDivision: s,
            barHeight: c / x,
            barWidth: d / x,
            zeroH: n,
            zeroW: o
          }
        }
      }, {
        key: "drawStackedBarPaths",
        value: function(i) {
          for (var a, l, s = i.indexes, r = i.barHeight, n = i.strokeWidth, o = i.zeroW, c = i.y, g = i
              .seriesGroup, p = i.yDivision, f = i.elSeries, x = this.w, m = c + i.columnGroupIndex * r, v = s
              .i, y = s.j, h = s.realIndex, u = s.translationsIndex, b = 0, k = 0; k < this.groupCtx.prevXF
            .length; k++) b += this.groupCtx.prevXF[k][y];
          var A;
          if ((A = g.indexOf(x.config.series[h].name)) > 0) {
            var S = o;
            this.groupCtx.prevXVal[A - 1][y] < 0 ? S = this.series[v][y] >= 0 ? this.groupCtx.prevX[A - 1][
              y] + b - 2 * (this.isReversed ? b : 0) : this.groupCtx.prevX[A - 1][y] : this.groupCtx.prevXVal[
                A - 1][y] >= 0 && (S = this.series[v][y] >= 0 ? this.groupCtx.prevX[A - 1][y] : this.groupCtx
                .prevX[A - 1][y] - b + 2 * (this.isReversed ? b : 0)), a = S
          } else a = o;
          var C = this.barHelpers.getBarpaths({
            barYPosition: m,
            barHeight: r,
            x1: a,
            x2: l = null === this.series[v][y] ? a : a + this.series[v][y] / this.invertedYRatio - 2 * (
              this.isReversed ? this.series[v][y] / this.invertedYRatio : 0),
            strokeWidth: n,
            series: this.series,
            realIndex: s.realIndex,
            seriesGroup: g,
            i: v,
            j: y,
            w: x
          });
          return this.barHelpers.barBackground({
            j: y,
            i: v,
            y1: m,
            y2: r,
            elSeries: f
          }), c += p, {
            pathTo: C.pathTo,
            pathFrom: C.pathFrom,
            goalX: this.barHelpers.getGoalValues("x", o, null, v, y, u),
            barXPosition: a,
            barYPosition: m,
            x: l,
            y: c
          }
        }
      }, {
        key: "drawStackedColumnPaths",
        value: function(i) {
          var r, a = i.indexes,
            s = i.x,
            n = i.xDivision,
            o = i.barWidth,
            l = i.zeroH,
            d = i.seriesGroup,
            g = i.elSeries,
            p = this.w,
            f = a.i,
            x = a.j,
            m = a.bc,
            v = a.realIndex,
            y = a.translationsIndex;
          if (p.globals.isXNumeric) {
            var h = p.globals.seriesX[v][x];
            h || (h = 0), s = (h - p.globals.minX) / this.xRatio - o / 2 * p.globals.barGroups.length
          }
          for (var u, b = s + i.columnGroupIndex * o, k = 0, A = 0; A < this.groupCtx.prevYF.length; A++) k +=
            isNaN(this.groupCtx.prevYF[A][x]) ? 0 : this.groupCtx.prevYF[A][x];
          var S = f;
          if (d && (S = d.indexOf(p.globals.seriesNames[v])), S > 0 && !p.globals.isXNumeric || S > 0 && p
            .globals.isXNumeric && p.globals.seriesX[v - 1][x] === p.globals.seriesX[v][x]) {
            var C, L, M, z = Math.min(this.yRatio.length + 1, v + 1);
            if (void 0 !== this.groupCtx.prevY[S - 1] && this.groupCtx.prevY[S - 1].length)
              for (var I = 1; I < z; I++) {
                var T;
                if (!isNaN(null === (T = this.groupCtx.prevY[S - I]) || void 0 === T ? void 0 : T[x])) {
                  M = this.groupCtx.prevY[S - I][x];
                  break
                }
              }
            for (var E = 1; E < z; E++) {
              var H, D;
              if ((null === (H = this.groupCtx.prevYVal[S - E]) || void 0 === H ? void 0 : H[x]) < 0) {
                L = this.series[f][x] >= 0 ? M - k + 2 * (this.isReversed ? k : 0) : M;
                break
              }
              if ((null === (D = this.groupCtx.prevYVal[S - E]) || void 0 === D ? void 0 : D[x]) >= 0) {
                L = this.series[f][x] >= 0 ? M : M + k - 2 * (this.isReversed ? k : 0);
                break
              }
            }
            void 0 === L && (L = p.globals.gridHeight), u = null !== (C = this.groupCtx.prevYF[0]) &&
              void 0 !== C && C.every(function(W) {
                return 0 === W
              }) && this.groupCtx.prevYF.slice(1, S).every(function(W) {
                return W.every(function(N) {
                  return isNaN(N)
                })
              }) ? l : L
          } else u = l;
          var O = this.barHelpers.getColumnPaths({
            barXPosition: b,
            barWidth: o,
            y1: u,
            y2: r = this.series[f][x] ? u - this.series[f][x] / this.yRatio[y] + 2 * (this.isReversed ?
              this.series[f][x] / this.yRatio[y] : 0) : u,
            yRatio: this.yRatio[y],
            strokeWidth: this.strokeWidth,
            series: this.series,
            seriesGroup: d,
            realIndex: a.realIndex,
            i: f,
            j: x,
            w: p
          });
          return this.barHelpers.barBackground({
            bc: m,
            j: x,
            i: f,
            x1: b,
            x2: o,
            elSeries: g
          }), s += n, {
            pathTo: O.pathTo,
            pathFrom: O.pathFrom,
            goalY: this.barHelpers.getGoalValues("y", null, l, f, x),
            barXPosition: b,
            x: p.globals.isXNumeric ? s - n : s,
            y: r
          }
        }
      }]), t
    }(pe),
    Re = function(w) {
      xe(t, w);
      var e = be(t);

      function t() {
        return F(this, t), e.apply(this, arguments)
      }
      return R(t, [{
        key: "draw",
        value: function(i, a, s) {
          var r = this,
            n = this.w,
            o = new X(this.ctx),
            l = n.globals.comboCharts ? a : n.config.chart.type,
            c = new re(this.ctx);
          this.candlestickOptions = this.w.config.plotOptions.candlestick, this.boxOptions = this.w.config
            .plotOptions.boxPlot, this.isHorizontal = n.config.plotOptions.bar.horizontal;
          var d = new q(this.ctx, n);
          i = d.getLogSeries(i), this.series = i, this.yRatio = d.getLogYRatios(this.yRatio), this.barHelpers
            .initVariables(i);
          for (var g = o.group({
              class: "apexcharts-".concat(l, "-series apexcharts-plot-series")
            }), p = function(x) {
              r.isBoxPlot = "boxPlot" === n.config.chart.type || "boxPlot" === n.config.series[x].type;
              var m, v, y, h, u = void 0,
                b = void 0,
                k = [],
                A = [],
                S = n.globals.comboCharts ? s[x] : x,
                C = r.barHelpers.getGroupIndex(S).columnGroupIndex,
                L = o.group({
                  class: "apexcharts-series",
                  seriesName: P.escapeString(n.globals.seriesNames[S]),
                  rel: x + 1,
                  "data:realIndex": S
                });
              r.ctx.series.addCollapsedClassToSeries(L, S), i[x].length > 0 && (r.visibleI = r.visibleI +
              1);
              var M, z, I = 0;
              r.yRatio.length > 1 && (r.yaxisIndex = n.globals.seriesYAxisReverseMap[S][0], I = S);
              var T = r.barHelpers.initialPositions();
              b = T.y, M = T.barHeight, v = T.yDivision, h = T.zeroW, m = T.xDivision, y = T.zeroH, A.push((
                u = T.x) + (z = T.barWidth) / 2);
              for (var E = o.group({
                  class: "apexcharts-datalabels",
                  "data:realIndex": S
                }), H = function(O) {
                  var W = r.barHelpers.getStrokeWidth(x, O, S),
                    N = null,
                    B = {
                      indexes: {
                        i: x,
                        j: O,
                        realIndex: S,
                        translationsIndex: I
                      },
                      x: u,
                      y: b,
                      strokeWidth: W,
                      elSeries: L
                    };
                  N = r.isHorizontal ? r.drawHorizontalBoxPaths(Y(Y({}, B), {}, {
                    yDivision: v,
                    barHeight: M,
                    zeroW: h
                  })) : r.drawVerticalBoxPaths(Y(Y({}, B), {}, {
                    xDivision: m,
                    barWidth: z,
                    zeroH: y
                  })), b = N.y, u = N.x, O > 0 && A.push(u + z / 2), k.push(b), N.pathTo.forEach(
                    function(Z, U) {
                      var _ = !r.isBoxPlot && r.candlestickOptions.wick.useFillColor ? N.color[U] : n
                        .globals.stroke.colors[x],
                        ae = c.fillPath({
                          seriesNumber: S,
                          dataPointIndex: O,
                          color: N.color[U],
                          value: i[x][O]
                        });
                      r.renderSeries({
                        realIndex: S,
                        pathFill: ae,
                        lineFill: _,
                        j: O,
                        i: x,
                        pathFrom: N.pathFrom,
                        pathTo: Z,
                        strokeWidth: W,
                        elSeries: L,
                        x: u,
                        y: b,
                        series: i,
                        columnGroupIndex: C,
                        barHeight: M,
                        barWidth: z,
                        elDataLabelsWrap: E,
                        visibleSeries: r.visibleI,
                        type: n.config.chart.type
                      })
                    })
                }, D = 0; D < n.globals.dataPoints; D++) H(D);
              n.globals.seriesXvalues[S] = A, n.globals.seriesYvalues[S] = k, g.add(L)
            }, f = 0; f < i.length; f++) p(f);
          return g
        }
      }, {
        key: "drawVerticalBoxPaths",
        value: function(i) {
          var a = i.indexes,
            s = i.x,
            r = i.xDivision,
            n = i.barWidth,
            o = i.zeroH,
            l = i.strokeWidth,
            c = this.w,
            d = new X(this.ctx),
            g = a.i,
            p = a.j,
            f = !0,
            x = c.config.plotOptions.candlestick.colors.upward,
            m = c.config.plotOptions.candlestick.colors.downward,
            v = "";
          this.isBoxPlot && (v = [this.boxOptions.colors.lower, this.boxOptions.colors.upper]);
          var y = this.yRatio[a.translationsIndex],
            h = a.realIndex,
            u = this.getOHLCValue(h, p),
            b = o,
            k = o;
          u.o > u.c && (f = !1);
          var A = Math.min(u.o, u.c),
            S = Math.max(u.o, u.c),
            C = u.m;
          c.globals.isXNumeric && (s = (c.globals.seriesX[h][p] - c.globals.minX) / this.xRatio - n / 2);
          var L = s + n * this.visibleI;
          null == this.series[g][p] ? (A = o, S = o) : (A = o - A / y, S = o - S / y, b = o - u.h / y, k = o -
            u.l / y, C = o - u.m / y);
          var M = d.move(L, o),
            z = d.move(L + n / 2, A);
          return c.globals.previousPaths.length > 0 && (z = this.getPreviousPath(h, p, !0)), M = this
            .isBoxPlot ? [d.move(L, A) + d.line(L + n / 2, A) + d.line(L + n / 2, b) + d.line(L + n / 4, b) +
              d.line(L + n - n / 4, b) + d.line(L + n / 2, b) + d.line(L + n / 2, A) + d.line(L + n, A) + d
              .line(L + n, C) + d.line(L, C) + d.line(L, A + l / 2), d.move(L, C) + d.line(L + n, C) + d.line(
                L + n, S) + d.line(L + n / 2, S) + d.line(L + n / 2, k) + d.line(L + n - n / 4, k) + d.line(
                L + n / 4, k) + d.line(L + n / 2, k) + d.line(L + n / 2, S) + d.line(L, S) + d.line(L, C) +
              "z"
            ] : [d.move(L, S) + d.line(L + n / 2, S) + d.line(L + n / 2, b) + d.line(L + n / 2, S) + d.line(
              L + n, S) + d.line(L + n, A) + d.line(L + n / 2, A) + d.line(L + n / 2, k) + d.line(L + n / 2,
              A) + d.line(L, A) + d.line(L, S - l / 2)], z += d.move(L, A), c.globals.isXNumeric || (s +=
            r), {
              pathTo: M,
              pathFrom: z,
              x: s,
              y: S,
              barXPosition: L,
              color: this.isBoxPlot ? v : f ? [x] : [m]
            }
        }
      }, {
        key: "drawHorizontalBoxPaths",
        value: function(i) {
          var a = i.indexes,
            s = i.y,
            r = i.yDivision,
            n = i.barHeight,
            o = i.zeroW,
            l = i.strokeWidth,
            c = this.w,
            d = new X(this.ctx),
            g = a.i,
            p = a.j,
            f = this.boxOptions.colors.lower;
          this.isBoxPlot && (f = [this.boxOptions.colors.lower, this.boxOptions.colors.upper]);
          var x = this.invertedYRatio,
            m = a.realIndex,
            v = this.getOHLCValue(m, p),
            y = o,
            h = o,
            u = Math.min(v.o, v.c),
            b = Math.max(v.o, v.c),
            k = v.m;
          c.globals.isXNumeric && (s = (c.globals.seriesX[m][p] - c.globals.minX) / this.invertedXRatio - n /
            2);
          var A = s + n * this.visibleI;
          null == this.series[g][p] ? (u = o, b = o) : (u = o + u / x, b = o + b / x, y = o + v.h / x, h = o +
            v.l / x, k = o + v.m / x);
          var S = d.move(o, A),
            C = d.move(u, A + n / 2);
          return c.globals.previousPaths.length > 0 && (C = this.getPreviousPath(m, p, !0)), S = [d.move(u,
            A) + d.line(u, A + n / 2) + d.line(y, A + n / 2) + d.line(y, A + n / 2 - n / 4) + d.line(y, A +
              n / 2 + n / 4) + d.line(y, A + n / 2) + d.line(u, A + n / 2) + d.line(u, A + n) + d.line(k,
              A + n) + d.line(k, A) + d.line(u + l / 2, A), d.move(k, A) + d.line(k, A + n) + d.line(b, A +
              n) + d.line(b, A + n / 2) + d.line(h, A + n / 2) + d.line(h, A + n - n / 4) + d.line(h, A +
              n / 4) + d.line(h, A + n / 2) + d.line(b, A + n / 2) + d.line(b, A) + d.line(k, A) + "z"
          ], C += d.move(u, A), c.globals.isXNumeric || (s += r), {
            pathTo: S,
            pathFrom: C,
            x: b,
            y: s,
            barYPosition: A,
            color: f
          }
        }
      }, {
        key: "getOHLCValue",
        value: function(i, a) {
          var s = this.w;
          return {
            o: this.isBoxPlot ? s.globals.seriesCandleH[i][a] : s.globals.seriesCandleO[i][a],
            h: this.isBoxPlot ? s.globals.seriesCandleO[i][a] : s.globals.seriesCandleH[i][a],
            m: s.globals.seriesCandleM[i][a],
            l: this.isBoxPlot ? s.globals.seriesCandleC[i][a] : s.globals.seriesCandleL[i][a],
            c: this.isBoxPlot ? s.globals.seriesCandleL[i][a] : s.globals.seriesCandleC[i][a]
          }
        }
      }]), t
    }(pe),
    it = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "checkColorRange",
        value: function() {
          var e = this.w,
            t = !1,
            i = e.config.plotOptions[e.config.chart.type];
          return i.colorScale.ranges.length > 0 && i.colorScale.ranges.map(function(a, s) {
            a.from <= 0 && (t = !0)
          }), t
        }
      }, {
        key: "getShadeColor",
        value: function(e, t, i, a) {
          var s = this.w,
            r = 1,
            n = s.config.plotOptions[e].shadeIntensity,
            o = this.determineColor(e, t, i);
          s.globals.hasNegs || a ? r = s.config.plotOptions[e].reverseNegativeShade ? o.percent < 0 ? o
            .percent / 100 * (1.25 * n) : 1.25 * n * (1 - o.percent / 100) : o.percent <= 0 ? 1 - (1 + o
              .percent / 100) * n : (1 - o.percent / 100) * n : (r = 1 - o.percent / 100, "treemap" === e && (
              r = 1.25 * n * (1 - o.percent / 100)));
          var l = o.color,
            c = new P;
          return s.config.plotOptions[e].enableShades && (l = P.hexToRgba(c.shadeColor("dark" === this.w
            .config.theme.mode ? -1 * r : r, o.color), s.config.fill.opacity)), {
            color: l,
            colorProps: o
          }
        }
      }, {
        key: "determineColor",
        value: function(e, t, i) {
          var a = this.w,
            s = a.globals.series[t][i],
            r = a.config.plotOptions[e],
            n = r.colorScale.inverse ? i : t;
          r.distributed && "treemap" === a.config.chart.type && (n = i);
          var o = a.globals.colors[n],
            l = null,
            c = Math.min.apply(Math, J(a.globals.series[t])),
            d = Math.max.apply(Math, J(a.globals.series[t]));
          r.distributed || "heatmap" !== e || (c = a.globals.minY, d = a.globals.maxY), void 0 !== r
            .colorScale.min && (c = r.colorScale.min < a.globals.minY ? r.colorScale.min : a.globals.minY, d =
              r.colorScale.max > a.globals.maxY ? r.colorScale.max : a.globals.maxY);
          var g = Math.abs(d) + Math.abs(c),
            p = 100 * s / (0 === g ? g - 1e-6 : g);
          return r.colorScale.ranges.length > 0 && r.colorScale.ranges.map(function(f, x) {
            if (s >= f.from && s <= f.to) {
              o = f.color, l = f.foreColor ? f.foreColor : null, c = f.from, d = f.to;
              var m = Math.abs(d) + Math.abs(c);
              p = 100 * s / (0 === m ? m - 1e-6 : m)
            }
          }), {
            color: o,
            foreColor: l,
            percent: p
          }
        }
      }, {
        key: "calculateDataLabels",
        value: function(e) {
          var t = e.text,
            i = e.x,
            a = e.y,
            s = e.i,
            r = e.j,
            n = e.colorProps,
            o = e.fontSize,
            l = this.w.config.dataLabels,
            c = new X(this.ctx),
            d = new ue(this.ctx),
            g = null;
          if (l.enabled) {
            g = c.group({
              class: "apexcharts-data-labels"
            });
            var f = l.offsetY,
              x = i + l.offsetX,
              m = a + parseFloat(l.style.fontSize) / 3 + f;
            d.plotDataLabelsText({
              x,
              y: m,
              text: t,
              i: s,
              j: r,
              color: n.foreColor,
              parent: g,
              fontSize: o,
              dataLabelsConfig: l
            })
          }
          return g
        }
      }, {
        key: "addListeners",
        value: function(e) {
          var t = new X(this.ctx);
          e.node.addEventListener("mouseenter", t.pathMouseEnter.bind(this, e)), e.node.addEventListener(
            "mouseleave", t.pathMouseLeave.bind(this, e)), e.node.addEventListener("mousedown", t
            .pathMouseDown.bind(this, e))
        }
      }]), w
    }(),
    Tt = function() {
      function w(e, t) {
        F(this, w), this.ctx = e, this.w = e.w, this.xRatio = t.xRatio, this.yRatio = t.yRatio, this.dynamicAnim =
          this.w.config.chart.animations.dynamicAnimation, this.helpers = new it(e), this.rectRadius = this.w.config
          .plotOptions.heatmap.radius, this.strokeWidth = this.w.config.stroke.show ? this.w.config.stroke.width : 0
      }
      return R(w, [{
        key: "draw",
        value: function(e) {
          var t = this.w,
            i = new X(this.ctx),
            a = i.group({
              class: "apexcharts-heatmap"
            });
          a.attr("clip-path", "url(#gridRectMask".concat(t.globals.cuid, ")"));
          var s = t.globals.gridWidth / t.globals.dataPoints,
            r = t.globals.gridHeight / t.globals.series.length,
            n = 0,
            o = !1;
          this.negRange = this.helpers.checkColorRange();
          var l = e.slice();
          t.config.yaxis[0].reversed && (o = !0, l.reverse());
          for (var c = o ? 0 : l.length - 1; o ? c < l.length : c >= 0; o ? c++ : c--) {
            var d = i.group({
              class: "apexcharts-series apexcharts-heatmap-series",
              seriesName: P.escapeString(t.globals.seriesNames[c]),
              rel: c + 1,
              "data:realIndex": c
            });
            if (this.ctx.series.addCollapsedClassToSeries(d, c), t.config.chart.dropShadow.enabled) {
              var g = t.config.chart.dropShadow;
              new K(this.ctx).dropShadow(d, g, c)
            }
            for (var p = 0, f = t.config.plotOptions.heatmap.shadeIntensity, x = 0; x < l[c].length; x++) {
              var m = this.helpers.getShadeColor(t.config.chart.type, c, x, this.negRange),
                v = m.color,
                y = m.colorProps;
              "image" === t.config.fill.type && (v = new re(this.ctx).fillPath({
                seriesNumber: c,
                dataPointIndex: x,
                opacity: t.globals.hasNegs ? y.percent < 0 ? 1 - (1 + y.percent / 100) : f + y.percent /
                  100 : y.percent / 100,
                patternID: P.randomId(),
                width: t.config.fill.image.width ? t.config.fill.image.width : s,
                height: t.config.fill.image.height ? t.config.fill.image.height : r
              }));
              var u = i.drawRect(p, n, s, r, this.rectRadius);
              if (u.attr({
                  cx: p,
                  cy: n
                }), u.node.classList.add("apexcharts-heatmap-rect"), d.add(u), u.attr({
                  fill: v,
                  i: c,
                  index: c,
                  j: x,
                  val: e[c][x],
                  "stroke-width": this.strokeWidth,
                  stroke: t.config.plotOptions.heatmap.useFillColorAsStroke ? v : t.globals.stroke.colors[
                    0],
                  color: v
                }), this.helpers.addListeners(u), t.config.chart.animations.enabled && !t.globals
                .dataChanged) {
                var b = 1;
                t.globals.resized || (b = t.config.chart.animations.speed), this.animateHeatMap(u, p, n, s, r,
                  b)
              }
              if (t.globals.dataChanged) {
                var k = 1;
                if (this.dynamicAnim.enabled && t.globals.shouldAnimate) {
                  k = this.dynamicAnim.speed;
                  var A = t.globals.previousPaths[c] && t.globals.previousPaths[c][x] && t.globals
                    .previousPaths[c][x].color;
                  A || (A = "rgba(255, 255, 255, 0)"), this.animateHeatColor(u, P.isColorHex(A) ? A : P
                    .rgb2hex(A), P.isColorHex(v) ? v : P.rgb2hex(v), k)
                }
              }
              var S = (0, t.config.dataLabels.formatter)(t.globals.series[c][x], {
                  value: t.globals.series[c][x],
                  seriesIndex: c,
                  dataPointIndex: x,
                  w: t
                }),
                C = this.helpers.calculateDataLabels({
                  text: S,
                  x: p + s / 2,
                  y: n + r / 2,
                  i: c,
                  j: x,
                  colorProps: y,
                  series: l
                });
              null !== C && d.add(C), p += s
            }
            n += r, a.add(d)
          }
          var L = t.globals.yAxisScale[0].result.slice();
          return t.config.yaxis[0].reversed ? L.unshift("") : L.push(""), t.globals.yAxisScale[0].result = L,
            a
        }
      }, {
        key: "animateHeatMap",
        value: function(e, t, i, a, s, r) {
          var n = new ge(this.ctx);
          n.animateRect(e, {
            x: t + a / 2,
            y: i + s / 2,
            width: 0,
            height: 0
          }, {
            x: t,
            y: i,
            width: a,
            height: s
          }, r, function() {
            n.animationCompleted(e)
          })
        }
      }, {
        key: "animateHeatColor",
        value: function(e, t, i, a) {
          e.attr({
            fill: t
          }).animate(a).attr({
            fill: i
          })
        }
      }]), w
    }(),
    at = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "drawYAxisTexts",
        value: function(e, t, i, a) {
          var s = this.w,
            r = s.config.yaxis[0],
            n = s.globals.yLabelFormatters[0];
          return new X(this.ctx).drawText({
            x: e + r.labels.offsetX,
            y: t + r.labels.offsetY,
            text: n(a, i),
            textAnchor: "middle",
            fontSize: r.labels.style.fontSize,
            fontFamily: r.labels.style.fontFamily,
            foreColor: Array.isArray(r.labels.style.colors) ? r.labels.style.colors[i] : r.labels.style
              .colors
          })
        }
      }]), w
    }(),
    st = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w;
        var t = this.w;
        this.chartType = this.w.config.chart.type, this.initialAnim = this.w.config.chart.animations.enabled, this
          .dynamicAnim = this.initialAnim && this.w.config.chart.animations.dynamicAnimation.enabled, this
          .animBeginArr = [0], this.animDur = 0, this.donutDataLabels = this.w.config.plotOptions.pie.donut.labels,
          this.lineColorArr = void 0 !== t.globals.stroke.colors ? t.globals.stroke.colors : t.globals.colors, this
          .defaultSize = Math.min(t.globals.gridWidth, t.globals.gridHeight), this.centerY = this.defaultSize / 2,
          this.centerX = t.globals.gridWidth / 2, this.fullAngle = "radialBar" === t.config.chart.type ? 360 : Math
          .abs(t.config.plotOptions.pie.endAngle - t.config.plotOptions.pie.startAngle), this.initialAngle = t.config
          .plotOptions.pie.startAngle % this.fullAngle, t.globals.radialSize = this.defaultSize / 2.05 - t.config
          .stroke.width - (t.config.chart.sparkline.enabled ? 0 : t.config.chart.dropShadow.blur), this.donutSize = t
          .globals.radialSize * parseInt(t.config.plotOptions.pie.donut.size, 10) / 100, this.maxY = 0, this
          .sliceLabels = [], this.sliceSizes = [], this.prevSectorAngleArr = []
      }
      return R(w, [{
        key: "draw",
        value: function(e) {
          var t = this,
            i = this.w,
            a = new X(this.ctx);
          if (this.ret = a.group({
              class: "apexcharts-pie"
            }), i.globals.noData) return this.ret;
          for (var s = 0, r = 0; r < e.length; r++) s += P.negToZero(e[r]);
          var n = [],
            o = a.group();
          0 === s && (s = 1e-5), e.forEach(function(A) {
              t.maxY = Math.max(t.maxY, A)
            }), i.config.yaxis[0].max && (this.maxY = i.config.yaxis[0].max), "back" === i.config.grid
            .position && "polarArea" === this.chartType && this.drawPolarElements(this.ret);
          for (var l = 0; l < e.length; l++) {
            var c = this.fullAngle * P.negToZero(e[l]) / s;
            n.push(c), "polarArea" === this.chartType ? (n[l] = this.fullAngle / e.length, this.sliceSizes
              .push(i.globals.radialSize * e[l] / this.maxY)) : this.sliceSizes.push(i.globals.radialSize)
          }
          if (i.globals.dataChanged) {
            for (var d, g = 0, p = 0; p < i.globals.previousPaths.length; p++) g += P.negToZero(i.globals
              .previousPaths[p]);
            for (var f = 0; f < i.globals.previousPaths.length; f++) d = this.fullAngle * P.negToZero(i
              .globals.previousPaths[f]) / g, this.prevSectorAngleArr.push(d)
          }
          this.donutSize < 0 && (this.donutSize = 0);
          var x = i.config.plotOptions.pie.customScale,
            y = i.globals.gridWidth / 2 - i.globals.gridWidth / 2 * x,
            h = i.globals.gridHeight / 2 - i.globals.gridHeight / 2 * x;
          if ("donut" === this.chartType) {
            var u = a.drawCircle(this.donutSize);
            u.attr({
              cx: this.centerX,
              cy: this.centerY,
              fill: i.config.plotOptions.pie.donut.background ? i.config.plotOptions.pie.donut
                .background : "transparent"
            }), o.add(u)
          }
          var b = this.drawArcs(n, e);
          if (this.sliceLabels.forEach(function(A) {
              b.add(A)
            }), o.attr({
              transform: "translate(".concat(y, ", ").concat(h, ") scale(").concat(x, ")")
            }), o.add(b), this.ret.add(o), this.donutDataLabels.show) {
            var k = this.renderInnerDataLabels(this.donutDataLabels, {
              hollowSize: this.donutSize,
              centerX: this.centerX,
              centerY: this.centerY,
              opacity: this.donutDataLabels.show,
              translateX: y,
              translateY: h
            });
            this.ret.add(k)
          }
          return "front" === i.config.grid.position && "polarArea" === this.chartType && this
            .drawPolarElements(this.ret), this.ret
        }
      }, {
        key: "drawArcs",
        value: function(e, t) {
          var i = this.w,
            a = new K(this.ctx),
            s = new X(this.ctx),
            r = new re(this.ctx),
            n = s.group({
              class: "apexcharts-slices"
            }),
            o = this.initialAngle,
            l = this.initialAngle,
            c = this.initialAngle,
            d = this.initialAngle;
          this.strokeWidth = i.config.stroke.show ? i.config.stroke.width : 0;
          for (var g = 0; g < e.length; g++) {
            var p = s.group({
              class: "apexcharts-series apexcharts-pie-series",
              seriesName: P.escapeString(i.globals.seriesNames[g]),
              rel: g + 1,
              "data:realIndex": g
            });
            n.add(p), c = (o = c) + e[g], d = (l = d) + this.prevSectorAngleArr[g];
            var f = c < o ? this.fullAngle + c - o : c - o,
              x = r.fillPath({
                seriesNumber: g,
                size: this.sliceSizes[g],
                value: t[g]
              }),
              m = this.getChangedPath(l, d),
              v = s.drawPath({
                d: m,
                stroke: Array.isArray(this.lineColorArr) ? this.lineColorArr[g] : this.lineColorArr,
                strokeWidth: 0,
                fill: x,
                fillOpacity: i.config.fill.opacity,
                classes: "apexcharts-pie-area apexcharts-".concat(this.chartType.toLowerCase(), "-slice-")
                  .concat(g)
              });
            v.attr({
              index: 0,
              j: g
            }), a.setSelectionFilter(v, 0, g), i.config.chart.dropShadow.enabled && a.dropShadow(v, i.config
              .chart.dropShadow, g), this.addListeners(v, this.donutDataLabels), X.setAttrs(v.node, {
              "data:angle": f,
              "data:startAngle": o,
              "data:strokeWidth": this.strokeWidth,
              "data:value": t[g]
            });
            var h = {
              x: 0,
              y: 0
            };
            "pie" === this.chartType || "polarArea" === this.chartType ? h = P.polarToCartesian(this.centerX,
              this.centerY, i.globals.radialSize / 1.25 + i.config.plotOptions.pie.dataLabels.offset, (o +
                f / 2) % this.fullAngle) : "donut" === this.chartType && (h = P.polarToCartesian(this
              .centerX, this.centerY, (i.globals.radialSize + this.donutSize) / 2 + i.config.plotOptions
              .pie.dataLabels.offset, (o + f / 2) % this.fullAngle)), p.add(v);
            var u = 0;
            if (!this.initialAnim || i.globals.resized || i.globals.dataChanged ? this.animBeginArr.push(0) :
              (0 == (u = f / this.fullAngle * i.config.chart.animations.speed) && (u = 1), this.animDur = u +
                this.animDur, this.animBeginArr.push(this.animDur)), this.animatePaths(v, this.dynamicAnim &&
                i.globals.dataChanged ? {
                  size: this.sliceSizes[g],
                  endAngle: c,
                  startAngle: o,
                  prevStartAngle: l,
                  prevEndAngle: d,
                  animateStartingPos: !0,
                  i: g,
                  animBeginArr: this.animBeginArr,
                  shouldSetPrevPaths: !0,
                  dur: i.config.chart.animations.dynamicAnimation.speed
                } : {
                  size: this.sliceSizes[g],
                  endAngle: c,
                  startAngle: o,
                  i: g,
                  totalItems: e.length - 1,
                  animBeginArr: this.animBeginArr,
                  dur: u
                }), i.config.plotOptions.pie.expandOnClick && "polarArea" !== this.chartType && v.node
              .addEventListener("mouseup", this.pieClicked.bind(this, g)), void 0 !== i.globals
              .selectedDataPoints[0] && i.globals.selectedDataPoints[0].indexOf(g) > -1 && this.pieClicked(g),
              i.config.dataLabels.enabled) {
              var b = h.x,
                k = h.y,
                A = 100 * f / this.fullAngle + "%";
              if (0 !== f && i.config.plotOptions.pie.dataLabels.minAngleToShowLabel < e[g]) {
                var S = i.config.dataLabels.formatter;
                void 0 !== S && (A = S(i.globals.seriesPercent[g][0], {
                  seriesIndex: g,
                  w: i
                }));
                var C = i.globals.dataLabels.style.colors[g],
                  L = s.group({
                    class: "apexcharts-datalabels"
                  }),
                  M = s.drawText({
                    x: b,
                    y: k,
                    text: A,
                    textAnchor: "middle",
                    fontSize: i.config.dataLabels.style.fontSize,
                    fontFamily: i.config.dataLabels.style.fontFamily,
                    fontWeight: i.config.dataLabels.style.fontWeight,
                    foreColor: C
                  });
                L.add(M), i.config.dataLabels.dropShadow.enabled && a.dropShadow(M, i.config.dataLabels
                    .dropShadow), M.node.classList.add("apexcharts-pie-label"), i.config.chart.animations
                  .animate && !1 === i.globals.resized && (M.node.classList.add("apexcharts-pie-label-delay"),
                    M.node.style.animationDelay = i.config.chart.animations.speed / 940 + "s"), this
                  .sliceLabels.push(L)
              }
            }
          }
          return n
        }
      }, {
        key: "addListeners",
        value: function(e, t) {
          var i = new X(this.ctx);
          e.node.addEventListener("mouseenter", i.pathMouseEnter.bind(this, e)), e.node.addEventListener(
            "mouseleave", i.pathMouseLeave.bind(this, e)), e.node.addEventListener("mouseleave", this
            .revertDataLabelsInner.bind(this, e.node, t)), e.node.addEventListener("mousedown", i
            .pathMouseDown.bind(this, e)), this.donutDataLabels.total.showAlways || (e.node
            .addEventListener("mouseenter", this.printDataLabelsInner.bind(this, e.node, t)), e.node
            .addEventListener("mousedown", this.printDataLabelsInner.bind(this, e.node, t)))
        }
      }, {
        key: "animatePaths",
        value: function(e, t) {
          var a = t.endAngle < t.startAngle ? this.fullAngle + t.endAngle - t.startAngle : t.endAngle - t
            .startAngle,
            s = a,
            r = t.startAngle,
            n = t.startAngle;
          void 0 !== t.prevStartAngle && void 0 !== t.prevEndAngle && (r = t.prevEndAngle, s = t
              .prevEndAngle < t.prevStartAngle ? this.fullAngle + t.prevEndAngle - t.prevStartAngle : t
              .prevEndAngle - t.prevStartAngle), t.i === this.w.config.series.length - 1 && (a + n > this
              .fullAngle ? t.endAngle = t.endAngle - (a + n) : a + n < this.fullAngle && (t.endAngle = t
                .endAngle + (this.fullAngle - (a + n)))), a === this.fullAngle && (a = this.fullAngle - .01),
            this.animateArc(e, r, n, a, s, t)
        }
      }, {
        key: "animateArc",
        value: function(e, t, i, a, s, r) {
          var n, o = this,
            l = this.w,
            c = new ge(this.ctx),
            d = r.size;
          (isNaN(t) || isNaN(s)) && (t = i, s = a, r.dur = 0);
          var g = a,
            p = i,
            f = t < i ? this.fullAngle + t - i : t - i;
          l.globals.dataChanged && r.shouldSetPrevPaths && r.prevEndAngle && (n = o.getPiePath({
            me: o,
            startAngle: r.prevStartAngle,
            angle: r.prevEndAngle < r.prevStartAngle ? this.fullAngle + r.prevEndAngle - r
              .prevStartAngle : r.prevEndAngle - r.prevStartAngle,
            size: d
          }), e.attr({
            d: n
          })), 0 !== r.dur ? e.animate(r.dur, l.globals.easing, r.animBeginArr[r.i]).afterAll(function() {
            "pie" !== o.chartType && "donut" !== o.chartType && "polarArea" !== o.chartType || this
              .animate(l.config.chart.animations.dynamicAnimation.speed).attr({
                "stroke-width": o.strokeWidth
              }), r.i === l.config.series.length - 1 && c.animationCompleted(e)
          }).during(function(x) {
            g = f + (a - f) * x, r.animateStartingPos && (g = s + (a - s) * x, p = t - s + (i - (t - s)) *
              x), n = o.getPiePath({
              me: o,
              startAngle: p,
              angle: g,
              size: d
            }), e.node.setAttribute("data:pathOrig", n), e.attr({
              d: n
            })
          }) : (n = o.getPiePath({
              me: o,
              startAngle: p,
              angle: a,
              size: d
            }), r.isTrack || (l.globals.animationEnded = !0), e.node.setAttribute("data:pathOrig", n), e
            .attr({
              d: n,
              "stroke-width": o.strokeWidth
            }))
        }
      }, {
        key: "pieClicked",
        value: function(e) {
          var t, i = this.w,
            a = this,
            s = a.sliceSizes[e] + (i.config.plotOptions.pie.expandOnClick ? 4 : 0),
            r = i.globals.dom.Paper.select(".apexcharts-".concat(a.chartType.toLowerCase(), "-slice-").concat(
              e)).members[0];
          if ("true" !== r.attr("data:pieClicked")) {
            var n = i.globals.dom.baseEl.getElementsByClassName("apexcharts-pie-area");
            Array.prototype.forEach.call(n, function(d) {
              d.setAttribute("data:pieClicked", "false");
              var g = d.getAttribute("data:pathOrig");
              g && d.setAttribute("d", g)
            }), i.globals.capturedDataPointIndex = e, r.attr("data:pieClicked", "true");
            var o = parseInt(r.attr("data:startAngle"), 10),
              l = parseInt(r.attr("data:angle"), 10);
            t = a.getPiePath({
              me: a,
              startAngle: o,
              angle: l,
              size: s
            }), 360 !== l && r.plot(t)
          } else {
            r.attr({
              "data:pieClicked": "false"
            }), this.revertDataLabelsInner(r.node, this.donutDataLabels);
            var c = r.attr("data:pathOrig");
            r.attr({
              d: c
            })
          }
        }
      }, {
        key: "getChangedPath",
        value: function(e, t) {
          var i = "";
          return this.dynamicAnim && this.w.globals.dataChanged && (i = this.getPiePath({
            me: this,
            startAngle: e,
            angle: t - e,
            size: this.size
          })), i
        }
      }, {
        key: "getPiePath",
        value: function(e) {
          var t, i = e.me,
            a = e.startAngle,
            s = e.angle,
            r = e.size,
            n = new X(this.ctx),
            o = a,
            l = Math.PI * (o - 90) / 180,
            c = s + a;
          Math.ceil(c) >= this.fullAngle + this.w.config.plotOptions.pie.startAngle % this.fullAngle && (c =
              this.fullAngle + this.w.config.plotOptions.pie.startAngle % this.fullAngle - .01), Math.ceil(
            c) > this.fullAngle && (c -= this.fullAngle);
          var d = Math.PI * (c - 90) / 180,
            g = i.centerX + r * Math.cos(l),
            p = i.centerY + r * Math.sin(l),
            f = i.centerX + r * Math.cos(d),
            x = i.centerY + r * Math.sin(d),
            m = P.polarToCartesian(i.centerX, i.centerY, i.donutSize, c),
            v = P.polarToCartesian(i.centerX, i.centerY, i.donutSize, o),
            y = s > 180 ? 1 : 0,
            h = ["M", g, p, "A", r, r, 0, y, 1, f, x];
          return t = "donut" === i.chartType ? [].concat(h, ["L", m.x, m.y, "A", i.donutSize, i.donutSize, 0,
            y, 0, v.x, v.y, "L", g, p, "z"
          ]).join(" ") : "pie" === i.chartType || "polarArea" === i.chartType ? [].concat(h, ["L", i
            .centerX, i.centerY, "L", g, p
          ]).join(" ") : [].concat(h).join(" "), n.roundPathCorners(t, 2 * this.strokeWidth)
        }
      }, {
        key: "drawPolarElements",
        value: function(e) {
          var t = this.w,
            i = new Ze(this.ctx),
            a = new X(this.ctx),
            s = new at(this.ctx),
            r = a.group(),
            n = a.group(),
            o = i.niceScale(0, Math.ceil(this.maxY), 0),
            l = o.result.reverse(),
            c = o.result.length;
          this.maxY = o.niceMax;
          for (var d = t.globals.radialSize, g = d / (c - 1), p = 0; p < c - 1; p++) {
            var f = a.drawCircle(d);
            if (f.attr({
                cx: this.centerX,
                cy: this.centerY,
                fill: "none",
                "stroke-width": t.config.plotOptions.polarArea.rings.strokeWidth,
                stroke: t.config.plotOptions.polarArea.rings.strokeColor
              }), t.config.yaxis[0].show) {
              var x = s.drawYAxisTexts(this.centerX, this.centerY - d + parseInt(t.config.yaxis[0].labels
                .style.fontSize, 10) / 2, p, l[p]);
              n.add(x)
            }
            r.add(f), d -= g
          }
          this.drawSpokes(e), e.add(r), e.add(n)
        }
      }, {
        key: "renderInnerDataLabels",
        value: function(e, t) {
          var i = this.w,
            a = new X(this.ctx),
            s = a.group({
              class: "apexcharts-datalabels-group",
              transform: "translate(".concat(t.translateX ? t.translateX : 0, ", ").concat(t.translateY ? t
                .translateY : 0, ") scale(").concat(i.config.plotOptions.pie.customScale, ")")
            }),
            r = e.total.show;
          s.node.style.opacity = t.opacity;
          var n, o, l = t.centerX,
            c = t.centerY;
          n = void 0 === e.name.color ? i.globals.colors[0] : e.name.color;
          var d = e.name.fontSize,
            g = e.name.fontFamily,
            p = e.name.fontWeight;
          o = void 0 === e.value.color ? i.config.chart.foreColor : e.value.color;
          var f = e.value.formatter,
            x = "",
            m = "";
          if (r ? (n = e.total.color, d = e.total.fontSize, g = e.total.fontFamily, p = e.total.fontWeight,
              m = e.total.label, x = e.total.formatter(i)) : 1 === i.globals.series.length && (x = f(i.globals
              .series[0], i), m = i.globals.seriesNames[0]), m && (m = e.name.formatter(m, e.total.show, i)),
            e.name.show) {
            var v = a.drawText({
              x: l,
              y: c + parseFloat(e.name.offsetY),
              text: m,
              textAnchor: "middle",
              foreColor: n,
              fontSize: d,
              fontWeight: p,
              fontFamily: g
            });
            v.node.classList.add("apexcharts-datalabel-label"), s.add(v)
          }
          if (e.value.show) {
            var y = e.name.show ? parseFloat(e.value.offsetY) + 16 : e.value.offsetY,
              h = a.drawText({
                x: l,
                y: c + y,
                text: x,
                textAnchor: "middle",
                foreColor: o,
                fontWeight: e.value.fontWeight,
                fontSize: e.value.fontSize,
                fontFamily: e.value.fontFamily
              });
            h.node.classList.add("apexcharts-datalabel-value"), s.add(h)
          }
          return s
        }
      }, {
        key: "printInnerLabels",
        value: function(e, t, i, a) {
          var s, r = this.w;
          a ? s = void 0 === e.name.color ? r.globals.colors[parseInt(a.parentNode.getAttribute("rel"), 10) -
            1] : e.name.color : r.globals.series.length > 1 && e.total.show && (s = e.total.color);
          var n = r.globals.dom.baseEl.querySelector(".apexcharts-datalabel-label"),
            o = r.globals.dom.baseEl.querySelector(".apexcharts-datalabel-value");
          i = (0, e.value.formatter)(i, r), a || "function" != typeof e.total.formatter || (i = e.total
            .formatter(r)), t = e.name.formatter(t, t === e.total.label, r), null !== n && (n.textContent =
            t), null !== o && (o.textContent = i), null !== n && (n.style.fill = s)
        }
      }, {
        key: "printDataLabelsInner",
        value: function(e, t) {
          var i = this.w,
            a = e.getAttribute("data:value"),
            s = i.globals.seriesNames[parseInt(e.parentNode.getAttribute("rel"), 10) - 1];
          i.globals.series.length > 1 && this.printInnerLabels(t, s, a, e);
          var r = i.globals.dom.baseEl.querySelector(".apexcharts-datalabels-group");
          null !== r && (r.style.opacity = 1)
        }
      }, {
        key: "drawSpokes",
        value: function(e) {
          var t = this,
            i = this.w,
            a = new X(this.ctx),
            s = i.config.plotOptions.polarArea.spokes;
          if (0 !== s.strokeWidth) {
            for (var r = [], n = 360 / i.globals.series.length, o = 0; o < i.globals.series.length; o++) r
              .push(P.polarToCartesian(this.centerX, this.centerY, i.globals.radialSize, i.config.plotOptions
                .pie.startAngle + n * o));
            r.forEach(function(l, c) {
              var d = a.drawLine(l.x, l.y, t.centerX, t.centerY, Array.isArray(s.connectorColors) ? s
                .connectorColors[c] : s.connectorColors);
              e.add(d)
            })
          }
        }
      }, {
        key: "revertDataLabelsInner",
        value: function(e, t, i) {
          var a = this,
            s = this.w,
            r = s.globals.dom.baseEl.querySelector(".apexcharts-datalabels-group"),
            n = !1,
            o = s.globals.dom.baseEl.getElementsByClassName("apexcharts-pie-area"),
            l = function(g) {
              var p = g.makeSliceOut,
                f = g.printLabel;
              Array.prototype.forEach.call(o, function(x) {
                "true" === x.getAttribute("data:pieClicked") && (p && (n = !0), f && a
                  .printDataLabelsInner(x, t))
              })
            };
          if (l({
              makeSliceOut: !0,
              printLabel: !1
            }), t.total.show && s.globals.series.length > 1) n && !t.total.showAlways ? l({
            makeSliceOut: !1,
            printLabel: !0
          }) : this.printInnerLabels(t, t.total.label, t.total.formatter(s));
          else if (l({
              makeSliceOut: !1,
              printLabel: !0
            }), !n)
            if (s.globals.selectedDataPoints.length && s.globals.series.length > 1)
              if (s.globals.selectedDataPoints[0].length > 0) {
                var c = s.globals.selectedDataPoints[0],
                  d = s.globals.dom.baseEl.querySelector(".apexcharts-".concat(this.chartType.toLowerCase(),
                    "-slice-").concat(c));
                this.printDataLabelsInner(d, t)
              } else r && s.globals.selectedDataPoints.length && 0 === s.globals.selectedDataPoints[0]
                .length && (r.style.opacity = 0);
          else r && s.globals.series.length > 1 && (r.style.opacity = 0)
        }
      }]), w
    }(),
    zt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.chartType = this.w.config.chart.type, this.initialAnim = this.w
          .config.chart.animations.enabled, this.dynamicAnim = this.initialAnim && this.w.config.chart.animations
          .dynamicAnimation.enabled, this.animDur = 0;
        var t = this.w;
        this.graphics = new X(this.ctx), this.lineColorArr = void 0 !== t.globals.stroke.colors ? t.globals.stroke
          .colors : t.globals.colors, this.defaultSize = t.globals.svgHeight < t.globals.svgWidth ? t.globals
          .gridHeight + 1.5 * t.globals.goldenPadding : t.globals.gridWidth, this.isLog = t.config.yaxis[0]
          .logarithmic, this.logBase = t.config.yaxis[0].logBase, this.coreUtils = new q(this.ctx), this.maxValue =
          this.isLog ? this.coreUtils.getLogVal(this.logBase, t.globals.maxY, 0) : t.globals.maxY, this.minValue =
          this.isLog ? this.coreUtils.getLogVal(this.logBase, this.w.globals.minY, 0) : t.globals.minY, this
          .polygons = t.config.plotOptions.radar.polygons, this.strokeWidth = t.config.stroke.show ? t.config.stroke
          .width : 0, this.size = this.defaultSize / 2.1 - this.strokeWidth - t.config.chart.dropShadow.blur, t.config
          .xaxis.labels.show && (this.size = this.size - t.globals.xAxisLabelsWidth / 1.75), void 0 !== t.config
          .plotOptions.radar.size && (this.size = t.config.plotOptions.radar.size), this.dataRadiusOfPercent = [],
          this.dataRadius = [], this.angleArr = [], this.yaxisLabelsTextsPos = []
      }
      return R(w, [{
        key: "draw",
        value: function(e) {
          var t = this,
            i = this.w,
            a = new re(this.ctx),
            s = [],
            r = new ue(this.ctx);
          e.length && (this.dataPointsLen = e[i.globals.maxValsInArrayIndex].length), this.disAngle = 2 * Math
            .PI / this.dataPointsLen;
          var c = i.globals.gridHeight / 2 + i.config.plotOptions.radar.offsetY,
            d = this.graphics.group({
              class: "apexcharts-radar-series apexcharts-plot-series",
              transform: "translate(".concat(i.globals.gridWidth / 2 + i.config.plotOptions.radar.offsetX ||
                0, ", ").concat(c || 0, ")")
            }),
            g = [],
            p = null,
            f = null;
          if (this.yaxisLabels = this.graphics.group({
              class: "apexcharts-yaxis"
            }), e.forEach(function(m, v) {
              var y = m.length === i.globals.dataPoints,
                h = t.graphics.group().attr({
                  class: "apexcharts-series",
                  "data:longestSeries": y,
                  seriesName: P.escapeString(i.globals.seriesNames[v]),
                  rel: v + 1,
                  "data:realIndex": v
                });
              t.dataRadiusOfPercent[v] = [], t.dataRadius[v] = [], t.angleArr[v] = [], m.forEach(function(I,
                T) {
                var E = Math.abs(t.maxValue - t.minValue);
                I -= t.minValue, t.isLog && (I = t.coreUtils.getLogVal(t.logBase, I, 0)), t
                  .dataRadiusOfPercent[v][T] = I / E, t.dataRadius[v][T] = t.dataRadiusOfPercent[v][T] *
                  t.size, t.angleArr[v][T] = T * t.disAngle
              }), g = t.getDataPointsPos(t.dataRadius[v], t.angleArr[v]);
              var u = t.createPaths(g, {
                x: 0,
                y: 0
              });
              p = t.graphics.group({
                class: "apexcharts-series-markers-wrap apexcharts-element-hidden"
              }), f = t.graphics.group({
                class: "apexcharts-datalabels",
                "data:realIndex": v
              }), i.globals.delayedElements.push({
                el: p.node,
                index: v
              });
              var b = {
                  i: v,
                  realIndex: v,
                  animationDelay: v,
                  initialSpeed: i.config.chart.animations.speed,
                  dataChangeSpeed: i.config.chart.animations.dynamicAnimation.speed,
                  className: "apexcharts-radar",
                  shouldClipToGrid: !1,
                  bindEventsOnPaths: !1,
                  stroke: i.globals.stroke.colors[v],
                  strokeLineCap: i.config.stroke.lineCap
                },
                k = null;
              i.globals.previousPaths.length > 0 && (k = t.getPreviousPath(v));
              for (var A = 0; A < u.linePathsTo.length; A++) {
                var S = t.graphics.renderPaths(Y(Y({}, b), {}, {
                  pathFrom: null === k ? u.linePathsFrom[A] : k,
                  pathTo: u.linePathsTo[A],
                  strokeWidth: Array.isArray(t.strokeWidth) ? t.strokeWidth[v] : t.strokeWidth,
                  fill: "none",
                  drawShadow: !1
                }));
                h.add(S);
                var C = a.fillPath({
                    seriesNumber: v
                  }),
                  L = t.graphics.renderPaths(Y(Y({}, b), {}, {
                    pathFrom: null === k ? u.areaPathsFrom[A] : k,
                    pathTo: u.areaPathsTo[A],
                    strokeWidth: 0,
                    fill: C,
                    drawShadow: !1
                  }));
                i.config.chart.dropShadow.enabled && new K(t.ctx).dropShadow(L, Object.assign({}, i.config
                  .chart.dropShadow, {
                    noUserSpaceOnUse: !0
                  }), v), h.add(L)
              }
              m.forEach(function(I, T) {
                var E = new we(t.ctx).getMarkerConfig({
                    cssClass: "apexcharts-marker",
                    seriesIndex: v,
                    dataPointIndex: T
                  }),
                  H = t.graphics.drawMarker(g[T].x, g[T].y, E);
                H.attr("rel", T), H.attr("j", T), H.attr("index", v), H.node.setAttribute(
                  "default-marker-size", E.pSize);
                var D = t.graphics.group({
                  class: "apexcharts-series-markers"
                });
                D && D.add(H), p.add(D), h.add(p);
                var O = i.config.dataLabels;
                if (O.enabled) {
                  var W = O.formatter(i.globals.series[v][T], {
                    seriesIndex: v,
                    dataPointIndex: T,
                    w: i
                  });
                  r.plotDataLabelsText({
                    x: g[T].x,
                    y: g[T].y,
                    text: W,
                    textAnchor: "middle",
                    i: v,
                    j: v,
                    parent: f,
                    offsetCorrection: !1,
                    dataLabelsConfig: Y({}, O)
                  })
                }
                h.add(f)
              }), s.push(h)
            }), this.drawPolygons({
              parent: d
            }), i.config.xaxis.labels.show) {
            var x = this.drawXAxisTexts();
            d.add(x)
          }
          return s.forEach(function(m) {
            d.add(m)
          }), d.add(this.yaxisLabels), d
        }
      }, {
        key: "drawPolygons",
        value: function(e) {
          for (var t = this, i = this.w, a = e.parent, s = new at(this.ctx), r = i.globals.yAxisScale[0]
              .result.reverse(), n = r.length, o = [], l = this.size / (n - 1), c = 0; c < n; c++) o[c] = l *
            c;
          o.reverse();
          var d = [],
            g = [];
          o.forEach(function(p, f) {
            var x = P.getPolygonPos(p, t.dataPointsLen),
              m = "";
            x.forEach(function(v, y) {
              if (0 === f) {
                var h = t.graphics.drawLine(v.x, v.y, 0, 0, Array.isArray(t.polygons
                  .connectorColors) ? t.polygons.connectorColors[y] : t.polygons.connectorColors);
                g.push(h)
              }
              0 === y && t.yaxisLabelsTextsPos.push({
                x: v.x,
                y: v.y
              }), m += v.x + "," + v.y + " "
            }), d.push(m)
          }), d.forEach(function(p, f) {
            var x = t.polygons.strokeColors,
              m = t.polygons.strokeWidth,
              v = t.graphics.drawPolygon(p, Array.isArray(x) ? x[f] : x, Array.isArray(m) ? m[f] : m, i
                .globals.radarPolygons.fill.colors[f]);
            a.add(v)
          }), g.forEach(function(p) {
            a.add(p)
          }), i.config.yaxis[0].show && this.yaxisLabelsTextsPos.forEach(function(p, f) {
            var x = s.drawYAxisTexts(p.x, p.y, f, r[f]);
            t.yaxisLabels.add(x)
          })
        }
      }, {
        key: "drawXAxisTexts",
        value: function() {
          var e = this,
            t = this.w,
            i = t.config.xaxis.labels,
            a = this.graphics.group({
              class: "apexcharts-xaxis"
            }),
            s = P.getPolygonPos(this.size, this.dataPointsLen);
          return t.globals.labels.forEach(function(r, n) {
            var o = t.config.xaxis.labels.formatter,
              l = new ue(e.ctx);
            if (s[n]) {
              var c = e.getTextPos(s[n], e.size),
                d = o(r, {
                  seriesIndex: -1,
                  dataPointIndex: n,
                  w: t
                });
              l.plotDataLabelsText({
                x: c.newX,
                y: c.newY,
                text: d,
                textAnchor: c.textAnchor,
                i: n,
                j: n,
                parent: a,
                color: Array.isArray(i.style.colors) && i.style.colors[n] ? i.style.colors[n] :
                  "#a8a8a8",
                dataLabelsConfig: Y({
                  textAnchor: c.textAnchor,
                  dropShadow: {
                    enabled: !1
                  }
                }, i),
                offsetCorrection: !1
              })
            }
          }), a
        }
      }, {
        key: "createPaths",
        value: function(e, t) {
          var i = this,
            a = [],
            s = [],
            r = [],
            n = [];
          if (e.length) {
            s = [this.graphics.move(t.x, t.y)], n = [this.graphics.move(t.x, t.y)];
            var o = this.graphics.move(e[0].x, e[0].y),
              l = this.graphics.move(e[0].x, e[0].y);
            e.forEach(function(c, d) {
              o += i.graphics.line(c.x, c.y), l += i.graphics.line(c.x, c.y), d === e.length - 1 && (o +=
                "Z", l += "Z")
            }), a.push(o), r.push(l)
          }
          return {
            linePathsFrom: s,
            linePathsTo: a,
            areaPathsFrom: n,
            areaPathsTo: r
          }
        }
      }, {
        key: "getTextPos",
        value: function(e, t) {
          var i = "middle",
            a = e.x,
            s = e.y;
          return Math.abs(e.x) >= 10 ? e.x > 0 ? (i = "start", a += 10) : e.x < 0 && (i = "end", a -= 10) :
            i = "middle", Math.abs(e.y) >= t - 10 && (e.y < 0 ? s -= 10 : e.y > 0 && (s += 10)), {
              textAnchor: i,
              newX: a,
              newY: s
            }
        }
      }, {
        key: "getPreviousPath",
        value: function(e) {
          for (var t = this.w, i = null, a = 0; a < t.globals.previousPaths.length; a++) {
            var s = t.globals.previousPaths[a];
            s.paths.length > 0 && parseInt(s.realIndex, 10) === parseInt(e, 10) && void 0 !== t.globals
              .previousPaths[a].paths[0] && (i = t.globals.previousPaths[a].paths[0].d)
          }
          return i
        }
      }, {
        key: "getDataPointsPos",
        value: function(e, t) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : this.dataPointsLen;
          e = e || [], t = t || [];
          for (var a = [], s = 0; s < i; s++) {
            var r = {};
            r.x = e[s] * Math.sin(t[s]), r.y = -e[s] * Math.cos(t[s]), a.push(r)
          }
          return a
        }
      }]), w
    }(),
    Xt = function(w) {
      xe(t, w);
      var e = be(t);

      function t(i) {
        var a;
        F(this, t), (a = e.call(this, i)).ctx = i, a.w = i.w, a.animBeginArr = [0], a.animDur = 0;
        var s = a.w;
        return a.startAngle = s.config.plotOptions.radialBar.startAngle, a.endAngle = s.config.plotOptions.radialBar
          .endAngle, a.totalAngle = Math.abs(s.config.plotOptions.radialBar.endAngle - s.config.plotOptions.radialBar
            .startAngle), a.trackStartAngle = s.config.plotOptions.radialBar.track.startAngle, a.trackEndAngle = s
          .config.plotOptions.radialBar.track.endAngle, a.barLabels = a.w.config.plotOptions.radialBar.barLabels, a
          .donutDataLabels = a.w.config.plotOptions.radialBar.dataLabels, a.radialDataLabels = a.donutDataLabels, a
          .trackStartAngle || (a.trackStartAngle = a.startAngle), a.trackEndAngle || (a.trackEndAngle = a.endAngle),
          360 === a.endAngle && (a.endAngle = 359.99), a.margin = parseInt(s.config.plotOptions.radialBar.track
            .margin, 10), a.onBarLabelClick = a.onBarLabelClick.bind(We(a)), a
      }
      return R(t, [{
        key: "draw",
        value: function(i) {
          var a = this.w,
            s = new X(this.ctx),
            r = s.group({
              class: "apexcharts-radialbar"
            });
          if (a.globals.noData) return r;
          var n = s.group(),
            o = this.defaultSize / 2,
            l = a.globals.gridWidth / 2,
            c = this.defaultSize / 2.05;
          a.config.chart.sparkline.enabled || (c = c - a.config.stroke.width - a.config.chart.dropShadow
          .blur);
          var d = a.globals.fill.colors;
          if (a.config.plotOptions.radialBar.track.show) {
            var g = this.drawTracks({
              size: c,
              centerX: l,
              centerY: o,
              colorArr: d,
              series: i
            });
            n.add(g)
          }
          var p = this.drawArcs({
              size: c,
              centerX: l,
              centerY: o,
              colorArr: d,
              series: i
            }),
            f = 360;
          a.config.plotOptions.radialBar.startAngle < 0 && (f = this.totalAngle);
          var x = (360 - f) / 360;
          if (a.globals.radialSize = c - c * x, this.radialDataLabels.value.show) {
            var m = Math.max(this.radialDataLabels.value.offsetY, this.radialDataLabels.name.offsetY);
            a.globals.radialSize += m * x
          }
          return n.add(p.g), "front" === a.config.plotOptions.radialBar.hollow.position && (p.g.add(p
            .elHollow), p.dataLabels && p.g.add(p.dataLabels)), r.add(n), r
        }
      }, {
        key: "drawTracks",
        value: function(i) {
          var a = this.w,
            s = new X(this.ctx),
            r = s.group({
              class: "apexcharts-tracks"
            }),
            n = new K(this.ctx),
            o = new re(this.ctx),
            l = this.getStrokeWidth(i);
          i.size = i.size - l / 2;
          for (var c = 0; c < i.series.length; c++) {
            var d = s.group({
              class: "apexcharts-radialbar-track apexcharts-track"
            });
            r.add(d), d.attr({
              rel: c + 1
            }), i.size = i.size - l - this.margin;
            var g = a.config.plotOptions.radialBar.track,
              p = o.fillPath({
                seriesNumber: 0,
                size: i.size,
                fillColors: Array.isArray(g.background) ? g.background[c] : g.background,
                solid: !0
              }),
              f = this.trackStartAngle,
              x = this.trackEndAngle;
            Math.abs(x) + Math.abs(f) >= 360 && (x = 360 - Math.abs(this.startAngle) - .1);
            var m = s.drawPath({
              d: "",
              stroke: p,
              strokeWidth: l * parseInt(g.strokeWidth, 10) / 100,
              fill: "none",
              strokeOpacity: g.opacity,
              classes: "apexcharts-radialbar-area"
            });
            g.dropShadow.enabled && n.dropShadow(m, g.dropShadow), d.add(m), m.attr("id",
              "apexcharts-radialbarTrack-" + c), this.animatePaths(m, {
              centerX: i.centerX,
              centerY: i.centerY,
              endAngle: x,
              startAngle: f,
              size: i.size,
              i: c,
              totalItems: 2,
              animBeginArr: 0,
              dur: 0,
              isTrack: !0,
              easing: a.globals.easing
            })
          }
          return r
        }
      }, {
        key: "drawArcs",
        value: function(i) {
          var a = this.w,
            s = new X(this.ctx),
            r = new re(this.ctx),
            n = new K(this.ctx),
            o = s.group(),
            l = this.getStrokeWidth(i);
          i.size = i.size - l / 2;
          var c = a.config.plotOptions.radialBar.hollow.background,
            d = i.size - l * i.series.length - this.margin * i.series.length - l * parseInt(a.config
              .plotOptions.radialBar.track.strokeWidth, 10) / 100 / 2,
            g = d - a.config.plotOptions.radialBar.hollow.margin;
          void 0 !== a.config.plotOptions.radialBar.hollow.image && (c = this.drawHollowImage(i, o, d, c));
          var p = this.drawHollow({
            size: g,
            centerX: i.centerX,
            centerY: i.centerY,
            fill: c || "transparent"
          });
          a.config.plotOptions.radialBar.hollow.dropShadow.enabled && n.dropShadow(p, a.config.plotOptions
            .radialBar.hollow.dropShadow);
          var x = 1;
          !this.radialDataLabels.total.show && a.globals.series.length > 1 && (x = 0);
          var m = null;
          this.radialDataLabels.show && (m = this.renderInnerDataLabels(this.radialDataLabels, {
            hollowSize: d,
            centerX: i.centerX,
            centerY: i.centerY,
            opacity: x
          })), "back" === a.config.plotOptions.radialBar.hollow.position && (o.add(p), m && o.add(m));
          var v = !1;
          a.config.plotOptions.radialBar.inverseOrder && (v = !0);
          for (var y = v ? i.series.length - 1 : 0; v ? y >= 0 : y < i.series.length; v ? y-- : y++) {
            var h = s.group({
              class: "apexcharts-series apexcharts-radial-series",
              seriesName: P.escapeString(a.globals.seriesNames[y])
            });
            o.add(h), h.attr({
              rel: y + 1,
              "data:realIndex": y
            }), this.ctx.series.addCollapsedClassToSeries(h, y), i.size = i.size - l - this.margin;
            var u = r.fillPath({
                seriesNumber: y,
                size: i.size,
                value: i.series[y]
              }),
              b = this.startAngle,
              k = void 0,
              A = P.negToZero(i.series[y] > 100 ? 100 : i.series[y]) / 100,
              S = Math.round(this.totalAngle * A) + this.startAngle,
              C = void 0;
            a.globals.dataChanged && (k = this.startAngle, C = Math.round(this.totalAngle * P.negToZero(a
                .globals.previousPaths[y]) / 100) + k), Math.abs(S) + Math.abs(b) >= 360 && (S -= .01), Math
              .abs(C) + Math.abs(k) >= 360 && (C -= .01);
            var L = S - b,
              M = Array.isArray(a.config.stroke.dashArray) ? a.config.stroke.dashArray[y] : a.config.stroke
              .dashArray,
              z = s.drawPath({
                d: "",
                stroke: u,
                strokeWidth: l,
                fill: "none",
                fillOpacity: a.config.fill.opacity,
                classes: "apexcharts-radialbar-area apexcharts-radialbar-slice-" + y,
                strokeDashArray: M
              });
            if (X.setAttrs(z.node, {
                "data:angle": L,
                "data:value": i.series[y]
              }), a.config.chart.dropShadow.enabled && n.dropShadow(z, a.config.chart.dropShadow, y), n
              .setSelectionFilter(z, 0, y), this.addListeners(z, this.radialDataLabels), h.add(z), z.attr({
                index: 0,
                j: y
              }), this.barLabels.enabled) {
              var T = P.polarToCartesian(i.centerX, i.centerY, i.size, b),
                E = this.barLabels.formatter(a.globals.seriesNames[y], {
                  seriesIndex: y,
                  w: a
                }),
                H = ["apexcharts-radialbar-label"];
              this.barLabels.onClick || H.push("apexcharts-no-click");
              var D = this.barLabels.useSeriesColors ? a.globals.colors[y] : a.config.chart.foreColor;
              D || (D = a.config.chart.foreColor);
              var O = T.x - this.barLabels.margin,
                W = T.y,
                N = s.drawText({
                  x: O,
                  y: W,
                  text: E,
                  textAnchor: "end",
                  dominantBaseline: "middle",
                  fontFamily: this.barLabels.fontFamily,
                  fontWeight: this.barLabels.fontWeight,
                  fontSize: this.barLabels.fontSize,
                  foreColor: D,
                  cssClass: H.join(" ")
                });
              N.on("click", this.onBarLabelClick), N.attr({
                rel: y + 1
              }), 0 !== b && N.attr({
                "transform-origin": "".concat(O, " ").concat(W),
                transform: "rotate(".concat(b, " 0 0)")
              }), h.add(N)
            }
            var B = 0;
            !this.initialAnim || a.globals.resized || a.globals.dataChanged || (B = a.config.chart.animations
                .speed), a.globals.dataChanged && (B = a.config.chart.animations.dynamicAnimation.speed), this
              .animDur = B / (1.2 * i.series.length) + this.animDur, this.animBeginArr.push(this.animDur),
              this.animatePaths(z, {
                centerX: i.centerX,
                centerY: i.centerY,
                endAngle: S,
                startAngle: b,
                prevEndAngle: C,
                prevStartAngle: k,
                size: i.size,
                i: y,
                totalItems: 2,
                animBeginArr: this.animBeginArr,
                dur: B,
                shouldSetPrevPaths: !0,
                easing: a.globals.easing
              })
          }
          return {
            g: o,
            elHollow: p,
            dataLabels: m
          }
        }
      }, {
        key: "drawHollow",
        value: function(i) {
          var a = new X(this.ctx).drawCircle(2 * i.size);
          return a.attr({
            class: "apexcharts-radialbar-hollow",
            cx: i.centerX,
            cy: i.centerY,
            r: i.size,
            fill: i.fill
          }), a
        }
      }, {
        key: "drawHollowImage",
        value: function(i, a, s, r) {
          var n = this.w,
            o = new re(this.ctx),
            l = P.randomId(),
            c = n.config.plotOptions.radialBar.hollow.image;
          if (n.config.plotOptions.radialBar.hollow.imageClipped) o.clippedImgArea({
            width: s,
            height: s,
            image: c,
            patternID: "pattern".concat(n.globals.cuid).concat(l)
          }), r = "url(#pattern".concat(n.globals.cuid).concat(l, ")");
          else {
            var d = n.config.plotOptions.radialBar.hollow.imageWidth,
              g = n.config.plotOptions.radialBar.hollow.imageHeight;
            if (void 0 === d && void 0 === g) {
              var p = n.globals.dom.Paper.image(c).loaded(function(x) {
                this.move(i.centerX - x.width / 2 + n.config.plotOptions.radialBar.hollow.imageOffsetX, i
                  .centerY - x.height / 2 + n.config.plotOptions.radialBar.hollow.imageOffsetY)
              });
              a.add(p)
            } else {
              var f = n.globals.dom.Paper.image(c).loaded(function(x) {
                this.move(i.centerX - d / 2 + n.config.plotOptions.radialBar.hollow.imageOffsetX, i
                  .centerY - g / 2 + n.config.plotOptions.radialBar.hollow.imageOffsetY), this.size(d,
                  g)
              });
              a.add(f)
            }
          }
          return r
        }
      }, {
        key: "getStrokeWidth",
        value: function(i) {
          return i.size * (100 - parseInt(this.w.config.plotOptions.radialBar.hollow.size, 10)) / 100 / (i
            .series.length + 1) - this.margin
        }
      }, {
        key: "onBarLabelClick",
        value: function(i) {
          var a = parseInt(i.target.getAttribute("rel"), 10) - 1,
            s = this.barLabels.onClick,
            r = this.w;
          s && s(r.globals.seriesNames[a], {
            w: r,
            seriesIndex: a
          })
        }
      }]), t
    }(st),
    Et = function(w) {
      xe(t, w);
      var e = be(t);

      function t() {
        return F(this, t), e.apply(this, arguments)
      }
      return R(t, [{
        key: "draw",
        value: function(i, a) {
          var s = this.w,
            r = new X(this.ctx);
          this.rangeBarOptions = this.w.config.plotOptions.rangeBar, this.series = i, this.seriesRangeStart =
            s.globals.seriesRangeStart, this.seriesRangeEnd = s.globals.seriesRangeEnd, this.barHelpers
            .initVariables(i);
          for (var n = r.group({
              class: "apexcharts-rangebar-series apexcharts-plot-series"
            }), o = 0; o < i.length; o++) {
            var l, c, d, g, p = void 0,
              f = void 0,
              x = s.globals.comboCharts ? a[o] : o,
              m = this.barHelpers.getGroupIndex(x).columnGroupIndex,
              v = r.group({
                class: "apexcharts-series",
                seriesName: P.escapeString(s.globals.seriesNames[x]),
                rel: o + 1,
                "data:realIndex": x
              });
            this.ctx.series.addCollapsedClassToSeries(v, x), i[o].length > 0 && (this.visibleI = this
              .visibleI + 1);
            var y = 0,
              h = 0,
              u = 0;
            this.yRatio.length > 1 && (this.yaxisIndex = s.globals.seriesYAxisReverseMap[x][0], u = x);
            var b = this.barHelpers.initialPositions();
            f = b.y, g = b.zeroW, p = b.x, h = b.barWidth, y = b.barHeight, l = b.xDivision, c = b.yDivision,
              d = b.zeroH;
            for (var k = r.group({
                class: "apexcharts-datalabels",
                "data:realIndex": x
              }), A = r.group({
                class: "apexcharts-rangebar-goals-markers"
              }), S = 0; S < s.globals.dataPoints; S++) {
              var C, L = this.barHelpers.getStrokeWidth(o, S, x),
                M = this.seriesRangeStart[o][S],
                z = this.seriesRangeEnd[o][S],
                I = null,
                T = null,
                E = null,
                H = {
                  x: p,
                  y: f,
                  strokeWidth: L,
                  elSeries: v
                },
                D = this.seriesLen;
              if (s.config.plotOptions.bar.rangeBarGroupRows && (D = 1), void 0 === s.config.series[o].data[
                S]) break;
              if (this.isHorizontal) {
                if (E = f + y * this.visibleI, s.config.series[o].data[S].x) {
                  var W = this.detectOverlappingBars({
                    i: o,
                    j: S,
                    barYPosition: E,
                    srty: (c - y * D) / 2,
                    barHeight: y,
                    yDivision: c,
                    initPositions: b
                  });
                  y = W.barHeight, E = W.barYPosition
                }
                h = (I = this.drawRangeBarPaths(Y({
                  indexes: {
                    i: o,
                    j: S,
                    realIndex: x
                  },
                  barHeight: y,
                  barYPosition: E,
                  zeroW: g,
                  yDivision: c,
                  y1: M,
                  y2: z
                }, H))).barWidth
              } else {
                if (s.globals.isXNumeric && (p = (s.globals.seriesX[o][S] - s.globals.minX) / this.xRatio -
                    h / 2), T = p + h * this.visibleI, s.config.series[o].data[S].x) {
                  var B = this.detectOverlappingBars({
                    i: o,
                    j: S,
                    barXPosition: T,
                    srtx: (l - h * D) / 2,
                    barWidth: h,
                    xDivision: l,
                    initPositions: b
                  });
                  h = B.barWidth, T = B.barXPosition
                }
                y = (I = this.drawRangeColumnPaths(Y({
                  indexes: {
                    i: o,
                    j: S,
                    realIndex: x,
                    translationsIndex: u
                  },
                  barWidth: h,
                  barXPosition: T,
                  zeroH: d,
                  xDivision: l
                }, H))).barHeight
              }
              var Z = this.barHelpers.drawGoalLine({
                barXPosition: I.barXPosition,
                barYPosition: E,
                goalX: I.goalX,
                goalY: I.goalY,
                barHeight: y,
                barWidth: h
              });
              Z && A.add(Z), f = I.y, p = I.x;
              var U = this.barHelpers.getPathFillColor(i, o, S, x);
              this.renderSeries((ne(C = {
                  realIndex: x,
                  pathFill: U,
                  lineFill: s.globals.stroke.colors[x],
                  j: S,
                  i: o,
                  x: p,
                  y: f,
                  y1: M,
                  y2: z,
                  pathFrom: I.pathFrom,
                  pathTo: I.pathTo,
                  strokeWidth: L,
                  elSeries: v,
                  series: i,
                  barHeight: y,
                  barWidth: h,
                  barXPosition: T,
                  barYPosition: E
                }, "barWidth", h), ne(C, "columnGroupIndex", m), ne(C, "elDataLabelsWrap", k), ne(C,
                  "elGoalsMarkers", A), ne(C, "visibleSeries", this.visibleI), ne(C, "type", "rangebar"),
                C))
            }
            n.add(v)
          }
          return n
        }
      }, {
        key: "detectOverlappingBars",
        value: function(i) {
          var a = i.i,
            s = i.j,
            r = i.barYPosition,
            n = i.barXPosition,
            o = i.srty,
            l = i.srtx,
            c = i.barHeight,
            d = i.barWidth,
            g = i.yDivision,
            p = i.xDivision,
            f = i.initPositions,
            x = this.w,
            m = [],
            v = x.config.series[a].data[s].rangeName,
            y = x.config.series[a].data[s].x,
            h = Array.isArray(y) ? y.join(" ") : y,
            u = x.globals.labels.map(function(k) {
              return Array.isArray(k) ? k.join(" ") : k
            }).indexOf(h),
            b = x.globals.seriesRange[a].findIndex(function(k) {
              return k.x === h && k.overlaps.length > 0
            });
          return this.isHorizontal ? (r = x.config.plotOptions.bar.rangeBarGroupRows ? o + g * u : o + c *
            this.visibleI + g * u, b > -1 && !x.config.plotOptions.bar.rangeBarOverlap && (m = x.globals
              .seriesRange[a][b].overlaps).indexOf(v) > -1 && (r = (c = f.barHeight / m.length) * this
              .visibleI + g * (100 - parseInt(this.barOptions.barHeight, 10)) / 100 / 2 + c * (this
                .visibleI + m.indexOf(v)) + g * u)) : (u > -1 && !x.globals.timescaleLabels.length && (n = x
              .config.plotOptions.bar.rangeBarGroupRows ? l + p * u : l + d * this.visibleI + p * u), b > -
            1 && !x.config.plotOptions.bar.rangeBarOverlap && (m = x.globals.seriesRange[a][b].overlaps)
            .indexOf(v) > -1 && (n = (d = f.barWidth / m.length) * this.visibleI + p * (100 - parseInt(this
              .barOptions.barWidth, 10)) / 100 / 2 + d * (this.visibleI + m.indexOf(v)) + p * u)), {
            barYPosition: r,
            barXPosition: n,
            barHeight: c,
            barWidth: d
          }
        }
      }, {
        key: "drawRangeColumnPaths",
        value: function(i) {
          var a = i.indexes,
            s = i.x,
            r = i.xDivision,
            n = i.barWidth,
            o = i.barXPosition,
            l = i.zeroH,
            c = this.w,
            d = a.i,
            g = a.j,
            p = a.realIndex,
            f = a.translationsIndex,
            x = this.yRatio[f],
            m = this.getRangeValue(p, g),
            v = Math.min(m.start, m.end),
            y = Math.max(m.start, m.end);
          null == this.series[d][g] ? v = l : (v = l - v / x, y = l - y / x);
          var h = Math.abs(y - v),
            u = this.barHelpers.getColumnPaths({
              barXPosition: o,
              barWidth: n,
              y1: v,
              y2: y,
              strokeWidth: this.strokeWidth,
              series: this.seriesRangeEnd,
              realIndex: p,
              i: p,
              j: g,
              w: c
            });
          if (c.globals.isXNumeric) {
            var b = this.getBarXForNumericXAxis({
              x: s,
              j: g,
              realIndex: p,
              barWidth: n
            });
            s = b.x, o = b.barXPosition
          } else s += r;
          return {
            pathTo: u.pathTo,
            pathFrom: u.pathFrom,
            barHeight: h,
            x: s,
            y: m.start < 0 && m.end < 0 ? v : y,
            goalY: this.barHelpers.getGoalValues("y", null, l, d, g, f),
            barXPosition: o
          }
        }
      }, {
        key: "drawRangeBarPaths",
        value: function(i) {
          var a = i.indexes,
            s = i.y,
            o = i.yDivision,
            l = i.barHeight,
            c = i.barYPosition,
            d = i.zeroW,
            g = this.w,
            p = a.realIndex,
            f = a.j,
            x = d + i.y1 / this.invertedYRatio,
            m = d + i.y2 / this.invertedYRatio,
            v = this.getRangeValue(p, f),
            y = Math.abs(m - x),
            h = this.barHelpers.getBarpaths({
              barYPosition: c,
              barHeight: l,
              x1: x,
              x2: m,
              strokeWidth: this.strokeWidth,
              series: this.seriesRangeEnd,
              i: p,
              realIndex: p,
              j: f,
              w: g
            });
          return g.globals.isXNumeric || (s += o), {
            pathTo: h.pathTo,
            pathFrom: h.pathFrom,
            barWidth: y,
            x: v.start < 0 && v.end < 0 ? x : m,
            goalX: this.barHelpers.getGoalValues("x", d, null, p, f),
            y: s
          }
        }
      }, {
        key: "getRangeValue",
        value: function(i, a) {
          var s = this.w;
          return {
            start: s.globals.seriesRangeStart[i][a],
            end: s.globals.seriesRangeEnd[i][a]
          }
        }
      }]), t
    }(pe),
    Yt = function() {
      function w(e) {
        F(this, w), this.w = e.w, this.lineCtx = e
      }
      return R(w, [{
        key: "sameValueSeriesFix",
        value: function(e, t) {
          var i = this.w;
          if (("gradient" === i.config.fill.type || "gradient" === i.config.fill.type[e]) && new q(this
              .lineCtx.ctx, i).seriesHaveSameValues(e)) {
            var a = t[e].slice();
            a[a.length - 1] = a[a.length - 1] + 1e-6, t[e] = a
          }
          return t
        }
      }, {
        key: "calculatePoints",
        value: function(e) {
          var t = e.series,
            a = e.x,
            s = e.y,
            r = e.i,
            n = e.j,
            o = e.prevY,
            l = this.w,
            c = [],
            d = [];
          if (0 === n) {
            var g = this.lineCtx.categoryAxisCorrection + l.config.markers.offsetX;
            l.globals.isXNumeric && (g = (l.globals.seriesX[e.realIndex][0] - l.globals.minX) / this.lineCtx
              .xRatio + l.config.markers.offsetX), c.push(g), d.push(P.isNumber(t[r][0]) ? o + l.config
              .markers.offsetY : null), c.push(a + l.config.markers.offsetX), d.push(P.isNumber(t[r][n +
              1]) ? s + l.config.markers.offsetY : null)
          } else c.push(a + l.config.markers.offsetX), d.push(P.isNumber(t[r][n + 1]) ? s + l.config.markers
            .offsetY : null);
          return {
            x: c,
            y: d
          }
        }
      }, {
        key: "checkPreviousPaths",
        value: function(e) {
          for (var t = e.pathFromLine, i = e.pathFromArea, a = e.realIndex, s = this.w, r = 0; r < s.globals
            .previousPaths.length; r++) {
            var n = s.globals.previousPaths[r];
            ("line" === n.type || "area" === n.type) && n.paths.length > 0 && parseInt(n.realIndex, 10) ===
              parseInt(a, 10) && ("line" === n.type ? (this.lineCtx.appendPathFrom = !1, t = s.globals
                .previousPaths[r].paths[0].d) : "area" === n.type && (this.lineCtx.appendPathFrom = !1, i =
                s.globals.previousPaths[r].paths[0].d, s.config.stroke.show && s.globals.previousPaths[r]
                .paths[1] && (t = s.globals.previousPaths[r].paths[1].d)))
          }
          return {
            pathFromLine: t,
            pathFromArea: i
          }
        }
      }, {
        key: "determineFirstPrevY",
        value: function(e) {
          var t, i, a, s = e.i,
            r = e.realIndex,
            n = e.series,
            o = e.prevY,
            l = e.lineYPosition,
            c = e.translationsIndex,
            d = this.w,
            g = d.config.chart.stacked && !d.globals.comboCharts || d.config.chart.stacked && d.globals
            .comboCharts && (!this.w.config.chart.stackOnlyBar || "bar" === (null === (t = this.w.config
              .series[r]) || void 0 === t ? void 0 : t.type) || "column" === (null === (i = this.w.config
              .series[r]) || void 0 === i ? void 0 : i.type));
          if (void 0 !== (null === (a = n[s]) || void 0 === a ? void 0 : a[0])) o = (l = g && s > 0 ? this
            .lineCtx.prevSeriesY[s - 1][0] : this.lineCtx.zeroY) - n[s][0] / this.lineCtx.yRatio[c] + 2 * (
            this.lineCtx.isReversed ? n[s][0] / this.lineCtx.yRatio[c] : 0);
          else if (g && s > 0 && void 0 === n[s][0])
            for (var p = s - 1; p >= 0; p--)
              if (null != n[p][0]) {
                o = l = this.lineCtx.prevSeriesY[p][0];
                break
              } return {
            prevY: o,
            lineYPosition: l
          }
        }
      }]), w
    }(),
    Ht = function(w, e, t) {
      var i = w.slice(e, t);
      if (e) {
        if (t - e > 1 && i[1].length < 6) {
          var a = i[0].length;
          i[1] = [2 * i[0][a - 2] - i[0][a - 4], 2 * i[0][a - 1] - i[0][a - 3]].concat(i[1])
        }
        i[0] = i[0].slice(-2)
      }
      return i
    };

  function He(w, e) {
    return (e[1] - w[1]) / (e[0] - w[0])
  }
  var De = function() {
    function w(e, t, i) {
      F(this, w), this.ctx = e, this.w = e.w, this.xyRatios = t, this.pointsChart = !("bubble" !== this.w.config
          .chart.type && "scatter" !== this.w.config.chart.type) || i, this.scatter = new _e(this.ctx), this
        .noNegatives = this.w.globals.minX === Number.MAX_VALUE, this.lineHelpers = new Yt(this), this.markers =
        new we(this.ctx), this.prevSeriesY = [], this.categoryAxisCorrection = 0, this.yaxisIndex = 0
    }
    return R(w, [{
      key: "draw",
      value: function(e, t, i, a) {
        var s, r = this.w,
          n = new X(this.ctx),
          o = r.globals.comboCharts ? t : r.config.chart.type,
          l = n.group({
            class: "apexcharts-".concat(o, "-series apexcharts-plot-series")
          }),
          c = new q(this.ctx, r);
        this.yRatio = this.xyRatios.yRatio, this.zRatio = this.xyRatios.zRatio, this.xRatio = this.xyRatios
          .xRatio, this.baseLineY = this.xyRatios.baseLineY, e = c.getLogSeries(e), this.yRatio = c
          .getLogYRatios(this.yRatio), this.prevSeriesY = [];
        for (var d = [], g = 0; g < e.length; g++) {
          e = this.lineHelpers.sameValueSeriesFix(g, e);
          var p = r.globals.comboCharts ? i[g] : g,
            f = this.yRatio.length > 1 ? p : 0;
          this._initSerieVariables(e, g, p);
          var x = [],
            m = [],
            v = [],
            y = r.globals.padHorizontal + this.categoryAxisCorrection;
          this.ctx.series.addCollapsedClassToSeries(this.elSeries, p), r.globals.isXNumeric && r.globals
            .seriesX.length > 0 && (y = (r.globals.seriesX[p][0] - r.globals.minX) / this.xRatio), v.push(
            y);
          var h, u = y,
            b = void 0,
            k = u,
            A = this.zeroY,
            S = this.zeroY;
          A = this.lineHelpers.determineFirstPrevY({
              i: g,
              realIndex: p,
              series: e,
              prevY: A,
              lineYPosition: 0,
              translationsIndex: f
            }).prevY, x.push("monotoneCubic" === r.config.stroke.curve && null === e[g][0] ? null : A), h =
            A, "rangeArea" === o && (b = S = this.lineHelpers.determineFirstPrevY({
              i: g,
              realIndex: p,
              series: a,
              prevY: S,
              lineYPosition: 0,
              translationsIndex: f
            }).prevY, m.push(null !== x[0] ? S : null));
          var C = this._calculatePathsFrom({
              type: o,
              series: e,
              i: g,
              realIndex: p,
              translationsIndex: f,
              prevX: k,
              prevY: A,
              prevY2: S
            }),
            L = [x[0]],
            M = [m[0]],
            z = {
              type: o,
              series: e,
              realIndex: p,
              translationsIndex: f,
              i: g,
              x: y,
              y: 1,
              pX: u,
              pY: h,
              pathsFrom: C,
              linePaths: [],
              areaPaths: [],
              seriesIndex: i,
              lineYPosition: 0,
              xArrj: v,
              yArrj: x,
              y2Arrj: m,
              seriesRangeEnd: a
            },
            I = this._iterateOverDataPoints(Y(Y({}, z), {}, {
              iterations: "rangeArea" === o ? e[g].length - 1 : void 0,
              isRangeStart: !0
            }));
          if ("rangeArea" === o) {
            for (var T = this._calculatePathsFrom({
                series: a,
                i: g,
                realIndex: p,
                prevX: k,
                prevY: S
              }), E = this._iterateOverDataPoints(Y(Y({}, z), {}, {
                series: a,
                xArrj: [y],
                yArrj: L,
                y2Arrj: M,
                pY: b,
                areaPaths: I.areaPaths,
                pathsFrom: T,
                iterations: a[g].length - 1,
                isRangeStart: !1
              })), H = I.linePaths.length / 2, D = 0; D < H; D++) I.linePaths[D] = E.linePaths[D + H] + I
              .linePaths[D];
            I.linePaths.splice(H), I.pathFromLine = E.pathFromLine + I.pathFromLine
          } else I.pathFromArea += n.line(0, this.zeroY);
          this._handlePaths({
            type: o,
            realIndex: p,
            i: g,
            paths: I
          }), this.elSeries.add(this.elPointsMain), this.elSeries.add(this.elDataLabelsWrap), d.push(this
            .elSeries)
        }
        if (void 0 !== (null === (s = r.config.series[0]) || void 0 === s ? void 0 : s.zIndex) && d.sort(
            function(N, B) {
              return Number(N.node.getAttribute("zIndex")) - Number(B.node.getAttribute("zIndex"))
            }), r.config.chart.stacked)
          for (var O = d.length - 1; O >= 0; O--) l.add(d[O]);
        else
          for (var W = 0; W < d.length; W++) l.add(d[W]);
        return l
      }
    }, {
      key: "_initSerieVariables",
      value: function(e, t, i) {
        var a = this.w,
          s = new X(this.ctx);
        this.xDivision = a.globals.gridWidth / (a.globals.dataPoints - ("on" === a.config.xaxis
            .tickPlacement ? 1 : 0)), this.strokeWidth = Array.isArray(a.config.stroke.width) ? a.config
          .stroke.width[i] : a.config.stroke.width;
        var r = 0;
        this.yRatio.length > 1 && (this.yaxisIndex = a.globals.seriesYAxisReverseMap[i], r = i), this
          .isReversed = a.config.yaxis[this.yaxisIndex] && a.config.yaxis[this.yaxisIndex].reversed, this
          .zeroY = a.globals.gridHeight - this.baseLineY[r] - (this.isReversed ? a.globals.gridHeight : 0) +
          (this.isReversed ? 2 * this.baseLineY[r] : 0), this.areaBottomY = this.zeroY, (this.zeroY > a
            .globals.gridHeight || "end" === a.config.plotOptions.area.fillTo) && (this.areaBottomY = a
            .globals.gridHeight), this.categoryAxisCorrection = this.xDivision / 2, this.elSeries = s
        .group({
            class: "apexcharts-series",
            zIndex: void 0 !== a.config.series[i].zIndex ? a.config.series[i].zIndex : i,
            seriesName: P.escapeString(a.globals.seriesNames[i])
          }), this.elPointsMain = s.group({
            class: "apexcharts-series-markers-wrap",
            "data:realIndex": i
          }), this.elDataLabelsWrap = s.group({
            class: "apexcharts-datalabels",
            "data:realIndex": i
          }), this.elSeries.attr({
            "data:longestSeries": e[t].length === a.globals.dataPoints,
            rel: t + 1,
            "data:realIndex": i
          }), this.appendPathFrom = !0
      }
    }, {
      key: "_calculatePathsFrom",
      value: function(e) {
        var t, i, a, s, r = e.type,
          n = e.series,
          o = e.i,
          l = e.realIndex,
          c = e.translationsIndex,
          d = e.prevX,
          g = e.prevY,
          p = e.prevY2,
          f = this.w,
          x = new X(this.ctx);
        if (null === n[o][0]) {
          for (var m = 0; m < n[o].length; m++)
            if (null !== n[o][m]) {
              t = x.move(d = this.xDivision * m, g = this.zeroY - n[o][m] / this.yRatio[c]), i = x.move(d,
                this.areaBottomY);
              break
            }
        } else t = x.move(d, g), "rangeArea" === r && (t = x.move(d, p) + x.line(d, g)), i = x.move(d, this
          .areaBottomY) + x.line(d, g);
        if (a = x.move(0, this.zeroY) + x.line(0, this.zeroY), s = x.move(0, this.zeroY) + x.line(0, this
            .zeroY), f.globals.previousPaths.length > 0) {
          var v = this.lineHelpers.checkPreviousPaths({
            pathFromLine: a,
            pathFromArea: s,
            realIndex: l
          });
          a = v.pathFromLine, s = v.pathFromArea
        }
        return {
          prevX: d,
          prevY: g,
          linePath: t,
          areaPath: i,
          pathFromLine: a,
          pathFromArea: s
        }
      }
    }, {
      key: "_handlePaths",
      value: function(e) {
        var t = e.type,
          i = e.realIndex,
          a = e.i,
          s = e.paths,
          r = this.w,
          n = new X(this.ctx),
          o = new re(this.ctx);
        this.prevSeriesY.push(s.yArrj), r.globals.seriesXvalues[i] = s.xArrj, r.globals.seriesYvalues[i] = s
          .yArrj;
        var l = r.config.forecastDataPoints;
        if (l.count > 0 && "rangeArea" !== t) {
          var c = r.globals.seriesXvalues[i][r.globals.seriesXvalues[i].length - l.count - 1],
            d = n.drawRect(c, 0, r.globals.gridWidth, r.globals.gridHeight, 0);
          r.globals.dom.elForecastMask.appendChild(d.node);
          var g = n.drawRect(0, 0, c, r.globals.gridHeight, 0);
          r.globals.dom.elNonForecastMask.appendChild(g.node)
        }
        this.pointsChart || r.globals.delayedElements.push({
          el: this.elPointsMain.node,
          index: i
        });
        var p = {
          i: a,
          realIndex: i,
          animationDelay: a,
          initialSpeed: r.config.chart.animations.speed,
          dataChangeSpeed: r.config.chart.animations.dynamicAnimation.speed,
          className: "apexcharts-".concat(t)
        };
        if ("area" === t)
          for (var f = o.fillPath({
              seriesNumber: i
            }), x = 0; x < s.areaPaths.length; x++) {
            var m = n.renderPaths(Y(Y({}, p), {}, {
              pathFrom: s.pathFromArea,
              pathTo: s.areaPaths[x],
              stroke: "none",
              strokeWidth: 0,
              strokeLineCap: null,
              fill: f
            }));
            this.elSeries.add(m)
          }
        if (r.config.stroke.show && !this.pointsChart) {
          var v = null;
          if ("line" === t) v = o.fillPath({
            seriesNumber: i,
            i: a
          });
          else if ("solid" === r.config.stroke.fill.type) v = r.globals.stroke.colors[i];
          else {
            var y = r.config.fill;
            r.config.fill = r.config.stroke.fill, v = o.fillPath({
              seriesNumber: i,
              i: a
            }), r.config.fill = y
          }
          for (var h = 0; h < s.linePaths.length; h++) {
            var u = v;
            "rangeArea" === t && (u = o.fillPath({
              seriesNumber: i
            }));
            var b = Y(Y({}, p), {}, {
                pathFrom: s.pathFromLine,
                pathTo: s.linePaths[h],
                stroke: v,
                strokeWidth: this.strokeWidth,
                strokeLineCap: r.config.stroke.lineCap,
                fill: "rangeArea" === t ? u : "none"
              }),
              k = n.renderPaths(b);
            if (this.elSeries.add(k), k.attr("fill-rule", "evenodd"), l.count > 0 && "rangeArea" !== t) {
              var A = n.renderPaths(b);
              A.node.setAttribute("stroke-dasharray", l.dashArray), l.strokeWidth && A.node.setAttribute(
                "stroke-width", l.strokeWidth), this.elSeries.add(A), A.attr("clip-path",
                "url(#forecastMask".concat(r.globals.cuid, ")")), k.attr("clip-path",
                "url(#nonForecastMask".concat(r.globals.cuid, ")"))
            }
          }
        }
      }
    }, {
      key: "_iterateOverDataPoints",
      value: function(e) {
        var t, i, a = this,
          s = e.type,
          r = e.series,
          n = e.iterations,
          o = e.realIndex,
          l = e.translationsIndex,
          c = e.i,
          d = e.x,
          g = e.y,
          p = e.pX,
          f = e.pY,
          x = e.pathsFrom,
          m = e.linePaths,
          v = e.areaPaths,
          y = e.seriesIndex,
          h = e.lineYPosition,
          u = e.xArrj,
          b = e.yArrj,
          k = e.y2Arrj,
          A = e.isRangeStart,
          S = e.seriesRangeEnd,
          C = this.w,
          L = new X(this.ctx),
          M = this.yRatio,
          z = x.prevY,
          I = x.linePath,
          T = x.areaPath,
          E = x.pathFromLine,
          H = x.pathFromArea,
          D = P.isNumber(C.globals.minYArr[o]) ? C.globals.minYArr[o] : C.globals.minY;
        n || (n = C.globals.dataPoints > 1 ? C.globals.dataPoints - 1 : C.globals.dataPoints);
        var O = function(ee, te) {
            return te - ee / M[l] + 2 * (a.isReversed ? ee / M[l] : 0)
          },
          W = g,
          N = C.config.chart.stacked && !C.globals.comboCharts || C.config.chart.stacked && C.globals
          .comboCharts && (!this.w.config.chart.stackOnlyBar || "bar" === (null === (t = this.w.config
            .series[o]) || void 0 === t ? void 0 : t.type) || "column" === (null === (i = this.w.config
            .series[o]) || void 0 === i ? void 0 : i.type)),
          B = C.config.stroke.curve;
        Array.isArray(B) && (B = Array.isArray(y) ? B[y[c]] : B[c]);
        for (var Z, U = 0, _ = 0; _ < n; _++) {
          var ae = null == r[c][_ + 1];
          if (C.globals.isXNumeric) {
            var V = C.globals.seriesX[o][_ + 1];
            void 0 === C.globals.seriesX[o][_ + 1] && (V = C.globals.seriesX[o][n - 1]), d = (V - C.globals
              .minX) / this.xRatio
          } else d += this.xDivision;
          h = N && c > 0 && C.globals.collapsedSeries.length < C.config.series.length - 1 ? this
            .prevSeriesY[function(ee) {
              for (var te = ee; te > 0; te--) {
                if (!(C.globals.collapsedSeriesIndices.indexOf(y?.[te] || te) > -1)) return te;
                te--
              }
              return 0
            }(c - 1)][_ + 1] : this.zeroY, ae ? g = O(D, h) : (g = O(r[c][_ + 1], h), "rangeArea" === s && (
              W = O(S[c][_ + 1], h))), u.push(d), !ae || "smooth" !== C.config.stroke.curve &&
            "monotoneCubic" !== C.config.stroke.curve ? (b.push(g), k.push(W)) : (b.push(null), k.push(
              null));
          var G = this.lineHelpers.calculatePoints({
              series: r,
              x: d,
              y: g,
              realIndex: o,
              i: c,
              j: _,
              prevY: z
            }),
            j = this._createPaths({
              type: s,
              series: r,
              i: c,
              realIndex: o,
              j: _,
              x: d,
              y: g,
              y2: W,
              xArrj: u,
              yArrj: b,
              y2Arrj: k,
              pX: p,
              pY: f,
              pathState: U,
              segmentStartX: Z,
              linePath: I,
              areaPath: T,
              linePaths: m,
              areaPaths: v,
              curve: B,
              isRangeStart: A
            });
          v = j.areaPaths, m = j.linePaths, p = j.pX, f = j.pY, U = j.pathState, Z = j.segmentStartX, T = j
            .areaPath, I = j.linePath, !this.appendPathFrom || "monotoneCubic" === B && "rangeArea" === s ||
            (E += L.line(d, this.zeroY), H += L.line(d, this.zeroY)), this.handleNullDataPoints(r, G, c, _,
              o), this._handleMarkersAndLabels({
              type: s,
              pointsPos: G,
              i: c,
              j: _,
              realIndex: o,
              isRangeStart: A
            })
        }
        return {
          yArrj: b,
          xArrj: u,
          pathFromArea: H,
          areaPaths: v,
          pathFromLine: E,
          linePaths: m,
          linePath: I,
          areaPath: T
        }
      }
    }, {
      key: "_handleMarkersAndLabels",
      value: function(e) {
        var t = e.type,
          i = e.pointsPos,
          a = e.isRangeStart,
          s = e.i,
          r = e.j,
          n = e.realIndex,
          o = this.w,
          l = new ue(this.ctx);
        if (this.pointsChart) this.scatter.draw(this.elSeries, r, {
          realIndex: n,
          pointsPos: i,
          zRatio: this.zRatio,
          elParent: this.elPointsMain
        });
        else {
          o.globals.series[s].length > 1 && this.elPointsMain.node.classList.add(
            "apexcharts-element-hidden");
          var c = this.markers.plotChartMarkers(i, n, r + 1);
          null !== c && this.elPointsMain.add(c)
        }
        var d = l.drawDataLabel({
          type: t,
          isRangeStart: a,
          pos: i,
          i: n,
          j: r + 1
        });
        null !== d && this.elDataLabelsWrap.add(d)
      }
    }, {
      key: "_createPaths",
      value: function(e) {
        var k, t = e.type,
          i = e.series,
          a = e.i,
          s = e.j,
          r = e.x,
          n = e.y,
          o = e.xArrj,
          l = e.yArrj,
          c = e.y2,
          d = e.y2Arrj,
          g = e.pX,
          p = e.pY,
          f = e.pathState,
          x = e.segmentStartX,
          m = e.linePath,
          v = e.areaPath,
          y = e.linePaths,
          h = e.areaPaths,
          u = e.curve,
          b = e.isRangeStart,
          A = new X(this.ctx),
          S = this.areaBottomY,
          C = "rangeArea" === t,
          L = "rangeArea" === t && b;
        switch (u) {
          case "monotoneCubic":
            var M = b ? l : d;
            switch (f) {
              case 0:
                if (null === M[s + 1]) break;
                f = 1;
              case 1:
                if (!(C ? o.length === i[a].length : s === i[a].length - 2)) break;
              case 2:
                var z = b ? o : o.slice().reverse(),
                  I = b ? M : M.slice().reverse(),
                  T = (k = I, z.map(function(V, G) {
                    return [V, k[G]]
                  }).filter(function(V) {
                    return null !== V[1]
                  })),
                  E = T.length > 1 ? function(w) {
                    var e = function(w) {
                        for (var e, t, i, a, s = function(c) {
                            for (var d = [], g = c[0], p = c[1], f = d[0] = He(g, p), x = 1, m = c
                                .length - 1; x < m; x++) d[x] = .5 * (f + (f = He(g = p, p = c[x + 1])));
                            return d[x] = f, d
                          }(w), r = w.length - 1, n = [], o = 0; o < r; o++) i = He(w[o], w[o + 1]), Math
                          .abs(i) < 1e-6 ? s[o] = s[o + 1] = 0 : (a = (e = s[o] / i) * e + (t = s[o + 1] /
                            i) * t) > 9 && (a = 3 * i / Math.sqrt(a), s[o] = a * e, s[o + 1] = a * t);
                        for (var l = 0; l <= r; l++) a = (w[Math.min(r, l + 1)][0] - w[Math.max(0, l - 1)][
                          0]) / (6 * (1 + s[l] * s[l])), n.push([a || 0, s[l] * a || 0]);
                        return n
                      }(w),
                      t = w[1],
                      i = w[0],
                      a = [],
                      s = e[1],
                      r = e[0];
                    a.push(i, [i[0] + r[0], i[1] + r[1], t[0] - s[0], t[1] - s[1], t[0], t[1]]);
                    for (var n = 2, o = e.length; n < o; n++) {
                      var l = w[n],
                        c = e[n];
                      a.push([l[0] - c[0], l[1] - c[1], l[0], l[1]])
                    }
                    return a
                  }(T) : T,
                  H = [];
                C && (L ? h = T : H = h.reverse());
                var D = 0,
                  O = 0;
                if (function(V, G) {
                    for (var j = function(Se) {
                        var ie = [],
                          he = 0;
                        return Se.forEach(function(Vt) {
                          null !== Vt ? he++ : he > 0 && (ie.push(he), he = 0)
                        }), he > 0 && ie.push(he), ie
                      }(V), ee = [], te = 0, oe = 0; te < j.length; oe += j[te++]) ee[te] = Ht(G, oe, oe +
                      j[te]);
                    return ee
                  }(I, E).forEach(function(V) {
                    D++;
                    var G = function(te) {
                        for (var oe = "", Se = 0; Se < te.length; Se++) {
                          var ie = te[Se],
                            he = ie.length;
                          he > 4 ? (oe += "C".concat(ie[0], ", ").concat(ie[1]), oe += ", ".concat(ie[2],
                              ", ").concat(ie[3]), oe += ", ".concat(ie[4], ", ").concat(ie[5])) : he >
                            2 && (oe += "S".concat(ie[0], ", ").concat(ie[1]), oe += ", ".concat(ie[2],
                              ", ").concat(ie[3]))
                        }
                        return oe
                      }(V),
                      j = O,
                      ee = (O += V.length) - 1;
                    L ? m = A.move(T[j][0], T[j][1]) + G : C ? m = A.move(H[j][0], H[j][1]) + A.line(T[j][
                      0
                    ], T[j][1]) + G + A.line(H[ee][0], H[ee][1]) : (m = A.move(T[j][0], T[j][1]) + G,
                      v = m + A.line(T[ee][0], S) + A.line(T[j][0], S) + "z", h.push(v)), y.push(m)
                  }), C && D > 1 && !L) {
                  var W = y.slice(D).reverse();
                  y.splice(D), W.forEach(function(V) {
                    return y.push(V)
                  })
                }
                f = 0
            }
            break;
          case "smooth":
            var N = .35 * (r - g);
            if (null === i[a][s]) f = 0;
            else switch (f) {
              case 0:
                if (x = g, m = L ? A.move(g, d[s]) + A.line(g, p) : A.move(g, p), v = A.move(g, p), f = 1,
                  s < i[a].length - 2) {
                  var B = A.curve(g + N, p, r - N, n, r, n);
                  m += B, v += B;
                  break
                }
              case 1:
                if (null === i[a][s + 1]) m += L ? A.line(g, c) : A.move(g, p), v += A.line(g, S) + A
                  .line(x, S) + "z", y.push(m), h.push(v);
                else {
                  var Z = A.curve(g + N, p, r - N, n, r, n);
                  m += Z, v += Z, s >= i[a].length - 2 && (L && (m += A.curve(r, n, r, n, r, c) + A.move(
                    r, c)), v += A.curve(r, n, r, n, r, S) + A.line(x, S) + "z", y.push(m), h.push(v))
                }
            }
            g = r, p = n;
            break;
          default:
            var U = function(V, G, j) {
              var ee = [];
              switch (V) {
                case "stepline":
                  ee = A.line(G, null, "H") + A.line(null, j, "V");
                  break;
                case "linestep":
                  ee = A.line(null, j, "V") + A.line(G, null, "H");
                  break;
                case "straight":
                  ee = A.line(G, j)
              }
              return ee
            };
            if (null === i[a][s]) f = 0;
            else switch (f) {
              case 0:
                if (x = g, m = L ? A.move(g, d[s]) + A.line(g, p) : A.move(g, p), v = A.move(g, p), f = 1,
                  s < i[a].length - 2) {
                  var _ = U(u, r, n);
                  m += _, v += _;
                  break
                }
              case 1:
                if (null === i[a][s + 1]) m += L ? A.line(g, c) : A.move(g, p), v += A.line(g, S) + A
                  .line(x, S) + "z", y.push(m), h.push(v);
                else {
                  var ae = U(u, r, n);
                  m += ae, v += ae, s >= i[a].length - 2 && (L && (m += A.line(r, c)), v += A.line(r, S) +
                    A.line(x, S) + "z", y.push(m), h.push(v))
                }
            }
            g = r, p = n
        }
        return {
          linePaths: y,
          areaPaths: h,
          pX: g,
          pY: p,
          pathState: f,
          segmentStartX: x,
          linePath: m,
          areaPath: v
        }
      }
    }, {
      key: "handleNullDataPoints",
      value: function(e, t, i, a, s) {
        var r = this.w;
        if (null === e[i][a] && r.config.markers.showNullDataPoints || 1 === e[i].length) {
          var n = this.strokeWidth - r.config.markers.strokeWidth / 2;
          n > 0 || (n = 0);
          var o = this.markers.plotChartMarkers(t, s, a + 1, n, !0);
          null !== o && this.elPointsMain.add(o)
        }
      }
    }]), w
  }();
  window.TreemapSquared = {}, window.TreemapSquared.generate = function() {
    function w(n, o, l, c) {
      this.xoffset = n, this.yoffset = o, this.height = c, this.width = l, this.shortestEdge = function() {
        return Math.min(this.height, this.width)
      }, this.getCoordinates = function(d) {
        var g, p = [],
          f = this.xoffset,
          x = this.yoffset,
          m = s(d) / this.height,
          v = s(d) / this.width;
        if (this.width >= this.height)
          for (g = 0; g < d.length; g++) p.push([f, x, f + m, x + d[g] / m]), x += d[g] / m;
        else
          for (g = 0; g < d.length; g++) p.push([f, x, f + d[g] / v, x + v]), f += d[g] / v;
        return p
      }, this.cutArea = function(d) {
        var g;
        if (this.width >= this.height) {
          var p = d / this.height;
          g = new w(this.xoffset + p, this.yoffset, this.width - p, this.height)
        } else {
          var x = d / this.width;
          g = new w(this.xoffset, this.yoffset + x, this.width, this.height - x)
        }
        return g
      }
    }

    function e(n, o, l, c, d) {
      return c = void 0 === c ? 0 : c, d = void 0 === d ? 0 : d,
        function(p) {
          var f, x, m = [];
          for (f = 0; f < p.length; f++)
            for (x = 0; x < p[f].length; x++) m.push(p[f][x]);
          return m
        }(t(function(p, f) {
          var x, m = [],
            v = f / s(p);
          for (x = 0; x < p.length; x++) m[x] = p[x] * v;
          return m
        }(n, o * l), [], new w(c, d, o, l), []))
    }

    function t(n, o, l, c) {
      var d, g, p, f, x, m, v;
      if (0 !== n.length) return d = l.shortestEdge(), x = g = n[0], m = d, 0 === (f = o).length || ((v = f.slice())
        .push(x), i(f, m) >= i(v, m)) ? (o.push(g), t(n.slice(1), o, l, c)) : (p = l.cutArea(s(o), c), c.push(l
        .getCoordinates(o)), t(n, [], p, c)), c;
      c.push(l.getCoordinates(o))
    }

    function i(n, o) {
      var l = Math.min.apply(Math, n),
        c = Math.max.apply(Math, n),
        d = s(n);
      return Math.max(Math.pow(o, 2) * c / Math.pow(d, 2), Math.pow(d, 2) / (Math.pow(o, 2) * l))
    }

    function a(n) {
      return n && n.constructor === Array
    }

    function s(n) {
      var o, l = 0;
      for (o = 0; o < n.length; o++) l += n[o];
      return l
    }

    function r(n) {
      var o, l = 0;
      if (a(n[0]))
        for (o = 0; o < n.length; o++) l += r(n[o]);
      else l = s(n);
      return l
    }
    return function n(o, l, c, d, g) {
      d = void 0 === d ? 0 : d, g = void 0 === g ? 0 : g;
      var p, f, x = [],
        m = [];
      if (a(o[0])) {
        for (f = 0; f < o.length; f++) x[f] = r(o[f]);
        for (p = e(x, l, c, d, g), f = 0; f < o.length; f++) m.push(n(o[f], p[f][2] - p[f][0], p[f][3] - p[f][1],
          p[f][0], p[f][1]))
      } else m = e(o, l, c, d, g);
      return m
    }
  }();
  var le, Ae, Dt = function() {
      function w(e, t) {
        F(this, w), this.ctx = e, this.w = e.w, this.strokeWidth = this.w.config.stroke.width, this.helpers = new it(
          e), this.dynamicAnim = this.w.config.chart.animations.dynamicAnimation, this.labels = []
      }
      return R(w, [{
        key: "draw",
        value: function(e) {
          var t = this,
            i = this.w,
            a = new X(this.ctx),
            s = new re(this.ctx),
            r = a.group({
              class: "apexcharts-treemap"
            });
          if (i.globals.noData) return r;
          var n = [];
          return e.forEach(function(o) {
            var l = o.map(function(c) {
              return Math.abs(c)
            });
            n.push(l)
          }), this.negRange = this.helpers.checkColorRange(), i.config.series.forEach(function(o, l) {
            o.data.forEach(function(c) {
              Array.isArray(t.labels[l]) || (t.labels[l] = []), t.labels[l].push(c.x)
            })
          }), window.TreemapSquared.generate(n, i.globals.gridWidth, i.globals.gridHeight).forEach(function(
            o, l) {
            var c = a.group({
              class: "apexcharts-series apexcharts-treemap-series",
              seriesName: P.escapeString(i.globals.seriesNames[l]),
              rel: l + 1,
              "data:realIndex": l
            });
            if (i.config.chart.dropShadow.enabled) {
              var d = i.config.chart.dropShadow;
              new K(t.ctx).dropShadow(r, d, l)
            }
            var g = a.group({
              class: "apexcharts-data-labels"
            });
            o.forEach(function(p, f) {
              var x = p[0],
                m = p[1],
                v = p[2],
                y = p[3],
                h = a.drawRect(x, m, v - x, y - m, i.config.plotOptions.treemap.borderRadius, "#fff",
                  1, t.strokeWidth, i.config.plotOptions.treemap.useFillColorAsStroke ? b : i.globals
                  .stroke.colors[l]);
              h.attr({
                cx: x,
                cy: m,
                index: l,
                i: l,
                j: f,
                width: v - x,
                height: y - m
              });
              var u = t.helpers.getShadeColor(i.config.chart.type, l, f, t.negRange),
                b = u.color;
              void 0 !== i.config.series[l].data[f] && i.config.series[l].data[f].fillColor && (b = i
                .config.series[l].data[f].fillColor);
              var k = s.fillPath({
                color: b,
                seriesNumber: l,
                dataPointIndex: f
              });
              h.node.classList.add("apexcharts-treemap-rect"), h.attr({
                fill: k
              }), t.helpers.addListeners(h);
              var A = {
                  x: x + (v - x) / 2,
                  y: m + (y - m) / 2,
                  width: 0,
                  height: 0
                },
                S = {
                  x,
                  y: m,
                  width: v - x,
                  height: y - m
                };
              if (i.config.chart.animations.enabled && !i.globals.dataChanged) {
                var C = 1;
                i.globals.resized || (C = i.config.chart.animations.speed), t.animateTreemap(h, A, S,
                  C)
              }
              i.globals.dataChanged && t.dynamicAnim.enabled && i.globals.shouldAnimate && (i.globals
                .previousPaths[l] && i.globals.previousPaths[l][f] && i.globals.previousPaths[l][f]
                .rect && (A = i.globals.previousPaths[l][f].rect), t.animateTreemap(h, A, S, t
                  .dynamicAnim.speed));
              var M = t.getFontSize(p),
                z = i.config.dataLabels.formatter(t.labels[l][f], {
                  value: i.globals.series[l][f],
                  seriesIndex: l,
                  dataPointIndex: f,
                  w: i
                });
              "truncate" === i.config.plotOptions.treemap.dataLabels.format && (M = parseInt(i.config
                .dataLabels.style.fontSize, 10), z = t.truncateLabels(z, M, x, m, v, y));
              var I = t.helpers.calculateDataLabels({
                text: z,
                x: (x + v) / 2,
                y: (m + y) / 2 + t.strokeWidth / 2 + M / 3,
                i: l,
                j: f,
                colorProps: u,
                fontSize: M,
                series: e
              });
              i.config.dataLabels.enabled && I && t.rotateToFitLabel(I, M, z, x, m, v, y), c.add(h),
                null !== I && c.add(I)
            }), c.add(g), r.add(c)
          }), r
        }
      }, {
        key: "getFontSize",
        value: function(e) {
          var r, t = this.w,
            n = function o(l) {
              var c, d = 0;
              if (Array.isArray(l[0]))
                for (c = 0; c < l.length; c++) d += o(l[c]);
              else
                for (c = 0; c < l.length; c++) d += l[c].length;
              return d
            }(this.labels) / function o(l) {
              var c, d = 0;
              if (Array.isArray(l[0]))
                for (c = 0; c < l.length; c++) d += o(l[c]);
              else
                for (c = 0; c < l.length; c++) d += 1;
              return d
            }(this.labels);
          return r = Math.pow((e[2] - e[0]) * (e[3] - e[1]), .5), Math.min(r / n, parseInt(t.config.dataLabels
            .style.fontSize, 10))
        }
      }, {
        key: "rotateToFitLabel",
        value: function(e, t, i, a, s, r, n) {
          var o = new X(this.ctx),
            l = o.getTextRects(i, t);
          if (l.width + this.w.config.stroke.width + 5 > r - a && l.width <= n - s) {
            var c = o.rotateAroundCenter(e.node);
            e.node.setAttribute("transform", "rotate(-90 ".concat(c.x, " ").concat(c.y, ") translate(")
              .concat(l.height / 3, ")"))
          }
        }
      }, {
        key: "truncateLabels",
        value: function(e, t, i, a, s, r) {
          var n = new X(this.ctx),
            o = n.getTextRects(e, t).width + this.w.config.stroke.width + 5 > s - i && r - a > s - i ? r - a :
            s - i,
            l = n.getTextBasedOnMaxWidth({
              text: e,
              maxWidth: o,
              fontSize: t
            });
          return e.length !== l.length && o / t < 5 ? "" : l
        }
      }, {
        key: "animateTreemap",
        value: function(e, t, i, a) {
          var s = new ge(this.ctx);
          s.animateRect(e, {
            x: t.x,
            y: t.y,
            width: t.width,
            height: t.height
          }, {
            x: i.x,
            y: i.y,
            width: i.width,
            height: i.height
          }, a, function() {
            s.animationCompleted(e)
          })
        }
      }]), w
    }(),
    Nt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w, this.timeScaleArray = [], this.utc = this.w.config.xaxis.labels
          .datetimeUTC
      }
      return R(w, [{
        key: "calculateTimeScaleTicks",
        value: function(e, t) {
          var i = this,
            a = this.w;
          if (a.globals.allSeriesCollapsed) return a.globals.labels = [], a.globals.timescaleLabels = [], [];
          var s = new Q(this.ctx),
            r = (t - e) / 864e5;
          this.determineInterval(r), a.globals.disableZoomIn = !1, a.globals.disableZoomOut = !1, r <
            .00011574074074074075 ? a.globals.disableZoomIn = !0 : r > 5e4 && (a.globals.disableZoomOut = !0);
          var n = s.getTimeUnitsfromTimestamp(e, t, this.utc),
            o = a.globals.gridWidth / r,
            l = o / 24,
            c = l / 60,
            d = c / 60,
            g = Math.floor(24 * r),
            p = Math.floor(1440 * r),
            f = Math.floor(86400 * r),
            x = Math.floor(r),
            m = Math.floor(r / 30),
            v = Math.floor(r / 365),
            y = {
              minMillisecond: n.minMillisecond,
              minSecond: n.minSecond,
              minMinute: n.minMinute,
              minHour: n.minHour,
              minDate: n.minDate,
              minMonth: n.minMonth,
              minYear: n.minYear
            },
            h = {
              firstVal: y,
              currentMillisecond: y.minMillisecond,
              currentSecond: y.minSecond,
              currentMinute: y.minMinute,
              currentHour: y.minHour,
              currentMonthDate: y.minDate,
              currentDate: y.minDate,
              currentMonth: y.minMonth,
              currentYear: y.minYear,
              daysWidthOnXAxis: o,
              hoursWidthOnXAxis: l,
              minutesWidthOnXAxis: c,
              secondsWidthOnXAxis: d,
              numberOfSeconds: f,
              numberOfMinutes: p,
              numberOfHours: g,
              numberOfDays: x,
              numberOfMonths: m,
              numberOfYears: v
            };
          switch (this.tickInterval) {
            case "years":
              this.generateYearScale(h);
              break;
            case "months":
            case "half_year":
              this.generateMonthScale(h);
              break;
            case "months_days":
            case "months_fortnight":
            case "days":
            case "week_days":
              this.generateDayScale(h);
              break;
            case "hours":
              this.generateHourScale(h);
              break;
            case "minutes_fives":
            case "minutes":
              this.generateMinuteScale(h);
              break;
            case "seconds_tens":
            case "seconds_fives":
            case "seconds":
              this.generateSecondScale(h)
          }
          var u = this.timeScaleArray.map(function(b) {
            var k = {
              position: b.position,
              unit: b.unit,
              year: b.year,
              day: b.day ? b.day : 1,
              hour: b.hour ? b.hour : 0,
              month: b.month + 1
            };
            return "month" === b.unit ? Y(Y({}, k), {}, {
              day: 1,
              value: b.value + 1
            }) : "day" === b.unit || "hour" === b.unit ? Y(Y({}, k), {}, {
              value: b.value
            }) : "minute" === b.unit ? Y(Y({}, k), {}, {
              value: b.value,
              minute: b.value
            }) : "second" === b.unit ? Y(Y({}, k), {}, {
              value: b.value,
              minute: b.minute,
              second: b.second
            }) : b
          });
          return u.filter(function(b) {
            var k = 1,
              A = Math.ceil(a.globals.gridWidth / 120),
              S = b.value;
            void 0 !== a.config.xaxis.tickAmount && (A = a.config.xaxis.tickAmount), u.length > A && (k =
              Math.floor(u.length / A));
            var C = !1,
              L = !1;
            switch (i.tickInterval) {
              case "years":
                "year" === b.unit && (C = !0);
                break;
              case "half_year":
                k = 7, "year" === b.unit && (C = !0);
                break;
              case "months":
                k = 1, "year" === b.unit && (C = !0);
                break;
              case "months_fortnight":
                k = 15, "year" !== b.unit && "month" !== b.unit || (C = !0), 30 === S && (L = !0);
                break;
              case "months_days":
                k = 10, "month" === b.unit && (C = !0), 30 === S && (L = !0);
                break;
              case "week_days":
                k = 8, "month" === b.unit && (C = !0);
                break;
              case "days":
                k = 1, "month" === b.unit && (C = !0);
                break;
              case "hours":
                "day" === b.unit && (C = !0);
                break;
              case "minutes_fives":
              case "seconds_fives":
                S % 5 != 0 && (L = !0);
                break;
              case "seconds_tens":
                S % 10 != 0 && (L = !0)
            }
            if ("hours" === i.tickInterval || "minutes_fives" === i.tickInterval || "seconds_tens" === i
              .tickInterval || "seconds_fives" === i.tickInterval) {
              if (!L) return !0
            } else if ((S % k == 0 || C) && !L) return !0
          })
        }
      }, {
        key: "recalcDimensionsBasedOnFormat",
        value: function(e, t) {
          var i = this.w,
            a = this.formatDates(e),
            s = this.removeOverlappingTS(a);
          i.globals.timescaleLabels = s.slice(), new Me(this.ctx).plotCoords()
        }
      }, {
        key: "determineInterval",
        value: function(e) {
          var t = 24 * e,
            i = 60 * t;
          switch (!0) {
            case e / 365 > 5:
              this.tickInterval = "years";
              break;
            case e > 800:
              this.tickInterval = "half_year";
              break;
            case e > 180:
              this.tickInterval = "months";
              break;
            case e > 90:
              this.tickInterval = "months_fortnight";
              break;
            case e > 60:
              this.tickInterval = "months_days";
              break;
            case e > 30:
              this.tickInterval = "week_days";
              break;
            case e > 2:
              this.tickInterval = "days";
              break;
            case t > 2.4:
              this.tickInterval = "hours";
              break;
            case i > 15:
              this.tickInterval = "minutes_fives";
              break;
            case i > 5:
              this.tickInterval = "minutes";
              break;
            case i > 1:
              this.tickInterval = "seconds_tens";
              break;
            case 60 * i > 20:
              this.tickInterval = "seconds_fives";
              break;
            default:
              this.tickInterval = "seconds"
          }
        }
      }, {
        key: "generateYearScale",
        value: function(e) {
          var t = e.firstVal,
            i = e.currentMonth,
            a = e.currentYear,
            s = e.daysWidthOnXAxis,
            r = e.numberOfYears,
            n = t.minYear,
            o = 0,
            l = new Q(this.ctx),
            c = "year";
          if (t.minDate > 1 || t.minMonth > 0) {
            var d = l.determineRemainingDaysOfYear(t.minYear, t.minMonth, t.minDate);
            o = (l.determineDaysOfYear(t.minYear) - d + 1) * s, this.timeScaleArray.push({
              position: o,
              value: n = t.minYear + 1,
              unit: c,
              year: n,
              month: P.monthMod(i + 1)
            })
          } else 1 === t.minDate && 0 === t.minMonth && this.timeScaleArray.push({
            position: o,
            value: n,
            unit: c,
            year: a,
            month: P.monthMod(i + 1)
          });
          for (var g = n, p = o, f = 0; f < r; f++) g++, p = l.determineDaysOfYear(g - 1) * s + p, this
            .timeScaleArray.push({
              position: p,
              value: g,
              unit: c,
              year: g,
              month: 1
            })
        }
      }, {
        key: "generateMonthScale",
        value: function(e) {
          var t = e.firstVal,
            i = e.currentMonthDate,
            a = e.currentMonth,
            s = e.currentYear,
            r = e.daysWidthOnXAxis,
            n = e.numberOfMonths,
            o = a,
            l = 0,
            c = new Q(this.ctx),
            d = "month",
            g = 0;
          if (t.minDate > 1) {
            l = (c.determineDaysOfMonths(a + 1, t.minYear) - i + 1) * r, o = P.monthMod(a + 1);
            var p = s + g,
              f = P.monthMod(o),
              x = o;
            0 === o && (d = "year", x = p, f = 1, p += g += 1), this.timeScaleArray.push({
              position: l,
              value: x,
              unit: d,
              year: p,
              month: f
            })
          } else this.timeScaleArray.push({
            position: l,
            value: o,
            unit: d,
            year: s,
            month: P.monthMod(a)
          });
          for (var m = o + 1, v = l, y = 0, h = 1; y < n; y++, h++) {
            0 === (m = P.monthMod(m)) ? (d = "year", g += 1) : d = "month";
            var u = this._getYear(s, m, g);
            v = c.determineDaysOfMonths(m, u) * r + v, this.timeScaleArray.push({
              position: v,
              value: 0 === m ? u : m,
              unit: d,
              year: u,
              month: 0 === m ? 1 : m
            }), m++
          }
        }
      }, {
        key: "generateDayScale",
        value: function(e) {
          var t = e.firstVal,
            i = e.currentMonth,
            a = e.currentYear,
            s = e.hoursWidthOnXAxis,
            r = e.numberOfDays,
            n = new Q(this.ctx),
            o = "day",
            l = t.minDate + 1,
            c = l,
            d = function(h, u, b) {
              return h > n.determineDaysOfMonths(u + 1, b) && (c = 1, o = "month", p = u += 1), u
            },
            g = (24 - t.minHour) * s,
            p = l,
            f = d(c, i, a);
          0 === t.minHour && 1 === t.minDate ? (g = 0, p = P.monthMod(t.minMonth), o = "month", c = t
            .minDate) : 1 !== t.minDate && 0 === t.minHour && 0 === t.minMinute && (g = 0, p = l = t.minDate,
              f = d(c = l, i, a)), this.timeScaleArray.push({
              position: g,
              value: p,
              unit: o,
              year: this._getYear(a, f, 0),
              month: P.monthMod(f),
              day: c
            });
          for (var x = g, m = 0; m < r; m++) {
            o = "day", f = d(c += 1, f, this._getYear(a, f, 0));
            var v = this._getYear(a, f, 0);
            x = 24 * s + x;
            var y = 1 === c ? P.monthMod(f) : c;
            this.timeScaleArray.push({
              position: x,
              value: y,
              unit: o,
              year: v,
              month: P.monthMod(f),
              day: y
            })
          }
        }
      }, {
        key: "generateHourScale",
        value: function(e) {
          var t = e.firstVal,
            i = e.currentDate,
            a = e.currentMonth,
            s = e.currentYear,
            r = e.minutesWidthOnXAxis,
            n = e.numberOfHours,
            o = new Q(this.ctx),
            l = "hour",
            c = function(k, A) {
              return k > o.determineDaysOfMonths(A + 1, s) && (m = 1, A += 1), {
                month: A,
                date: m
              }
            },
            d = function(k, A) {
              return k > o.determineDaysOfMonths(A + 1, s) ? A += 1 : A
            },
            g = 60 - (t.minMinute + t.minSecond / 60),
            p = g * r,
            f = t.minHour + 1,
            x = f;
          60 === g && (p = 0, x = f = t.minHour);
          var m = i;
          x >= 24 && (x = 0, m += 1, l = "day");
          var v = c(m, a).month;
          v = d(m, v), this.timeScaleArray.push({
            position: p,
            value: f,
            unit: l,
            day: m,
            hour: x,
            year: s,
            month: P.monthMod(v)
          }), x++;
          for (var y = p, h = 0; h < n; h++) {
            l = "hour", x >= 24 && (x = 0, l = "day", v = c(m += 1, v).month, v = d(m, v));
            var u = this._getYear(s, v, 0);
            this.timeScaleArray.push({
              position: y = 60 * r + y,
              value: 0 === x ? m : x,
              unit: l,
              hour: x,
              day: m,
              year: u,
              month: P.monthMod(v)
            }), x++
          }
        }
      }, {
        key: "generateMinuteScale",
        value: function(e) {
          for (var l = e.minutesWidthOnXAxis, d = e.numberOfMinutes, g = e.currentMinute + 1, p = e
              .currentDate, f = e.currentMonth, x = e.currentYear, m = e.currentHour, v = (60 - e
                .currentSecond - e.currentMillisecond / 1e3) * e.secondsWidthOnXAxis, y = 0; y < d; y++) g >=
            60 && (g = 0, 24 === (m += 1) && (m = 0)), this.timeScaleArray.push({
              position: v,
              value: g,
              unit: "minute",
              hour: m,
              minute: g,
              day: p,
              year: this._getYear(x, f, 0),
              month: P.monthMod(f)
            }), v += l, g++
        }
      }, {
        key: "generateSecondScale",
        value: function(e) {
          for (var l = e.secondsWidthOnXAxis, c = e.numberOfSeconds, d = e.currentSecond + 1, g = e
              .currentMinute, p = e.currentDate, f = e.currentMonth, x = e.currentYear, m = e.currentHour, v =
              (1e3 - e.currentMillisecond) / 1e3 * l, y = 0; y < c; y++) d >= 60 && (d = 0, ++g >= 60 && (g =
            0, 24 == ++m && (m = 0))), this.timeScaleArray.push({
            position: v,
            value: d,
            unit: "second",
            hour: m,
            minute: g,
            second: d,
            day: p,
            year: this._getYear(x, f, 0),
            month: P.monthMod(f)
          }), v += l, d++
        }
      }, {
        key: "createRawDateString",
        value: function(e, t) {
          var i = e.year;
          return 0 === e.month && (e.month = 1), i += "-" + ("0" + e.month.toString()).slice(-2), i +=
            "day" === e.unit ? "day" === e.unit ? "-" + ("0" + t).slice(-2) : "-01" : "-" + ("0" + (e.day ? e
              .day : "1")).slice(-2), i += "hour" === e.unit ? "hour" === e.unit ? "T" + ("0" + t).slice(-2) :
            "T00" : "T" + ("0" + (e.hour ? e.hour : "0")).slice(-2), i += "minute" === e.unit ? ":" + ("0" +
              t).slice(-2) : ":" + (e.minute ? ("0" + e.minute).slice(-2) : "00"), i += "second" === e.unit ?
            ":" + ("0" + t).slice(-2) : ":00", this.utc && (i += ".000Z"), i
        }
      }, {
        key: "formatDates",
        value: function(e) {
          var t = this,
            i = this.w;
          return e.map(function(a) {
            var s = a.value.toString(),
              r = new Q(t.ctx),
              n = t.createRawDateString(a, s),
              o = r.getDate(r.parseDate(n));
            if (t.utc || (o = r.getDate(r.parseDateWithTimezone(n))), void 0 === i.config.xaxis.labels
              .format) {
              var l = "dd MMM",
                c = i.config.xaxis.labels.datetimeFormatter;
              "year" === a.unit && (l = c.year), "month" === a.unit && (l = c.month), "day" === a.unit &&
                (l = c.day), "hour" === a.unit && (l = c.hour), "minute" === a.unit && (l = c.minute),
                "second" === a.unit && (l = c.second), s = r.formatDate(o, l)
            } else s = r.formatDate(o, i.config.xaxis.labels.format);
            return {
              dateString: n,
              position: a.position,
              value: s,
              unit: a.unit,
              year: a.year,
              month: a.month
            }
          })
        }
      }, {
        key: "removeOverlappingTS",
        value: function(e) {
          var t, i = this,
            a = new X(this.ctx),
            s = !1;
          e.length > 0 && e[0].value && e.every(function(o) {
            return o.value.length === e[0].value.length
          }) && (s = !0, t = a.getTextRects(e[0].value).width);
          var r = 0;
          return e.map(function(o, l) {
            if (l > 0 && i.w.config.xaxis.labels.hideOverlappingLabels) {
              var c = s ? t : a.getTextRects(e[r].value).width;
              return o.position > e[r].position + c + 10 ? (r = l, o) : null
            }
            return o
          }).filter(function(o) {
            return null !== o
          })
        }
      }, {
        key: "_getYear",
        value: function(e, t, i) {
          return e + Math.floor(t / 12) + i
        }
      }]), w
    }(),
    Wt = function() {
      function w(e, t) {
        F(this, w), this.ctx = t, this.w = t.w, this.el = e
      }
      return R(w, [{
        key: "setupElements",
        value: function() {
          var e = this.w.globals,
            t = this.w.config,
            i = t.chart.type;
          e.axisCharts = ["line", "area", "bar", "rangeBar", "rangeArea", "candlestick", "boxPlot", "scatter",
              "bubble", "radar", "heatmap", "treemap"
            ].indexOf(i) > -1, e.xyCharts = ["line", "area", "bar", "rangeBar", "rangeArea", "candlestick",
              "boxPlot", "scatter", "bubble"
            ].indexOf(i) > -1, e.isBarHorizontal = ("bar" === t.chart.type || "rangeBar" === t.chart.type ||
              "boxPlot" === t.chart.type) && t.plotOptions.bar.horizontal, e.chartClass = ".apexcharts" + e
            .chartID, e.dom.baseEl = this.el, e.dom.elWrap = document.createElement("div"), X.setAttrs(e.dom
              .elWrap, {
                id: e.chartClass.substring(1),
                class: "apexcharts-canvas " + e.chartClass.substring(1)
              }), this.el.appendChild(e.dom.elWrap), e.dom.Paper = new window.SVG.Doc(e.dom.elWrap), e.dom
            .Paper.attr({
              class: "apexcharts-svg",
              "xmlns:data": "ApexChartsNS",
              transform: "translate(".concat(t.chart.offsetX, ", ").concat(t.chart.offsetY, ")")
            }), e.dom.Paper.node.style.background = "dark" !== t.theme.mode || t.chart.background ? t.chart
            .background : "rgba(0, 0, 0, 0.8)", this.setSVGDimensions(), e.dom.elLegendForeign = document
            .createElementNS(e.SVGNS, "foreignObject"), X.setAttrs(e.dom.elLegendForeign, {
              x: 0,
              y: 0,
              width: e.svgWidth,
              height: e.svgHeight
            }), e.dom.elLegendWrap = document.createElement("div"), e.dom.elLegendWrap.classList.add(
              "apexcharts-legend"), e.dom.elLegendWrap.setAttribute("xmlns", "http://www.w3.org/1999/xhtml"),
            e.dom.elLegendForeign.appendChild(e.dom.elLegendWrap), e.dom.Paper.node.appendChild(e.dom
              .elLegendForeign), e.dom.elGraphical = e.dom.Paper.group().attr({
              class: "apexcharts-inner apexcharts-graphical"
            }), e.dom.elDefs = e.dom.Paper.defs(), e.dom.Paper.add(e.dom.elGraphical), e.dom.elGraphical.add(e
              .dom.elDefs)
        }
      }, {
        key: "plotChartType",
        value: function(e, t) {
          var i = this.w,
            a = i.config,
            s = i.globals,
            r = {
              series: [],
              i: []
            },
            n = {
              series: [],
              i: []
            },
            o = {
              series: [],
              i: []
            },
            l = {
              series: [],
              i: []
            },
            c = {
              series: [],
              i: []
            },
            d = {
              series: [],
              i: []
            },
            g = {
              series: [],
              i: []
            },
            p = {
              series: [],
              i: []
            },
            f = {
              series: [],
              seriesRangeEnd: [],
              i: []
            },
            x = void 0 !== a.chart.type ? a.chart.type : "line",
            m = null,
            v = 0;
          s.series.forEach(function(I, T) {
            var E = e[T].type || x;
            switch (E) {
              case "column":
              case "bar":
                c.series.push(I), c.i.push(T), i.globals.columnSeries = c;
                break;
              case "area":
                n.series.push(I), n.i.push(T);
                break;
              case "line":
                r.series.push(I), r.i.push(T);
                break;
              case "scatter":
                o.series.push(I), o.i.push(T);
                break;
              case "bubble":
                l.series.push(I), l.i.push(T);
                break;
              case "candlestick":
                d.series.push(I), d.i.push(T);
                break;
              case "boxPlot":
                g.series.push(I), g.i.push(T);
                break;
              case "rangeBar":
                p.series.push(I), p.i.push(T);
                break;
              case "rangeArea":
                f.series.push(s.seriesRangeStart[T]), f.seriesRangeEnd.push(s.seriesRangeEnd[T]), f.i
                  .push(T);
                break;
              case "heatmap":
              case "treemap":
              case "pie":
              case "donut":
              case "polarArea":
              case "radialBar":
              case "radar":
                m = E;
                break;
              default:
                console.warn("You have specified an unrecognized series type (", E, ").")
            }
            x !== E && "scatter" !== E && v++
          }), v > 0 && (null !== m && console.warn("Chart or series type ", m,
              " can not appear with other chart or series types."), c.series.length > 0 && a.plotOptions.bar
            .horizontal && (v -= c.length, c = {
              series: [],
              i: []
            }, i.globals.columnSeries = {
              series: [],
              i: []
            }, console.warn(
              "Horizontal bars are not supported in a mixed/combo chart. Please turn off `plotOptions.bar.horizontal`"
              ))), s.comboCharts || (s.comboCharts = v > 0);
          var y = new De(this.ctx, t),
            h = new Re(this.ctx, t);
          this.ctx.pie = new st(this.ctx);
          var u = new Xt(this.ctx);
          this.ctx.rangeBar = new Et(this.ctx, t);
          var b = new zt(this.ctx),
            k = [];
          if (s.comboCharts) {
            var A, S, C = new q(this.ctx);
            if (n.series.length > 0 && (A = k).push.apply(A, J(C.drawSeriesByGroup(n, s.areaGroups, "area",
                y))), c.series.length > 0)
              if (i.config.chart.stacked) {
                var L = new tt(this.ctx, t);
                k.push(L.draw(c.series, c.i))
              } else this.ctx.bar = new pe(this.ctx, t), k.push(this.ctx.bar.draw(c.series, c.i));
            if (f.series.length > 0 && k.push(y.draw(f.series, "rangeArea", f.i, f.seriesRangeEnd)), r.series
              .length > 0 && (S = k).push.apply(S, J(C.drawSeriesByGroup(r, s.lineGroups, "line", y))), d
              .series.length > 0 && k.push(h.draw(d.series, "candlestick", d.i)), g.series.length > 0 && k
              .push(h.draw(g.series, "boxPlot", g.i)), p.series.length > 0 && k.push(this.ctx.rangeBar.draw(p
                .series, p.i)), o.series.length > 0) {
              var M = new De(this.ctx, t, !0);
              k.push(M.draw(o.series, "scatter", o.i))
            }
            if (l.series.length > 0) {
              var z = new De(this.ctx, t, !0);
              k.push(z.draw(l.series, "bubble", l.i))
            }
          } else switch (a.chart.type) {
            case "line":
              k = y.draw(s.series, "line");
              break;
            case "area":
              k = y.draw(s.series, "area");
              break;
            case "bar":
              a.chart.stacked ? k = new tt(this.ctx, t).draw(s.series) : (this.ctx.bar = new pe(this.ctx,
                t), k = this.ctx.bar.draw(s.series));
              break;
            case "candlestick":
              k = new Re(this.ctx, t).draw(s.series, "candlestick");
              break;
            case "boxPlot":
              k = new Re(this.ctx, t).draw(s.series, a.chart.type);
              break;
            case "rangeBar":
              k = this.ctx.rangeBar.draw(s.series);
              break;
            case "rangeArea":
              k = y.draw(s.seriesRangeStart, "rangeArea", void 0, s.seriesRangeEnd);
              break;
            case "heatmap":
              k = new Tt(this.ctx, t).draw(s.series);
              break;
            case "treemap":
              k = new Dt(this.ctx, t).draw(s.series);
              break;
            case "pie":
            case "donut":
            case "polarArea":
              k = this.ctx.pie.draw(s.series);
              break;
            case "radialBar":
              k = u.draw(s.series);
              break;
            case "radar":
              k = b.draw(s.series);
              break;
            default:
              k = y.draw(s.series)
          }
          return k
        }
      }, {
        key: "setSVGDimensions",
        value: function() {
          var e = this.w.globals,
            t = this.w.config;
          e.svgWidth = t.chart.width, e.svgHeight = t.chart.height;
          var i = P.getDimensions(this.el),
            a = t.chart.width.toString().split(/[0-9]+/g).pop();
          "%" === a ? P.isNumber(i[0]) && (0 === i[0].width && (i = P.getDimensions(this.el.parentNode)), e
            .svgWidth = i[0] * parseInt(t.chart.width, 10) / 100) : "px" !== a && "" !== a || (e.svgWidth =
            parseInt(t.chart.width, 10));
          var s = t.chart.height.toString().split(/[0-9]+/g).pop();
          if ("auto" !== e.svgHeight && "" !== e.svgHeight)
            if ("%" === s) {
              var r = P.getDimensions(this.el.parentNode);
              e.svgHeight = r[1] * parseInt(t.chart.height, 10) / 100
            } else e.svgHeight = parseInt(t.chart.height, 10);
          else e.svgHeight = e.axisCharts ? e.svgWidth / 1.61 : e.svgWidth / 1.2;
          e.svgWidth < 0 && (e.svgWidth = 0), e.svgHeight < 0 && (e.svgHeight = 0), X.setAttrs(e.dom.Paper
              .node, {
                width: e.svgWidth,
                height: e.svgHeight
              }), "%" !== s && (e.dom.Paper.node.parentNode.parentNode.style.minHeight = e.svgHeight + (t
              .chart.sparkline.enabled ? 0 : e.axisCharts ? t.chart.parentHeightOffset : 0) + "px"), e.dom
            .elWrap.style.width = e.svgWidth + "px", e.dom.elWrap.style.height = e.svgHeight + "px"
        }
      }, {
        key: "shiftGraphPosition",
        value: function() {
          var e = this.w.globals;
          X.setAttrs(e.dom.elGraphical.node, {
            transform: "translate(" + e.translateX + ", " + e.translateY + ")"
          })
        }
      }, {
        key: "resizeNonAxisCharts",
        value: function() {
          var e = this.w,
            t = e.globals,
            i = 0,
            a = e.config.chart.sparkline.enabled ? 1 : 15;
          a += e.config.grid.padding.bottom, "top" !== e.config.legend.position && "bottom" !== e.config
            .legend.position || !e.config.legend.show || e.config.legend.floating || (i = new $e(this.ctx)
              .legendHelpers.getLegendBBox().clwh + 10);
          var s = e.globals.dom.baseEl.querySelector(".apexcharts-radialbar, .apexcharts-pie"),
            r = 2.05 * e.globals.radialSize;
          if (s && !e.config.chart.sparkline.enabled && 0 !== e.config.plotOptions.radialBar.startAngle) {
            var n = P.getBoundingClientRect(s);
            r = n.bottom, r = Math.max(2.05 * e.globals.radialSize, n.bottom - n.top)
          }
          var l = r + t.translateY + i + a;
          t.dom.elLegendForeign && t.dom.elLegendForeign.setAttribute("height", l), e.config.chart.height &&
            String(e.config.chart.height).indexOf("%") > 0 || (t.dom.elWrap.style.height = l + "px", X
              .setAttrs(t.dom.Paper.node, {
                height: l
              }), t.dom.Paper.node.parentNode.parentNode.style.minHeight = l + "px")
        }
      }, {
        key: "coreCalculations",
        value: function() {
          new Ee(this.ctx).init()
        }
      }, {
        key: "resetGlobals",
        value: function() {
          var e = this,
            t = function() {
              return e.w.config.series.map(function(s) {
                return []
              })
            },
            i = new je,
            a = this.w.globals;
          i.initGlobalVars(a), a.seriesXvalues = t(), a.seriesYvalues = t()
        }
      }, {
        key: "isMultipleY",
        value: function() {
          if (this.w.config.yaxis.constructor === Array && this.w.config.yaxis.length > 1) return this.w
            .globals.isMultipleYAxis = !0, !0
        }
      }, {
        key: "xySettings",
        value: function() {
          var e = null,
            t = this.w;
          if (t.globals.axisCharts) {
            if ("back" === t.config.xaxis.crosshairs.position && new Fe(this.ctx).drawXCrosshairs(),
              "back" === t.config.yaxis[0].crosshairs.position && new Fe(this.ctx).drawYCrosshairs(),
              "datetime" === t.config.xaxis.type && void 0 === t.config.xaxis.labels.formatter) {
              this.ctx.timeScale = new Nt(this.ctx);
              var i = [];
              isFinite(t.globals.minX) && isFinite(t.globals.maxX) && !t.globals.isBarHorizontal ? i = this
                .ctx.timeScale.calculateTimeScaleTicks(t.globals.minX, t.globals.maxX) : t.globals
                .isBarHorizontal && (i = this.ctx.timeScale.calculateTimeScaleTicks(t.globals.minY, t.globals
                  .maxY)), this.ctx.timeScale.recalcDimensionsBasedOnFormat(i)
            }
            e = new q(this.ctx).getCalculatedRatios()
          }
          return e
        }
      }, {
        key: "updateSourceChart",
        value: function(e) {
          this.ctx.w.globals.selection = void 0, this.ctx.updateHelpers._updateOptions({
            chart: {
              selection: {
                xaxis: {
                  min: e.w.globals.minX,
                  max: e.w.globals.maxX
                }
              }
            }
          }, !1, !1)
        }
      }, {
        key: "setupBrushHandler",
        value: function() {
          var e = this,
            t = this.w;
          if (t.config.chart.brush.enabled && "function" != typeof t.config.chart.events.selection) {
            var i = Array.isArray(t.config.chart.brush.targets) ? t.config.chart.brush.targets : [t.config
              .chart.brush.target
            ];
            i.forEach(function(a) {
              var s = ApexCharts.getChartByID(a);
              s.w.globals.brushSource = e.ctx, "function" != typeof s.w.config.chart.events.zoomed && (s.w
                .config.chart.events.zoomed = function() {
                  e.updateSourceChart(s)
                }), "function" != typeof s.w.config.chart.events.scrolled && (s.w.config.chart.events
                .scrolled = function() {
                  e.updateSourceChart(s)
                })
            }), t.config.chart.events.selection = function(a, s) {
              i.forEach(function(r) {
                ApexCharts.getChartByID(r).ctx.updateHelpers._updateOptions({
                  xaxis: {
                    min: s.xaxis.min,
                    max: s.xaxis.max
                  }
                }, !1, !1, !1, !1)
              })
            }
          }
        }
      }]), w
    }(),
    Bt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "_updateOptions",
        value: function(e) {
          var t = this,
            i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            a = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
            s = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
            r = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
          return new Promise(function(n) {
            var o = [t.ctx];
            s && (o = t.ctx.getSyncedCharts()), t.ctx.w.globals.isExecCalled && (o = [t.ctx], t.ctx.w
              .globals.isExecCalled = !1), o.forEach(function(l, c) {
              var d = l.w;
              if (d.globals.shouldAnimate = a, i || (d.globals.resized = !0, d.globals.dataChanged = !
                  0, a && l.series.getPreviousPaths()), e && "object" === $(e) && (l.config = new ye(
                    e), e = q.extendArrayProps(l.config, e, d), l.w.globals.chartID !== t.ctx.w
                  .globals.chartID && delete e.series, d.config = P.extend(d.config, e), r && (d
                    .globals.lastXAxis = e.xaxis ? P.clone(e.xaxis) : [], d.globals.lastYAxis = e
                    .yaxis ? P.clone(e.yaxis) : [], d.globals.initialConfig = P.extend({}, d.config),
                    d.globals.initialSeries = P.clone(d.config.series), e.series))) {
                for (var g = 0; g < d.globals.collapsedSeriesIndices.length; g++) {
                  var p = d.config.series[d.globals.collapsedSeriesIndices[g]];
                  d.globals.collapsedSeries[g].data = d.globals.axisCharts ? p.data.slice() : p
                }
                for (var f = 0; f < d.globals.ancillaryCollapsedSeriesIndices.length; f++) {
                  var x = d.config.series[d.globals.ancillaryCollapsedSeriesIndices[f]];
                  d.globals.ancillaryCollapsedSeries[f].data = d.globals.axisCharts ? x.data.slice() :
                    x
                }
                l.series.emptyCollapsedSeries(d.config.series)
              }
              return l.update(e).then(function() {
                c === o.length - 1 && n(l)
              })
            })
          })
        }
      }, {
        key: "_updateSeries",
        value: function(e, t) {
          var i = this,
            a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
          return new Promise(function(s) {
            var r, n = i.w;
            return n.globals.shouldAnimate = t, n.globals.dataChanged = !0, t && i.ctx.series
              .getPreviousPaths(), n.globals.axisCharts ? (0 === (r = e.map(function(o, l) {
                return i._extendSeries(o, l)
              })).length && (r = [{
                data: []
              }]), n.config.series = r) : n.config.series = e.slice(), a && (n.globals.initialConfig
                .series = P.clone(n.config.series), n.globals.initialSeries = P.clone(n.config.series)), i
              .ctx.update().then(function() {
                s(i.ctx)
              })
          })
        }
      }, {
        key: "_extendSeries",
        value: function(e, t) {
          var i = this.w,
            a = i.config.series[t];
          return Y(Y({}, i.config.series[t]), {}, {
            name: e.name ? e.name : a?.name,
            color: e.color ? e.color : a?.color,
            type: e.type ? e.type : a?.type,
            group: e.group ? e.group : a?.group,
            data: e.data ? e.data : a?.data,
            zIndex: void 0 !== e.zIndex ? e.zIndex : t
          })
        }
      }, {
        key: "toggleDataPointSelection",
        value: function(e, t) {
          var i = this.w,
            a = null,
            s = ".apexcharts-series[data\\:realIndex='".concat(e, "']");
          return i.globals.axisCharts ? a = i.globals.dom.Paper.select("".concat(s, " path[j='").concat(t,
              "'], ").concat(s, " circle[j='").concat(t, "'], ").concat(s, " rect[j='").concat(t, "']"))
            .members[0] : void 0 === t && (a = i.globals.dom.Paper.select("".concat(s, " path[j='").concat(e,
                "']")).members[0], "pie" !== i.config.chart.type && "polarArea" !== i.config.chart.type &&
              "donut" !== i.config.chart.type || this.ctx.pie.pieClicked(e)), a ? (new X(this.ctx)
              .pathMouseDown(a, null), a.node ? a.node : null) : (console.warn(
              "toggleDataPointSelection: Element not found"), null)
        }
      }, {
        key: "forceXAxisUpdate",
        value: function(e) {
          var t = this.w;
          if (["min", "max"].forEach(function(a) {
              void 0 !== e.xaxis[a] && (t.config.xaxis[a] = e.xaxis[a], t.globals.lastXAxis[a] = e.xaxis[a])
            }), e.xaxis.categories && e.xaxis.categories.length && (t.config.xaxis.categories = e.xaxis
              .categories), t.config.xaxis.convertedCatToNumeric) {
            var i = new ve(e);
            e = i.convertCatToNumericXaxis(e, this.ctx)
          }
          return e
        }
      }, {
        key: "forceYAxisUpdate",
        value: function(e) {
          return e.chart && e.chart.stacked && "100%" === e.chart.stackType && (Array.isArray(e.yaxis) ? e
            .yaxis.forEach(function(t, i) {
              e.yaxis[i].min = 0, e.yaxis[i].max = 100
            }) : (e.yaxis.min = 0, e.yaxis.max = 100)), e
        }
      }, {
        key: "revertDefaultAxisMinMax",
        value: function(e) {
          var t = this,
            i = this.w,
            a = i.globals.lastXAxis,
            s = i.globals.lastYAxis;
          e && e.xaxis && (a = e.xaxis), e && e.yaxis && (s = e.yaxis), i.config.xaxis.min = a.min, i.config
            .xaxis.max = a.max, i.config.yaxis.map(function(n, o) {
              i.globals.zoomed || void 0 !== s[o] ? function(n) {
                void 0 !== s[n] && (i.config.yaxis[n].min = s[n].min, i.config.yaxis[n].max = s[n].max)
              }(o) : void 0 !== t.ctx.opts.yaxis[o] && (n.min = t.ctx.opts.yaxis[o].min, n.max = t.ctx
                .opts.yaxis[o].max)
            })
        }
      }]), w
    }();
  le = typeof window < "u" ? window : void 0, Ae = function(w, e) {
      var t = (void 0 !== this ? this : w).SVG = function(h) {
        if (t.supported) return h = new t.Doc(h), t.parser.draw || t.prepare(), h
      };
      if (t.ns = "http://www.w3.org/2000/svg", t.xmlns = "http://www.w3.org/2000/xmlns/", t.xlink =
        "http://www.w3.org/1999/xlink", t.svgjs = "http://svgjs.dev", t.supported = !0, !t.supported) return !1;
      t.did = 1e3, t.eid = function(h) {
        return "Svgjs" + c(h) + t.did++
      }, t.create = function(h) {
        var u = e.createElementNS(this.ns, h);
        return u.setAttribute("id", this.eid(h)), u
      }, t.extend = function() {
        var h, u;
        u = (h = [].slice.call(arguments)).pop();
        for (var b = h.length - 1; b >= 0; b--)
          if (h[b])
            for (var k in u) h[b].prototype[k] = u[k];
        t.Set && t.Set.inherit && t.Set.inherit()
      }, t.invent = function(h) {
        var u = "function" == typeof h.create ? h.create : function() {
          this.constructor.call(this, t.create(h.create))
        };
        return h.inherit && (u.prototype = new h.inherit), h.extend && t.extend(u, h.extend), h.construct && t
          .extend(h.parent || t.Container, h.construct), u
      }, t.adopt = function(h) {
        return h ? h.instance ? h.instance : ((u = "svg" == h.nodeName ? h.parentNode instanceof w.SVGElement ?
            new t.Nested : new t.Doc : "linearGradient" == h.nodeName ? new t.Gradient("linear") :
            "radialGradient" == h.nodeName ? new t.Gradient("radial") : t[c(h.nodeName)] ? new(t[c(h.nodeName)]) :
            new t.Element(h)).type = h.nodeName, u.node = h, h.instance = u, u instanceof t.Doc && u.namespace()
          .defs(), u.setData(JSON.parse(h.getAttribute("svgjs:data")) || {}), u) : null;
        var u
      }, t.prepare = function() {
        var h = e.getElementsByTagName("body")[0],
          u = (h ? new t.Doc(h) : t.adopt(e.documentElement).nested()).size(2, 0);
        t.parser = {
          body: h || e.documentElement,
          draw: u.style("opacity:0;position:absolute;left:-100%;top:-100%;overflow:hidden").node,
          poly: u.polyline().node,
          path: u.path().node,
          native: t.create("svg")
        }
      }, t.parser = {
        native: t.create("svg")
      }, e.addEventListener("DOMContentLoaded", function() {
        t.parser.draw || t.prepare()
      }, !1), t.regex = {
        numberAndUnit: /^([+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?)([a-z%]*)$/i,
        hex: /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i,
        rgb: /rgb\((\d+),(\d+),(\d+)\)/,
        reference: /#([a-z0-9\-_]+)/i,
        transforms: /\)\s*,?\s*/,
        whitespace: /\s/g,
        isHex: /^#[a-f0-9]{3,6}$/i,
        isRgb: /^rgb\(/,
        isCss: /[^:]+:[^;]+;?/,
        isBlank: /^(\s+)?$/,
        isNumber: /^[+-]?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i,
        isPercent: /^-?[\d\.]+%$/,
        isImage: /\.(jpg|jpeg|png|gif|svg)(\?[^=]+.*)?/i,
        delimiter: /[\s,]+/,
        hyphen: /([^e])\-/gi,
        pathLetters: /[MLHVCSQTAZ]/gi,
        isPathLetter: /[MLHVCSQTAZ]/i,
        numbersWithDots: /((\d?\.\d+(?:e[+-]?\d+)?)((?:\.\d+(?:e[+-]?\d+)?)+))+/gi,
        dots: /\./g
      }, t.utils = {
        map: function(h, u) {
          for (var b = h.length, k = [], A = 0; A < b; A++) k.push(u(h[A]));
          return k
        },
        filter: function(h, u) {
          for (var b = h.length, k = [], A = 0; A < b; A++) u(h[A]) && k.push(h[A]);
          return k
        },
        filterSVGElements: function(h) {
          return this.filter(h, function(u) {
            return u instanceof w.SVGElement
          })
        }
      }, t.defaults = {
        attrs: {
          "fill-opacity": 1,
          "stroke-opacity": 1,
          "stroke-width": 0,
          "stroke-linejoin": "miter",
          "stroke-linecap": "butt",
          fill: "#000000",
          stroke: "#000000",
          opacity: 1,
          x: 0,
          y: 0,
          cx: 0,
          cy: 0,
          width: 0,
          height: 0,
          r: 0,
          rx: 0,
          ry: 0,
          offset: 0,
          "stop-opacity": 1,
          "stop-color": "#000000",
          "font-size": 16,
          "font-family": "Helvetica, Arial, sans-serif",
          "text-anchor": "start"
        }
      }, t.Color = function(h) {
        var u, b;
        this.r = 0, this.g = 0, this.b = 0, h && ("string" == typeof h ? t.regex.isRgb.test(h) ? (u = t.regex.rgb
          .exec(h.replace(t.regex.whitespace, "")), this.r = parseInt(u[1]), this.g = parseInt(u[2]), this.b =
          parseInt(u[3])) : t.regex.isHex.test(h) && (u = t.regex.hex.exec(4 == (b = h).length ? ["#", b
            .substring(1, 2), b.substring(1, 2), b.substring(2, 3), b.substring(2, 3), b.substring(3, 4), b
            .substring(3, 4)
          ].join("") : b), this.r = parseInt(u[1], 16), this.g = parseInt(u[2], 16), this.b = parseInt(u[3],
          16)) : "object" === $(h) && (this.r = h.r, this.g = h.g, this.b = h.b))
      }, t.extend(t.Color, {
        toString: function() {
          return this.toHex()
        },
        toHex: function() {
          return "#" + d(this.r) + d(this.g) + d(this.b)
        },
        toRgb: function() {
          return "rgb(" + [this.r, this.g, this.b].join() + ")"
        },
        brightness: function() {
          return this.r / 255 * .3 + this.g / 255 * .59 + this.b / 255 * .11
        },
        morph: function(h) {
          return this.destination = new t.Color(h), this
        },
        at: function(h) {
          return this.destination ? new t.Color({
            r: ~~(this.r + (this.destination.r - this.r) * (h = h < 0 ? 0 : h > 1 ? 1 : h)),
            g: ~~(this.g + (this.destination.g - this.g) * h),
            b: ~~(this.b + (this.destination.b - this.b) * h)
          }) : this
        }
      }), t.Color.test = function(h) {
        return t.regex.isHex.test(h += "") || t.regex.isRgb.test(h)
      }, t.Color.isRgb = function(h) {
        return h && "number" == typeof h.r && "number" == typeof h.g && "number" == typeof h.b
      }, t.Color.isColor = function(h) {
        return t.Color.isRgb(h) || t.Color.test(h)
      }, t.Array = function(h, u) {
        0 == (h = (h || []).valueOf()).length && u && (h = u.valueOf()), this.value = this.parse(h)
      }, t.extend(t.Array, {
        toString: function() {
          return this.value.join(" ")
        },
        valueOf: function() {
          return this.value
        },
        parse: function(h) {
          return h = h.valueOf(), Array.isArray(h) ? h : this.split(h)
        }
      }), t.PointArray = function(h, u) {
        t.Array.call(this, h, u || [
          [0, 0]
        ])
      }, t.PointArray.prototype = new t.Array, t.PointArray.prototype.constructor = t.PointArray;
      for (var i = {
          M: function(h, u, b) {
            return u.x = b.x = h[0], u.y = b.y = h[1], ["M", u.x, u.y]
          },
          L: function(h, u) {
            return u.x = h[0], u.y = h[1], ["L", h[0], h[1]]
          },
          H: function(h, u) {
            return u.x = h[0], ["H", h[0]]
          },
          V: function(h, u) {
            return u.y = h[0], ["V", h[0]]
          },
          C: function(h, u) {
            return u.x = h[4], u.y = h[5], ["C", h[0], h[1], h[2], h[3], h[4], h[5]]
          },
          Q: function(h, u) {
            return u.x = h[2], u.y = h[3], ["Q", h[0], h[1], h[2], h[3]]
          },
          S: function(h, u) {
            return u.x = h[2], u.y = h[3], ["S", h[0], h[1], h[2], h[3]]
          },
          Z: function(h, u, b) {
            return u.x = b.x, u.y = b.y, ["Z"]
          }
        }, a = "mlhvqtcsaz".split(""), s = 0, r = a.length; s < r; ++s) i[a[s]] = function(h) {
        return function(u, b, k) {
          if ("H" == h) u[0] = u[0] + b.x;
          else if ("V" == h) u[0] = u[0] + b.y;
          else if ("A" == h) u[5] = u[5] + b.x, u[6] = u[6] + b.y;
          else
            for (var A = 0, S = u.length; A < S; ++A) u[A] = u[A] + (A % 2 ? b.y : b.x);
          if (i && "function" == typeof i[h]) return i[h](u, b, k)
        }
      }(a[s].toUpperCase());
      t.PathArray = function(h, u) {
        t.Array.call(this, h, u || [
          ["M", 0, 0]
        ])
      }, t.PathArray.prototype = new t.Array, t.PathArray.prototype.constructor = t.PathArray, t.extend(t
      .PathArray, {
        toString: function() {
          return function(h) {
            for (var u = 0, b = h.length, k = ""; u < b; u++) k += h[u][0], null != h[u][1] && (k += h[u][1],
              null != h[u][2] && (k += " ", k += h[u][2], null != h[u][3] && (k += " ", k += h[u][3], k +=
                " ", k += h[u][4], null != h[u][5] && (k += " ", k += h[u][5], k += " ", k += h[u][6],
                  null != h[u][7] && (k += " ", k += h[u][7])))));
            return k + " "
          }(this.value)
        },
        move: function(h, u) {
          return this.bbox(), this
        },
        at: function(h) {
          if (!this.destination) return this;
          for (var u = this.value, b = this.destination.value, k = [], A = new t.PathArray, S = 0, C = u
            .length; S < C; S++) {
            k[S] = [u[S][0]];
            for (var L = 1, M = u[S].length; L < M; L++) k[S][L] = u[S][L] + (b[S][L] - u[S][L]) * h;
            "A" === k[S][0] && (k[S][4] = +(0 != k[S][4]), k[S][5] = +(0 != k[S][5]))
          }
          return A.value = k, A
        },
        parse: function(h) {
          if (h instanceof t.PathArray) return h.valueOf();
          var u, b = {
            M: 2,
            L: 2,
            H: 1,
            V: 1,
            C: 6,
            S: 4,
            Q: 4,
            T: 2,
            A: 7,
            Z: 0
          };
          h = "string" == typeof h ? h.replace(t.regex.numbersWithDots, o).replace(t.regex.pathLetters, " $& ")
            .replace(t.regex.hyphen, "$1 -").trim().split(t.regex.delimiter) : h.reduce(function(M, z) {
              return [].concat.call(M, z)
            }, []);
          var k = [],
            A = new t.Point,
            S = new t.Point,
            C = 0,
            L = h.length;
          do {
            t.regex.isPathLetter.test(h[C]) ? (u = h[C], ++C) : "M" == u ? u = "L" : "m" == u && (u = "l"), k
              .push(i[u].call(null, h.slice(C, C += b[u.toUpperCase()]).map(parseFloat), A, S))
          } while (L > C);
          return k
        },
        bbox: function() {
          return t.parser.draw || t.prepare(), t.parser.path.setAttribute("d", this.toString()), t.parser.path
            .getBBox()
        }
      }), t.Number = t.invent({
        create: function(h, u) {
          this.value = 0, this.unit = u || "", "number" == typeof h ? this.value = isNaN(h) ? 0 : isFinite(h) ?
            h : h < 0 ? -34e37 : 34e37 : "string" == typeof h ? (u = h.match(t.regex.numberAndUnit)) && (this
              .value = parseFloat(u[1]), "%" == u[5] ? this.value /= 100 : "s" == u[5] && (this.value *= 1e3),
              this.unit = u[5]) : h instanceof t.Number && (this.value = h.valueOf(), this.unit = h.unit)
        },
        extend: {
          toString: function() {
            return ("%" == this.unit ? ~~(1e8 * this.value) / 1e6 : "s" == this.unit ? this.value / 1e3 : this
              .value) + this.unit
          },
          toJSON: function() {
            return this.toString()
          },
          valueOf: function() {
            return this.value
          },
          plus: function(h) {
            return h = new t.Number(h), new t.Number(this + h, this.unit || h.unit)
          },
          minus: function(h) {
            return h = new t.Number(h), new t.Number(this - h, this.unit || h.unit)
          },
          times: function(h) {
            return h = new t.Number(h), new t.Number(this * h, this.unit || h.unit)
          },
          divide: function(h) {
            return h = new t.Number(h), new t.Number(this / h, this.unit || h.unit)
          },
          to: function(h) {
            var u = new t.Number(this);
            return "string" == typeof h && (u.unit = h), u
          },
          morph: function(h) {
            return this.destination = new t.Number(h), h.relative && (this.destination.value += this.value),
              this
          },
          at: function(h) {
            return this.destination ? new t.Number(this.destination).minus(this).times(h).plus(this) : this
          }
        }
      }), t.Element = t.invent({
        create: function(h) {
          this._stroke = t.defaults.attrs.stroke, this._event = null, this.dom = {}, (this.node = h) && (this
            .type = h.nodeName, this.node.instance = this, this._stroke = h.getAttribute("stroke") || this
            ._stroke)
        },
        extend: {
          x: function(h) {
            return this.attr("x", h)
          },
          y: function(h) {
            return this.attr("y", h)
          },
          cx: function(h) {
            return null == h ? this.x() + this.width() / 2 : this.x(h - this.width() / 2)
          },
          cy: function(h) {
            return null == h ? this.y() + this.height() / 2 : this.y(h - this.height() / 2)
          },
          move: function(h, u) {
            return this.x(h).y(u)
          },
          center: function(h, u) {
            return this.cx(h).cy(u)
          },
          width: function(h) {
            return this.attr("width", h)
          },
          height: function(h) {
            return this.attr("height", h)
          },
          size: function(h, u) {
            var b = g(this, h, u);
            return this.width(new t.Number(b.width)).height(new t.Number(b.height))
          },
          clone: function(h) {
            this.writeDataToDom();
            var u = x(this.node.cloneNode(!0));
            return h ? h.add(u) : this.after(u), u
          },
          remove: function() {
            return this.parent() && this.parent().removeElement(this), this
          },
          replace: function(h) {
            return this.after(h).remove(), h
          },
          addTo: function(h) {
            return h.put(this)
          },
          putIn: function(h) {
            return h.add(this)
          },
          id: function(h) {
            return this.attr("id", h)
          },
          show: function() {
            return this.style("display", "")
          },
          hide: function() {
            return this.style("display", "none")
          },
          visible: function() {
            return "none" != this.style("display")
          },
          toString: function() {
            return this.attr("id")
          },
          classes: function() {
            var h = this.attr("class");
            return null == h ? [] : h.trim().split(t.regex.delimiter)
          },
          hasClass: function(h) {
            return -1 != this.classes().indexOf(h)
          },
          addClass: function(h) {
            if (!this.hasClass(h)) {
              var u = this.classes();
              u.push(h), this.attr("class", u.join(" "))
            }
            return this
          },
          removeClass: function(h) {
            return this.hasClass(h) && this.attr("class", this.classes().filter(function(u) {
              return u != h
            }).join(" ")), this
          },
          toggleClass: function(h) {
            return this.hasClass(h) ? this.removeClass(h) : this.addClass(h)
          },
          reference: function(h) {
            return t.get(this.attr(h))
          },
          parent: function(h) {
            var u = this;
            if (!u.node.parentNode) return null;
            if (u = t.adopt(u.node.parentNode), !h) return u;
            for (; u && u.node instanceof w.SVGElement;) {
              if ("string" == typeof h ? u.matches(h) : u instanceof h) return u;
              if (!u.node.parentNode || "#document" == u.node.parentNode.nodeName) return null;
              u = t.adopt(u.node.parentNode)
            }
          },
          doc: function() {
            return this instanceof t.Doc ? this : this.parent(t.Doc)
          },
          parents: function(h) {
            var u = [],
              b = this;
            do {
              if (!(b = b.parent(h)) || !b.node) break;
              u.push(b)
            } while (b.parent);
            return u
          },
          matches: function(h) {
            return ((u = this.node).matches || u.matchesSelector || u.msMatchesSelector || u
              .mozMatchesSelector || u.webkitMatchesSelector || u.oMatchesSelector).call(u, h);
            var u
          },
          native: function() {
            return this.node
          },
          svg: function(h) {
            var u = e.createElementNS("http://www.w3.org/2000/svg", "svg");
            if (!(h && this instanceof t.Parent)) return u.appendChild(h = e.createElementNS(
              "http://www.w3.org/2000/svg", "svg")), this.writeDataToDom(), h.appendChild(this.node
              .cloneNode(!0)), u.innerHTML.replace(/^<svg>/, "").replace(/<\/svg>$/, "");
            u.innerHTML = "<svg>" + h.replace(/\n/, "").replace(/<([\w:-]+)([^<]+?)\/>/g, "<$1$2></$1>") +
              "</svg>";
            for (var b = 0, k = u.firstChild.childNodes.length; b < k; b++) this.node.appendChild(u.firstChild
              .firstChild);
            return this
          },
          writeDataToDom: function() {
            return (this.each || this.lines) && (this.each ? this : this.lines()).each(function() {
                this.writeDataToDom()
              }), this.node.removeAttribute("svgjs:data"), Object.keys(this.dom).length && this.node
              .setAttribute("svgjs:data", JSON.stringify(this.dom)), this
          },
          setData: function(h) {
            return this.dom = h, this
          },
          is: function(h) {
            return this instanceof h
          }
        }
      }), t.easing = {
        "-": function(h) {
          return h
        },
        "<>": function(h) {
          return -Math.cos(h * Math.PI) / 2 + .5
        },
        ">": function(h) {
          return Math.sin(h * Math.PI / 2)
        },
        "<": function(h) {
          return 1 - Math.cos(h * Math.PI / 2)
        }
      }, t.morph = function(h) {
        return function(u, b) {
          return new t.MorphObj(u, b).at(h)
        }
      }, t.Situation = t.invent({
        create: function(h) {
          this.init = !1, this.reversed = !1, this.reversing = !1, this.duration = new t.Number(h.duration)
            .valueOf(), this.delay = new t.Number(h.delay).valueOf(), this.start = +new Date + this.delay, this
            .finish = this.start + this.duration, this.ease = h.ease, this.loop = 0, this.loops = !1, this
            .animations = {}, this.attrs = {}, this.styles = {}, this.transforms = [], this.once = {}
        }
      }), t.FX = t.invent({
        create: function(h) {
          this._target = h, this.situations = [], this.active = !1, this.situation = null, this.paused = !1,
            this.lastPos = 0, this.pos = 0, this.absPos = 0, this._speed = 1
        },
        extend: {
          animate: function(h, u, b) {
            "object" === $(h) && (u = h.ease, b = h.delay, h = h.duration);
            var k = new t.Situation({
              duration: h || 1e3,
              delay: b || 0,
              ease: t.easing[u || "-"] || u
            });
            return this.queue(k), this
          },
          target: function(h) {
            return h && h instanceof t.Element ? (this._target = h, this) : this._target
          },
          timeToAbsPos: function(h) {
            return (h - this.situation.start) / (this.situation.duration / this._speed)
          },
          absPosToTime: function(h) {
            return this.situation.duration / this._speed * h + this.situation.start
          },
          startAnimFrame: function() {
            this.stopAnimFrame(), this.animationFrame = w.requestAnimationFrame(function() {
              this.step()
            }.bind(this))
          },
          stopAnimFrame: function() {
            w.cancelAnimationFrame(this.animationFrame)
          },
          start: function() {
            return !this.active && this.situation && (this.active = !0, this.startCurrent()), this
          },
          startCurrent: function() {
            return this.situation.start = +new Date + this.situation.delay / this._speed, this.situation
              .finish = this.situation.start + this.situation.duration / this._speed, this.initAnimations()
              .step()
          },
          queue: function(h) {
            return ("function" == typeof h || h instanceof t.Situation) && this.situations.push(h), this
              .situation || (this.situation = this.situations.shift()), this
          },
          dequeue: function() {
            return this.stop(), this.situation = this.situations.shift(), this.situation && (this
              .situation instanceof t.Situation ? this.start() : this.situation.call(this)), this
          },
          initAnimations: function() {
            var h, u = this.situation;
            if (u.init) return this;
            for (var b in u.animations) {
              h = this.target()[b](), Array.isArray(h) || (h = [h]), Array.isArray(u.animations[b]) || (u
                .animations[b] = [u.animations[b]]);
              for (var k = h.length; k--;) u.animations[b][k] instanceof t.Number && (h[k] = new t.Number(h[
                k])), u.animations[b][k] = h[k].morph(u.animations[b][k])
            }
            for (var b in u.attrs) u.attrs[b] = new t.MorphObj(this.target().attr(b), u.attrs[b]);
            for (var b in u.styles) u.styles[b] = new t.MorphObj(this.target().style(b), u.styles[b]);
            return u.initialTransformation = this.target().matrixify(), u.init = !0, this
          },
          clearQueue: function() {
            return this.situations = [], this
          },
          clearCurrent: function() {
            return this.situation = null, this
          },
          stop: function(h, u) {
            var b = this.active;
            return this.active = !1, u && this.clearQueue(), h && this.situation && (!b && this.startCurrent(),
              this.atEnd()), this.stopAnimFrame(), this.clearCurrent()
          },
          after: function(h) {
            var u = this.last();
            return this.target().on("finished.fx", function b(k) {
              k.detail.situation == u && (h.call(this, u), this.off("finished.fx", b))
            }), this._callStart()
          },
          during: function(h) {
            var u = this.last(),
              b = function(k) {
                k.detail.situation == u && h.call(this, k.detail.pos, t.morph(k.detail.pos), k.detail.eased, u)
              };
            return this.target().off("during.fx", b).on("during.fx", b), this.after(function() {
              this.off("during.fx", b)
            }), this._callStart()
          },
          afterAll: function(h) {
            var u = function b(k) {
              h.call(this), this.off("allfinished.fx", b)
            };
            return this.target().off("allfinished.fx", u).on("allfinished.fx", u), this._callStart()
          },
          last: function() {
            return this.situations.length ? this.situations[this.situations.length - 1] : this.situation
          },
          add: function(h, u, b) {
            return this.last()[b || "animations"][h] = u, this._callStart()
          },
          step: function(h) {
            var u, b, k;
            h || (this.absPos = this.timeToAbsPos(+new Date)), !1 !== this.situation.loops ? (u = Math.max(this
              .absPos, 0), b = Math.floor(u), !0 === this.situation.loops || b < this.situation.loops ? (
              this.pos = u - b, k = this.situation.loop, this.situation.loop = b) : (this.absPos = this
              .situation.loops, this.pos = 1, k = this.situation.loop - 1, this.situation.loop = this
              .situation.loops), this.situation.reversing && (this.situation.reversed = this.situation
              .reversed != !!((this.situation.loop - k) % 2))) : (this.absPos = Math.min(this.absPos, 1), this
              .pos = this.absPos), this.pos < 0 && (this.pos = 0), this.situation.reversed && (this.pos = 1 -
              this.pos);
            var A = this.situation.ease(this.pos);
            for (var S in this.situation.once) S > this.lastPos && S <= A && (this.situation.once[S].call(this
              .target(), this.pos, A), delete this.situation.once[S]);
            return this.active && this.target().fire("during", {
              pos: this.pos,
              eased: A,
              fx: this,
              situation: this.situation
            }), this.situation ? (this.eachAt(), 1 == this.pos && !this.situation.reversed || this.situation
              .reversed && 0 == this.pos ? (this.stopAnimFrame(), this.target().fire("finished", {
                  fx: this,
                  situation: this.situation
                }), this.situations.length || (this.target().fire("allfinished"), this.situations.length || (
                  this.target().off(".fx"), this.active = !1)), this.active ? this.dequeue() : this
                .clearCurrent()) : !this.paused && this.active && this.startAnimFrame(), this.lastPos = A,
              this) : this
          },
          eachAt: function() {
            var h, u = this,
              b = this.target(),
              k = this.situation;
            for (var A in k.animations) h = [].concat(k.animations[A]).map(function(L) {
              return "string" != typeof L && L.at ? L.at(k.ease(u.pos), u.pos) : L
            }), b[A].apply(b, h);
            for (var A in k.attrs) h = [A].concat(k.attrs[A]).map(function(M) {
              return "string" != typeof M && M.at ? M.at(k.ease(u.pos), u.pos) : M
            }), b.attr.apply(b, h);
            for (var A in k.styles) h = [A].concat(k.styles[A]).map(function(M) {
              return "string" != typeof M && M.at ? M.at(k.ease(u.pos), u.pos) : M
            }), b.style.apply(b, h);
            if (k.transforms.length) {
              h = k.initialTransformation, A = 0;
              for (var S = k.transforms.length; A < S; A++) {
                var C = k.transforms[A];
                C instanceof t.Matrix ? h = C.relative ? h.multiply((new t.Matrix).morph(C).at(k.ease(this
                  .pos))) : h.morph(C).at(k.ease(this.pos)) : (C.relative || C.undo(h.extract()), h = h
                  .multiply(C.at(k.ease(this.pos))))
              }
              b.matrix(h)
            }
            return this
          },
          once: function(h, u, b) {
            var k = this.last();
            return b || (h = k.ease(h)), k.once[h] = u, this
          },
          _callStart: function() {
            return setTimeout(function() {
              this.start()
            }.bind(this), 0), this
          }
        },
        parent: t.Element,
        construct: {
          animate: function(h, u, b) {
            return (this.fx || (this.fx = new t.FX(this))).animate(h, u, b)
          },
          delay: function(h) {
            return (this.fx || (this.fx = new t.FX(this))).delay(h)
          },
          stop: function(h, u) {
            return this.fx && this.fx.stop(h, u), this
          },
          finish: function() {
            return this.fx && this.fx.finish(), this
          }
        }
      }), t.MorphObj = t.invent({
        create: function(h, u) {
          return t.Color.isColor(u) ? new t.Color(h).morph(u) : t.regex.delimiter.test(h) ? t.regex.pathLetters
            .test(h) ? new t.PathArray(h).morph(u) : new t.Array(h).morph(u) : t.regex.numberAndUnit.test(u) ?
            new t.Number(h).morph(u) : (this.value = h, void(this.destination = u))
        },
        extend: {
          at: function(h, u) {
            return u < 1 ? this.value : this.destination
          },
          valueOf: function() {
            return this.value
          }
        }
      }), t.extend(t.FX, {
        attr: function(h, u, b) {
          if ("object" === $(h))
            for (var k in h) this.attr(k, h[k]);
          else this.add(h, u, "attrs");
          return this
        },
        plot: function(h, u, b, k) {
          return 4 == arguments.length ? this.plot([h, u, b, k]) : this.add("plot", new(this.target()
            .morphArray)(h))
        }
      }), t.Box = t.invent({
        create: function(h, u, b, k) {
          if (!("object" !== $(h) || h instanceof t.Element)) return t.Box.call(this, null != h.left ? h.left :
            h.x, null != h.top ? h.top : h.y, h.width, h.height);
          var A;
          4 == arguments.length && (this.x = h, this.y = u, this.width = b, this.height = k), null == (A = this)
            .x && (A.x = 0, A.y = 0, A.width = 0, A.height = 0), A.w = A.width, A.h = A.height, A.x2 = A.x + A
            .width, A.y2 = A.y + A.height, A.cx = A.x + A.width / 2, A.cy = A.y + A.height / 2
        }
      }), t.BBox = t.invent({
        create: function(h) {
          if (t.Box.apply(this, [].slice.call(arguments)), h instanceof t.Element) {
            var u;
            try {
              if (!e.documentElement.contains) {
                for (var b = h.node; b.parentNode;) b = b.parentNode;
                if (b != e) throw new Error("Element not in the dom")
              }
              u = h.node.getBBox()
            } catch {
              if (h instanceof t.Shape) {
                t.parser.draw || t.prepare();
                var k = h.clone(t.parser.draw.instance).show();
                k && k.node && "function" == typeof k.node.getBBox && (u = k.node.getBBox()), k && "function" ==
                  typeof k.remove && k.remove()
              } else u = {
                x: h.node.clientLeft,
                y: h.node.clientTop,
                width: h.node.clientWidth,
                height: h.node.clientHeight
              }
            }
            t.Box.call(this, u)
          }
        },
        inherit: t.Box,
        parent: t.Element,
        construct: {
          bbox: function() {
            return new t.BBox(this)
          }
        }
      }), t.BBox.prototype.constructor = t.BBox, t.Matrix = t.invent({
        create: function(h) {
          var u = f([1, 0, 0, 1, 0, 0]);
          h = null === h ? u : h instanceof t.Element ? h.matrixify() : "string" == typeof h ? f(h.split(t.regex
              .delimiter).map(parseFloat)) : 6 == arguments.length ? f([].slice.call(arguments)) : Array
            .isArray(h) ? f(h) : h && "object" === $(h) ? h : u;
          for (var b = v.length - 1; b >= 0; --b) this[v[b]] = null != h[v[b]] ? h[v[b]] : u[v[b]]
        },
        extend: {
          extract: function() {
            var h = p(this, 0, 1);
            p(this, 1, 0);
            var u = 180 / Math.PI * Math.atan2(h.y, h.x) - 90;
            return {
              x: this.e,
              y: this.f,
              transformedX: (this.e * Math.cos(u * Math.PI / 180) + this.f * Math.sin(u * Math.PI / 180)) / Math
                .sqrt(this.a * this.a + this.b * this.b),
              transformedY: (this.f * Math.cos(u * Math.PI / 180) + this.e * Math.sin(-u * Math.PI / 180)) /
                Math.sqrt(this.c * this.c + this.d * this.d),
              rotation: u,
              a: this.a,
              b: this.b,
              c: this.c,
              d: this.d,
              e: this.e,
              f: this.f,
              matrix: new t.Matrix(this)
            }
          },
          clone: function() {
            return new t.Matrix(this)
          },
          morph: function(h) {
            return this.destination = new t.Matrix(h), this
          },
          multiply: function(h) {
            return new t.Matrix(this.native().multiply((u = h, u instanceof t.Matrix || (u = new t.Matrix(u)),
              u).native()));
            var u
          },
          inverse: function() {
            return new t.Matrix(this.native().inverse())
          },
          translate: function(h, u) {
            return new t.Matrix(this.native().translate(h || 0, u || 0))
          },
          native: function() {
            for (var h = t.parser.native.createSVGMatrix(), u = v.length - 1; u >= 0; u--) h[v[u]] = this[v[u]];
            return h
          },
          toString: function() {
            return "matrix(" + m(this.a) + "," + m(this.b) + "," + m(this.c) + "," + m(this.d) + "," + m(this
              .e) + "," + m(this.f) + ")"
          }
        },
        parent: t.Element,
        construct: {
          ctm: function() {
            return new t.Matrix(this.node.getCTM())
          },
          screenCTM: function() {
            if (this instanceof t.Nested) {
              var h = this.rect(1, 1),
                u = h.node.getScreenCTM();
              return h.remove(), new t.Matrix(u)
            }
            return new t.Matrix(this.node.getScreenCTM())
          }
        }
      }), t.Point = t.invent({
        create: function(h, u) {
          var b;
          b = Array.isArray(h) ? {
            x: h[0],
            y: h[1]
          } : "object" === $(h) ? {
            x: h.x,
            y: h.y
          } : null != h ? {
            x: h,
            y: u ?? h
          } : {
            x: 0,
            y: 0
          }, this.x = b.x, this.y = b.y
        },
        extend: {
          clone: function() {
            return new t.Point(this)
          },
          morph: function(h, u) {
            return this.destination = new t.Point(h, u), this
          }
        }
      }), t.extend(t.Element, {
        point: function(h, u) {
          return new t.Point(h, u).transform(this.screenCTM().inverse())
        }
      }), t.extend(t.Element, {
        attr: function(h, u, b) {
          if (null == h) {
            for (h = {}, b = (u = this.node.attributes).length - 1; b >= 0; b--) h[u[b].nodeName] = t.regex
              .isNumber.test(u[b].nodeValue) ? parseFloat(u[b].nodeValue) : u[b].nodeValue;
            return h
          }
          if ("object" === $(h))
            for (var k in h) this.attr(k, h[k]);
          else if (null === u) this.node.removeAttribute(h);
          else {
            if (null == u) return null == (u = this.node.getAttribute(h)) ? t.defaults.attrs[h] : t.regex
              .isNumber.test(u) ? parseFloat(u) : u;
            "stroke-width" == h ? this.attr("stroke", parseFloat(u) > 0 ? this._stroke : null) : "stroke" ==
              h && (this._stroke = u), "fill" != h && "stroke" != h || (t.regex.isImage.test(u) && (u = this
                .doc().defs().image(u, 0, 0)), u instanceof t.Image && (u = this.doc().defs().pattern(0, 0,
                function() {
                  this.add(u)
                }))), "number" == typeof u ? u = new t.Number(u) : t.Color.isColor(u) ? u = new t.Color(u) :
              Array.isArray(u) && (u = new t.Array(u)), "leading" == h ? this.leading && this.leading(u) :
              "string" == typeof b ? this.node.setAttributeNS(b, h, u.toString()) : this.node.setAttribute(h, u
                .toString()), !this.rebuild || "font-size" != h && "x" != h || this.rebuild(h, u)
          }
          return this
        }
      }), t.extend(t.Element, {
        transform: function(h, u) {
          var b;
          return "object" !== $(h) ? (b = new t.Matrix(this).extract(), "string" == typeof h ? b[h] : b) : (b =
            new t.Matrix(this), u = !!u || !!h.relative, null != h.a && (b = u ? b.multiply(new t.Matrix(h)) :
              new t.Matrix(h)), this.attr("transform", b))
        }
      }), t.extend(t.Element, {
        untransform: function() {
          return this.attr("transform", null)
        },
        matrixify: function() {
          return (this.attr("transform") || "").split(t.regex.transforms).slice(0, -1).map(function(h) {
            var u = h.trim().split("(");
            return [u[0], u[1].split(t.regex.delimiter).map(function(b) {
              return parseFloat(b)
            })]
          }).reduce(function(h, u) {
            return "matrix" == u[0] ? h.multiply(f(u[1])) : h[u[0]].apply(h, u[1])
          }, new t.Matrix)
        },
        toParent: function(h) {
          if (this == h) return this;
          var u = this.screenCTM(),
            b = h.screenCTM().inverse();
          return this.addTo(h).untransform().transform(b.multiply(u)), this
        },
        toDoc: function() {
          return this.toParent(this.doc())
        }
      }), t.Transformation = t.invent({
        create: function(h, u) {
          if (arguments.length > 1 && "boolean" != typeof u) return this.constructor.call(this, [].slice.call(
            arguments));
          if (Array.isArray(h))
            for (var b = 0, k = this.arguments.length; b < k; ++b) this[this.arguments[b]] = h[b];
          else if (h && "object" === $(h))
            for (b = 0, k = this.arguments.length; b < k; ++b) this[this.arguments[b]] = h[this.arguments[b]];
          this.inversed = !1, !0 === u && (this.inversed = !0)
        }
      }), t.Translate = t.invent({
        parent: t.Matrix,
        inherit: t.Transformation,
        create: function(h, u) {
          this.constructor.apply(this, [].slice.call(arguments))
        },
        extend: {
          arguments: ["transformedX", "transformedY"],
          method: "translate"
        }
      }), t.extend(t.Element, {
        style: function(h, u) {
          if (0 == arguments.length) return this.node.style.cssText || "";
          if (arguments.length < 2)
            if ("object" === $(h))
              for (var b in h) this.style(b, h[b]);
            else {
              if (!t.regex.isCss.test(h)) return this.node.style[l(h)];
              for (h = h.split(/\s*;\s*/).filter(function(k) {
                  return !!k
                }).map(function(k) {
                  return k.split(/\s*:\s*/)
                }); u = h.pop();) this.style(u[0], u[1])
            }
          else this.node.style[l(h)] = null === u || t.regex.isBlank.test(u) ? "" : u;
          return this
        }
      }), t.Parent = t.invent({
        create: function(h) {
          this.constructor.call(this, h)
        },
        inherit: t.Element,
        extend: {
          children: function() {
            return t.utils.map(t.utils.filterSVGElements(this.node.childNodes), function(h) {
              return t.adopt(h)
            })
          },
          add: function(h, u) {
            return null == u ? this.node.appendChild(h.node) : h.node != this.node.childNodes[u] && this.node
              .insertBefore(h.node, this.node.childNodes[u]), this
          },
          put: function(h, u) {
            return this.add(h, u), h
          },
          has: function(h) {
            return this.index(h) >= 0
          },
          index: function(h) {
            return [].slice.call(this.node.childNodes).indexOf(h.node)
          },
          get: function(h) {
            return t.adopt(this.node.childNodes[h])
          },
          first: function() {
            return this.get(0)
          },
          last: function() {
            return this.get(this.node.childNodes.length - 1)
          },
          each: function(h, u) {
            for (var b = this.children(), k = 0, A = b.length; k < A; k++) b[k] instanceof t.Element && h.apply(
              b[k], [k, b]), u && b[k] instanceof t.Container && b[k].each(h, u);
            return this
          },
          removeElement: function(h) {
            return this.node.removeChild(h.node), this
          },
          clear: function() {
            for (; this.node.hasChildNodes();) this.node.removeChild(this.node.lastChild);
            return delete this._defs, this
          },
          defs: function() {
            return this.doc().defs()
          }
        }
      }), t.extend(t.Parent, {
        ungroup: function(h, u) {
          return 0 === u || this instanceof t.Defs || this.node == t.parser.draw || (h = h || (this instanceof t
            .Doc ? this : this.parent(t.Parent)), u = u || 1 / 0, this.each(function() {
            return this instanceof t.Defs ? this : this instanceof t.Parent ? this.ungroup(h, u - 1) :
              this.toParent(h)
          }), this.node.firstChild || this.remove()), this
        },
        flatten: function(h, u) {
          return this.ungroup(h, u)
        }
      }), t.Container = t.invent({
        create: function(h) {
          this.constructor.call(this, h)
        },
        inherit: t.Parent
      }), t.ViewBox = t.invent({
        parent: t.Container,
        construct: {}
      }), ["click", "dblclick", "mousedown", "mouseup", "mouseover", "mouseout", "mousemove", "touchstart",
        "touchmove", "touchleave", "touchend", "touchcancel"
      ].forEach(function(h) {
        t.Element.prototype[h] = function(u) {
          return t.on(this.node, h, u), this
        }
      }), t.listeners = [], t.handlerMap = [], t.listenerId = 0, t.on = function(h, u, b, k, A) {
        var S = b.bind(k || h.instance || h),
          C = (t.handlerMap.indexOf(h) + 1 || t.handlerMap.push(h)) - 1,
          L = u.split(".")[0],
          M = u.split(".")[1] || "*";
        t.listeners[C] = t.listeners[C] || {}, t.listeners[C][L] = t.listeners[C][L] || {}, t.listeners[C][L][M] = t
          .listeners[C][L][M] || {}, b._svgjsListenerId || (b._svgjsListenerId = ++t.listenerId), t.listeners[C][L][
            M
          ][b._svgjsListenerId] = S, h.addEventListener(L, S, A || {
            passive: !1
          })
      }, t.off = function(h, u, b) {
        var k = t.handlerMap.indexOf(h),
          A = u && u.split(".")[0],
          S = u && u.split(".")[1],
          C = "";
        if (-1 != k)
          if (b) {
            if ("function" == typeof b && (b = b._svgjsListenerId), !b) return;
            t.listeners[k][A] && t.listeners[k][A][S || "*"] && (h.removeEventListener(A, t.listeners[k][A][S ||
              "*"][b], !1), delete t.listeners[k][A][S || "*"][b])
          } else if (S && A) {
          if (t.listeners[k][A] && t.listeners[k][A][S]) {
            for (var L in t.listeners[k][A][S]) t.off(h, [A, S].join("."), L);
            delete t.listeners[k][A][S]
          }
        } else if (S)
          for (var M in t.listeners[k])
            for (var C in t.listeners[k][M]) S === C && t.off(h, [M, S].join("."));
        else if (A) {
          if (t.listeners[k][A]) {
            for (var C in t.listeners[k][A]) t.off(h, [A, C].join("."));
            delete t.listeners[k][A]
          }
        } else {
          for (var M in t.listeners[k]) t.off(h, M);
          delete t.listeners[k], delete t.handlerMap[k]
        }
      }, t.extend(t.Element, {
        on: function(h, u, b, k) {
          return t.on(this.node, h, u, b, k), this
        },
        off: function(h, u) {
          return t.off(this.node, h, u), this
        },
        fire: function(h, u) {
          return this.node.dispatchEvent(h instanceof w.Event ? h : h = new t.CustomEvent(h, {
            detail: u,
            cancelable: !0
          })), this._event = h, this
        },
        event: function() {
          return this._event
        }
      }), t.Defs = t.invent({
        create: "defs",
        inherit: t.Container
      }), t.G = t.invent({
        create: "g",
        inherit: t.Container,
        extend: {
          x: function(h) {
            return null == h ? this.transform("x") : this.transform({
              x: h - this.x()
            }, !0)
          }
        },
        construct: {
          group: function() {
            return this.put(new t.G)
          }
        }
      }), t.Doc = t.invent({
        create: function(h) {
          h && ("svg" == (h = "string" == typeof h ? e.getElementById(h) : h).nodeName ? this.constructor.call(
            this, h) : (this.constructor.call(this, t.create("svg")), h.appendChild(this.node), this.size(
            "100%", "100%")), this.namespace().defs())
        },
        inherit: t.Container,
        extend: {
          namespace: function() {
            return this.attr({
              xmlns: t.ns,
              version: "1.1"
            }).attr("xmlns:xlink", t.xlink, t.xmlns).attr("xmlns:svgjs", t.svgjs, t.xmlns)
          },
          defs: function() {
            var h;
            return this._defs || (this._defs = (h = this.node.getElementsByTagName("defs")[0]) ? t.adopt(h) :
              new t.Defs, this.node.appendChild(this._defs.node)), this._defs
          },
          parent: function() {
            return this.node.parentNode && "#document" != this.node.parentNode.nodeName ? this.node.parentNode :
              null
          },
          remove: function() {
            return this.parent() && this.parent().removeChild(this.node), this
          },
          clear: function() {
            for (; this.node.hasChildNodes();) this.node.removeChild(this.node.lastChild);
            return delete this._defs, t.parser.draw && !t.parser.draw.parentNode && this.node.appendChild(t
              .parser.draw), this
          },
          clone: function(h) {
            this.writeDataToDom();
            var u = this.node,
              b = x(u.cloneNode(!0));
            return h ? (h.node || h).appendChild(b.node) : u.parentNode.insertBefore(b.node, u.nextSibling), b
          }
        }
      }), t.extend(t.Element, {}), t.Gradient = t.invent({
        create: function(h) {
          this.constructor.call(this, t.create(h + "Gradient")), this.type = h
        },
        inherit: t.Container,
        extend: {
          at: function(h, u, b) {
            return this.put(new t.Stop).update(h, u, b)
          },
          update: function(h) {
            return this.clear(), "function" == typeof h && h.call(this, this), this
          },
          fill: function() {
            return "url(#" + this.id() + ")"
          },
          toString: function() {
            return this.fill()
          },
          attr: function(h, u, b) {
            return "transform" == h && (h = "gradientTransform"), t.Container.prototype.attr.call(this, h, u, b)
          }
        },
        construct: {
          gradient: function(h, u) {
            return this.defs().gradient(h, u)
          }
        }
      }), t.extend(t.Gradient, t.FX, {
        from: function(h, u) {
          return this.attr("radial" == (this._target || this).type ? {
            fx: new t.Number(h),
            fy: new t.Number(u)
          } : {
            x1: new t.Number(h),
            y1: new t.Number(u)
          })
        },
        to: function(h, u) {
          return this.attr("radial" == (this._target || this).type ? {
            cx: new t.Number(h),
            cy: new t.Number(u)
          } : {
            x2: new t.Number(h),
            y2: new t.Number(u)
          })
        }
      }), t.extend(t.Defs, {
        gradient: function(h, u) {
          return this.put(new t.Gradient(h)).update(u)
        }
      }), t.Stop = t.invent({
        create: "stop",
        inherit: t.Element,
        extend: {
          update: function(h) {
            return ("number" == typeof h || h instanceof t.Number) && (h = {
              offset: arguments[0],
              color: arguments[1],
              opacity: arguments[2]
            }), null != h.opacity && this.attr("stop-opacity", h.opacity), null != h.color && this.attr(
              "stop-color", h.color), null != h.offset && this.attr("offset", new t.Number(h.offset)), this
          }
        }
      }), t.Pattern = t.invent({
        create: "pattern",
        inherit: t.Container,
        extend: {
          fill: function() {
            return "url(#" + this.id() + ")"
          },
          update: function(h) {
            return this.clear(), "function" == typeof h && h.call(this, this), this
          },
          toString: function() {
            return this.fill()
          },
          attr: function(h, u, b) {
            return "transform" == h && (h = "patternTransform"), t.Container.prototype.attr.call(this, h, u, b)
          }
        },
        construct: {
          pattern: function(h, u, b) {
            return this.defs().pattern(h, u, b)
          }
        }
      }), t.extend(t.Defs, {
        pattern: function(h, u, b) {
          return this.put(new t.Pattern).update(b).attr({
            x: 0,
            y: 0,
            width: h,
            height: u,
            patternUnits: "userSpaceOnUse"
          })
        }
      }), t.Shape = t.invent({
        create: function(h) {
          this.constructor.call(this, h)
        },
        inherit: t.Element
      }), t.Symbol = t.invent({
        create: "symbol",
        inherit: t.Container,
        construct: {
          symbol: function() {
            return this.put(new t.Symbol)
          }
        }
      }), t.Use = t.invent({
        create: "use",
        inherit: t.Shape,
        extend: {
          element: function(h, u) {
            return this.attr("href", (u || "") + "#" + h, t.xlink)
          }
        },
        construct: {
          use: function(h, u) {
            return this.put(new t.Use).element(h, u)
          }
        }
      }), t.Rect = t.invent({
        create: "rect",
        inherit: t.Shape,
        construct: {
          rect: function(h, u) {
            return this.put(new t.Rect).size(h, u)
          }
        }
      }), t.Circle = t.invent({
        create: "circle",
        inherit: t.Shape,
        construct: {
          circle: function(h) {
            return this.put(new t.Circle).rx(new t.Number(h).divide(2)).move(0, 0)
          }
        }
      }), t.extend(t.Circle, t.FX, {
        rx: function(h) {
          return this.attr("r", h)
        },
        ry: function(h) {
          return this.rx(h)
        }
      }), t.Ellipse = t.invent({
        create: "ellipse",
        inherit: t.Shape,
        construct: {
          ellipse: function(h, u) {
            return this.put(new t.Ellipse).size(h, u).move(0, 0)
          }
        }
      }), t.extend(t.Ellipse, t.Rect, t.FX, {
        rx: function(h) {
          return this.attr("rx", h)
        },
        ry: function(h) {
          return this.attr("ry", h)
        }
      }), t.extend(t.Circle, t.Ellipse, {
        x: function(h) {
          return null == h ? this.cx() - this.rx() : this.cx(h + this.rx())
        },
        y: function(h) {
          return null == h ? this.cy() - this.ry() : this.cy(h + this.ry())
        },
        cx: function(h) {
          return null == h ? this.attr("cx") : this.attr("cx", h)
        },
        cy: function(h) {
          return null == h ? this.attr("cy") : this.attr("cy", h)
        },
        width: function(h) {
          return null == h ? 2 * this.rx() : this.rx(new t.Number(h).divide(2))
        },
        height: function(h) {
          return null == h ? 2 * this.ry() : this.ry(new t.Number(h).divide(2))
        },
        size: function(h, u) {
          var b = g(this, h, u);
          return this.rx(new t.Number(b.width).divide(2)).ry(new t.Number(b.height).divide(2))
        }
      }), t.Line = t.invent({
        create: "line",
        inherit: t.Shape,
        extend: {
          array: function() {
            return new t.PointArray([
              [this.attr("x1"), this.attr("y1")],
              [this.attr("x2"), this.attr("y2")]
            ])
          },
          plot: function(h, u, b, k) {
            return null == h ? this.array() : (h = void 0 !== u ? {
              x1: h,
              y1: u,
              x2: b,
              y2: k
            } : new t.PointArray(h).toLine(), this.attr(h))
          },
          move: function(h, u) {
            return this.attr(this.array().move(h, u).toLine())
          },
          size: function(h, u) {
            var b = g(this, h, u);
            return this.attr(this.array().size(b.width, b.height).toLine())
          }
        },
        construct: {
          line: function(h, u, b, k) {
            return t.Line.prototype.plot.apply(this.put(new t.Line), null != h ? [h, u, b, k] : [0, 0, 0, 0])
          }
        }
      }), t.Polyline = t.invent({
        create: "polyline",
        inherit: t.Shape,
        construct: {
          polyline: function(h) {
            return this.put(new t.Polyline).plot(h || new t.PointArray)
          }
        }
      }), t.Polygon = t.invent({
        create: "polygon",
        inherit: t.Shape,
        construct: {
          polygon: function(h) {
            return this.put(new t.Polygon).plot(h || new t.PointArray)
          }
        }
      }), t.extend(t.Polyline, t.Polygon, {
        array: function() {
          return this._array || (this._array = new t.PointArray(this.attr("points")))
        },
        plot: function(h) {
          return null == h ? this.array() : this.clear().attr("points", "string" == typeof h ? h : this._array =
            new t.PointArray(h))
        },
        clear: function() {
          return delete this._array, this
        },
        move: function(h, u) {
          return this.attr("points", this.array().move(h, u))
        },
        size: function(h, u) {
          var b = g(this, h, u);
          return this.attr("points", this.array().size(b.width, b.height))
        }
      }), t.extend(t.Line, t.Polyline, t.Polygon, {
        morphArray: t.PointArray,
        x: function(h) {
          return null == h ? this.bbox().x : this.move(h, this.bbox().y)
        },
        y: function(h) {
          return null == h ? this.bbox().y : this.move(this.bbox().x, h)
        },
        width: function(h) {
          var u = this.bbox();
          return null == h ? u.width : this.size(h, u.height)
        },
        height: function(h) {
          var u = this.bbox();
          return null == h ? u.height : this.size(u.width, h)
        }
      }), t.Path = t.invent({
        create: "path",
        inherit: t.Shape,
        extend: {
          morphArray: t.PathArray,
          array: function() {
            return this._array || (this._array = new t.PathArray(this.attr("d")))
          },
          plot: function(h) {
            return null == h ? this.array() : this.clear().attr("d", "string" == typeof h ? h : this._array =
              new t.PathArray(h))
          },
          clear: function() {
            return delete this._array, this
          }
        },
        construct: {
          path: function(h) {
            return this.put(new t.Path).plot(h || new t.PathArray)
          }
        }
      }), t.Image = t.invent({
        create: "image",
        inherit: t.Shape,
        extend: {
          load: function(h) {
            if (!h) return this;
            var u = this,
              b = new w.Image;
            return t.on(b, "load", function() {
              t.off(b);
              var k = u.parent(t.Pattern);
              null !== k && (0 == u.width() && 0 == u.height() && u.size(b.width, b.height), k && 0 == k
                .width() && 0 == k.height() && k.size(u.width(), u.height()), "function" == typeof u
                ._loaded && u._loaded.call(u, {
                  width: b.width,
                  height: b.height,
                  ratio: b.width / b.height,
                  url: h
                }))
            }), t.on(b, "error", function(k) {
              t.off(b), "function" == typeof u._error && u._error.call(u, k)
            }), this.attr("href", b.src = this.src = h, t.xlink)
          },
          loaded: function(h) {
            return this._loaded = h, this
          },
          error: function(h) {
            return this._error = h, this
          }
        },
        construct: {
          image: function(h, u, b) {
            return this.put(new t.Image).load(h).size(u || 0, b || u || 0)
          }
        }
      }), t.Text = t.invent({
        create: function() {
          this.constructor.call(this, t.create("text")), this.dom.leading = new t.Number(1.3), this._rebuild = !
            0, this._build = !1, this.attr("font-family", t.defaults.attrs["font-family"])
        },
        inherit: t.Shape,
        extend: {
          x: function(h) {
            return null == h ? this.attr("x") : this.attr("x", h)
          },
          text: function(h) {
            if (void 0 === h) {
              h = "";
              for (var u = this.node.childNodes, b = 0, k = u.length; b < k; ++b) 0 != b && 3 != u[b]
                .nodeType && 1 == t.adopt(u[b]).dom.newLined && (h += "\n"), h += u[b].textContent;
              return h
            }
            if (this.clear().build(!0), "function" == typeof h) h.call(this, this);
            else {
              b = 0;
              for (var A = (h = h.split("\n")).length; b < A; b++) this.tspan(h[b]).newLine()
            }
            return this.build(!1).rebuild()
          },
          size: function(h) {
            return this.attr("font-size", h).rebuild()
          },
          leading: function(h) {
            return null == h ? this.dom.leading : (this.dom.leading = new t.Number(h), this.rebuild())
          },
          lines: function() {
            var h = (this.textPath && this.textPath() || this).node,
              u = t.utils.map(t.utils.filterSVGElements(h.childNodes), function(b) {
                return t.adopt(b)
              });
            return new t.Set(u)
          },
          rebuild: function(h) {
            if ("boolean" == typeof h && (this._rebuild = h), this._rebuild) {
              var u = this,
                b = 0,
                k = this.dom.leading * new t.Number(this.attr("font-size"));
              this.lines().each(function() {
                this.dom.newLined && (u.textPath() || this.attr("x", u.attr("x")), "\n" == this.text() ?
                  b += k : (this.attr("dy", k + b), b = 0))
              }), this.fire("rebuild")
            }
            return this
          },
          build: function(h) {
            return this._build = !!h, this
          },
          setData: function(h) {
            return this.dom = h, this.dom.leading = new t.Number(h.leading || 1.3), this
          }
        },
        construct: {
          text: function(h) {
            return this.put(new t.Text).text(h)
          },
          plain: function(h) {
            return this.put(new t.Text).plain(h)
          }
        }
      }), t.Tspan = t.invent({
        create: "tspan",
        inherit: t.Shape,
        extend: {
          text: function(h) {
            return null == h ? this.node.textContent + (this.dom.newLined ? "\n" : "") : ("function" ==
              typeof h ? h.call(this, this) : this.plain(h), this)
          },
          dx: function(h) {
            return this.attr("dx", h)
          },
          dy: function(h) {
            return this.attr("dy", h)
          },
          newLine: function() {
            var h = this.parent(t.Text);
            return this.dom.newLined = !0, this.dy(h.dom.leading * h.attr("font-size")).attr("x", h.x())
          }
        }
      }), t.extend(t.Text, t.Tspan, {
        plain: function(h) {
          return !1 === this._build && this.clear(), this.node.appendChild(e.createTextNode(h)), this
        },
        tspan: function(h) {
          var u = (this.textPath && this.textPath() || this).node,
            b = new t.Tspan;
          return !1 === this._build && this.clear(), u.appendChild(b.node), b.text(h)
        },
        clear: function() {
          for (var h = (this.textPath && this.textPath() || this).node; h.hasChildNodes();) h.removeChild(h
            .lastChild);
          return this
        },
        length: function() {
          return this.node.getComputedTextLength()
        }
      }), t.TextPath = t.invent({
        create: "textPath",
        inherit: t.Parent,
        parent: t.Text,
        construct: {
          morphArray: t.PathArray,
          array: function() {
            var h = this.track();
            return h ? h.array() : null
          },
          plot: function(h) {
            var u = this.track(),
              b = null;
            return u && (b = u.plot(h)), null == h ? b : this
          },
          track: function() {
            var h = this.textPath();
            if (h) return h.reference("href")
          },
          textPath: function() {
            if (this.node.firstChild && "textPath" == this.node.firstChild.nodeName) return t.adopt(this.node
              .firstChild)
          }
        }
      }), t.Nested = t.invent({
        create: function() {
          this.constructor.call(this, t.create("svg")), this.style("overflow", "visible")
        },
        inherit: t.Container,
        construct: {
          nested: function() {
            return this.put(new t.Nested)
          }
        }
      });
      var n = {
        stroke: ["color", "width", "opacity", "linecap", "linejoin", "miterlimit", "dasharray", "dashoffset"],
        fill: ["color", "opacity", "rule"],
        prefix: function(h, u) {
          return "color" == u ? h : h + "-" + u
        }
      };

      function o(h, u, b, k) {
        return b + k.replace(t.regex.dots, " .")
      }

      function l(h) {
        return h.toLowerCase().replace(/-(.)/g, function(u, b) {
          return b.toUpperCase()
        })
      }

      function c(h) {
        return h.charAt(0).toUpperCase() + h.slice(1)
      }

      function d(h) {
        var u = h.toString(16);
        return 1 == u.length ? "0" + u : u
      }

      function g(h, u, b) {
        if (null == u || null == b) {
          var k = h.bbox();
          null == u ? u = k.width / k.height * b : null == b && (b = k.height / k.width * u)
        }
        return {
          width: u,
          height: b
        }
      }

      function p(h, u, b) {
        return {
          x: u * h.a + b * h.c + 0,
          y: u * h.b + b * h.d + 0
        }
      }

      function f(h) {
        return {
          a: h[0],
          b: h[1],
          c: h[2],
          d: h[3],
          e: h[4],
          f: h[5]
        }
      }

      function x(h) {
        for (var u = h.childNodes.length - 1; u >= 0; u--) h.childNodes[u] instanceof w.SVGElement && x(h.childNodes[
          u]);
        return t.adopt(h).id(t.eid(h.nodeName))
      }

      function m(h) {
        return Math.abs(h) > 1e-37 ? h : 0
      } ["fill", "stroke"].forEach(function(h) {
        var u = {};
        u[h] = function(b) {
          if (void 0 === b) return this;
          if ("string" == typeof b || t.Color.isRgb(b) || b && "function" == typeof b.fill) this.attr(h, b);
          else
            for (var k = n[h].length - 1; k >= 0; k--) null != b[n[h][k]] && this.attr(n.prefix(h, n[h][k]), b[
              n[h][k]]);
          return this
        }, t.extend(t.Element, t.FX, u)
      }), t.extend(t.Element, t.FX, {
        translate: function(h, u) {
          return this.transform({
            x: h,
            y: u
          })
        },
        matrix: function(h) {
          return this.attr("transform", new t.Matrix(6 == arguments.length ? [].slice.call(arguments) : h))
        },
        opacity: function(h) {
          return this.attr("opacity", h)
        },
        dx: function(h) {
          return this.x(new t.Number(h).plus(this instanceof t.FX ? 0 : this.x()), !0)
        },
        dy: function(h) {
          return this.y(new t.Number(h).plus(this instanceof t.FX ? 0 : this.y()), !0)
        }
      }), t.extend(t.Path, {
        length: function() {
          return this.node.getTotalLength()
        },
        pointAt: function(h) {
          return this.node.getPointAtLength(h)
        }
      }), t.Set = t.invent({
        create: function(h) {
          Array.isArray(h) ? this.members = h : this.clear()
        },
        extend: {
          add: function() {
            for (var h = [].slice.call(arguments), u = 0, b = h.length; u < b; u++) this.members.push(h[u]);
            return this
          },
          remove: function(h) {
            var u = this.index(h);
            return u > -1 && this.members.splice(u, 1), this
          },
          each: function(h) {
            for (var u = 0, b = this.members.length; u < b; u++) h.apply(this.members[u], [u, this.members]);
            return this
          },
          clear: function() {
            return this.members = [], this
          },
          length: function() {
            return this.members.length
          },
          has: function(h) {
            return this.index(h) >= 0
          },
          index: function(h) {
            return this.members.indexOf(h)
          },
          get: function(h) {
            return this.members[h]
          },
          first: function() {
            return this.get(0)
          },
          last: function() {
            return this.get(this.members.length - 1)
          },
          valueOf: function() {
            return this.members
          }
        },
        construct: {
          set: function(h) {
            return new t.Set(h)
          }
        }
      }), t.FX.Set = t.invent({
        create: function(h) {
          this.set = h
        }
      }), t.Set.inherit = function() {
        var h = [];
        for (var u in t.Shape.prototype) "function" == typeof t.Shape.prototype[u] && "function" != typeof t.Set
          .prototype[u] && h.push(u);
        for (var u in h.forEach(function(k) {
            t.Set.prototype[k] = function() {
              for (var A = 0, S = this.members.length; A < S; A++) this.members[A] && "function" ==
                typeof this.members[A][k] && this.members[A][k].apply(this.members[A], arguments);
              return "animate" == k ? this.fx || (this.fx = new t.FX.Set(this)) : this
            }
          }), h = [], t.FX.prototype) "function" == typeof t.FX.prototype[u] && "function" != typeof t.FX.Set
          .prototype[u] && h.push(u);
        h.forEach(function(b) {
          t.FX.Set.prototype[b] = function() {
            for (var k = 0, A = this.set.members.length; k < A; k++) this.set.members[k].fx[b].apply(this.set
              .members[k].fx, arguments);
            return this
          }
        })
      }, t.extend(t.Element, {}), t.extend(t.Element, {
        remember: function(h, u) {
          if ("object" === $(arguments[0]))
            for (var b in h) this.remember(b, h[b]);
          else {
            if (1 == arguments.length) return this.memory()[h];
            this.memory()[h] = u
          }
          return this
        },
        forget: function() {
          if (0 == arguments.length) this._memory = {};
          else
            for (var h = arguments.length - 1; h >= 0; h--) delete this.memory()[arguments[h]];
          return this
        },
        memory: function() {
          return this._memory || (this._memory = {})
        }
      }), t.get = function(h) {
        var u = e.getElementById(function(b) {
          var k = (b || "").toString().match(t.regex.reference);
          if (k) return k[1]
        }(h) || h);
        return t.adopt(u)
      }, t.select = function(h, u) {
        return new t.Set(t.utils.map((u || e).querySelectorAll(h), function(b) {
          return t.adopt(b)
        }))
      }, t.extend(t.Parent, {
        select: function(h) {
          return t.select(h, this.node)
        }
      });
      var v = "abcdef".split("");
      if ("function" != typeof w.CustomEvent) {
        var y = function(h, u) {
          u = u || {
            bubbles: !1,
            cancelable: !1,
            detail: void 0
          };
          var b = e.createEvent("CustomEvent");
          return b.initCustomEvent(h, u.bubbles, u.cancelable, u.detail), b
        };
        y.prototype = w.Event.prototype, t.CustomEvent = y
      } else t.CustomEvent = w.CustomEvent;
      return t
    }, "function" == typeof define && define.amd ? define(function() {
      return Ae(le, le.document)
    }) : "object" === (typeof exports > "u" ? "undefined" : $(exports)) && typeof module < "u" ? module.exports = le
    .document ? Ae(le, le.document) : function(w) {
      return Ae(w, w.document)
    } : le.SVG = Ae(le, le.document),
    /*! svg.filter.js - v2.0.2 - 2016-02-24
     * https://github.com/wout/svg.filter.js
     * Copyright (c) 2016 Wout Fierens; Licensed MIT */
    function() {
      SVG.Filter = SVG.invent({
        create: "filter",
        inherit: SVG.Parent,
        extend: {
          source: "SourceGraphic",
          sourceAlpha: "SourceAlpha",
          background: "BackgroundImage",
          backgroundAlpha: "BackgroundAlpha",
          fill: "FillPaint",
          stroke: "StrokePaint",
          autoSetIn: !0,
          put: function(r, n) {
            return this.add(r, n), !r.attr("in") && this.autoSetIn && r.attr("in", this.source), r.attr(
              "result") || r.attr("result", r), r
          },
          blend: function(r, n, o) {
            return this.put(new SVG.BlendEffect(r, n, o))
          },
          colorMatrix: function(r, n) {
            return this.put(new SVG.ColorMatrixEffect(r, n))
          },
          convolveMatrix: function(r) {
            return this.put(new SVG.ConvolveMatrixEffect(r))
          },
          componentTransfer: function(r) {
            return this.put(new SVG.ComponentTransferEffect(r))
          },
          composite: function(r, n, o) {
            return this.put(new SVG.CompositeEffect(r, n, o))
          },
          flood: function(r, n) {
            return this.put(new SVG.FloodEffect(r, n))
          },
          offset: function(r, n) {
            return this.put(new SVG.OffsetEffect(r, n))
          },
          image: function(r) {
            return this.put(new SVG.ImageEffect(r))
          },
          merge: function() {
            var r = [void 0];
            for (var n in arguments) r.push(arguments[n]);
            return this.put(new(SVG.MergeEffect.bind.apply(SVG.MergeEffect, r)))
          },
          gaussianBlur: function(r, n) {
            return this.put(new SVG.GaussianBlurEffect(r, n))
          },
          morphology: function(r, n) {
            return this.put(new SVG.MorphologyEffect(r, n))
          },
          diffuseLighting: function(r, n, o) {
            return this.put(new SVG.DiffuseLightingEffect(r, n, o))
          },
          displacementMap: function(r, n, o, l, c) {
            return this.put(new SVG.DisplacementMapEffect(r, n, o, l, c))
          },
          specularLighting: function(r, n, o, l) {
            return this.put(new SVG.SpecularLightingEffect(r, n, o, l))
          },
          tile: function() {
            return this.put(new SVG.TileEffect)
          },
          turbulence: function(r, n, o, l, c) {
            return this.put(new SVG.TurbulenceEffect(r, n, o, l, c))
          },
          toString: function() {
            return "url(#" + this.attr("id") + ")"
          }
        }
      }), SVG.extend(SVG.Defs, {
        filter: function(r) {
          var n = this.put(new SVG.Filter);
          return "function" == typeof r && r.call(n, n), n
        }
      }), SVG.extend(SVG.Container, {
        filter: function(r) {
          return this.defs().filter(r)
        }
      }), SVG.extend(SVG.Element, SVG.G, SVG.Nested, {
        filter: function(r) {
          return this.filterer = r instanceof SVG.Element ? r : this.doc().filter(r), this.doc() && this
            .filterer.doc() !== this.doc() && this.doc().defs().add(this.filterer), this.attr("filter", this
              .filterer), this.filterer
        },
        unfilter: function(r) {
          return this.filterer && !0 === r && this.filterer.remove(), delete this.filterer, this.attr("filter",
            null)
        }
      }), SVG.Effect = SVG.invent({
        create: function() {
          this.constructor.call(this)
        },
        inherit: SVG.Element,
        extend: {
          in: function(r) {
            return null == r ? this.parent() && this.parent().select('[result="' + this.attr("in") + '"]').get(
              0) || this.attr("in") : this.attr("in", r)
          },
          result: function(r) {
            return null == r ? this.attr("result") : this.attr("result", r)
          },
          toString: function() {
            return this.result()
          }
        }
      }), SVG.ParentEffect = SVG.invent({
        create: function() {
          this.constructor.call(this)
        },
        inherit: SVG.Parent,
        extend: {
          in: function(r) {
            return null == r ? this.parent() && this.parent().select('[result="' + this.attr("in") + '"]').get(
              0) || this.attr("in") : this.attr("in", r)
          },
          result: function(r) {
            return null == r ? this.attr("result") : this.attr("result", r)
          },
          toString: function() {
            return this.result()
          }
        }
      });
      var w = {
        blend: function(r, n) {
          return this.parent() && this.parent().blend(this, r, n)
        },
        colorMatrix: function(r, n) {
          return this.parent() && this.parent().colorMatrix(r, n).in(this)
        },
        convolveMatrix: function(r) {
          return this.parent() && this.parent().convolveMatrix(r).in(this)
        },
        componentTransfer: function(r) {
          return this.parent() && this.parent().componentTransfer(r).in(this)
        },
        composite: function(r, n) {
          return this.parent() && this.parent().composite(this, r, n)
        },
        flood: function(r, n) {
          return this.parent() && this.parent().flood(r, n)
        },
        offset: function(r, n) {
          return this.parent() && this.parent().offset(r, n).in(this)
        },
        image: function(r) {
          return this.parent() && this.parent().image(r)
        },
        merge: function() {
          return this.parent() && this.parent().merge.apply(this.parent(), [this].concat(arguments))
        },
        gaussianBlur: function(r, n) {
          return this.parent() && this.parent().gaussianBlur(r, n).in(this)
        },
        morphology: function(r, n) {
          return this.parent() && this.parent().morphology(r, n).in(this)
        },
        diffuseLighting: function(r, n, o) {
          return this.parent() && this.parent().diffuseLighting(r, n, o).in(this)
        },
        displacementMap: function(r, n, o, l) {
          return this.parent() && this.parent().displacementMap(this, r, n, o, l)
        },
        specularLighting: function(r, n, o, l) {
          return this.parent() && this.parent().specularLighting(r, n, o, l).in(this)
        },
        tile: function() {
          return this.parent() && this.parent().tile().in(this)
        },
        turbulence: function(r, n, o, l, c) {
          return this.parent() && this.parent().turbulence(r, n, o, l, c).in(this)
        }
      };
      SVG.extend(SVG.Effect, w), SVG.extend(SVG.ParentEffect, w), SVG.ChildEffect = SVG.invent({
        create: function() {
          this.constructor.call(this)
        },
        inherit: SVG.Element,
        extend: {
          in: function(r) {
            this.attr("in", r)
          }
        }
      });
      var e = {
          blend: function(r, n, o) {
            this.attr({
              in: r,
              in2: n,
              mode: o || "normal"
            })
          },
          colorMatrix: function(r, n) {
            "matrix" == r && (n = a(n)), this.attr({
              type: r,
              values: void 0 === n ? null : n
            })
          },
          convolveMatrix: function(r) {
            r = a(r), this.attr({
              order: Math.sqrt(r.split(" ").length),
              kernelMatrix: r
            })
          },
          composite: function(r, n, o) {
            this.attr({
              in: r,
              in2: n,
              operator: o
            })
          },
          flood: function(r, n) {
            this.attr("flood-color", r), null != n && this.attr("flood-opacity", n)
          },
          offset: function(r, n) {
            this.attr({
              dx: r,
              dy: n
            })
          },
          image: function(r) {
            this.attr("href", r, SVG.xlink)
          },
          displacementMap: function(r, n, o, l, c) {
            this.attr({
              in: r,
              in2: n,
              scale: o,
              xChannelSelector: l,
              yChannelSelector: c
            })
          },
          gaussianBlur: function(r, n) {
            this.attr("stdDeviation", null != r || null != n ? function(o) {
              if (!Array.isArray(o)) return o;
              for (var l = 0, c = o.length, d = []; l < c; l++) d.push(o[l]);
              return d.join(" ")
            }(Array.prototype.slice.call(arguments)) : "0 0")
          },
          morphology: function(r, n) {
            this.attr({
              operator: r,
              radius: n
            })
          },
          tile: function() {},
          turbulence: function(r, n, o, l, c) {
            this.attr({
              numOctaves: n,
              seed: o,
              stitchTiles: l,
              baseFrequency: r,
              type: c
            })
          }
        },
        t = {
          merge: function() {
            var r;
            if (arguments[0] instanceof SVG.Set) {
              var n = this;
              arguments[0].each(function(l) {
                this instanceof SVG.MergeNode ? n.put(this) : (this instanceof SVG.Effect || this instanceof SVG
                  .ParentEffect) && n.put(new SVG.MergeNode(this))
              })
            } else {
              r = Array.isArray(arguments[0]) ? arguments[0] : arguments;
              for (var o = 0; o < r.length; o++) r[o] instanceof SVG.MergeNode ? this.put(r[o]) : this.put(new SVG
                .MergeNode(r[o]))
            }
          },
          componentTransfer: function(r) {
            if (this.rgb = new SVG.Set, ["r", "g", "b", "a"].forEach(function(o) {
                this[o] = new(SVG["Func" + o.toUpperCase()])("identity"), this.rgb.add(this[o]), this.node
                  .appendChild(this[o].node)
              }.bind(this)), r)
              for (var n in r.rgb && (["r", "g", "b"].forEach(function(o) {
                  this[o].attr(r.rgb)
                }.bind(this)), delete r.rgb), r) this[n].attr(r[n])
          },
          diffuseLighting: function(r, n, o) {
            this.attr({
              surfaceScale: r,
              diffuseConstant: n,
              kernelUnitLength: o
            })
          },
          specularLighting: function(r, n, o, l) {
            this.attr({
              surfaceScale: r,
              diffuseConstant: n,
              specularExponent: o,
              kernelUnitLength: l
            })
          }
        },
        i = {
          distantLight: function(r, n) {
            this.attr({
              azimuth: r,
              elevation: n
            })
          },
          pointLight: function(r, n, o) {
            this.attr({
              x: r,
              y: n,
              z: o
            })
          },
          spotLight: function(r, n, o, l, c, d) {
            this.attr({
              x: r,
              y: n,
              z: o,
              pointsAtX: l,
              pointsAtY: c,
              pointsAtZ: d
            })
          },
          mergeNode: function(r) {
            this.attr("in", r)
          }
        };

      function a(r) {
        return Array.isArray(r) && (r = new SVG.Array(r)), r.toString().replace(/^\s+/, "").replace(/\s+$/, "")
          .replace(/\s+/g, " ")
      }

      function s() {
        var r = function() {};
        for (var n in "function" == typeof arguments[arguments.length - 1] && (r = arguments[arguments.length - 1],
            Array.prototype.splice.call(arguments, arguments.length - 1, 1)), arguments)
          for (var o in arguments[n]) r(arguments[n][o], o, arguments[n])
      } ["r", "g", "b", "a"].forEach(function(r) {
        i["Func" + r.toUpperCase()] = function(n) {
          switch (this.attr("type", n), n) {
            case "table":
              this.attr("tableValues", arguments[1]);
              break;
            case "linear":
              this.attr("slope", arguments[1]), this.attr("intercept", arguments[2]);
              break;
            case "gamma":
              this.attr("amplitude", arguments[1]), this.attr("exponent", arguments[2]), this.attr("offset",
                arguments[2])
          }
        }
      }), s(e, function(r, n) {
        var o = n.charAt(0).toUpperCase() + n.slice(1);
        SVG[o + "Effect"] = SVG.invent({
          create: function() {
            this.constructor.call(this, SVG.create("fe" + o)), r.apply(this, arguments), this.result(this
              .attr("id") + "Out")
          },
          inherit: SVG.Effect,
          extend: {}
        })
      }), s(t, function(r, n) {
        var o = n.charAt(0).toUpperCase() + n.slice(1);
        SVG[o + "Effect"] = SVG.invent({
          create: function() {
            this.constructor.call(this, SVG.create("fe" + o)), r.apply(this, arguments), this.result(this
              .attr("id") + "Out")
          },
          inherit: SVG.ParentEffect,
          extend: {}
        })
      }), s(i, function(r, n) {
        var o = n.charAt(0).toUpperCase() + n.slice(1);
        SVG[o] = SVG.invent({
          create: function() {
            this.constructor.call(this, SVG.create("fe" + o)), r.apply(this, arguments)
          },
          inherit: SVG.ChildEffect,
          extend: {}
        })
      }), SVG.extend(SVG.MergeEffect, {
        in: function(r) {
          return r instanceof SVG.MergeNode ? this.add(r, 0) : this.add(new SVG.MergeNode(r), 0), this
        }
      }), SVG.extend(SVG.CompositeEffect, SVG.BlendEffect, SVG.DisplacementMapEffect, {
        in2: function(r) {
          return null == r ? this.parent() && this.parent().select('[result="' + this.attr("in2") + '"]').get(
            0) || this.attr("in2") : this.attr("in2", r)
        }
      }), SVG.filter = {
        sepiatone: [.343, .669, .119, 0, 0, .249, .626, .13, 0, 0, .172, .334, .111, 0, 0, 0, 0, 0, 1, 0]
      }
    }.call(void 0),
    function() {
      function w(s, r, n, o, l, c, d) {
        for (var g = s.slice(r, n || d), p = o.slice(l, c || d), f = 0, x = {
            pos: [0, 0],
            start: [0, 0]
          }, m = {
            pos: [0, 0],
            start: [0, 0]
          }; g[f] = e.call(x, g[f]), p[f] = e.call(m, p[f]), g[f][0] != p[f][0] || "M" == g[f][0] || "A" == g[f][0] &&
          (g[f][4] != p[f][4] || g[f][5] != p[f][5]) ? (Array.prototype.splice.apply(g, [f, 1].concat(i.call(x, g[
            f]))), Array.prototype.splice.apply(p, [f, 1].concat(i.call(m, p[f])))) : (g[f] = t.call(x, g[f]), p[f] =
            t.call(m, p[f])), ++f != g.length || f != p.length;) f == g.length && g.push(["C", x.pos[0], x.pos[1], x
          .pos[0], x.pos[1], x.pos[0], x.pos[1]
        ]), f == p.length && p.push(["C", m.pos[0], m.pos[1], m.pos[0], m.pos[1], m.pos[0], m.pos[1]]);
        return {
          start: g,
          dest: p
        }
      }

      function e(s) {
        switch (s[0]) {
          case "z":
          case "Z":
            s[0] = "L", s[1] = this.start[0], s[2] = this.start[1];
            break;
          case "H":
            s[0] = "L", s[2] = this.pos[1];
            break;
          case "V":
            s[0] = "L", s[2] = s[1], s[1] = this.pos[0];
            break;
          case "T":
            s[0] = "Q", s[3] = s[1], s[4] = s[2], s[1] = this.reflection[1], s[2] = this.reflection[0];
            break;
          case "S":
            s[0] = "C", s[6] = s[4], s[5] = s[3], s[4] = s[2], s[3] = s[1], s[2] = this.reflection[1], s[1] = this
              .reflection[0]
        }
        return s
      }

      function t(s) {
        var r = s.length;
        return this.pos = [s[r - 2], s[r - 1]], -1 != "SCQT".indexOf(s[0]) && (this.reflection = [2 * this.pos[0] - s[
          r - 4], 2 * this.pos[1] - s[r - 3]]), s
      }

      function i(s) {
        var r = [s];
        switch (s[0]) {
          case "M":
            return this.pos = this.start = [s[1], s[2]], r;
          case "L":
            s[5] = s[3] = s[1], s[6] = s[4] = s[2], s[1] = this.pos[0], s[2] = this.pos[1];
            break;
          case "Q":
            s[6] = s[4], s[5] = s[3], s[4] = 1 * s[4] / 3 + 2 * s[2] / 3, s[3] = 1 * s[3] / 3 + 2 * s[1] / 3, s[2] =
              1 * this.pos[1] / 3 + 2 * s[2] / 3, s[1] = 1 * this.pos[0] / 3 + 2 * s[1] / 3;
            break;
          case "A":
            s = (r = function(n, o) {
              var l, c, d, g, p, f, x, m, v, y, h, u, b, k, A, S, C, L, M, z, I, T, E, H, D, O, W = Math.abs(o[
                1]),
                N = Math.abs(o[2]),
                B = o[3] % 360,
                Z = o[4],
                U = o[5],
                _ = o[6],
                ae = o[7],
                V = new SVG.Point(n),
                G = new SVG.Point(_, ae),
                j = [];
              if (0 === W || 0 === N || V.x === G.x && V.y === G.y) return [
                ["C", V.x, V.y, G.x, G.y, G.x, G.y]
              ];
              for ((c = (l = new SVG.Point((V.x - G.x) / 2, (V.y - G.y) / 2).transform((new SVG.Matrix).rotate(
                  B))).x * l.x / (W * W) + l.y * l.y / (N * N)) > 1 && (W *= c = Math.sqrt(c), N *= c), d = (
                  new SVG.Matrix).rotate(B).scale(1 / W, 1 / N).rotate(-B), V = V.transform(d), f = (g = [(G = G
                  .transform(d)).x - V.x, G.y - V.y])[0] * g[0] + g[1] * g[1], p = Math.sqrt(f), g[0] /= p, g[
                1] /= p, x = f < 4 ? Math.sqrt(1 - f / 4) : 0, Z === U && (x *= -1), m = new SVG.Point((G.x + V
                  .x) / 2 + x * -g[1], (G.y + V.y) / 2 + x * g[0]), v = new SVG.Point(V.x - m.x, V.y - m.y), y =
                new SVG.Point(G.x - m.x, G.y - m.y), h = Math.acos(v.x / Math.sqrt(v.x * v.x + v.y * v.y)), v.y <
                0 && (h *= -1), u = Math.acos(y.x / Math.sqrt(y.x * y.x + y.y * y.y)), y.y < 0 && (u *= -1), U &&
                h > u && (u += 2 * Math.PI), !U && h < u && (u -= 2 * Math.PI), S = [], C = h, b = (u - h) / (k =
                  Math.ceil(2 * Math.abs(h - u) / Math.PI)), A = 4 * Math.tan(b / 4) / 3, I = 0; I <= k; I++) M =
                Math.cos(C), L = Math.sin(C), z = new SVG.Point(m.x + M, m.y + L), S[I] = [new SVG.Point(z.x + A *
                  L, z.y - A * M), z, new SVG.Point(z.x - A * L, z.y + A * M)], C += b;
              for (S[0][0] = S[0][1].clone(), S[S.length - 1][2] = S[S.length - 1][1].clone(), d = (new SVG
                  .Matrix).rotate(B).scale(W, N).rotate(-B), I = 0, T = S.length; I < T; I++) S[I][0] = S[I][0]
                .transform(d), S[I][1] = S[I][1].transform(d), S[I][2] = S[I][2].transform(d);
              for (I = 1, T = S.length; I < T; I++) E = (z = S[I - 1][2]).x, H = z.y, D = (z = S[I][0]).x, O = z
                .y, _ = (z = S[I][1]).x, j.push(["C", E, H, D, O, _, ae = z.y]);
              return j
            }(this.pos, s))[0]
        }
        return s[0] = "C", this.pos = [s[5], s[6]], this.reflection = [2 * s[5] - s[3], 2 * s[6] - s[4]], r
      }

      function a(s, r) {
        if (!1 === r) return !1;
        for (var n = r, o = s.length; n < o; ++n)
          if ("M" == s[n][0]) return n;
        return !1
      }
      SVG.extend(SVG.PathArray, {
        morph: function(s) {
          for (var r = this.value, n = this.parse(s), o = 0, l = 0, c = !1, d = !1; !1 !== o || !1 !== l;) {
            var g;
            c = a(r, !1 !== o && o + 1), d = a(n, !1 !== l && l + 1), !1 === o && (o = 0 == (g = new SVG
              .PathArray(p.start).bbox()).height || 0 == g.width ? r.push(r[0]) - 1 : r.push(["M", g.x + g
              .width / 2, g.y + g.height / 2
            ]) - 1), !1 === l && (l = 0 == (g = new SVG.PathArray(p.dest).bbox()).height || 0 == g.width ? n
              .push(n[0]) - 1 : n.push(["M", g.x + g.width / 2, g.y + g.height / 2]) - 1);
            var p = w(r, o, c, n, l, d);
            r = r.slice(0, o).concat(p.start, !1 === c ? [] : r.slice(c)), n = n.slice(0, l).concat(p.dest, !
                1 === d ? [] : n.slice(d)), o = !1 !== c && o + p.start.length, l = !1 !== d && l + p.dest
              .length
          }
          return this.value = r, this.destination = new SVG.PathArray, this.destination.value = n, this
        }
      })
    }(),
    /*! svg.draggable.js - v2.2.2 - 2019-01-08
     * https://github.com/svgdotjs/svg.draggable.js
     * Copyright (c) 2019 Wout Fierens; Licensed MIT */
    function() {
      function w(e) {
        e.remember("_draggable", this), this.el = e
      }
      w.prototype.init = function(e, t) {
        var i = this;
        this.constraint = e, this.value = t, this.el.on("mousedown.drag", function(a) {
          i.start(a)
        }), this.el.on("touchstart.drag", function(a) {
          i.start(a)
        })
      }, w.prototype.transformPoint = function(e, t) {
        var i = (e = e || window.event).changedTouches && e.changedTouches[0] || e;
        return this.p.x = i.clientX - (t || 0), this.p.y = i.clientY, this.p.matrixTransform(this.m)
      }, w.prototype.getBBox = function() {
        var e = this.el.bbox();
        return this.el instanceof SVG.Nested && (e = this.el.rbox()), (this.el instanceof SVG.G || this
          .el instanceof SVG.Use || this.el instanceof SVG.Nested) && (e.x = this.el.x(), e.y = this.el.y()), e
      }, w.prototype.start = function(e) {
        if ("click" != e.type && "mousedown" != e.type && "mousemove" != e.type || 1 == (e.which || e.buttons)) {
          var t = this;
          if (this.el.fire("beforedrag", {
              event: e,
              handler: this
            }), !this.el.event().defaultPrevented) {
            e.preventDefault(), e.stopPropagation(), this.parent = this.parent || this.el.parent(SVG.Nested) || this
              .el.parent(SVG.Doc), this.p = this.parent.node.createSVGPoint(), this.m = this.el.node.getScreenCTM()
              .inverse();
            var i, a = this.getBBox();
            if (this.el instanceof SVG.Text) switch (i = this.el.node.getComputedTextLength(), this.el.attr(
                "text-anchor")) {
              case "middle":
                i /= 2;
                break;
              case "start":
                i = 0
            }
            this.startPoints = {
              point: this.transformPoint(e, i),
              box: a,
              transform: this.el.transform()
            }, SVG.on(window, "mousemove.drag", function(s) {
              t.drag(s)
            }), SVG.on(window, "touchmove.drag", function(s) {
              t.drag(s)
            }), SVG.on(window, "mouseup.drag", function(s) {
              t.end(s)
            }), SVG.on(window, "touchend.drag", function(s) {
              t.end(s)
            }), this.el.fire("dragstart", {
              event: e,
              p: this.startPoints.point,
              m: this.m,
              handler: this
            })
          }
        }
      }, w.prototype.drag = function(e) {
        var t = this.getBBox(),
          i = this.transformPoint(e),
          a = this.startPoints.box.x + i.x - this.startPoints.point.x,
          s = this.startPoints.box.y + i.y - this.startPoints.point.y,
          r = this.constraint,
          n = i.x - this.startPoints.point.x,
          o = i.y - this.startPoints.point.y;
        if (this.el.fire("dragmove", {
            event: e,
            p: i,
            m: this.m,
            handler: this
          }), this.el.event().defaultPrevented) return i;
        if ("function" == typeof r) {
          var l = r.call(this.el, a, s, this.m);
          "boolean" == typeof l && (l = {
              x: l,
              y: l
            }), !0 === l.x ? this.el.x(a) : !1 !== l.x && this.el.x(l.x), !0 === l.y ? this.el.y(s) : !1 !== l.y &&
            this.el.y(l.y)
        } else "object" == typeof r && (null != r.minX && a < r.minX ? n = (a = r.minX) - this.startPoints.box.x :
          null != r.maxX && a > r.maxX - t.width && (n = (a = r.maxX - t.width) - this.startPoints.box.x), null !=
          r.minY && s < r.minY ? o = (s = r.minY) - this.startPoints.box.y : null != r.maxY && s > r.maxY - t
          .height && (o = (s = r.maxY - t.height) - this.startPoints.box.y), null != r.snapToGrid && (a -= a % r
            .snapToGrid, s -= s % r.snapToGrid, n -= n % r.snapToGrid, o -= o % r.snapToGrid), this
          .el instanceof SVG.G ? this.el.matrix(this.startPoints.transform).transform({
            x: n,
            y: o
          }, !0) : this.el.move(a, s));
        return i
      }, w.prototype.end = function(e) {
        var t = this.drag(e);
        this.el.fire("dragend", {
            event: e,
            p: t,
            m: this.m,
            handler: this
          }), SVG.off(window, "mousemove.drag"), SVG.off(window, "touchmove.drag"), SVG.off(window, "mouseup.drag"),
          SVG.off(window, "touchend.drag")
      }, SVG.extend(SVG.Element, {
        draggable: function(e, t) {
          "function" != typeof e && "object" != typeof e || (t = e, e = !0);
          var i = this.remember("_draggable") || new w(this);
          return (e = void 0 === e || e) ? i.init(t || {}, e) : (this.off("mousedown.drag"), this.off(
            "touchstart.drag")), this
        }
      })
    }.call(void 0),
    function() {
      function w(e) {
        this.el = e, e.remember("_selectHandler", this), this.pointSelection = {
          isSelected: !1
        }, this.rectSelection = {
          isSelected: !1
        }, this.pointsList = {
          lt: [0, 0],
          rt: ["width", 0],
          rb: ["width", "height"],
          lb: [0, "height"],
          t: ["width", 0],
          r: ["width", "height"],
          b: ["width", "height"],
          l: [0, "height"]
        }, this.pointCoord = function(t, i, a) {
          var s = "string" != typeof t ? t : i[t];
          return a ? s / 2 : s
        }, this.pointCoords = function(t, i) {
          var a = this.pointsList[t];
          return {
            x: this.pointCoord(a[0], i, "t" === t || "b" === t),
            y: this.pointCoord(a[1], i, "r" === t || "l" === t)
          }
        }
      }
      w.prototype.init = function(e, t) {
        var i = this.el.bbox();
        this.options = {};
        var a = this.el.selectize.defaults.points;
        for (var s in this.el.selectize.defaults) this.options[s] = this.el.selectize.defaults[s], void 0 !== t[
          s] && (this.options[s] = t[s]);
        var r = ["points", "pointsExclude"];
        for (var s in r) {
          var n = this.options[r[s]];
          "string" == typeof n ? n = n.length > 0 ? n.split(/\s*,\s*/i) : [] : "boolean" == typeof n && "points" ===
            r[s] && (n = n ? a : []), this.options[r[s]] = n
        }
        this.options.points = [a, this.options.points].reduce(function(o, l) {
          return o.filter(function(c) {
            return l.indexOf(c) > -1
          })
        }), this.options.points = [this.options.points, this.options.pointsExclude].reduce(function(o, l) {
          return o.filter(function(c) {
            return l.indexOf(c) < 0
          })
        }), this.parent = this.el.parent(), this.nested = this.nested || this.parent.group(), this.nested.matrix(
          new SVG.Matrix(this.el).translate(i.x, i.y)), this.options.deepSelect && -1 !== ["line", "polyline",
          "polygon"
        ].indexOf(this.el.type) ? this.selectPoints(e) : this.selectRect(e), this.observe(), this.cleanup()
      }, w.prototype.selectPoints = function(e) {
        return this.pointSelection.isSelected = e, this.pointSelection.set || (this.pointSelection.set = this.parent
          .set(), this.drawPoints()), this
      }, w.prototype.getPointArray = function() {
        var e = this.el.bbox();
        return this.el.array().valueOf().map(function(t) {
          return [t[0] - e.x, t[1] - e.y]
        })
      }, w.prototype.drawPoints = function() {
        for (var e = this, t = this.getPointArray(), i = 0, a = t.length; i < a; ++i) {
          var s = function(n) {
              return function(o) {
                (o = o || window.event).preventDefault ? o.preventDefault() : o.returnValue = !1, o
                  .stopPropagation(), e.el.fire("point", {
                    x: o.pageX || o.touches[0].pageX,
                    y: o.pageY || o.touches[0].pageY,
                    i: n,
                    event: o
                  })
              }
            }(i),
            r = this.drawPoint(t[i][0], t[i][1]).addClass(this.options.classPoints).addClass(this.options
              .classPoints + "_point").on("touchstart", s).on("mousedown", s);
          this.pointSelection.set.add(r)
        }
      }, w.prototype.drawPoint = function(e, t) {
        var i = this.options.pointType;
        switch (i) {
          case "circle":
            return this.drawCircle(e, t);
          case "rect":
            return this.drawRect(e, t);
          default:
            if ("function" == typeof i) return i.call(this, e, t);
            throw new Error("Unknown " + i + " point type!")
        }
      }, w.prototype.drawCircle = function(e, t) {
        return this.nested.circle(this.options.pointSize).center(e, t)
      }, w.prototype.drawRect = function(e, t) {
        return this.nested.rect(this.options.pointSize, this.options.pointSize).center(e, t)
      }, w.prototype.updatePointSelection = function() {
        var e = this.getPointArray();
        this.pointSelection.set.each(function(t) {
          this.cx() === e[t][0] && this.cy() === e[t][1] || this.center(e[t][0], e[t][1])
        })
      }, w.prototype.updateRectSelection = function() {
        var e = this,
          t = this.el.bbox();
        if (this.rectSelection.set.get(0).attr({
            width: t.width,
            height: t.height
          }), this.options.points.length && this.options.points.map(function(a, s) {
            var r = e.pointCoords(a, t);
            e.rectSelection.set.get(s + 1).center(r.x, r.y)
          }), this.options.rotationPoint) {
          var i = this.rectSelection.set.length();
          this.rectSelection.set.get(i - 1).center(t.width / 2, 20)
        }
      }, w.prototype.selectRect = function(e) {
        var t = this,
          i = this.el.bbox();

        function a(n) {
          return function(o) {
            (o = o || window.event).preventDefault ? o.preventDefault() : o.returnValue = !1, o.stopPropagation(),
              t.el.fire(n, {
                x: o.pageX || o.touches[0].pageX,
                y: o.pageY || o.touches[0].pageY,
                event: o
              })
          }
        }
        if (this.rectSelection.isSelected = e, this.rectSelection.set = this.rectSelection.set || this.parent.set(),
          this.rectSelection.set.get(0) || this.rectSelection.set.add(this.nested.rect(i.width, i.height).addClass(
            this.options.classRect)), this.options.points.length && this.rectSelection.set.length() < 2 && (this
            .options.points.map(function(n, o) {
              var l = t.pointCoords(n, i),
                c = t.drawPoint(l.x, l.y).attr("class", t.options.classPoints + "_" + n).on("mousedown", a(n)).on(
                  "touchstart", a(n));
              t.rectSelection.set.add(c)
            }), this.rectSelection.set.each(function() {
              this.addClass(t.options.classPoints)
            })), this.options.rotationPoint && (this.options.points && !this.rectSelection.set.get(9) || !this
            .options.points && !this.rectSelection.set.get(1))) {
          var s = function(n) {
              (n = n || window.event).preventDefault ? n.preventDefault() : n.returnValue = !1, n.stopPropagation(),
                t.el.fire("rot", {
                  x: n.pageX || n.touches[0].pageX,
                  y: n.pageY || n.touches[0].pageY,
                  event: n
                })
            },
            r = this.drawPoint(i.width / 2, 20).attr("class", this.options.classPoints + "_rot").on("touchstart", s)
            .on("mousedown", s);
          this.rectSelection.set.add(r)
        }
      }, w.prototype.handler = function() {
        var e = this.el.bbox();
        this.nested.matrix(new SVG.Matrix(this.el).translate(e.x, e.y)), this.rectSelection.isSelected && this
          .updateRectSelection(), this.pointSelection.isSelected && this.updatePointSelection()
      }, w.prototype.observe = function() {
        var e = this;
        if (MutationObserver)
          if (this.rectSelection.isSelected || this.pointSelection.isSelected) this.observerInst = this
            .observerInst || new MutationObserver(function() {
              e.handler()
            }), this.observerInst.observe(this.el.node, {
              attributes: !0
            });
          else try {
            this.observerInst.disconnect(), delete this.observerInst
          } catch {} else this.el.off("DOMAttrModified.select"), (this.rectSelection.isSelected || this
            .pointSelection.isSelected) && this.el.on("DOMAttrModified.select", function() {
            e.handler()
          })
      }, w.prototype.cleanup = function() {
        !this.rectSelection.isSelected && this.rectSelection.set && (this.rectSelection.set.each(function() {
            this.remove()
          }), this.rectSelection.set.clear(), delete this.rectSelection.set), !this.pointSelection.isSelected &&
          this.pointSelection.set && (this.pointSelection.set.each(function() {
            this.remove()
          }), this.pointSelection.set.clear(), delete this.pointSelection.set), this.pointSelection.isSelected ||
          this.rectSelection.isSelected || (this.nested.remove(), delete this.nested)
      }, SVG.extend(SVG.Element, {
        selectize: function(e, t) {
          return "object" == typeof e && (t = e, e = !0), (this.remember("_selectHandler") || new w(this)).init(
            void 0 === e || e, t || {}), this
        }
      }), SVG.Element.prototype.selectize.defaults = {
        points: ["lt", "rt", "rb", "lb", "t", "r", "b", "l"],
        pointsExclude: [],
        classRect: "svg_select_boundingRect",
        classPoints: "svg_select_points",
        pointSize: 7,
        rotationPoint: !0,
        deepSelect: !1,
        pointType: "circle"
      }
    }(),
    function() {
      (function() {
        function w(e) {
          e.remember("_resizeHandler", this), this.el = e, this.parameters = {}, this.lastUpdateCall = null, this
            .p = e.doc().node.createSVGPoint()
        }
        w.prototype.transformPoint = function(e, t, i) {
          return this.p.x = e - (this.offset.x - window.pageXOffset), this.p.y = t - (this.offset.y - window
            .pageYOffset), this.p.matrixTransform(i || this.m)
        }, w.prototype._extractPosition = function(e) {
          return {
            x: null != e.clientX ? e.clientX : e.touches[0].clientX,
            y: null != e.clientY ? e.clientY : e.touches[0].clientY
          }
        }, w.prototype.init = function(e) {
          var t = this;
          if (this.stop(), "stop" !== e) {
            for (var i in this.options = {}, this.el.resize.defaults) this.options[i] = this.el.resize.defaults[
              i], void 0 !== e[i] && (this.options[i] = e[i]);
            this.el.on("lt.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("rt.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("rb.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("lb.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("t.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("r.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("b.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("l.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("rot.resize", function(a) {
              t.resize(a || window.event)
            }), this.el.on("point.resize", function(a) {
              t.resize(a || window.event)
            }), this.update()
          }
        }, w.prototype.stop = function() {
          return this.el.off("lt.resize"), this.el.off("rt.resize"), this.el.off("rb.resize"), this.el.off(
              "lb.resize"), this.el.off("t.resize"), this.el.off("r.resize"), this.el.off("b.resize"), this.el
            .off("l.resize"), this.el.off("rot.resize"), this.el.off("point.resize"), this
        }, w.prototype.resize = function(e) {
          var t = this;
          this.m = this.el.node.getScreenCTM().inverse(), this.offset = {
            x: window.pageXOffset,
            y: window.pageYOffset
          };
          var i = this._extractPosition(e.detail.event);
          if (this.parameters = {
              type: this.el.type,
              p: this.transformPoint(i.x, i.y),
              x: e.detail.x,
              y: e.detail.y,
              box: this.el.bbox(),
              rotation: this.el.transform().rotation
            }, "text" === this.el.type && (this.parameters.fontSize = this.el.attr()["font-size"]), void 0 !== e
            .detail.i) {
            var a = this.el.array().valueOf();
            this.parameters.i = e.detail.i, this.parameters.pointCoords = [a[e.detail.i][0], a[e.detail.i][1]]
          }
          switch (e.type) {
            case "lt":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r);
                if (this.parameters.box.width - n[0] > 0 && this.parameters.box.height - n[1] > 0) {
                  if ("text" === this.parameters.type) return this.el.move(this.parameters.box.x + n[0], this
                    .parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize - n[0]);
                  n = this.checkAspectRatio(n), this.el.move(this.parameters.box.x + n[0], this.parameters.box
                    .y + n[1]).size(this.parameters.box.width - n[0], this.parameters.box.height - n[1])
                }
              };
              break;
            case "rt":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r, 2);
                if (this.parameters.box.width + n[0] > 0 && this.parameters.box.height - n[1] > 0) {
                  if ("text" === this.parameters.type) return this.el.move(this.parameters.box.x - n[0], this
                    .parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize + n[0]);
                  n = this.checkAspectRatio(n, !0), this.el.move(this.parameters.box.x, this.parameters.box.y +
                    n[1]).size(this.parameters.box.width + n[0], this.parameters.box.height - n[1])
                }
              };
              break;
            case "rb":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r, 0);
                if (this.parameters.box.width + n[0] > 0 && this.parameters.box.height + n[1] > 0) {
                  if ("text" === this.parameters.type) return this.el.move(this.parameters.box.x - n[0], this
                    .parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize + n[0]);
                  n = this.checkAspectRatio(n), this.el.move(this.parameters.box.x, this.parameters.box.y).size(
                    this.parameters.box.width + n[0], this.parameters.box.height + n[1])
                }
              };
              break;
            case "lb":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r, 1);
                if (this.parameters.box.width - n[0] > 0 && this.parameters.box.height + n[1] > 0) {
                  if ("text" === this.parameters.type) return this.el.move(this.parameters.box.x + n[0], this
                    .parameters.box.y), void this.el.attr("font-size", this.parameters.fontSize - n[0]);
                  n = this.checkAspectRatio(n, !0), this.el.move(this.parameters.box.x + n[0], this.parameters
                    .box.y).size(this.parameters.box.width - n[0], this.parameters.box.height + n[1])
                }
              };
              break;
            case "t":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r, 2);
                if (this.parameters.box.height - n[1] > 0) {
                  if ("text" === this.parameters.type) return;
                  this.el.move(this.parameters.box.x, this.parameters.box.y + n[1]).height(this.parameters.box
                    .height - n[1])
                }
              };
              break;
            case "r":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r, 0);
                if (this.parameters.box.width + n[0] > 0) {
                  if ("text" === this.parameters.type) return;
                  this.el.move(this.parameters.box.x, this.parameters.box.y).width(this.parameters.box.width +
                    n[0])
                }
              };
              break;
            case "b":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r, 0);
                if (this.parameters.box.height + n[1] > 0) {
                  if ("text" === this.parameters.type) return;
                  this.el.move(this.parameters.box.x, this.parameters.box.y).height(this.parameters.box.height +
                    n[1])
                }
              };
              break;
            case "l":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r, 1);
                if (this.parameters.box.width - n[0] > 0) {
                  if ("text" === this.parameters.type) return;
                  this.el.move(this.parameters.box.x + n[0], this.parameters.box.y).width(this.parameters.box
                    .width - n[0])
                }
              };
              break;
            case "rot":
              this.calc = function(s, r) {
                var n = s + this.parameters.p.x,
                  o = r + this.parameters.p.y,
                  l = Math.atan2(this.parameters.p.y - this.parameters.box.y - this.parameters.box.height / 2,
                    this.parameters.p.x - this.parameters.box.x - this.parameters.box.width / 2),
                  c = Math.atan2(o - this.parameters.box.y - this.parameters.box.height / 2, n - this.parameters
                    .box.x - this.parameters.box.width / 2),
                  d = this.parameters.rotation + 180 * (c - l) / Math.PI + this.options.snapToAngle / 2;
                this.el.center(this.parameters.box.cx, this.parameters.box.cy).rotate(d - d % this.options
                  .snapToAngle, this.parameters.box.cx, this.parameters.box.cy)
              };
              break;
            case "point":
              this.calc = function(s, r) {
                var n = this.snapToGrid(s, r, this.parameters.pointCoords[0], this.parameters.pointCoords[1]),
                  o = this.el.array().valueOf();
                o[this.parameters.i][0] = this.parameters.pointCoords[0] + n[0], o[this.parameters.i][1] = this
                  .parameters.pointCoords[1] + n[1], this.el.plot(o)
              }
          }
          this.el.fire("resizestart", {
            dx: this.parameters.x,
            dy: this.parameters.y,
            event: e
          }), SVG.on(window, "touchmove.resize", function(s) {
            t.update(s || window.event)
          }), SVG.on(window, "touchend.resize", function() {
            t.done()
          }), SVG.on(window, "mousemove.resize", function(s) {
            t.update(s || window.event)
          }), SVG.on(window, "mouseup.resize", function() {
            t.done()
          })
        }, w.prototype.update = function(e) {
          if (e) {
            var t = this._extractPosition(e),
              i = this.transformPoint(t.x, t.y),
              a = i.x - this.parameters.p.x,
              s = i.y - this.parameters.p.y;
            this.lastUpdateCall = [a, s], this.calc(a, s), this.el.fire("resizing", {
              dx: a,
              dy: s,
              event: e
            })
          } else this.lastUpdateCall && this.calc(this.lastUpdateCall[0], this.lastUpdateCall[1])
        }, w.prototype.done = function() {
          this.lastUpdateCall = null, SVG.off(window, "mousemove.resize"), SVG.off(window, "mouseup.resize"), SVG
            .off(window, "touchmove.resize"), SVG.off(window, "touchend.resize"), this.el.fire("resizedone")
        }, w.prototype.snapToGrid = function(e, t, i, a) {
          var s;
          return s = void 0 !== a ? [(i + e) % this.options.snapToGrid, (a + t) % this.options.snapToGrid] : [(
                this.parameters.box.x + e + (1 & (i = i ?? 3) ? 0 : this.parameters.box.width)) % this.options
              .snapToGrid, (this.parameters.box.y + t + (2 & i ? 0 : this.parameters.box.height)) % this.options
              .snapToGrid
            ], e < 0 && (s[0] -= this.options.snapToGrid), t < 0 && (s[1] -= this.options.snapToGrid), e -= Math
            .abs(s[0]) < this.options.snapToGrid / 2 ? s[0] : s[0] - (e < 0 ? -this.options.snapToGrid : this
              .options.snapToGrid), t -= Math.abs(s[1]) < this.options.snapToGrid / 2 ? s[1] : s[1] - (t < 0 ? -
              this.options.snapToGrid : this.options.snapToGrid), this.constraintToBox(e, t, i, a)
        }, w.prototype.constraintToBox = function(e, t, i, a) {
          var s, r, n = this.options.constraint || {};
          return void 0 !== a ? (s = i, r = a) : (s = this.parameters.box.x + (1 & i ? 0 : this.parameters.box
              .width), r = this.parameters.box.y + (2 & i ? 0 : this.parameters.box.height)), void 0 !== n.minX &&
            s + e < n.minX && (e = n.minX - s), void 0 !== n.maxX && s + e > n.maxX && (e = n.maxX - s),
            void 0 !== n.minY && r + t < n.minY && (t = n.minY - r), void 0 !== n.maxY && r + t > n.maxY && (t = n
              .maxY - r), [e, t]
        }, w.prototype.checkAspectRatio = function(e, t) {
          if (!this.options.saveAspectRatio) return e;
          var i = e.slice(),
            a = this.parameters.box.width / this.parameters.box.height,
            s = this.parameters.box.width + e[0],
            r = this.parameters.box.height - e[1],
            n = s / r;
          return n < a ? (i[1] = s / a - this.parameters.box.height, t && (i[1] = -i[1])) : n > a && (i[0] = this
            .parameters.box.width - r * a, t && (i[0] = -i[0])), i
        }, SVG.extend(SVG.Element, {
          resize: function(e) {
            return (this.remember("_resizeHandler") || new w(this)).init(e || {}), this
          }
        }), SVG.Element.prototype.resize.defaults = {
          snapToAngle: .1,
          snapToGrid: 1,
          constraint: {},
          saveAspectRatio: !1
        }
      }).call(this)
    }(), void 0 === window.Apex && (window.Apex = {});
  var rt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "initModules",
        value: function() {
          this.ctx.publicMethods = ["updateOptions", "updateSeries", "appendData", "appendSeries",
              "isSeriesHidden", "toggleSeries", "showSeries", "hideSeries", "setLocale", "resetSeries",
              "zoomX", "toggleDataPointSelection", "dataURI", "exportToCSV", "addXaxisAnnotation",
              "addYaxisAnnotation", "addPointAnnotation", "clearAnnotations", "removeAnnotation", "paper",
              "destroy"
            ], this.ctx.eventList = ["click", "mousedown", "mousemove", "mouseleave", "touchstart",
              "touchmove", "touchleave", "mouseup", "touchend"
            ], this.ctx.animations = new ge(this.ctx), this.ctx.axes = new pt(this.ctx), this.ctx.core =
            new Wt(this.ctx.el, this.ctx), this.ctx.config = new ye({}), this.ctx.data = new Ue(this.ctx),
            this.ctx.grid = new qe(this.ctx), this.ctx.graphics = new X(this.ctx), this.ctx.coreUtils = new q(
              this.ctx), this.ctx.crosshairs = new Fe(this.ctx), this.ctx.events = new gt(this.ctx), this.ctx
            .exports = new Pe(this.ctx), this.ctx.localization = new ut(this.ctx), this.ctx.options = new de,
            this.ctx.responsive = new ft(this.ctx), this.ctx.series = new se(this.ctx), this.ctx.theme =
            new xt(this.ctx), this.ctx.formatters = new me(this.ctx), this.ctx.titleSubtitle = new bt(this
              .ctx), this.ctx.legend = new $e(this.ctx), this.ctx.toolbar = new Je(this.ctx), this.ctx
            .tooltip = new et(this.ctx), this.ctx.dimensions = new Me(this.ctx), this.ctx.updateHelpers =
            new Bt(this.ctx), this.ctx.zoomPanSelection = new At(this.ctx), this.ctx.w.globals.tooltip =
            new et(this.ctx)
        }
      }]), w
    }(),
    nt = function() {
      function w(e) {
        F(this, w), this.ctx = e, this.w = e.w
      }
      return R(w, [{
        key: "clear",
        value: function(e) {
          var t = e.isUpdating;
          this.ctx.zoomPanSelection && this.ctx.zoomPanSelection.destroy(), this.ctx.toolbar && this.ctx
            .toolbar.destroy(), this.ctx.animations = null, this.ctx.axes = null, this.ctx.annotations = null,
            this.ctx.core = null, this.ctx.data = null, this.ctx.grid = null, this.ctx.series = null, this.ctx
            .responsive = null, this.ctx.theme = null, this.ctx.formatters = null, this.ctx.titleSubtitle =
            null, this.ctx.legend = null, this.ctx.dimensions = null, this.ctx.options = null, this.ctx
            .crosshairs = null, this.ctx.zoomPanSelection = null, this.ctx.updateHelpers = null, this.ctx
            .toolbar = null, this.ctx.localization = null, this.ctx.w.globals.tooltip = null, this
            .clearDomElements({
              isUpdating: t
            })
        }
      }, {
        key: "killSVG",
        value: function(e) {
          e.each(function(t, i) {
            this.removeClass("*"), this.off(), this.stop()
          }, !0), e.ungroup(), e.clear()
        }
      }, {
        key: "clearDomElements",
        value: function(e) {
          var t = this,
            a = this.w.globals.dom.Paper.node;
          a.parentNode && a.parentNode.parentNode && !e.isUpdating && (a.parentNode.parentNode.style
            .minHeight = "unset");
          var s = this.w.globals.dom.baseEl;
          s && this.ctx.eventList.forEach(function(n) {
            s.removeEventListener(n, t.ctx.events.documentEvent)
          });
          var r = this.w.globals.dom;
          if (null !== this.ctx.el)
            for (; this.ctx.el.firstChild;) this.ctx.el.removeChild(this.ctx.el.firstChild);
          this.killSVG(r.Paper), r.Paper.remove(), r.elWrap = null, r.elGraphical = null, r.elLegendWrap =
            null, r.elLegendForeign = null, r.baseEl = null, r.elGridRect = null, r.elGridRectMask = null, r
            .elGridRectMarkerMask = null, r.elForecastMask = null, r.elNonForecastMask = null, r.elDefs = null
        }
      }]), w
    }(),
    Oe = new WeakMap,
    Gt = function() {
      function w(e, t) {
        F(this, w), this.opts = t, this.ctx = this, this.w = new dt(t).init(), this.el = e, this.w.globals.cuid = P
          .randomId(), this.w.globals.chartID = this.w.config.chart.id ? P.escapeString(this.w.config.chart.id) : this
          .w.globals.cuid, new rt(this).initModules(), this.create = P.bind(this.create, this), this
          .windowResizeHandler = this._windowResizeHandler.bind(this), this.parentResizeHandler = this
          ._parentResizeCallback.bind(this)
      }
      return R(w, [{
        key: "render",
        value: function() {
          var e = this;
          return new Promise(function(t, i) {
            if (null !== e.el) {
              void 0 === Apex._chartInstances && (Apex._chartInstances = []), e.w.config.chart.id && Apex
                ._chartInstances.push({
                  id: e.w.globals.chartID,
                  group: e.w.config.chart.group,
                  chart: e
                }), e.setLocale(e.w.config.chart.defaultLocale);
              var a = e.w.config.chart.events.beforeMount;
              "function" == typeof a && a(e, e.w), e.events.fireEvent("beforeMount", [e, e.w]), window
                .addEventListener("resize", e.windowResizeHandler),
                function(g, p) {
                  var f = !1;
                  if (g.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) {
                    var x = g.getBoundingClientRect();
                    "none" !== g.style.display && 0 !== x.width || (f = !0)
                  }
                  var m = new ResizeObserver(function(v) {
                    f && p.call(g, v), f = !0
                  });
                  g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? Array.from(g.children).forEach(function(
                  v) {
                    return m.observe(v)
                  }) : m.observe(g), Oe.set(p, m)
                }(e.el.parentNode, e.parentResizeHandler);
              var s = e.el.getRootNode && e.el.getRootNode(),
                r = P.is("ShadowRoot", s),
                n = e.el.ownerDocument,
                o = r ? s.getElementById("apexcharts-css") : n.getElementById("apexcharts-css");
              if (!o) {
                var l;
                (o = document.createElement("style")).id = "apexcharts-css", o.textContent =
                  '@keyframes opaque {\n  0% {\n      opacity: 0\n  }\n\n  to {\n      opacity: 1\n  }\n}\n\n@keyframes resizeanim {\n  0%,to {\n      opacity: 0\n  }\n}\n\n.apexcharts-canvas {\n  position: relative;\n  user-select: none\n}\n\n.apexcharts-canvas ::-webkit-scrollbar {\n  -webkit-appearance: none;\n  width: 6px\n}\n\n.apexcharts-canvas ::-webkit-scrollbar-thumb {\n  border-radius: 4px;\n  background-color: rgba(0,0,0,.5);\n  box-shadow: 0 0 1px rgba(255,255,255,.5);\n  -webkit-box-shadow: 0 0 1px rgba(255,255,255,.5)\n}\n\n.apexcharts-inner {\n  position: relative\n}\n\n.apexcharts-text tspan {\n  font-family: inherit\n}\n\n.legend-mouseover-inactive {\n  transition: .15s ease all;\n  opacity: .2\n}\n\n.apexcharts-legend-text {\n  padding-left: 15px;\n  margin-left: -15px;\n}\n\n.apexcharts-series-collapsed {\n  opacity: 0\n}\n\n.apexcharts-tooltip {\n  border-radius: 5px;\n  box-shadow: 2px 2px 6px -4px #999;\n  cursor: default;\n  font-size: 14px;\n  left: 62px;\n  opacity: 0;\n  pointer-events: none;\n  position: absolute;\n  top: 20px;\n  display: flex;\n  flex-direction: column;\n  overflow: hidden;\n  white-space: nowrap;\n  z-index: 12;\n  transition: .15s ease all\n}\n\n.apexcharts-tooltip.apexcharts-active {\n  opacity: 1;\n  transition: .15s ease all\n}\n\n.apexcharts-tooltip.apexcharts-theme-light {\n  border: 1px solid #e3e3e3;\n  background: rgba(255,255,255,.96)\n}\n\n.apexcharts-tooltip.apexcharts-theme-dark {\n  color: #fff;\n  background: rgba(30,30,30,.8)\n}\n\n.apexcharts-tooltip * {\n  font-family: inherit\n}\n\n.apexcharts-tooltip-title {\n  padding: 6px;\n  font-size: 15px;\n  margin-bottom: 4px\n}\n\n.apexcharts-tooltip.apexcharts-theme-light .apexcharts-tooltip-title {\n  background: #eceff1;\n  border-bottom: 1px solid #ddd\n}\n\n.apexcharts-tooltip.apexcharts-theme-dark .apexcharts-tooltip-title {\n  background: rgba(0,0,0,.7);\n  border-bottom: 1px solid #333\n}\n\n.apexcharts-tooltip-text-goals-value,.apexcharts-tooltip-text-y-value,.apexcharts-tooltip-text-z-value {\n  display: inline-block;\n  margin-left: 5px;\n  font-weight: 600\n}\n\n.apexcharts-tooltip-text-goals-label:empty,.apexcharts-tooltip-text-goals-value:empty,.apexcharts-tooltip-text-y-label:empty,.apexcharts-tooltip-text-y-value:empty,.apexcharts-tooltip-text-z-value:empty,.apexcharts-tooltip-title:empty {\n  display: none\n}\n\n.apexcharts-tooltip-text-goals-label,.apexcharts-tooltip-text-goals-value {\n  padding: 6px 0 5px\n}\n\n.apexcharts-tooltip-goals-group,.apexcharts-tooltip-text-goals-label,.apexcharts-tooltip-text-goals-value {\n  display: flex\n}\n\n.apexcharts-tooltip-text-goals-label:not(:empty),.apexcharts-tooltip-text-goals-value:not(:empty) {\n  margin-top: -6px\n}\n\n.apexcharts-tooltip-marker {\n  width: 12px;\n  height: 12px;\n  position: relative;\n  top: 0;\n  margin-right: 10px;\n  border-radius: 50%\n}\n\n.apexcharts-tooltip-series-group {\n  padding: 0 10px;\n  display: none;\n  text-align: left;\n  justify-content: left;\n  align-items: center\n}\n\n.apexcharts-tooltip-series-group.apexcharts-active .apexcharts-tooltip-marker {\n  opacity: 1\n}\n\n.apexcharts-tooltip-series-group.apexcharts-active,.apexcharts-tooltip-series-group:last-child {\n  padding-bottom: 4px\n}\n\n.apexcharts-tooltip-series-group-hidden {\n  opacity: 0;\n  height: 0;\n  line-height: 0;\n  padding: 0!important\n}\n\n.apexcharts-tooltip-y-group {\n  padding: 6px 0 5px\n}\n\n.apexcharts-custom-tooltip,.apexcharts-tooltip-box {\n  padding: 4px 8px\n}\n\n.apexcharts-tooltip-boxPlot {\n  display: flex;\n  flex-direction: column-reverse\n}\n\n.apexcharts-tooltip-box>div {\n  margin: 4px 0\n}\n\n.apexcharts-tooltip-box span.value {\n  font-weight: 700\n}\n\n.apexcharts-tooltip-rangebar {\n  padding: 5px 8px\n}\n\n.apexcharts-tooltip-rangebar .category {\n  font-weight: 600;\n  color: #777\n}\n\n.apexcharts-tooltip-rangebar .series-name {\n  font-weight: 700;\n  display: block;\n  margin-bottom: 5px\n}\n\n.apexcharts-xaxistooltip,.apexcharts-yaxistooltip {\n  opacity: 0;\n  pointer-events: none;\n  color: #373d3f;\n  font-size: 13px;\n  text-align: center;\n  border-radius: 2px;\n  position: absolute;\n  z-index: 10;\n  background: #eceff1;\n  border: 1px solid #90a4ae\n}\n\n.apexcharts-xaxistooltip {\n  padding: 9px 10px;\n  transition: .15s ease all\n}\n\n.apexcharts-xaxistooltip.apexcharts-theme-dark {\n  background: rgba(0,0,0,.7);\n  border: 1px solid rgba(0,0,0,.5);\n  color: #fff\n}\n\n.apexcharts-xaxistooltip:after,.apexcharts-xaxistooltip:before {\n  left: 50%;\n  border: solid transparent;\n  content: " ";\n  height: 0;\n  width: 0;\n  position: absolute;\n  pointer-events: none\n}\n\n.apexcharts-xaxistooltip:after {\n  border-color: transparent;\n  border-width: 6px;\n  margin-left: -6px\n}\n\n.apexcharts-xaxistooltip:before {\n  border-color: transparent;\n  border-width: 7px;\n  margin-left: -7px\n}\n\n.apexcharts-xaxistooltip-bottom:after,.apexcharts-xaxistooltip-bottom:before {\n  bottom: 100%\n}\n\n.apexcharts-xaxistooltip-top:after,.apexcharts-xaxistooltip-top:before {\n  top: 100%\n}\n\n.apexcharts-xaxistooltip-bottom:after {\n  border-bottom-color: #eceff1\n}\n\n.apexcharts-xaxistooltip-bottom:before {\n  border-bottom-color: #90a4ae\n}\n\n.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:after,.apexcharts-xaxistooltip-bottom.apexcharts-theme-dark:before {\n  border-bottom-color: rgba(0,0,0,.5)\n}\n\n.apexcharts-xaxistooltip-top:after {\n  border-top-color: #eceff1\n}\n\n.apexcharts-xaxistooltip-top:before {\n  border-top-color: #90a4ae\n}\n\n.apexcharts-xaxistooltip-top.apexcharts-theme-dark:after,.apexcharts-xaxistooltip-top.apexcharts-theme-dark:before {\n  border-top-color: rgba(0,0,0,.5)\n}\n\n.apexcharts-xaxistooltip.apexcharts-active {\n  opacity: 1;\n  transition: .15s ease all\n}\n\n.apexcharts-yaxistooltip {\n  padding: 4px 10px\n}\n\n.apexcharts-yaxistooltip.apexcharts-theme-dark {\n  background: rgba(0,0,0,.7);\n  border: 1px solid rgba(0,0,0,.5);\n  color: #fff\n}\n\n.apexcharts-yaxistooltip:after,.apexcharts-yaxistooltip:before {\n  top: 50%;\n  border: solid transparent;\n  content: " ";\n  height: 0;\n  width: 0;\n  position: absolute;\n  pointer-events: none\n}\n\n.apexcharts-yaxistooltip:after {\n  border-color: transparent;\n  border-width: 6px;\n  margin-top: -6px\n}\n\n.apexcharts-yaxistooltip:before {\n  border-color: transparent;\n  border-width: 7px;\n  margin-top: -7px\n}\n\n.apexcharts-yaxistooltip-left:after,.apexcharts-yaxistooltip-left:before {\n  left: 100%\n}\n\n.apexcharts-yaxistooltip-right:after,.apexcharts-yaxistooltip-right:before {\n  right: 100%\n}\n\n.apexcharts-yaxistooltip-left:after {\n  border-left-color: #eceff1\n}\n\n.apexcharts-yaxistooltip-left:before {\n  border-left-color: #90a4ae\n}\n\n.apexcharts-yaxistooltip-left.apexcharts-theme-dark:after,.apexcharts-yaxistooltip-left.apexcharts-theme-dark:before {\n  border-left-color: rgba(0,0,0,.5)\n}\n\n.apexcharts-yaxistooltip-right:after {\n  border-right-color: #eceff1\n}\n\n.apexcharts-yaxistooltip-right:before {\n  border-right-color: #90a4ae\n}\n\n.apexcharts-yaxistooltip-right.apexcharts-theme-dark:after,.apexcharts-yaxistooltip-right.apexcharts-theme-dark:before {\n  border-right-color: rgba(0,0,0,.5)\n}\n\n.apexcharts-yaxistooltip.apexcharts-active {\n  opacity: 1\n}\n\n.apexcharts-yaxistooltip-hidden {\n  display: none\n}\n\n.apexcharts-xcrosshairs,.apexcharts-ycrosshairs {\n  pointer-events: none;\n  opacity: 0;\n  transition: .15s ease all\n}\n\n.apexcharts-xcrosshairs.apexcharts-active,.apexcharts-ycrosshairs.apexcharts-active {\n  opacity: 1;\n  transition: .15s ease all\n}\n\n.apexcharts-ycrosshairs-hidden {\n  opacity: 0\n}\n\n.apexcharts-selection-rect {\n  cursor: move\n}\n\n.svg_select_boundingRect,.svg_select_points_rot {\n  pointer-events: none;\n  opacity: 0;\n  visibility: hidden\n}\n\n.apexcharts-selection-rect+g .svg_select_boundingRect,.apexcharts-selection-rect+g .svg_select_points_rot {\n  opacity: 0;\n  visibility: hidden\n}\n\n.apexcharts-selection-rect+g .svg_select_points_l,.apexcharts-selection-rect+g .svg_select_points_r {\n  cursor: ew-resize;\n  opacity: 1;\n  visibility: visible\n}\n\n.svg_select_points {\n  fill: #efefef;\n  stroke: #333;\n  rx: 2\n}\n\n.apexcharts-svg.apexcharts-zoomable.hovering-zoom {\n  cursor: crosshair\n}\n\n.apexcharts-svg.apexcharts-zoomable.hovering-pan {\n  cursor: move\n}\n\n.apexcharts-menu-icon,.apexcharts-pan-icon,.apexcharts-reset-icon,.apexcharts-selection-icon,.apexcharts-toolbar-custom-icon,.apexcharts-zoom-icon,.apexcharts-zoomin-icon,.apexcharts-zoomout-icon {\n  cursor: pointer;\n  width: 20px;\n  height: 20px;\n  line-height: 24px;\n  color: #6e8192;\n  text-align: center\n}\n\n.apexcharts-menu-icon svg,.apexcharts-reset-icon svg,.apexcharts-zoom-icon svg,.apexcharts-zoomin-icon svg,.apexcharts-zoomout-icon svg {\n  fill: #6e8192\n}\n\n.apexcharts-selection-icon svg {\n  fill: #444;\n  transform: scale(.76)\n}\n\n.apexcharts-theme-dark .apexcharts-menu-icon svg,.apexcharts-theme-dark .apexcharts-pan-icon svg,.apexcharts-theme-dark .apexcharts-reset-icon svg,.apexcharts-theme-dark .apexcharts-selection-icon svg,.apexcharts-theme-dark .apexcharts-toolbar-custom-icon svg,.apexcharts-theme-dark .apexcharts-zoom-icon svg,.apexcharts-theme-dark .apexcharts-zoomin-icon svg,.apexcharts-theme-dark .apexcharts-zoomout-icon svg {\n  fill: #f3f4f5\n}\n\n.apexcharts-canvas .apexcharts-reset-zoom-icon.apexcharts-selected svg,.apexcharts-canvas .apexcharts-selection-icon.apexcharts-selected svg,.apexcharts-canvas .apexcharts-zoom-icon.apexcharts-selected svg {\n  fill: #008ffb\n}\n\n.apexcharts-theme-light .apexcharts-menu-icon:hover svg,.apexcharts-theme-light .apexcharts-reset-icon:hover svg,.apexcharts-theme-light .apexcharts-selection-icon:not(.apexcharts-selected):hover svg,.apexcharts-theme-light .apexcharts-zoom-icon:not(.apexcharts-selected):hover svg,.apexcharts-theme-light .apexcharts-zoomin-icon:hover svg,.apexcharts-theme-light .apexcharts-zoomout-icon:hover svg {\n  fill: #333\n}\n\n.apexcharts-menu-icon,.apexcharts-selection-icon {\n  position: relative\n}\n\n.apexcharts-reset-icon {\n  margin-left: 5px\n}\n\n.apexcharts-menu-icon,.apexcharts-reset-icon,.apexcharts-zoom-icon {\n  transform: scale(.85)\n}\n\n.apexcharts-zoomin-icon,.apexcharts-zoomout-icon {\n  transform: scale(.7)\n}\n\n.apexcharts-zoomout-icon {\n  margin-right: 3px\n}\n\n.apexcharts-pan-icon {\n  transform: scale(.62);\n  position: relative;\n  left: 1px;\n  top: 0\n}\n\n.apexcharts-pan-icon svg {\n  fill: #fff;\n  stroke: #6e8192;\n  stroke-width: 2\n}\n\n.apexcharts-pan-icon.apexcharts-selected svg {\n  stroke: #008ffb\n}\n\n.apexcharts-pan-icon:not(.apexcharts-selected):hover svg {\n  stroke: #333\n}\n\n.apexcharts-toolbar {\n  position: absolute;\n  z-index: 11;\n  max-width: 176px;\n  text-align: right;\n  border-radius: 3px;\n  padding: 0 6px 2px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center\n}\n\n.apexcharts-menu {\n  background: #fff;\n  position: absolute;\n  top: 100%;\n  border: 1px solid #ddd;\n  border-radius: 3px;\n  padding: 3px;\n  right: 10px;\n  opacity: 0;\n  min-width: 110px;\n  transition: .15s ease all;\n  pointer-events: none\n}\n\n.apexcharts-menu.apexcharts-menu-open {\n  opacity: 1;\n  pointer-events: all;\n  transition: .15s ease all\n}\n\n.apexcharts-menu-item {\n  padding: 6px 7px;\n  font-size: 12px;\n  cursor: pointer\n}\n\n.apexcharts-theme-light .apexcharts-menu-item:hover {\n  background: #eee\n}\n\n.apexcharts-theme-dark .apexcharts-menu {\n  background: rgba(0,0,0,.7);\n  color: #fff\n}\n\n@media screen and (min-width:768px) {\n  .apexcharts-canvas:hover .apexcharts-toolbar {\n      opacity: 1\n  }\n}\n\n.apexcharts-canvas .apexcharts-element-hidden,.apexcharts-datalabel.apexcharts-element-hidden,.apexcharts-hide .apexcharts-series-points {\n  display: none;\n}\n\n.apexcharts-hidden-element-shown {\n  opacity: 1;\n  transition: 0.25s ease all;\n}\n.apexcharts-datalabel,.apexcharts-datalabel-label,.apexcharts-datalabel-value,.apexcharts-datalabels,.apexcharts-pie-label {\n  cursor: default;\n  pointer-events: none\n}\n\n.apexcharts-pie-label-delay {\n  opacity: 0;\n  animation-name: opaque;\n  animation-duration: .3s;\n  animation-fill-mode: forwards;\n  animation-timing-function: ease\n}\n\n.apexcharts-radialbar-label {\n  cursor: pointer;\n}\n\n.apexcharts-annotation-rect,.apexcharts-area-series .apexcharts-area,.apexcharts-area-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,.apexcharts-gridline,.apexcharts-line,.apexcharts-line-series .apexcharts-series-markers .apexcharts-marker.no-pointer-events,.apexcharts-point-annotation-label,.apexcharts-radar-series path,.apexcharts-radar-series polygon,.apexcharts-toolbar svg,.apexcharts-tooltip .apexcharts-marker,.apexcharts-xaxis-annotation-label,.apexcharts-yaxis-annotation-label,.apexcharts-zoom-rect {\n  pointer-events: none\n}\n\n.apexcharts-marker {\n  transition: .15s ease all\n}\n\n.resize-triggers {\n  animation: 1ms resizeanim;\n  visibility: hidden;\n  opacity: 0;\n  height: 100%;\n  width: 100%;\n  overflow: hidden\n}\n\n.contract-trigger:before,.resize-triggers,.resize-triggers>div {\n  content: " ";\n  display: block;\n  position: absolute;\n  top: 0;\n  left: 0\n}\n\n.resize-triggers>div {\n  height: 100%;\n  width: 100%;\n  background: #eee;\n  overflow: auto\n}\n\n.contract-trigger:before {\n  overflow: hidden;\n  width: 200%;\n  height: 200%\n}\n\n.apexcharts-bar-goals-markers{\n  pointer-events: none\n}\n\n.apexcharts-bar-shadows{\n  pointer-events: none\n}\n\n.apexcharts-rangebar-goals-markers{\n  pointer-events: none\n}';
                var c = (null === (l = e.opts.chart) || void 0 === l ? void 0 : l.nonce) || e.w.config
                  .chart.nonce;
                c && o.setAttribute("nonce", c), r ? s.prepend(o) : n.head.appendChild(o)
              }
              var d = e.create(e.w.config.series, {});
              if (!d) return t(e);
              e.mount(d).then(function() {
                "function" == typeof e.w.config.chart.events.mounted && e.w.config.chart.events
                  .mounted(e, e.w), e.events.fireEvent("mounted", [e, e.w]), t(d)
              }).catch(function(g) {
                i(g)
              })
            } else i(new Error("Element not found"))
          })
        }
      }, {
        key: "create",
        value: function(e, t) {
          var i = this.w;
          new rt(this).initModules();
          var a = this.w.globals;
          if (a.noData = !1, a.animationEnded = !1, this.responsive.checkResponsiveConfig(t), i.config.xaxis
            .convertedCatToNumeric && new ve(i.config).convertCatToNumericXaxis(i.config, this.ctx), null ===
            this.el || (this.core.setupElements(), "treemap" === i.config.chart.type && (i.config.grid
              .show = !1, i.config.yaxis[0].show = !1), 0 === a.svgWidth)) return a.animationEnded = !0, null;
          var s = q.checkComboSeries(e, i.config.chart.type);
          a.comboCharts = s.comboCharts, a.comboBarCount = s.comboBarCount;
          var r = e.every(function(c) {
            return c.data && 0 === c.data.length
          });
          (0 === e.length || r && a.collapsedSeries.length < 1) && this.series.handleNoData(), this.events
            .setupEventHandlers(), this.data.parseData(e), this.theme.init(), new we(this)
            .setGlobalMarkerSize(), this.formatters.setLabelFormatters(), this.titleSubtitle.draw(), a
            .noData && a.collapsedSeries.length !== a.series.length && !i.config.legend.showForSingleSeries ||
            this.legend.init(), this.series.hasAllSeriesEqualX(), a.axisCharts && (this.core
              .coreCalculations(), "category" !== i.config.xaxis.type && this.formatters.setLabelFormatters(),
              this.ctx.toolbar.minX = i.globals.minX, this.ctx.toolbar.maxX = i.globals.maxX), this.formatters
            .heatmapLabelFormatters(), new q(this).getLargestMarkerSize(), this.dimensions.plotCoords();
          var n = this.core.xySettings();
          this.grid.createGridMask();
          var o = this.core.plotChartType(e, n),
            l = new ue(this);
          return l.bringForward(), i.config.dataLabels.background.enabled && l.dataLabelsBackground(), this
            .core.shiftGraphPosition(), {
              elGraph: o,
              xyRatios: n,
              dimensions: {
                plot: {
                  left: i.globals.translateX,
                  top: i.globals.translateY,
                  width: i.globals.gridWidth,
                  height: i.globals.gridHeight
                }
              }
            }
        }
      }, {
        key: "mount",
        value: function() {
          var e = this,
            t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
            i = this,
            a = i.w;
          return new Promise(function(s, r) {
            if (null === i.el) return r(new Error(
              "Not enough data to display or target element not found"));
            (null === t || a.globals.allSeriesCollapsed) && i.series.handleNoData(), i.grid = new qe(i);
            var n, o, l = i.grid.drawGrid();
            if (i.annotations = new ct(i), i.annotations.drawImageAnnos(), i.annotations.drawTextAnnos(),
              "back" === a.config.grid.position && (l && a.globals.dom.elGraphical.add(l.el), null != l &&
                null !== (n = l.elGridBorders) && void 0 !== n && n.node && a.globals.dom.elGraphical.add(
                  l.elGridBorders)), Array.isArray(t.elGraph))
              for (var c = 0; c < t.elGraph.length; c++) a.globals.dom.elGraphical.add(t.elGraph[c]);
            else a.globals.dom.elGraphical.add(t.elGraph);
            "front" === a.config.grid.position && (l && a.globals.dom.elGraphical.add(l.el), null != l &&
                null !== (o = l.elGridBorders) && void 0 !== o && o.node && a.globals.dom.elGraphical.add(
                  l.elGridBorders)), "front" === a.config.xaxis.crosshairs.position && i.crosshairs
              .drawXCrosshairs(), "front" === a.config.yaxis[0].crosshairs.position && i.crosshairs
              .drawYCrosshairs(), "treemap" !== a.config.chart.type && i.axes.drawAxis(a.config.chart
                .type, l);
            var d = new ke(e.ctx, l),
              g = new Ye(e.ctx, l);
            if (null !== l && (d.xAxisLabelCorrections(l.xAxisTickWidth), g.setYAxisTextAlignments(), a
                .config.yaxis.map(function(f, x) {
                  -1 === a.globals.ignoreYAxisIndexes.indexOf(x) && g.yAxisTitleRotate(x, f.opposite)
                })), i.annotations.drawAxesAnnotations(), !a.globals.noData) {
              if (a.config.tooltip.enabled && !a.globals.noData && i.w.globals.tooltip.drawTooltip(t
                  .xyRatios), a.globals.axisCharts && (a.globals.isXNumeric || a.config.xaxis
                  .convertedCatToNumeric || a.globals.isRangeBar))(a.config.chart.zoom.enabled || a.config
                .chart.selection && a.config.chart.selection.enabled || a.config.chart.pan && a.config
                .chart.pan.enabled) && i.zoomPanSelection.init({
                xyRatios: t.xyRatios
              });
              else {
                var p = a.config.chart.toolbar.tools;
                ["zoom", "zoomin", "zoomout", "selection", "pan", "reset"].forEach(function(f) {
                  p[f] = !1
                })
              }
              a.config.chart.toolbar.show && !a.globals.allSeriesCollapsed && i.toolbar.createToolbar()
            }
            a.globals.memory.methodsToExec.length > 0 && a.globals.memory.methodsToExec.forEach(function(
              f) {
              f.method(f.params, !1, f.context)
            }), a.globals.axisCharts || a.globals.noData || i.core.resizeNonAxisCharts(), s(i)
          })
        }
      }, {
        key: "destroy",
        value: function() {
          var e, t;
          window.removeEventListener("resize", this.windowResizeHandler), (t = Oe.get(e = this
            .parentResizeHandler)) && (t.disconnect(), Oe.delete(e));
          var i = this.w.config.chart.id;
          i && Apex._chartInstances.forEach(function(a, s) {
            a.id === P.escapeString(i) && Apex._chartInstances.splice(s, 1)
          }), new nt(this.ctx).clear({
            isUpdating: !1
          })
        }
      }, {
        key: "updateOptions",
        value: function(e) {
          var t = this,
            i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            a = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
            s = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3],
            r = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4],
            n = this.w;
          return n.globals.selection = void 0, e.series && (this.series.resetSeries(!1, !0, !1), e.series
              .length && e.series[0].data && (e.series = e.series.map(function(o, l) {
                return t.updateHelpers._extendSeries(o, l)
              })), this.updateHelpers.revertDefaultAxisMinMax()), e.xaxis && (e = this.updateHelpers
              .forceXAxisUpdate(e)), e.yaxis && (e = this.updateHelpers.forceYAxisUpdate(e)), n.globals
            .collapsedSeriesIndices.length > 0 && this.series.clearPreviousPaths(), e.theme && (e = this.theme
              .updateThemeOptions(e)), this.updateHelpers._updateOptions(e, i, a, s, r)
        }
      }, {
        key: "updateSeries",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
            t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
            i = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
          return this.series.resetSeries(!1), this.updateHelpers.revertDefaultAxisMinMax(), this.updateHelpers
            ._updateSeries(e, t, i)
        }
      }, {
        key: "appendSeries",
        value: function(e) {
          var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
            i = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
            a = this.w.config.series.slice();
          return a.push(e), this.series.resetSeries(!1), this.updateHelpers.revertDefaultAxisMinMax(), this
            .updateHelpers._updateSeries(a, t, i)
        }
      }, {
        key: "appendData",
        value: function(e) {
          var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
            i = this;
          i.w.globals.dataChanged = !0, i.series.getPreviousPaths();
          for (var a = i.w.config.series.slice(), s = 0; s < a.length; s++)
            if (null != e[s])
              for (var r = 0; r < e[s].data.length; r++) a[s].data.push(e[s].data[r]);
          return i.w.config.series = a, t && (i.w.globals.initialSeries = P.clone(i.w.config.series)), this
            .update()
        }
      }, {
        key: "update",
        value: function(e) {
          var t = this;
          return new Promise(function(i, a) {
            new nt(t.ctx).clear({
              isUpdating: !0
            });
            var s = t.create(t.w.config.series, e);
            if (!s) return i(t);
            t.mount(s).then(function() {
              "function" == typeof t.w.config.chart.events.updated && t.w.config.chart.events.updated(
                t, t.w), t.events.fireEvent("updated", [t, t.w]), t.w.globals.isDirty = !0, i(t)
            }).catch(function(r) {
              a(r)
            })
          })
        }
      }, {
        key: "getSyncedCharts",
        value: function() {
          var e = this.getGroupedCharts(),
            t = [this];
          return e.length && (t = [], e.forEach(function(i) {
            t.push(i)
          })), t
        }
      }, {
        key: "getGroupedCharts",
        value: function() {
          var e = this;
          return Apex._chartInstances.filter(function(t) {
            if (t.group) return !0
          }).map(function(t) {
            return e.w.config.chart.group === t.group ? t.chart : e
          })
        }
      }, {
        key: "toggleSeries",
        value: function(e) {
          return this.series.toggleSeries(e)
        }
      }, {
        key: "highlightSeriesOnLegendHover",
        value: function(e, t) {
          return this.series.toggleSeriesOnHover(e, t)
        }
      }, {
        key: "showSeries",
        value: function(e) {
          this.series.showSeries(e)
        }
      }, {
        key: "hideSeries",
        value: function(e) {
          this.series.hideSeries(e)
        }
      }, {
        key: "isSeriesHidden",
        value: function(e) {
          this.series.isSeriesHidden(e)
        }
      }, {
        key: "resetSeries",
        value: function() {
          this.series.resetSeries(!(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], !(
            arguments.length > 1 && void 0 !== arguments[1]) || arguments[1])
        }
      }, {
        key: "addEventListener",
        value: function(e, t) {
          this.events.addEventListener(e, t)
        }
      }, {
        key: "removeEventListener",
        value: function(e, t) {
          this.events.removeEventListener(e, t)
        }
      }, {
        key: "addXaxisAnnotation",
        value: function(e) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
            a = this;
          i && (a = i), a.annotations.addXaxisAnnotationExternal(e, !(arguments.length > 1 && void 0 !==
            arguments[1]) || arguments[1], a)
        }
      }, {
        key: "addYaxisAnnotation",
        value: function(e) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
            a = this;
          i && (a = i), a.annotations.addYaxisAnnotationExternal(e, !(arguments.length > 1 && void 0 !==
            arguments[1]) || arguments[1], a)
        }
      }, {
        key: "addPointAnnotation",
        value: function(e) {
          var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
            a = this;
          i && (a = i), a.annotations.addPointAnnotationExternal(e, !(arguments.length > 1 && void 0 !==
            arguments[1]) || arguments[1], a)
        }
      }, {
        key: "clearAnnotations",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0,
            t = this;
          e && (t = e), t.annotations.clearAnnotations(t)
        }
      }, {
        key: "removeAnnotation",
        value: function(e) {
          var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0,
            i = this;
          t && (i = t), i.annotations.removeAnnotation(i, e)
        }
      }, {
        key: "getChartArea",
        value: function() {
          return this.w.globals.dom.baseEl.querySelector(".apexcharts-inner")
        }
      }, {
        key: "getSeriesTotalXRange",
        value: function(e, t) {
          return this.coreUtils.getSeriesTotalsXRange(e, t)
        }
      }, {
        key: "getHighestValueInSeries",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
          return new Ee(this.ctx).getMinYMaxY(e).highestY
        }
      }, {
        key: "getLowestValueInSeries",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
          return new Ee(this.ctx).getMinYMaxY(e).lowestY
        }
      }, {
        key: "getSeriesTotal",
        value: function() {
          return this.w.globals.seriesTotals
        }
      }, {
        key: "toggleDataPointSelection",
        value: function(e, t) {
          return this.updateHelpers.toggleDataPointSelection(e, t)
        }
      }, {
        key: "zoomX",
        value: function(e, t) {
          this.ctx.toolbar.zoomUpdateOptions(e, t)
        }
      }, {
        key: "setLocale",
        value: function(e) {
          this.localization.setCurrentLocaleValues(e)
        }
      }, {
        key: "dataURI",
        value: function(e) {
          return new Pe(this.ctx).dataURI(e)
        }
      }, {
        key: "exportToCSV",
        value: function() {
          var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          return new Pe(this.ctx).exportToCSV(e)
        }
      }, {
        key: "paper",
        value: function() {
          return this.w.globals.dom.Paper
        }
      }, {
        key: "_parentResizeCallback",
        value: function() {
          this.w.globals.animationEnded && this.w.config.chart.redrawOnParentResize && this._windowResize()
        }
      }, {
        key: "_windowResize",
        value: function() {
          var e = this;
          clearTimeout(this.w.globals.resizeTimer), this.w.globals.resizeTimer = window.setTimeout(
        function() {
            e.w.globals.resized = !0, e.w.globals.dataChanged = !1, e.ctx.update()
          }, 150)
        }
      }, {
        key: "_windowResizeHandler",
        value: function() {
          var e = this.w.config.chart.redrawOnWindowResize;
          "function" == typeof e && (e = e()), e && this._windowResize()
        }
      }], [{
        key: "getChartByID",
        value: function(e) {
          var t = P.escapeString(e);
          if (Apex._chartInstances) {
            var i = Apex._chartInstances.filter(function(a) {
              return a.id === t
            })[0];
            return i && i.chart
          }
        }
      }, {
        key: "initOnLoad",
        value: function() {
          for (var e = document.querySelectorAll("[data-apexcharts]"), t = 0; t < e.length; t++) new w(e[t],
            JSON.parse(e[t].getAttribute("data-options"))).render()
        }
      }, {
        key: "exec",
        value: function(e, t) {
          var i = this.getChartByID(e);
          if (i) {
            i.w.globals.isExecCalled = !0;
            var a = null;
            if (-1 !== i.publicMethods.indexOf(t)) {
              for (var s = arguments.length, r = new Array(s > 2 ? s - 2 : 0), n = 2; n < s; n++) r[n - 2] =
                arguments[n];
              a = i[t].apply(i, r)
            }
            return a
          }
        }
      }, {
        key: "merge",
        value: function(e, t) {
          return P.extend(e, t)
        }
      }]), w
    }();
  return Gt
});