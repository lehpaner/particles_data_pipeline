# decompyle3 version 3.9.4.dev0
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.11.15 (main, Mar  3 2026, 09:26:23) [GCC 13.3.0]
# Embedded file name: services\discover.py
import logging, socket
from zeroconf import ServiceBrowser, ServiceListener, Zeroconf

class Discover:
    rapidcp_discovered = {}

    class _Listener(ServiceListener):

        def update_service(self, zc, type_, name):
            """
            When Service of machine has been updated.

            Ip may have changed
            """
            info = zc.get_service_info(type_, name)
            if info:
                if hasattr(info, "properties"):
                    serial = info.properties[b'serialno'].decode("utf-8")
                    logging.debug(f"Machine Rapid C+ serial {serial} updated")
                    if serial in Discover.rapidcp_discovered:
                        Discover.rapidcp_discovered[serial] = {'ip':(socket.inet_ntop)(socket.AF_INET, info.addresses[0]),  'port':info.port}

        def remove_service(self, zc, type_, name):
            info = zc.get_service_info(type_, name)
            if info:
                if hasattr(info, "properties"):
                    serial = info.properties[b'serialno'].decode("utf-8")
                    logging.debug(f"Machine Rapid C+ serial {serial} removed")
                    if serial in Discover.rapidcp_discovered:
                        del Discover.rapidcp_discovered[serial]

        def add_service(self, zc, type_, name):
            info = zc.get_service_info(type_, name)
            if info:
                if hasattr(info, "properties"):
                    serial = info.properties[b'serialno'].decode("utf-8")
                    if info.addresses:
                        logging.debug(f"Machine Rapid C+ serial '{serial}' added, service info: {info}")
                        Discover.rapidcp_discovered[serial] = {'ip':(socket.inet_ntop)(socket.AF_INET, info.addresses[0]), 
                         'port':info.port}
                    else:
                        logging.debug(f"Machine Rapid C+ serial '{serial}' added, but no ip found")

    def __init__(self):
        self.zeroconf = Zeroconf()
        listener = self._Listener()
        browser = ServiceBrowser(self.zeroconf, "_plair._tcp.local.", listener)

    def close(self):
        self.zeroconf.close()
