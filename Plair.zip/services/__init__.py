# decompyle3 version 3.9.4.dev0
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.11.15 (main, Mar  3 2026, 09:26:23) [GCC 13.3.0]
# Embedded file name: services\__init__.py
pass
