# decompyle3 version 3.9.4.dev0
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.11.15 (main, Mar  3 2026, 09:26:23) [GCC 13.3.0]
# Embedded file name: main.py
import logging, os, sys
from services.discover import Discover
logging.basicConfig(format="%(asctime)s\t%(levelname)s\t%(message)s",
  level=(logging.INFO))
log = logging.getLogger("werkzeug")
log.disabled = True
import signal, sys, webbrowser
from threading import Timer
from flask import request, send_from_directory
from flask.cli import FlaskGroup
from app import create_app
PLAIRGRID_SERVER_HOST = os.getenv("PLAIRGRID_SERVER_HOST", "localhost")
PLAIRGRID_SERVER_PORT = os.getenv("PLAIRGRID_SERVER_PORT", 5104)
PID = os.getpid()
if getattr(sys, "frozen", False):
    if hasattr(sys, "_MEIPASS"):
        application_path = sys._MEIPASS
    else:
        application_path = os.path.dirname(sys.executable)
else:
    application_path = os.path.dirname(__file__)
app = create_app()
cli = FlaskGroup(create_app=create_app)
__angular_paths = []
__angular_default_path = "index.html"
__root = os.path.join(application_path, "dist")
for root, subdirs, files in os.walk(__root):
    if len(root) > len(__root):
        root += "/"
    for file in files:
        absolute_path = os.path.join(root, file)
        relativePath = absolute_path[absolute_path.index("dist") + len("dist") + 1:].replace(os.sep, "/")
        __angular_paths.append(relativePath)

@app.route("/<path:path>")
@app.route("/", defaults={"path": ""})
def angular(path):
    if path not in __angular_paths:
        path = __angular_default_path
    return send_from_directory(__root, path)


def shutdown_server():
    pid = os.getpid()
    assert pid == PID
    os.kill(pid, signal.SIGINT)


@app.errorhandler(500)
def server_error(e):
    return (
     "An internal error occurred [main.py] %s" % e, 500)


@app.route("/api/shutdown", methods=["GET"])
def shutdown():
    shutdown_server()
    logging.info("PlairGrid server shutting down...")
    return ('PlairGrid server shutting down...', 200)


def open_browser():
    webbrowser.open_new(f"http://localhost:{PLAIRGRID_SERVER_PORT}")


@app.before_request
def log_request_info():
    pass


if __name__ == "__main__":
    debug_mode = os.getenv("PLAIRGRID_BACKEND_DEBUG", False)
    app.config["machine_discovery"] = Discover()
    logging.info("PlairGrid server starting...")
    if not debug_mode:
        Timer(1.5, open_browser).start()
    app.run(debug=debug_mode,
      host=PLAIRGRID_SERVER_HOST,
      port=PLAIRGRID_SERVER_PORT)
    logging.info("PlairGrid server shutdown.")
