# decompyle3 version 3.9.4.dev0
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.11.15 (main, Mar  3 2026, 09:26:23) [GCC 13.3.0]
# Embedded file name: app.py
import os
from flask import Flask
from flask_cors import CORS
cors = CORS()

def create_app(script_info=None):
    nonlocal app
    app = Flask(__name__)
    CORS(app)
    app_settings = os.getenv("APP_SETTINGS")
    app.config.from_object(app_settings)
    cors.init_app(app)
    from endpoints.local import bp as local_bp
    from endpoints.remote import bp as remote_bp
    app.register_blueprint(local_bp)
    app.register_blueprint(remote_bp)

    @app.shell_context_processor
    def ctx():
        return {'app':app, 
         'conn':None}

    return app
