// TsiTcpClient.cs
// Wrapper TCP per comunicazione Modbus con strumento TSI.
// Estratto da TSI.Communication.TSI_IPCommunication (TrakProLiteClassLibrary.dll).
//
// Il client apre e tiene aperta una TcpClient per tutta la sessione
// (come nel metodo ReadSampleRecords del sorgente originale):
//   connect → write packet → read response → ... → close
//
// ReceiveTimeout originale: 1000 ms per lettura record,
//                           2000 ms per operazioni singole.

using System.Net.Sockets;

namespace TsiConsole;

public sealed class TsiTcpClient : IDisposable
{
    private TcpClient?     _tcp;
    private NetworkStream? _stream;
    private readonly string _ip;
    private readonly int    _port;
    private readonly int    _connectTimeoutMs;
    private readonly int    _receiveTimeoutMs;

    // Buffer di ricezione — dimensione uguale al ReceiveBufferSize di TcpClient (65536)
    private readonly byte[] _rxBuf = new byte[65536];

    public string  IP      => _ip;
    public int     Port    => _port;
    public bool    Connected => _tcp?.Connected == true;

    public TsiTcpClient(string ip, int port = 502,
                        int connectTimeoutMs = 3000,
                        int receiveTimeoutMs = 2000)
    {
        _ip               = ip;
        _port             = port;
        _connectTimeoutMs = connectTimeoutMs;
        _receiveTimeoutMs = receiveTimeoutMs;
    }

    // ── Connessione ───────────────────────────────────────────────────────────

    /// <summary>
    /// Apre la connessione TCP. Lancia SocketException in caso di errore.
    /// </summary>
    public void Connect()
    {
        _tcp = new TcpClient();
        // Timeout di connessione esplicito (non disponibile in TcpClient nativo)
        var task = _tcp.ConnectAsync(_ip, _port);
        if (!task.Wait(_connectTimeoutMs))
        {
            _tcp.Dispose();
            throw new TimeoutException(
                $"Connessione a {_ip}:{_port} non riuscita in {_connectTimeoutMs} ms.");
        }
        _stream = _tcp.GetStream();
        _stream.ReadTimeout = _receiveTimeoutMs;
    }

    /// <summary>Chiude la connessione.</summary>
    public void Disconnect()
    {
        _stream?.Close();
        _tcp?.Close();
        _stream = null;
        _tcp    = null;
    }

    public void Dispose() => Disconnect();

    // ── Send / Receive ────────────────────────────────────────────────────────

    /// <summary>
    /// Invia un pacchetto Modbus e legge la risposta.
    /// Restituisce una copia dei byte ricevuti (solo i byte significativi).
    /// </summary>
    public byte[] SendReceive(byte[] packet)
    {
        EnsureConnected();
        _stream!.Write(packet, 0, packet.Length);
        int n = _stream.Read(_rxBuf, 0, _rxBuf.Length);
        // restituisce copia della sola parte ricevuta
        byte[] result = new byte[n];
        Array.Copy(_rxBuf, result, n);
        return result;
    }

    /// <summary>
    /// Invia un pacchetto e scarta la risposta (usato per Write FC6
    /// il cui ACK non è necessario leggere prima della lettura successiva).
    /// </summary>
    public void Send(byte[] packet)
    {
        EnsureConnected();
        _stream!.Write(packet, 0, packet.Length);
        // leggi e scarta ACK (6-12 byte) per svuotare il buffer
        _stream.Read(_rxBuf, 0, _rxBuf.Length);
    }

    private void EnsureConnected()
    {
        if (_stream == null || !Connected)
            throw new InvalidOperationException(
                "Chiamare Connect() prima di inviare dati.");
    }
}
