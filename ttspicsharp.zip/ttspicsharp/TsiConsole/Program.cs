// Program.cs — TSI Console App
// Connette a un particle counter TSI via Modbus TCP,
// legge le informazioni del device e i record di campionamento.
//
// Uso:
//   TsiConsole <ip> [port] [--max <n>] [--from <index>] [--info-only]
//
// Esempi:
//   TsiConsole 192.168.1.50
//   TsiConsole 192.168.1.50 502 --max 10
//   TsiConsole 192.168.1.50 502 --from 5 --max 3
//   TsiConsole 192.168.1.50 502 --info-only

using TsiConsole;

// ── Parsing argomenti ─────────────────────────────────────────────────────────

if (args.Length == 0)
{
    Console.Error.WriteLine("Uso: TsiConsole <ip> [port] [--max <n>] [--from <idx>] [--info-only]");
    return 1;
}

string ip         = args[0];
int    port       = 502;
int    maxRecords = 50;
uint   fromIndex  = 0;
bool   infoOnly   = false;

for (int i = 1; i < args.Length; i++)
{
    switch (args[i])
    {
        case "--max"       when i + 1 < args.Length: maxRecords = int.Parse(args[++i]);  break;
        case "--from"      when i + 1 < args.Length: fromIndex  = uint.Parse(args[++i]); break;
        case "--info-only":                           infoOnly   = true;                  break;
        default:
            if (int.TryParse(args[i], out int p)) port = p;
            break;
    }
}

// ── Connessione e lettura device ──────────────────────────────────────────────

Print.Header("TSI Particle Counter — Console Reader");
Console.WriteLine($"  Indirizzo : {ip}:{port}");
Console.WriteLine($"  Max record: {maxRecords}  |  Da indice: {fromIndex}");
Console.WriteLine();

using var client = new TsiTcpClient(ip, port, connectTimeoutMs: 4000, receiveTimeoutMs: 2000);
var reader = new TsiDeviceReader(client);

try
{
    Print.Step("Connessione...");
    DeviceInfo info = reader.Connect();
    Print.Ok("Connesso");
    Console.WriteLine();

    // ── Device Info ───────────────────────────────────────────────────────────
    Print.Section("DEVICE INFO");
    Print.Field("Modello",         info.Model);
    Print.Field("Numero di serie", info.Serial);
    Print.Field("MapRev",          info.MapRev.ToString());
    Print.Field("Firmware",        info.FirmwareVersion.ToString());
    Print.Field("Canali",          info.NumberOfChannels.ToString());
    Print.Field("Flow nominale",   $"{info.NominalFlowRate} {info.FlowUnit}");
    Print.Field("Data Integrity",  info.HasDataIntegrity ? "Sì" : "No");
    Print.Field("Viable Counts",   info.ViableCounts     ? "Sì" : "No");
    Print.Field("Unicode",         info.Unicode           ? "Sì" : "No");
    Print.Field("Locations",       info.NumberOfLocations.ToString());
    Print.Field("Recipes",         info.NumberOfRecipes.ToString());

    // Dimensioni canali configurati
    var configuredSizes = info.ChannelSizes
        .Take(info.NumberOfChannels)
        .Where(s => s > 0)
        .Select(s => $"{s / 1000.0:F3} µm")
        .ToList();
    if (configuredSizes.Count > 0)
        Print.Field("Canali µm", string.Join("  ", configuredSizes));

    Console.WriteLine();

    if (infoOnly)
    {
        Print.Ok("Modalità --info-only: lettura record saltata.");
        return 0;
    }

    // ── Numero di campioni ────────────────────────────────────────────────────
    Print.Step("Lettura numero campioni...");
    uint totalSamples = reader.ReadNumberOfSamples();
    Print.Ok($"Campioni in memoria: {totalSamples}");
    Console.WriteLine();

    if (totalSamples == 0)
    {
        Console.WriteLine("  Nessun campione presente nello strumento.");
        return 0;
    }

    // Calcola range da leggere
    uint toRead = Math.Min((uint)maxRecords, totalSamples - fromIndex);
    if (fromIndex >= totalSamples)
    {
        Console.Error.WriteLine($"  Indice {fromIndex} fuori range (totale: {totalSamples}).");
        return 1;
    }

    Print.Section($"RECORD DI CAMPIONAMENTO  (indici {fromIndex}–{fromIndex + toRead - 1} di {totalSamples})");

    // ── Lettura record ────────────────────────────────────────────────────────
    int recPrinted = 0;
    var progress   = new Progress<(uint Done, uint Total)>(p =>
    {
        Console.Write($"\r  Lettura: {p.Done}/{p.Total}   ");
    });

    foreach (var (idx, rec) in reader.ReadRecords(fromIndex, toRead, progress))
    {
        Console.WriteLine();  // a-capo dopo il progresso
        if (rec == null)
        {
            Console.WriteLine($"  [Record {idx}]  ❌ risposta vuota o non valida");
            continue;
        }

        PrintRecord(idx, rec, info.NumberOfChannels);
        recPrinted++;
    }

    Console.WriteLine();
    Print.Ok($"Letti {recPrinted} record su {toRead} richiesti.");
}
catch (TimeoutException ex)
{
    Console.Error.WriteLine($"\n❌ Timeout: {ex.Message}");
    return 2;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"\n❌ Errore: {ex.GetType().Name}: {ex.Message}");
    return 3;
}

return 0;

// ── Stampa record ─────────────────────────────────────────────────────────────

static void PrintRecord(uint idx, TsiRecord rec, int numChannels)
{
    string validity = rec.DataValid ? "✓ Valido" : "✗ Non valido";
    string status   = BuildStatusString(rec);

    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine($"  ┌─ Record #{rec.RecNum}  (indice {idx})");
    Console.ResetColor();
    Console.WriteLine($"  │  Timestamp     : {rec.Timestamp:yyyy-MM-dd HH:mm:ss}");
    Console.WriteLine($"  │  Stato dati    : {validity}");
    Console.WriteLine($"  │  Status device : {status}");
    Console.WriteLine($"  │  Loc. ID       : {rec.LocationId}");
    Console.WriteLine($"  │  Flow rate     : {rec.FlowRate:F2} {rec.FlowType}");
    if (rec.PrecisionFlowRate > 0)
        Console.WriteLine($"  │  Flow prec.    : {rec.PrecisionFlowRate:F4} CFM");
    Console.WriteLine($"  │  Tempo camp.   : {rec.SampleTime.TotalSeconds:F0} s");
    Console.WriteLine($"  │  Modalità      : {rec.CountMode}");

    // Misure ambientali
    if (rec.MeasurementEnabled != 0)
    {
        if ((rec.MeasurementEnabled & 0x01) != 0)
            Console.WriteLine($"  │  Temperatura   : {rec.Temperature:F1} °{rec.TempUnit}");
        if ((rec.MeasurementEnabled & 0x02) != 0)
            Console.WriteLine($"  │  Umidità       : {rec.Humidity:F1} %RH");
        if ((rec.MeasurementEnabled & 0x04) != 0)
            Console.WriteLine($"  │  Velocità aria : {rec.Velocity:F2} m/s");
        if ((rec.MeasurementEnabled & 0x10) != 0)
            Console.WriteLine($"  │  CO₂           : {rec.CO2:F0} ppm");
    }

    // Canali particelle
    Console.WriteLine($"  │");
    Console.WriteLine($"  │  {'Canale',-10} {'Dimensione',12} {'Conteggio',12} {'Allarme',8}");
    Console.WriteLine($"  │  {new string('─', 46)}");
    int channels = Math.Min(numChannels, 16);
    for (int i = 0; i < channels; i++)
    {
        double sizeMicron = rec.ChSizes[i] / 1000.0;
        string alarm      = rec.ChAlarm[i] ? "⚠ SI" : "no";
        if (rec.ChAlarm[i]) Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine($"  │  {$"Ch {i + 1}",-10} {$"{sizeMicron:F3} µm",12} {rec.Counts[i],12:N0} {alarm,8}");
        Console.ResetColor();
    }
    Console.ForegroundColor = ConsoleColor.Cyan;
    Console.WriteLine($"  └{'─',46}");
    Console.ResetColor();
}

static string BuildStatusString(TsiRecord rec)
{
    var parts = new List<string>();
    if (!rec.FlowOk)           parts.Add("FlowError");
    if (!rec.LaserOk)          parts.Add("LaserError");
    if (rec.OpticsDirty)       parts.Add("OpticsDirty");
    if (rec.ScatterAlert)      parts.Add("ScatterAlert");
    if (rec.CalibrationCorrupt) parts.Add("CalCorrupt");
    if (rec.ServiceAlert)      parts.Add("ServiceAlert");
    return parts.Count == 0 ? "OK" : string.Join(" | ", parts);
}

// ── Helper di stampa ──────────────────────────────────────────────────────────

internal static class Print
{
    public static void Header(string text)
    {
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine($"\n{'═',1}{new string('═', text.Length + 4)}");
        Console.WriteLine($"  {text}");
        Console.WriteLine($"{'═',1}{new string('═', text.Length + 4)}");
        Console.ResetColor();
    }

    public static void Section(string text)
    {
        Console.ForegroundColor = ConsoleColor.DarkCyan;
        Console.WriteLine($"\n  ── {text} ──");
        Console.ResetColor();
    }

    public static void Step(string text)
    {
        Console.ForegroundColor = ConsoleColor.Gray;
        Console.Write($"  {text}");
        Console.ResetColor();
    }

    public static void Ok(string text)
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine($" {text}");
        Console.ResetColor();
    }

    public static void Field(string label, string value)
    {
        Console.Write($"    {label,-20}: ");
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine(value);
        Console.ResetColor();
    }
}
