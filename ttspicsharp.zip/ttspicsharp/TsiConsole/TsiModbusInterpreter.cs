// TsiModbusInterpreter.cs
// Decodifica le risposte Modbus grezze nei dati strutturati.
// Trascrizione diretta di TSI.ModbusTCP.ModbusInterpreter (TrakProLiteClassLibrary.dll).
//
// Nota sul byte-order:
//   Il protocollo TSI usa big-endian con swap a coppie di byte.
//   Ogni ushort nel payload viene invertito (Array.Reverse su 2 byte),
//   poi letto con BitConverter (little-endian di default su x86).
//   Per i uint32 e float vengono invertiti 4 byte.

namespace TsiConsole;

// ── Strutture dati risultato ──────────────────────────────────────────────────

public record DeviceInfo(
    ushort  MapRev,
    ushort  FirmwareVersion,
    string  Model,
    string  Serial,
    int     NumberOfChannels,
    decimal NominalFlowRate,
    string  FlowUnit,          // "CFM" | "LPM"
    bool    HasDataIntegrity,
    bool    ViableCounts,
    bool    Unicode,
    ushort  NumberOfLocations,
    ushort  NumberOfRecipes,
    ushort[] ChannelSizes      // µm × 1000 (es. 300 = 0.3 µm)
);

public record TsiRecord(
    uint     RecNum,
    DateTime Timestamp,
    ushort   LocationId,
    string   FlowType,         // "CFM" | "LPM"
    float    FlowRate,         // LPM o CFM
    float    PrecisionFlowRate,
    TimeSpan SampleTime,
    string   CountMode,        // "Differential" | "Cumulative"
    bool     DataValid,
    bool     FlowOk,
    bool     LaserOk,
    bool     OpticsDirty,
    bool     ScatterAlert,
    bool     CalibrationCorrupt,
    bool     ServiceAlert,
    uint[]   Counts,           // [16] conteggi particelle
    ushort[] ChSizes,          // [16] dimensioni µm × 1000
    bool[]   ChAlarm,          // [16] allarmi canale
    float    Temperature,
    string   TempUnit,         // "C" | "F" | "N/A"
    float    Humidity,
    float    Velocity,
    float    Flow,
    float    CO2,
    ushort   MeasurementEnabled,
    ushort   DIUserId
);

// ── Interprete ────────────────────────────────────────────────────────────────

internal static class TsiModbusInterpreter
{
    // ── Helpers interni ───────────────────────────────────────────────────────

    // Numero di byte dati Modbus validi nella risposta.
    // Il byte [8] contiene il byte-count della risposta FC3.
    private static int MsgLen(byte[] msg) => msg.Length > 8 ? msg[8] : 0;

    // Inverti 2 byte in-place a partire da offset, poi leggi ushort.
    private static ushort ReadU16(byte[] msg, int offset)
    {
        Array.Reverse(msg, offset, 2);
        return BitConverter.ToUInt16(msg, offset);
    }

    // Inverti 4 byte in-place a partire da offset, poi leggi uint32.
    private static uint ReadU32(byte[] msg, int offset)
    {
        Array.Reverse(msg, offset, 4);
        return BitConverter.ToUInt32(msg, offset);
    }

    // Inverti 4 byte in-place, poi leggi float32.
    private static float ReadF32(byte[] msg, int offset)
    {
        Array.Reverse(msg, offset, 4);
        return BitConverter.ToSingle(msg, offset);
    }

    // ── Parse Modello ─────────────────────────────────────────────────────────
    // A_GET_MODEL: reg 40003, 8 registri, swap a coppie, ASCII 16 byte.
    public static string ParseModel(byte[] msg)
    {
        if (msg == null || msg.Length < 9 + 16) return "";
        int start = 9;
        int len   = msg[8];                             // byte-count
        for (int i = start; i < start + len; i += 2)
            Array.Reverse(msg, i, 2);
        return System.Text.Encoding.ASCII
            .GetString(msg, start, 16).TrimEnd('\0').Trim();
    }

    // ── Parse Numero di serie ─────────────────────────────────────────────────
    // A_GET_SERIAL: reg 40011, 8 registri, swap a coppie, ASCII.
    public static string ParseSerial(byte[] msg)
    {
        if (msg == null || msg.Length < 9) return "";
        int start = 9;
        int len   = msg[8];
        for (int i = start; i < start + len; i += 2)
            Array.Reverse(msg, i, 2);
        return System.Text.Encoding.ASCII
            .GetString(msg, start, len).TrimEnd('\0').Trim();
    }

    // ── Parse Numero campioni ─────────────────────────────────────────────────
    // A_GET_NUMBER_OF_SAMPLES: reg 42001, 2 registri → uint32 invertito.
    public static uint ParseNumberOfSamples(byte[] msg)
    {
        if (msg == null || msg.Length < 13) return 0;
        Array.Reverse(msg, 9, 4);
        return BitConverter.ToUInt32(msg, 9);
    }

    // ── Parse MapRev + FirmwareVersion ────────────────────────────────────────
    // A_READ_MAPREV_REGISTER: reg 40001, 2 registri.
    // byte 9-10 = mapRev, byte 11-12 = firmwareVersion
    public static (ushort MapRev, ushort FirmwareVersion) ParseMapRev(byte[] msg)
    {
        if (msg == null || msg.Length < 13) return (200, 0);
        Array.Reverse(msg, 9,  2);
        Array.Reverse(msg, 11, 2);
        return (BitConverter.ToUInt16(msg, 9),
                BitConverter.ToUInt16(msg, 11));
    }

    // ── Parse DeviceInfo ──────────────────────────────────────────────────────
    // A_READ_DEVICE_INFO: reg 40002, lunghezza variabile (65/77/89 registri).
    // Trascrizione di ModbusInterpreter.InterpretDeviceInfo.
    public static DeviceInfo? ParseDeviceInfo(byte[] msg, ushort mapRev = 200)
    {
        if (msg == null || msg.Length < 9) return null;

        int msgLen = msg[8];
        int pos    = 9;

        // Swap tutti i byte a coppie nel blocco dati
        for (int i = pos; i < pos + msgLen; i += 2)
            Array.Reverse(msg, i, 2);

        // FirmwareVersion (ushort)
        ushort fwVersion = BitConverter.ToUInt16(msg, pos); pos += 2;

        // Model (16 byte ASCII)
        string model  = System.Text.Encoding.ASCII
            .GetString(msg, pos, 16).TrimEnd('\0').Trim(); pos += 16;

        // Serial (16 byte ASCII)
        string serial = System.Text.Encoding.ASCII
            .GetString(msg, pos, 16).TrimEnd('\0').Trim(); pos += 16;

        // Algorithm ID (16 byte) — skip
        pos += 16;

        // Last calibration date: year, month, day (3 × ushort)
        // ushort già invertiti dal loop sopra → leggi direttamente
        pos += 6; // skip LastCalDate

        // Calibration due date
        pos += 6; // skip CalDueDate

        // NominalFlowRate + FlowUnit
        ushort flowRaw   = BitConverter.ToUInt16(msg, pos); pos += 2;
        bool   isLPM     = (flowRaw & 0x8000) != 0;
        decimal nomFlow  = (decimal)((flowRaw & 0x7FFF) / 100.0);

        // NumberOfChannels
        ushort numChan   = BitConverter.ToUInt16(msg, pos); pos += 2;

        // DeviceFeatures
        ushort devFeat   = BitConverter.ToUInt16(msg, pos); pos += 2;
        bool varBins     = (devFeat & 512)  != 0;
        bool unicode     = (devFeat & 8192) != 0;
        bool handheld    = (devFeat & 1)    != 0;

        // ChannelSizes[16] (16 × ushort = 32 byte)
        ushort[] chSizes = new ushort[16];
        for (int i = 0; i < 16; i++)
        {
            chSizes[i] = BitConverter.ToUInt16(msg, pos); pos += 2;
        }

        // DeviceFeatures2
        ushort devFeat2   = BitConverter.ToUInt16(msg, pos); pos += 2;
        bool viableCounts = (devFeat2 & 1)  != 0;
        bool hasDI        = (devFeat2 & 16) != 0;

        // Skip 16 byte reserved/padding
        pos += 16;

        // supportedMeasurements (ushort)
        pos += 2;  // skip
        pos += 6;  // skip 3 ushort

        // NumberOfLocations
        ushort numLoc = BitConverter.ToUInt16(msg, pos); pos += 2;
        pos += 2;  // LocationLabelLength

        // NumberOfRecipes
        ushort numRcp = BitConverter.ToUInt16(msg, pos);

        return new DeviceInfo(
            MapRev:            mapRev,
            FirmwareVersion:   fwVersion,
            Model:             model,
            Serial:            serial,
            NumberOfChannels:  numChan,
            NominalFlowRate:   nomFlow,
            FlowUnit:          isLPM ? "LPM" : "CFM",
            HasDataIntegrity:  hasDI,
            ViableCounts:      viableCounts,
            Unicode:           unicode,
            NumberOfLocations: numLoc,
            NumberOfRecipes:   numRcp,
            ChannelSizes:      chSizes
        );
    }

    // ── Parse Record ──────────────────────────────────────────────────────────
    // A_READ_RECORD: reg 42005, 118/119 registri.
    // Trascrizione fedele di ModbusInterpreter.InterpretRecord.
    public static TsiRecord? ParseRecord(byte[] msg, bool hasDataIntegrity = false)
    {
        if (msg == null || msg.Length < 9) return null;

        int msgLen = msg[8];                      // byte-count
        int pos    = 9;

        // recNum (uint32)
        uint recNum = ReadU32(msg, pos); pos += 4;

        // DateTime: year, month, day, hour, minute, second (6 × ushort)
        for (int i = pos; i < pos + 12; i += 2)
            Array.Reverse(msg, i, 2);
        ushort yr  = BitConverter.ToUInt16(msg, pos);     pos += 2;
        ushort mo  = BitConverter.ToUInt16(msg, pos);     pos += 2;
        ushort dy  = BitConverter.ToUInt16(msg, pos);     pos += 2;
        ushort hr  = BitConverter.ToUInt16(msg, pos);     pos += 2;
        ushort mi  = BitConverter.ToUInt16(msg, pos);     pos += 2;
        ushort sc  = BitConverter.ToUInt16(msg, pos);     pos += 2;
        DateTime ts;
        try   { ts = new DateTime(yr, mo, dy, hr, mi, sc); }
        catch { ts = DateTime.MinValue; }

        // skip 4 byte padding (indicato nel C# originale con num7 + 4)
        pos += 4;

        // ViableDetectionSensitivity (ushort)
        ushort viableSens = ReadU16(msg, pos); pos += 2;

        // PrecisionFlowRate (float32)
        float precFlow = ReadF32(msg, pos); pos += 4;

        // DeviceStatus (ushort)
        ushort devStatus = ReadU16(msg, pos); pos += 2;
        bool flowOk          = (devStatus & 0x0001) == 0;
        bool flowStopped     = (devStatus & 0x0002) != 0;
        bool laserOk         = (devStatus & 0x0004) == 0;
        bool scatterAlert    = (devStatus & 0x0008) != 0;
        bool opticsDirty     = (devStatus & 0x0010) != 0;
        bool calCorrupt      = (devStatus & 0x0020) != 0;
        bool serviceAlert    = (devStatus & 0x4000) != 0;
        bool dataValid       = (devStatus & 0x8000) == 0;

        // chAlarm[16] (bitmask ushort)
        ushort alarmMask = ReadU16(msg, pos); pos += 2;
        bool[] chAlarm = new bool[16];
        for (int y = 0; y < 16; y++)
            chAlarm[y] = (alarmMask & (1 << y)) != 0;

        // FlowRate + FlowType (ushort)
        ushort flowRaw  = ReadU16(msg, pos); pos += 2;
        bool   isLPM    = (flowRaw & 0x8000) != 0;
        ushort flowX100 = (ushort)(flowRaw & 0x7FFF);
        float  flowRate = flowX100 / 100.0f;

        // sampleTime value (uint32) + timeUnit (ushort)
        uint sampleVal  = ReadU32(msg, pos); pos += 4;
        ushort timeUnit = ReadU16(msg, pos); pos += 2;
        TimeSpan sampleTime = timeUnit == 0
            ? TimeSpan.FromSeconds(sampleVal / 1000.0)
            : TimeSpan.FromSeconds(sampleVal);

        // CountMode / UnitMode (ushort)
        ushort modeRaw  = ReadU16(msg, pos); pos += 2;
        string countMode = ((modeRaw & 0xFF00) == 0) ? "Differential" : "Cumulative";

        // LocNumber (ushort)
        ushort locNum = ReadU16(msg, pos); pos += 2;

        // counts[16] (16 × uint32 = 64 byte)
        uint[] counts = new uint[16];
        for (int i = 0; i < 16; i++)
        {
            counts[i] = ReadU32(msg, pos); pos += 4;
        }

        // chSizes[16] (16 × ushort = 32 byte)
        ushort[] chSizes = new ushort[16];
        for (int i = 0; i < 16; i++)
        {
            chSizes[i] = ReadU16(msg, pos); pos += 2;
        }

        // MeasurementEnabled (vicino alla fine del buffer)
        int meOffset = hasDataIntegrity ? msgLen - 4 : msgLen - 2;
        ushort measurementEnabled = 0;
        if (9 + meOffset + 2 <= msg.Length)
        {
            Array.Reverse(msg, 9 + meOffset, 2);
            measurementEnabled = BitConverter.ToUInt16(msg, 9 + meOffset);
        }

        // Misure ambientali opzionali
        float  temp = 0, hum = 0, vel = 0, flow = 0, co2 = 0;
        string tempUnit = "N/A";

        if ((measurementEnabled & 0x01) != 0)   // Temperatura
        {
            ushort tu = ReadU16(msg, pos); pos += 2;
            tempUnit  = tu == 0x43 ? "C" : tu == 0x46 ? "F" : "N/A";
            temp      = ReadF32(msg, pos); pos += 4;
        }
        if ((measurementEnabled & 0x02) != 0)   // Umidità
        {
            pos += 2;
            hum = ReadF32(msg, pos); pos += 4;
        }
        if ((measurementEnabled & 0x04) != 0)   // Velocità
        {
            pos += 2;
            vel = ReadF32(msg, pos); pos += 4;
        }
        if ((measurementEnabled & 0x08) != 0)   // Flow
        {
            pos += 2;
            flow = ReadF32(msg, pos); pos += 4;
        }
        if ((measurementEnabled & 0x10) != 0)   // CO2
        {
            pos += 2;
            co2 = ReadF32(msg, pos); pos += 4;
        }

        // DataIntegrity User ID (ushort, ultimi 2 byte)
        ushort diUserId = 0;
        if (hasDataIntegrity && 9 + msgLen - 2 + 2 <= msg.Length)
        {
            Array.Reverse(msg, 9 + msgLen - 2, 2);
            diUserId = BitConverter.ToUInt16(msg, 9 + msgLen - 2);
        }

        // Se il record era Cumulative, converti in Differential
        // (logica originale in InterpretRecord)
        if (countMode == "Cumulative")
        {
            for (int i = 0; i < 15; i++)
                counts[i] = counts[i] > counts[i + 1] ? counts[i] - counts[i + 1] : 0;
            countMode = "Differential";
        }

        return new TsiRecord(
            RecNum:              recNum,
            Timestamp:           ts,
            LocationId:          locNum,
            FlowType:            isLPM ? "LPM" : "CFM",
            FlowRate:            flowRate,
            PrecisionFlowRate:   precFlow,
            SampleTime:          sampleTime,
            CountMode:           countMode,
            DataValid:           dataValid,
            FlowOk:              flowOk,
            LaserOk:             laserOk,
            OpticsDirty:         opticsDirty,
            ScatterAlert:        scatterAlert,
            CalibrationCorrupt:  calCorrupt,
            ServiceAlert:        serviceAlert,
            Counts:              counts,
            ChSizes:             chSizes,
            ChAlarm:             chAlarm,
            Temperature:         temp,
            TempUnit:            tempUnit,
            Humidity:            hum,
            Velocity:            vel,
            Flow:                flow,
            CO2:                 co2,
            MeasurementEnabled:  measurementEnabled,
            DIUserId:            diUserId
        );
    }
}
