// TsiDeviceReader.cs
// Orchestratore di alto livello per le operazioni di lettura:
//   - connessione
//   - lettura device info (model, serial, mapRev, channels, ...)
//   - lettura numero di campioni
//   - lettura record singolo o bulk
//
// Segue la stessa sequenza di TSI_IPCommunication.ReadSampleRecords
// e ModbusInterpreter.InterpretData.

namespace TsiConsole;

public sealed class TsiDeviceReader
{
    private readonly TsiTcpClient _client;

    public DeviceInfo? Info { get; private set; }

    public TsiDeviceReader(TsiTcpClient client)
    {
        _client = client;
    }

    // ── Connessione e lettura device info ─────────────────────────────────────

    /// <summary>
    /// Connette al device e legge: MapRev, FirmwareVersion, Model, Serial,
    /// DeviceInfo completo (canali, flow unit, DataIntegrity, locations...).
    /// </summary>
    public DeviceInfo Connect()
    {
        _client.Connect();

        // 1. MapRev + FirmwareVersion (reg 40001, 2 reg)
        byte[] mapRevPkt  = TsiModbusPackets.ReadMapRevRegister();
        byte[] mapRevResp = _client.SendReceive(mapRevPkt);
        var (mapRev, fwVer) = TsiModbusInterpreter.ParseMapRev(mapRevResp);

        // 2. DeviceInfo completo (reg 40002, lunghezza in base a mapRev)
        byte[] infoPkt  = TsiModbusPackets.ReadDeviceInfo(mapRev: mapRev);
        byte[] infoResp = _client.SendReceive(infoPkt);
        var info = TsiModbusInterpreter.ParseDeviceInfo(infoResp, mapRev);

        // Se ParseDeviceInfo non disponibile (risposta troppo corta),
        // usa model/serial separati come fallback
        if (info == null)
        {
            byte[] modelResp  = _client.SendReceive(TsiModbusPackets.ReadModelNumber());
            byte[] serialResp = _client.SendReceive(TsiModbusPackets.ReadSerialNumber());
            string model  = TsiModbusInterpreter.ParseModel(modelResp);
            string serial = TsiModbusInterpreter.ParseSerial(serialResp);
            info = new DeviceInfo(
                MapRev: mapRev, FirmwareVersion: fwVer,
                Model: model, Serial: serial,
                NumberOfChannels: 8, NominalFlowRate: 0,
                FlowUnit: "CFM", HasDataIntegrity: false,
                ViableCounts: false, Unicode: false,
                NumberOfLocations: 0, NumberOfRecipes: 0,
                ChannelSizes: new ushort[16]);
        }

        Info = info;
        return info;
    }

    public void Disconnect() => _client.Disconnect();

    // ── Numero di campioni ────────────────────────────────────────────────────

    /// <summary>
    /// Legge il numero di campioni presenti in memoria nello strumento.
    /// Corrisponde a TSIModbusTCP.ReadNumberOfSamples → A_GET_NUMBER_OF_SAMPLES.
    /// </summary>
    public uint ReadNumberOfSamples()
    {
        byte[] resp = _client.SendReceive(TsiModbusPackets.ReadNumberOfSamples());
        return TsiModbusInterpreter.ParseNumberOfSamples(resp);
    }

    // ── Lettura singolo record ────────────────────────────────────────────────

    /// <summary>
    /// Legge il record all'indice specificato.
    /// Sequenza:
    ///   Write reg 41078 (hi word indice)  → ricevi ACK
    ///   Write reg 41079 (lo word indice)  → ricevi ACK
    ///   Read  reg 42005 (payload record)  → ricevi dati
    /// Corrisponde a TSIModbusTCP.ReadDataRecord /
    ///             TSI_IPCommunication.ReadSampleRecords (loop singolo).
    /// </summary>
    public TsiRecord? ReadRecord(uint index)
    {
        bool hasDI = Info?.HasDataIntegrity ?? false;

        // Imposta indice record nei registri 41078 (hi) e 41079 (lo)
        var (hiPkt, loPkt) = TsiModbusPackets.WriteRecordIndex(1, index);
        _client.Send(hiPkt);   // write + scarta ACK
        _client.Send(loPkt);   // write + scarta ACK

        // Leggi il payload del record
        byte[] readPkt = TsiModbusPackets.ReadRecord(hasDataIntegrity: hasDI);
        byte[] resp    = _client.SendReceive(readPkt);

        return TsiModbusInterpreter.ParseRecord(resp, hasDI);
    }

    // ── Lettura bulk ──────────────────────────────────────────────────────────

    /// <summary>
    /// Legge una sequenza di record a partire da startIndex.
    /// Restituisce IEnumerable per streaming: non carica tutto in RAM.
    /// Equivale al loop di TSI_IPCommunication.ReadSampleRecords.
    /// </summary>
    public IEnumerable<(uint Index, TsiRecord? Record)> ReadRecords(
        uint startIndex,
        uint count,
        IProgress<(uint Done, uint Total)>? progress = null)
    {
        for (uint i = 0; i < count; i++)
        {
            uint idx = startIndex + i;
            TsiRecord? rec = ReadRecord(idx);
            progress?.Report((i + 1, count));
            yield return (idx, rec);
        }
    }
}
