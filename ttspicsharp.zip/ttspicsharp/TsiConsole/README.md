# TsiConsole — C# Console App per strumenti TSI

Console app **.NET 8** che si connette a un particle counter TSI (serie 9xxx)
via **Modbus TCP** (porta 502) e legge:

- Informazioni device (modello, seriale, canali, flow unit, DataIntegrity…)
- Numero di campioni memorizzati
- Record di campionamento singoli o in bulk

## Struttura file

| File | Contenuto |
|---|---|
| `TsiModbusPackets.cs` | Costruisce i pacchetti Modbus TCP raw (FC3/FC6). Estratto da `TSIModbusTCP.cs`. |
| `TsiModbusInterpreter.cs` | Decodifica le risposte binarie. Estratto da `ModbusInterpreter.cs`. |
| `TsiTcpClient.cs` | Client TCP con Connect/Send/Receive. Estratto da `TSI_IPCommunication.cs`. |
| `TsiDeviceReader.cs` | Orchestratore: Connect → ReadDeviceInfo → ReadRecord(s). |
| `Program.cs` | Entry point, parsing argomenti, output formattato a console. |

## Compilazione

```powershell
cd C:\Users\Sasa\Desktop\ttspicsharp\TsiConsole
dotnet build -c Release
```

## Esecuzione

```
dotnet run -- <ip> [port] [opzioni]
```

oppure dopo la build:
```
.\bin\Release\net8.0\TsiConsole.exe <ip> [opzioni]
```

### Opzioni

| Opzione | Default | Descrizione |
|---|---|---|
| `<ip>` | — | Indirizzo IP dello strumento (obbligatorio) |
| `[port]` | `502` | Porta Modbus TCP |
| `--max <n>` | `50` | Numero massimo di record da leggere |
| `--from <idx>` | `0` | Indice del primo record da leggere (0-based) |
| `--info-only` | — | Legge solo le info del device, salta i record |

### Esempi

```powershell
# Connetti e leggi i primi 50 record
dotnet run -- 192.168.1.50

# Leggi solo le info del device
dotnet run -- 192.168.1.50 --info-only

# Leggi 10 record a partire dall'indice 100
dotnet run -- 192.168.1.50 502 --from 100 --max 10

# Porta custom
dotnet run -- 192.168.1.50 5020 --max 5
```

## Protocollo Modbus TSI — sequenza di lettura

```
1. Read  reg 40001 (2 reg) → MapRev + FirmwareVersion
2. Read  reg 40002 (65/77/89 reg) → DeviceInfo completo
3. Read  reg 42001 (2 reg) → numero campioni (uint32)
4. Per ogni record:
     Write reg 41078  → high word dell'indice (FC6)
     Write reg 41079  → low  word dell'indice (FC6)
     Read  reg 42005 (118/119 reg) → payload record
```

## Registri chiave

| Registro | Descrizione |
|---|---|
| 40001 | MapRev + FirmwareVersion |
| 40002 | DeviceInfo (model, serial, channels, flow, DI…) |
| 40003 | Model ASCII (8 reg) |
| 40011 | Serial ASCII (8 reg) |
| 41001 | Command register |
| 41002 | Device status |
| 41078-79 | Indice record da leggere (hi/lo uint32) |
| 42001-02 | Numero totale campioni (uint32) |
| 42005+ | Payload record corrente (118/119 reg) |

## Output di esempio

```
══════════════════════════════════
  TSI Particle Counter — Console Reader
══════════════════════════════════

  Indirizzo : 192.168.1.50:502
  Max record: 50  |  Da indice: 0

  Connessione... Connesso

  ── DEVICE INFO ──
    Modello             : AEROTRAK 9110
    Numero di serie     : SN12345678
    MapRev              : 207
    Firmware            : 315
    Canali              : 6
    Flow nominale       : 1.00 CFM
    Data Integrity      : No
    Canali µm           : 0.300 µm  0.500 µm  0.700 µm  1.000 µm  3.000 µm  5.000 µm

  ── RECORD DI CAMPIONAMENTO (indici 0–4 di 128) ──

  ┌─ Record #1  (indice 0)
  │  Timestamp     : 2024-03-15 09:30:00
  │  Stato dati    : ✓ Valido
  │  Status device : OK
  │  Loc. ID       : 1
  │  Flow rate     : 1.00 CFM
  │  Tempo camp.   : 60 s
  │  Modalità      : Differential
  │  Temperatura   : 22.4 °C
  │  Umidità       : 45.2 %RH
  │
  │  Canale        Dimensione    Conteggio  Allarme
  │  ──────────────────────────────────────────────
  │  Ch 1           0.300 µm         1254       no
  │  Ch 2           0.500 µm          387       no
  │  Ch 3           0.700 µm           92       no
  │  Ch 4           1.000 µm           18       no
  │  Ch 5           3.000 µm            2       no
  │  Ch 6           5.000 µm            0       no
  └──────────────────────────────────────────────
```
