// TsiModbusPackets.cs
// Costruisce i pacchetti Modbus TCP raw.
// Estratto direttamente da TSI.ModbusTCP.TSIModbusTCP (TrakProLiteClassLibrary.dll).
//
// Struttura pacchetto Modbus TCP (12 byte):
//   [0-1] Transaction ID (random)
//   [2-3] Protocol ID = 0x0000
//   [4-5] Length = 0x0006
//   [6]   Unit ID (address)
//   [7]   Function code: 0x03 = Read Holding Registers, 0x06 = Write Single Register
//   [8-9] Start register (0-based binary address)
//   [10-11] Read: numero registri da leggere  |  Write: valore da scrivere

namespace TsiConsole;

internal static class TsiModbusPackets
{
    private static readonly Random _rng = new();

    // ── BinaryAddress ──────────────────────────────────────────────────────────
    // Converte l'indirizzo 1-based del registro Modbus nel 0-based usato nel
    // payload binario. Formula originale: reg - 40001.
    // Es. 42005 → 2004,  40003 → 2,  41001 → 1000
    public static ushort BinaryAddress(ushort regAddr) =>
        (ushort)(regAddr - 40001u);

    // ── Read (FC3 — Read Holding Registers) ───────────────────────────────────
    // Genera il pacchetto di lettura.
    // unit  : unit ID (tipicamente 1)
    // start : indirizzo 0-based (usa BinaryAddress prima di passarlo)
    // length: numero di registri da leggere (max 125)
    public static byte[] Read(byte unit, ushort start, ushort length)
    {
        if (length > 125)
            throw new ArgumentOutOfRangeException(nameof(length), length,
                "Non si possono richiedere più di 125 registri in un singolo pacchetto FC3.");

        ushort tid = (ushort)_rng.Next(ushort.MaxValue);
        byte[] pkt = new byte[12];
        pkt[0]  = (byte)((tid & 0xFF00) >> 8);
        pkt[1]  = (byte)(tid  & 0x00FF);
        pkt[2]  = 0x00;                         // Protocol ID hi
        pkt[3]  = 0x00;                         // Protocol ID lo
        pkt[4]  = 0x00;                         // Length hi
        pkt[5]  = 0x06;                         // Length lo
        pkt[6]  = unit;                         // Unit ID
        pkt[7]  = 0x03;                         // FC3 = Read Holding Registers
        pkt[8]  = (byte)((start  & 0xFF00) >> 8);
        pkt[9]  = (byte)(start   & 0x00FF);
        pkt[10] = (byte)((length & 0xFF00) >> 8);
        pkt[11] = (byte)(length  & 0x00FF);
        return pkt;
    }

    // ── Write (FC6 — Write Single Register) ───────────────────────────────────
    // Genera il pacchetto di scrittura di un singolo registro.
    // addr  : unit ID
    // reg   : indirizzo 0-based
    // value : valore ushort da scrivere
    public static byte[] Write(byte addr, ushort reg, ushort value)
    {
        ushort tid = (ushort)_rng.Next(ushort.MaxValue);
        byte[] pkt = new byte[12];
        pkt[0]  = (byte)((tid   & 0xFF00) >> 8);
        pkt[1]  = (byte)(tid    & 0x00FF);
        pkt[2]  = 0x00;
        pkt[3]  = 0x00;
        pkt[4]  = 0x00;
        pkt[5]  = 0x06;
        pkt[6]  = addr;
        pkt[7]  = 0x06;                         // FC6 = Write Single Register
        pkt[8]  = (byte)((reg   & 0xFF00) >> 8);
        pkt[9]  = (byte)(reg    & 0x00FF);
        pkt[10] = (byte)((value & 0xFF00) >> 8);
        pkt[11] = (byte)(value  & 0x00FF);
        return pkt;
    }

    // ── Pacchetti compositi (estratti da TSIModbusTCP) ─────────────────────────

    /// <summary>Legge il modello (reg 40003, 8 registri = 16 byte ASCII).</summary>
    public static byte[] ReadModelNumber(byte addr = 1) =>
        Read(addr, BinaryAddress(40003), 8);

    /// <summary>Legge il numero di serie (reg 40011, 8 registri).</summary>
    public static byte[] ReadSerialNumber(byte addr = 1) =>
        Read(addr, BinaryAddress(40011), 8);

    /// <summary>
    /// Legge il numero totale di campioni memorizzati nello strumento
    /// (reg 42001, 2 registri → uint32).
    /// </summary>
    public static byte[] ReadNumberOfSamples(byte addr = 1) =>
        Read(addr, BinaryAddress(42001), 2);

    /// <summary>
    /// Legge le informazioni del device (reg 40002).
    /// mapRev: registro di revisione mappa (letto prima con ReadMapRevRegister).
    ///   ≤ 200 → 65 registri
    ///   201-206 → 77 registri
    ///   ≥ 207  → 89 registri
    /// </summary>
    public static byte[] ReadDeviceInfo(byte addr = 1, ushort mapRev = 200)
    {
        ushort len = mapRev < 207
            ? (mapRev <= 200 ? (ushort)65 : (ushort)77)
            : (ushort)89;
        return Read(addr, BinaryAddress(40002), len);
    }

    /// <summary>Legge il registro di revisione mappa (reg 40001, 2 registri).</summary>
    public static byte[] ReadMapRevRegister(byte addr = 1) =>
        Read(addr, BinaryAddress(40001), 2);

    /// <summary>Legge lo stato del device (reg 41002, 1 registro).</summary>
    public static byte[] GetDeviceStatus(byte addr = 1) =>
        Read(addr, BinaryAddress(41002), 1);

    // ── Scrittura indice record ────────────────────────────────────────────────
    // L'indice viene spezzato in due registri:
    //   41078 → high word (byte [2-3] del uint32 in little-endian)
    //   41079 → low  word (byte [0-1])
    // Estratto da TSIModbusTCP.WriteSampleRecordIndex / ReadDataRecord.

    /// <summary>
    /// Restituisce i due pacchetti Write per impostare l'indice del record
    /// da leggere (registri 41078 hi, 41079 lo).
    /// </summary>
    public static (byte[] HiPkt, byte[] LoPkt) WriteRecordIndex(byte addr, uint index)
    {
        byte[] bytes = BitConverter.GetBytes(index);      // little-endian
        ushort hiWord = BitConverter.ToUInt16(bytes, 2);  // byte [3,2]
        ushort loWord = BitConverter.ToUInt16(bytes, 0);  // byte [1,0]
        return (
            Write(addr, BinaryAddress(41078), hiWord),
            Write(addr, BinaryAddress(41079), loWord)
        );
    }

    /// <summary>
    /// Pacchetto di lettura del payload del record corrente
    /// (reg 42005, 118 registri senza DataIntegrity, 119 con DataIntegrity).
    /// </summary>
    public static byte[] ReadRecord(byte addr = 1, bool hasDataIntegrity = false)
    {
        // Formula originale: (hasDataIntegrity ? 42123 : 42122) - 42005 + 1
        ushort len = hasDataIntegrity ? (ushort)119 : (ushort)118;
        return Read(addr, BinaryAddress(42005), len);
    }
}
